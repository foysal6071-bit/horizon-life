// Sunny Drift - roadside Swiss-style guide posts (white plastic delineators with a black band + reflectors, no rope) + galvanised steel lamp poles. Originally the wooden post-and-rope fence + wooden lamp poles: C++ port of the HTML "Roadside border" block (FENCE),
// fencePosts() (car <-> post / rope collision) and the "street lamps" block (lampCollide). Pure C++, no OpenGL (see fence_render.h).
//  * a rustic post every 3 m on both edges of every road (2.8 m outside the tarmac), a sagging twisted rope between neighbours.
//    Stops 10 m before every junction, is left out across the river / bridges, the dirt track and the coast  (okAt in the HTML)
//  * the car's body (a box) knocks posts over: the post is thrown away from the car AND along its motion (faster = further), spins and
//    tumbles to lie on the ground, dirt + splinters burst up, the rope between a broken post and its neighbour drops loose
//    and wiggles on the ground. The car loses a little speed (x0.93 post, x0.95 rope). A broken post is put back once the car has
//    driven a whole lap of that road and is > 40 m away  (breakPost / step / restore in the HTML)
//  * a rope that crosses the car body knocks down the nearer post as well (the car never drives through a rope)
//  * lamp poles are solid: the car box is pushed out of the pole, bounces off, and a hard hit leaves the pole leaning away
#pragma once
#include <algorithm>
#include <cmath>
#include <functional>
#include <cstdint>
#include <random>
#include <unordered_map>
#include <vector>
#include "road.h"
#include "terrain.h"
#include "bridge.h"
#include "car_core.h"
#include "quality.h"

namespace Fence {

static const double PI = 3.14159265358979323846;
static const int    SP = 25;                     // post spacing (m): Swiss Leitpfosten stand every 25 m (50 m on long straights)
static const bool   kRopes = false;              // no ropes between the posts (they are delineators, not a fence)
static std::function<bool(double, double)> gGuardVeto;   // set by the game before init(): true where a guardrail would block a driveway (next to a house)
static const double GR_OFF = 1.1;                // guardrail distance from the tarmac edge (m)
static const double OFF = 0.9;                   // distance from the tarmac edge to the post (guide posts stand right at the shoulder)
static const double CELL = 8;                    // spatial grid cell for the car
static const double LAMP_H = 8.5;                // street lamp height (galvanised steel pole)
static const double LAMP_ARM = 2.2;              // reach of the lamp arm over the road (m)
static const double FAR_DIST = 260.0;            // posts / ropes farther than this are not drawn

static inline double hsh(double a, double b){ const double h = std::sin(a * 127.1 + b * 311.7) * 43758.5453; return h - std::floor(h); }
static inline double smoothS(double a, double b, double x){ double k = std::min(std::max((x - a) / (b - a), 0.0), 1.0); return k*k*(3 - 2*k); }
static inline double jr(double v){ return std::floor(v + 0.5); }          // JS Math.round
static inline double clampv(double v, double a, double b){ return std::min(std::max(v, a), b); }

static std::mt19937 gRng(20260123);
static double rn(){ return std::uniform_real_distribution<double>(0.0, 1.0)(gRng); }

// ======================================================================= tiny mesh toolkit (three.js geometry look-alikes)
struct Mesh {
    std::vector<float> p, n, uv, c; std::vector<uint16_t> idx;
    int vc() const { return (int)(p.size() / 3); }
};
static void computeNormals(Mesh& m){
    const int nv = m.vc(); std::vector<double> nr(nv * 3, 0.0);
    for (size_t f = 0; f + 2 < m.idx.size(); f += 3){
        const int a = m.idx[f], b = m.idx[f+1], c = m.idx[f+2];
        double A[3], B[3], C[3]; for (int k = 0; k < 3; k++){ A[k] = m.p[a*3+k]; B[k] = m.p[b*3+k]; C[k] = m.p[c*3+k]; }
        const double cb[3] = {C[0]-B[0], C[1]-B[1], C[2]-B[2]}, ab[3] = {A[0]-B[0], A[1]-B[1], A[2]-B[2]};
        const double n[3] = {cb[1]*ab[2] - cb[2]*ab[1], cb[2]*ab[0] - cb[0]*ab[2], cb[0]*ab[1] - cb[1]*ab[0]};
        for (int k = 0; k < 3; k++){ nr[a*3+k] += n[k]; nr[b*3+k] += n[k]; nr[c*3+k] += n[k]; }
    }
    m.n.assign(nv * 3, 0.f);
    for (int i = 0; i < nv; i++){
        double l = std::sqrt(nr[i*3]*nr[i*3] + nr[i*3+1]*nr[i*3+1] + nr[i*3+2]*nr[i*3+2]); if (l == 0) l = 1;
        for (int k = 0; k < 3; k++) m.n[i*3+k] = (float)(nr[i*3+k] / l);
    }
}
static void whiten(Mesh& m){ if ((int)m.c.size() != m.vc() * 3) m.c.assign((size_t)m.vc() * 3, 1.f); }
static void tr(Mesh& m, double x, double y, double z){ for (int i = 0; i < m.vc(); i++){ m.p[i*3] += (float)x; m.p[i*3+1] += (float)y; m.p[i*3+2] += (float)z; } }
static void scl(Mesh& m, double x, double y, double z){ for (int i = 0; i < m.vc(); i++){ m.p[i*3] *= (float)x; m.p[i*3+1] *= (float)y; m.p[i*3+2] *= (float)z; } }
static void rotX(Mesh& m, double a){ const double c = std::cos(a), s = std::sin(a); for (int i = 0; i < m.vc(); i++){ double y = m.p[i*3+1], z = m.p[i*3+2]; m.p[i*3+1] = (float)(c*y - s*z); m.p[i*3+2] = (float)(s*y + c*z); } }
static void rotY(Mesh& m, double a){ const double c = std::cos(a), s = std::sin(a); for (int i = 0; i < m.vc(); i++){ double x = m.p[i*3], z = m.p[i*3+2]; m.p[i*3] = (float)(c*x + s*z); m.p[i*3+2] = (float)(-s*x + c*z); } }
static void rotZ(Mesh& m, double a){ const double c = std::cos(a), s = std::sin(a); for (int i = 0; i < m.vc(); i++){ double x = m.p[i*3], y = m.p[i*3+1]; m.p[i*3] = (float)(c*x - s*y); m.p[i*3+1] = (float)(s*x + c*y); } }
static void setUV(Mesh& m, double u, double v){ for (int i = 0; i < m.vc(); i++){ m.uv[i*2] = (float)u; m.uv[i*2+1] = (float)v; } }
static void paintAll(Mesh& m, double r, double g, double b){ m.c.resize((size_t)m.vc() * 3); for (int i = 0; i < m.vc(); i++){ m.c[i*3] = (float)r; m.c[i*3+1] = (float)g; m.c[i*3+2] = (float)b; } }

// CylinderGeometry(rTop, rBottom, h, radial, heightSeg, openEnded)  (same vertex / index layout as three.js)
static Mesh cylinder(double rt, double rb, double h, int rad, int hs, bool open){
    Mesh m; std::vector<std::vector<int>> grid;
    for (int iy = 0; iy <= hs; iy++){
        std::vector<int> row; const double v = (double)iy / hs, r = v * (rb - rt) + rt;
        for (int ix = 0; ix <= rad; ix++){
            const double u = (double)ix / rad, th = u * 2 * PI;
            m.p.push_back((float)(r * std::sin(th))); m.p.push_back((float)(-v * h + h / 2)); m.p.push_back((float)(r * std::cos(th)));
            m.uv.push_back((float)u); m.uv.push_back((float)(1 - v)); row.push_back(m.vc() - 1);
        }
        grid.push_back(row);
    }
    for (int ix = 0; ix < rad; ix++) for (int iy = 0; iy < hs; iy++){
        const int a = grid[iy][ix], b = grid[iy+1][ix], c = grid[iy+1][ix+1], d = grid[iy][ix+1];
        if (rt > 0 || iy != 0){ m.idx.push_back(a); m.idx.push_back(b); m.idx.push_back(d); }
        if (rb > 0 || iy != hs - 1){ m.idx.push_back(b); m.idx.push_back(c); m.idx.push_back(d); }
    }
    if (!open) for (int top = 0; top < 2; top++){
        const double r = top ? rt : rb; if (r <= 0) continue; const double sg = top ? 1 : -1, y = sg * h / 2;
        const int ctr = m.vc(); m.p.push_back(0); m.p.push_back((float)y); m.p.push_back(0); m.uv.push_back(.5f); m.uv.push_back(.5f);
        const int r0 = m.vc();
        for (int ix = 0; ix <= rad; ix++){
            const double th = (double)ix / rad * 2 * PI, s = std::sin(th), c = std::cos(th);
            m.p.push_back((float)(r * s)); m.p.push_back((float)y); m.p.push_back((float)(r * c)); m.uv.push_back((float)(c * .5 + .5)); m.uv.push_back((float)(s * .5 * sg + .5));
        }
        for (int x = 0; x < rad; x++){
            if (top){ m.idx.push_back(r0 + x); m.idx.push_back(r0 + x + 1); m.idx.push_back(ctr); }
            else    { m.idx.push_back(r0 + x + 1); m.idx.push_back(r0 + x); m.idx.push_back(ctr); }
        }
    }
    computeNormals(m); whiten(m); return m;
}
// TorusGeometry(R, tube, radialSeg, tubularSeg)
static Mesh torus(double R, double tube, int rs, int ts){
    Mesh m;
    for (int j = 0; j <= rs; j++) for (int i = 0; i <= ts; i++){
        const double u = (double)i / ts * 2 * PI, v = (double)j / rs * 2 * PI;
        m.p.push_back((float)((R + tube * std::cos(v)) * std::cos(u))); m.p.push_back((float)((R + tube * std::cos(v)) * std::sin(u))); m.p.push_back((float)(tube * std::sin(v)));
        m.uv.push_back((float)i / ts); m.uv.push_back((float)j / rs);
    }
    for (int j = 1; j <= rs; j++) for (int i = 1; i <= ts; i++){
        const int a = (ts + 1) * j + i - 1, b = (ts + 1) * (j - 1) + i - 1, c = (ts + 1) * (j - 1) + i, d = (ts + 1) * j + i;
        m.idx.push_back(a); m.idx.push_back(b); m.idx.push_back(d); m.idx.push_back(b); m.idx.push_back(c); m.idx.push_back(d);
    }
    computeNormals(m); whiten(m); return m;
}
// SphereGeometry(r, wSeg, hSeg)
static Mesh sphere(double r, int ws, int hs){
    Mesh m; std::vector<std::vector<int>> grid;
    for (int iy = 0; iy <= hs; iy++){
        std::vector<int> row; const double v = (double)iy / hs;
        for (int ix = 0; ix <= ws; ix++){
            const double u = (double)ix / ws;
            m.p.push_back((float)(-r * std::cos(u * 2 * PI) * std::sin(v * PI))); m.p.push_back((float)(r * std::cos(v * PI))); m.p.push_back((float)(r * std::sin(u * 2 * PI) * std::sin(v * PI)));
            m.uv.push_back((float)u); m.uv.push_back((float)(1 - v)); row.push_back(m.vc() - 1);
        }
        grid.push_back(row);
    }
    for (int iy = 0; iy < hs; iy++) for (int ix = 0; ix < ws; ix++){
        const int a = grid[iy][ix+1], b = grid[iy][ix], c = grid[iy+1][ix], d = grid[iy+1][ix+1];
        if (iy != 0){ m.idx.push_back(a); m.idx.push_back(b); m.idx.push_back(d); }
        if (iy != hs - 1){ m.idx.push_back(b); m.idx.push_back(c); m.idx.push_back(d); }
    }
    computeNormals(m); whiten(m); return m;
}
// BoxGeometry(w, h, d)
static Mesh box(double w, double h, double d){
    Mesh m;
    const int A[6][3] = {{2,1,0},{2,1,0},{0,2,1},{0,2,1},{0,1,2},{0,1,2}};
    const double S[6][3] = {{-1,-1,1},{1,-1,-1},{1,1,1},{1,-1,-1},{1,-1,1},{-1,-1,-1}}, dim[3] = {w, h, d};
    for (int f = 0; f < 6; f++){
        const int base = m.vc();
        for (int iy = 0; iy < 2; iy++) for (int ix = 0; ix < 2; ix++){
            double v[3]; v[A[f][0]] = ix * dim[A[f][0]] * S[f][0] + (-dim[A[f][0]] * S[f][0] / 2) ; v[A[f][1]] = iy * dim[A[f][1]] * S[f][1] + (-dim[A[f][1]] * S[f][1] / 2); v[A[f][2]] = dim[A[f][2]] / 2 * S[f][2];
            m.p.push_back((float)v[0]); m.p.push_back((float)v[1]); m.p.push_back((float)v[2]); m.uv.push_back((float)ix); m.uv.push_back((float)(1 - iy));
        }
        m.idx.push_back(base); m.idx.push_back(base + 2); m.idx.push_back(base + 1); m.idx.push_back(base + 2); m.idx.push_back(base + 3); m.idx.push_back(base + 1);
    }
    computeNormals(m);
    // make sure every face points outwards (the winding above is only a guess): flip faces whose normal looks towards the centre
    for (size_t f = 0; f + 2 < m.idx.size(); f += 3){
        const int a = m.idx[f], b = m.idx[f+1], c = m.idx[f+2]; double cx = 0, cy = 0, cz = 0, n[3];
        for (int k : {a, b, c}){ cx += m.p[k*3]; cy += m.p[k*3+1]; cz += m.p[k*3+2]; } cx /= 3; cy /= 3; cz /= 3;
        const double A_[3] = {m.p[a*3], m.p[a*3+1], m.p[a*3+2]}, B_[3] = {m.p[b*3], m.p[b*3+1], m.p[b*3+2]}, C_[3] = {m.p[c*3], m.p[c*3+1], m.p[c*3+2]};
        const double cb[3] = {C_[0]-B_[0], C_[1]-B_[1], C_[2]-B_[2]}, ab[3] = {A_[0]-B_[0], A_[1]-B_[1], A_[2]-B_[2]};
        n[0] = cb[1]*ab[2] - cb[2]*ab[1]; n[1] = cb[2]*ab[0] - cb[0]*ab[2]; n[2] = cb[0]*ab[1] - cb[1]*ab[0];
        if (n[0]*cx + n[1]*cy + n[2]*cz < 0) std::swap(m.idx[f+1], m.idx[f+2]);
    }
    computeNormals(m); whiten(m); return m;
}
// IcosahedronGeometry(1, 0), flat shaded (dirt / splinter chunks)
static Mesh icosahedron(){
    const double t = (1 + std::sqrt(5.0)) / 2; const double V[12][3] = {{-1,t,0},{1,t,0},{-1,-t,0},{1,-t,0},{0,-1,t},{0,1,t},{0,-1,-t},{0,1,-t},{t,0,-1},{t,0,1},{-t,0,-1},{-t,0,1}};
    const int F[20][3] = {{0,11,5},{0,5,1},{0,1,7},{0,7,10},{0,10,11},{1,5,9},{5,11,4},{11,10,2},{10,7,6},{7,1,8},{3,9,4},{3,4,2},{3,2,6},{3,6,8},{3,8,9},{4,9,5},{2,4,11},{6,2,10},{8,6,7},{9,8,1}};
    Mesh m;
    for (auto& f : F){
        double P[3][3]; for (int k = 0; k < 3; k++){ const double l = std::sqrt(V[f[k]][0]*V[f[k]][0] + V[f[k]][1]*V[f[k]][1] + V[f[k]][2]*V[f[k]][2]); for (int c = 0; c < 3; c++) P[k][c] = V[f[k]][c] / l; }
        const double e1[3] = {P[1][0]-P[0][0], P[1][1]-P[0][1], P[1][2]-P[0][2]}, e2[3] = {P[2][0]-P[0][0], P[2][1]-P[0][1], P[2][2]-P[0][2]};
        double n[3] = {e1[1]*e2[2]-e1[2]*e2[1], e1[2]*e2[0]-e1[0]*e2[2], e1[0]*e2[1]-e1[1]*e2[0]}; const double nl = std::sqrt(n[0]*n[0]+n[1]*n[1]+n[2]*n[2]); for (double& q : n) q /= nl;
        if (n[0]*(P[0][0]+P[1][0]+P[2][0]) + n[1]*(P[0][1]+P[1][1]+P[2][1]) + n[2]*(P[0][2]+P[1][2]+P[2][2]) < 0){ for (int c = 0; c < 3; c++) std::swap(P[1][c], P[2][c]); for (double& q : n) q = -q; }
        for (int k = 0; k < 3; k++){ for (int c = 0; c < 3; c++){ m.p.push_back((float)P[k][c]); m.n.push_back((float)n[c]); } m.uv.push_back(0); m.uv.push_back(0); m.idx.push_back((uint16_t)(m.vc() - 1)); }
    }
    whiten(m); return m;
}
static Mesh merge(std::vector<Mesh> gs){
    Mesh o; for (Mesh& g : gs){
        whiten(g); const uint16_t base = (uint16_t)o.vc();
        o.p.insert(o.p.end(), g.p.begin(), g.p.end()); o.n.insert(o.n.end(), g.n.begin(), g.n.end());
        o.uv.insert(o.uv.end(), g.uv.begin(), g.uv.end()); o.c.insert(o.c.end(), g.c.begin(), g.c.end());
        for (uint16_t i : g.idx) o.idx.push_back((uint16_t)(i + base));
    } return o;
}
// WoodBeam from the lamp code: box whose grain runs along its long axis (ax 0 = x, 1 = y)
static Mesh woodBeam(double w, double h, double d, int ax){
    Mesh g = box(w, h, d);
    for (int i = 0; i < g.vc(); i++){
        const double x = g.p[i*3], y = g.p[i*3+1], z = g.p[i*3+2], along = ax == 0 ? x : y, across = ax == 0 ? (y + z) : (x + z);
        g.uv[i*2] = (float)(across * 1.6 + 0.5); g.uv[i*2+1] = (float)(along * 0.9 + 0.5);
    }
    return g;
}

// ======================================================================= geometry (post, mound, rope, lamp) - built once
static const int RS = 10;                        // rope pieces per section
static const int RSEG = 8;                       // pieces of a loose (snapped) rope
struct Geo {
    Mesh post, mound, rope, seg, part, pole, shade, head, grail, gpost, swall;
    std::vector<uint8_t> barkTex, ropeTex, woodTex; int barkW = 128, barkH = 256, ropeS = 32, woodW = 128, woodH = 256;
};
static Geo G;

static void buildPost(){
    // ---- Swiss guide post (Leitpfosten): white plastic round post, black band near the top with a retroreflector on both faces (they look along the road)
    std::vector<Mesh> parts;
    { Mesh g = cylinder(0.050, 0.056, 1.0, 12, 1, false); tr(g, 0, 0.5, 0);
      g.c.resize((size_t)g.vc() * 3);
      for (int i = 0; i < g.vc(); i++){ const double y = g.p[i*3+1], v = 0.74 - 0.20 * (1 - smoothS(0.0, 0.25, y)) + (hsh(i, 3) - 0.5) * 0.03;   // dirty foot, clean top
        g.c[i*3] = (float)v; g.c[i*3+1] = (float)v; g.c[i*3+2] = (float)(v * 0.97); }
      parts.push_back(g); }
    { Mesh g = cylinder(0.0, 0.050, 0.05, 12, 1, true); tr(g, 0, 1.025, 0); paintAll(g, 0.74, 0.74, 0.72); parts.push_back(g); }               // domed cap
    { Mesh g = cylinder(0.0575, 0.0575, 0.17, 12, 1, true); tr(g, 0, 0.78, 0); paintAll(g, 0.012, 0.012, 0.014); parts.push_back(g); }             // black band
    for (int sg : {-1, 1}){ Mesh r = box(0.046, 0.085, 0.012); tr(r, 0, 0.78, sg * 0.0575); paintAll(r, 0.85, 0.85, 0.80); parts.push_back(r); }    // retroreflectors
    for (int sg : {-1, 1}){ Mesh r = box(0.062, 0.100, 0.006); tr(r, 0, 0.78, sg * 0.0555); paintAll(r, 0.03, 0.03, 0.03); parts.push_back(r); }    // dark frame behind each reflector
    G.post = merge(parts);

    // ---- mound of soil round the foot (dark soil heap, a few stones, sparse grass)
    std::vector<Mesh> ms;
    { Mesh m0 = cylinder(0.11, 0.27, 0.11, 12, 1, false);
      for (int i = 0; i < m0.vc(); i++){ const double k = 1 + (hsh(i, 5) - 0.5) * 0.34; m0.p[i*3] = (float)(m0.p[i*3] * k); m0.p[i*3+1] = (float)(m0.p[i*3+1] + 0.01); m0.p[i*3+2] = (float)(m0.p[i*3+2] * k); }
      computeNormals(m0); m0.c.resize((size_t)m0.vc() * 3);
      for (int i = 0; i < m0.vc(); i++){ const double v = 0.26 + (hsh(i, 2) - 0.5) * 0.12, e = std::min(1.0, std::hypot(m0.p[i*3], m0.p[i*3+2]) / 0.25);
        m0.c[i*3] = (float)(v * (1 - 0.2 * e)); m0.c[i*3+1] = (float)(v * 0.74 * (1 - 0.15 * e)); m0.c[i*3+2] = (float)(v * 0.52); }
      ms.push_back(m0); }
    for (int k = 0; k < 4; k++){
        const double a = hsh(k, 11) * 6.283, r = 0.10 + hsh(k, 12) * 0.11, s = 0.028 + hsh(k, 13) * 0.03;
        Mesh g = sphere(s, 6, 4); scl(g, 1, 0.55, 0.9); rotY(g, hsh(k, 14) * 3); tr(g, std::cos(a) * r, 0.045, std::sin(a) * r); computeNormals(g);
        const double v = 0.38 + hsh(k, 15) * 0.16; paintAll(g, v, v * 0.97, v * 0.90); ms.push_back(g);
    }
    for (int k = 0; k < 7; k++){
        const double a = hsh(k, 21) * 6.283, r = 0.085 + hsh(k, 22) * 0.12;
        Mesh g = cylinder(0.0, 0.010, 0.13 + hsh(k, 23) * 0.10, 3, 1, true);                                  // ConeGeometry(0.010, h, 3, 1, open)
        tr(g, 0, 0.07, 0); rotZ(g, (hsh(k, 24) - 0.5) * 0.7); rotX(g, (hsh(k, 25) - 0.5) * 0.7); tr(g, std::cos(a) * r, 0.03, std::sin(a) * r); computeNormals(g);
        const double gv = 0.7 + hsh(k, 26) * 0.5; g.c.resize((size_t)g.vc() * 3);
        for (int i = 0; i < g.vc(); i++){ const double y = g.p[i*3+1]; g.c[i*3] = (float)(0.16 * gv); g.c[i*3+1] = (float)(0.27 * gv * (0.7 + std::min(1.0, y * 5) * 0.3)); g.c[i*3+2] = (float)(0.07 * gv); }
        ms.push_back(g);
    }
    G.mound = merge(ms); setUV(G.mound, 124.5 / 128, 0.5);

    // ---- rope: 10 round pieces following a sagging curve, 1 m long along +z (stretched to the section later); diagonal stripes = the twist
    std::vector<Mesh> rp;
    for (int k = 0; k < RS; k++){
        auto yAt = [](double z){ return 0.905 - 0.16 * (1 - (2*z) * (2*z)); };
        const double z0 = -0.5 + (double)k / RS, z1 = -0.5 + (double)(k + 1) / RS, y0 = yAt(z0), y1 = yAt(z1), L = std::hypot(z1 - z0, y1 - y0) + 0.012;
        Mesh g = cylinder(0.026, 0.026, L, 6, 1, true); rotX(g, PI / 2); rotX(g, -std::atan2(y1 - y0, z1 - z0)); tr(g, 0, (y0 + y1) / 2, (z0 + z1) / 2); computeNormals(g);
        for (int i = 0; i < g.vc(); i++) g.uv[i*2+1] = (float)((g.p[i*3+2] + 0.5) * 44);
        rp.push_back(g);
    }
    G.rope = merge(rp);
    // loose rope piece: unit cylinder along z
    { Mesh g = cylinder(0.026, 0.026, 1, 6, 1, true); rotX(g, PI / 2); computeNormals(g); for (int i = 0; i < g.vc(); i++) g.uv[i*2+1] = (float)((g.p[i*3+2] + 0.5) * 6); G.seg = g; }
    G.part = icosahedron();
}

// round steel tube between two points in the lamp's xy plane (x < 0 = towards the road)
static Mesh tubeXY(double x0, double y0, double x1, double y1, double r){
    const double dx = x1 - x0, dy = y1 - y0, L = std::hypot(dx, dy); Mesh g = cylinder(r, r, L, 14, 1, false);
    rotZ(g, std::atan2(-dx, dy)); tr(g, (x0 + x1) / 2, (y0 + y1) / 2, 0); computeNormals(g); return g;
}
static void buildGuardMesh(){
    // galvanised W-beam: flat web + three corrugation ridges + rolled edges, bolt heads at the splice, dark spacer blocks; C-post with reflector
    std::vector<Mesh> b;
    auto add=[&](Mesh g,double x,double y,double z,double v,double bl=1.0){ tr(g,x,y,z); paintAll(g,v*0.97,v,v*1.03*bl); b.push_back(g); };
    { // real W-beam: ONE smooth ribbon (corners rounded by Chaikin corner cutting) instead of 9 flat strips -> soft rounded humps, smooth normals, fewer vertices
      std::vector<std::pair<double,double>> pr = {{0.0,0.755},{0.0,0.725},{-0.040,0.692},{-0.040,0.668},{0.0,0.632},{0.0,0.568},{-0.040,0.532},{-0.040,0.508},{0.0,0.472},{0.0,0.445}};
      for (int it = 0; it < 3; it++){ std::vector<std::pair<double,double>> q; q.push_back(pr.front());
        for (size_t i = 0; i + 1 < pr.size(); i++){ q.push_back({0.75*pr[i].first + 0.25*pr[i+1].first, 0.75*pr[i].second + 0.25*pr[i+1].second}); q.push_back({0.25*pr[i].first + 0.75*pr[i+1].first, 0.25*pr[i].second + 0.75*pr[i+1].second}); }
        q.push_back(pr.back()); pr.swap(q); }
      Mesh g; const int n = (int)pr.size();
      for (int i = 0; i < n; i++){
        const double dx = pr[std::min(i+1,n-1)].first - pr[std::max(i-1,0)].first, dy = pr[std::min(i+1,n-1)].second - pr[std::max(i-1,0)].second;
        const double sl = std::fabs(dx) / (std::hypot(dx, dy) + 1e-9);                      // 0 = flat web, 1 = steep flank of a hump
        const double v = 0.90 - 0.14 * sl;                                                  // flanks a little darker -> the corrugation reads as real curved metal
        for (int zz = 0; zz < 2; zz++){
          g.p.push_back((float)pr[i].first); g.p.push_back((float)pr[i].second); g.p.push_back(zz ? 0.5f : -0.5f);
          g.n.push_back(1); g.n.push_back(0); g.n.push_back(0); g.uv.push_back((float)i / n); g.uv.push_back((float)zz);
          g.c.push_back((float)(v*0.97)); g.c.push_back((float)v); g.c.push_back((float)(v*1.03)); } }
      for (int i = 0; i + 1 < n; i++){ const uint16_t a0 = (uint16_t)(i*2), a1 = (uint16_t)(i*2+1), b0 = (uint16_t)(i*2+2), b1 = (uint16_t)(i*2+3);
        g.idx.push_back(a0); g.idx.push_back(b0); g.idx.push_back(a1); g.idx.push_back(a1); g.idx.push_back(b0); g.idx.push_back(b1); }
      computeNormals(g); Mesh g2 = g; tr(g, 0, 0.07, 0); tr(g2, 0, -0.30, 0); b.push_back(g); b.push_back(g2); }   // DOUBLE rail like the photo: two stacked rounded corrugated beams with a gap between
    for (int e : {-1,1}) for (int h : {-1,1}) for (int r : {0,1}){ add(box(0.060,0.035,0.012),0,(r ? 0.30 : 0.67)+h*0.075,e*0.46,0.30); }  // bolt heads on both rails
    for (int r : {0,1}){ add(box(0.030,0.050,0.980),-0.012,(r ? 0.30 : 0.67)+0.0,0.0,0.62); }                                          // overlapping splice plate
    G.grail = merge(b);
    std::vector<Mesh> p;
    { Mesh g = cylinder(0.046, 0.046, 1.12, 18, 1, false); tr(g, 0, 0.42, 0); paintAll(g, 0.58, 0.60, 0.63); p.push_back(g); }      // round steel post (was a square I-section)
    { Mesh g = sphere(0.046, 12, 6); scl(g, 1, 0.45, 1); tr(g, 0, 0.98, 0); computeNormals(g); paintAll(g, 0.62, 0.64, 0.67); p.push_back(g); }   // rounded cap
    { Mesh g = box(0.150, 0.26, 0.090); tr(g, 0, 0.67, 0); paintAll(g, 0.14, 0.12, 0.10); p.push_back(g); }      // spacer block, upper rail
    { Mesh g = box(0.150, 0.26, 0.090); tr(g, 0, 0.30, 0); paintAll(g, 0.14, 0.12, 0.10); p.push_back(g); }      // spacer block, lower rail
    { Mesh g = box(0.200, 0.030, 0.100); tr(g, 0, 0.67, 0); paintAll(g, 0.30, 0.31, 0.33); p.push_back(g); }
    { Mesh g = box(0.095, 0.055, 0.020); tr(g, 0, 0.93, 0.0); paintAll(g, 0.9, 0.9, 0.85); p.push_back(g); }      // retro-reflector
    { Mesh g = box(0.100, 0.060, 0.012); tr(g, 0, 0.93, 0.0); paintAll(g, 0.9, 0.55, 0.05); p.push_back(g); }
    G.gpost = merge(p);
    {   // low dry-stone retaining wall (hill road hairpins): 1 m long unit along z, light grey block + slightly wider cap + dark footing
        std::vector<Mesh> w;
        { Mesh g = box(0.56, 0.95, 1.0); tr(g, 0, 0.17, 0); paintAll(g, 0.60, 0.58, 0.54); w.push_back(g); }
        { Mesh g = box(0.70, 0.14, 1.0); tr(g, 0, 0.72, 0); paintAll(g, 0.74, 0.72, 0.68); w.push_back(g); }
        { Mesh g = box(0.62, 0.20, 1.0); tr(g, 0, -0.18, 0); paintAll(g, 0.42, 0.40, 0.37); w.push_back(g); }
        { Mesh g = box(0.58, 0.05, 0.04); tr(g, 0, 0.30, 0.0); paintAll(g, 0.44, 0.42, 0.39); w.push_back(g); }
        G.swall = merge(w);
    }
}
static void buildLamp(){
    // galvanised steel street lamp: tapered round pole on a flanged base, a gently rising arm over the road and a flat LED luminaire
    const double H = LAMP_H, A = LAMP_ARM; std::vector<Mesh> list;
    { Mesh g = cylinder(0.052, 0.098, H, 24, 6, false); tr(g, 0, H / 2, 0); g.c.resize((size_t)g.vc() * 3);
      for (int i = 0; i < g.vc(); i++){ const double f = g.p[i*3+1] / H, v = 0.46 + 0.05 * std::sin(std::atan2(g.p[i*3+2], g.p[i*3]) * 1.0) - 0.06 * (1 - smoothS(0.0, 0.08, f)); g.c[i*3] = (float)v; g.c[i*3+1] = (float)(v * 1.03); g.c[i*3+2] = (float)(v * 1.07); }
      list.push_back(g); }
    { Mesh g = cylinder(0.125, 0.14, 0.42, 24, 1, false); tr(g, 0, 0.21, 0); paintAll(g, 0.40, 0.42, 0.45); list.push_back(g); }                   // base sleeve
    { Mesh g = cylinder(0.17, 0.17, 0.035, 24, 1, false); tr(g, 0, 0.018, 0); paintAll(g, 0.22, 0.23, 0.24); list.push_back(g); }                  // flange plate
    { Mesh g = box(0.012, 0.32, 0.10); tr(g, 0.128, 0.30, 0); paintAll(g, 0.30, 0.32, 0.34); list.push_back(g); }                                   // service door
    { Mesh g = cylinder(0.0, 0.058, 0.09, 14, 1, true); tr(g, 0, H + 0.045, 0); paintAll(g, 0.46, 0.48, 0.52); list.push_back(g); }                 // pole-top cap
    const double px[4] = {0, -0.7, -1.45, -A}, py[4] = {H - 0.30, H - 0.10, H + 0.08, H + 0.18};
    for (int k = 0; k < 3; k++){ Mesh g = tubeXY(px[k], py[k], px[k+1], py[k+1], k == 0 ? 0.045 : 0.036); paintAll(g, 0.46, 0.48, 0.52); list.push_back(g); }   // arm
    { Mesh g = cylinder(0.062, 0.062, 0.14, 12, 1, false); tr(g, 0, H - 0.30, 0); paintAll(g, 0.44, 0.46, 0.50); list.push_back(g); }               // arm clamp ring
    G.pole = merge(list);
    { Mesh a = box(0.86, 0.095, 0.31); tr(a, -A, H + 0.145, 0); paintAll(a, 0.30, 0.31, 0.33);                                                      // luminaire housing
      Mesh b = box(0.20, 0.07, 0.12); tr(b, -A - 0.38, H + 0.20, 0); paintAll(b, 0.26, 0.27, 0.29); G.shade = merge({a, b}); }                     // driver box
    { Mesh h = box(0.76, 0.02, 0.25); tr(h, -A, H + 0.088, 0); G.head = h; }                                                                          // LED lens
}

// ======================================================================= procedural textures
static void makeBarkTex(){
    const int W = 128, BW = 120, H = 256; std::vector<float> hg((size_t)W * H), lm((size_t)W * H), crk((size_t)W * H, 0.f);
    auto lat = [&](double px, double py, double sx, double sy, double sd){ return hsh(std::fmod(std::fmod(px, sx) + sx, sx) + sd * 17.3, std::fmod(std::fmod(py, sy) + sy, sy) + sd * 5.7); };
    auto vn = [&](double x, double y, double fx, double fy, double sd){
        const double gx = x / fx, gy = y / fy, ix = std::floor(gx), iy = std::floor(gy), tx = gx - ix, ty = gy - iy, sx = BW / fx, sy = H / fy, ux = tx*tx*(3 - 2*tx), uy = ty*ty*(3 - 2*ty);
        return (lat(ix, iy, sx, sy, sd) * (1 - ux) + lat(ix + 1, iy, sx, sy, sd) * ux) * (1 - uy) + (lat(ix, iy + 1, sx, sy, sd) * (1 - ux) + lat(ix + 1, iy + 1, sx, sy, sd) * ux) * uy; };
    for (int c = 0; c < 12; c++){                                                                    // long wavy vertical splits that come and go
        const double x0 = hsh(c, 41) * BW, y0 = hsh(c, 42) * H, len = 40 + hsh(c, 43) * 110, ph = hsh(c, 44) * 6.28, wd = 0.9 + hsh(c, 45) * 1.1;
        for (int t = 0; t < (int)len; t++){
            const int y = (int)std::floor(y0 + t) % H; const double xc = x0 + 2.2 * std::sin(t * 0.06 + ph) + 1.2 * std::sin(t * 0.17 + ph * 2), f = std::min(1.0, std::min(t / 14.0, (len - t) / 18.0));
            for (int dx = -2; dx <= 2; dx++){ const int xx = (((int)jr(xc) + dx) % BW + BW) % BW; const float v = (float)(f * std::max(0.0, 1 - std::fabs(xx - xc) / wd)); if (v > crk[(size_t)y * W + xx]) crk[(size_t)y * W + xx] = v; }
        }
    }
    for (int y = 0; y < H; y++) for (int x = 0; x < W; x++){
        const size_t i = (size_t)y * W + x; if (x >= BW){ hg[i] = 0.5f; lm[i] = 0.8f; continue; }
        const double f1 = vn(x, y, 3, 64, 1), f2 = vn(x, y, 8, 32, 2), f3 = vn(x, y, 2, 16, 3), crack = crk[i];
        const double h = 0.5 * f1 + 0.32 * f2 + 0.18 * f3 - 0.95 * crack;                           // ridges + fine fibres, cracks cut deep
        hg[i] = (float)h; lm[i] = (float)std::max(0.12, std::min(1.0, 0.50 + 0.50 * h + 0.10 * (vn(x, y, 20, 40, 6) - 0.5) - 0.38 * crack));
    }
    G.barkTex.assign((size_t)W * H * 4, 255);
    for (size_t i = 0; i < (size_t)W * H; i++){ const uint8_t v = (uint8_t)jr(lm[i] * 255); G.barkTex[i*4] = G.barkTex[i*4+1] = G.barkTex[i*4+2] = v; }
}
static void makeRopeTex(){
    const int S = 32; G.ropeTex.assign((size_t)S * S * 4, 255);
    for (int y = 0; y < S; y++) for (int x = 0; x < S; x++){
        double c[3] = {0xb8, 0x9c, 0x6c}; const double px = x + .5, py = y + .5;
        for (int o : {-32, 0, 32}){ const double d = std::fabs(px + py - (o + 32)) / std::sqrt(2.0); if (d <= 3.0){ c[0] = 0x6e; c[1] = 0x58; c[2] = 0x36; } }          // dark strand grooves
        for (int o : {-32, 0, 32}){ const double d = std::fabs(px + py - (o + 9 + 32)) / std::sqrt(2.0); if (d <= 1.5){ c[0] = 0xd8; c[1] = 0xc2; c[2] = 0x94; } }      // lit strands
        for (int k = 0; k < 3; k++) G.ropeTex[((size_t)y * S + x) * 4 + k] = (uint8_t)c[k];
    }
}
static void makeWoodTex(){
    const int W = 128, H = 256; Bridge::Img im(W, H); long long q = 77; auto rnd = [&](){ q = (q * 16807) % 2147483647LL; return (double)q / 2147483647.0; };
    Bridge::fillRect(im, 0, 0, W, H, 0x6d, 0x4f, 0x33, 1);
    for (int i = 0; i < 46; i++){ const double x = rnd() * W, w = 3 + rnd() * 14, l = H * (0.3 + 0.7 * rnd()), y = rnd() * H; const bool dk = rnd() < 0.5; const double a = 0.07 + rnd() * 0.10;
        Bridge::fillRect(im, x, y, w, l, dk ? 40 : 150, dk ? 26 : 115, dk ? 14 : 78, a); }                                       // broad light / dark growth bands
    for (int i = 0; i < 260; i++){ const double x = rnd() * W, y = rnd() * H, l = 18 + rnd() * 90, dr = (rnd() - 0.5) * 5, a = 0.30 + rnd() * 0.40, lw = 0.7 + rnd() * 1.7;
        Bridge::bezier(im, x, y, x + dr, y + l * 0.3, x - dr, y + l * 0.7, x + dr * 0.5, y + l, lw, 22, 13, 7, a); }              // long vertical fissures in the bark
    for (int i = 0; i < 340; i++){ const double x = rnd() * W, y = rnd() * H, l = 10 + rnd() * 40, a = 0.10 + rnd() * 0.16, lw = 0.6 + rnd();
        Bridge::lineSeg(im, x, y, x + (rnd() - 0.5) * 2, y + l, lw, 190, 160, 122, a); }                                          // pale weathered grain
    for (int i = 0; i < 5; i++){ const double x = rnd() * W, y = rnd() * H, r = 3 + rnd() * 5, rx = r * 0.8, ry = r * 1.8;                      // knots
        for (int yy = (int)(y - ry); yy <= (int)(y + ry); yy++) for (int xx = (int)(x - rx); xx <= (int)(x + rx); xx++){
            const double ex = (xx + .5 - x) / rx, ey = (yy + .5 - y) / ry; if (ex*ex + ey*ey > 1) continue;
            const double d = std::hypot(xx + .5 - x, yy + .5 - y) / (r * 1.8), a = d < 0.5 ? 0.9 + (0.6 - 0.9) * (d / 0.5) : 0.6 * (1 - (d - 0.5) / 0.5);
            const double cr = d < 0.5 ? 24 + 26 * (d / 0.5) : 50, cg = d < 0.5 ? 14 + 18 * (d / 0.5) : 32, cb = d < 0.5 ? 8 + 10 * (d / 0.5) : 18;
            Bridge::blendPx(im, xx, yy, cr, cg, cb, std::max(0.0, a)); } }
    for (int i = 0; i < 3000; i++){ const double x = rnd() * W, y = rnd() * H; const bool dk = rnd() < 0.5; const double a = rnd() * 0.10, hh = 1 + rnd() * 3;
        Bridge::fillRect(im, x, y, 1, hh, dk ? 0 : 255, dk ? 0 : 235, dk ? 0 : 200, a); }
    G.woodTex = im.px;
}

// ======================================================================= quaternions / matrices (column-major, like three.js)
struct Q { double x = 0, y = 0, z = 0, w = 1; };
static Q qAxis(double ax, double ay, double az, double a){ const double s = std::sin(a / 2); return {ax * s, ay * s, az * s, std::cos(a / 2)}; }
static Q qMul(const Q& a, const Q& b){ return {a.x*b.w + a.w*b.x + a.y*b.z - a.z*b.y, a.y*b.w + a.w*b.y + a.z*b.x - a.x*b.z, a.z*b.w + a.w*b.z + a.x*b.y - a.y*b.x, a.w*b.w - a.x*b.x - a.y*b.y - a.z*b.z}; }
static Q qFromUnit(double fx, double fy, double fz, double tx, double ty, double tz){            // setFromUnitVectors
    double r = fx*tx + fy*ty + fz*tz + 1; Q q;
    if (r < 1e-6){ r = 0; if (std::fabs(fx) > std::fabs(fz)){ q = {-fy, fx, 0, r}; } else { q = {0, -fz, fy, r}; } }
    else q = {fy*tz - fz*ty, fz*tx - fx*tz, fx*ty - fy*tx, r};
    const double l = std::sqrt(q.x*q.x + q.y*q.y + q.z*q.z + q.w*q.w); if (l > 0){ q.x /= l; q.y /= l; q.z /= l; q.w /= l; } return q;
}
static Q qSlerpId(const Q& b, double t){                                                           // slerp from the identity
    if (t <= 0) return Q(); if (t >= 1) return b;
    double cosH = b.w; Q e = b; if (cosH < 0){ e = {-b.x, -b.y, -b.z, -b.w}; cosH = -cosH; }
    if (cosH >= 1) return Q();
    const double sq = 1 - cosH * cosH, s = std::sqrt(sq), half = std::atan2(s, cosH), ra = std::sin((1 - t) * half) / s, rb = std::sin(t * half) / s;
    return {e.x * rb, e.y * rb, e.z * rb, ra + e.w * rb};
}
static void compose(float* te, double px, double py, double pz, const Q& q, double sx, double sy, double sz){
    const double x2 = q.x + q.x, y2 = q.y + q.y, z2 = q.z + q.z, xx = q.x*x2, xy = q.x*y2, xz = q.x*z2, yy = q.y*y2, yz = q.y*z2, zz = q.z*z2, wx = q.w*x2, wy = q.w*y2, wz = q.w*z2;
    te[0] = (float)((1 - (yy + zz)) * sx); te[1] = (float)((xy + wz) * sx); te[2] = (float)((xz - wy) * sx); te[3] = 0;
    te[4] = (float)((xy - wz) * sy); te[5] = (float)((1 - (xx + zz)) * sy); te[6] = (float)((yz + wx) * sy); te[7] = 0;
    te[8] = (float)((xz + wy) * sz); te[9] = (float)((yz - wx) * sz); te[10] = (float)((1 - (xx + yy)) * sz); te[11] = 0;
    te[12] = (float)px; te[13] = (float)py; te[14] = (float)pz; te[15] = 1;
}
// matrix whose +z axis points along (dx,dy,dz) (Object3D.lookAt for a non-camera), scaled along z by `len`
static void lookZ(float* te, double px, double py, double pz, double dx, double dy, double dz, double len){
    double l = std::sqrt(dx*dx + dy*dy + dz*dz); if (l < 1e-9){ dx = 0; dy = 0; dz = 1; l = 1; } dx /= l; dy /= l; dz /= l;
    double xx = dz, xy = 0, xz = -dx;                                                              // up(0,1,0) x z  (was z x up -> the beam came out upside-down, i.e. buried under the ground)
    double xl = std::sqrt(xx*xx + xy*xy + xz*xz); if (xl < 1e-9){ xx = 1; xy = 0; xz = 0; xl = 1; } xx /= xl; xy /= xl; xz /= xl;
    const double yx = dy*xz - dz*xy, yy = dz*xx - dx*xz, yz = dx*xy - dy*xx;                        // z x x
    te[0] = (float)xx; te[1] = (float)xy; te[2] = (float)xz; te[3] = 0; te[4] = (float)yx; te[5] = (float)yy; te[6] = (float)yz; te[7] = 0;
    te[8] = (float)(dx * len); te[9] = (float)(dy * len); te[10] = (float)(dz * len); te[11] = 0; te[12] = (float)px; te[13] = (float)py; te[14] = (float)pz; te[15] = 1;
}

// ======================================================================= world: posts, ropes, lamps
struct Post {
    double x, z, y; double yaw, sy; double len; bool ok = false, broken = false, anim = false; std::vector<int> rl; float tint = 1;
    double at = 0, t = 0, D = 0, dur = 0.34, arc = 0, lat = 0, spin = 0, gy = 0, ex = 0, ez = 0; double fx = 0, fz = 0;
};
struct Rail { int a, b; bool chain = false, anim = false; double t = 1, w = 0, ph = 0; float tint = 1; };
static std::vector<Post> gPosts; static std::vector<Rail> gRails;
static std::unordered_map<long long, std::vector<int>> gGrid;
static std::vector<int> gBroken;
static double gDistance = 0;                              // metres driven (HTML `distance`)
static inline long long gkey(long cx, long cz){ return (long long)(cx + 100000) * 200003LL + (cz + 100000); }

struct Part { double life = 0, max = 1, x = 0, y = 0, z = 0, vx = 0, vy = 0, vz = 0, s = 0, sp = 0; float r = 1, g = 1, b = 1; };
static const int NPART = 260; static Part gParts[NPART]; static int gPn = 0;

struct Lamp { double x, z, a; double tilt = 0, tiltDir = 0, by = 0; float tint[3]; };
static std::vector<Lamp> gLamps;
static double gHitCool = 0;
static bool gReady = false;
struct GSeg { float bm[16], pm[16]; double x, z; float tint = 1; double td = 0; bool post, beam = true, broken = false, anim = false, stone = false; double ax, ay, az, bx, by, bz, t = 0, tx = 0, tz = 0, ty = 0; };
static std::vector<GSeg> gGS;                                         // guardrail segments (static, solid)
static std::vector<int> gGPtSeg;
static std::vector<double> gGPts;                                     // collision sample points (x,z every ~1 m)
static std::unordered_map<long long, std::vector<int>> gGGrid;

static double groundY(double x, double z){ return Terrain::fieldH(x, z); }

static void railUpdate(int ri){
    Rail& r = gRails[ri]; const bool cut = gPosts[r.a].broken || gPosts[r.b].broken;
    if (cut){ if (!r.chain){ r.chain = true; r.w = 2 + rn() * 2.5; r.ph = rn() * 6.28; } r.t = 0; r.anim = true; }
    else if (r.chain){ r.chain = false; r.anim = false; r.t = 1; }
}
static void burst(const Post& p, double fx, double fz){
    const int n = 16;
    for (int i = 0; i < n; i++){
        Part& q = gParts[gPn]; gPn = (gPn + 1) % NPART; const bool wood = i % 4 == 0; const double sp = 3.5 + rn() * 5.5, a = (rn() - 0.5) * 2.4;
        const double cx = fx * std::cos(a) - fz * std::sin(a), cz = fx * std::sin(a) + fz * std::cos(a);   // mostly thrown away from the car
        q.x = p.x + (rn() - 0.5) * 0.2; q.y = p.y + 0.05 + rn() * 0.25; q.z = p.z + (rn() - 0.5) * 0.2;
        q.vx = cx * sp * 0.8 + (rn() - 0.5) * 1.5; q.vy = 1.5 + rn() * 3.2; q.vz = cz * sp * 0.8 + (rn() - 0.5) * 1.5;
        q.s = wood ? 0.025 + rn() * 0.03 : 0.03 + rn() * 0.06; q.life = q.max = 0.55 + rn() * 0.5; q.sp = rn() * 6;
        const double v = 0.7 + rn() * 0.5, d = wood ? 1 : 0, rr = wood ? 0.50 : 0.40, gg = wood ? 0.36 : 0.27, bb = wood ? 0.22 : 0.16; (void)d;
        q.r = (float)std::pow(rr * v, 2.2); q.g = (float)std::pow(gg * v, 2.2); q.b = (float)std::pow(bb * v, 2.2);       // sRGB -> linear (the renderer encodes again)
    }
}
static void breakPost(int pi, double fx, double fz, const CarState& car){
    Post& p = gPosts[pi]; if (p.broken) return; p.broken = true; p.at = gDistance; p.t = 0; p.anim = true;
    const double sp = std::min(1.0, std::fabs(car.speed) / 20), fw = car.speed > 0 ? 1.0 : car.speed < 0 ? -1.0 : 1.0;      // thrown away from the car AND along its motion
    double dx = fx + std::sin(car.heading) * fw * sp * 1.2, dz = fz + std::cos(car.heading) * fw * sp * 1.2; double dl = std::hypot(dx, dz); if (dl == 0) dl = 1; dx /= dl; dz /= dl;
    const double an = (rn() - 0.5) * 2.2, ca = std::cos(an), sa = std::sin(an); fx = dx * ca - dz * sa; fz = dx * sa + dz * ca; p.fx = fx; p.fz = fz;
    const double sp2 = std::min(1.0, std::fabs(car.speed) / 25);
    p.D = 0.6 + rn() * 0.7 + sp2 * sp2 * 12; p.dur = 0.34 + 0.014 * p.D; p.arc = std::min(0.10, 0.03 + 0.006 * p.D);          // the faster the car, the further the post flies
    p.lat = (rn() - 0.5) * 1.5; p.spin = (rn() < 0.5 ? -1 : 1) * (3 + rn() * 7);
    p.gy = groundY(p.x + fx * p.D - fz * p.lat, p.z + fz * p.D + fx * p.lat) + 0.30;                                           // ground height where it lands
    p.ex = p.x + fx * (0.5 + rn() * 1.3) - fz * (rn() - 0.5) * 1.2; p.ez = p.z + fz * (0.5 + rn() * 1.3) + fx * (rn() - 0.5) * 1.2;   // where the loose rope end falls
    gBroken.push_back(pi); burst(p, fx, fz); for (int r : p.rl) railUpdate(r);
}
static void restorePost(int pi){ Post& p = gPosts[pi]; p.broken = false; p.anim = false; p.t = 0; for (int r : p.rl) railUpdate(r); }

// ---------------------------------------------------------------------------------- build the fence + lamps (after Terrain::init / Bridge::init)
static void init(){
    if (gReady) return;
    Bridge::init();
    buildPost(); buildLamp(); makeBarkTex(); makeRopeTex(); makeWoodTex();
    const std::vector<const Road::Curve*> ROADS = Road::all(); const int NRD = (int)ROADS.size();
    std::vector<std::vector<double>> roadPts(NRD), lampPts(NRD);
    for (int r = 0; r < NRD; r++){
        const Road::Curve& cv = *ROADS[r];
        const int n3 = (int)std::ceil(cv.length() / 3), n2 = (int)std::ceil(cv.length() / 2);
        for (int k = 0; k <= n3; k++){ Road::V3 p = cv.getPointAt(cv.open ? std::min((double)k / n3, 0.99999) : (double)(k % n3) / n3); roadPts[r].push_back(p.x); roadPts[r].push_back(p.z); }
        for (int k = 0; k <= n2; k++){ Road::V3 p = cv.getPointAt(cv.open ? std::min((double)k / n2, 0.99999) : (double)(k % n2) / n2); lampPts[r].push_back(p.x); lampPts[r].push_back(p.z); }
    }
    auto otherEdge = [&](double x, double z, int ci){ double best = 1e9; for (int r = 0; r < NRD; r++){ if (r == ci) continue; const auto& a = roadPts[r]; const double hw = ROADS[r]->hw;
        for (size_t k = 0; k < a.size(); k += 2){ const double dx = x - a[k], dz = z - a[k+1], d = std::sqrt(dx*dx + dz*dz) - hw; if (d < best) best = d; } } return best; };
    auto okAt = [&](double x, double z, int ci){ return otherEdge(x, z, ci) > 10 && std::fabs(River::riverSd(x, z)) >= 24 + 6 && Terrain::trackDist(x, z) > 14 && Terrain::coastDist(x, z) < -52 && !(gGuardVeto && gGuardVeto(x, z)); };   // rails run right up to the bridge approaches (bank + 6 m); gaps at house entrances (gGuardVeto)
    for (int ci = 0; ci < NRD; ci++){
        const Road::Curve& cv = *ROADS[ci]; const double len = cv.length(); const int n = std::max(2, (int)jr(len / SP)); const bool closed = !cv.open; const int cnt = closed ? n : n + 1;
        for (int sd : {-1, 1}){
            const int base = (int)gPosts.size();
            for (int k = 0; k < cnt; k++){
                const double t = closed ? (double)k / n : std::min((double)k / n, 0.99999); Road::V3 p = cv.getPointAt(t), tg = cv.getTangentAt(t); double nl = std::hypot(tg.x, tg.z); if (nl == 0) nl = 1;
                Post q; q.x = p.x + (-tg.z / nl) * sd * (cv.hw + OFF); q.z = p.z + (tg.x / nl) * sd * (cv.hw + OFF); q.y = groundY(q.x, q.z) + 0.05; q.ok = okAt(q.x, q.z, ci); q.len = len;
                q.yaw = std::atan2(tg.x / nl, tg.z / nl); const int idx = (int)gPosts.size() - 0; q.sy = 1.0;                       // reflectors face along the road
                { const double v = 0.96 + ((idx * 53) % 17) / 200.0; q.tint = (float)v; }
                gPosts.push_back(q);
            }
            for (int k = 0; k < cnt; k++){
                const int a = base + k; if (!gPosts[a].ok) continue;
                const int b = (k + 1 < cnt) ? base + k + 1 : (closed ? base : -1);
                if (kRopes && b >= 0 && gPosts[b].ok){ Rail r; r.a = a; r.b = b; r.tint = (float)(0.85 + ((int)gRails.size() * 29 % 13) / 40.0); gRails.push_back(r); gPosts[a].rl.push_back((int)gRails.size() - 1); gPosts[b].rl.push_back((int)gRails.size() - 1); }
            }
        }
    }
    // drop the posts that are not allowed (keeps the arrays small): remap rail indices
    { std::vector<int> map(gPosts.size(), -1); std::vector<Post> np; for (size_t i = 0; i < gPosts.size(); i++) if (gPosts[i].ok){ map[i] = (int)np.size(); np.push_back(gPosts[i]); }
      for (Rail& r : gRails){ r.a = map[r.a]; r.b = map[r.b]; } gPosts.swap(np); }
    for (size_t i = 0; i < gPosts.size(); i++) gGrid[gkey((long)std::floor(gPosts[i].x / CELL), (long)std::floor(gPosts[i].z / CELL))].push_back((int)i);

    // ---- street lamps (placed beside the road on its outer side, arm pointing back over the road)
    auto lampBlocked = [&](double x, double z, int ci){
        if (std::fabs(River::riverSd(x, z)) < River::RIVER_WALL + 3) return true;
        for (int r = 0; r < NRD; r++){ if (r == ci) continue; const auto& a = lampPts[r]; const double lim = ROADS[r]->hw + 3.5, l2 = lim * lim;
            for (size_t k = 0; k < a.size(); k += 2){ const double dx = x - a[k], dz = z - a[k+1]; if (dx*dx + dz*dz < l2) return true; } }
        return false; };
    for (int ci = 0; ci < NRD; ci++){
        const Road::Curve& cv = *ROADS[ci]; const double L = cv.length(); const int n = (int)std::floor(L / 44);
        for (int i = 0; i < n; i++){
            const double t = (double)i / n; Road::V3 p = cv.getPointAt(t), tn = cv.getTangentAt(t); double nx = -tn.z, nz = tn.x; const double nl = std::hypot(nx, nz); nx /= nl ? nl : 1; nz /= nl ? nl : 1;
            if (nx * p.x + nz * p.z < 0){ nx = -nx; nz = -nz; }
            const double off = cv.hw + 2.3, lx = p.x + nx * off, lz = p.z + nz * off; if (lampBlocked(lx, lz, ci)) continue;
            Lamp l; l.x = lx; l.z = lz; l.a = std::atan2(nz, nx); const int li = (int)gLamps.size(); const double k = 0.82 + ((li * 37) % 17) / 50.0, w = ((li * 13) % 7) / 60.0;
            l.tint[0] = (float)(k + w); l.tint[1] = (float)k; l.tint[2] = (float)(k - w); l.by = Bridge::lift(lx, lz, 9); gLamps.push_back(l);
        }
    }

    // ---- hill road + summit car park: lamps where a real mountain road has them = every ~70 m on the mountain (inner) side, so the arm reaches over the tarmac
    //      and the guardrail on the drop side stays clear; plus a ring of lamps around the summit car park.
    if (Terrain::TRK.on && Terrain::PEAK.on && Terrain::TRK.n > 20){
        const std::vector<float>& P = Terrain::TRK.pts; const int cntT = Terrain::TRK.n; const double hwT = Terrain::TRK_W * 0.5, cxP = Terrain::PEAK.x, czP = Terrain::PEAK.z;
        double acc = 0, nextAt = 40;
        auto addLamp = [&](double lx, double lz, double ang){
            Lamp l; l.x = lx; l.z = lz; l.a = ang; const int li = (int)gLamps.size(); const double k = 0.82 + ((li * 37) % 17) / 50.0, w = ((li * 13) % 7) / 60.0;
            l.tint[0] = (float)(k + w); l.tint[1] = (float)k; l.tint[2] = (float)(k - w); l.by = Bridge::lift(lx, lz, 9); gLamps.push_back(l); };
        for (int k = 1; k < cntT; k++){
            acc += Terrain::TRK.L[k - 1]; if (acc < nextAt || k < 14) continue;
            const int a = std::max(k - 1, 0), b = std::min(k + 1, cntT - 1); double tx = P[b*2] - P[a*2], tz = P[b*2+1] - P[a*2+1]; double tl = std::hypot(tx, tz); if (tl == 0) continue; tx /= tl; tz /= tl;
            double nx = -tz, nz = tx; if (nx * (P[k*2] - cxP) + nz * (P[k*2+1] - czP) > 0){ nx = -nx; nz = -nz; }            // towards the mountain's centre (inner side)
            const double lx = P[k*2] + nx * (hwT + 2.3), lz = P[k*2+1] + nz * (hwT + 2.3);
            if (Terrain::TRK.clr[k] <= 14.f || std::fabs(River::riverSd(lx, lz)) < 36 || Terrain::coastDist(lx, lz) > -52) continue;
            if (Road::gPark[2] > 0.f && std::hypot(lx - Road::gPark[0], lz - Road::gPark[1]) < Road::gPark[2] + 6.0) continue;
            addLamp(lx, lz, std::atan2(nz, nx)); acc = 0; nextAt = 70;
        }
        if (Road::gPark[2] > 0.f){ const double pr = Road::gPark[2] + 3.0; for (int i = 0; i < 6; i++){ const double an = i * PI / 3 + 0.4; addLamp(Road::gPark[0] + std::cos(an) * pr, Road::gPark[1] + std::sin(an) * pr, an); } }
    }
    // ---- steel guardrails: only where they are needed = outer side of tighter bends + wherever the ground drops away beside the road
    buildGuardMesh();
    for (int ci = 0; ci < NRD; ci++){
        const Road::Curve& cv = *ROADS[ci]; const double len = cv.length(), STEP = 4.0; const int n = std::max(4, (int)jr(len / STEP)); const bool closed = !cv.open; const int cnt = closed ? n : n + 1;
        auto tAt = [&](int k){ return closed ? (double)(((k % n) + n) % n) / n : std::min(std::max((double)k / n, 0.0), 0.99999); };
        auto idxOk = [&](int k){ return closed || (k >= 0 && k < cnt); };
        for (int sd : {-1, 1}){
            std::vector<double> X(cnt), Z(cnt), Y(cnt); std::vector<char> need(cnt, 0), okc(cnt, 0);
            for (int k = 0; k < cnt; k++){                                                              // a continuous W-beam guardrail along the whole roadside (like the photo)
                const double t = tAt(k); Road::V3 p = cv.getPointAt(t), tg = cv.getTangentAt(t); double nl = std::hypot(tg.x, tg.z); if (nl == 0) nl = 1;
                const double nx = -tg.z / nl * sd, nz = tg.x / nl * sd;
                X[k] = p.x + nx * (cv.hw + GR_OFF); Z[k] = p.z + nz * (cv.hw + GR_OFF); Y[k] = groundY(X[k], Z[k]);
                okc[k] = okAt(X[k], Z[k], ci); need[k] = okc[k];
            }
            std::vector<char> dl = need;                                                                // widen by one step each way, then drop runs shorter than 3
            for (int k = 0; k < cnt; k++) if (need[k]){ for (int d = -1; d <= 1; d += 2){ int j = k + d; if (closed) j = ((j % cnt) + cnt) % cnt; if (j >= 0 && j < cnt && okc[j]) dl[j] = 1; } }
            std::vector<char> keep = dl;
            for (int k = 0; k < cnt; k++) if (dl[k]){ int a = k, b = k; while (idxOk(a - 1) && dl[((a - 1) % cnt + cnt) % cnt] && k - a < 2) a--; while (idxOk(b + 1) && dl[(b + 1) % cnt] && b - k < 2) b++; if (b - a < 2) keep[k] = 0; }
            for (int k = 0; k < cnt; k++){
                const int k2 = closed ? (k + 1) % cnt : k + 1; if (k2 >= cnt || !keep[k] || !keep[k2]) continue;
                const double ax = X[k], az = Z[k], ay = Y[k], bx = X[k2], bz = Z[k2], by = Y[k2], dx = bx - ax, dy = by - ay, dz = bz - az, L = std::sqrt(dx*dx + dy*dy + dz*dz);
                if (L < 0.5 || L > 12) continue;
                GSeg g; g.ax = ax; g.ay = ay; g.az = az; g.bx = bx; g.by = by; g.bz = bz; g.x = (ax + bx) / 2; g.z = (az + bz) / 2; g.post = true; g.tint = (float)(0.93 + 0.07 * hsh(gGS.size(), 7));
                lookZ(g.bm, g.x, (ay + by) / 2, g.z, dx, dy, dz, L + 0.03);
                { const double ul = std::hypot(dx, dz) + 1e-9, ox = -dz / ul * sd * 0.09, oz = dx / ul * sd * 0.09; compose(g.pm, ax + ox, ay, az + oz, qAxis(0, 1, 0, std::atan2(dx, dz)), 1, 1, 1); }
                if (k == 0 || !keep[closed ? (k - 1 + cnt) % cnt : k - 1]){ GSeg t = g; t.post = false; t.beam = true; const double ux = dx / L, uz = dz / L, ex = ax - ux * 1.6, ez = az - uz * 1.6, ey = groundY(ex, ez) - 0.55;
                    lookZ(t.bm, (ax + ex) / 2, (ay + ey) / 2, (az + ez) / 2, ex - ax, ey - ay, ez - az, std::sqrt((ex-ax)*(ex-ax) + (ey-ay)*(ey-ay) + (ez-az)*(ez-az))); t.broken = false; t.x = ex; t.z = ez; gGS.push_back(t); }
                gGS.push_back(g); const int gi = (int)gGS.size() - 1;
                const int k3 = closed ? (k2 + 1) % cnt : k2 + 1;                                         // closing post at the end of a run
                if (k3 >= cnt || !keep[k3]){ GSeg e = g; e.post = true; e.beam = false; { const double ul = std::hypot(dx, dz) + 1e-9, ox = -dz / ul * sd * 0.09, oz = dx / ul * sd * 0.09; compose(e.pm, bx + ox, by, bz + oz, qAxis(0, 1, 0, std::atan2(dx, dz)), 1, 1, 1); } gGS.push_back(e);
                    { GSeg t = g; t.post = false; t.beam = true; t.broken = false; const double ux = dx / L, uz = dz / L, ex = bx + ux * 1.6, ez = bz + uz * 1.6, ey = groundY(ex, ez) - 0.55;
                      lookZ(t.bm, (bx + ex) / 2, (by + ey) / 2, (bz + ez) / 2, ex - bx, ey - by, ez - bz, std::sqrt((ex-bx)*(ex-bx) + (ey-by)*(ey-by) + (ez-bz)*(ez-bz))); t.x = ex; t.z = ez; gGS.push_back(t); } }
                for (int q = 0; q < 4; q++){ const double f = q / 4.0; gGPts.push_back(ax + dx * f); gGPts.push_back(az + dz * f); gGPtSeg.push_back(gi); }
                if (k3 >= cnt || !keep[k3]){ gGPts.push_back(bx); gGPts.push_back(bz); gGPtSeg.push_back(gi); }
            }
        }
    }
    // ---- WINDING_ROAD_HILL: steel guardrail along the spiral hill road (Terrain::TRK). Same W-beam + posts + collision + break-away as the ring roads.
    //  The mountain is on the inside of every bend, the drop is on the outside: the rail runs on the OUTER side (set HILL_RAIL_BOTH_SIDES = true for the uphill side too). Steel W-beam along the whole outer edge of the spiral.
    //  It starts after the short straight approach (where the road is still close to the ring roads) and runs on round the parking pad on the summit.
    if (Terrain::TRK.on && Terrain::PEAK.on && Terrain::TRK.n > 20){
        static const bool HILL_RAIL_BOTH_SIDES = false;
        const std::vector<float>& P = Terrain::TRK.pts; const int cnt = Terrain::TRK.n; const double hwT = Terrain::TRK_W * 0.5, cxP = Terrain::PEAK.x, czP = Terrain::PEAK.z;
        for (int pass = 0; pass < (HILL_RAIL_BOTH_SIDES ? 2 : 1); pass++){
            std::vector<double> X(cnt), Z(cnt), Y(cnt), NXv(cnt), NZv(cnt); std::vector<char> need(cnt, 0), okc(cnt, 0);
            for (int k = 0; k < cnt; k++){
                const int a = std::max(k - 1, 0), b = std::min(k + 1, cnt - 1); double tx = P[b*2] - P[a*2], tz = P[b*2+1] - P[a*2+1]; double tl = std::hypot(tx, tz); if (tl == 0) tl = 1; tx /= tl; tz /= tl;
                double nx = -tz, nz = tx; if (nx * (P[k*2] - cxP) + nz * (P[k*2+1] - czP) < 0){ nx = -nx; nz = -nz; }          // nx, nz = away from the mountain's centre (outer side)
                if (pass == 1){ nx = -nx; nz = -nz; }
                NXv[k] = nx; NZv[k] = nz;
                X[k] = P[k*2] + nx * (hwT + GR_OFF); Z[k] = P[k*2+1] + nz * (hwT + GR_OFF); Y[k] = groundY(X[k], Z[k]);
                okc[k] = (k >= 14 && Terrain::trackDist(X[k], Z[k]) > hwT + GR_OFF - 0.5 && Terrain::TRK.clr[k] > 14.f && !(Road::gPark[2] > 0.f && std::hypot(X[k] - Terrain::PEAK.x, Z[k] - Terrain::PEAK.z) < Road::gPark[2] + 9.0) && std::fabs(River::riverSd(X[k], Z[k])) >= 36 && Terrain::coastDist(X[k], Z[k]) < -52) ? 1 : 0; need[k] = okc[k];
            }
            // never let a rail segment cut across the tarmac: at a hairpin the "away from the mountain" side flips, so the offset points of two neighbours
            // land on opposite sides of the road (or the inside of a tight bend folds over the road). Break the rail there instead of bridging the road.
            for (int k = 0; k + 1 < cnt; k++){
                bool bad = (NXv[k] * NXv[k+1] + NZv[k] * NZv[k+1]) < 0.5;
                for (int q = 1; q <= 3 && !bad; q++){ const double f = q / 4.0, mx = X[k] + (X[k+1] - X[k]) * f, mz = Z[k] + (Z[k+1] - Z[k]) * f; if (Terrain::trackDist(mx, mz) < hwT + GR_OFF - 0.8) bad = true; }
                if (bad){ need[k] = 0; need[k+1] = 0; okc[k] = 0; okc[k+1] = 0; }
            }
            std::vector<char> keep = need;
            for (int k = 0; k < cnt; k++) if (need[k]){ int a = k, b = k; while (a - 1 >= 0 && need[a - 1] && k - a < 2) a--; while (b + 1 < cnt && need[b + 1] && b - k < 2) b++; if (b - a < 2) keep[k] = 0; }   // drop runs shorter than 3
            for (int k = 0; k + 1 < cnt; k++){
                const int k2 = k + 1; if (!keep[k] || !keep[k2]) continue;
                const double ax = X[k], az = Z[k], ay = Y[k], bx = X[k2], bz = Z[k2], by = Y[k2], dx = bx - ax, dy = by - ay, dz = bz - az, L = std::sqrt(dx*dx + dy*dy + dz*dz);
                if (L < 0.5 || L > 12) continue;
                const double ul = std::hypot(dx, dz) + 1e-9, ox = -dz / ul * (pass ? 1 : -1) * 0.09, oz = dx / ul * (pass ? 1 : -1) * 0.09;
                GSeg g; g.ax = ax; g.ay = ay; g.az = az; g.bx = bx; g.by = by; g.bz = bz; g.x = (ax + bx) / 2; g.z = (az + bz) / 2; g.post = true; g.tint = (float)(0.93 + 0.07 * hsh(gGS.size(), 7));
                lookZ(g.bm, g.x, (ay + by) / 2, g.z, dx, dy, dz, L + 0.03);   // W-beam steel guardrail piece + post
                compose(g.pm, ax + ox, ay, az + oz, qAxis(0, 1, 0, std::atan2(dx, dz)), 1, 1, 1);
                const bool runStart = (k == 0 || !keep[k - 1]), runEnd = (k2 + 1 >= cnt || !keep[k2 + 1]);
                if (runStart){ GSeg t = g; t.post = false; t.beam = true; const double ux = dx / L, uz = dz / L, ex = ax - ux * 1.6, ez = az - uz * 1.6, ey = groundY(ex, ez) - 0.55;
                    lookZ(t.bm, (ax + ex) / 2, (ay + ey) / 2, (az + ez) / 2, ex - ax, ey - ay, ez - az, std::sqrt((ex-ax)*(ex-ax) + (ey-ay)*(ey-ay) + (ez-az)*(ez-az))); t.broken = false; t.x = ex; t.z = ez; gGS.push_back(t); }     // turned-down start terminal
                gGS.push_back(g); const int gi = (int)gGS.size() - 1;
                if (runEnd){ GSeg e = g; e.post = true; e.beam = false; compose(e.pm, bx + ox, by, bz + oz, qAxis(0, 1, 0, std::atan2(dx, dz)), 1, 1, 1); e.x = bx; e.z = bz; gGS.push_back(e);                                   // closing post
                    GSeg t = g; t.post = false; t.beam = true; t.broken = false; const double ux = dx / L, uz = dz / L, ex = bx + ux * 1.6, ez = bz + uz * 1.6, ey = groundY(ex, ez) - 0.55;
                    lookZ(t.bm, (bx + ex) / 2, (by + ey) / 2, (bz + ez) / 2, ex - bx, ey - by, ez - bz, std::sqrt((ex-bx)*(ex-bx) + (ey-by)*(ey-by) + (ez-bz)*(ez-bz))); t.x = ex; t.z = ez; gGS.push_back(t); }                // turned-down end terminal
                for (int q = 0; q < 4; q++){ const double f = q / 4.0; gGPts.push_back(ax + dx * f); gGPts.push_back(az + dz * f); gGPtSeg.push_back(gi); }
                if (runEnd){ gGPts.push_back(bx); gGPts.push_back(bz); gGPtSeg.push_back(gi); }
            }
        }
    }
    for (size_t i = 0; i + 1 < gGPts.size(); i += 2) gGGrid[gkey((long)std::floor(gGPts[i] / CELL), (long)std::floor(gGPts[i+1] / CELL))].push_back((int)(i / 2));
    // the white delineator posts would stand right in front of the rail: leave them out wherever a guardrail runs (the rail carries the reflectors)
    if (gRails.empty() && !gGPts.empty()){
        std::vector<Post> np; np.reserve(gPosts.size());
        for (const Post& q : gPosts){
            bool near = false; const long cx = (long)std::floor(q.x / CELL), cz = (long)std::floor(q.z / CELL);
            for (long i = cx - 1; i <= cx + 1 && !near; i++) for (long j = cz - 1; j <= cz + 1 && !near; j++){
                auto it = gGGrid.find(gkey(i, j)); if (it == gGGrid.end()) continue;
                for (int gi : it->second){ const double dx = gGPts[(size_t)gi * 2] - q.x, dz = gGPts[(size_t)gi * 2 + 1] - q.z; if (dx*dx + dz*dz < 1.6 * 1.6){ near = true; break; } }
            }
            if (!near) np.push_back(q);
        }
        gPosts.swap(np); gGrid.clear();
        for (size_t i = 0; i < gPosts.size(); i++) gGrid[gkey((long)std::floor(gPosts[i].x / CELL), (long)std::floor(gPosts[i].z / CELL))].push_back((int)i);
    }
    gReady = true;
}

// ======================================================================= physics
// bounceOff() of the HTML: reflect the car's velocity about the contact normal (e = restitution, fric = tangential loss)
static void bounceOff(CarState& S, double nx, double nz, double e, double fric){
    const double sH = std::sin(S.heading), cH = std::cos(S.heading);
    double wx = S.speed * sH + S.vy * cH, wz = S.speed * cH - S.vy * sH; const double vn = wx * nx + wz * nz; if (vn >= 0) return;
    wx -= (1 + e) * vn * nx; wz -= (1 + e) * vn * nz; const double tx = -nz, tz = nx, vt = wx * tx + wz * tz; wx -= vt * fric * tx; wz -= vt * fric * tz;
    S.speed = wx * sH + wz * cH; S.vy = wx * cH - wz * sH; S.yaw *= 0.6;
}
static void fencePosts(CarState& S, double dt){
    const double px = S.x, pz = S.z, sH = std::sin(S.heading), cH = std::cos(S.heading), sw = std::fabs(S.speed) * dt;     // car box, extended by how far the car moves this frame
    const long cx = (long)std::floor(px / CELL), cz = (long)std::floor(pz / CELL);
    for (long i = cx - 1; i <= cx + 1; i++) for (long j = cz - 1; j <= cz + 1; j++){
        auto it = gGrid.find(gkey(i, j)); if (it == gGrid.end()) continue; const std::vector<int>& g = it->second;
        for (int pi : g){
            Post& p = gPosts[pi]; if (p.broken) continue;
            const double dx = p.x - px, dz = p.z - pz, lon = dx * sH + dz * cH, lat = dx * cH - dz * sH;                      // post in the car's own frame
            if (std::fabs(lat) > 1.02 || lon > 2.3 + sw || lon < -2.2 - sw) continue;                                         // half width ~1.1 m + post, half length ~2.4 m + swept distance
            double d = std::hypot(dx, dz); if (d == 0) d = 0.001; breakPost(pi, dx / d, dz / d, S); S.speed *= 0.93;          // a small knock: the car loses a little speed
        }
        // the ROPE between two standing posts: if it crosses the car body, knock down the post nearer the car instead of driving through the rope
        for (int pi : g){
            Post& p = gPosts[pi]; if (p.broken) continue;
            for (int ri : p.rl){
                const Rail& r = gRails[ri]; if (r.a != pi || gPosts[r.b].broken) continue; Post& q = gPosts[r.b];
                const double x0 = (p.x - px) * cH - (p.z - pz) * sH, y0 = (p.x - px) * sH + (p.z - pz) * cH, x1 = (q.x - px) * cH - (q.z - pz) * sH, y1 = (q.x - px) * sH + (q.z - pz) * cH;
                const double bx = 1.12, yMin = -2.3 - sw, yMax = 2.5 + sw; double t0 = 0, t1 = 1; const double ddx = x1 - x0, ddy = y1 - y0; bool hit = true;
                auto clip = [&](double pp, double qq){ if (pp == 0){ if (qq < 0) hit = false; return; } const double t = qq / pp;
                    if (pp < 0){ if (t > t1) hit = false; else if (t > t0) t0 = t; } else { if (t < t0) hit = false; else if (t < t1) t1 = t; } };
                clip(-ddx, x0 + bx); clip(ddx, bx - x0); clip(-ddy, y0 - yMin); clip(ddy, yMax - y0);
                if (!hit || t0 > t1) continue;
                const double dp = std::hypot(p.x - px, p.z - pz), dq = std::hypot(q.x - px, q.z - pz); const int k = dp <= dq ? pi : r.b; const Post& kp = gPosts[k];
                const double ex = kp.x - px, ez = kp.z - pz; double dd = std::hypot(ex, ez); if (dd == 0) dd = 0.001;
                breakPost(k, ex / dd, ez / dd, S); S.speed *= 0.95; break;
            }
        }
    }
}
// the wooden lamp poles are solid: the car's body (a box) is pushed out of the pole, the impact is felt, a hard hit leaves the pole leaning away
static void lampCollide(CarState& S){
    const double POLE_R = 0.13, HL = 2.3, HW = 0.97, LIM2 = 3.6 * 3.6, px = S.x, pz = S.z, sH = std::sin(S.heading), cH = std::cos(S.heading);
    for (Lamp& lp : gLamps){
        const double dx = lp.x - px, dz = lp.z - pz; if (dx*dx + dz*dz > LIM2) continue;
        const double f = dx * sH + dz * cH, l = dx * cH - dz * sH;                                        // pole in the car's frame (f forward, l left)
        const double cf = std::max(-HL, std::min(HL, f)), cl = std::max(-HW, std::min(HW, l)), vf = f - cf, vl = l - cl, d = std::hypot(vf, vl); double nf, nl, pen;
        if (d > 1e-4){ if (d >= POLE_R) continue; nf = -vf / d; nl = -vl / d; pen = POLE_R - d; }                       // outside the box: push along the closest-point normal
        else { const double ef = HL - std::fabs(f), el = HW - std::fabs(l); if (ef < el){ nf = f > 0 ? -1 : 1; nl = 0; pen = ef + POLE_R; } else { nf = 0; nl = l > 0 ? -1 : 1; pen = el + POLE_R; } }
        const double nx = nf * sH + nl * cH, nz = nf * cH - nl * sH;                                      // world normal: from the pole towards the car
        const double wx = S.speed * sH + S.vy * cH, wz = S.speed * cH - S.vy * sH, vn = -(wx * nx + wz * nz);   // closing speed
        S.x += nx * pen; S.z += nz * pen;
        bounceOff(S, nx, nz, 0.28, 0.22);
        if (vn > 0.5 && gHitCool <= 0){ gHitCool = 0.6; if (vn > 4){ lp.tilt = std::min(0.16, lp.tilt + 0.012 * vn); lp.tiltDir = std::atan2(-nz, -nx); } }   // pole is shoved away from the car
    }
}



static void sparks(double x, double y, double z, double nx, double nz, int n){                  // bright hot flecks thrown away from the car along the rail
    for (int i = 0; i < n; i++){
        Part& q = gParts[gPn]; gPn = (gPn + 1) % NPART; const double a = (rn() - 0.5) * 2.0, sp = 2 + rn() * 5, cx = -nx * std::cos(a) + nz * std::sin(a), cz = -nz * std::cos(a) - nx * std::sin(a);
        q.x = x + (rn() - 0.5) * 0.6; q.y = y + (rn() - 0.5) * 0.3; q.z = z + (rn() - 0.5) * 0.6; q.vx = cx * sp; q.vy = 0.5 + rn() * 2.5; q.vz = cz * sp;
        q.s = 0.012 + rn() * 0.014; q.life = q.max = 0.25 + rn() * 0.3; q.sp = rn() * 4; q.r = 6.0f; q.g = 2.6f + (float)rn() * 1.5f; q.b = 0.5f;
    }
}
static double gSparkCool = 0;
static void breakGuard(int gi, double nx, double nz, double vn){                       // (nx,nz) points from the rail towards the car: the beam is flung the other way
    GSeg& g = gGS[gi]; if (g.broken) return; g.broken = true; g.anim = true; g.t = 0;
    const double D = 1.5 + std::min(3.0, vn * 0.15);
    g.tx = g.bx - nx * D; g.tz = g.bz - nz * D; g.ty = groundY(g.tx, g.tz) + 0.12;
    g.td = std::atan2(-nz, -nx);
    Post p; p.x = g.x; p.z = g.z; p.y = (g.ay + g.by) / 2 + 0.5; burst(p, -nx, -nz); sparks(g.x, p.y, g.z, nx, nz, 18);
}
// steel guardrails are solid: sample points every ~1 m along the beam are treated like thin poles
static void guardCollide(CarState& S){
    if (gGPts.empty()) return;
    const double R = 0.30, HL = 2.3, HW = 0.97, px = S.x, pz = S.z, sH = std::sin(S.heading), cH = std::cos(S.heading);
    const long cx = (long)std::floor(px / CELL), cz = (long)std::floor(pz / CELL);
    for (long i = cx - 1; i <= cx + 1; i++) for (long j = cz - 1; j <= cz + 1; j++){
        auto it = gGGrid.find(gkey(i, j)); if (it == gGGrid.end()) continue;
        for (int pi : it->second){
            if (gGS[gGPtSeg[pi]].broken) continue;
            const double qx = gGPts[(size_t)pi * 2], qz = gGPts[(size_t)pi * 2 + 1], dx = qx - px, dz = qz - pz; if (dx*dx + dz*dz > 3.6 * 3.6) continue;
            const double f = dx * sH + dz * cH, l = dx * cH - dz * sH;
            const double cf = std::max(-HL, std::min(HL, f)), cl = std::max(-HW, std::min(HW, l)), vf = f - cf, vl = l - cl, d = std::hypot(vf, vl); double nf, nl, pen;
            if (d > 1e-4){ if (d >= R) continue; nf = -vf / d; nl = -vl / d; pen = R - d; }
            else { const double ef = HL - std::fabs(f), el = HW - std::fabs(l); if (ef < el){ nf = f > 0 ? -1 : 1; nl = 0; pen = ef + R; } else { nf = 0; nl = l > 0 ? -1 : 1; pen = el + R; } }
            const double nx = nf * sH + nl * cH, nz = nf * cH - nl * sH;
            const double wx = S.speed * sH + S.vy * cH, wz = S.speed * cH - S.vy * sH, vn = -(wx * nx + wz * nz);
            if (gGS[gGPtSeg[pi]].stone){ if (vn > 2.0 && gSparkCool <= 0){ gSparkCool = 0.07; sparks(qx, 0.5, qz, nx, nz, 3 + (int)std::min(6.0, vn)); S.speed *= 0.99; } S.x += nx * pen; S.z += nz * pen; bounceOff(S, nx, nz, 0.15, 0.15); continue; }   // stone wall: never breaks
            if (vn > 7.0){ breakGuard(gGPtSeg[pi], nx, nz, vn); S.speed *= 0.88; continue; }       // hard hit: the rail gives way
            if (vn > 2.0 && gSparkCool <= 0){ gSparkCool = 0.07; sparks(qx, 0.5, qz, nx, nz, 3 + (int)std::min(6.0, vn)); S.speed *= 0.995; }
            S.x += nx * pen; S.z += nz * pen;
            bounceOff(S, nx, nz, 0.20, 0.12);
        }
    }
}

// advance the fence by dt seconds: collisions with the car (call after the car physics step), flying posts, dirt, loose ropes, restoring
static void update(CarState& S, double dt){
    if (!gReady || dt <= 0) return;
    gDistance += std::fabs(S.speed) * dt; gHitCool = std::max(0.0, gHitCool - dt); gSparkCool = std::max(0.0, gSparkCool - dt);
    fencePosts(S, dt);
    lampCollide(S);
    guardCollide(S);
    for (GSeg& g : gGS) if (g.anim){ g.t = std::min(1.0, g.t + dt / 0.35); if (g.t >= 1) g.anim = false; }
    for (int i = 0; i < NPART; i++){ Part& q = gParts[i]; if (q.life <= 0) continue; q.life -= dt; q.vy -= 12 * dt; q.x += q.vx * dt; q.y += q.vy * dt; q.z += q.vz * dt;
        if (q.y < 0.03){ q.y = 0.03; q.vy *= -0.25; q.vx *= 0.6; q.vz *= 0.6; } }
    for (int pi : gBroken){ Post& p = gPosts[pi]; if (p.anim){ p.t = std::min(1.0, p.t + dt / p.dur); if (p.t >= 1) p.anim = false; } }
    for (Rail& r : gRails) if (r.anim){ r.t = std::min(1.0, r.t + dt / 0.35); if (r.t >= 1) r.anim = false; }
    // posts come back once the car has driven a full lap of that road (and is not standing next to them)
    for (int k = (int)gBroken.size() - 1; k >= 0; k--){
        const int pi = gBroken[k]; const Post& p = gPosts[pi];
        if (gDistance - p.at > p.len && std::hypot(p.x - S.x, p.z - S.z) > 40){ restorePost(pi); gBroken.erase(gBroken.begin() + k); }
    }
}

// ======================================================================= per-frame instance data (everything is drawn instanced)
// one instance = 16 floats (column-major model matrix) + 3 floats (tint)
struct Inst { std::vector<float> posts, mounds, ropes, segs, parts, lamps, beams, gposts, swalls; };
static Inst gI;
static inline void pushI(std::vector<float>& v, const float* m, float r, float g, float b){ v.insert(v.end(), m, m + 16); v.push_back(r); v.push_back(g); v.push_back(b); }

static void postMatrix(const Post& p, float* m){
    if (!p.broken){ compose(m, p.x, p.y, p.z, qAxis(0, 1, 0, p.yaw), 1, p.sy, 1); return; }
    const double k = p.t, e = 1 - std::pow(1 - k, 2.2), arc = p.arc * std::sin(PI * k);                                  // flying off and tumbling down to lie on the ground
    double fx = p.fx, fy = 0.10, fz = p.fz; const double fl = std::sqrt(fx*fx + fy*fy + fz*fz); fx /= fl; fy /= fl; fz /= fl;
    Q q = qSlerpId(qFromUnit(0, 1, 0, fx, fy, fz), std::min(1.0, e * 3));
    q = qMul(q, qAxis(0, 1, 0, p.yaw + p.spin * e));
    compose(m, p.x + p.fx * p.D * e - p.fz * p.lat * e, p.y + (std::max(p.gy, p.y) - p.y + 0.03) * e + arc, p.z + p.fz * p.D * e + p.fx * p.lat * e, q, 1, p.sy * 0.9, 1);
}
static void endPt(const Post& p, double k, double* o){                         // where one end of the rope is: on its post top, or whipping down to the ground near the stump
    if (!p.broken){ o[0] = p.x; o[1] = p.y + 0.90; o[2] = p.z; return; }
    const double e = 1 - (1 - k) * (1 - k); o[0] = p.x + (p.ex - p.x) * e; o[1] = p.y + 0.90 + (p.y + 0.04 - p.y - 0.90) * e; o[2] = p.z + (p.ez - p.z) * e;
}
static void chainSegs(const Rail& r, std::vector<float>& out){
    const Post &pa = gPosts[r.a], &pb = gPosts[r.b]; double P[RSEG + 1][3]; const double k = r.t;
    endPt(pa, k, P[0]); endPt(pb, k, P[RSEG]);
    const double dx = P[RSEG][0] - P[0][0], dz = P[RSEG][2] - P[0][2]; double dl = std::hypot(dx, dz); if (dl == 0) dl = 1; const double nx = -dz / dl, nz = dx / dl, amp = 0.30 * k, ay = P[0][1], by = P[RSEG][1];
    for (int i = 0; i <= RSEG; i++){
        const double t = (double)i / RSEG, env = std::sin(PI * t) * 0.85 + 0.15, w = std::sin(t * PI * r.w + r.ph) * amp * env;
        if (i > 0 && i < RSEG){ P[i][0] = P[0][0] + dx * t + nx * w; P[i][2] = P[0][2] + dz * t + nz * w; P[i][1] = ay + (by - ay) * t + std::sin(t * PI * r.w * 1.7 + r.ph * 2) * 0.05 * k; }
        const double g = (pa.y + (pb.y - pa.y) * t) + 0.04; if (P[i][1] < g) P[i][1] = g;                                   // never below the ground
    }
    for (int i = 0; i < RSEG; i++){
        const double *a = P[i], *b = P[i+1]; float m[16];
        lookZ(m, (a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2, (b[0] - a[0]) / 2, b[1] - a[1], (b[2] - a[2]) / 2, std::sqrt((b[0]-a[0])*(b[0]-a[0]) + (b[1]-a[1])*(b[1]-a[1]) + (b[2]-a[2])*(b[2]-a[2])) + 0.02);
        pushI(out, m, r.tint, r.tint, r.tint);
    }
}

// eye = camera position, fwd = camera forward (unit). Only posts / ropes within FAR_DIST (and not far behind the camera) are emitted.
static void build(const float* eye, const float* fwd){
    gI.posts.clear(); gI.mounds.clear(); gI.ropes.clear(); gI.segs.clear(); gI.parts.clear(); gI.lamps.clear(); gI.beams.clear(); gI.gposts.clear(); gI.swalls.clear();
    if (!gReady) return;
    const double FD = FAR_DIST * Quality::distScale(); const double F2 = FD * FD; float m[16];
    auto vis = [&](double x, double z){ const double dx = x - eye[0], dz = z - eye[2], d2 = dx*dx + dz*dz; if (d2 > F2) return false; return d2 < 400.0 || dx * fwd[0] + dz * fwd[2] > -12.0; };
    for (const Post& p : gPosts){
        if (!vis(p.x, p.z)) continue;
        compose(m, p.x, p.y, p.z, qAxis(0, 1, 0, p.yaw), 1, 1, 1); pushI(gI.mounds, m, p.tint, p.tint, p.tint);        // the mound stays when the post is gone
        postMatrix(p, m); pushI(gI.posts, m, p.tint, p.tint, p.tint);
    }
    for (const GSeg& g : gGS){
        if (!vis(g.x, g.z)) continue;
        if (g.stone){ pushI(gI.swalls, g.bm, g.tint, g.tint, g.tint); continue; }
        if (g.beam){
            if (!g.broken) pushI(gI.beams, g.bm, g.tint, g.tint, g.tint);
            else {                                                                          // torn loose: one end stays bolted, the beam buckles in the middle and flops to the ground
                const double e = 1 - (1 - g.t) * (1 - g.t), bx = g.bx + (g.tx - g.bx) * e, bz = g.bz + (g.tz - g.bz) * e, by = g.by + (g.ty - g.by) * e;
                const double mx = (g.ax + bx) / 2, mz = (g.az + bz) / 2; double dx = bx - g.ax, dz = bz - g.az; const double dl = std::hypot(dx, dz) + 1e-6;
                const double ox = -dz / dl, oz = dx / dl, side = (std::fmod(g.x * 3.7 + g.z, 2.0) < 1.0 ? 1.0 : -1.0) * 0.45 * e;
                const double cx = mx + ox * side, cz = mz + oz * side, cy = std::max((g.ay + by) / 2 - 0.55 * e, groundY(cx, cz) + 0.12), v = g.tint * 0.72f;
                const double P[3][3] = {{g.ax, g.ay, g.az}, {cx, cy, cz}, {bx, by, bz}};
                for (int i = 0; i < 2; i++){ const double* A = P[i]; const double* B = P[i+1]; const double ddx = B[0]-A[0], ddy = B[1]-A[1], ddz = B[2]-A[2];
                    lookZ(m, (A[0]+B[0])/2, (A[1]+B[1])/2, (A[2]+B[2])/2, ddx, ddy, ddz, std::sqrt(ddx*ddx + ddy*ddy + ddz*ddz) + 0.03); pushI(gI.beams, m, (float)v, (float)(v * 0.97), (float)(v * 0.92)); }
            }
        }
        if (g.post){
            if (!g.broken) pushI(gI.gposts, g.pm, 1, 1, 1);
            else { const double k = 1 - (1 - g.t) * (1 - g.t); Q q = qMul(qAxis(std::sin(g.td), 0, -std::cos(g.td), 0.55 * k), qAxis(0, 1, 0, std::atan2(g.bx - g.ax, g.bz - g.az)));
                compose(m, g.ax, g.ay, g.az, q, 1, 1, 1); pushI(gI.gposts, m, 0.9f, 0.9f, 0.9f); }
        }
    }
    for (const Rail& r : gRails){
        const Post &a = gPosts[r.a], &b = gPosts[r.b]; if (!vis((a.x + b.x) / 2, (a.z + b.z) / 2)) continue;
        if (r.chain){ chainSegs(r, gI.segs); continue; }
        const double dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z; lookZ(m, (a.x + b.x) / 2, (a.y + b.y) / 2, (a.z + b.z) / 2, dx, dy, dz, std::sqrt(dx*dx + dy*dy + dz*dz)); pushI(gI.ropes, m, r.tint, r.tint, r.tint);
    }
    for (int i = 0; i < NPART; i++){
        const Part& q = gParts[i]; if (q.life <= 0) continue; const double k = std::min(1.0, q.life / q.max * 1.6); if (k <= 0) continue;
        compose(m, q.x, q.y, q.z, qMul(qAxis(1, 0, 0, q.sp * q.life), qAxis(0, 1, 0, q.sp * 0.7 * q.life)), q.s * k, q.s * k, q.s * k); pushI(gI.parts, m, q.r, q.g, q.b);
    }
    for (const Lamp& l : gLamps){
        const double dx = l.x - eye[0], dz = l.z - eye[2]; if (dx*dx + dz*dz > 400.0 * 400.0) continue;
        Q q = qAxis(0, 1, 0, -l.a); if (l.tilt > 0) q = qMul(qAxis(std::sin(l.tiltDir), 0, -std::cos(l.tiltDir), l.tilt), q);      // lean about the foot, away from the car
        compose(m, l.x, l.by, l.z, q, 1, 1, 1); pushI(gI.lamps, m, l.tint[0], l.tint[1], l.tint[2]);
    }
}

} // namespace Fence
