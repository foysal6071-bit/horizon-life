# Sunny Drift — Migration Notes (বাংলা)

মূল প্রজেক্টের `native-lib.cpp` অনুযায়ী গাড়ির mesh `r8.bin`-এ packed থাকে:
- প্রতি vertex 6 bytes: তিনটি little-endian uint16 position
- প্রতি vertex 4 bytes: চারটি int8 normal storage (XYZ ব্যবহৃত)
- এরপর `ni` little-endian uint16 triangle indices
- `r8_meta.txt`-এ vertex/index count, bounds এবং material group-এর start/count/colour থাকে।

`Assets/Editor/SunnyDriftR8Importer.cs` Unity Editor menu থেকে এই ফরম্যাট import করে। Importer native OpenGL loader-এর coordinate transform `(rz - (-104.45), ry, -rx) * (2.8 / 2643.1)` অনুসরণ করে।

সতর্কতা: Unity Editor-এ importer চালিয়ে ফলাফল দেখা ও mesh winding/normals যাচাই করা প্রয়োজন। এই পরিবেশে Unity Editor/Android SDK নেই, তাই Unity compile বা APK build যাচাই করা হয়নি।


## C# Physics and road port
`SunnyDriftPhysics.cs` is a line-by-line style translation of `Veh::step` from `OriginalAndroidSource/cpp/car_core.h`, including pedal state logic, gearbox, engine torque curve, load transfer, tyre friction circle, relaxation slip angles and integration. Surface defaults mirror the source `Surface` struct. `SunnyDriftWorldGenerator.cs` implements the `ringPt` harmonics and the five road centre-lines (three loops and two S-bend connectors); its road strip is a Unity mesh approximation, not a byte-for-byte rendering port.
