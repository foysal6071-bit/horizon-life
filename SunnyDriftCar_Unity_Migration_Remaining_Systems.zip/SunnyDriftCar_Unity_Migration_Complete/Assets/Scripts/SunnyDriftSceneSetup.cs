using UnityEngine;
/// <summary>One-click runtime scene bootstrap. Add to an empty GameObject in the first scene.</summary>
public class SunnyDriftSceneSetup : MonoBehaviour
{
    public GameObject carPrefab;
    public bool createWorld=true,createEnvironment=true,createHud=true;
    void Start(){
        if(createWorld&&!FindObjectOfType<SunnyDriftWorldGenerator>()){
            var w=new GameObject("Sunny Drift Road Network");w.AddComponent<SunnyDriftWorldGenerator>();
        }
        if(createEnvironment&&!FindObjectOfType<SunnyDriftEnvironment>()){
            var e=new GameObject("Sunny Drift Environment");e.AddComponent<SunnyDriftEnvironment>();
        }
        GameObject car=carPrefab;
        if(!car){var existing=FindObjectOfType<SunnyDriftVehicle>();if(existing)car=existing.gameObject;}
        if(car&&!car.GetComponent<SunnyDriftVehicle>())car.AddComponent<SunnyDriftVehicle>();
        if(car&&!FindObjectOfType<SunnyDriftFollowCamera>()){
            var cam=Camera.main;if(!cam){var cg=new GameObject("Main Camera");cam=cg.AddComponent<Camera>();cg.tag="MainCamera";}
            var follow=cam.gameObject.AddComponent<SunnyDriftFollowCamera>();follow.target=car.transform;
        }
        if(car&&createHud&&!FindObjectOfType<SunnyDriftMobileHUD>()){
            var h=new GameObject("Sunny Drift HUD");h.AddComponent<SunnyDriftMobileHUD>().vehicle=car.GetComponent<SunnyDriftVehicle>();
        }
        if(!FindObjectOfType<SunnyDriftDayNight>())new GameObject("Day Night Cycle").AddComponent<SunnyDriftDayNight>();
    }
}
