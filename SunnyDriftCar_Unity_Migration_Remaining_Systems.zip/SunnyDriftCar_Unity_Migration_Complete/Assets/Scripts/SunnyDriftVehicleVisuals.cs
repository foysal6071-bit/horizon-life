using UnityEngine;
/// <summary>Visual effects for the imported vehicle: wheel spin hooks, brake/reverse lights, headlamps and skid particles.</summary>
public class SunnyDriftVehicleVisuals : MonoBehaviour
{
    public SunnyDriftVehicle vehicle;
    public Transform[] wheelMeshes=new Transform[4];
    public Light[] headlamps;
    public Renderer[] brakeLightRenderers;
    public ParticleSystem dust, tyreSmoke;
    public float wheelRadius=.332f;
    float wheelAngle;
    void Awake(){if(!vehicle)vehicle=GetComponent<SunnyDriftVehicle>();}
    void Update(){
        if(!vehicle)return;
        float speed=vehicle.SpeedKph/3.6f;
        wheelAngle+=speed/Mathf.Max(.05f,wheelRadius)*Mathf.Rad2Deg*Time.deltaTime;
        for(int i=0;i<wheelMeshes.Length;i++)if(wheelMeshes[i]){
            wheelMeshes[i].localRotation=Quaternion.Euler(wheelAngle,(i<2?vehicle.transform.localEulerAngles.y:0),0);
        }
        bool night=RenderSettings.ambientIntensity<.6f;
        foreach(var l in headlamps)if(l)l.enabled=night;
        foreach(var r in brakeLightRenderers)if(r&&r.material.HasProperty("_EmissionColor")){
            Color c=vehicle.GetComponent<SunnyDriftVehicle>()?Color.red:Color.black;
            r.material.EnableKeyword("_EMISSION");r.material.SetColor("_EmissionColor",c*(vehicle.SpeedKph<1?0.2f:1.2f));
        }
        bool drifting=Mathf.Abs(speed)>8 && (vehicle.Gear>0);
        if(dust){var e=dust.emission;e.rateOverTime=drifting?16:0;}
        if(tyreSmoke){var e=tyreSmoke.emission;e.rateOverTime=drifting?8:0;}
    }
}
