using UnityEngine;
[RequireComponent(typeof(Rigidbody))]
public class SunnyDriftVehicle : MonoBehaviour
{
    public float steeringSensitivity=1.8f; public Transform centerOfMass; public SunnyDriftPhysics physics=new SunnyDriftPhysics();
    public float SpeedKph {get;private set;} public float RPM=900; public int Gear=1; public float Drift=> (float)physics.drift;
    bool gas,brake,left,right,hand; float analog; bool useAnalog;
    Rigidbody rb;
    void Awake(){rb=GetComponent<Rigidbody>();rb.mass=1650;rb.useGravity=false;rb.drag=0;rb.angularDrag=0;rb.interpolation=RigidbodyInterpolation.Interpolate;rb.isKinematic=true; if(centerOfMass){} }
    void FixedUpdate(){physics.Step(gas,brake,left,right,hand,analog,useAnalog,steeringSensitivity,Time.fixedDeltaTime);Vector3 p=new Vector3((float)physics.x,transform.position.y,(float)physics.z);Quaternion q=Quaternion.Euler(0,(float)(physics.heading*Mathf.Rad2Deg),0);rb.MovePosition(p);rb.MoveRotation(q);SpeedKph=(float)Mathf.Abs((float)physics.speed)*3.6f;RPM=(float)physics.rpm;Gear=physics.gear;}
    public void SetThrottle(float v)=>gas=v>.5f; public void SetBrake(float v)=>brake=v>.5f; public void SetSteer(float v){left=v<-.1f;right=v>.1f;} public void SetSteerButtons(bool l,bool r){left=l;right=r;useAnalog=false;} public void SetAnalogSteer(float v){analog=v;useAnalog=true;} public void SetHandbrake(bool v)=>hand=v;
    public void ResetVehicle(Transform spawn){physics.Reset(spawn?spawn.position.x:transform.position.x,spawn?spawn.position.z:transform.position.z,spawn?spawn.eulerAngles.y*Mathf.Deg2Rad:0);if(spawn)transform.SetPositionAndRotation(spawn.position,spawn.rotation);}
}
