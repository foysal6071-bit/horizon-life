using UnityEngine;

public class SunnyDriftFollowCamera : MonoBehaviour
{
    public Transform target;
    public Vector3 offset = new Vector3(0, 4.2f, -8.5f);
    public float positionSmooth = 6f;
    public float lookHeight = 1.1f;
    void LateUpdate()
    {
        if (!target) return;
        Vector3 desired = target.TransformPoint(offset);
        transform.position = Vector3.Lerp(transform.position, desired, 1f - Mathf.Exp(-positionSmooth * Time.deltaTime));
        transform.LookAt(target.position + Vector3.up * lookHeight);
    }
}
