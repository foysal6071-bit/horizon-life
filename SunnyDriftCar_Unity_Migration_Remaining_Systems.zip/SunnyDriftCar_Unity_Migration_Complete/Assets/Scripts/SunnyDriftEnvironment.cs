using UnityEngine;

/// <summary>
/// Runtime environment pass: rolling valley terrain, forest, Swiss-style village,
/// bridge decks, tunnel portals, roadside lamps and boundary fencing.
/// Generated procedurally so the Unity project has no external model dependency.
/// </summary>
public class SunnyDriftEnvironment : MonoBehaviour
{
    public Material terrainMaterial, treeMaterial, woodMaterial, stoneMaterial, waterMaterial, lampMaterial;
    [Range(4,10)] public int terrainResolution = 7;
    [Range(80,500)] public int treeCount = 240;
    public int seed = 2206;
    public bool generateOnStart = true;

    void Start(){ if(generateOnStart) Generate(); }
    Material Mat(string n, Color c, float metallic=0f, float smooth=.25f){
        var m=new Material(Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard"));
        m.name=n; m.color=c;
        if(m.HasProperty("_Metallic"))m.SetFloat("_Metallic",metallic);
        if(m.HasProperty("_Smoothness"))m.SetFloat("_Smoothness",smooth);
        return m;
    }
    public void Generate(){
        if(transform.childCount>0)return;
        if(!terrainMaterial)terrainMaterial=Mat("Valley grass",new Color(.23f,.34f,.19f));
        if(!treeMaterial)treeMaterial=Mat("Pine foliage",new Color(.08f,.25f,.10f));
        if(!woodMaterial)woodMaterial=Mat("Chalet timber",new Color(.30f,.16f,.08f));
        if(!stoneMaterial)stoneMaterial=Mat("Mountain stone",new Color(.27f,.29f,.30f));
        if(!waterMaterial)waterMaterial=Mat("Lake water",new Color(.10f,.31f,.40f),.25f,.8f);
        if(!lampMaterial)lampMaterial=Mat("Warm lamp",new Color(1f,.72f,.35f));
        Terrain(); Forest(); Village(); Bridge(new Vector3(-42,.35f,85),new Vector3(42,.35f,85), "Wooden Bridge"); 
        Tunnels(); Fence(); Lamps(); Beach();
    }
    float Height(float x,float z){
        float broad=Mathf.Sin(x*.0031f+1.2f)*Mathf.Cos(z*.0024f)*15f;
        float ridge=Mathf.Sin((x+z)*.009f)*Mathf.Cos(z*.006f)*4.5f;
        float basin=-Mathf.Exp(-Mathf.Pow(x/90f,2))*4f;
        return broad+ridge+basin-2f;
    }
    void Terrain(){
        int n=1<<terrainResolution; float size=1500f;
        var mesh=new Mesh(); mesh.name="Procedural Alpine Valley";
        var v=new Vector3[(n+1)*(n+1)];var uv=new Vector2[v.Length];var t=new int[n*n*6];
        for(int z=0;z<=n;z++)for(int x=0;x<=n;x++){
            int i=z*(n+1)+x;float px=(x/(float)n-.5f)*size,pz=(z/(float)n-.5f)*size;
            v[i]=new Vector3(px,Height(px,pz),pz);uv[i]=new Vector2(x,z);
        }
        int k=0;for(int z=0;z<n;z++)for(int x=0;x<n;x++){
            int a=z*(n+1)+x,b=a+1,c=a+n+1,d=c+1;
            t[k++]=a;t[k++]=c;t[k++]=b;t[k++]=b;t[k++]=c;t[k++]=d;
        }
        mesh.vertices=v;mesh.uv=uv;mesh.triangles=t;mesh.RecalculateNormals();
        var go=new GameObject("Rolling Alpine Terrain");go.transform.SetParent(transform,false);
        go.AddComponent<MeshFilter>().sharedMesh=mesh;go.AddComponent<MeshRenderer>().sharedMaterial=terrainMaterial;
    }
    void Forest(){
        var rng=new System.Random(seed);var root=new GameObject("Pine Forest").transform;root.SetParent(transform,false);
        var cone=GameObject.CreatePrimitive(PrimitiveType.Capsule);cone.name="Pine prototype";cone.transform.SetParent(root,false);
        cone.transform.localScale=new Vector3(.7f,1.5f,.7f);cone.GetComponent<Renderer>().sharedMaterial=treeMaterial;
        var trunk=GameObject.CreatePrimitive(PrimitiveType.Cylinder);trunk.name="Trunk prototype";trunk.transform.SetParent(root,false);
        trunk.transform.localScale=new Vector3(.18f,.75f,.18f);trunk.GetComponent<Renderer>().sharedMaterial=woodMaterial;
        for(int i=0;i<treeCount;i++){
            float a=(float)rng.NextDouble()*Mathf.PI*2,r=80+(float)rng.NextDouble()*620;
            float x=Mathf.Cos(a)*r*1.25f,z=Mathf.Sin(a)*r*.78f;
            if(Mathf.Abs(x)<32 && Mathf.Abs(z)<170)continue;
            float y=Height(x,z);float s=.75f+(float)rng.NextDouble()*1.5f;
            var c=GameObject.CreatePrimitive(PrimitiveType.Capsule);c.name="Pine";c.transform.SetParent(root,false);
            c.transform.position=new Vector3(x,y+1.3f*s,z);c.transform.localScale=new Vector3(.7f*s,1.5f*s,.7f*s);c.GetComponent<Renderer>().sharedMaterial=treeMaterial;
            var tr=GameObject.CreatePrimitive(PrimitiveType.Cylinder);tr.name="Pine Trunk";tr.transform.SetParent(root,false);
            tr.transform.position=new Vector3(x,y+.65f*s,z);tr.transform.localScale=new Vector3(.15f*s,.65f*s,.15f*s);tr.GetComponent<Renderer>().sharedMaterial=woodMaterial;
        }
        Destroy(cone);Destroy(trunk);
    }
    void Village(){
        var village=new GameObject("Alpine Village").transform;village.SetParent(transform,false);
        for(int i=0;i<12;i++){
            float x=-115+(i%4)*38,z=175+(i/4)*35;
            var house=GameObject.CreatePrimitive(PrimitiveType.Cube);house.name="Timber Chalet";house.transform.SetParent(village,false);
            house.transform.position=new Vector3(x,Height(x,z)+4,z);house.transform.localScale=new Vector3(18,8,14);house.GetComponent<Renderer>().sharedMaterial=woodMaterial;
            var roof=GameObject.CreatePrimitive(PrimitiveType.Cube);roof.name="Chalet Roof";roof.transform.SetParent(village,false);
            roof.transform.position=new Vector3(x,Height(x,z)+9,z);roof.transform.localScale=new Vector3(20,2,16);roof.transform.rotation=Quaternion.Euler(0,45,0);roof.GetComponent<Renderer>().sharedMaterial=stoneMaterial;
        }
        var church=GameObject.CreatePrimitive(PrimitiveType.Cube);church.name="Village Church";church.transform.SetParent(village,false);
        church.transform.position=new Vector3(0,Height(0,250)+7,250);church.transform.localScale=new Vector3(12,14,16);church.GetComponent<Renderer>().sharedMaterial=stoneMaterial;
        var spire=GameObject.CreatePrimitive(PrimitiveType.Cylinder);spire.name="Church Spire";spire.transform.SetParent(village,false);
        spire.transform.position=new Vector3(0,Height(0,250)+17,250);spire.transform.localScale=new Vector3(2,7,2);spire.GetComponent<Renderer>().sharedMaterial=woodMaterial;
    }
    void Bridge(Vector3 a,Vector3 b,string label){
        var go=GameObject.CreatePrimitive(PrimitiveType.Cube);go.name=label;go.transform.SetParent(transform,false);
        go.transform.position=(a+b)*.5f;Vector3 d=b-a;go.transform.localScale=new Vector3(13,.7f,d.magnitude);go.transform.rotation=Quaternion.LookRotation(d);
        go.GetComponent<Renderer>().sharedMaterial=woodMaterial;
        for(int side=-1;side<=1;side+=2)for(int i=0;i<9;i++){
            var rail=GameObject.CreatePrimitive(PrimitiveType.Cube);rail.name="Bridge rail";rail.transform.SetParent(transform,false);
            rail.transform.position=go.transform.position+go.transform.right*(side*6.5f)+go.transform.forward*((i-4)*d.magnitude/9)+Vector3.up*1.2f;
            rail.transform.localScale=new Vector3(.25f,.25f,d.magnitude/9);rail.GetComponent<Renderer>().sharedMaterial=woodMaterial;
        }
    }
    void Tunnels(){
        for(int i=0;i<2;i++){float z=i==0?-690:690;var portal=GameObject.CreatePrimitive(PrimitiveType.Cube);portal.name="Tunnel Portal";
            portal.transform.SetParent(transform,false);portal.transform.position=new Vector3(0,Height(0,z)+4,z);portal.transform.localScale=new Vector3(24,9,4);portal.GetComponent<Renderer>().sharedMaterial=stoneMaterial;}
    }
    void Fence(){
        var f=new GameObject("World Boundary Fence").transform;f.SetParent(transform,false);
        for(int i=0;i<80;i++){float a=i/80f*Mathf.PI*2;float x=Mathf.Cos(a)*720,z=Mathf.Sin(a)*560;
            var p=GameObject.CreatePrimitive(PrimitiveType.Cylinder);p.name="Fence post";p.transform.SetParent(f,false);p.transform.position=new Vector3(x,Height(x,z)+1,z);p.transform.localScale=new Vector3(.18f,1,.18f);p.GetComponent<Renderer>().sharedMaterial=woodMaterial;}
    }
    void Lamps(){
        for(int i=0;i<20;i++){float z=-300+i*32;var pole=GameObject.CreatePrimitive(PrimitiveType.Cylinder);pole.name="Road Lamp";pole.transform.SetParent(transform,false);
            pole.transform.position=new Vector3(17,Height(17,z)+3,z);pole.transform.localScale=new Vector3(.12f,3,.12f);pole.GetComponent<Renderer>().sharedMaterial=woodMaterial;
            var lightGo=new GameObject("Warm street light");lightGo.transform.SetParent(pole.transform,false);lightGo.transform.localPosition=new Vector3(0,1,0);
            var l=lightGo.AddComponent<Light>();l.type=LightType.Point;l.color=new Color(1f,.72f,.42f);l.range=13;l.intensity=.8f;
        }
    }
    void Beach(){
        var shore=GameObject.CreatePrimitive(PrimitiveType.Cube);shore.name="Lake Shore";shore.transform.SetParent(transform,false);
        shore.transform.position=new Vector3(260,-.4f,0);shore.transform.localScale=new Vector3(95,.4f,230);shore.GetComponent<Renderer>().sharedMaterial=waterMaterial;
        var pier=GameObject.CreatePrimitive(PrimitiveType.Cube);pier.name="Wooden Pier";pier.transform.SetParent(transform,false);
        pier.transform.position=new Vector3(210,.5f,0);pier.transform.localScale=new Vector3(8,.5f,45);pier.GetComponent<Renderer>().sharedMaterial=woodMaterial;
    }
}
