using UnityEngine;
/// <summary>Day/night cycle, sun/moon ambience and vehicle headlamp support.</summary>
public class SunnyDriftDayNight : MonoBehaviour
{
    public Light sun; public Light moon; public Material skyMaterial;
    [Range(0,24)] public float timeOfDay=15f; public bool animateTime;
    public float minutesPerDay=12f;
    void Start(){
        if(!sun){var g=new GameObject("Sunny Drift Sun");sun=g.AddComponent<Light>();sun.type=LightType.Directional;}
        if(!moon){var g=new GameObject("Sunny Drift Moon");moon=g.AddComponent<Light>();moon.type=LightType.Directional;moon.color=new Color(.42f,.52f,.8f);}
    }
    void Update(){
        if(animateTime)timeOfDay=(timeOfDay+Time.deltaTime*24f/(minutesPerDay*60f))%24f;
        float angle=(timeOfDay/24f)*360f-90f;sun.transform.rotation=Quaternion.Euler(angle,35,0);
        float daylight=Mathf.Clamp01(Mathf.Sin((timeOfDay-6f)/12f*Mathf.PI));
        sun.intensity=Mathf.Lerp(.04f,1.15f,daylight);moon.intensity=(1-daylight)*.35f;
        RenderSettings.ambientIntensity=Mathf.Lerp(.35f,1f,daylight);
        RenderSettings.fog=true;RenderSettings.fogColor=Color.Lerp(new Color(.025f,.04f,.09f),new Color(.58f,.68f,.76f),daylight);
        RenderSettings.fogDensity=Mathf.Lerp(.0018f,.00045f,daylight);
    }
    public void SetNight(bool night){timeOfDay=night?22f:14f;}
}
