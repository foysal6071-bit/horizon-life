using System;
using UnityEngine;

/// <summary>Port of OriginalAndroidSource/cpp/car_core.h Veh::step (v19).</summary>
[Serializable] public class SunnyDriftPhysics
{
    public double x,z,heading,speed,vy,yaw,steer,steerAngle,throttle,brake,ax,ay,axS,revTimer;
    public int gear=1; public double rpm=900,shiftT,ayLim=9,hb,drift,fd,slope; public bool reverse,braking,handOn; public double aFr,aRr;
    public double surfaceMu=1.15, surfaceRr=.028, surfaceMuF=-1, surfaceMuR=-1, surfacePull, surfaceMuSide;
    const double G=9.81,MASS=1650,WB=2.8,WR=.40,RPMK=1.0/(.10472*.40),VMAX=220.0/3.6,IDLE=900,REDLINE=7000,EFF=.92,ENGINE_BRAKE=30;
    const double R6=7000/(VMAX*RPMK),REV_MAX=20.0/3.6,REV_FORCE=3600,BRAKE_DECEL=13,K_AERO=.40,K_DOWN=.45,RR_OFFSET=.015;
    const double TYRE_K=.97,TYRE_KL=1.06,TYRE_B=13,TYRE_C=1.4,LOAD_SENS=.13,FZ_REF=MASS*G/4,RELAX=.45,DRIVE_REAR=.60;
    const double LA=1.55,LB=1.25,IZ=2700,HCG=.46,TRACK=1.64,LT_FRONT=.54,STEER_LOCK=.55,STEER_RATE=3.6,STEER_RETURN=6;
    static readonly double[] RATIOS={0,R6*3.297,R6*2.286,R6*1.670,R6*1.319,R6*1.121,R6};
    static double Clamp(double v,double a,double b)=>Math.Max(a,Math.Min(b,v)); static double Sgn(double v)=>v>0?1:v<0?-1:0;
    static double Torque(double r){double[] R={900,1500,2500,3500,4500,5500,6500,7300},T={230,330,430,500,545,565,560,500}; double v;if(r<=R[0])v=T[0];else if(r>=R[7])v=T[7];else{int i=0;while(r>R[i+1])i++;v=T[i]+(T[i+1]-T[i])*(r-R[i])/(R[i+1]-R[i]);}return v*Clamp((REDLINE+300-r)/300,0,1);}
    static double AxleGrip(double fa,double df){double fz0=fa*.5,k0=1-LOAD_SENS*(fz0/FZ_REF-1),r=Math.Min(df/Math.Max(fz0,1),1);return Math.Max(k0,.4)*(1-LOAD_SENS*1.6*r*r);}
    public void Step(bool gas,bool brakeIn,bool left,bool right,bool hand,double analog,bool useAnalog,double sens,double dt){
        double vx0=speed,thrT=0,brkT=0;bool rev=false;
        if(gas&&brakeIn)brkT=1; else if(gas){if(vx0<-.8)brkT=1;else thrT=1;} else if(brakeIn){if(vx0>.8)brkT=1;else{revTimer+=dt;if(revTimer>.3||vx0<-.8){rev=true;thrT=1;}else brkT=1;}}
        if(!brakeIn||gas)revTimer=0;
        if(hand){if(speed>6)brkT=brakeIn?1:gas?0:((left||right)?.18:.45);else{brkT=1;thrT=0;rev=false;}}
        reverse=rev;throttle+=(thrT-throttle)*(1-Math.Exp(-dt*(thrT>throttle?7:14)));this.brake+=(brkT-this.brake)*(1-Math.Exp(-dt*(brkT>this.brake?18:20)));
        braking=this.brake>.25;handOn=hand;hb+=(((hand&&speed>5)?1:0)-hb)*(1-Math.Exp(-dt*6));double av=Math.Abs(speed);
        double steerIn=useAnalog?analog:(left?1:0)-(right?1:0);double rate=((steerIn==0||Sgn(steerIn)!=Sgn(steer))?STEER_RETURN:STEER_RATE)*sens/(1+av/120);double dS=steerIn-steer;steer+=Sgn(dS)*Math.Min(Math.Abs(dS),rate*dt);
        shiftT=Math.Max(0,shiftT-dt);if(reverse||speed<-.5)gear=0;else{if(gear==0)gear=1;double sp=Math.Max(speed,0),rpmG=sp*RATIOS[gear]*RPMK;if(shiftT<=0){if(gear<6&&(rpmG>6700||(rpmG>5200&&throttle<.15))){gear++;shiftT=.12;}else if(gear>1&&(rpmG<2300||(throttle>.9&&rpmG<3600))&&sp*RATIOS[gear-1]*RPMK<6400){gear--;shiftT=.10;}}}
        double gearR=gear==0?14:RATIOS[gear],rpmW=av*gearR*RPMK,clutch=1-Clamp(av/6,0,1),rpmTgt=Math.Max(rpmW,IDLE+throttle*3600*clutch);rpm+=(rpmTgt-rpm)*(1-Math.Exp(-dt*(rpmTgt>rpm?12:7)));rpm=Math.Min(rpm,REDLINE+300);
        double fdrive=0;if(throttle>.001){if(reverse)fdrive=-throttle*REV_FORCE*Clamp((REV_MAX+speed)/3,0,1);else fdrive=throttle*Torque(Math.Max(rpm,3300))*RATIOS[gear]*EFF/WR*(shiftT>0?1-.5*Math.Sin(Math.PI*(1-Math.Min(shiftT/.12,1))):1);}if(!reverse)fdrive*=Clamp((VMAX-speed)/1.2,0,1);fd+=(fdrive-fd)*(1-Math.Exp(-dt*16));fdrive=fd;
        double rrS=Math.Max(surfaceRr-RR_OFFSET,.008),gripN0=surfaceMu*TYRE_K*(MASS*G+K_DOWN*speed*speed),gripL0=surfaceMu*TYRE_KL*(MASS*G+K_DOWN*speed*speed);
        double flong=Math.Max(Math.Min(Math.Abs(fdrive),.8*gripL0),this.brake*Math.Min(BRAKE_DECEL*MASS,.97*gripL0));ayLim=Math.Sqrt(Math.Max(gripN0*gripN0-flong*flong,.04*gripN0*gripN0))/MASS*.97;
        double sensK=Clamp(.7+.3*sens,.85,1.6),lockSpeed=sensK*STEER_LOCK/(1+Math.Pow(av/46,2)),lockGrip=.06*sensK+Math.Atan(WB*ayLim*1.1/Math.Max(speed*speed,1)),dDrv=steer*Math.Min(lockSpeed,lockGrip),delta=dDrv;
        int n=Math.Max(1,(int)Math.Ceiling(dt/.005));double h=dt/n,axAcc=0;
        for(int it=0;it<n;it++){
            double vx=speed,sp=Math.Abs(vx),sg=Clamp(vx/.4,-1,1),wDyn=Clamp((vx-3)/4,0,1),down=K_DOWN*vx*vx,muFl=surfaceMuF>0?surfaceMuF:surfaceMu,muRl=surfaceMuR>0?surfaceMuR:surfaceMu;
            double gripN=surfaceMu*TYRE_KL*(MASS*G+down);bool wasDrift=drift>.3;double lim=(wasDrift?1:.8)*gripN,Fd=Clamp(fdrive,-lim,lim),Fb=this.brake*Math.Min(BRAKE_DECEL*MASS,.97*gripN);
            double Fres=-sg*(rrS*MASS*G+K_AERO*vx*vx+MASS*Math.Abs(ay)*.04);if(gear>0){double eb=Clamp(1-throttle/.15,0,1)*Clamp(1-this.brake/.15,0,1);Fres-=sg*Clamp(sp/2,0,1)*ENGINE_BRAKE*RATIOS[gear]*(rpm/REDLINE)/WR*eb;}double Fg=-MASS*G*slope,Fx=Fd-sg*Fb+Fres+Fg;
            double dFz=Clamp(MASS*axS*HCG/WB,-.22*MASS*G,.22*MASS*G),FzF=Math.Max(MASS*G*LB/WB-dFz+down*.40,800),FzR=Math.Max(MASS*G*LA/WB+dFz+down*.60,800),latT=MASS*Math.Abs(ay)*HCG/TRACK;
            double gF=AxleGrip(FzF,latT*LT_FRONT),gR=AxleGrip(FzR,latT*(1-LT_FRONT)),muF=muFl*TYRE_K*gF,muR=muRl*TYRE_K*gR,muFL=muFl*TYRE_KL*gF,muRL=muRl*TYRE_KL*gR;
            double uA=Math.Max(vx,2.5),beta=Math.Atan2(vy,uA),usF=Clamp((Fb*.68+Math.Abs(Fd)*(1-DRIVE_REAR)*.8)/(muFL*FzF),0,.95),usR=Clamp(.8*Math.Abs(Fd*DRIVE_REAR-sg*Fb*.32)/(muRL*FzR),0,.9),capF=Math.Sqrt(1-usF*usF),capR=Math.Sqrt(1-usR*usR)*(1-.55*hb)*(1+1.3*Clamp((Math.Abs(beta)-.55)/.4,0,1));
            double wAs=Clamp((Math.Abs(beta)-.08)/.15,0,1)*.7*wDyn;delta=Clamp(dDrv+wAs*Clamp(beta,-.7,.7),-.65,.65);
            double aFk=Math.Atan2(vy+LA*yaw,uA)-delta,aRk=Math.Atan2(vy-LB*yaw,uA),kr=1-Math.Exp(-Math.Max(sp,4)*h/RELAX);aFr+=(aFk-aFr)*kr;aRr+=(aRk-aRr)*kr;
            double FyF=-muF*FzF*capF*Math.Sin(TYRE_C*Math.Atan(TYRE_B*aFr)),FyR=-muR*FzR*capR*Math.Sin(TYRE_C*Math.Atan(TYRE_B*aRr)),cd=Math.Cos(delta),sd=Math.Sin(delta);
            speed+=(Fx-FyF*sd*wDyn)/MASS*h;speed=Clamp(speed,-REV_MAX,VMAX*(1+.03*Clamp(-slope*8,0,1)));axAcc+=Fx/MASS;vy+=(FyF*cd+FyR)/MASS*h*wDyn;
            double yawAsym=(.5*MASS*G*surfacePull*Clamp(sp/2,0,1)+.5*Fb*surfaceMuSide)*.85/IZ;yaw+=((LA*FyF*cd-LB*FyR)/IZ-.55*yaw+yawAsym)*h*wDyn;
            if(wDyn<1){double rK=speed*Math.Tan(delta)/WB;yaw+=(rK-yaw)*(1-Math.Exp(-h/.05))*(1-wDyn);vy*=Math.Exp(-8*(1-wDyn)*h);aFr*=Math.Exp(-8*(1-wDyn)*h);aRr*=Math.Exp(-8*(1-wDyn)*h);}yaw=Clamp(yaw,-2.6,2.6);
            if(Math.Abs(speed)<.08&&throttle<.02&&(Math.Abs(slope)<.3||this.brake>.3||hand)){speed=0;vy=0;yaw=0;aFr=aRr=0;}
            double dH=yaw*h;heading+=dH;double aa=dH*wDyn,c=Math.Cos(aa),sn=Math.Sin(aa),sp0=speed;speed=sp0*c+vy*sn;vy=-sp0*sn+vy*c;double sh=Math.Sin(heading),ch=Math.Cos(heading);x+=(speed*sh+vy*ch)*h;z+=(speed*ch-vy*sh)*h;
        }
        steerAngle=Clamp(delta,-.6,.6);double bR=Math.Abs(Math.Atan2(vy-LB*yaw,Math.Max(speed,2.5))),tgt=speed>5?Clamp((bR-.12)/.2,0,1):0;drift+=(tgt-drift)*(1-Math.Exp(-dt*(tgt>drift?10:3)));ax=axAcc/n;axS+=(ax-axS)*(1-Math.Exp(-dt*5));ay=speed*yaw;
    }
    public void Reset(double px=0,double pz=0,double h=0){x=px;z=pz;heading=h;speed=vy=yaw=steer=steerAngle=throttle=brake=ax=ay=axS=revTimer=0;gear=1;rpm=900;shiftT=hb=drift=fd=0;reverse=braking=handOn=false;aFr=aRr=0;}
}
