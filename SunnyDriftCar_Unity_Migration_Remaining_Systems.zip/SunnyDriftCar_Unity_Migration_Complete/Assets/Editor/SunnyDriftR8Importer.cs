#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

/// <summary>
/// Imports Sunny Drift's original packed Audi R8 mesh.
/// Binary layout is read directly from the supplied Android source:
/// uint16 position[3] per vertex, int8 normal[4] per vertex, uint16 triangle indices.
/// </summary>
public static class SunnyDriftR8Importer
{
    const string Source = "Assets/StreamingAssets/OriginalAssets";
    const string Output = "Assets/Generated/AudiR8";

    [MenuItem("Sunny Drift/Import Original Audi R8 Model")]
    public static void Import()
    {
        string rawPath = Path.Combine(Source, "r8.bin");
        string metaPath = Path.Combine(Source, "r8_meta.txt");
        if (!File.Exists(rawPath) || !File.Exists(metaPath))
        {
            EditorUtility.DisplayDialog("Sunny Drift Import", "Missing r8.bin or r8_meta.txt in Assets/StreamingAssets/OriginalAssets.", "OK");
            return;
        }

        string[] lines = File.ReadAllText(metaPath).Split(new[] {'\r','\n',' ','\t'}, StringSplitOptions.RemoveEmptyEntries);
        int p = 0;
        int vertexCount = int.Parse(lines[p++], CultureInfo.InvariantCulture);
        int indexCount = int.Parse(lines[p++], CultureInfo.InvariantCulture);
        Vector3 min = new Vector3(Parse(lines[p++]), Parse(lines[p++]), Parse(lines[p++]));
        Vector3 size = new Vector3(Parse(lines[p++]), Parse(lines[p++]), Parse(lines[p++]));
        int groupCount = int.Parse(lines[p++], CultureInfo.InvariantCulture);

        var groups = new List<Group>();
        for (int i = 0; i < groupCount; i++)
        {
            string name = lines[p++];
            int start = int.Parse(lines[p++], CultureInfo.InvariantCulture);
            int count = int.Parse(lines[p++], CultureInfo.InvariantCulture);
            string hex = lines[p++];
            int emissive = int.Parse(lines[p++], CultureInfo.InvariantCulture);
            if (count > 0 && start < 152712) groups.Add(new Group(name, start, count, Hex(hex), emissive != 0));
        }

        byte[] raw = File.ReadAllBytes(rawPath);
        long required = (long)vertexCount * 10 + (long)indexCount * 2;
        if (raw.LongLength < required)
            throw new InvalidDataException("r8.bin is shorter than the vertex/index counts declared by r8_meta.txt.");

        var vertices = new Vector3[vertexCount];
        var normals = new Vector3[vertexCount];
        const float scale = 2.8f / 2643.1f;
        const float zCenter = -104.45f;
        for (int i = 0; i < vertexCount; i++)
        {
            int o = i * 6;
            float rx = min.x + U16(raw, o) / 65535f * size.x;
            float ry = min.y + U16(raw, o + 2) / 65535f * size.y;
            float rz = min.z + U16(raw, o + 4) / 65535f * size.z;
            // Same axis conversion and scale as the original native OpenGL loader.
            vertices[i] = new Vector3((rz - zCenter) * scale, ry * scale, -rx * scale);

            int no = vertexCount * 6 + i * 4;
            Vector3 n = new Vector3(unchecked((sbyte)raw[no + 2]), unchecked((sbyte)raw[no + 1]), -unchecked((sbyte)raw[no]));
            normals[i] = n.sqrMagnitude > 0.00001f ? n.normalized : Vector3.up;
        }

        int indexOffset = vertexCount * 10;
        var allIndices = new int[indexCount];
        for (int i = 0; i < indexCount; i++) allIndices[i] = U16(raw, indexOffset + i * 2);

        Directory.CreateDirectory(Output);
        var mesh = new Mesh { name = "SunnyDrift_AudiR8_Mesh", indexFormat = IndexFormat.UInt32 };
        mesh.vertices = vertices;
        mesh.normals = normals;
        mesh.subMeshCount = groups.Count;
        var materials = new Material[groups.Count];

        for (int g = 0; g < groups.Count; g++)
        {
            Group group = groups[g];
            int end = Math.Min(indexCount, group.start + group.count);
            if (group.start < 0 || group.start >= end) continue;
            var sub = new int[end - group.start];
            Array.Copy(allIndices, group.start, sub, 0, sub.Length);
            mesh.SetIndices(sub, MeshTopology.Triangles, g, false);

            var mat = new Material(Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard"));
            mat.name = "R8_" + Safe(group.name);
            mat.color = group.color;
            if (mat.HasProperty("_Metallic")) mat.SetFloat("_Metallic", group.emissive ? 0.15f : 0.55f);
            if (mat.HasProperty("_Smoothness")) mat.SetFloat("_Smoothness", group.emissive ? 0.8f : 0.68f);
            if (group.emissive)
            {
                mat.EnableKeyword("_EMISSION");
                if (mat.HasProperty("_EmissionColor")) mat.SetColor("_EmissionColor", group.color * 1.4f);
            }
            string matPath = Output + "/" + mat.name + ".mat";
            AssetDatabase.CreateAsset(mat, AssetDatabase.GenerateUniqueAssetPath(matPath));
            materials[g] = mat;
        }
        mesh.RecalculateBounds();
        AssetDatabase.CreateAsset(mesh, Output + "/AudiR8_Mesh.asset");

        var root = new GameObject("Audi R8");
        var filter = root.AddComponent<MeshFilter>();
        var renderer = root.AddComponent<MeshRenderer>();
        filter.sharedMesh = mesh;
        renderer.sharedMaterials = materials;
        var body = root.AddComponent<Rigidbody>();
        body.mass = 1650f;
        body.interpolation = RigidbodyInterpolation.Interpolate;
        body.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
        var collider = root.AddComponent<BoxCollider>();
        collider.center = mesh.bounds.center;
        collider.size = new Vector3(mesh.bounds.size.x, Mathf.Max(0.5f, mesh.bounds.size.y * 0.55f), mesh.bounds.size.z);

        string prefabPath = Output + "/AudiR8.prefab";
        PrefabUtility.SaveAsPrefabAsset(root, prefabPath);
        UnityEngine.Object.DestroyImmediate(root);
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        EditorUtility.DisplayDialog("Sunny Drift Import", "Original Audi R8 mesh and material groups imported. Prefab: " + prefabPath, "OK");
    }

    static float Parse(string s) => float.Parse(s, CultureInfo.InvariantCulture);
    static int U16(byte[] b, int i) => b[i] | (b[i + 1] << 8);
    static Color Hex(string h)
    {
        if (ColorUtility.TryParseHtmlString(h, out Color c)) return c;
        return Color.gray;
    }
    static string Safe(string s)
    {
        foreach (char c in Path.GetInvalidFileNameChars()) s = s.Replace(c, '_');
        return s.Replace('/', '_').Replace('\\', '_');
    }
    struct Group
    {
        public string name; public int start, count; public Color color; public bool emissive;
        public Group(string n, int s, int c, Color col, bool e) { name=n; start=s; count=c; color=col; emissive=e; }
    }
}
#endif
