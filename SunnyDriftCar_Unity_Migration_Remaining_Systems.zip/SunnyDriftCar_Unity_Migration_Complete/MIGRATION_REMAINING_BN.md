# SunnyDriftCar — বাকি সিস্টেমের Unity পোর্ট (প্রস্তুতকৃত সোর্স)

এই আপডেটে Unity-র জন্য অতিরিক্ত C# runtime systems যোগ করা হয়েছে:

- `SunnyDriftEnvironment.cs`: procedural valley terrain, pine forest, chalet village, bridge, tunnel portal, fence, lamps ও beach/pier।
- `SunnyDriftDayNight.cs`: day/night lighting ও fog cycle।
- `SunnyDriftVehicleVisuals.cs`: wheel transform hooks, headlamp toggle, brake light emission ও dust/smoke emission hooks।
- `SunnyDriftSceneSetup.cs`: scene bootstrap; road generator, environment, car camera, HUD ও day/night setup।

## চালানোর ধাপ
1. Unity 6 project খুলুন এবং Package Manager থেকে Universal RP package resolve হতে দিন।
2. `Assets/StreamingAssets/OriginalAssets`-এ মূল ZIP থেকে কপি করা original binary assets রয়েছে।
3. Unity menu `Sunny Drift > Import Original Audi R8 Model` চালিয়ে model asset তৈরি করুন।
4. একটি Scene-এ empty GameObject বানিয়ে `SunnyDriftSceneSetup` যোগ করুন।
5. Audi R8 prefab-টি `carPrefab` slot-এ দিন। গাড়ির জন্য `SunnyDriftVehicle` ও প্রয়োজনীয় collider/visual hierarchy নিশ্চিত করুন।
6. `SunnyDriftVehicleVisuals.wheelMeshes`-এ চারটি পৃথক wheel transform দিন; imported combined mesh নিজে থেকে wheel-এ ভাগ হয় না।
7. Build Settings-এ Android যোগ করে Player Settings (ARM64, IL2CPP, graphics APIs) সেট করে Build করুন।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এটি একটি migration source package, verified finished game নয়। Original native OpenGL render pipeline-এর সব shader/effects, exact terrain/river/road mesh parity, bridge/water animation, village/tree source mesh parity, skid mark geometry, sound/settings persistence এবং device performance tuning এখনো সম্পূর্ণ 1:1 port নয়। নতুন environment কিছু procedural approximation ব্যবহার করে। Unity Editor/Android device এখানে চালিয়ে compile বা APK test করা হয়নি। APK build-এর আগে Unity-তে compile errors ও scene references যাচাই করা আবশ্যক।
