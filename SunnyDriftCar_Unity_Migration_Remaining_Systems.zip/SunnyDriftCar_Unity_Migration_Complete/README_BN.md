# Sunny Drift Car — Unity Migration Starter

আপনি সম্পূর্ণ Unity migration নির্বাচন করেছেন। এই প্যাকেজটি হলো প্রথম Unity migration scaffold; এটি এখনো সম্পূর্ণ playable conversion বা APK নয়।

## মূল Android প্রজেক্ট পরীক্ষা করে যা পাওয়া গেছে
- Android Java `MainActivity` + JNI + C++ native renderer
- OpenGL ES 3 rendering (`GLES3/gl3.h`), Android AssetManager এবং নিজস্ব GLSL shader pipeline
- C++-এ গাড়ির physics (`car_core.h`), road/environment generation এবং Audi R8 mesh renderer
- `r8.bin`, `r8_meta.txt`, `r8_groups.txt`, road textures/heights, sky এবং environment assets

## Unity scaffold-এ কী আছে
- `Assets/StreamingAssets/OriginalAssets/`: মূল গেমের সব runtime asset অপরিবর্তিত রাখা হয়েছে
- `OriginalAndroidSource/`: মূল C++/Java source reference হিসেবে রাখা হয়েছে
- `SunnyDriftVehicle.cs`: Unity Rigidbody ভিত্তিক প্রাথমিক driving controller; মূল C++ physics-এর সমতুল্য নয়
- `SunnyDriftFollowCamera.cs`: প্রাথমিক chase camera

## Unity-তে খোলার ধাপ
1. Unity Hub-এ **Unity 6 LTS → Universal 3D (URP)** project তৈরি করুন।
2. এই প্যাকেজের `Assets` এবং `OriginalAndroidSource` নতুন project-এর root-এ কপি করুন।
3. একটি car GameObject তৈরি করে Rigidbody, Collider এবং `SunnyDriftVehicle` যোগ করুন।
4. Main Camera-তে `SunnyDriftFollowCamera` যোগ করে `target`-এ car Transform দিন।
5. Android Build Support, SDK/NDK এবং OpenJDK ইনস্টল করে Android platform-এ switch করুন।

## সম্পূর্ণ migration-এর বাকি কাজ
1. `r8.bin` binary vertex/index data এবং group/material metadata থেকে Unity Mesh/Materials importer তৈরি।
2. C++ road, terrain, river, bridge, trees, village, tunnel, beach ও fence generators C# / Unity Mesh-এ port করা।
3. `car_core.h`-এর dynamic bicycle/Pacejka-style vehicle physics Unity physics বা C# solver-এ port ও tune করা।
4. GLSL shader-গুলো URP Shader Graph/HLSL-এ port করা; night/headlights, sky, shadows, tyre smoke/skid FX পুনর্নির্মাণ।
5. Java HUD/settings/minimap/touch controls/audio-কে Unity UI/Input System/Audio-তে port করা।
6. Android device profiling, visual parity testing এবং APK build।

**গুরুত্বপূর্ণ:** OpenGL ES renderer সরাসরি Unity-তে কপি করে কাজ করবে না। Unity-তে rendering-কে URP/HDRP pipeline-এ পুনর্লিখতে হবে। এই starter-এ মূল assets/source সংরক্ষিত আছে, কিন্তু scene, Audi mesh importer, environment renderer ও UI এখনো সম্পূর্ণ port করা হয়নি।


## নতুন ধাপ: আসল Audi R8 মডেল Import

1. Unity Hub দিয়ে Unity 6 (6000.0.32f1 বা কাছাকাছি 6.0 LTS) ইনস্টল করুন।
2. Android Build Support, Android SDK & NDK Tools এবং OpenJDK নির্বাচন করুন।
3. এই ফোল্ডারটি Unity Hub থেকে Add/Open করুন।
4. Unity Editor খুলে `Sunny Drift > Import Original Audi R8 Model` নির্বাচন করুন।
5. Import সফল হলে `Assets/Generated/AudiR8/AudiR8.prefab` তৈরি হবে।
6. Prefab-টি Scene-এ Drag করুন। গাড়ির Rigidbody এবং প্রাথমিক BoxCollider-ও তৈরি হবে।

### মডেল Import সম্পর্কে
- importer মূল `r8.bin`-এর packed uint16 vertex positions, int8 normals ও uint16 indices পড়ে।
- `r8_meta.txt`-এর material group range ও hex colour ব্যবহার করে Unity materials/submeshes তৈরি করে।
- OpenGL native loader-এ ব্যবহৃত একই axis conversion এবং 2.8m scale অনুসরণ করা হয়েছে।
- এই ধাপে শুধু Audi R8 static mesh/material groups Unity Mesh-এ রূপান্তর হয়। Wheel animation, original shader behaviour, tyre smoke/skid marks, road/terrain/village rendering এবং exact C++ physics এখনো Unity-তে সম্পূর্ণ port হয়নি।
- Original C++ source `OriginalAndroidSource/cpp/`-এ reference হিসেবে রাখা আছে; এটি Unity-তে স্বয়ংক্রিয়ভাবে চলে না।

## Migration status
- [x] Original Android source and binary assets retained
- [x] Unity 6 + URP project package manifest
- [x] Original packed Audi R8 mesh importer
- [x] Material groups and prefab generation
- [x] C# translation of original v19 vehicle physics solver (needs Unity runtime parity test)
- [x] Three ring roads + two connector road meshes (procedural C# approximation)
- [ ] Detailed terrain, river network/bridges, village, trees, beach, fences and sky port
- [ ] Animated wheels, lights, tyre FX and original shaders
- [x] Basic runtime mobile touch HUD (steering, gas, brake, handbrake, speed/gear)
- [ ] Settings/audio/minimap integration
- [ ] Android build and device testing

এটি Unity-তে প্রকৃত asset migration-এর কাজের প্রজেক্ট; সম্পূর্ণ গেম বা পরীক্ষিত APK নয়।


## Unity migration — gameplay port (পরবর্তী প্যাকেজ আপডেট)
এই আপডেটে অতিরিক্ত C# scripts যুক্ত হয়েছে:
- `SunnyDriftPhysics.cs`: মূল `car_core.h`-এর v19 `Veh::step` dynamic bicycle/Pacejka physics, automatic gearbox, throttle/brake smoothing, tyre relaxation, load transfer, drift/counter-steer, surface grip parameters-এর C# port।
- `SunnyDriftVehicle.cs`: Unity Transform/Rigidbody kinematic pose sync করে physics state চালায়; WASD/keyboard বা HUD input methods গ্রহণ করে।
- `SunnyDriftMobileHUD.cs`: runtime touch buttons (steer, gas, brake, handbrake) এবং speed/gear display তৈরি করে।
- `SunnyDriftWorldGenerator.cs`: মূল `road.h` থেকে ringPt harmonics/scale/phase এবং তিনটি ring road + দুই connector-এর procedural mesh port।

### Scene setup (নতুন scripts)
1. Scene-এ Empty GameObject `World` তৈরি করে `SunnyDriftWorldGenerator` যোগ করুন; Play করলে 3টি ring road, 2টি connector, ground ও river strip তৈরি হবে।
2. AudiR8 prefab-এ `SunnyDriftVehicle` যোগ করুন (Importer-এর Rigidbody থাকলে script নিজেই সেটিকে kinematic করে)। গাড়ির prefab-এর forward axis যেন Unity +Z-এর দিকে থাকে।
3. Empty GameObject-এ `SunnyDriftMobileHUD` যোগ করুন; touch controls runtime-এ তৈরি হবে।
4. গাড়ির শুরু অবস্থান (0,0,0) থেকে inner ring-এর কাছাকাছি সরিয়ে দিন; road mesh world coordinates-এ তৈরি হয়।

**Porting status:** Physics-এর মূল solver ও ring/connector road geometry C#-এ অনুবাদ করা হয়েছে, কিন্তু Unity-তে চালিয়ে numerical parity/visual parity যাচাই করা হয়নি। Terrain elevation, detailed river/bridges, tree/village meshes, tunnel/beach/fences, full sky/night shaders, audio, settings/minimap এবং Android APK testing এখনও বাকি। HUD legacy Unity Input API ব্যবহার করে; Project Settings > Player > Active Input Handling-এ `Both` বা `Input Manager (Old)` নির্বাচন করতে হবে।


## অতিরিক্ত Environment ও Runtime Systems

এই সংস্করণে `SunnyDriftEnvironment`, `SunnyDriftDayNight`, `SunnyDriftVehicleVisuals`, `SunnyDriftSceneSetup` যুক্ত হয়েছে। বিস্তারিত বাংলা নির্দেশনা `MIGRATION_REMAINING_BN.md`-এ। এগুলো procedural/Unity-side port; মূল OpenGL renderer-এর হুবহু রূপ নয় এবং Unity Editor-এ compile/device test করা হয়নি।
