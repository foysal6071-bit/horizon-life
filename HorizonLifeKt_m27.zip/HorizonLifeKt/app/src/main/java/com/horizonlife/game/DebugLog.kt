package com.horizonlife.game

import android.content.Context
import android.os.SystemClock
import android.util.Log
import java.io.File

/** On-screen debug log: lines are drawn over the game by ControlsView. A crash is saved to a file and shown on the next start. */
object DebugLog {
    private val lines = ArrayList<String>()
    private val seen = HashSet<String>()
    @Volatile var errors = 0
    @Volatile var firstFrameAt = 0L
    @Volatile var visible = true
    private val t0 = SystemClock.elapsedRealtime()
    private var crashFile: File? = null

    fun add(msg: String) {
        val t = (SystemClock.elapsedRealtime() - t0) / 1000.0
        val s = String.format("%.1fs %s", t, msg)
        Log.i("HL", s)
        synchronized(lines) { lines.add(s); while (lines.size > 60) lines.removeAt(0) }
    }

    /** log an error once per distinct (where + message) */
    fun err(where: String, e: Throwable) {
        val key = where + e.toString()
        synchronized(seen) { if (!seen.add(key)) return }
        errors++
        Log.e("HL", "ERROR in $where", e)
        add("ERROR $where: ${e.javaClass.simpleName}: ${(e.message ?: "").take(300)}")
        e.stackTrace.take(4).forEach { add("   at ${it.className.substringAfterLast('.')}.${it.methodName}:${it.lineNumber}") }
    }

    fun snapshot(): List<String> = synchronized(lines) { ArrayList(lines) }

    fun install(ctx: Context) {
        val f = File(ctx.filesDir, "last_crash.txt"); crashFile = f
        if (f.exists()) {
            errors++
            add("=== PREVIOUS RUN CRASHED ===")
            f.readText().lines().take(14).forEach { add(it.take(160)) }
            f.delete()
        }
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { th, e ->
            try {
                val sb = StringBuilder("thread ${th.name}\n$e\n")
                e.stackTrace.take(10).forEach { sb.append("  at $it\n") }
                e.cause?.let { sb.append("cause: $it\n"); it.stackTrace.take(6).forEach { s -> sb.append("  at $s\n") } }
                sb.append("--- last log ---\n"); snapshot().takeLast(12).forEach { sb.append(it).append('\n') }
                f.writeText(sb.toString())
            } catch (_: Throwable) {}
            prev?.uncaughtException(th, e)
        }
    }
}
