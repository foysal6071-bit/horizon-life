package com.horizonlife.gl

import android.opengl.GLES30
import com.horizonlife.game.World
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executors
import kotlin.math.*

/**
 * Streams the island as 128 m chunks (32x32 cells of 4 m) around the camera. Heights/colours/normals are computed
 * on a worker thread from the ported World functions; only the GL upload happens on the render thread.
 */
class Terrain {
    companion object {
        const val CH = 128.0; const val N = 32; const val STEP = CH / N; val RAD get() = ceil(com.horizonlife.game.Settings.renderDist / CH).toInt().coerceIn(3, 6)
        private fun hex(v: Int) = doubleArrayOf((v shr 16 and 255) / 255.0, (v shr 8 and 255) / 255.0, (v and 255) / 255.0)
        private val C1 = hex(0x5b7a3b); private val C2 = hex(0x86994e); private val DRY = hex(0xa09a5c); private val DARK = hex(0x44592f)
        private val BED = hex(0x8a7a55); private val WET = hex(0x5b5a3c); private val DAMP = hex(0x4a6030); private val MUD = hex(0x6a5a3a)
        private val DIRT = hex(0x86684a); private val SAND = hex(0xfff0c4); private val WSAND = hex(0xc9b27c); private val SEA = hex(0x2c7088)
        private fun lerp(c: DoubleArray, o: DoubleArray, t: Double) { for (i in 0..2) c[i] += (o[i] - c[i]) * t }
    }

    private class Chunk(val cx: Int, val cz: Int, val trees: FloatArray) { var vao = 0; var vbo = 0; var ready = false }
    private class Built(val cx: Int, val cz: Int, val data: FloatArray, val trees: FloatArray)

    private val chunks = HashMap<Long, Chunk>()
    private val pending = HashSet<Long>()
    private val done = ConcurrentLinkedQueue<Built>()
    private val pool = Executors.newFixedThreadPool(2) { r -> Thread(r, "terrain").apply { isDaemon = true; priority = Thread.MIN_PRIORITY } }
    private var ebo = 0
    private var nIdx = 0
    private fun key(cx: Int, cz: Int) = (cx.toLong() shl 32) xor (cz.toLong() and 0xffffffffL)

    fun init() {
        chunks.clear(); pending.clear(); done.clear()
        val idx = ShortArray(N * N * 6); var k = 0; val W = N + 1
        for (j in 0 until N) for (i in 0 until N) {
            val a = j * W + i; val b = a + 1; val c = a + W; val d = c + 1
            // CCW seen from above (+Y)
            idx[k++] = a.toShort(); idx[k++] = c.toShort(); idx[k++] = b.toShort()
            idx[k++] = b.toShort(); idx[k++] = c.toShort(); idx[k++] = d.toShort()
        }
        nIdx = idx.size
        val e = IntArray(1); GLES30.glGenBuffers(1, e, 0); ebo = e[0]
        val sb: ShortBuffer = ByteBuffer.allocateDirect(idx.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer().put(idx).also { it.position(0) }
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, ebo)
        GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, idx.size * 2, sb, GLES30.GL_STATIC_DRAW)
    }

    /** call once per frame on the GL thread, before draw() */
    fun update(camX: Double, camZ: Double) {
        val ccx = floor(camX / CH).toInt(); val ccz = floor(camZ / CH).toInt()
        // drop far chunks
        val it = chunks.entries.iterator()
        while (it.hasNext()) {
            val c = it.next().value
            if (abs(c.cx - ccx) > RAD + 1 || abs(c.cz - ccz) > RAD + 1) {
                if (c.ready) { GLES30.glDeleteVertexArrays(1, intArrayOf(c.vao), 0); GLES30.glDeleteBuffers(1, intArrayOf(c.vbo), 0) }
                it.remove()
            }
        }
        // request missing ones, nearest first (only while the queue is short)
        if (pending.size < 6) {
            val want = ArrayList<IntArray>()
            for (dz in -RAD..RAD) for (dx in -RAD..RAD) {
                val cx = ccx + dx; val cz = ccz + dz
                if (!chunks.containsKey(key(cx, cz)) && !pending.contains(key(cx, cz))) want.add(intArrayOf(cx, cz))
            }
            want.sortBy { (it[0] - ccx) * (it[0] - ccx) + (it[1] - ccz) * (it[1] - ccz) }
            for (w in want) {
                if (pending.size >= 6) break
                val cx = w[0]; val cz = w[1]; pending.add(key(cx, cz))
                pool.execute { done.add(Built(cx, cz, build(cx, cz), plantTrees(cx, cz))) }
            }
        }
        // upload up to 2 per frame
        var up = 0
        while (up < 2) {
            val b = done.poll() ?: break
            pending.remove(key(b.cx, b.cz))
            if (abs(b.cx - ccx) > RAD + 1 || abs(b.cz - ccz) > RAD + 1) continue
            val c = Chunk(b.cx, b.cz, b.trees)
            val ids = IntArray(1)
            GLES30.glGenVertexArrays(1, ids, 0); c.vao = ids[0]; GLES30.glBindVertexArray(c.vao)
            GLES30.glGenBuffers(1, ids, 0); c.vbo = ids[0]; GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, c.vbo)
            val fb: FloatBuffer = ByteBuffer.allocateDirect(b.data.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(b.data).also { it.position(0) }
            GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, b.data.size * 4, fb, GLES30.GL_STATIC_DRAW)
            for (a in 0..2) { GLES30.glEnableVertexAttribArray(a); GLES30.glVertexAttribPointer(a, 3, GLES30.GL_FLOAT, false, 36, a * 12) }
            GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, ebo)
            c.ready = true; chunks[key(b.cx, b.cz)] = c; up++
        }
        GLES30.glBindVertexArray(0)
    }

    fun stats() = "chunks ${chunks.count { it.value.ready }} ready, ${pending.size} pending, ${done.size} queued"

    /** x,y,z,scale,rot of every tree in the loaded chunks */
    fun treeLists(): List<FloatArray> = chunks.values.filter { it.ready && it.trees.isNotEmpty() }.map { it.trees }

    /** x,y,z,scale,rot per tree: deterministic scatter shared with the collision code (game/TreeField.kt) */
    private fun plantTrees(cx: Int, cz: Int): FloatArray { com.horizonlife.game.Scatter.chunk(cx, cz); return com.horizonlife.game.TreeField.chunk(cx, cz) }   // also warms bushes / rocks / grass on the worker thread

    fun draw() {
        for (c in chunks.values) { GLES30.glBindVertexArray(c.vao); GLES30.glDrawElements(GLES30.GL_TRIANGLES, nIdx, GLES30.GL_UNSIGNED_SHORT, 0) }
        GLES30.glBindVertexArray(0)
    }

    /** vertices: pos(3) colour(3) normal(3) */
    private fun build(cx: Int, cz: Int): FloatArray {
        val W = N + 1; val B = N + 3   // height grid with a 1-cell border for normals
        val ox = cx * CH; val oz = cz * CH
        val h = DoubleArray(B * B)
        for (j in 0 until B) for (i in 0 until B) h[j * B + i] = World.height(ox + (i - 1) * STEP, oz + (j - 1) * STEP)
        val out = FloatArray(W * W * 9); var o = 0
        val col = DoubleArray(3)
        for (j in 0 until W) for (i in 0 until W) {
            val x = ox + i * STEP; val z = oz + j * STEP; val hh = h[(j + 1) * B + (i + 1)]
            val hx = h[(j + 1) * B + (i + 2)] - h[(j + 1) * B + i]; val hz = h[(j + 2) * B + (i + 1)] - h[j * B + (i + 1)]
            val nl = sqrt(hx * hx + 4 * STEP * STEP + hz * hz)
            color(x, z, hh, col)
            out[o++] = x.toFloat(); out[o++] = hh.toFloat(); out[o++] = z.toFloat()
            out[o++] = col[0].toFloat(); out[o++] = col[1].toFloat(); out[o++] = col[2].toFloat()
            out[o++] = (-hx / nl).toFloat(); out[o++] = (2 * STEP / nl).toFloat(); out[o++] = (-hz / nl).toFloat()
        }
        return out
    }

    /** simplified port of the JS ground vertex-colour block */
    private fun color(x: Double, z: Double, h: Double, c: DoubleArray) {
        val t = ((sin(x * 0.05) + cos(z * 0.07)) * 0.25 + sin(x * 0.17 + z * 0.11) * 0.15 + sin(x * 0.011 - z * 0.013) * 0.25 + 0.5)
            .coerceIn(0.0, 1.0) + (World.fNoise(x / 2.3, z / 2.3) - 0.5) * 0.12
        for (k in 0..2) c[k] = C1[k]; lerp(c, C2, t.coerceIn(0.0, 1.0))
        val dn = sin(x * 0.007 + 1.3) * cos(z * 0.006 - 0.7) + sin(x * 0.021 + z * 0.017) * 0.4
        if (dn > 0.35) lerp(c, DRY, min((dn - 0.35) * 0.5, 0.22)) else if (dn < -0.5) lerp(c, DARK, min((-0.5 - dn) * 0.7, 0.5))
        val rd = abs(World.riverSd(x, z))
        if (rd < 46) { lerp(c, DAMP, (1 - World.sstep(22.0, 46.0, rd)) * 0.28); lerp(c, MUD, (1 - World.sstep(21.0, 31.0, rd)) * 0.42) }
        if (h < -0.05) { lerp(c, WET, World.sstep(-0.1, -1.0, h) * 0.7); lerp(c, BED, World.sstep(-0.9, -2.6, h)) }
        if (com.horizonlife.game.Track.ready) {             // bare earth beside the dirt track
            val td = com.horizonlife.game.Track.dist(x, z); val T = com.horizonlife.game.Track
            if (td < T.HW + 3) lerp(c, DIRT, (1 - World.sstep(T.HW - 1.5, T.HW + 3, td)) * 0.75)
        }
        val cd = World.coastDist(x, z)
        if (cd > -52) {
            lerp(c, SAND, World.sstep(-52.0, -40.0, cd) * 0.95)
            if (h < -0.15) lerp(c, WSAND, World.sstep(-0.15, -1.1, h))
            if (h < -1.3) lerp(c, SEA, World.sstep(-1.3, -6.0, h))
        }
    }
}
