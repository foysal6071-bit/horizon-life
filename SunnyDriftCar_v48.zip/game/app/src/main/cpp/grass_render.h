// Sunny Drift - real 3D grass: thousands of small curved blades (tufts of 5) standing on the meadow around the camera, swaying in the wind.
//  * a ring-buffer grid of tufts (0.195 m spacing = 8x denser, ~20 m radius) follows the camera: only cells that newly come into range are computed, a few hundred per frame,
//    so there is no stall. A cell gets a tuft only where the ground is really grass (colour test on the ground colour, away from road / dirt track / sand / river / lake).
//  * one instanced draw call; the blade shape, lean and wind sway are made in the vertex shader (no per-blade CPU work)
//  * tufts fade out by shrinking with distance and are pressed lower around the car
#pragma once
#include <GLES3/gl3.h>
#include <cmath>
#include <climits>
#include <vector>
#include <algorithm>
#include "terrain.h"

namespace GrassGL {

static const int   N = 208;                // grid cells per side
static const float S = 0.195f;             // metres per cell  (window = 40.6 m): 8x as many tufts per m2 as the old 0.55 m grid (~130 blades / m2)
static const int   PER_FRAME = 2400;        // max new cells computed per frame

static GLuint gProg = 0, gVbo = 0, gVao = 0; static GLint uVP, uCam, uCar, uTime;
static std::vector<float> gData;            // N*N*8 : x, y, z, scale | r, g, b, seed
static std::vector<long> gKX, gKZ;
static bool gOk = false, gDirty = false;

static const char* VS = R"GLSL(#version 300 es
layout(location=0) in vec4 aP; layout(location=1) in vec4 aC;
uniform mat4 uVP; uniform vec3 uCam; uniform vec3 uCar; uniform float uTime;
out float vT; out vec3 vCol; out float vD; out float vW;
float h(float n){ return fract(sin(n*91.345 + 17.7)*43758.5453); }
void main(){
  if (aP.w < 0.01){ gl_Position = vec4(2.0, 2.0, 2.0, 1.0); vT = 0.0; vCol = vec3(0.0); vD = 0.0; vW = 0.0; return; }
  int b = gl_VertexID/3, k = gl_VertexID - b*3;
  float seed = aC.w*61.0 + float(b)*7.31;
  float a = h(seed)*6.2831853, rad = h(seed + 1.3)*0.16;
  vec3 base = aP.xyz + vec3(cos(a), 0.0, sin(a))*rad;
  float d = length(base.xz - uCam.xz);
  float fade = 1.0 - smoothstep(14.0, 20.0, d);                                      // far tufts shrink away
  float dc = length(base.xz - uCar.xz);
  float press = mix(0.30, 1.0, smoothstep(1.0, 2.8, dc));                            // grass is pressed down under / beside the car
  float hgt = (0.15 + 0.22*h(seed + 2.7)) * aP.w * fade * press;
  float ang = h(seed + 4.1)*3.14159265;
  vec3 side = vec3(cos(ang), 0.0, sin(ang)) * (0.014 + 0.008*h(seed + 6.2));         // half width of the blade at the root
  vec3 ld = vec3(cos(ang + 1.5708), 0.0, sin(ang + 1.5708));
  float lean = (h(seed + 5.5) - 0.5)*2.0;
  const vec2 WD = vec2(0.85, 0.53);
  float w = sin(dot(base.xz, WD)*0.6 - uTime*2.6 + h(seed)*1.5)*0.5 + sin(base.x*0.31 + base.z*0.23 - uTime*1.7)*0.5;   // -1..1: gust wave + ripple
  float t = (k == 2) ? 1.0 : 0.0;
  vec3 pos = base;
  if (k == 0) pos -= side; else if (k == 1) pos += side;
  pos.y += t*hgt - 0.03*(1.0 - t);
  pos += vec3(WD.x, 0.0, WD.y)*(w*0.5 + 0.40)*hgt*0.42*t + ld*lean*0.28*hgt*t;      // the tip bends with the wind and leans its own way
  pos.y -= t*hgt*0.06*abs(w);                                                         // a bent blade is a little lower
  vT = t; vCol = aC.rgb; vW = w; vD = length(pos - uCam);
  gl_Position = uVP*vec4(pos, 1.0);
}
)GLSL";
static const char* FS = R"GLSL(#version 300 es
precision mediump float;
in float vT; in vec3 vCol; in float vD; in float vW; out vec4 o;
void main(){
  vec3 root = vec3(0.07, 0.27, 0.04), tip = vec3(0.40, 0.74, 0.12);
  vec3 tint = clamp(vec3((vCol.r/max(vCol.g, 0.01))/0.82, 1.0, (vCol.b/max(vCol.g, 0.01))/0.50), 0.7, 1.4);
  vec3 c = mix(root, tip, vT) * tint * clamp(vCol.g/0.64, 0.6, 1.3);
  c *= 0.62 + 0.55*mix(0.6, 1.0, vT);                                               // darker in the depth of the lawn, sunlit tips
  c += vec3(0.10, 0.12, 0.02) * max(vW, 0.0) * vT;                                  // gust: tips catch a little more light
  float fog = 1.0 - exp(-pow(vD/2850.0, 1.35));
  c = mix(c, vec3(0.70, 0.88, 0.97), clamp(fog, 0.0, 1.0));
  o = vec4(c, 1.0);
}
)GLSL";

static inline float hash2(long a, long b, int s){ unsigned x = (unsigned)(a*374761393L + b*668265263L + s*2246822519L); x = (x ^ (x >> 13)) * 1274126177u; x ^= x >> 16; return (x & 0xFFFFFF) / 16777216.f; }
static inline float ss(float a, float b, float x){ x = std::min(1.f, std::max(0.f, (x - a) / (b - a))); return x*x*(3 - 2*x); }

static void init(){
    gData.assign((size_t)N*N*8, 0.f); gKX.assign((size_t)N*N, LONG_MIN); gKZ.assign((size_t)N*N, LONG_MIN);
    GLuint v = glCreateShader(GL_VERTEX_SHADER), f = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(v, 1, &VS, nullptr); glCompileShader(v); glShaderSource(f, 1, &FS, nullptr); glCompileShader(f);
    gProg = glCreateProgram(); glAttachShader(gProg, v); glAttachShader(gProg, f); glLinkProgram(gProg);
    GLint ok = 0; glGetProgramiv(gProg, GL_LINK_STATUS, &ok); if (!ok){ gOk = false; return; }
    uVP = glGetUniformLocation(gProg, "uVP"); uCam = glGetUniformLocation(gProg, "uCam"); uCar = glGetUniformLocation(gProg, "uCar"); uTime = glGetUniformLocation(gProg, "uTime");
    glGenVertexArrays(1, &gVao); glBindVertexArray(gVao);
    glGenBuffers(1, &gVbo); glBindBuffer(GL_ARRAY_BUFFER, gVbo); glBufferData(GL_ARRAY_BUFFER, gData.size()*4, gData.data(), GL_DYNAMIC_DRAW);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 32, (void*)0); glVertexAttribDivisor(0, 1);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 32, (void*)16); glVertexAttribDivisor(1, 1);
    glBindVertexArray(0); gOk = true;
}

// one cell: where its tuft stands, how big it is (0 = no grass here) and the ground colour under it
static void compute(long cx, long cz, float* o){
    const double x = (cx + 0.1 + 0.8*hash2(cx, cz, 1)) * S, z = (cz + 0.1 + 0.8*hash2(cx, cz, 2)) * S;
    o[0] = (float)x; o[2] = (float)z; o[1] = 0; o[3] = 0; o[4] = o[5] = o[6] = 0; o[7] = hash2(cx, cz, 3);
    const float cl = Road::clearance((float)x, (float)z); if (cl < 1.6f) return;                 // road + verge
    if (Terrain::gLake.on && Terrain::lakeDn(x, z) < 1.15) return;                                 // lake + beach
    if (River::groundH(x, z) < -0.10) return;                                                      // river bed
    double r = 0.441, g = 0.539, b = 0.269; Terrain::grassColor(x, z, Terrain::fieldH(x, z), r, g, b);
    const float gk = ss(1.04f, 1.14f, (float)(g / std::max(r, 0.01))) * (g > b * 1.5 ? 1.f : 0.f);   // sand, dirt, rock and snow are not green
    if (gk <= 0.f) return;
    o[3] = gk * ss(1.6f, 4.0f, cl) * (0.75f + 0.5f * hash2(cx, cz, 4));
    o[1] = (float)Terrain::meshH(x, z); o[4] = (float)r; o[5] = (float)g; o[6] = (float)b;
}

static void update(const float* eye){
    if (!gOk) return;
    const long ccx = (long)std::floor(eye[0] / S), ccz = (long)std::floor(eye[2] / S), x0 = ccx - N/2, z0 = ccz - N/2; int budget = PER_FRAME;
    for (int j = 0; j < N; j++){
        const long cz = z0 + (((j - z0) % N) + N) % N;
        for (int i = 0; i < N; i++){
            const long cx = x0 + (((i - x0) % N) + N) % N; const size_t s = (size_t)j*N + i;
            if (gKX[s] == cx && gKZ[s] == cz) continue;
            if (budget <= 0) { if (gKX[s] == LONG_MIN) continue; gData[s*8+3] = 0; continue; }       // out of budget: hide the stale tuft until its turn
            compute(cx, cz, &gData[s*8]); gKX[s] = cx; gKZ[s] = cz; budget--; gDirty = true;
        }
    }
}

static void draw(const float* VP, const float* eye, const float* car, float tSec){
    if (!gOk) return;
    update(eye);
    // only tufts that exist and are inside the view are sent to the GPU (8x more tufts than before, so this keeps the draw cheap)
    float pl[5][4];
    for (int i = 0; i < 5; i++){ const int a = i >> 1; const float sg = (i & 1) ? 1.f : -1.f;
        for (int j = 0; j < 4; j++) pl[i][j] = VP[j*4 + 3] + sg * VP[j*4 + a];
        const float l = std::sqrt(pl[i][0]*pl[i][0] + pl[i][1]*pl[i][1] + pl[i][2]*pl[i][2]); if (l > 1e-6f) for (int j = 0; j < 4; j++) pl[i][j] /= l; }
    static std::vector<float> vis; vis.clear(); vis.reserve((size_t)N*N*3);
    for (size_t s = 0; s < (size_t)N*N; s++){
        const float* d = &gData[s*8]; if (d[3] < 0.01f) continue;
        bool out = false; const float cy = d[1] + 0.2f;
        for (int i = 0; i < 5 && !out; i++) if (pl[i][0]*d[0] + pl[i][1]*cy + pl[i][2]*d[2] + pl[i][3] < -0.6f) out = true;
        if (out) continue;
        vis.insert(vis.end(), d, d + 8);
    }
    const int cnt = (int)(vis.size() / 8); if (!cnt) return;
    glBindVertexArray(gVao); glBindBuffer(GL_ARRAY_BUFFER, gVbo); glBufferData(GL_ARRAY_BUFFER, vis.size()*4, vis.data(), GL_STREAM_DRAW);
    glEnable(GL_DEPTH_TEST); glDepthMask(GL_TRUE); glDisable(GL_BLEND); glDisable(GL_CULL_FACE);
    glUseProgram(gProg); glUniformMatrix4fv(uVP, 1, GL_FALSE, VP); glUniform3fv(uCam, 1, eye); glUniform3fv(uCar, 1, car); glUniform1f(uTime, tSec);
    glDrawArraysInstanced(GL_TRIANGLES, 0, 15, cnt);
    glBindVertexArray(0);
}

}   // namespace GrassGL
