// Sunny Drift - Audi R8 look + animation: C++ / OpenGL ES 3 port of buildCarR8() and the car part of animate() in the HTML game.
//  * every R8 material group gets the HTML material (clear-coated white paint, chrome, aluminium, tyres, calipers, interior,
//    transparent glass, head / tail light emissives) shaded with a PBR-style shader: sun + hemisphere + ambient light and the
//    HTML "carEnv" sky reflection (analytic: gradient sky, sun disc, two soft boxes), ACES filmic tone mapping at exposure 1.4
//  * the 4 wheels are separate parts: they roll with the road speed, the two front ones steer, the brake calipers only steer,
//    and a tyre that would sink into the ground (body squat / dive / roll) is lifted into its arch
//  * body roll / pitch are damped springs driven by cornering and braking (susp in the HTML)
//  * tail lights react to braking / reversing, soft brake-light halo and the soft contact shadow under the car
#pragma once
#include <GLES3/gl3.h>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <sstream>
#include <string>
#include <vector>
#include "car_core.h"
#include "env_glsl.h"

namespace CarGL {

// ---------------- model constants (HTML buildCarR8) ----------------
static const int    WH0 = 54432, WHN = 24570, NEON0 = 152712;   // wheel index ranges inside the model, neon under-glow is not drawn
static const double CAR_S = 2.8 / 2643.1, CAR_ZC = -104.45;
static const float  CAR_WHEEL_R = 0.3318f;                      // tyre radius after scaling (m)

// ---------------- suspension / wheel / light state ----------------
static double suspRoll = 0, suspRollV = 0, suspPitch = 0, suspPitchV = 0, suspHeave = 0, suspHeaveV = 0; static bool lastAir = false;   // heave = body height offset (m): aero squat, cornering compression, landing bounce
static double spinF = 0, spinR = 0, brakeK = 0; static bool lastRev = false;
static double brakeHeat[4] = {0, 0, 0, 0};                      // 0..1.2 disc temperature (game wheel order: front A, front B, rear A, rear B)
static inline float discGlow(int i){ float x = (float)((brakeHeat[i] - 0.30) / 0.70); x = x < 0.f ? 0.f : (x > 1.f ? 1.f : x); return x * x * (3.f - 2.f * x); }
static float  wheelComp[4] = {0, 0, 0, 0};

struct Mat {
    float col[3]; float emis[3];
    float metal, rough, clear, clearRough, envI, alpha;
    int kind;                       // 0 normal, 1 tail light (animated), 2 head light
    bool transparent;
};
struct Item { int start, count, mat, tgt, disc; };   // disc: 0 = no, else 1 + game wheel index of the brake disc    // tgt: 0 body, 1..4 wheel i (spinning part), 5..8 wheel i (brake caliper, steers only)

static float gMM[9][16], gMV[9][16];     // matrices of the last draw (body, 4 x tyre+rim, 4 x caliper)
static std::vector<Mat> gMats; static std::vector<Item> gItems;
static GLuint gVBO = 0, gIBO = 0, gProg = 0, gQuadVBO = 0, gQuadProg = 0;
static GLint uMVP, uModel, uCam, uCol, uEmis, uMR, uEnvA, uNight;
static GLint qMVP, qKind, qOp;
static float wC[4][3];              // wheel centres in the model frame (x forward, y up, z = -raw x), game order: front A, front B, rear A, rear B

static inline float lin(double c){ return (float)std::pow(c / 255.0, 2.2); }        // sRGB 0..255 -> linear (three.js Color(hex))
static void hexLin(unsigned hx, float* o){ o[0] = lin((hx >> 16) & 255); o[1] = lin((hx >> 8) & 255); o[2] = lin(hx & 255); }

// material table exactly like matFor() in the HTML
static Mat makeMat(const std::string& name, unsigned c, int em, double a){
    Mat m = {}; hexLin(c, m.col); m.metal = 0; m.rough = 1; m.clear = 0; m.clearRough = 0; m.envI = 0; m.alpha = 1; m.kind = 0; m.transparent = false;
    if (em == 1){
        if (name == "light"){ m.kind = 2; hexLin(0xf2f9ff, m.col); hexLin(0xdff0ff, m.emis); for (int i = 0; i < 3; i++) m.emis[i] *= 2.2f; m.rough = 1; }
        else { m.kind = 1; hexLin(0xff2a2a, m.col); hexLin(0xff0c0c, m.emis); for (int i = 0; i < 3; i++) m.emis[i] *= 1.5f; m.rough = 0.25f; }
        return m;
    }
    if (a < 1){ m.metal = 0.35f; m.rough = 0.03f; m.envI = 2.0f; m.alpha = (float)std::min(0.9, a * 1.5); m.transparent = true; return m; }
    auto P = [&](float me, float ro, float cl, float cr, float ei){ m.metal = me; m.rough = ro; m.clear = cl; m.clearRough = cr; m.envI = ei; };
    if (name == "body_color"){ hexLin(0xf3f4f6, m.col); P(0.28f, 0.14f, 1, 0.02f, 1.5f); }
    else if (name == "black_gloss" || name == "trim") P(0.3f, 0.16f, 1, 0.05f, 1.2f);
    else if (name == "black_matt" || name == "tail_light_red_2" || name == "tail_light_red_3") P(0.5f, 0.35f, 1, 0.05f, 1.1f);
    else if (name == "rims_1") P(0.9f, 0.22f, 1, 0.04f, 1.6f);
    else if (name == "chrome") P(1, 0.12f, 0, 0, 1.3f);
    else if (name == "Aluminium_1" || name == "Aluminum_2") P(1, 0.3f, 0, 0, 1.2f);
    else if (name == "grille") P(0.7f, 0.45f, 0, 0, 0.8f);
    else if (name == "metal_1") P(0.2f, 0.28f, 0, 0, 1.0f);              // red brake calipers
    else if (name == "interior_1" || name == "interior_2" || name == "interior_roof") P(0, 0.85f, 0, 0, 0.3f);
    else if (name == "tyre") P(0, 0.92f, 0, 0, 0.25f);
    else P(0.3f, 0.55f, 0, 0, 0.6f);
    return m;
}

// ---------------- 4x4 helpers (column-major) ----------------
typedef float M4[16];
static void mIdent(M4 m){ memset(m, 0, 64); m[0] = m[5] = m[10] = m[15] = 1; }
static void mMul(M4 o, const M4 a, const M4 b){
    M4 t; for (int c = 0; c < 4; c++) for (int r = 0; r < 4; r++){ float s = 0; for (int k = 0; k < 4; k++) s += a[k*4+r] * b[c*4+k]; t[c*4+r] = s; }
    memcpy(o, t, 64);
}
static void mT(M4 m, float x, float y, float z){ mIdent(m); m[12] = x; m[13] = y; m[14] = z; }
static void mRY(M4 m, float a){ mIdent(m); float c = cosf(a), s = sinf(a); m[0] = c; m[2] = -s; m[8] = s; m[10] = c; }
static void mRZ(M4 m, float a){ mIdent(m); float c = cosf(a), s = sinf(a); m[0] = c; m[1] = s; m[4] = -s; m[5] = c; }

// ---------------- shaders ----------------
static const char* CAR_VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in vec3 n;
uniform mat4 uMVP, uModel; out vec3 vn; out vec3 wp;
void main(){ vn = mat3(uModel)*n; wp = (uModel*vec4(p,1.0)).xyz; gl_Position = uMVP*vec4(p,1.0); }
)GLSL";

static const char* CAR_FS = R"GLSL(#version 300 es
precision highp float;
in vec3 vn; in vec3 wp;
uniform vec3 uCam, uCol, uEmis;
uniform vec4 uMR;      // metalness, roughness, clearcoat, clearcoat roughness
uniform vec2 uEnvA;    // env map intensity, opacity
uniform float uNight;
out vec4 o;
const float PI = 3.14159265;
)GLSL" ENV_GLSL R"GLSL(

float D_GGX(float a2, float NoH){ float d = NoH*NoH*(a2 - 1.0) + 1.0; return a2/(PI*d*d); }
float V_SmithCorr(float a2, float NoL, float NoV){
  float gv = NoL*sqrt(a2 + (1.0 - a2)*NoV*NoV), gl = NoV*sqrt(a2 + (1.0 - a2)*NoL*NoL); return 0.5/max(gv + gl, 1e-5);
}
vec3 aces(vec3 c, float ex){
  c *= ex/0.6;
  mat3 I = mat3(vec3(0.59719,0.07600,0.02840), vec3(0.35458,0.90834,0.13383), vec3(0.04823,0.01566,0.83777));
  mat3 O = mat3(vec3(1.60475,-0.10208,-0.00327), vec3(-0.53108,1.10813,-0.07276), vec3(-0.07367,-0.00605,1.07602));
  c = I*c; vec3 a = c*(c + 0.0245786) - 0.000090537, b = c*(0.983729*c + 0.4329510) + 0.238081; c = O*(a/b);
  return clamp(c, 0.0, 1.0);
}
void main(){
  vec3 V = normalize(uCam - wp), N = normalize(vn);
  if (dot(N, V) < 0.0) N = -N;                                  // double sided
  float NoV = clamp(dot(N, V), 1e-3, 1.0);
  float metal = uMR.x, rough = clamp(uMR.y, 0.06, 1.0), cc = uMR.z, ccr = max(uMR.w, 0.06), envI = uEnvA.x;
  vec3 alb = uCol*(1.0 - metal), F0 = mix(vec3(0.04), uCol, metal);
  float a = rough*rough, a2 = a*a;
  // lights: sun (DirectionalLight 3.0), hemisphere (day 1.35), ambient 0.45
  vec3 Ls = normalize(vec3(0.4,0.8,0.3)), Lc = L2(vec3(1.0,0.965,0.878))*3.0;
  float NoL = max(dot(N, Ls), 0.0); vec3 H = normalize(Ls + V); float NoH = max(dot(N, H), 0.0), VoH = max(dot(V, H), 0.0);
  vec3 F = F0 + (1.0 - F0)*pow(1.0 - VoH, 5.0);
  vec3 dirSpec = F*D_GGX(a2, NoH)*V_SmithCorr(a2, NoL, NoV);
  vec3 col = (alb/PI + dirSpec)*Lc*NoL;
  float ac = ccr*ccr, ac2 = ac*ac; float Fc = 0.04 + 0.96*pow(1.0 - VoH, 5.0);
  vec3 ccDir = vec3(Fc*D_GGX(ac2, NoH)*V_SmithCorr(ac2, NoL, NoV))*Lc*NoL;
  vec3 hemi = mix(L2(vec3(0.416,0.612,0.345)), L2(vec3(0.847,0.937,1.0)), 0.5 + 0.5*N.y)*(0.5 + 0.85) + vec3(0.45);
  float ao = mix(0.45, 1.0, smoothstep(-0.55, 0.35, N.y));      // underside / sill / arch occlusion: surfaces facing the road get less sky light
  col += alb*hemi/PI*ao;
  // image based lighting from the car environment
  vec3 Lcos = envC(N, 1.0) + vec3(14.0,12.0,9.0)*0.0443/PI*max(dot(N, normalize(vec3(40.0,45.0,30.0))), 0.0);
  col += alb*Lcos*envI*ao;
  vec3 R = reflect(-V, N);
  vec2 ab = envBRDF(rough, NoV);
  float so = mix(0.30, 1.0, smoothstep(-0.35, 0.15, R.y));       // reflections pointing into the road are shadowed by the car itself
  vec3 spec = envC(R, rough)*envI*(F0*ab.x + ab.y)*so;
  if (cc > 0.0){
    vec2 abc = envBRDF(ccr, NoV); float Fcc = 0.04*abc.x + abc.y;
    float Fn = 0.04 + 0.96*pow(1.0 - NoV, 5.0);
    col = col*(1.0 - cc*Fn) + ccDir*cc; spec = spec*(1.0 - cc*Fn);
    spec += envC(R, ccr)*envI*Fcc*cc*so;
  }
  col += spec + uEmis;
  col = aces(col, 1.4 + 0.3*uNight);
  col = pow(col, vec3(1.0/2.2));
  col = mix(col, vec3(0.62,0.80,0.95), clamp(length(uCam - wp)/3750.0, 0.0, 1.0));   // same haze as the rest of this project
  float al = uEnvA.y; if (al < 0.999) al = mix(al, 1.0, pow(1.0 - NoV, 3.0)*0.6);   // glass is more opaque / reflective at grazing angles (Fresnel)
  o = vec4(col, al);
}
)GLSL";

// soft quads (contact shadow, brake-light halo): position in the car model frame, uv in 0..1
static const char* Q_VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in vec2 uv;
uniform mat4 uMVP; out vec2 vUv;
void main(){ vUv = uv; gl_Position = uMVP*vec4(p,1.0); }
)GLSL";
static const char* Q_FS = R"GLSL(#version 300 es
precision mediump float;
in vec2 vUv; uniform int uKind; uniform float uOp; out vec4 o;
void main(){
  vec2 q = vUv*2.0 - 1.0;
  if (uKind == 0){                                   // contact shadow: dark blob, tighter dark core (canvas 256x128 radial gradient)
    float r = length(vec2(q.y, q.x*0.5))*1.016;    // u runs along the car, v across it
    float a = r < 0.048 ? 0.78 : (r < 0.55 ? mix(0.78, 0.42, (r - 0.048)/0.502) : mix(0.42, 0.0, clamp((r - 0.55)/0.45, 0.0, 1.0)));
    o = vec4(0.0, 0.0, 0.0, a);
  } else if (uKind == 2){                            // hot brake disc: soft orange glow (additive)
    float r = length(q); float a = clamp(1.0 - r, 0.0, 1.0); a = a*a*(0.55 + 0.9*a);
    o = vec4(1.0, 0.36 + 0.22*a, 0.06 + 0.12*a, a*uOp);
  } else {                                           // brake-light halo: red radial glow (additive)
    float r = length(vec2(q.x, q.y*0.5));
    float a = r < 0.016 ? 0.9 : (r < 0.4 ? mix(0.9, 0.35, (r - 0.016)/0.384) : mix(0.35, 0.0, clamp((r - 0.4)/0.6, 0.0, 1.0)));
    o = vec4(1.0, 0.235, 0.196, a*uOp);
  }
}
)GLSL";

static GLuint comp(GLenum t, const char* s){
    GLuint sh = glCreateShader(t); glShaderSource(sh, 1, &s, nullptr); glCompileShader(sh); return sh;
}
static GLuint prog(const char* vs, const char* fs){
    GLuint p = glCreateProgram(); glAttachShader(p, comp(GL_VERTEX_SHADER, vs)); glAttachShader(p, comp(GL_FRAGMENT_SHADER, fs)); glLinkProgram(p); return p;
}

// ---------------- init: raw model (r8.bin) + header (r8_meta.txt) + material groups (r8_groups.txt) ----------------
static void init(const std::vector<char>& raw, const std::vector<char>& meta, const std::vector<char>& groups){
    std::istringstream mf(std::string(meta.begin(), meta.end()));
    int n, ni; double mn[3], sz[3]; mf >> n >> ni >> mn[0] >> mn[1] >> mn[2] >> sz[0] >> sz[1] >> sz[2];
    const uint16_t* pos = (const uint16_t*)raw.data();
    const int8_t*   nor = (const int8_t*)(raw.data() + n * 6);
    const uint16_t* idx = (const uint16_t*)(raw.data() + n * 10);
    std::vector<float> vb(n * 6);
    for (int i = 0; i < n; i++){
        double rx = mn[0] + pos[i*3]   / 65535.0 * sz[0], ry = mn[1] + pos[i*3+1] / 65535.0 * sz[1], rz = mn[2] + pos[i*3+2] / 65535.0 * sz[2];
        vb[i*6] = (float)((rz - CAR_ZC) * CAR_S); vb[i*6+1] = (float)(ry * CAR_S); vb[i*6+2] = (float)(-rx * CAR_S);
        double nx = nor[i*4] / 127.0, ny = nor[i*4+1] / 127.0, nz = nor[i*4+2] / 127.0, l = std::sqrt(nx*nx + ny*ny + nz*nz); if (l == 0) l = 1;
        vb[i*6+3] = (float)(nz / l); vb[i*6+4] = (float)(ny / l); vb[i*6+5] = (float)(-nx / l);
    }
    glGenBuffers(1, &gVBO); glBindBuffer(GL_ARRAY_BUFFER, gVBO); glBufferData(GL_ARRAY_BUFFER, vb.size() * 4, vb.data(), GL_STATIC_DRAW);
    glGenBuffers(1, &gIBO); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gIBO); glBufferData(GL_ELEMENT_ARRAY_BUFFER, ni * 2, idx, GL_STATIC_DRAW);

    // wheel centres = middle of each wheel's bounding box (raw wheel 0 / 2 = front, 1 / 3 = rear -> game order 0,2,1,3)
    static const int ORDER[4] = {0, 2, 1, 3};
    for (int gi = 0; gi < 4; gi++){
        const int wi = ORDER[gi]; float lo[3] = {1e9f, 1e9f, 1e9f}, hi[3] = {-1e9f, -1e9f, -1e9f};
        for (int i = WH0 + wi * WHN; i < WH0 + (wi + 1) * WHN; i++) for (int k = 0; k < 3; k++){
            float v = vb[idx[i] * 6 + k]; lo[k] = std::min(lo[k], v); hi[k] = std::max(hi[k], v); }
        for (int k = 0; k < 3; k++) wC[gi][k] = (lo[k] + hi[k]) / 2;
    }

    // material groups
    std::istringstream gf(std::string(groups.begin(), groups.end())); std::string name, col;
    int s, c, em; double al;
    while (gf >> name >> s >> c >> col >> em >> al){
        if (c == 0 || s >= NEON0 || em == 2) continue;
        unsigned hx = 0x808080; sscanf(col.c_str(), "#%x", &hx);
        gMats.push_back(makeMat(name, hx, em, al)); const int mi = (int)gMats.size() - 1;
        int tgt = 0, disc = 0;
        if (s >= WH0){
            const int wi = (s - WH0) / WHN, off = s - WH0 - wi * WHN; int gi = 0; for (int k = 0; k < 4; k++) if (ORDER[k] == wi) gi = k;
            tgt = (off >= 666 && off < 1944 ? 5 : 1) + gi;
            if (off == 0 && name == "metal_2") disc = gi + 1;                      // the brake disc: first group of every wheel (steers, does not spin)
            if (disc) tgt = 5 + gi;
        }
        gItems.push_back({s, c, mi, tgt, disc});
    }

    gProg = prog(CAR_VS, CAR_FS);
    uMVP = glGetUniformLocation(gProg, "uMVP"); uModel = glGetUniformLocation(gProg, "uModel"); uCam = glGetUniformLocation(gProg, "uCam");
    uCol = glGetUniformLocation(gProg, "uCol"); uEmis = glGetUniformLocation(gProg, "uEmis"); uMR = glGetUniformLocation(gProg, "uMR");
    uEnvA = glGetUniformLocation(gProg, "uEnvA"); uNight = glGetUniformLocation(gProg, "uNight");
    gQuadProg = prog(Q_VS, Q_FS); qMVP = glGetUniformLocation(gQuadProg, "uMVP"); qKind = glGetUniformLocation(gQuadProg, "uKind"); qOp = glGetUniformLocation(gQuadProg, "uOp");
    // quads: [0..5] contact shadow 5.6 m x 2.5 m at y = 0.015, [6..11] brake-light halo 1.9 m x 0.42 m behind the LED bar
    const float tailX = (float)((-2111 - CAR_ZC) * CAR_S) - 0.08f;
    std::vector<float> qv = {
        -2.8f,0.015f,-1.25f,0,0,  2.8f,0.015f,-1.25f,1,0,  -2.8f,0.015f,1.25f,0,1,   2.8f,0.015f,-1.25f,1,0,  2.8f,0.015f,1.25f,1,1,  -2.8f,0.015f,1.25f,0,1,
        tailX,0.72f-0.21f,-0.95f,0,0, tailX,0.72f-0.21f,0.95f,1,0, tailX,0.72f+0.21f,-0.95f,0,1,  tailX,0.72f-0.21f,0.95f,1,0, tailX,0.72f+0.21f,0.95f,1,1, tailX,0.72f+0.21f,-0.95f,0,1 };
    // [12 + 12*i ..] hot-disc glow of wheel i (game order): 6 vertices a soft quad just outside the rim (side view) + 6 behind the wheel (rear view)
    for (int i = 0; i < 4; i++){
        const float cx = wC[i][0], cy = wC[i][1], cz = wC[i][2], sg = cz > 0 ? 1.f : -1.f, R = 0.30f, zo = cz + sg * 0.15f, xo = cx - 0.26f;
        const float side[] = { cx-R,cy-R,zo,0,0, cx+R,cy-R,zo,1,0, cx-R,cy+R,zo,0,1,  cx+R,cy-R,zo,1,0, cx+R,cy+R,zo,1,1, cx-R,cy+R,zo,0,1 };
        const float rear[] = { xo,cy-R,cz-R,0,0, xo,cy-R,cz+R,1,0, xo,cy+R,cz-R,0,1,  xo,cy-R,cz+R,1,0, xo,cy+R,cz+R,1,1, xo,cy+R,cz-R,0,1 };
        qv.insert(qv.end(), side, side + 30); qv.insert(qv.end(), rear, rear + 30);
    }
    glGenBuffers(1, &gQuadVBO); glBindBuffer(GL_ARRAY_BUFFER, gQuadVBO); glBufferData(GL_ARRAY_BUFFER, qv.size() * 4, qv.data(), GL_STATIC_DRAW);
}

// ---------------- per-frame animation (suspension springs, wheel spin / steer, tail lights) ----------------
//  air = the car is flying (no tyre compression); pitchS = smoothed slope pitch (HTML rampPitch); ptT = its target; tRoll / tRollT = smoothed / target cross-slope roll
static void update(const CarState& S, double dt, bool air, double pitchS, double ptT, double tRoll, double tRollT){
    {   // suspension: body leans outward in corners (roll), nose dives under braking / squats under power (pitch), damped springs
        const double W = 10, Z = 0.85;
        const double rt = clampd(S.ay * 0.0045, -0.07, 0.07), pt = clampd(-S.axS * 0.0042, -0.05, 0.06);   // ~2.6 deg / g roll, ~2.4 deg / g dive
        suspRollV  += (W*W*(rt - suspRoll)  - 2*Z*W*suspRollV)  * dt; suspRoll  += suspRollV  * dt;
        suspPitchV += (W*W*(pt - suspPitch) - 2*Z*W*suspPitchV) * dt; suspPitch += suspPitchV * dt;
    }
    {   // heave: aero downforce presses the car down at speed, hard cornering compresses it, a landing makes it bounce (under-damped spring)
        const double W = 11, Z = 0.5, vn = std::min(fabs(S.speed) / 55.0, 1.3);
        const double ht = -0.014 * vn * vn - 0.006 * std::min(fabs(S.ay) / 9.81, 1.2);
        if (lastAir && !air){ suspHeaveV -= 2.0; suspPitchV -= 0.25 * clampd(S.speed / 40.0, 0, 1.5); }
        lastAir = air;
        suspHeaveV += (W*W*(ht - suspHeave) - 2*Z*W*suspHeaveV) * dt; suspHeave += suspHeaveV * dt;
        suspHeave = clampd(suspHeave, -0.09, 0.03);
    }
    {   // wheels roll with the speed of the contact patch along the wheel; the rears slow a little in a drift
        const double sa = S.steerAngle, CG_A = Veh::LA;
        const double vF = S.speed * cos(sa) + (S.vy + CG_A * S.yaw) * sin(sa), vR = S.speed * (1 - 0.35 * S.drift) * (1 - 0.97 * S.hb) + (S.reverse ? -1.0 : 1.0) * 3.0 * S.throttle * clampd(1 - fabs(S.speed) / 14, 0, 1);   // handbrake locks the rears; a little wheelspin at launch
        spinF = fmod(spinF + clampd(vF * dt / CAR_WHEEL_R, -0.5, 0.5), 2 * M_PI);
        spinR = fmod(spinR + clampd(vR * dt / CAR_WHEEL_R, -0.5, 0.5), 2 * M_PI);
    }
    {   // no tyre may sink into the road: lift it into its arch by exactly the sunken amount
        const double sinP = sin(suspPitch - pitchS + ptT), sinR = sin(suspRoll + tRoll - tRollT);
        for (int i = 0; i < 4; i++){
            const double fF = wC[i][0], lL = -wC[i][2];
            wheelComp[i] = air ? 0.f : (float)clampd(std::max(0.0, fF * sinP - lL * sinR) + 0.003 - suspHeave, -0.05, 0.10);   // body heave moves the body, the tyre stays on the road
        }
    }
    {   // brake discs: heat up under hard braking at speed (fronts do most of the work), cool down in the air stream
        const double sp = fabs(S.speed), br = S.reverse ? 0.0 : S.brake, vk = clampd(sp / 30.0, 0, 1.4);
        for (int i = 0; i < 4; i++){
            const double gain = i < 2 ? 0.62 * br * vk : 0.38 * br * vk + 0.45 * S.hb * clampd(sp / 20.0, 0, 1);
            brakeHeat[i] = clampd(brakeHeat[i] + gain * dt - brakeHeat[i] * (0.28 + 0.012 * sp) * dt, 0, 1.2);
        }
    }
    {   // brake light: snaps on, fades off a little slower (handbrake also lights it)
        const double on = (S.braking || S.handOn) ? 1 : 0;
        brakeK += (on - brakeK) * (1 - exp(-(on ? 38 : 9) * dt));
        lastRev = S.reverse;
    }
}

// ---------------- draw ----------------
//  VP = view-projection, Mdl = car model matrix (heading / pitch / roll / position, model frame: nose +X), eye = camera position
static void draw(const float* VP, const float* Mdl, const float* eye, const CarState& S, float night = 0.f){
    float (&MM)[9][16] = gMM; float (&MV)[9][16] = gMV;                                                   // 0 body, 1..4 wheel spin parts, 5..8 calipers
    for (int i = 0; i < 9; i++){ memcpy(MM[i], Mdl, 64); }
    const float steer = (float)S.steerAngle;
    for (int i = 0; i < 4; i++){
        const float cx = wC[i][0], cy = wC[i][1], cz = wC[i][2];
        M4 T1, Ry, Rz, T0, t; mT(T1, cx, cy + wheelComp[i], cz); mT(T0, -cx, -cy, -cz);
        if (i < 2) mRY(Ry, steer); else mIdent(Ry);
        mRZ(Rz, -(float)(i < 2 ? spinF : spinR));
        mMul(t, T1, Ry); mMul(t, t, T0); mMul(MM[5 + i], Mdl, t);                       // caliper: steers only
        mMul(t, T1, Ry); mMul(t, t, Rz); mMul(t, t, T0); mMul(MM[1 + i], Mdl, t);       // tyre + rim: steers and rolls
    }
    for (int i = 0; i < 9; i++) mMul(MV[i], VP, MM[i]);

    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glDisable(GL_BLEND); glDepthMask(GL_TRUE);
    glUseProgram(gProg); glUniform3fv(uCam, 1, eye); glUniform1f(uNight, night);
    glBindBuffer(GL_ARRAY_BUFFER, gVBO); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gIBO);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 24, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 24, (void*)12);

    // tail light colours (HTML): red running light -> hot orange-white when braking, white while reversing
    const float run = 0.45f, k = (float)brakeK, strength = lastRev ? 1.6f : run + (4.4f - run) * k;
    float tailEm[3], tailCol[3];
    if (lastRev){ tailEm[0] = tailEm[1] = tailEm[2] = 1.f; tailCol[0] = tailCol[1] = tailCol[2] = 1.f; hexLin(0xffffff, tailEm); }
    else { tailEm[0] = 1.f; tailEm[1] = 0.045f + 0.17f * k; tailEm[2] = 0.03f + 0.12f * k; hexLin(0xff2a2a, tailCol); }

    for (int pass = 0; pass < 2; pass++){
        if (pass == 1){                                                                  // soft contact shadow, then the glass on top
            glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); glDepthMask(GL_FALSE);
            glUseProgram(gQuadProg); glUniform1i(qKind, 0); glUniform1f(qOp, 1.f);
            glUniformMatrix4fv(qMVP, 1, GL_FALSE, MV[0]);
            glBindBuffer(GL_ARRAY_BUFFER, gQuadVBO);
            glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 20, (void*)0);
            glEnableVertexAttribArray(1); glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 20, (void*)12);
            glEnable(GL_POLYGON_OFFSET_FILL); glPolygonOffset(-6.f, -6.f); glDrawArrays(GL_TRIANGLES, 0, 6); glDisable(GL_POLYGON_OFFSET_FILL);
            glUseProgram(gProg); glBindBuffer(GL_ARRAY_BUFFER, gVBO); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gIBO);
            glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 24, (void*)0);
            glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 24, (void*)12);
        }
        for (const Item& it : gItems){
            const Mat& m = gMats[it.mat]; if (m.transparent != (pass == 1)) continue;
            glUniformMatrix4fv(uMVP, 1, GL_FALSE, MV[it.tgt]); glUniformMatrix4fv(uModel, 1, GL_FALSE, MM[it.tgt]);
            const float* col = m.col; const float* em = m.emis; float emv[3] = {em[0], em[1], em[2]}; float cv[3] = {col[0], col[1], col[2]};
            if (m.kind == 1){ for (int i = 0; i < 3; i++){ emv[i] = tailEm[i] * strength; cv[i] = tailCol[i]; } }
            if (it.disc){ const float g = discGlow(it.disc - 1); emv[0] = 2.6f * g; emv[1] = 0.46f * g; emv[2] = 0.05f * g; }   // red-hot disc
            glUniform3fv(uCol, 1, cv); glUniform3fv(uEmis, 1, emv);
            glUniform4f(uMR, m.metal, m.rough, m.clear, m.clearRough); glUniform2f(uEnvA, m.envI, m.alpha);
            glDrawElements(GL_TRIANGLES, it.count, GL_UNSIGNED_SHORT, (void*)(intptr_t)(it.start * 2));
        }
    }
    glDepthMask(GL_TRUE); glDisable(GL_BLEND);
}

// ---------------- glow pass: after the night darkening, so the lights stay bright ----------------
//  night > 0: the head / tail light parts are drawn again on top of the dark picture; the brake-light halo is always drawn
static void drawGlow(float night){
    const float k = (float)brakeK;
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glDisable(GL_BLEND); glDepthMask(GL_TRUE);
    if (night > 0.002f){
        glDepthFunc(GL_LEQUAL);
        glUseProgram(gProg); glUniform1f(uNight, night);
        glBindBuffer(GL_ARRAY_BUFFER, gVBO); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gIBO);
        glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 24, (void*)0);
        glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 24, (void*)12);
        const float strength = lastRev ? 1.6f : 0.45f + (4.4f - 0.45f) * k;
        for (const Item& it : gItems){
            const Mat& m = gMats[it.mat]; if (m.transparent || (m.kind == 0 && !(it.disc && discGlow(it.disc - 1) > 0.01f))) continue;
            float emv[3] = {m.emis[0], m.emis[1], m.emis[2]}, cv[3] = {m.col[0], m.col[1], m.col[2]};
            if (m.kind == 1){
                if (lastRev){ hexLin(0xffffff, emv); hexLin(0xffffff, cv); for (int i = 0; i < 3; i++) emv[i] *= strength; }
                else { hexLin(0xff2a2a, cv); emv[0] = strength; emv[1] = (0.045f + 0.17f * k) * strength; emv[2] = (0.03f + 0.12f * k) * strength; }
            }
            if (it.disc){ const float g = discGlow(it.disc - 1); emv[0] = 2.6f * g; emv[1] = 0.46f * g; emv[2] = 0.05f * g; }
            glUniformMatrix4fv(uMVP, 1, GL_FALSE, gMV[it.tgt]); glUniformMatrix4fv(uModel, 1, GL_FALSE, gMM[it.tgt]);
            glUniform3fv(uCol, 1, cv); glUniform3fv(uEmis, 1, emv);
            glUniform4f(uMR, m.metal, m.rough, m.clear, m.clearRough); glUniform2f(uEnvA, m.envI, m.alpha);
            glDrawElements(GL_TRIANGLES, it.count, GL_UNSIGNED_SHORT, (void*)(intptr_t)(it.start * 2));
        }
        glDepthFunc(GL_LESS);
    }
    glEnable(GL_BLEND); glDepthMask(GL_FALSE);
    {   // brake-light halo (additive), brighter while braking
        const float rev = lastRev ? 0.f : 1.f, runOp = 0.05f * rev, op = runOp + (0.82f - runOp) * k * rev;
        glUseProgram(gQuadProg); glUniform1i(qKind, 1); glUniform1f(qOp, op);
        glUniformMatrix4fv(qMVP, 1, GL_FALSE, gMV[0]);
        glBindBuffer(GL_ARRAY_BUFFER, gQuadVBO);
        glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 20, (void*)0);
        glEnableVertexAttribArray(1); glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 20, (void*)12);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE); glDrawArrays(GL_TRIANGLES, 6, 6);
    }
    {   // hot brake discs: a soft orange glow shining out round the rim + a little spill behind the wheel
        glUseProgram(gQuadProg); glUniform1i(qKind, 2);
        glBindBuffer(GL_ARRAY_BUFFER, gQuadVBO);
        glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 20, (void*)0);
        glEnableVertexAttribArray(1); glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 20, (void*)12);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE);
        for (int i = 0; i < 4; i++){
            const float g = discGlow(i); if (g < 0.02f) continue;
            glUniformMatrix4fv(qMVP, 1, GL_FALSE, gMV[5 + i]);
            glUniform1f(qOp, 0.62f * g); glDrawArrays(GL_TRIANGLES, 12 + i * 12, 6);
            glUniform1f(qOp, 0.38f * g); glDrawArrays(GL_TRIANGLES, 18 + i * 12, 6);
        }
    }
    glDepthMask(GL_TRUE); glDisable(GL_BLEND);
}

} // namespace CarGL
