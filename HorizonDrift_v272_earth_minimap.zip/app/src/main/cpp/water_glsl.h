// Sunny Drift - shared realistic-water GLSL (river, mountain lake, ponds): non-repeating noise waves, live sky reflection, sun glitter, soft foam.
#pragma once
#include <GLES3/gl3.h>

namespace WaterEnv {
// filled every frame from the time of day (native-lib.cpp)
static float hor[3] = {.74f,.88f,.98f}, mid[3] = {.34f,.65f,.98f}, zen[3] = {.09f,.34f,.88f}, sun[3] = {.4f,.8f,.45f}, warm = 0.f;
static void apply(GLuint p){
    glUniform3fv(glGetUniformLocation(p, "uSkyH"), 1, hor); glUniform3fv(glGetUniformLocation(p, "uSkyM"), 1, mid); glUniform3fv(glGetUniformLocation(p, "uSkyZ"), 1, zen);
    glUniform3fv(glGetUniformLocation(p, "uSunR"), 1, sun); glUniform1f(glGetUniformLocation(p, "uWarm"), warm);
}
}   // namespace WaterEnv

#define WATER_GLSL R"GLSL(
uniform vec3 uSkyH, uSkyM, uSkyZ, uSunR; uniform float uWarm;
float wHash(vec2 p){ vec3 q = fract(vec3(p.xyx) * 0.1031); q += dot(q, q.yzx + 33.33); return fract((q.x + q.y) * q.z); }
vec3 wNoise(vec2 p){                               // value noise: x = value, yz = gradient (quintic, so the normals have no creases)
  vec2 i = floor(p), f = fract(p), u = f*f*f*(f*(f*6.0 - 15.0) + 10.0), du = 30.0*f*f*(f*(f - 2.0) + 1.0);
  float a = wHash(i), b = wHash(i + vec2(1,0)), c = wHash(i + vec2(0,1)), d = wHash(i + vec2(1,1)), k = a - b - c + d;
  return vec3(a + (b-a)*u.x + (c-a)*u.y + k*u.x*u.y, du * (vec2(b-a, c-a) + k*u.yx));
}
// surface slope (d height / d xz) from 5 rotated octaves drifting at different speeds; an octave fades out before it gets smaller than a pixel (no shimmer)
vec2 wSlope(vec2 p, float t, float px, vec2 flow){
  vec2 g = vec2(0.0); float fq = 0.23, amp = 0.115;           // amp = height * frequency (slope strength)
  mat2 R = mat2(0.80, 0.60, -0.60, 0.80), M = mat2(1.0);
  for (int i = 0; i < 5; i++){
    float vis = 1.0 - smoothstep(0.25, 0.85, px * fq);
    vec2 q = M * (p - flow * t * (0.6 + 0.22*float(i))) * fq + vec2(float(i)*19.7) + vec2(t*0.11, -t*0.07) * (1.0 + float(i)*0.5);
    vec3 n = wNoise(q);
    g += (n.yz * M) * (amp * vis);
    M = R * M; fq *= 2.07; amp *= 0.82;
  }
  return g;
}
vec3 wSunCol(){ return mix(vec3(1.0, 0.95, 0.84), vec3(1.0, 0.55, 0.22), uWarm) * smoothstep(-0.03, 0.10, uSunR.y); }
// sun glitter: a tight sparkle + a wider soft sheen (stretches into a long path when the sun is low)
vec3 wGlint(vec3 r){ float s = max(dot(r, uSunR), 0.0); return wSunCol() * (pow(s, 900.0) * 2.6 + pow(s, 160.0) * 0.55 + pow(s, 30.0) * 0.07); }
// the sky as it is right now (same three colours as the sky dome) with drifting soft clouds and the glow round the sun
vec3 wSky(vec3 r, float t){
  float y = clamp(r.y, 0.0, 1.0);
  vec3 c = mix(uSkyH, uSkyM, smoothstep(0.0, 0.28, y)); c = mix(c, uSkyZ, smoothstep(0.22, 0.85, y));
  vec2 q = r.xz / (y + 0.18) * 1.6 + vec2(t * 0.006, 0.0);
  float cl = smoothstep(0.52, 0.82, wNoise(q).x * 0.65 + wNoise(q * 2.7).x * 0.35) * smoothstep(0.03, 0.22, y);
  c = mix(c, mix(uSkyH, vec3(1.0), 0.55 * smoothstep(0.0, 0.35, uSunR.y)), cl * 0.55);
  c = max(c, vec3(0.09, 0.13, 0.21));                        // night: the water keeps a faint sheen (the night overlay darkens it again)
  return c + wSunCol() * pow(max(dot(r, uSunR), 0.0), 12.0) * 0.16;
}
)GLSL"
