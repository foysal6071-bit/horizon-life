// Sunny Drift - OpenGL ES 3 rendering of the rolling hills and the distant mountain ring (see terrain.h).
//  The hills next to the river patch are two strips of the same 4 m lattice; the river patch itself (BridgeGL::drawTerrain) already carries
//  the hills inside its area. Both use the river-bed shader (vertex colour x sun + haze). The dirt track is drawn by RoadGL (mud material).
#pragma once
#include "terrain.h"
#include "bridge_render.h"

namespace TerrainGL {

static BridgeGL::Gpu gSouth, gNorth, gMountains, gOuter;
static void initLake();

// Call once with a current GL context, after Terrain::init() and BridgeGL::init() (it re-uses the bridge's terrain shader).
static void init(){
    auto up = [](const Terrain::GMesh& m){ const int n[3] = {3, 3, 3}, o[3] = {0, 12, 24}; return BridgeGL::upload(m.v.data(), m.v.size() * 4, m.idx, 36, n, o, 3); };
    gSouth = up(Terrain::gMeshes.southHills); gNorth = up(Terrain::gMeshes.northHills); gMountains = up(Terrain::gMeshes.mountains); gOuter = up(Terrain::gMeshes.outer);
    initLake();
}

static void draw(const float* VP, const float* eye){
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE);
    glUseProgram(BridgeGL::gProgT); glUniformMatrix4fv(BridgeGL::uT_VP, 1, GL_FALSE, VP); glUniform3fv(BridgeGL::uT_Cam, 1, eye); glUniform1f(BridgeGL::uT_Time, BridgeGL::gWindT);
    if (BridgeGL::uT_MQ >= 0) glUniform1f(BridgeGL::uT_MQ, Quality::flat ? 0.f : (float)Quality::level);   // mountain rock relief + haze follow Settings > Graphics
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, BridgeGL::gGrass); glUniform1i(BridgeGL::uT_Grass, 0);
    BridgeGL::setCullVP(VP);
    BridgeGL::drawGpuCulled(gSouth); BridgeGL::drawGpuCulled(gNorth); BridgeGL::drawGpuCulled(gMountains); BridgeGL::drawGpuCulled(gOuter);
}

// ---------- mountain lake: the river-water shader (ripples, fresnel, sun glint, shore foam) in turquoise, with the mountains mirrored in it ----------
static const char* LAKE_VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in float dep;
uniform mat4 uVP; out float vD; out vec3 wp;
void main(){ vD = dep; wp = p; gl_Position = uVP * vec4(p, 1.0); }
)GLSL";
static const char* LAKE_FS = R"GLSL(#version 300 es
precision highp float;
in float vD; in vec3 wp; uniform vec3 uCam; uniform float uT; uniform sampler2D uSky; out vec4 o;
)GLSL" WATER_GLSL R"GLSL(
float wvn(vec2 p){ return wNoise(p).x; }
void main(){                                       // premultiplied alpha, see the river water
  float cd = length(uCam - wp); vec3 V = (uCam - wp) / cd;
  float px = max(length(fwidth(wp.xz)) * 0.6, 0.001);
  float dw = vD + 0.03*sin(uT*0.9 + wp.x*0.31 + wp.z*0.23);
  if (dw <= 0.0) discard;
  float gust = 0.35 + 1.05 * smoothstep(0.30, 0.75, wNoise(wp.xz * 0.018 - vec2(uT * 0.035, uT * 0.012)).x);     // glassy lanes + wind patches
  vec2 g = wSlope(wp.xz, uT * 0.75, px, vec2(0.30, 0.18)) * gust * (0.40 + 0.35 * smoothstep(0.0, 2.0, dw));
  vec3 N = normalize(vec3(-g.x, 1.0, -g.y));
  float ndv = clamp(dot(N, V), 0.02, 1.0), fr = 0.02 + 0.98 * pow(1.0 - ndv, 5.0);
  float day = smoothstep(-0.08, 0.30, uSunR.y), lit = 0.18 + 0.82 * day;
  // mirrored mountains: reflect the view ray, look the skyline up by azimuth
  vec3 R = reflect(-V, N); R.y = abs(R.y);
  vec3 Rm = normalize(mix(vec3(-V.x, V.y, -V.z), R, 0.55));          // softened ray for the mountain mirror
  float el = atan(Rm.y, length(Rm.xz)), az = atan(Rm.z, Rm.x)*0.15915494 + 0.5;
  float se = texture(uSky, vec2(az, 0.5)).r, crest = texture(uSky, vec2(az, 0.5)).g * 850.0;
  vec3 hzc = vec3(0.75, 0.85, 0.93);
  vec3 sky = wSky(R, uT);
  float v = clamp(el / max(se, 0.001), 0.0, 1.0);
  float hg = v*crest + (wvn(vec2(az*900.0, el*80.0)) - 0.5)*60.0;
  vec3 mc = mix(vec3(0.13, 0.29, 0.11), vec3(0.45, 0.44, 0.42), smoothstep(240.0, 340.0, hg));                // grass -> rock -> snow, like the real slopes
  mc = mix(mc, vec3(0.94, 0.96, 0.99), smoothstep(520.0, 640.0, hg));
  mc *= 0.78 + 0.34*wvn(vec2(az*1800.0, el*160.0)); mc = mix(mc * lit, uSkyH, 0.28);
  float mm = smoothstep(0.0015, -0.0015, el - se) * step(0.002, se);
  vec3 refl = mix(sky, mc, mm);
  float path = dw * (0.55 + 0.45 / max(V.y, 0.30));
  vec3 T = exp(-vec3(0.95, 0.34, 0.28) * path);
  float hide = 1.0 - dot(T, vec3(0.25, 0.50, 0.25));
  vec3 body = mix(vec3(0.14, 0.50, 0.48), vec3(0.025, 0.17, 0.27), smoothstep(0.4, 4.5, dw)) * lit;           // alpine turquoise -> deep blue
  vec3 c = body * hide * (1.0 - fr) + refl * fr + wGlint(R);
  float a = clamp(hide * (1.0 - fr) + fr, 0.0, 1.0);
  float fn = wNoise(wp.xz * 2.4 + vec2(uT * 0.2, -uT * 0.15)).x;
  float foam = (1.0 - smoothstep(0.02, 0.22, dw)) * smoothstep(0.45, 0.80, fn) * (1.0 - smoothstep(60.0, 180.0, cd)) * 0.65;
  c = mix(c, vec3(0.88, 0.93, 0.92) * lit, foam); a = mix(a, 1.0, foam);
  float edge = smoothstep(0.0, 0.18, dw); c *= edge; a *= edge;
  c = mix(c, hzc * a, clamp(cd / 3750.0, 0.0, 1.0));
  o = vec4(c, a);
}
)GLSL";
static BridgeGL::Gpu gLakeG; static GLuint gLakeProg = 0, gLakeSky = 0; static GLint uL_VP, uL_Cam, uL_T, uL_Sky;
static void initLake(){
    if (!Terrain::gLake.on || Terrain::LAKE_I.empty()) return;
    gLakeProg = RoadGL::makeProg(LAKE_VS, LAKE_FS);
    uL_VP = glGetUniformLocation(gLakeProg, "uVP"); uL_Cam = glGetUniformLocation(gLakeProg, "uCam"); uL_T = glGetUniformLocation(gLakeProg, "uT"); uL_Sky = glGetUniformLocation(gLakeProg, "uSky");
    const int n[2] = {3, 1}, o[2] = {0, 12}; gLakeG = BridgeGL::upload(Terrain::LAKE_V.data(), Terrain::LAKE_V.size() * 4, Terrain::LAKE_I, 16, n, o, 2);
    glGenTextures(1, &gLakeSky); glBindTexture(GL_TEXTURE_2D, gLakeSky); glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, Terrain::LAKE_SKY_N, 1, 0, GL_RGBA, GL_UNSIGNED_BYTE, Terrain::LAKE_SKY.data());
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
}
// transparent: call after all opaque things (trees) are drawn
static void drawLake(const float* VP, const float* eye, float t){
    if (!gLakeG.count) return;
    glUseProgram(gLakeProg); glUniformMatrix4fv(uL_VP, 1, GL_FALSE, VP); glUniform3fv(uL_Cam, 1, eye); glUniform1f(uL_T, t);
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, gLakeSky); glUniform1i(uL_Sky, 0); WaterEnv::apply(gLakeProg);
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glEnable(GL_BLEND); glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA); glDepthMask(GL_FALSE);
    BridgeGL::setCullVP(VP); BridgeGL::drawGpuCulled(gLakeG);
    glDepthMask(GL_TRUE); glDisable(GL_BLEND);
}

} // namespace TerrainGL
