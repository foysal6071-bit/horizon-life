// Sunny Drift - Audi R8 look + animation: C++ / OpenGL ES 3 port of buildCarR8() and the car part of animate() in the HTML game.
//  * every R8 material group gets the HTML material (clear-coated white paint, chrome, aluminium, tyres, calipers, interior,
//    transparent glass, head / tail light emissives) shaded with a PBR-style shader: sun + hemisphere + ambient light and the
//    HTML "carEnv" sky reflection (analytic: gradient sky, sun disc, two soft boxes), ACES filmic tone mapping at exposure 1.4
//  * the 4 wheels are separate parts: they roll with the road speed, the two front ones steer, the brake calipers only steer,
//    and a tyre that would sink into the ground (body squat / dive / roll) is lifted into its arch
//  * body roll / pitch are damped springs driven by cornering and braking (susp in the HTML)
//  * tail lights react to braking / reversing, soft brake-light halo and the soft contact shadow under the car
#pragma once
#include <GLES3/gl3.h>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <array>
#include <algorithm>
#include <sstream>
#include <string>
#include <vector>
#include <unordered_map>
#include <functional>
#include "car_core.h"
#include "env_glsl.h"
#include "sun_light.h"

namespace CarGL {

// ---------------- model constants (HTML buildCarR8) ----------------
static const int    WH0 = 54432, WHN = 24570, NEON0 = 152712;   // wheel index ranges inside the model, neon under-glow is not drawn
static const double CAR_S = 2.8 / 2643.1, CAR_ZC = -104.45;
static const float  CAR_WHEEL_R = 0.3318f;                      // tyre radius after scaling (m)

// ---------------- suspension / wheel / light state ----------------
static double suspRoll = 0, suspRollV = 0, suspPitch = 0, suspPitchV = 0, suspHeave = 0, suspHeaveV = 0; static bool lastAir = false;   // heave = body height offset (m): aero squat, cornering compression, landing bounce
static double spinF = 0, spinR = 0, brakeK = 0; static bool lastRev = false;
static double brakeHeat[4] = {0, 0, 0, 0};                      // 0..1.2 disc temperature (game wheel order: front A, front B, rear A, rear B)
static inline float discGlow(int i){ float x = (float)((brakeHeat[i] - 0.30) / 0.70); x = x < 0.f ? 0.f : (x > 1.f ? 1.f : x); return x * x * (3.f - 2.f * x); }
static float  wheelComp[4] = {0, 0, 0, 0};                      // wheel travel relative to the body (m): + = pushed up into the arch (compression), - = hanging down (droop)
static double wheelZ[4] = {0, 0, 0, 0}, wheelV[4] = {0, 0, 0, 0};   // each wheel = its own sprung mass (damped spring) -> lag, small bounce after a landing, full droop in the air
static void resetWheels(){ for (int i = 0; i < 4; i++){ wheelZ[i] = wheelV[i] = 0; wheelComp[i] = 0.f; } }

struct Mat {
    float col[3]; float emis[3];
    float metal, rough, clear, clearRough, envI, alpha;
    int kind;                       // 0 normal, 1 tail light (animated), 2 head light
    bool transparent;
};
struct Item { int start, count, mat, tgt, disc; };   // disc: 0 = no, else 1 + game wheel index of the brake disc    // tgt: 0 body, 1..4 wheel i (spinning part), 5..8 wheel i (brake caliper, steers only)

static float gMM[9][16], gMV[9][16];     // matrices of the last draw (body, 4 x tyre+rim, 4 x caliper)
static std::vector<Mat> gMats; static std::vector<Item> gItems;
static GLuint gVBO = 0, gIBO = 0, gProg = 0, gQuadVBO = 0, gQuadProg = 0;
static GLint uMVP, uModel, uCam, uCol, uEmis, uMR, uEnvA, uNight, uMulN, uSurf, uInside;
static std::vector<std::array<float,6>> gBB;   // per item: model-frame bounding box (xmin,ymin,zmin,xmax,ymax,zmax) for cockpit visibility culling
static GLint qMVP, qKind, qOp;
static float wC[4][3];              // wheel centres in the model frame (x forward, y up, z = -raw x), game order: front A, front B, rear A, rear B

static inline float lin(double c){ return (float)std::pow(c / 255.0, 2.2); }        // sRGB 0..255 -> linear (three.js Color(hex))
static void hexLin(unsigned hx, float* o){ o[0] = lin((hx >> 16) & 255); o[1] = lin((hx >> 8) & 255); o[2] = lin(hx & 255); }

// material table exactly like matFor() in the HTML
static Mat makeMat(const std::string& name, unsigned c, int em, double a){
    Mat m = {}; hexLin(c, m.col); m.metal = 0; m.rough = 1; m.clear = 0; m.clearRough = 0; m.envI = 0; m.alpha = 1; m.kind = 0; m.transparent = false;
    if (em == 1){
        if (name == "light"){ m.kind = 2; hexLin(0xf2f9ff, m.col); hexLin(0xdff0ff, m.emis); for (int i = 0; i < 3; i++) m.emis[i] *= 2.2f; m.rough = 1; }
        else { m.kind = 1; hexLin(0xff2a2a, m.col); hexLin(0xff0c0c, m.emis); for (int i = 0; i < 3; i++) m.emis[i] *= 1.5f; m.rough = 0.25f; }
        return m;
    }
    if (a < 1){ m.metal = 0.35f; m.rough = 0.03f; m.envI = 2.0f; m.alpha = (float)std::min(0.9, a * 1.5); m.transparent = true; return m; }
    auto P = [&](float me, float ro, float cl, float cr, float ei){ m.metal = me; m.rough = ro; m.clear = cl; m.clearRough = cr; m.envI = ei; };
    if (name == "body_color"){ hexLin(0xf3f4f6, m.col); P(0.28f, 0.14f, 1, 0.02f, 1.5f); }
    else if (name == "black_gloss" || name == "trim") P(0.3f, 0.16f, 1, 0.05f, 1.2f);
    else if (name == "black_matt" || name == "tail_light_red_2" || name == "tail_light_red_3") P(0.5f, 0.35f, 1, 0.05f, 1.1f);
    else if (name == "rims_1") P(0.9f, 0.22f, 1, 0.04f, 1.6f);
    else if (name == "chrome") P(1, 0.12f, 0, 0, 1.3f);
    else if (name == "Aluminium_1" || name == "Aluminum_2") P(1, 0.3f, 0, 0, 1.2f);
    else if (name == "grille") P(0.7f, 0.45f, 0, 0, 0.8f);
    else if (name == "metal_1") P(0.2f, 0.28f, 0, 0, 1.0f);              // red brake calipers
    else if (name == "interior_1" || name == "interior_2" || name == "interior_roof") P(0, 0.85f, 0, 0, 0.3f);
    else if (name == "tyre") P(0, 0.92f, 0, 0, 0.25f);
    else P(0.3f, 0.55f, 0, 0, 0.6f);
    return m;
}

// ---------------- 4x4 helpers (column-major) ----------------
typedef float M4[16];
static void mIdent(M4 m){ memset(m, 0, 64); m[0] = m[5] = m[10] = m[15] = 1; }
static void mMul(M4 o, const M4 a, const M4 b){
    M4 t; for (int c = 0; c < 4; c++) for (int r = 0; r < 4; r++){ float s = 0; for (int k = 0; k < 4; k++) s += a[k*4+r] * b[c*4+k]; t[c*4+r] = s; }
    memcpy(o, t, 64);
}
static void mT(M4 m, float x, float y, float z){ mIdent(m); m[12] = x; m[13] = y; m[14] = z; }
static void mRY(M4 m, float a){ mIdent(m); float c = cosf(a), s = sinf(a); m[0] = c; m[2] = -s; m[8] = s; m[10] = c; }
static void mRX(M4 m, float a){ mIdent(m); float c = cosf(a), s = sinf(a); m[5] = c; m[6] = s; m[9] = -s; m[10] = c; }   // about the nose axis (camber)
static void mRZ(M4 m, float a){ mIdent(m); float c = cosf(a), s = sinf(a); m[0] = c; m[1] = s; m[4] = -s; m[5] = c; }

// ---------------- shaders ----------------
static const char* CAR_VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in vec3 n; layout(location=2) in vec3 aux;
uniform mat4 uMVP, uModel; out vec3 vn; out vec3 wp; out vec3 lp; out vec3 ln; out vec3 rp; out vec3 vaux;
void main(){ vaux = aux; rp = mat3(uModel)*p; lp = p; ln = n; vn = mat3(uModel)*n; wp = (uModel*vec4(p,1.0)).xyz; gl_Position = uMVP*vec4(p,1.0); }
)GLSL";

static const char* CAR_FS = R"GLSL(#version 300 es
precision highp float;
in vec3 vn; in vec3 wp; in vec3 lp; in vec3 ln; in vec3 rp; in vec3 vaux;
uniform int uSurf; uniform float uInside;
uniform vec3 uCam, uCol, uEmis;
uniform vec4 uMR;      // metalness, roughness, clearcoat, clearcoat roughness
uniform vec2 uEnvA;    // env map intensity, opacity
uniform float uNight;
uniform vec3 uMulN;     // night darkening for the cockpit pass (1,1,1 = none)
out vec4 o;
const float PI = 3.14159265;
)GLSL" ENV_GLSL R"GLSL(

float h31(vec3 p){ p = fract(p*0.1031); p += dot(p, p.yzx + 33.33); return fract((p.x + p.y)*p.z); }
float vnoise(vec3 x){ vec3 i = floor(x), f = fract(x); f = f*f*(3.0 - 2.0*f);
  return mix(mix(mix(h31(i), h31(i+vec3(1,0,0)), f.x), mix(h31(i+vec3(0,1,0)), h31(i+vec3(1,1,0)), f.x), f.y),
             mix(mix(h31(i+vec3(0,0,1)), h31(i+vec3(1,0,1)), f.x), mix(h31(i+vec3(0,1,1)), h31(i+vec3(1,1,1)), f.x), f.y), f.z); }
float grain(vec3 p, float fade){ float a = vnoise(p*380.0), b = vnoise(p*820.0 + 5.0); return mix(0.5, (1.0 - abs(a*2.0 - 1.0))*0.65 + b*0.35, fade); }
vec3 bumpN(vec3 N, vec3 P, float h, float k){
  vec3 dpx = dFdx(P), dpy = dFdy(P); float dhx = dFdx(h), dhy = dFdy(h);
  vec3 r1 = cross(dpy, N), r2 = cross(N, dpx); float det = dot(dpx, r1);
  return normalize(abs(det)*N - k*sign(det)*(dhx*r1 + dhy*r2));
}

float D_GGX(float a2, float NoH){ float d = NoH*NoH*(a2 - 1.0) + 1.0; return a2/(PI*d*d); }
float V_SmithCorr(float a2, float NoL, float NoV){
  float gv = NoL*sqrt(a2 + (1.0 - a2)*NoV*NoV), gl = NoV*sqrt(a2 + (1.0 - a2)*NoL*NoL); return 0.5/max(gv + gl, 1e-5);
}
vec3 aces(vec3 c, float ex){
  c *= ex/0.6;
  mat3 I = mat3(vec3(0.59719,0.07600,0.02840), vec3(0.35458,0.90834,0.13383), vec3(0.04823,0.01566,0.83777));
  mat3 O = mat3(vec3(1.60475,-0.10208,-0.00327), vec3(-0.53108,1.10813,-0.07276), vec3(-0.07367,-0.00605,1.07602));
  c = I*c; vec3 a = c*(c + 0.0245786) - 0.000090537, b = c*(0.983729*c + 0.4329510) + 0.238081; c = O*(a/b);
  return clamp(c, 0.0, 1.0);
}
void main(){
  vec3 V = normalize(uCam - wp), N = normalize(vn);
  if (dot(N, V) < 0.0) N = -N;                                  // double sided
  vec3 baseO = uCol; float metalO = -1.0; float cabAO = 1.0, sunK = 1.0, roughAdd = 0.0, sheen = 0.0, stitch = 0.0; vec3 tint = vec3(1.0), stitchCol = vec3(0.0);
  float fwl = length(fwidth(lp)); float fade = 1.0 - smoothstep(0.0007, 0.0024, fwl), sfade = 1.0 - smoothstep(0.001, 0.0035, fwl);
  if (uInside > 0.5){   // realistic cabin: analytic occlusion, roof-shaded sun
    cabAO = mix(0.28, 1.0, smoothstep(0.16, 0.60, lp.y));
    if (lp.x > 0.45) cabAO *= mix(0.5, 1.0, smoothstep(0.55, 0.80, lp.y));
    cabAO *= 1.0 - 0.28*smoothstep(0.66, 0.82, abs(lp.z));
    cabAO *= mix(0.7, 1.0, smoothstep(-0.9, 0.2, ln.y));
    sunK = mix(0.20, 1.0, smoothstep(0.55, 0.9, N.y)*step(0.45, lp.x));
  }
  if (uSurf == 1){ float g = grain(lp, fade); N = bumpN(N, rp, g*0.0006, 1.0); tint = vec3(mix(0.84, 1.10, g)); sheen = 0.05;
    if (lp.x > 0.55 && lp.x < 0.95 && abs(ln.z) < 0.5 && ln.y > 0.2){ float yy = lp.y - 0.755; stitch = smoothstep(0.0009, 0.0004, abs(abs(yy) - 0.004))*step(0.5, fract(lp.z*140.0))*step(abs(yy), 0.01)*sfade; stitchCol = vec3(0.30, 0.28, 0.25); } }
  else if (uSurf == 2){   // quilted diamond leather seat + dashed thread
    vec2 q = abs(ln.z) > 0.6 ? lp.xy : (abs(ln.y) > 0.55 ? lp.xz : lp.yz);
    vec2 d = vec2(q.x + q.y, q.x - q.y)/0.085; vec2 f = abs(fract(d) - 0.5);
    float e = 0.5 - max(f.x, f.y); float pillow = smoothstep(0.0, 0.30, e); float gq = grain(lp, fade);
    N = bumpN(N, rp, pillow*0.010 + gq*0.0005, 1.0);
    tint = vec3(mix(0.55, 1.06, pillow)*mix(0.88, 1.06, gq));
    float along = f.x > f.y ? d.y : d.x;
    stitch = smoothstep(0.016, 0.008, abs(e - 0.05))*step(0.5, fract(along*7.0))*sfade; stitchCol = vec3(0.62, 0.52, 0.36);
  }
  else if (uSurf == 3){ float n1 = vnoise(lp*900.0), n2 = vnoise(lp*2200.0); tint = vec3(mix(0.82, 1.15, n1*0.6 + n2*0.4)); sheen = 0.10; roughAdd = 0.3; N = bumpN(N, rp, n1*0.0003*fade, 1.0); }
  else if (uSurf == 4){   // wheel rim: leather grain, red seam on the driver side, 12 o'clock marker, perforated 3 / 9 o'clock grips
    float g = grain(lp, fade); N = bumpN(N, rp, g*0.0005, 1.0); tint = vec3(mix(0.85, 1.10, g));
    float th = vaux.x, phi = vaux.y; float sd = 0.03*(phi + 1.5708);
    stitch = smoothstep(0.0009, 0.0004, abs(abs(sd) - 0.0035))*step(0.5, fract(th*19.0986))*sfade; stitchCol = vec3(0.55, 0.04, 0.03);
    float mk = smoothstep(0.05, 0.035, abs(th)); stitch = max(stitch, mk); stitchCol = mix(stitchCol, vec3(0.7, 0.03, 0.02), mk);
    float side = smoothstep(0.62, 0.50, abs(abs(th) - 1.5708))*smoothstep(0.35, 0.5, abs(phi + 1.5708) + 0.2)*step(-2.7, phi)*step(phi, -0.4);
    vec2 pc = vec2(th*0.15/0.0032, phi*0.03/0.0032); pc.x += 0.5*mod(floor(pc.y), 2.0);
    float hole = (1.0 - smoothstep(0.20, 0.27, length(fract(pc) - 0.5)))*side*sfade; tint *= 1.0 - 0.88*hole; roughAdd += 0.3*hole;
  }
  else if (uSurf == 6){   // airbag hub: leather + four-ring emblem
    float g = grain(lp, fade); N = bumpN(N, rp, g*0.0005, 1.0); tint = vec3(mix(0.85, 1.10, g));
    const vec3 WC = vec3(0.588, 0.746, 0.375); vec3 AX = normalize(vec3(0.871, -0.492, 0.016));
    vec3 d3 = lp - WC; float a = dot(d3, AX); vec3 rv = d3 - a*AX; float rho = length(rv);
    vec3 up = normalize(vec3(0.0, 1.0, 0.0) - AX*AX.y); vec3 sv = cross(AX, up);
    if (rho < 0.074 && -dot(normalize(ln), AX) > 0.8){
      vec2 e = vec2(dot(rv, sv), dot(rv, up)); float ring = 0.0;
      for (int k = 0; k < 4; k++) ring = max(ring, smoothstep(0.0013, 0.0007, abs(length(e - vec2((float(k) - 1.5)*0.0072, 0.0)) - 0.0105)));
      baseO = mix(uCol, vec3(0.75, 0.76, 0.78), ring); metalO = 0.95*ring; roughAdd += 0.1*ring;
    }
  }
  else if (uSurf == 7){   // brushed aluminium (spokes, trim ring): circular brushing
    const vec3 WC = vec3(0.588, 0.746, 0.375); vec3 AX = normalize(vec3(0.871, -0.492, 0.016));
    vec3 d3 = lp - WC; float a = dot(d3, AX); float rho = length(d3 - a*AX);
    float t = vnoise(vec3(rho*420.0, a*30.0, 0.5))*0.6 + vnoise(vec3(rho*900.0, a*60.0, 3.0))*0.4;
    tint = vec3(0.78 + 0.32*mix(0.5, t, fade)); roughAdd += 0.12*t;
  }
  else if (uSurf == 8){ float g = grain(lp, fade); tint = vec3(mix(0.8, 1.1, g)); N = bumpN(N, rp, g*0.0004, 1.0); }
  float NoV = clamp(dot(N, V), 1e-3, 1.0);
  float metal = metalO >= 0.0 ? metalO : uMR.x, rough = clamp(uMR.y + roughAdd + stitch*0.5 + clamp(length(fwidth(N))*0.6, 0.0, 0.25)*uInside, 0.06, 1.0), cc = uMR.z, ccr = max(uMR.w, 0.06), envI = uEnvA.x;
  vec3 alb = mix(baseO*(1.0 - metal)*tint, stitchCol, stitch), F0 = mix(vec3(0.04), baseO, metal);
  float a = rough*rough, a2 = a*a;
  // lights: sun (DirectionalLight 3.0), hemisphere (day 1.35), ambient 0.45
  vec3 Ls = SUNL, Lc = L2(vec3(1.0,0.965,0.878))*3.0*sunK;
  float NoL = max(dot(N, Ls), 0.0); vec3 H = normalize(Ls + V); float NoH = max(dot(N, H), 0.0), VoH = max(dot(V, H), 0.0);
  vec3 F = F0 + (1.0 - F0)*pow(1.0 - VoH, 5.0);
  vec3 dirSpec = F*D_GGX(a2, NoH)*V_SmithCorr(a2, NoL, NoV);
  vec3 col = (alb/PI + dirSpec)*Lc*NoL;
  float ac = ccr*ccr, ac2 = ac*ac; float Fc = 0.04 + 0.96*pow(1.0 - VoH, 5.0);
  vec3 ccDir = vec3(Fc*D_GGX(ac2, NoH)*V_SmithCorr(ac2, NoL, NoV))*Lc*NoL;
  vec3 hemi = mix(L2(vec3(0.416,0.612,0.345)), L2(vec3(0.847,0.937,1.0)), 0.5 + 0.5*N.y)*(0.5 + 0.85) + vec3(0.45);
  float ao = mix(0.45, 1.0, smoothstep(-0.55, 0.35, N.y))*cabAO;      // underside / sill / arch occlusion: surfaces facing the road get less sky light
  col += alb*hemi/PI*ao;
  // image based lighting from the car environment
  vec3 Lcos = envC(N, 1.0) + vec3(14.0,12.0,9.0)*0.0443/PI*max(dot(N, normalize(vec3(40.0,45.0,30.0))), 0.0);
  col += alb*Lcos*envI*ao;
  vec3 R = reflect(-V, N);
  vec2 ab = envBRDF(rough, NoV);
  float so = mix(0.30, 1.0, smoothstep(-0.35, 0.15, R.y));       // reflections pointing into the road are shadowed by the car itself
  vec3 spec = envC(R, rough)*envI*(F0*ab.x + ab.y)*so;
  if (cc > 0.0){
    vec2 abc = envBRDF(ccr, NoV); float Fcc = 0.04*abc.x + abc.y;
    float Fn = 0.04 + 0.96*pow(1.0 - NoV, 5.0);
    col = col*(1.0 - cc*Fn) + ccDir*cc; spec = spec*(1.0 - cc*Fn);
    spec += envC(R, ccr)*envI*Fcc*cc*so;
  }
  spec *= mix(1.0, 0.6, uInside)*cabAO;
  col += alb*sheen*pow(1.0 - NoV, 3.0)*1.5;
  col += spec + uEmis;
  col = aces(col, 1.4 + 0.3*uNight);
  col = pow(col, vec3(1.0/2.2));
  col *= uMulN;
  col = mix(col, vec3(0.62,0.80,0.95), clamp(length(uCam - wp)/3750.0, 0.0, 1.0));   // same haze as the rest of this project
  float al = uEnvA.y; if (al < 0.999) al = mix(al, 1.0, pow(1.0 - NoV, 3.0)*0.6);   // glass is more opaque / reflective at grazing angles (Fresnel)
  o = vec4(col, al);
}
)GLSL";

// soft quads (contact shadow, brake-light halo): position in the car model frame, uv in 0..1
static const char* Q_VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in vec2 uv;
uniform mat4 uMVP; out vec2 vUv;
void main(){ vUv = uv; gl_Position = uMVP*vec4(p,1.0); }
)GLSL";
static const char* Q_FS = R"GLSL(#version 300 es
precision mediump float;
in vec2 vUv; uniform int uKind; uniform float uOp; out vec4 o;
void main(){
  vec2 q = vUv*2.0 - 1.0;
  if (uKind == 0){                                   // contact shadow: dark blob, tighter dark core (canvas 256x128 radial gradient)
    float r = length(vec2(q.y, q.x*0.5))*1.016;    // u runs along the car, v across it
    float a = r < 0.048 ? 0.78 : (r < 0.55 ? mix(0.78, 0.42, (r - 0.048)/0.502) : mix(0.42, 0.0, clamp((r - 0.55)/0.45, 0.0, 1.0)));
    o = vec4(0.0, 0.0, 0.0, a);
  } else if (uKind == 2){                            // hot brake disc: soft orange glow (additive)
    float r = length(q); float a = clamp(1.0 - r, 0.0, 1.0); a = a*a*(0.55 + 0.9*a);
    o = vec4(1.0, 0.36 + 0.22*a, 0.06 + 0.12*a, a*uOp);
  } else {                                           // brake-light halo: red radial glow (additive)
    float r = length(vec2(q.x, q.y*0.5));
    float a = r < 0.016 ? 0.9 : (r < 0.4 ? mix(0.9, 0.35, (r - 0.016)/0.384) : mix(0.35, 0.0, clamp((r - 0.4)/0.6, 0.0, 1.0)));
    o = vec4(1.0, 0.235, 0.196, a*uOp);
  }
}
)GLSL";

static GLuint comp(GLenum t, const char* s){
    GLuint sh = glCreateShader(t); SunLight::shaderSource(sh, s); glCompileShader(sh); return sh;
}
static GLuint prog(const char* vs, const char* fs){
    GLuint p = glCreateProgram(); glAttachShader(p, comp(GL_VERTEX_SHADER, vs)); glAttachShader(p, comp(GL_FRAGMENT_SHADER, fs)); glLinkProgram(p); SunLight::attach(p); return p;
}

// ---------------- init: raw model (r8.bin) + header (r8_meta.txt) + material groups (r8_groups.txt) ----------------
static void cabinInit(); static void wheelMeshInit();
static void init(const std::vector<char>& raw, const std::vector<char>& meta, const std::vector<char>& groups){
    std::istringstream mf(std::string(meta.begin(), meta.end()));
    int n, ni; double mn[3], sz[3]; mf >> n >> ni >> mn[0] >> mn[1] >> mn[2] >> sz[0] >> sz[1] >> sz[2];
    const uint16_t* pos = (const uint16_t*)raw.data();
    const int8_t*   nor = (const int8_t*)(raw.data() + n * 6);
    const uint16_t* idx = (const uint16_t*)(raw.data() + n * 10);
    std::vector<float> vb(n * 6);
    for (int i = 0; i < n; i++){
        double rx = mn[0] + pos[i*3]   / 65535.0 * sz[0], ry = mn[1] + pos[i*3+1] / 65535.0 * sz[1], rz = mn[2] + pos[i*3+2] / 65535.0 * sz[2];
        vb[i*6] = (float)((rz - CAR_ZC) * CAR_S); vb[i*6+1] = (float)(ry * CAR_S); vb[i*6+2] = (float)(-rx * CAR_S);
        double nx = nor[i*4] / 127.0, ny = nor[i*4+1] / 127.0, nz = nor[i*4+2] / 127.0, l = std::sqrt(nx*nx + ny*ny + nz*nz); if (l == 0) l = 1;
        vb[i*6+3] = (float)(nz / l); vb[i*6+4] = (float)(ny / l); vb[i*6+5] = (float)(-nx / l);
    }
    glGenBuffers(1, &gVBO); glBindBuffer(GL_ARRAY_BUFFER, gVBO); glBufferData(GL_ARRAY_BUFFER, vb.size() * 4, vb.data(), GL_STATIC_DRAW);
    glGenBuffers(1, &gIBO); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gIBO); glBufferData(GL_ELEMENT_ARRAY_BUFFER, ni * 2, idx, GL_STATIC_DRAW);

    // wheel centres = middle of each wheel's bounding box (raw wheel 0 / 2 = front, 1 / 3 = rear -> game order 0,2,1,3)
    static const int ORDER[4] = {0, 2, 1, 3};
    for (int gi = 0; gi < 4; gi++){
        const int wi = ORDER[gi]; float lo[3] = {1e9f, 1e9f, 1e9f}, hi[3] = {-1e9f, -1e9f, -1e9f};
        for (int i = WH0 + wi * WHN; i < WH0 + (wi + 1) * WHN; i++) for (int k = 0; k < 3; k++){
            float v = vb[idx[i] * 6 + k]; lo[k] = std::min(lo[k], v); hi[k] = std::max(hi[k], v); }
        for (int k = 0; k < 3; k++) wC[gi][k] = (lo[k] + hi[k]) / 2;
    }

    // material groups
    std::istringstream gf(std::string(groups.begin(), groups.end())); std::string name, col;
    int s, c, em; double al;
    while (gf >> name >> s >> c >> col >> em >> al){
        if (c == 0 || s >= NEON0 || em == 2) continue;
        unsigned hx = 0x808080; sscanf(col.c_str(), "#%x", &hx);
        gMats.push_back(makeMat(name, hx, em, al)); const int mi = (int)gMats.size() - 1;
        int tgt = 0, disc = 0;
        if (s >= WH0){
            const int wi = (s - WH0) / WHN, off = s - WH0 - wi * WHN; int gi = 0; for (int k = 0; k < 4; k++) if (ORDER[k] == wi) gi = k;
            tgt = (off >= 666 && off < 1944 ? 5 : 1) + gi;
            if (off == 0 && name == "metal_2") disc = gi + 1;                      // the brake disc: first group of every wheel (steers, does not spin)
            if (disc) tgt = 5 + gi;
        }
        gItems.push_back({s, c, mi, tgt, disc});
        { std::array<float,6> bb = {1e9f,1e9f,1e9f,-1e9f,-1e9f,-1e9f};
          for (int q = s; q < s + c; q++) for (int k = 0; k < 3; k++){ const float v = vb[idx[q] * 6 + k]; bb[k] = std::min(bb[k], v); bb[3 + k] = std::max(bb[3 + k], v); }
          gBB.push_back(bb); }
    }

    {   // smooth the low-poly cabin: average normals of welded vertices (<~55 deg apart) for the interior parts only
        std::vector<char> sel(n, 0);
        for (size_t ii = 0; ii < gItems.size(); ii++){
            const Item& it = gItems[ii]; const Mat& m = gMats[it.mat]; const std::array<float,6>& b = gBB[ii];
            if (it.tgt != 0 || it.disc || m.kind) continue;
            const bool fabric = m.metal == 0.f && m.rough > 0.8f && m.rough < 0.9f && m.envI < 0.4f;
            const bool dashMatt = m.metal > 0.4f && m.metal < 0.6f && b[1] > 0.70f && b[0] > 0.3f && b[3] < 1.4f;
            if (!fabric && !dashMatt) continue;
            for (int q = it.start; q < it.start + it.count; q++) sel[idx[q]] = 1;
        }
        std::unordered_map<long long, std::vector<int>> W;
        auto key = [&](int i){ return ((long long)llround(vb[i*6] * 400.0) * 1000003LL + (long long)llround(vb[i*6+1] * 400.0)) * 1000003LL + (long long)llround(vb[i*6+2] * 400.0); };
        for (int i = 0; i < n; i++) if (sel[i]) W[key(i)].push_back(i);
        std::vector<float> nn(n * 3);
        for (int i = 0; i < n; i++) if (sel[i]){
            float a[3] = {0, 0, 0};
            for (int j : W[key(i)]){ const float d = vb[i*6+3]*vb[j*6+3] + vb[i*6+4]*vb[j*6+4] + vb[i*6+5]*vb[j*6+5]; if (d > 0.57f){ a[0] += vb[j*6+3]; a[1] += vb[j*6+4]; a[2] += vb[j*6+5]; } }
            const float l = std::sqrt(a[0]*a[0] + a[1]*a[1] + a[2]*a[2]); if (l > 1e-6f){ nn[i*3] = a[0]/l; nn[i*3+1] = a[1]/l; nn[i*3+2] = a[2]/l; } else { nn[i*3] = vb[i*6+3]; nn[i*3+1] = vb[i*6+4]; nn[i*3+2] = vb[i*6+5]; }
        }
        for (int i = 0; i < n; i++) if (sel[i]){ vb[i*6+3] = nn[i*3]; vb[i*6+4] = nn[i*3+1]; vb[i*6+5] = nn[i*3+2]; }
        glBindBuffer(GL_ARRAY_BUFFER, gVBO); glBufferSubData(GL_ARRAY_BUFFER, 0, vb.size() * 4, vb.data());
    }

    gProg = prog(CAR_VS, CAR_FS);
    uMVP = glGetUniformLocation(gProg, "uMVP"); uModel = glGetUniformLocation(gProg, "uModel"); uCam = glGetUniformLocation(gProg, "uCam");
    uCol = glGetUniformLocation(gProg, "uCol"); uEmis = glGetUniformLocation(gProg, "uEmis"); uMR = glGetUniformLocation(gProg, "uMR");
    uEnvA = glGetUniformLocation(gProg, "uEnvA"); uNight = glGetUniformLocation(gProg, "uNight"); uMulN = glGetUniformLocation(gProg, "uMulN"); uSurf = glGetUniformLocation(gProg, "uSurf"); uInside = glGetUniformLocation(gProg, "uInside");
    gQuadProg = prog(Q_VS, Q_FS); qMVP = glGetUniformLocation(gQuadProg, "uMVP"); qKind = glGetUniformLocation(gQuadProg, "uKind"); qOp = glGetUniformLocation(gQuadProg, "uOp");
    // quads: [0..5] contact shadow 5.6 m x 2.5 m at y = 0.015, [6..11] brake-light halo 1.9 m x 0.42 m behind the LED bar
    const float tailX = (float)((-2111 - CAR_ZC) * CAR_S) - 0.08f;
    std::vector<float> qv = {
        -2.8f,0.015f,-1.25f,0,0,  2.8f,0.015f,-1.25f,1,0,  -2.8f,0.015f,1.25f,0,1,   2.8f,0.015f,-1.25f,1,0,  2.8f,0.015f,1.25f,1,1,  -2.8f,0.015f,1.25f,0,1,
        tailX,0.72f-0.21f,-0.95f,0,0, tailX,0.72f-0.21f,0.95f,1,0, tailX,0.72f+0.21f,-0.95f,0,1,  tailX,0.72f-0.21f,0.95f,1,0, tailX,0.72f+0.21f,0.95f,1,1, tailX,0.72f+0.21f,-0.95f,0,1 };
    // [12 + 12*i ..] hot-disc glow of wheel i (game order): 6 vertices a soft quad just outside the rim (side view) + 6 behind the wheel (rear view)
    for (int i = 0; i < 4; i++){
        const float cx = wC[i][0], cy = wC[i][1], cz = wC[i][2], sg = cz > 0 ? 1.f : -1.f, R = 0.30f, zo = cz + sg * 0.15f, xo = cx - 0.26f;
        const float side[] = { cx-R,cy-R,zo,0,0, cx+R,cy-R,zo,1,0, cx-R,cy+R,zo,0,1,  cx+R,cy-R,zo,1,0, cx+R,cy+R,zo,1,1, cx-R,cy+R,zo,0,1 };
        const float rear[] = { xo,cy-R,cz-R,0,0, xo,cy-R,cz+R,1,0, xo,cy+R,cz-R,0,1,  xo,cy-R,cz+R,1,0, xo,cy+R,cz+R,1,1, xo,cy+R,cz-R,0,1 };
        qv.insert(qv.end(), side, side + 30); qv.insert(qv.end(), rear, rear + 30);
    }
    glGenBuffers(1, &gQuadVBO); glBindBuffer(GL_ARRAY_BUFFER, gQuadVBO); glBufferData(GL_ARRAY_BUFFER, qv.size() * 4, qv.data(), GL_STATIC_DRAW);
    cabinInit();
}

// ---------------- per-frame animation (suspension springs, wheel spin / steer, tail lights) ----------------
//  air = the car is flying (no tyre compression); pitchS = smoothed slope pitch (HTML rampPitch); ptT = its target; tRoll / tRollT = smoothed / target cross-slope roll
static void update(const CarState& S, double dt, bool air, double pitchS, double ptT, double tRoll, double tRollT){
    {   // suspension: body leans outward in corners (roll), nose dives under braking / squats under power (pitch), damped springs
        const double W = 11, Z = 0.60;                                       // sports-car springs: a little overshoot, then settles (was heavily over-damped)
        const double rt = clampd(S.ay * 0.0045, -0.07, 0.07), pt = clampd(-S.axS * 0.0042, -0.05, 0.06);   // ~2.6 deg / g roll, ~2.4 deg / g dive
        suspRollV  += (W*W*(rt - suspRoll)  - 2*Z*W*suspRollV)  * dt; suspRoll  += suspRollV  * dt;
        suspPitchV += (W*W*(pt - suspPitch) - 2*Z*W*suspPitchV) * dt; suspPitch += suspPitchV * dt;
    }
    {   // heave: aero downforce presses the car down at speed, hard cornering compresses it, a landing makes it bounce (under-damped spring)
        const double W = 11, Z = 0.5, vn = std::min(fabs(S.speed) / 55.0, 1.3);
        const double ht = -0.014 * vn * vn - 0.006 * std::min(fabs(S.ay) / 9.81, 1.2);
        if (lastAir && !air){ suspHeaveV -= 2.0; suspPitchV -= 0.25 * clampd(S.speed / 40.0, 0, 1.5); }
        lastAir = air;
        suspHeaveV += (W*W*(ht - suspHeave) - 2*Z*W*suspHeaveV) * dt; suspHeave += suspHeaveV * dt;
        suspHeave = clampd(suspHeave, -0.09, 0.03);
    }
    {   // wheels roll with the speed of the contact patch along the wheel; the rears slow a little in a drift
        const double sa = S.steerAngle, CG_A = Veh::LA;
        const double vF = S.speed * cos(sa) + (S.vy + CG_A * S.yaw) * sin(sa), vR = S.speed * (1 - 0.35 * S.drift) * (1 - 0.97 * S.hb) + (S.reverse ? -1.0 : 1.0) * 3.0 * S.throttle * clampd(1 - fabs(S.speed) / 14, 0, 1);   // handbrake locks the rears; a little wheelspin at launch
        spinF = fmod(spinF + clampd(vF * dt / CAR_WHEEL_R, -0.5, 0.5), 2 * M_PI);
        spinR = fmod(spinR + clampd(vR * dt / CAR_WHEEL_R, -0.5, 0.5), 2 * M_PI);
    }
    {   // each tyre stays on the road: it compresses where the body corner sinks, droops where the body rises, and hangs fully extended in the air.
        // The wheel is its own sprung mass (damped spring, a bit under-damped) so a landing gives a small bounce instead of a hard snap.
        const double sinP = sin(suspPitch - pitchS + ptT), sinR = sin(suspRoll + tRoll - tRollT);
        const int ns = std::min(6, std::max(1, (int)std::ceil(dt / 0.008))); const double h = dt / ns, W = 26, Z = 0.55;
        for (int i = 0; i < 4; i++){
            const double fF = wC[i][0], lL = -wC[i][2];
            const double tgt = air ? -0.075 : clampd(fF * sinP - lL * sinR + 0.003 - suspHeave, -0.075, 0.10);
            for (int k = 0; k < ns; k++){ wheelV[i] += (W*W*(tgt - wheelZ[i]) - 2*Z*W*wheelV[i]) * h; wheelZ[i] += wheelV[i] * h; }
            wheelZ[i] = clampd(wheelZ[i], -0.09, 0.12); wheelComp[i] = (float)wheelZ[i];
        }
    }
    {   // brake discs: heat up under hard braking at speed (fronts do most of the work), cool down in the air stream
        const double sp = fabs(S.speed), br = S.reverse ? 0.0 : S.brake, vk = clampd(sp / 30.0, 0, 1.4);
        for (int i = 0; i < 4; i++){
            const double gain = i < 2 ? 0.62 * br * vk : 0.38 * br * vk + 0.45 * S.hb * clampd(sp / 20.0, 0, 1);
            brakeHeat[i] = clampd(brakeHeat[i] + gain * dt - brakeHeat[i] * (0.28 + 0.012 * sp) * dt, 0, 1.2);
        }
    }
    {   // brake light: snaps on, fades off a little slower (handbrake also lights it)
        const double on = (!S.reverse && (S.brake > 0.08 || S.handOn)) ? 1 : 0;
        brakeK += (on - brakeK) * (1 - exp(-(on ? 38 : 9) * dt));
        lastRev = S.reverse;
    }
}

// ---------------- draw ----------------
//  VP = view-projection, Mdl = car model matrix (heading / pitch / roll / position, model frame: nose +X), eye = camera position
static void draw(const float* VP, const float* Mdl, const float* eye, const CarState& S, float night = 0.f){
    float (&MM)[9][16] = gMM; float (&MV)[9][16] = gMV;                                                   // 0 body, 1..4 wheel spin parts, 5..8 calipers
    for (int i = 0; i < 9; i++){ memcpy(MM[i], Mdl, 64); }
    const float steer = (float)S.steerAngle;
    const float WB = (float)Veh::WHEELBASE, TK = (float)Veh::TRACK, tn = std::fabs(std::tan(steer));
    for (int i = 0; i < 4; i++){
        const float cx = wC[i][0], cy = wC[i][1], cz = wC[i][2];
        M4 T1, Ry, Rx, Rz, T0, t; mT(T1, cx, cy + wheelComp[i], cz); mT(T0, -cx, -cy, -cz);
        const bool leftSide = cz < 0.f;                                               // model frame: z < 0 = the side a positive steer turns towards
        if (i < 2){                                                                    // Ackermann: the inner front wheel turns more than the outer one (both roll about the same turn centre)
            const bool inner = (steer > 0.f) == leftSide;
            const float a = std::atan(WB * tn / (inner ? (WB - 0.5f * TK * tn) : (WB + 0.5f * TK * tn)));
            mRY(Ry, steer >= 0.f ? a : -a);
        } else mIdent(Ry);
        // camber: static negative camber (top of the wheel leans in: 1.0 deg front, 1.5 deg rear); a real suspension also keeps ~55 % of the body roll out of the wheel,
        // so on the outside of a corner the tyre stays flatter on the road than the leaning body
        const float cam = (i < 2 ? 0.0175f : 0.0262f) * (leftSide ? 1.f : -1.f) - 0.55f * (float)suspRoll;
        mRX(Rx, cam);
        mRZ(Rz, -(float)(i < 2 ? spinF : spinR));
        mMul(t, T1, Ry); mMul(t, t, Rx); mMul(t, t, T0); mMul(MM[5 + i], Mdl, t);                       // caliper: steers + cambers, does not spin
        mMul(t, T1, Ry); mMul(t, t, Rx); mMul(t, t, Rz); mMul(t, t, T0); mMul(MM[1 + i], Mdl, t);       // tyre + rim: steers, cambers and rolls
    }
    for (int i = 0; i < 9; i++) mMul(MV[i], VP, MM[i]);

    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glDisable(GL_BLEND); glDepthMask(GL_TRUE);
    glUseProgram(gProg); glUniform1f(uInside, 0.f); glUniform1i(uSurf, 0); glUniform3fv(uCam, 1, eye); glUniform1f(uNight, night); glUniform3f(uMulN, 1.f, 1.f, 1.f);
    glBindBuffer(GL_ARRAY_BUFFER, gVBO); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gIBO);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 24, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 24, (void*)12);

    // tail light colours (HTML): red running light -> hot orange-white when braking, white while reversing
    const float run = 0.35f, k = (float)brakeK, strength = lastRev ? 1.6f : run + (5.0f - run) * k;   // brake: much brighter, but it stays RED (not orange-white)
    float tailEm[3], tailCol[3];
    if (lastRev){ tailEm[0] = tailEm[1] = tailEm[2] = 1.f; tailCol[0] = tailCol[1] = tailCol[2] = 1.f; hexLin(0xffffff, tailEm); }
    else { tailEm[0] = 1.f; tailEm[1] = 0.04f + 0.02f * k; tailEm[2] = 0.03f + 0.015f * k; hexLin(0xff2a2a, tailCol); }

    for (int pass = 0; pass < 2; pass++){
        if (pass == 1){                                                                  // soft contact shadow, then the glass on top
            glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); glDepthMask(GL_FALSE);
            glUseProgram(gQuadProg); glUniform1i(qKind, 0); glUniform1f(qOp, 1.f);
            glUniformMatrix4fv(qMVP, 1, GL_FALSE, MV[0]);
            glBindBuffer(GL_ARRAY_BUFFER, gQuadVBO);
            glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 20, (void*)0);
            glEnableVertexAttribArray(1); glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 20, (void*)12);
            glEnable(GL_POLYGON_OFFSET_FILL); glPolygonOffset(-6.f, -6.f); glDrawArrays(GL_TRIANGLES, 0, 6); glDisable(GL_POLYGON_OFFSET_FILL);
            glUseProgram(gProg); glBindBuffer(GL_ARRAY_BUFFER, gVBO); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gIBO);
            glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 24, (void*)0);
            glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 24, (void*)12);
        }
        for (const Item& it : gItems){
            const Mat& m = gMats[it.mat]; if (m.transparent != (pass == 1)) continue;
            glUniformMatrix4fv(uMVP, 1, GL_FALSE, MV[it.tgt]); glUniformMatrix4fv(uModel, 1, GL_FALSE, MM[it.tgt]);
            const float* col = m.col; const float* em = m.emis; float emv[3] = {em[0], em[1], em[2]}; float cv[3] = {col[0], col[1], col[2]};
            if (m.kind == 1){ for (int i = 0; i < 3; i++){ emv[i] = tailEm[i] * strength; cv[i] = tailCol[i]; } }
            if (it.disc){ const float g = discGlow(it.disc - 1); emv[0] = 2.6f * g; emv[1] = 0.46f * g; emv[2] = 0.05f * g; }   // red-hot disc
            glUniform3fv(uCol, 1, cv); glUniform3fv(uEmis, 1, emv);
            glUniform4f(uMR, m.metal, m.rough, m.clear, m.clearRough); glUniform2f(uEnvA, m.envI, m.alpha);
            glDrawElements(GL_TRIANGLES, it.count, GL_UNSIGNED_SHORT, (void*)(intptr_t)(it.start * 2));
        }
    }
    glDepthMask(GL_TRUE); glDisable(GL_BLEND);
}

// ---------------- glow pass: after the night darkening, so the lights stay bright ----------------
//  night > 0: the head / tail light parts are drawn again on top of the dark picture; the brake-light halo is always drawn
static void drawGlow(float night){
    const float k = (float)brakeK;
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glDisable(GL_BLEND); glDepthMask(GL_TRUE);
    if (night > 0.002f){
        glDepthFunc(GL_LEQUAL);
        glUseProgram(gProg); glUniform1f(uNight, night);
        glBindBuffer(GL_ARRAY_BUFFER, gVBO); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gIBO);
        glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 24, (void*)0);
        glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 24, (void*)12);
        const float strength = lastRev ? 1.6f : 0.35f + (5.0f - 0.35f) * k;
        for (const Item& it : gItems){
            const Mat& m = gMats[it.mat]; if (m.transparent || (m.kind == 0 && !(it.disc && discGlow(it.disc - 1) > 0.01f))) continue;
            float emv[3] = {m.emis[0], m.emis[1], m.emis[2]}, cv[3] = {m.col[0], m.col[1], m.col[2]};
            if (m.kind == 1){
                if (lastRev){ hexLin(0xffffff, emv); hexLin(0xffffff, cv); for (int i = 0; i < 3; i++) emv[i] *= strength; }
                else { hexLin(0xff2a2a, cv); emv[0] = strength; emv[1] = (0.04f + 0.02f * k) * strength; emv[2] = (0.03f + 0.015f * k) * strength; }
            }
            if (it.disc){ const float g = discGlow(it.disc - 1); emv[0] = 2.6f * g; emv[1] = 0.46f * g; emv[2] = 0.05f * g; }
            glUniformMatrix4fv(uMVP, 1, GL_FALSE, gMV[it.tgt]); glUniformMatrix4fv(uModel, 1, GL_FALSE, gMM[it.tgt]);
            glUniform3fv(uCol, 1, cv); glUniform3fv(uEmis, 1, emv);
            glUniform4f(uMR, m.metal, m.rough, m.clear, m.clearRough); glUniform2f(uEnvA, m.envI, m.alpha);
            glDrawElements(GL_TRIANGLES, it.count, GL_UNSIGNED_SHORT, (void*)(intptr_t)(it.start * 2));
        }
        glDepthFunc(GL_LESS);
    }
    glEnable(GL_BLEND); glDepthMask(GL_FALSE);
    {   // brake-light halo (additive), brighter while braking
        const float rev = lastRev ? 0.f : 1.f, runOp = 0.05f * rev, op = runOp + (0.82f - runOp) * k * rev;
        glUseProgram(gQuadProg); glUniform1i(qKind, 1); glUniform1f(qOp, op);
        glUniformMatrix4fv(qMVP, 1, GL_FALSE, gMV[0]);
        glBindBuffer(GL_ARRAY_BUFFER, gQuadVBO);
        glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 20, (void*)0);
        glEnableVertexAttribArray(1); glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 20, (void*)12);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE); glDrawArrays(GL_TRIANGLES, 6, 6);
    }
    {   // hot brake discs: a soft orange glow shining out round the rim + a little spill behind the wheel
        glUseProgram(gQuadProg); glUniform1i(qKind, 2);
        glBindBuffer(GL_ARRAY_BUFFER, gQuadVBO);
        glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 20, (void*)0);
        glEnableVertexAttribArray(1); glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 20, (void*)12);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE);
        for (int i = 0; i < 4; i++){
            const float g = discGlow(i); if (g < 0.02f) continue;
            glUniformMatrix4fv(qMVP, 1, GL_FALSE, gMV[5 + i]);
            glUniform1f(qOp, 0.62f * g); glDrawArrays(GL_TRIANGLES, 12 + i * 12, 6);
            glUniform1f(qOp, 0.38f * g); glDrawArrays(GL_TRIANGLES, 18 + i * 12, 6);
        }
    }
    glDepthMask(GL_TRUE); glDisable(GL_BLEND);
}


// =====================================================================================================================
//  COCKPIT / BONNET / DASHBOARD view-model pass (camera modes 2, 3, 4)
//  The camera is rigidly attached to the chassis. The part of the car around the driver is drawn in a SECOND pass with its own projection
//  (near 3 cm) and a squeezed depth range, so it always lies in front of the world (no depth clear: the god-ray / haze depth texture stays valid).
//  Steering wheel = model index range 4959 (657 indices) rotated about its real column axis; gauges + mirror glass are small procedural quads.
// =====================================================================================================================
static const int WHEEL_ST = 4959, WHEEL_CNT = 657;
static const float WHEEL_C[3] = {0.588f, 0.746f, 0.375f}, WHEEL_AX[3] = {0.871f, -0.492f, 0.016f};   // centre + column axis (fitted to the R8 wheel vertices; axis points forward-down)
static const float WHEEL_RATIO = 9.0f, WHEEL_MAX = 5.2f;                                                // road-wheel angle -> steering-wheel angle (full lock 31 deg = ~283 deg), hard limit (rad)
static GLuint gCabProg = 0, gCabVBO = 0; static GLint cMVP, cKind, cVals, cWarn, cNight;
static const char* CAB_VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in vec2 uv; uniform mat4 uMVP; out vec2 vUv; void main(){ vUv = uv; gl_Position = uMVP*vec4(p,1.0); }
)GLSL";
static const char* CAB_FS = R"GLSL(#version 300 es
precision highp float; in vec2 vUv; uniform int uKind; uniform vec4 uVals, uWarn; uniform vec3 uNight; out vec4 o;
// 7-segment digit
float seg(vec2 p, vec2 c, vec2 h){ vec2 d = abs(p - c) - h; return 1.0 - smoothstep(0.0, 0.004, max(d.x, d.y)); }
float digit(vec2 p, int n){   // p in 0..1 box
  int m = n==0?63: n==1?6: n==2?91: n==3?79: n==4?102: n==5?109: n==6?125: n==7?7: n==8?127: n==9?111: n==10?80 : 0;   // 10 = 'r'
  float a = 0.0; vec2 hh = vec2(0.30, 0.045), hv = vec2(0.045, 0.21);
  if ((m &  1)!=0) a = max(a, seg(p, vec2(0.5,0.93), hh));  if ((m &  2)!=0) a = max(a, seg(p, vec2(0.86,0.72), hv));
  if ((m &  4)!=0) a = max(a, seg(p, vec2(0.86,0.28), hv)); if ((m &  8)!=0) a = max(a, seg(p, vec2(0.5,0.07), hh));
  if ((m & 16)!=0) a = max(a, seg(p, vec2(0.14,0.28), hv)); if ((m & 32)!=0) a = max(a, seg(p, vec2(0.14,0.72), hv));
  if ((m & 64)!=0) a = max(a, seg(p, vec2(0.5,0.5), hh));  return a;
}
vec3 dial(vec2 q, float val, float maxv, float redFrom, float major, vec3 acc, out float needle){
  float r = length(q); float ang = atan(q.x, q.y);                     // 0 = straight up, clockwise +
  float t = (ang + 2.356) / 4.712;                                      // -135 deg ... +135 deg -> 0..1
  vec3 c = vec3(0.012, 0.013, 0.016) * smoothstep(0.50, 0.46, r);
  float inArc = step(0.0, t) * step(t, 1.0);
  float nt = maxv / major;                                              // number of major ticks
  float tk = t * nt; float f = abs(fract(tk + 0.5) - 0.5);              // distance to the nearest major tick
  float mt = (1.0 - smoothstep(0.018, 0.030, f)) * smoothstep(0.30, 0.33, r) * smoothstep(0.47, 0.44, r) * inArc;
  float mn = (1.0 - smoothstep(0.045, 0.07, abs(fract(tk * 2.0 + 0.5) - 0.5))) * smoothstep(0.38, 0.40, r) * smoothstep(0.47, 0.44, r) * inArc;
  bool red = t * maxv >= redFrom;
  c += (red ? vec3(1.0, 0.12, 0.08) : vec3(0.92, 0.94, 0.98)) * (mt + 0.5 * mn);
  float ring = smoothstep(0.015, 0.0, abs(r - 0.485)) * 0.35; c += acc * ring;
  float tv = clamp(val / maxv, 0.0, 1.0); float aN = -2.356 + tv * 4.712;
  vec2 d = vec2(sin(aN), cos(aN)); float along = dot(q, d), perp = abs(dot(q, vec2(d.y, -d.x)));
  needle = step(-0.04, along) * step(along, 0.44) * (1.0 - smoothstep(0.008, 0.016, perp)) * (1.0 - smoothstep(0.0, 0.5, along) * 0.35);
  c += acc * smoothstep(0.075, 0.06, r) * 0.6;
  return c;
}
void main(){
  vec3 col; float a = 1.0;
  if (uKind == 1){   // mirror glass: cheap sky / road reflection (no render-to-texture: costs nothing)
    float y = vUv.y; col = mix(vec3(0.32, 0.36, 0.30), vec3(0.58, 0.74, 0.92), smoothstep(0.40, 0.60, y)) * (0.80 + 0.2 * vUv.x);
    col = mix(col, vec3(0.9, 0.95, 1.0), smoothstep(0.78, 1.0, y) * 0.25); col *= uNight; o = vec4(col, 1.0); return;
  }
  if (uKind >= 2){   // extra dash parts: 2 air vent, 3 climate strip, 4 gear buttons
    vec2 q; float sdf; vec3 c;
    if (uKind == 2){
      q = vec2((vUv.x - 0.5)*2.83, vUv.y - 0.5); sdf = length(max(abs(q) - vec2(0.915, 0.0), 0.0)) - 0.5; if (sdf > 0.0) discard;
      float ring = smoothstep(-0.09, -0.06, sdf); c = mix(vec3(0.012), vec3(0.20, 0.20, 0.21)*(0.6 + 0.8*smoothstep(-0.3, 0.4, q.y)), ring);
      if (ring < 0.5){ float k = fract((q.y + 0.5)*5.0); float sl = smoothstep(0.2, 0.3, k)*smoothstep(0.8, 0.7, k); c = mix(vec3(0.004), vec3(0.05) + vec3(0.22)*smoothstep(0.72, 0.8, k), sl); }
    } else if (uKind == 3){
      q = vec2((vUv.x - 0.5)*5.0, vUv.y - 0.5); vec2 ad = abs(q) - vec2(2.42, 0.44); sdf = max(ad.x, ad.y); if (sdf > 0.0) discard;
      c = mix(vec3(0.012, 0.012, 0.014), vec3(0.22), smoothstep(-0.06, -0.03, sdf));
      for (int s = 0; s < 2; s++){ float sg = s == 0 ? -1.0 : 1.0; vec2 p = (q - vec2(sg*1.75, 0.0))/vec2(0.55, 0.30) + 0.5;
        if (p.x > 0.0 && p.x < 1.0 && p.y > 0.0 && p.y < 1.0){ float dg = p.x < 0.5 ? digit(vec2(p.x*2.0, p.y), 2) : digit(vec2(p.x*2.0 - 1.0, p.y), s == 0 ? 1 : 2); c = mix(c, vec3(1.0, 0.45, 0.1), dg); } }
      for (int k = 0; k < 3; k++){ vec2 kq = q - vec2((float(k) - 1.0)*0.62, 0.0); float r = length(kq);
        float kn = 1.0 - smoothstep(0.26, 0.28, r); vec3 kc = vec3(0.07 + 0.05*sin(atan(kq.y, kq.x)*40.0)) + vec3(0.18)*smoothstep(0.26, 0.2, r)*step(r, 0.27)*0.0;
        kc += vec3(0.5)*step(0.18, r)*step(r, 0.2)*smoothstep(0.06, 0.0, abs(atan(kq.x, kq.y) + 0.6)); c = mix(c, kc, kn); }
    } else if (uKind == 5){   // start button
      q = (vUv - 0.5)*2.0; float r = length(q); if (r > 1.0) discard;
      c = r > 0.82 ? vec3(0.28) : mix(vec3(0.30, 0.01, 0.01), vec3(0.75, 0.04, 0.03), smoothstep(0.7, 0.0, length(q - vec2(-0.25, 0.3))));
      c += vec3(0.5)*smoothstep(0.22, 0.0, length(q - vec2(-0.3, 0.38)))*step(r, 0.8);
    } else if (uKind == 6){   // drive-select dial
      q = (vUv - 0.5)*2.0; float r = length(q); if (r > 1.0) discard;
      c = r > 0.62 ? vec3(0.12 + 0.10*sin(atan(q.y, q.x)*36.0)) : vec3(0.012);
      c = r > 0.93 ? vec3(0.30) : c; c = mix(c, vec3(0.2, 1.0, 0.5), step(abs(q.x), 0.07)*step(0.2, q.y)*step(q.y, 0.52)*step(r, 0.62));
    } else if (uKind == 7){   // aluminium paddle shifter
      q = (vUv - 0.5)*2.0; vec2 d = abs(q) - vec2(0.88, 0.72); sdf = length(max(d, 0.0)) + min(max(d.x, d.y), 0.0) - 0.12; if (sdf > 0.0) discard;
      float st = 0.5 + 0.5*sin(vUv.y*260.0 + sin(vUv.x*9.0)*2.0);
      c = vec3(0.40, 0.41, 0.43)*(0.72 + 0.28*st)*(0.6 + 0.6*smoothstep(-0.7, 0.7, q.y)); c = sdf > -0.10 ? vec3(0.07) : c;
      c = mix(c, vec3(0.03), smoothstep(0.08, 0.0, abs(q.y + 0.35))*0.8*step(abs(q.x), 0.5));
    } else {
      q = vec2((vUv.x - 0.5)*1.333, vUv.y - 0.5); vec2 ad = abs(q) - vec2(0.64, 0.46); sdf = max(ad.x, ad.y); if (sdf > 0.0) discard;
      c = mix(vec3(0.006), vec3(0.18), smoothstep(-0.05, -0.02, sdf));
      int act = uVals.z < -0.5 ? 1 : (uVals.z < 0.5 ? 2 : 3);
      for (int k = 0; k < 4; k++){ vec2 bq = q - vec2(-0.45 + 0.30*float(k), 0.0); vec2 bd = abs(bq) - vec2(0.115, 0.17); float bs = max(bd.x, bd.y);
        if (bs < 0.0){ vec3 bc = mix(vec3(0.02), vec3(0.14), smoothstep(-0.02, 0.0, bs)); float led = step(abs(bq.x), 0.07)*step(abs(bq.y - 0.09), 0.025);
          bc = mix(bc, k == act ? vec3(0.3, 1.0, 0.55) : vec3(0.05), led); c = bc; } }
    }
    c *= uNight; o = vec4(c, 1.0); return;
  }
  // instrument cluster: panel is 2 : 1
  vec2 p = vec2(vUv.x * 2.0, vUv.y);
  col = vec3(0.01, 0.011, 0.014);
  float nd; vec3 c1 = dial((p - vec2(0.55, 0.50)) / 0.95, uVals.x, 9000.0, 7200.0, 1000.0, vec3(1.0, 0.45, 0.1), nd); float n1 = nd;      // rpm (left)
  vec3 c2 = dial((p - vec2(1.45, 0.50)) / 0.95, uVals.y, 360.0, 9999.0, 40.0, vec3(0.2, 0.75, 1.0), nd); float n2 = nd;                      // speed (right)
  col += c1 + c2;
  col = mix(col, vec3(1.0, 0.25, 0.10), n1) ; col = mix(col, vec3(0.2, 0.85, 1.0), n2);
  // gear (centre) + digital speed under the right dial
  int g = int(floor(uVals.z + 0.5)); float gd = digit((p - vec2(0.86, 0.34)) / vec2(0.28, 0.32), g < 0 ? 10 : g); col = mix(col, vec3(0.3, 1.0, 0.6), gd * step(0.0, p.x - 0.86) * step(p.x, 1.14));
  int kmh = int(uVals.y + 0.5); vec2 sp = p - vec2(1.28, 0.20);
  for (int i = 0; i < 3; i++){ int dv = i == 0 ? (kmh / 100) % 10 : (i == 1 ? (kmh / 10) % 10 : kmh % 10); vec2 q = (sp - vec2(float(i) * 0.10, 0.0)) / vec2(0.09, 0.13);
    if (q.x >= 0.0 && q.x <= 1.0 && q.y >= 0.0 && q.y <= 1.0 && !(i == 0 && kmh < 100) && !(i == 1 && kmh < 10)) col = mix(col, vec3(0.9, 0.95, 1.0), digit(q, dv)); }
  // warning lights (ABS, TCS, ESC, handbrake) along the top + shift light
  for (int i = 0; i < 5; i++){ float on = i == 0 ? uWarn.x : (i == 1 ? uWarn.y : (i == 2 ? uWarn.z : (i == 3 ? uWarn.w : uVals.w)));
    vec3 lc = i == 3 ? vec3(1.0, 0.1, 0.1) : (i == 4 ? vec3(0.3, 0.6, 1.0) : vec3(1.0, 0.7, 0.05)); vec2 q = p - vec2(0.80 + float(i) * 0.10, 0.93);
    col = mix(col, lc * (0.12 + 0.88 * on), 1.0 - smoothstep(0.030, 0.038, length(q))); }
  col *= uNight; o = vec4(col, 1.0);
}
)GLSL";

static void cabinInit(){
    gCabProg = prog(CAB_VS, CAB_FS);
    cMVP = glGetUniformLocation(gCabProg, "uMVP"); cKind = glGetUniformLocation(gCabProg, "uKind"); cVals = glGetUniformLocation(gCabProg, "uVals");
    cWarn = glGetUniformLocation(gCabProg, "uWarn"); cNight = glGetUniformLocation(gCabProg, "uNight");
    // quad 0: instrument cluster (30 x 15 cm, faces the driver, tilted like the wheel column);  quads 1, 2: side-mirror glass (driver side + passenger side);  quad 3: rear-view mirror glass
    std::vector<float> v;
    auto quad = [&](const float* c, const float* r, const float* u, float hw, float hh){
        const float P[4][2] = {{-1,-1},{1,-1},{1,1},{-1,1}}, UV[4][2] = {{0,0},{1,0},{1,1},{0,1}}; const int I[6] = {0,1,2,0,2,3};
        for (int k = 0; k < 6; k++){ const int i = I[k]; for (int a = 0; a < 3; a++) v.push_back(c[a] + r[a] * hw * P[i][0] + u[a] * hh * P[i][1]); v.push_back(UV[i][0]); v.push_back(UV[i][1]); }
    };
    { const float c[3] = {0.700f, 0.830f, 0.375f}, r[3] = {0, 0, 1}, u[3] = {0.37f, 0.93f, 0}; quad(c, r, u, 0.15f, 0.075f); }
    { const float c[3] = {0.668f, 0.885f, 0.985f}, r[3] = {0, 0, 1}, u[3] = {0, 1, 0}; quad(c, r, u, 0.060f, 0.040f); }
    { const float c[3] = {0.668f, 0.885f, -0.985f}, r[3] = {0, 0, -1}, u[3] = {0, 1, 0}; quad(c, r, u, 0.060f, 0.040f); }
    { const float c[3] = {0.598f, 1.108f, 0.0f}, r[3] = {0, 0, 1}, u[3] = {0, 1, 0}; quad(c, r, u, 0.085f, 0.028f); }
    auto surfQuad = [&](const float* p, const float* n, float hw, float hh){ const float u[3] = {n[1], -n[0], 0.f}, r[3] = {0, 0, 1}; const float c[3] = {p[0] + n[0]*0.008f, p[1] + n[1]*0.008f, p[2] + n[2]*0.008f}; quad(c, r, u, hw, hh); };
    { const float p[3] = {0.773f, 0.715f, -0.62f}, n[3] = {-0.692f, 0.721f, 0.f}; surfQuad(p, n, 0.085f, 0.030f); }
    { const float p[3] = {0.762f, 0.715f, -0.30f}, n[3] = {-0.632f, 0.775f, 0.f}; surfQuad(p, n, 0.085f, 0.030f); }
    { const float p[3] = {0.667f, 0.640f, 0.00f}, n[3] = {-0.764f, 0.645f, 0.f}; surfQuad(p, n, 0.150f, 0.030f); }
    { const float c[3] = {0.45f, 0.509f, 0.f}, r[3] = {0, 0, 1}, u[3] = {1, 0, 0}; quad(c, r, u, 0.08f, 0.06f); }
    {   // steering-wheel parts (wheel-local frame): start button, drive-select dial, hub; two column-mounted paddles behind the rim
        float ax[3] = {WHEEL_AX[0], WHEEL_AX[1], WHEEL_AX[2]}; { const float l = std::sqrt(ax[0]*ax[0] + ax[1]*ax[1] + ax[2]*ax[2]); for (float& x : ax) x /= l; }
        float up[3] = {-ax[1]*ax[0], 1.f - ax[1]*ax[1], -ax[1]*ax[2]}; { const float l = std::sqrt(up[0]*up[0] + up[1]*up[1] + up[2]*up[2]); for (float& x : up) x /= l; }
        const float sv[3] = {ax[1]*up[2] - ax[2]*up[1], ax[2]*up[0] - ax[0]*up[2], ax[0]*up[1] - ax[1]*up[0]};
        auto at = [&](float th, float rho, float a, float* o){ for (int k = 0; k < 3; k++) o[k] = WHEEL_C[k] + ax[k]*a + (up[k]*std::cos(th) + sv[k]*std::sin(th))*rho; };
        { float c[3]; at(-2.2f, 0.058f, -0.0565f, c); quad(c, sv, up, 0.012f, 0.012f); }
        { float c[3]; at(2.2f, 0.058f, -0.0565f, c); quad(c, sv, up, 0.015f, 0.015f); }
        for (int sgn = -1; sgn <= 1; sgn += 2){ const float th = 1.85f*sgn; float c[3]; at(th, 0.19f, 0.035f, c);
            const float d[3] = {up[0]*std::cos(th) + sv[0]*std::sin(th), up[1]*std::cos(th) + sv[1]*std::sin(th), up[2]*std::cos(th) + sv[2]*std::sin(th)};
            const float t[3] = {-up[0]*std::sin(th) + sv[0]*std::cos(th), -up[1]*std::sin(th) + sv[1]*std::cos(th), -up[2]*std::sin(th) + sv[2]*std::cos(th)};
            quad(c, t, d, 0.034f, 0.013f); }
    }
    glGenBuffers(1, &gCabVBO); glBindBuffer(GL_ARRAY_BUFFER, gCabVBO); glBufferData(GL_ARRAY_BUFFER, v.size() * 4, v.data(), GL_STATIC_DRAW);
    wheelMeshInit();
}

// ---------------- procedural steering wheel (replaces the low-poly R8 wheel in the cockpit views) ----------------
//  wheel frame: centre WHEEL_C, axis WHEEL_AX (points away from the driver), th = 0 at 12 o'clock.  Flat-bottom leather rim, 3 aluminium spokes, domed airbag hub, trim ring, column shroud.
struct WSeg { int start, count, region; };
static GLuint gWVBO = 0, gWIBO = 0; static std::vector<WSeg> gWSeg;
static void wheelMeshInit(){
    float ax[3] = {WHEEL_AX[0], WHEEL_AX[1], WHEEL_AX[2]}; { const float l = std::sqrt(ax[0]*ax[0] + ax[1]*ax[1] + ax[2]*ax[2]); for (float& x : ax) x /= l; }
    float up[3] = {-ax[1]*ax[0], 1.f - ax[1]*ax[1], -ax[1]*ax[2]}; { const float l = std::sqrt(up[0]*up[0] + up[1]*up[1] + up[2]*up[2]); for (float& x : up) x /= l; }
    const float sv[3] = {ax[1]*up[2] - ax[2]*up[1], ax[2]*up[0] - ax[0]*up[2], ax[0]*up[1] - ax[1]*up[0]};
    const float PI_ = 3.14159265f;
    std::vector<float> vb; std::vector<uint16_t> ib;
    auto D = [&](float th, float* d){ for (int k = 0; k < 3; k++) d[k] = up[k]*std::cos(th) + sv[k]*std::sin(th); };
    auto T = [&](float th, float* t){ for (int k = 0; k < 3; k++) t[k] = -up[k]*std::sin(th) + sv[k]*std::cos(th); };
    auto nrm = [&](float* n){ const float l = std::sqrt(n[0]*n[0] + n[1]*n[1] + n[2]*n[2]); if (l > 1e-9f) for (int k = 0; k < 3; k++) n[k] /= l; };
    auto begin = [&](int region){ gWSeg.push_back({(int)ib.size(), 0, region}); };
    auto end = [&](){ gWSeg.back().count = (int)ib.size() - gWSeg.back().start; };
    auto surf = [&](int nu, int nv, const std::function<void(float, float, float*, float*, float*)>& f){
        const int base = (int)(vb.size() / 9);
        for (int i = 0; i <= nu; i++) for (int j = 0; j <= nv; j++){
            float p[3], n[3], x[3]; f((float)i / nu, (float)j / nv, p, n, x); nrm(n);
            vb.insert(vb.end(), {p[0], p[1], p[2], n[0], n[1], n[2], x[0], x[1], x[2]}); }
        for (int i = 0; i < nu; i++) for (int j = 0; j < nv; j++){
            const int a = base + i*(nv + 1) + j, b = a + 1, c = a + (nv + 1), d = c + 1;
            for (int q : {a, c, b, b, c, d}) ib.push_back((uint16_t)q); }
    };
    auto place = [&](float a, const float* d, float rho, const float* t, float tw, float* p){ for (int k = 0; k < 3; k++) p[k] = WHEEL_C[k] + ax[k]*a + d[k]*rho + (t ? t[k]*tw : 0.f); };
    // rim (region 4): flat bottom, thicker grips at 3 / 9 o'clock
    begin(4); surf(128, 24, [&](float u, float v, float* p, float* n, float* x){
        const float th = (u*2.f - 1.f)*PI_, phi = v*2.f*PI_ - PI_, cb = -std::cos(th);
        float rc = 0.152f; if (cb > 1e-4f) rc = std::min(rc, 0.128f / cb);
        const float sw = std::fabs(std::sin(th)), rr = 0.0255f + 0.004f*sw, ra = 0.032f + 0.004f*sw, cp = std::cos(phi), sp = std::sin(phi);
        float d[3]; D(th, d); place(-0.023f + ra*sp, d, rc + rr*cp, nullptr, 0.f, p);
        for (int k = 0; k < 3; k++) n[k] = d[k]*(cp / rr) + ax[k]*(sp / ra);
        x[0] = th; x[1] = phi; x[2] = 0.f; });
    end();
    // airbag hub: dome + side wall (region 6)
    begin(6);
    surf(10, 48, [&](float u, float v, float* p, float* n, float* x){
        const float th = v*2.f*PI_ - PI_, rho = u*0.085f, kk = 1.94f; float d[3]; D(th, d);
        place(-0.058f + kk*rho*rho, d, rho, nullptr, 0.f, p); for (int k = 0; k < 3; k++) n[k] = -ax[k] + d[k]*(2.f*kk*rho); x[0] = th; x[1] = 0.f; x[2] = 0.f; });
    surf(2, 48, [&](float u, float v, float* p, float* n, float* x){
        const float th = v*2.f*PI_ - PI_; float d[3]; D(th, d); place(-0.044f + u*0.024f, d, 0.085f, nullptr, 0.f, p); for (int k = 0; k < 3; k++) n[k] = d[k]; x[0] = th; x[1] = 0.f; x[2] = 0.f; });
    end();
    // aluminium (region 7): trim ring round the hub + three spokes (left, right, bottom)
    begin(7);
    surf(8, 48, [&](float u, float v, float* p, float* n, float* x){
        const float th = v*2.f*PI_ - PI_, ph = u*2.f*PI_, c = std::cos(ph), sn = std::sin(ph); float d[3]; D(th, d);
        place(-0.042f + 0.004f*sn, d, 0.0875f + 0.004f*c, nullptr, 0.f, p); for (int k = 0; k < 3; k++) n[k] = d[k]*c + ax[k]*sn; x[0] = th; x[1] = 0.f; x[2] = 0.f; });
    const float ths[3] = {-1.72f, 1.72f, PI_}, rEnd[3] = {0.145f, 0.145f, 0.112f};
    for (int si = 0; si < 3; si++){
        const float ths_ = ths[si], re = rEnd[si];
        surf(8, 12, [&](float u, float v, float* p, float* n, float* x){
            const float ps = v*2.f*PI_, c = std::cos(ps), sn = std::sin(ps), wt = 0.020f - 0.008f*u, hb = 0.010f; float d[3], t[3]; D(ths_, d); T(ths_, t);
            place(-0.034f + hb*sn, d, 0.085f + u*(re - 0.085f), t, wt*c, p);
            for (int k = 0; k < 3; k++) n[k] = t[k]*(c / wt) + ax[k]*(sn / hb); x[0] = ths_; x[1] = 0.f; x[2] = 0.f; });
    }
    end();
    // column shroud (region 8)
    begin(8); surf(6, 24, [&](float u, float v, float* p, float* n, float* x){
        const float th = v*2.f*PI_ - PI_; float d[3]; D(th, d); place(-0.02f + u*0.40f, d, 0.060f, nullptr, 0.f, p); for (int k = 0; k < 3; k++) n[k] = d[k]; x[0] = th; x[1] = 0.f; x[2] = 0.f; });
    end();
    glGenBuffers(1, &gWVBO); glBindBuffer(GL_ARRAY_BUFFER, gWVBO); glBufferData(GL_ARRAY_BUFFER, vb.size() * 4, vb.data(), GL_STATIC_DRAW);
    glGenBuffers(1, &gWIBO); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gWIBO); glBufferData(GL_ELEMENT_ARRAY_BUFFER, ib.size() * 2, ib.data(), GL_STATIC_DRAW);
}
// draws the procedural wheel with the program already bound (gProg); MV = VPc * wheel rotation, MM = chassis * wheel rotation
static void drawWheelMesh(const float* MV, const float* MM){
    glBindBuffer(GL_ARRAY_BUFFER, gWVBO); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gWIBO);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 36, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 36, (void*)12);
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 36, (void*)24);
    glUniformMatrix4fv(uMVP, 1, GL_FALSE, MV); glUniformMatrix4fv(uModel, 1, GL_FALSE, MM);
    const float zero[3] = {0, 0, 0};
    for (const WSeg& sg : gWSeg){
        float col[3] = {0.02f, 0.02f, 0.022f}; float me = 0.05f, ro = 0.50f, cl = 1.f, cr = 0.25f, ei = 0.7f; int surf = sg.region;
        if (sg.region == 7){ col[0] = 0.62f; col[1] = 0.63f; col[2] = 0.65f; me = 0.95f; ro = 0.30f; cl = 0.f; cr = 0.f; ei = 1.2f; }
        else if (sg.region == 8){ col[0] = col[1] = col[2] = 0.012f; me = 0.1f; ro = 0.6f; cl = 0.f; cr = 0.f; ei = 0.3f; }
        glUniform1i(uSurf, surf); glUniform3fv(uCol, 1, col); glUniform3fv(uEmis, 1, zero); glUniform4f(uMR, me, ro, cl, cr); glUniform2f(uEnvA, ei, 1.f);
        glDrawElements(GL_TRIANGLES, sg.count, GL_UNSIGNED_SHORT, (void*)(intptr_t)(sg.start * 2));
    }
    glDisableVertexAttribArray(2); glUniform1i(uSurf, 0);
    glBindBuffer(GL_ARRAY_BUFFER, gVBO); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gIBO);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 24, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 24, (void*)12);
}

//  VPc = projection * (chassis-local -> camera view), Mdl = chassis world matrix, mode 2 bonnet / 3 cockpit / 4 dashboard, wheelRad = steering wheel rotation (rad, + = turning left)
static void drawCabin(const float* VPc, const float* Mdl, const float* eye, const CarState& S, float night, int mode, float wheelRad){
    const bool inside = mode >= 3;
    const float k = night; const float mn[3] = {1 - k * (1 - 0.13f), 1 - k * (1 - 0.17f), 1 - k * (1 - 0.30f)};
    // steering wheel matrix (local): rotate about the column axis through the wheel centre
    M4 W, T1, T0, R; mT(T1, WHEEL_C[0], WHEEL_C[1], WHEEL_C[2]); mT(T0, -WHEEL_C[0], -WHEEL_C[1], -WHEEL_C[2]);
    {   // Rodrigues rotation about the unit axis n by angle -wheelRad (axis points away from the driver, so left steering = + = counter-clockwise seen by the driver)
        float n[3] = {WHEEL_AX[0], WHEEL_AX[1], WHEEL_AX[2]}; const float l = std::sqrt(n[0]*n[0] + n[1]*n[1] + n[2]*n[2]); for (float& x : n) x /= l;
        const float a = -wheelRad, c = std::cos(a), s = std::sin(a), t = 1 - c; mIdent(R);
        R[0] = t*n[0]*n[0] + c;        R[4] = t*n[0]*n[1] - s*n[2]; R[8]  = t*n[0]*n[2] + s*n[1];
        R[1] = t*n[0]*n[1] + s*n[2];   R[5] = t*n[1]*n[1] + c;      R[9]  = t*n[1]*n[2] - s*n[0];
        R[2] = t*n[0]*n[2] - s*n[1];   R[6] = t*n[1]*n[2] + s*n[0]; R[10] = t*n[2]*n[2] + c;
    }
    mMul(W, T1, R); mMul(W, W, T0);
    M4 MVw, MMw; mMul(MVw, VPc, W); mMul(MMw, Mdl, W);

    glEnable(GL_DEPTH_TEST); glDepthFunc(GL_LESS); glDisable(GL_CULL_FACE); glDisable(GL_BLEND); glDepthMask(GL_TRUE); glDepthRangef(0.f, 0.01f);
    glUseProgram(gProg); glUniform1f(uInside, inside ? 1.f : 0.f); glUniform1i(uSurf, 0); glUniform3fv(uCam, 1, eye); glUniform1f(uNight, night); glUniform3f(uMulN, mn[0], mn[1], mn[2]);
    glBindBuffer(GL_ARRAY_BUFFER, gVBO); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gIBO);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 24, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 24, (void*)12);
    for (int pass = 0; pass < 2; pass++){
        if (pass == 0 && inside) drawWheelMesh(MVw, MMw);
        if (pass == 1){ glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); glDepthMask(GL_FALSE); }
        for (size_t ii = 0; ii < gItems.size(); ii++){
            const Item& it = gItems[ii]; const Mat& m = gMats[it.mat]; const std::array<float,6>& b = gBB[ii];
            if (it.tgt != 0 || it.disc || m.kind == 1 || m.kind == 2) continue;               // wheels, calipers, discs and lamp meshes are not part of this view
            if (m.transparent != (pass == 1)) continue;
            if (b[3] < -0.7f || b[4] < 0.12f) continue;                                         // everything behind the seats (engine bay, tail) and the underbody: never visible from here
            const bool isWheel = it.start == WHEEL_ST && it.count == WHEEL_CNT; if (isWheel && inside) continue;   // replaced by the procedural wheel
            glUniformMatrix4fv(uMVP, 1, GL_FALSE, isWheel ? MVw : VPc); glUniformMatrix4fv(uModel, 1, GL_FALSE, isWheel ? MMw : Mdl);
            float cv[3] = {m.col[0], m.col[1], m.col[2]}, emv[3] = {m.emis[0], m.emis[1], m.emis[2]}; float me = m.metal, ro = m.rough, cl = m.clear, cr = m.clearRough, ei = m.envI, al = m.alpha;
            if (inside && m.clear > 0.5f && m.metal > 0.2f && m.metal < 0.3f && b[1] > 0.78f && b[3] < 1.2f){   // body paint seen from inside (roof, A-pillars, frame): dark matte trim
                cv[0] = 0.025f; cv[1] = 0.026f; cv[2] = 0.03f; me = 0.f; ro = 0.65f; cl = 0.f; ei = 0.25f; }
            if (inside && m.metal == 0.f && m.rough > 0.8f && m.rough < 0.9f && m.envI < 0.4f){   // interior fabrics: seats / dash = soft-sheen leather, roof liner = matte alcantara
                const bool liner = m.col[0] < 0.03f && b[4] > 1.0f && b[1] > 0.75f;
                if (liner){ ro = 1.f; ei = 0.08f; } else { ro = 0.48f; cl = 0.3f; cr = 0.32f; ei = 0.55f; if (cv[0] < 0.02f){ cv[0] = 0.028f; cv[1] = 0.027f; cv[2] = 0.026f; } } }
            if (isWheel){ cv[0] = cv[1] = cv[2] = 0.02f; me = 0.05f; ro = 0.45f; cl = 1.f; cr = 0.25f; ei = 0.7f; }    // dark leather, a little sheen
            if (m.transparent){ al = inside ? 0.12f : 0.30f; ei = 0.6f; }                       // clear glass: the driver sees the road
            int surf = 0;
            if (inside){
                if (isWheel) surf = 4;
                else if (m.metal == 0.f && m.rough > 0.8f && m.rough < 0.9f && m.envI < 0.4f){
                    const bool liner = m.col[0] < 0.03f && b[4] > 1.0f && b[1] > 0.75f;
                    surf = liner ? 3 : ((it.start == 7116 || it.start == 7086) ? 2 : 1);
                } else if (m.kind == 0 && m.metal > 0.4f && m.metal < 0.6f && b[1] > 0.70f && b[0] > 0.3f && b[3] < 1.4f){ surf = 1; me = 0.f; ro = 0.55f; cl = 0.15f; cr = 0.3f; }
            }
            glUniform1i(uSurf, surf);
            glUniform3fv(uCol, 1, cv); glUniform3fv(uEmis, 1, emv); glUniform4f(uMR, me, ro, cl, cr); glUniform2f(uEnvA, ei, al);
            glDrawElements(GL_TRIANGLES, it.count, GL_UNSIGNED_SHORT, (void*)(intptr_t)(it.start * 2));
        }
        if (pass == 0){   // instrument cluster + mirror glass (opaque, drawn before the glass)
            glUseProgram(gCabProg); glUniformMatrix4fv(cMVP, 1, GL_FALSE, VPc); glUniform3f(cNight, mn[0], mn[1], mn[2]);
            glBindBuffer(GL_ARRAY_BUFFER, gCabVBO);
            glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 20, (void*)0);
            glEnableVertexAttribArray(1); glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 20, (void*)12);
            const double sp = std::fabs(S.speed) * 3.6;
            glUniform1i(cKind, 0); glUniform4f(cVals, (float)S.rpm, (float)sp, S.reverse ? -1.f : (float)S.gear, S.limiter || S.rpm > 6600 ? 1.f : 0.f);
            glUniform4f(cWarn, (float)clampd(S.absAct * 3.0, 0, 1), (float)clampd(S.tcsAct * 3.0, 0, 1), (float)clampd(S.escAct * 3.0, 0, 1), (float)clampd(std::max(S.hb, S.handOn ? 1.0 : 0.0), 0, 1));
            glDrawArrays(GL_TRIANGLES, 0, 6);
            glUniform1i(cKind, 1); glDrawArrays(GL_TRIANGLES, 6, 18);
            if (inside){ glUniform1i(cKind, 2); glDrawArrays(GL_TRIANGLES, 24, 12); glUniform1i(cKind, 3); glDrawArrays(GL_TRIANGLES, 36, 6); glUniform1i(cKind, 4); glDrawArrays(GL_TRIANGLES, 42, 6);
                glUniformMatrix4fv(cMVP, 1, GL_FALSE, MVw); glUniform1i(cKind, 5); glDrawArrays(GL_TRIANGLES, 48, 6); glUniform1i(cKind, 6); glDrawArrays(GL_TRIANGLES, 54, 6);
                glUniformMatrix4fv(cMVP, 1, GL_FALSE, VPc); glUniform1i(cKind, 7); glDrawArrays(GL_TRIANGLES, 60, 12); }
            glUseProgram(gProg); glBindBuffer(GL_ARRAY_BUFFER, gVBO); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gIBO);
            glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 24, (void*)0);
            glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 24, (void*)12);
        }
    }
    glUniform3f(uMulN, 1.f, 1.f, 1.f); glUniform1i(uSurf, 0); glUniform1f(uInside, 0.f); glDepthRangef(0.f, 1.f); glDepthMask(GL_TRUE); glDisable(GL_BLEND);
}

} // namespace CarGL
