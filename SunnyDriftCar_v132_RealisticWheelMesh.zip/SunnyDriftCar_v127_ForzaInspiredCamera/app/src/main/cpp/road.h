// Sunny Drift - road network: a hierarchical valley road system (junction to junction) over the whole valley, plus the same three.js CatmullRom / buildStrip geometry as the HTML game (pure C++, no OpenGL).
//  * the road web = a short table of junction nodes + a table of roads (each road is a Catmull-Rom curve through hand-placed points, from junction to junction; T / Y / X junctions with kerb returns only on the corners that really exist)
//  * roadClearance() / surfaceAt() are used by the trees and by the car's grip
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <unordered_map>
#include <vector>
#include "river.h"

namespace Road {
static float gPark[3] = {0.f, 0.f, 0.f};   // PARKING_AREA on the hill summit: centre x, z and the radius of the asphalt ring (0 = none); the road shader paints the bays


const double ROAD_SURF = 0.08;                        // height of the road surface
const double PI = 3.14159265358979323846;

struct V3 { double x = 0, y = 0, z = 0; };
static inline V3 vsub(const V3& a, const V3& b){ return {a.x - b.x, a.y - b.y, a.z - b.z}; }
static inline double dist2(const V3& a, const V3& b){ V3 d = vsub(a, b); return d.x*d.x + d.y*d.y + d.z*d.z; }
static inline double jsRound(double v){ return std::floor(v + 0.5); }          // JS Math.round

// ---------- three.js CatmullRomCurve3 (centripetal) ----------
struct Curve {
    std::vector<V3> pts; bool closed = true, open = false; double hw = 0;
    double rA = 0, rB = 0;                             // half-width of the road it joins at its start / end (junction fillet), 0 = none
    int fA = 0, fB = 0;                                // which corners of the start / end junction have a kerb return: bit 0 = the +normal side of the road, bit 1 = the other side
    std::vector<double> lens;                          // cumulative arc lengths, 200 divisions (Curve.getLengths)

    static double cr(double x0, double x1, double x2, double x3, double dt0, double dt1, double dt2, double t){
        double t1 = (x1 - x0) / dt0 - (x2 - x0) / (dt0 + dt1) + (x2 - x1) / dt1;
        double t2 = (x2 - x1) / dt1 - (x3 - x1) / (dt1 + dt2) + (x3 - x2) / dt2;
        t1 *= dt1; t2 *= dt1;
        double c0 = x1, c1 = t1, c2 = -3*x1 + 3*x2 - 2*t1 - t2, c3 = 2*x1 - 2*x2 + t1 + t2;
        return c0 + c1*t + c2*t*t + c3*t*t*t;
    }
    V3 getPoint(double t) const {
        const long l = (long)pts.size();
        double p = (double)(l - (closed ? 0 : 1)) * t;
        long ip = (long)std::floor(p); double w = p - (double)ip;
        if (closed){ if (!(ip > 0)) ip += (long)(std::floor(std::fabs((double)ip) / (double)l) + 1) * l; }
        else if (w == 0 && ip == l - 1){ ip = l - 2; w = 1; }
        V3 p0, p3;
        if (closed || ip > 0) p0 = pts[(ip - 1) % l];
        else { const V3 &a = pts[0], &b = pts[1]; p0 = {2*a.x - b.x, 2*a.y - b.y, 2*a.z - b.z}; }
        const V3 p1 = pts[ip % l], p2 = pts[(ip + 1) % l];
        if (closed || ip + 2 < l) p3 = pts[(ip + 2) % l];
        else { const V3 &a = pts[l-1], &b = pts[l-2]; p3 = {2*a.x - b.x, 2*a.y - b.y, 2*a.z - b.z}; }
        double dt0 = std::pow(dist2(p0, p1), 0.25), dt1 = std::pow(dist2(p1, p2), 0.25), dt2 = std::pow(dist2(p2, p3), 0.25);
        if (dt1 < 1e-4) dt1 = 1.0;
        if (dt0 < 1e-4) dt0 = dt1;
        if (dt2 < 1e-4) dt2 = dt1;
        return { cr(p0.x, p1.x, p2.x, p3.x, dt0, dt1, dt2, w), cr(p0.y, p1.y, p2.y, p3.y, dt0, dt1, dt2, w), cr(p0.z, p1.z, p2.z, p3.z, dt0, dt1, dt2, w) };
    }
    void build(){
        const int DIV = 200; lens.assign(1, 0.0); V3 last = getPoint(0); double sum = 0;
        for (int p = 1; p <= DIV; p++){ V3 c = getPoint((double)p / DIV); sum += std::sqrt(dist2(c, last)); lens.push_back(sum); last = c; }
    }
    double length() const { return lens.back(); }
    double utoT(double u) const {                      // Curve.getUtoTmapping
        const long il = (long)lens.size(); double target = u * lens[il - 1];
        long low = 0, high = il - 1, i = 0;
        while (low <= high){
            i = low + (high - low) / 2; double cmp = lens[i] - target;
            if (cmp < 0) low = i + 1; else if (cmp > 0) high = i - 1; else { high = i; break; }
        }
        i = high < 0 ? 0 : high;
        if (lens[i] == target) return (double)i / (double)(il - 1);
        double before = lens[i], after = lens[i + 1];
        return ((double)i + (target - before) / (after - before)) / (double)(il - 1);
    }
    V3 getPointAt(double u) const { return getPoint(utoT(u)); }
    V3 getTangent(double t) const {
        const double d = 0.0001; double t1 = t - d, t2 = t + d; if (t1 < 0) t1 = 0; if (t2 > 1) t2 = 1;
        V3 a = getPoint(t1), b = getPoint(t2), v = vsub(b, a); double l = std::sqrt(v.x*v.x + v.y*v.y + v.z*v.z); if (l == 0) l = 1;
        return {v.x / l, v.y / l, v.z / l};
    }
    V3 getTangentAt(double u) const { return getTangent(utoT(u)); }
};


// direction the valley / river runs in (angle used by the terrain code): fixed, the river is hand-placed in river.h
static double pickRiverAngle(){ return PI / 2; }

// ---------- strip meshes (buildStrip in the HTML). vertex = pos(3) uv(2) normal(3) along(1) curv(1) = 10 floats ----------
//  along = metres travelled along the road (lets the shader paint dashed centre lines), curv = 1 / bend radius (solid line in tight bends).
struct Mesh { std::vector<float> v; std::vector<uint32_t> idx; };
static const int VSTRIDE = 10;
struct Prof { double o, y, u; };

// ts = sample positions along the curve; widen(t, side) = extra half width at t on that side (+1 / -1) (junction kerb return; shifts the profile points of that side outwards, asphalt uv with it)
static void buildStrip(Mesh& m, const Curve& curve, const std::vector<double>& ts, const std::vector<Prof>& prof, int vRepeat, double t0, double t1, bool closed, double vConst = -1,
                       double (*widen)(const Curve&, double, int) = nullptr){
    const int N = (int)ts.size() - 1, P = (int)prof.size(); const uint32_t base = (uint32_t)(m.v.size() / VSTRIDE); const double len = curve.length();
    const int nv = (N + 1) * P; std::vector<double> pos(nv * 3), nor(nv * 3, 0.0), aux(nv * 2); std::vector<float> uv(nv * 2);
    for (int i = 0; i <= N; i++){
        auto wr = [&](double q){ return closed ? std::fmod(std::fmod(q, 1.0) + 1.0, 1.0) : std::min(std::max(q, 0.0), 0.99999); };      // open roads never wrap round
        double t = wr(ts[i]);
        V3 p = curve.getPointAt(t), tan = curve.getTangentAt(t);
        double nl = std::hypot(tan.x, tan.z); if (nl == 0) nl = 1; double ux = -tan.z / nl, uz = tan.x / nl;
        const double d = 1.5 / len; V3 ta = curve.getTangentAt(wr(t - d)), tb = curve.getTangentAt(wr(t + d));
        const double skap = std::atan2(ta.x*tb.z - ta.z*tb.x, ta.x*tb.x + ta.z*tb.z) / 3.0, kap = std::fabs(skap);
        const double exP = widen ? widen(curve, t, 1) : 0.0, exN = widen ? widen(curve, t, -1) : 0.0, vr = (ts[i] - t0) / (t1 - t0) * vRepeat;
        const double shift = (exP - exN) * 0.5, hwx = (exP + exN) * 0.5;       // asphalt: the shader wants a road that is symmetric about u = 0, so a one-sided kerb return re-centres the uv (the geometry itself is exact)
        for (int j = 0; j < P; j++){
            int k = i * P + j; const double ex = prof[j].o < 0 ? exN : exP; double o = prof[j].o + (prof[j].o < 0 ? -ex : ex);
            if (std::fabs(o) > 0.5 && o * skap > 0 && std::fabs(o * skap) > 0.8){ const double lim = std::max(0.8 / std::fabs(skap), 4.5); o = (o > 0 ? 1 : -1) * std::min(std::fabs(o), lim); }
            pos[k*3] = p.x + ux * o; pos[k*3+1] = prof[j].y; pos[k*3+2] = p.z + uz * o;
            uv[k*2] = (float)(vConst >= 0 ? prof[j].u + (prof[j].u < 0 ? -ex : ex) - shift : prof[j].u); uv[k*2+1] = (float)(vConst >= 0 ? vConst + hwx : vr);
            aux[k*2] = (double)(ts[i]) * len; aux[k*2+1] = kap;
        }
    }
    std::vector<uint32_t> idx;
    for (int i = 0; i < N; i++) for (int j = 0; j < P - 1; j++){
        uint32_t a = i*P + j, b = (i+1)*P + j; uint32_t t[6] = {a, b, a+1, a+1, b, b+1};
        idx.insert(idx.end(), t, t + 6);
    }
    for (size_t f = 0; f < idx.size(); f += 3){                                    // computeVertexNormals
        const double *A = &pos[idx[f]*3], *B = &pos[idx[f+1]*3], *C = &pos[idx[f+2]*3];
        double cb[3] = {C[0]-B[0], C[1]-B[1], C[2]-B[2]}, ab[3] = {A[0]-B[0], A[1]-B[1], A[2]-B[2]};
        double n[3] = {cb[1]*ab[2] - cb[2]*ab[1], cb[2]*ab[0] - cb[0]*ab[2], cb[0]*ab[1] - cb[1]*ab[0]};
        for (int q = 0; q < 3; q++) for (int c = 0; c < 3; c++) nor[idx[f+q]*3 + c] += n[c];
    }
    for (int j = 0; closed && j < P; j++){                                          // seamless shading where the loop closes
        int a = j, b = N*P + j;
        for (int c = 0; c < 3; c++){ double s = nor[a*3+c] + nor[b*3+c]; nor[a*3+c] = nor[b*3+c] = s; }
    }
    for (int k = 0; k < nv; k++){
        double l = std::sqrt(nor[k*3]*nor[k*3] + nor[k*3+1]*nor[k*3+1] + nor[k*3+2]*nor[k*3+2]); if (l == 0) l = 1;
        double s = nor[k*3+1] < 0 ? -1.0 : 1.0;                                     // always face up
        for (int c = 0; c < 3; c++) nor[k*3+c] = nor[k*3+c] / l * s;
        float row[VSTRIDE] = {(float)pos[k*3], (float)pos[k*3+1], (float)pos[k*3+2], uv[k*2], uv[k*2+1], (float)nor[k*3], (float)nor[k*3+1], (float)nor[k*3+2], (float)aux[k*2], (float)aux[k*2+1]};
        m.v.insert(m.v.end(), row, row + VSTRIDE);
    }
    for (uint32_t i : idx) m.idx.push_back(base + i);
}


// ---------- the road web ----------
//  A real valley road system, drawn like a road map instead of a spider's web:
//   * the VALLEY ROAD runs west -> east along the north bank (nodes 0 - 1 - 3), well away from the river, with the villages strung along it
//   * a ring road closes the valley: north ring (0 - 2 - 8), the east bridge (9) and the south valley road back past the mountain (7 - 4), the west bridge (0 - 5), the south-west road (5 - 6) and the road back up to the centre (6 - 4)
//   * the centre bridge (1 - 4) joins the two banks in the middle; short loops (north-east, south-west) give a second way round
//   * junctions are T / Y / X only (3 or 4 roads, at least 55 deg apart, the side road leaves at right angles); there are no dead ends and no road crosses another outside a junction
//   * every river is crossed at (nearly) right angles by one bridge, 6 bridges in all; no road runs along a river
//   * the mountain (Terrain::buildPeak) stands in the big empty south-east; its road starts at the turn-off MTN_NODE on the south valley road and is added by addConnector()
//  Nodes = junctions (villages / crossroads), world x / z in metres.
static const double NODES[][2] = {
{-1113.6,-629.3},   // 0 M0
{-761.2,-308.8},   // 1 B1
{-395.8,-120.3},   // 2 B2
{-81.2,1.4},   // 3 B3
{156.6,127.6},   // 4 B4
{263.9,374.1},   // 5 P8
{446.6,479.9},   // 6 MTN
{1061.4,742.4},   // 7 MEND
{-771.4,-406.0},   // 8 F1
{-809.1,-459.6},   // 9 D_V1
{-785.9,-208.8},   // 10 F2
{-896.1,-269.7},   // 11 D_V4
{-408.9,-46.4},   // 12 F3
{-361.1,-377.0},   // 13 C_N
{-355.2,-271.1},   // 14 C_C
{-5.8,-155.2},   // 15 J3
{-146.4,-362.5},   // 16 L1
{-113.1,-667.0},   // 17 D_H
{42.0,-236.3},   // 18 J1
{359.6,-532.1},   // 19 JN
{366.8,-640.9},   // 20 D_V12
{321.9,-179.8},   // 21 V11
{218.9,-123.2},   // 22 J2
{179.8,-56.5},   // 23 J2b
{-39.1,-87.0},   // 24 J3b
{242.2,23.2},   // 25 V10J
{-118.9,155.2},   // 26 J4
{-319.0,87.0},   // 27 V6
{-606.1,179.8},   // 28 D_V6
{-185.6,506.1},   // 29 D_S
{174.0,359.6},   // 30 V8
{539.4,408.9},   // 31 HS
};
static const int NODE_N = (int)(sizeof(NODES) / sizeof(NODES[0]));

// every road = the list of points the Catmull-Rom curve passes through, first / last = the two junctions (a, b); the 2nd and the next-to-last point sit 38 m out so that every road leaves a junction in a straight line
struct Pt2 { double x, z; };
struct EdgeDef { int a, b; std::vector<Pt2> pts; };
static const std::vector<EdgeDef>& edgeDefs(){
    static const std::vector<EdgeDef> D = {
        {0, 1, {{-1113.6,-629.3},{-1082.0,-608.2},{-1048.3,-585.8},{-983.1,-542.3},{-949.8,-493.0},{-932.4,-430.6},{-917.9,-372.6},{-874.4,-336.4},{-816.4,-319.0},{-797.8,-319.2},{-761.2,-308.8}}},   // 0
        {1, 2, {{-761.2,-308.8},{-724.7,-298.5},{-693.1,-284.2},{-617.7,-246.5},{-558.2,-224.8},{-507.5,-182.7},{-456.8,-140.7},{-433.2,-127.2},{-395.8,-120.3}}},   // 1
        {2, 3, {{-395.8,-120.3},{-358.5,-113.5},{-314.6,-114.5},{-246.5,-97.1},{-188.5,-69.6},{-129.0,-31.9},{-112.7,-19.7},{-81.2,1.4}}},   // 2
        {3, 4, {{-81.2,1.4},{-49.7,22.6},{-27.6,36.2},{50.8,68.1},{132.4,98.3},{156.6,127.6}}},   // 3
        {4, 5, {{156.6,127.6},{180.8,156.9},{192.8,182.7},{205.9,229.1},{213.2,276.9},{229.1,324.8},{236.4,347.9},{263.9,374.1}}},   // 4
        {5, 6, {{263.9,374.1},{291.4,400.3},{320.4,411.8},{382.8,443.7},{412.5,463.1},{446.6,479.9}}},   // 5
        {6, 7, {{446.6,479.9},{480.7,496.8},{508.9,506.1},{564.0,537.9},{627.9,561.1},{691.6,577.1},{771.4,584.4},{916.4,603.2},{988.9,635.1},{1039.6,693.1},{1061.4,742.4},{1061.4,742.4}}},   // 6
        {1, 8, {{-761.2,-308.8},{-752.4,-340.2},{-762.4,-374.7},{-771.4,-406.0}}},   // 7
        {8, 9, {{-771.4,-406.0},{-784.0,-423.9},{-788.8,-430.6},{-809.1,-459.6}}},   // 8
        {8, 13, {{-771.4,-406.0},{-736.4,-391.2},{-733.7,-390.1},{-675.7,-397.3},{-642.4,-439.3},{-609.0,-465.4},{-558.2,-490.1},{-507.5,-490.1},{-465.4,-456.8},{-414.7,-435.0},{-381.3,-419.1},{-377.6,-411.2},{-361.1,-377.0}}},   // 9
        {1, 10, {{-761.2,-308.8},{-770.6,-275.8},{-778.2,-242.3},{-785.9,-208.8}}},   // 10
        {10, 11, {{-785.9,-208.8},{-819.6,-226.4},{-843.9,-246.5},{-874.4,-263.9},{-896.1,-269.7}}},   // 11
        {10, 12, {{-785.9,-208.8},{-778.9,-171.5},{-777.2,-162.4},{-751.1,-136.3},{-693.1,-116.0},{-633.6,-98.6},{-600.3,-94.2},{-540.9,-87.0},{-490.1,-85.5},{-441.9,-65.3},{-408.9,-46.4}}},   // 12
        {13, 14, {{-361.1,-377.0},{-361.1,-341.6},{-361.1,-329.1},{-358.8,-306.4},{-355.2,-271.1}}},   // 13
        {13, 16, {{-361.1,-377.0},{-323.1,-378.0},{-305.9,-378.4},{-230.5,-371.2},{-184.2,-366.9},{-146.4,-362.5}}},   // 14
        {14, 2, {{-355.2,-271.1},{-364.2,-234.2},{-366.8,-223.3},{-384.2,-184.2},{-389.0,-157.7},{-395.8,-120.3}}},   // 15
        {14, 15, {{-355.2,-271.1},{-317.9,-264.0},{-279.8,-256.6},{-230.5,-246.5},{-162.4,-224.8},{-113.1,-211.7},{-55.1,-176.9},{-40.6,-170.5},{-5.8,-155.2}}},   // 16
        {16, 17, {{-146.4,-362.5},{-152.7,-400.0},{-153.7,-406.0},{-175.4,-464.0},{-179.8,-523.4},{-146.4,-574.2},{-133.4,-598.9},{-137.8,-633.6},{-113.1,-667.0}}},   // 17
        {16, 18, {{-146.4,-362.5},{-109.0,-356.0},{-104.4,-355.2},{-62.4,-324.8},{-24.6,-298.7},{10.2,-268.2},{15.2,-263.2},{42.0,-236.3}}},   // 18
        {18, 19, {{42.0,-236.3},{64.8,-266.8},{68.1,-271.1},{104.4,-329.1},{136.3,-384.2},{152.2,-446.6},{168.2,-506.1},{189.9,-524.9},{256.6,-520.5},{322.3,-524.7},{359.6,-532.1}}},   // 19
        {19, 21, {{359.6,-532.1},{395.3,-545.2},{419.1,-553.9},{448.1,-572.8},{485.8,-616.2},{514.8,-635.1},{552.4,-639.4},{597.4,-630.8},{640.9,-616.2},{685.9,-606.1},{714.9,-590.1},{722.1,-535.0},{719.2,-453.8},{704.7,-417.6},{655.4,-394.4},{630.8,-377.0},{622.0,-343.6},{597.4,-305.9},{552.4,-279.8},{514.8,-253.8},{485.8,-224.8},{433.6,-203.0},{382.8,-191.4},{359.2,-186.9},{321.9,-179.8}}},   // 20
        {19, 21, {{359.6,-532.1},{346.0,-496.7},{337.8,-432.1},{330.6,-394.4},{349.4,-358.1},{363.9,-320.4},{356.7,-284.2},{337.8,-246.5},{330.0,-216.9},{321.9,-179.8}}},   // 21
        {19, 20, {{359.6,-532.1},{363.2,-568.3},{365.4,-590.1},{366.8,-640.9}}},   // 22
        {21, 22, {{321.9,-179.8},{289.3,-160.2},{271.1,-136.3},{256.5,-129.2},{218.9,-123.2}}},   // 23
        {18, 22, {{42.0,-236.3},{77.2,-221.9},{123.2,-203.0},{182.7,-158.0},{190.1,-148.0},{218.9,-123.2}}},   // 24
        {18, 15, {{42.0,-236.3},{32.7,-205.5},{31.9,-203.0},{20.3,-179.8},{17.6,-177.3},{-5.8,-155.2}}},   // 25
        {15, 24, {{-5.8,-155.2},{-16.7,-132.3},{-23.2,-118.9},{-27.8,-109.6},{-39.1,-87.0}}},   // 26
        {22, 23, {{218.9,-123.2},{207.4,-100.2},{205.9,-97.1},{193.5,-78.4},{179.8,-56.5}}},   // 27
        {23, 24, {{179.8,-56.5},{141.8,-54.8},{118.9,-56.5},{75.4,-55.1},{31.9,-50.8},{-4.3,-60.9},{-8.8,-64.2},{-39.1,-87.0}}},   // 28
        {24, 3, {{-39.1,-87.0},{-53.2,-57.5},{-63.0,-25.7},{-81.2,1.4}}},   // 29
        {23, 25, {{179.8,-56.5},{192.6,-24.4},{194.3,-20.3},{217.7,-1.3},{242.2,23.2}}},   // 30
        {25, 4, {{242.2,23.2},{218.1,52.6},{185.9,103.4},{156.6,127.6}}},   // 31
        {3, 26, {{-81.2,1.4},{-102.4,33.0},{-104.4,84.1},{-107.5,118.9},{-118.9,155.2}}},   // 32
        {2, 12, {{-395.8,-120.3},{-400.4,-95.7},{-404.6,-71.1},{-408.9,-46.4}}},   // 33
        {12, 27, {{-408.9,-46.4},{-413.9,-8.7},{-407.4,-2.9},{-379.9,40.6},{-371.2,55.1},{-350.6,65.9},{-319.0,87.0}}},   // 34
        {27, 28, {{-319.0,87.0},{-355.2,98.6},{-359.6,100.0},{-403.1,113.1},{-442.2,114.5},{-504.6,140.7},{-556.8,171.1},{-606.1,179.8}}},   // 35
        {27, 26, {{-319.0,87.0},{-282.5,76.4},{-274.1,74.0},{-230.5,104.4},{-185.6,131.9},{-155.4,144.5},{-118.9,155.2}}},   // 36
        {26, 30, {{-118.9,155.2},{-84.1,170.5},{-27.6,189.9},{20.3,210.2},{27.6,237.8},{91.3,285.6},{137.8,332.1},{143.7,336.6},{174.0,359.6}}},   // 37
        {26, 29, {{-118.9,155.2},{-145.8,182.0},{-165.3,221.8},{-169.7,276.9},{-158.0,324.8},{-118.9,356.7},{-98.6,372.6},{-91.3,387.1},{-105.8,435.0},{-142.1,474.1},{-169.7,498.8},{-185.6,506.1}}},   // 38
        {30, 5, {{174.0,359.6},{203.1,382.9},{238.2,401.1},{263.9,374.1}}},   // 39
        {30, 6, {{174.0,359.6},{160.2,395.0},{153.7,411.8},{137.8,458.2},{130.5,498.8},{130.5,537.9},{146.4,561.1},{162.4,565.5},{208.8,581.4},{256.6,600.3},{288.6,613.4},{320.4,604.6},{350.9,581.4},{382.8,553.9},{414.7,522.0},{429.8,514.0},{446.6,479.9}}},   // 40
        {6, 31, {{446.6,479.9},{463.4,445.9},{484.3,410.3},{510.4,406.0},{539.4,408.9}}},   // 41
    };
    return D;
}
// the winding hill road (control points, world metres): starts at the end of the connector (last node), 5 hairpin legs up to the summit car park
static const std::vector<Pt2>& hillPts(){ static const std::vector<Pt2> H = {{539.4,408.9},{597.4,426.3},{648.1,426.3},{713.4,403.1},{778.6,369.8},{825.0,352.3},{836.6,337.8},{822.1,326.2},{771.4,311.8},{698.9,301.6},{648.1,279.8},{635.1,261.0},{651.0,243.6},{698.9,243.6},{771.4,253.8},{843.9,261.0},{901.9,261.0},{912.0,236.3},{894.6,214.6},{843.9,203.0},{771.4,195.8},{713.4,181.2},{694.5,156.6},{713.4,139.2},{771.4,139.2},{843.9,140.7},{875.8,134.8},{880.1,116.0},{843.9,105.8},{771.4,98.6},{713.4,84.1},{694.5,58.0},{713.4,42.0},{771.4,46.4},{843.9,55.1},{909.1,62.4},{933.8,43.5},{916.4,21.8},{843.9,11.6},{771.4,-2.9},{735.1,-21.8},{730.8,-39.1},{749.6,-53.6},{785.9,-53.6},{843.9,-43.5},{909.1,-29.0},{919.3,-43.5},{901.9,-58.0},{843.9,-68.1},{812.9,-81.3}}; return H; }

// a road that is added at run time leaves node MTN_NODE at this heading (degrees, 0 = +x, 90 = +z): it is the road up the mountain, so that junction already gets its kerb returns
static const int MTN_NODE = 7; static const double MTN_HEADING = 90;
static const int START_EDGE = 3;                                    // the start line: middle of the long, dry east half of the valley road, far from every bridge
static const int EDGE_N = 42;

struct Net {
    std::vector<Curve> roads;                              // every road of the web (open curves, junction to junction)
    std::vector<Mesh> roadM;                               // one asphalt ribbon per road (paint stops 9 m before each end = the junction mouths)
    Mesh road, verge, trk, trkV;                           // road = bridge decks only (bridge.h appends there); verge = sand shoulders of all roads; trk / trkV = hill road (filled by Terrain)
    std::unordered_map<long long, std::vector<float>> grid;  // road centre samples (x, z, halfwidth) per 24 m cell
    double riverAng = 0; int startRoad = 0; bool ready = false, hillRoad = false;
};
static Net gNet;
static const int RG = 24;
static inline long long cellKey(long cx, long cz){ return (long long)(cx + 100000) * 200003LL + (cz + 100000); }
static std::vector<const Curve*> all(){ std::vector<const Curve*> v; for (const Curve& c : gNet.roads) v.push_back(&c); return v; }

// one road: a centripetal Catmull-Rom curve through the listed points (three.js CatmullRomCurve3, like the HTML game)
static Curve makeEdge(const std::vector<Pt2>& P){
    Curve c; c.closed = false; c.open = true; c.hw = 9.0 / 2;                                   // two real 4.5 m lanes
    for (const Pt2& q : P) c.pts.push_back({q.x, ROAD_SURF, q.z});
    c.build(); return c;
}
// Junction kerb return: the road widens towards its end along a circular arc of radius FLARE. Extra half width at arc length d from the start of the road,
// on one side only (side = +1 / -1 = the sign of the profile offset): a corner that does not exist (the far side of a T) gets no fillet.
static const double FLARE = 6.0;
static double connExtra(const Curve& c, double d, int side){
    auto f = [](double dd, double rh){
        if (rh <= 0) return 0.0; const double x = rh + FLARE - dd;            // distance from the arc's centre, along the road
        if (x >= FLARE) return FLARE; if (x <= 0) return 0.0;
        return FLARE - std::sqrt(FLARE * FLARE - x * x);
    };
    const int bit = side > 0 ? 1 : 2; double e = 0;
    if (c.fA & bit) e = std::max(e, f(d, c.rA));
    if (c.fB & bit) e = std::max(e, f(c.length() - d, c.rB));
    return e;
}
static double connWiden(const Curve& c, double t, int side){ return connExtra(c, t * c.length(), side); }
// samples along the road (curve parameter t0..t1): 1.5 m, but every 0.3 m inside the fillets where the edge sweeps out quickly
static std::vector<double> connT(const Curve& c, double t0, double t1){
    const double len = c.length(); std::vector<double> ts; double s = t0 * len; const double e = t1 * len;
    while (s < e - 1e-6){ ts.push_back(s / len); const bool fine = s < c.rA + FLARE + 1.0 || s > len - c.rB - FLARE - 1.0; s += fine ? 0.3 : 1.5; }
    ts.push_back(t1); return ts;
}

// ribbon + sand verges of one road. No road / sand across a river: the bridge deck is the roadway there (same sampling as the old ring roads).
static void addEdge(Mesh& road, Mesh& vergeM, const Curve& c){
    const double len = c.length(), hw = c.hw, T1 = 0.99999;
    const int SS = (int)std::ceil(len / 1.2); std::vector<char> inRv(SS + 1);
    for (int i = 0; i <= SS; i++){ const V3 q = c.getPointAt(std::min((double)i / SS, T1)); inRv[i] = std::fabs(River::riverSd(q.x, q.z)) < River::RIVER_WALL + 5; }
    struct Run { double a, b; }; std::vector<Run> runs;
    for (int i = 0; i <= SS; ){ if (inRv[i]){ i++; continue; } int j = i; while (j <= SS && !inRv[j]) j++; runs.push_back({(double)i / SS, j > SS ? T1 : std::min((double)j / SS, T1)}); i = j; }
    static const double SP[4][2] = {{-1.5, 0.075}, {0, 0.08}, {3.5, 0.06}, {8, 0.045}};
    const double endT = std::min(0.35, c.hw * 1.5 / len);                                      // verges stop short of the junctions
    for (const Run& r : runs){
        if ((r.b - r.a) * len < 2.0) continue;
        buildStrip(road, c, connT(c, r.a, r.b), {{hw, ROAD_SURF, hw}, {-hw, ROAD_SURF, -hw}}, std::max(1, (int)jsRound((r.b - r.a) * len / 8)), r.a, r.b, false, hw, connWiden);
        const double s0 = std::max(r.a, endT), s1 = std::min(r.b, 1 - endT); if ((s1 - s0) * len < 2.0) continue;
        for (int sd : {1, -1}){
            std::vector<Prof> sh; for (auto& q : SP) sh.push_back({sd * (hw + q[0]), q[1], (q[0] + 1.5) / (8 + 1.5)});
            if (sd > 0) std::reverse(sh.begin(), sh.end());
            buildStrip(vergeM, c, connT(c, s0, s1), sh, std::max(1, (int)jsRound((s1 - s0) * len / 2.5)), s0, s1, false, -1, connWiden);
        }
    }
}

// unit direction of a road as it leaves a junction (outward from the junction)
static void armDir(const Curve& c, bool atStart, double& dx, double& dz){
    const size_t n = c.pts.size(); const V3 &a = atStart ? c.pts[0] : c.pts[n-1], &b = atStart ? c.pts[1] : c.pts[n-2];
    dx = b.x - a.x; dz = b.z - a.z; const double l = std::hypot(dx, dz); dx /= l; dz /= l;
}
// which corners of every junction get a kerb return: a road gets a fillet on a side if the next road on that side leaves it at less than 140 deg (a straight-through road gets none on the far side of a T)
static void setFillets(Net& n){
    struct Arm { double ang; int edge; bool start; };
    std::vector<std::vector<Arm>> arms(NODE_N);
    for (size_t e = 0; e < n.roads.size() && e < edgeDefs().size(); e++){
        double dx, dz;
        armDir(n.roads[e], true, dx, dz);  arms[edgeDefs()[e].a].push_back({std::atan2(dz, dx), (int)e, true});
        armDir(n.roads[e], false, dx, dz); arms[edgeDefs()[e].b].push_back({std::atan2(dz, dx), (int)e, false});
    }
         // the road up the mountain is added later but its corners are planned now
    const double LIM = 140 * PI / 180, P2 = 2 * PI;
    for (int nd = 0; nd < NODE_N; nd++) for (const Arm& a : arms[nd]){
        if (a.edge < 0) continue;
        double gInc = 1e9, gDec = 1e9;                                                           // angular gap to the nearest other road, counter-clockwise / clockwise
        for (const Arm& o : arms[nd]){ if (&o == &a) continue;
            double g = std::fmod(o.ang - a.ang, P2); if (g < 0) g += P2; if (g < 1e-6) g = P2;
            gInc = std::min(gInc, g); gDec = std::min(gDec, P2 - g); }
        const int inc = gInc < LIM ? 1 : 0, dec = gDec < LIM ? 1 : 0;
        Curve& c = n.roads[a.edge];                                                              // start of the road: +normal = counter-clockwise side; end of the road: the other way round
        if (a.start) c.fA = inc | (dec << 1); else c.fB = dec | (inc << 1);
    }
}
static void addToGrid(const Curve& cv){
    const int cnt = (int)std::ceil(cv.length() / 2);
    for (int i = 0; i <= cnt; i++){
        const double u = std::min((double)i / cnt, 0.99999); V3 p = cv.getPointAt(u);
        auto& l = gNet.grid[cellKey((long)std::floor(p.x / RG), (long)std::floor(p.z / RG))];
        l.push_back((float)p.x); l.push_back((float)p.z);
        l.push_back((float)(cv.hw + std::max(connExtra(cv, u * cv.length(), 1), connExtra(cv, u * cv.length(), -1))));   // flared junction mouths count as road
    }
}

static void init(){
    Net& n = gNet; if (n.ready) return;
    River::init();
    n.riverAng = pickRiverAngle();
    const std::vector<EdgeDef>& defs = edgeDefs();
    n.roads.reserve(defs.size() + 4);
    for (size_t e = 0; e < defs.size(); e++){
        Curve c = makeEdge(defs[e].pts); c.rA = c.rB = c.hw;                                    // kerb returns are as wide as the road they join
        n.roads.push_back(c);
    }
    n.startRoad = START_EDGE;
    setFillets(n);
    n.roadM.reserve(defs.size() + 4); n.roadM.resize(n.roads.size());
    for (size_t e = 0; e < n.roads.size(); e++) addEdge(n.roadM[e], n.verge, n.roads[e]);
    for (const Curve& cv : n.roads) addToGrid(cv);                                              // grid of centre-line samples -> distance from the nearest road EDGE
    n.ready = true;
}

// THE ROAD UP THE MOUNTAIN: the mountain stands where Terrain::buildPeak puts it, so its first point (px, pz) and the direction the hill road leaves it in (hx, hz, unit) are only known
// then. This adds the paved road from the turn-off MTN_NODE on the south valley road to that point, so the hill road is part of the network (not a track that starts in the middle of a meadow).
// Call once, from Terrain::buildPeak, before anything uses the road grid for that mountain.
static bool addConnector(double, double, double, double){ gNet.hillRoad = true; return true; }   // the connector to the hill road is now an ordinary edge of the road table

// distance from the nearest road EDGE (negative = on the road)
static float clearance(float x, float z){
    long cx = (long)std::floor(x / RG), cz = (long)std::floor(z / RG); float best = 1e9f;
    for (int i = -1; i <= 1; i++) for (int j = -1; j <= 1; j++){
        auto it = gNet.grid.find(cellKey(cx + i, cz + j)); if (it == gNet.grid.end()) continue;
        const std::vector<float>& l = it->second;
        for (size_t k = 0; k < l.size(); k += 3){ float dx = x - l[k], dz = z - l[k+1], d = std::sqrt(dx*dx + dz*dz) - l[k+2]; if (d < best) best = d; }
    }
    return best;
}

// grip / drag / ride height under the tyres (surfaceAt in the HTML): tarmac-like road, softer verge, grass
struct SurfaceInfo { double mu, rr, rideY; };
static SurfaceInfo surfaceAt(float x, float z){
    double c = clearance(x, z), t = std::min(std::max((c - 0.8) / 2.2, 0.0), 1.0), g = t*t*(3 - 2*t);
    double u = std::min(std::max((c - 0.3) / 2.4, 0.0), 1.0);
    return {1.15 - 0.3 * g, 0.028 + 0.06 * g, ROAD_SURF * (1 - u*u*(3 - 2*u))};
}

// where the car starts: on the road web at the start line, facing along the road
static void startPose(double& x, double& z, double& heading){
    const Curve& c = gNet.roads[gNet.startRoad]; V3 p = c.getPointAt(0.5), t = c.getTangentAt(0.5); x = p.x; z = p.z; heading = std::atan2(t.x, t.z);
}

} // namespace Road
