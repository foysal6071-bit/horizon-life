// Sunny Drift - procedural models of the Swiss village (pure C++, no OpenGL): the wooden chalet and the church with its pointed spire.
//  Both are built once into one static vertex buffer each and drawn with instancing (village_render.h).
//  Vertex = position(3) normal(3) colour(3) material(1). Units are metres; the model's FRONT is +Z, the ground is y = 0.
//  material: 0 plain colour, 1 wood logs (tinted per house), 2 stone, 3 roof shingle / tile, 4 window glass, 5 shutters (accent colour per house), 6 plaster, 7 asphalt, 8 road paint
#pragma once
#include <cmath>
#include <cstdint>
#include <functional>
#include <vector>

namespace VillageMesh {

struct P3 { float x, y, z; };
static inline P3 operator+(P3 a, P3 b){ return {a.x + b.x, a.y + b.y, a.z + b.z}; }
static inline P3 operator-(P3 a, P3 b){ return {a.x - b.x, a.y - b.y, a.z - b.z}; }
static inline P3 operator-(P3 a){ return {-a.x, -a.y, -a.z}; }
static inline P3 operator*(P3 a, float k){ return {a.x * k, a.y * k, a.z * k}; }
static inline float dot(P3 a, P3 b){ return a.x * b.x + a.y * b.y + a.z * b.z; }
static inline P3 cross(P3 a, P3 b){ return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x}; }
static inline P3 norm(P3 a){ const float l = std::sqrt(dot(a, a)); return l > 1e-9f ? a * (1.f / l) : P3{0, 1, 0}; }

struct Col { float r, g, b; };
struct Mesh { std::vector<float> v; std::vector<uint16_t> i; int count() const { return (int)v.size() / 10; } };

// ---------- palette ----------
static const Col STONE  = {0.56f, 0.54f, 0.50f}, WOOD   = {0.50f, 0.31f, 0.16f}, WOOD_D = {0.36f, 0.22f, 0.12f}, WOOD_L = {0.62f, 0.42f, 0.24f};
static const Col ROOF   = {0.46f, 0.35f, 0.27f}, TILE   = {0.68f, 0.26f, 0.17f}, SLATE  = {0.23f, 0.26f, 0.32f};
static const Col GLASS  = {0.20f, 0.26f, 0.34f}, WHITE  = {0.93f, 0.91f, 0.85f}, PLASTER = {0.94f, 0.92f, 0.86f}, DARK = {0.07f, 0.06f, 0.05f};
static const Col LEAF   = {0.16f, 0.40f, 0.13f}, RED = {0.80f, 0.09f, 0.11f}, PINK = {0.90f, 0.35f, 0.50f}, FWHITE = {0.95f, 0.95f, 0.92f}, GOLD = {0.86f, 0.70f, 0.20f};
static const Col BLACK  = {0.05f, 0.05f, 0.05f};

// ---------- primitives ----------
static void quadN(Mesh& m, P3 a, P3 b, P3 c, P3 d, P3 n, Col col, float mat){
    const uint16_t base = (uint16_t)m.count(); const P3 q[4] = {a, b, c, d};
    for (int k = 0; k < 4; k++){ const float f[10] = {q[k].x, q[k].y, q[k].z, n.x, n.y, n.z, col.r, col.g, col.b, mat}; m.v.insert(m.v.end(), f, f + 10); }
    const uint16_t ix[6] = {0, 1, 2, 0, 2, 3}; for (uint16_t t : ix) m.i.push_back(base + t);
}
// quad whose normal is flipped to point along `hint`
static void quad(Mesh& m, P3 a, P3 b, P3 c, P3 d, P3 hint, Col col, float mat){
    P3 n = norm(cross(b - a, d - a)); if (dot(n, hint) < 0) n = n * -1.f; quadN(m, a, b, c, d, n, col, mat);
}
static void tri(Mesh& m, P3 a, P3 b, P3 c, P3 hint, Col col, float mat){
    P3 n = norm(cross(b - a, c - a)); if (dot(n, hint) < 0) n = n * -1.f;
    const uint16_t base = (uint16_t)m.count(); const P3 q[3] = {a, b, c};
    for (int k = 0; k < 3; k++){ const float f[10] = {q[k].x, q[k].y, q[k].z, n.x, n.y, n.z, col.r, col.g, col.b, mat}; m.v.insert(m.v.end(), f, f + 10); }
    m.i.push_back(base); m.i.push_back(base + 1); m.i.push_back(base + 2);
}
// box in a frame: centre c, horizontal unit vectors t (along) and n (outward), half sizes ht, hy, hn
static void obox(Mesh& m, P3 c, P3 t, P3 n, float ht, float hy, float hn, Col col, float mat){
    const P3 Y = {0, 1, 0}, T = t * ht, N = n * hn, H = Y * hy;
    auto face = [&](P3 ctr, P3 u, P3 w, P3 nrm){ quadN(m, ctr - u - w, ctr + u - w, ctr + u + w, ctr - u + w, nrm, col, mat); };
    face(c + N, T, H, n); face(c - N, T, H, n * -1.f); face(c + T, N, H, t); face(c - T, N, H, t * -1.f); face(c + H, T, N, Y); face(c - H, T, N, Y * -1.f);
}
static void box(Mesh& m, float x, float y, float z, float hx, float hy, float hz, Col col, float mat){ obox(m, {x, y, z}, {1, 0, 0}, {0, 0, 1}, hx, hy, hz, col, mat); }
// slab: quad a,b,c,d extruded `th` downwards (roof planes)
static void slab(Mesh& m, P3 a, P3 b, P3 c, P3 d, float th, Col col, float mat){
    const P3 dn = {0, -th, 0}, a2 = a + dn, b2 = b + dn, c2 = c + dn, d2 = d + dn, ctr = (a + b + c + d + a2 + b2 + c2 + d2) * 0.125f;
    auto q = [&](P3 p0, P3 p1, P3 p2, P3 p3){ quad(m, p0, p1, p2, p3, (p0 + p1 + p2 + p3) * 0.25f - ctr, col, mat); };
    q(a, b, c, d); q(a2, b2, c2, d2); q(a, b, b2, a2); q(b, c, c2, b2); q(c, d, d2, c2); q(d, a, a2, d2);
}
// n-sided pyramid (base ring at height y0, radius R, first vertex at angle a0) rising to apex
static void pyramid(Mesh& m, P3 centre, float R, int sides, float a0, P3 apex, Col col, float mat){
    for (int k = 0; k < sides; k++){
        const float a = a0 + 6.2831853f * k / sides, b = a0 + 6.2831853f * (k + 1) / sides;
        const P3 p = {centre.x + R * std::cos(a), centre.y, centre.z + R * std::sin(a)}, q = {centre.x + R * std::cos(b), centre.y, centre.z + R * std::sin(b)};
        tri(m, p, q, apex, (p + q) * 0.5f - P3{centre.x, centre.y + 4.f, centre.z}, col, mat);
    }
}

// ---------- parts ----------
// window on a wall: centre c on the wall surface, t = along the wall, n = outward. Glass + white frame + mullion + sill, optional shutters / flower box
static void flowerBox(Mesh& m, P3 c, P3 t, P3 n, float hw, Col wood){
    obox(m, c, t, n, hw, 0.13f, 0.17f, wood, 1);                                                  // the wooden box
    obox(m, c + P3{0, 0.17f, 0}, t, n, hw - 0.03f, 0.08f, 0.14f, LEAF, 0);                        // leaves
    const Col fc[5] = {RED, RED, PINK, FWHITE, RED}; const int cnt = std::max(3, (int)(hw / 0.17f));
    for (int k = 0; k < cnt; k++){                                                                 // flower heads along the box
        const float u = (cnt == 1 ? 0.f : (-1.f + 2.f * k / (cnt - 1))) * (hw - 0.12f), h = 0.26f + 0.05f * (float)((k * 7) % 3);
        obox(m, c + t * u + P3{0, h, 0} + n * (0.04f * (float)((k % 2) ? 1 : -1)), t, n, 0.10f, 0.07f, 0.10f, fc[k % 5], 0);
    }
}
static void window(Mesh& m, P3 c, P3 t, P3 n, float w, float h, bool shutters, bool fbox){
    const P3 Y = {0, 1, 0}, o = n * 0.025f;
    quadN(m, c + o - t * (w / 2) - Y * (h / 2), c + o + t * (w / 2) - Y * (h / 2), c + o + t * (w / 2) + Y * (h / 2), c + o - t * (w / 2) + Y * (h / 2), n, GLASS, 4);
    const float f = 0.06f;
    obox(m, c + t * (w / 2 + f / 2) + n * 0.035f, t, n, f / 2, h / 2 + f, 0.045f, WHITE, 0); obox(m, c - t * (w / 2 + f / 2) + n * 0.035f, t, n, f / 2, h / 2 + f, 0.045f, WHITE, 0);
    obox(m, c + Y * (h / 2 + f / 2) + n * 0.035f, t, n, w / 2 + f, f / 2, 0.045f, WHITE, 0);
    obox(m, c + n * 0.045f, t, n, 0.02f, h / 2, 0.03f, WHITE, 0); obox(m, c + n * 0.045f + Y * (h * 0.12f), t, n, w / 2, 0.02f, 0.03f, WHITE, 0);   // mullion + transom
    obox(m, c - Y * (h / 2 + 0.1f) + n * 0.09f, t, n, w / 2 + 0.14f, 0.04f, 0.10f, WHITE, 0);                                                          // sill
    if (shutters) for (int sd : {1, -1}) obox(m, c + t * (float)sd * (w / 2 + f + 0.27f) + n * 0.05f, t, n, 0.26f, h / 2 + 0.05f, 0.03f, WOOD, 5);
    if (fbox) flowerBox(m, c - Y * (h / 2 + 0.3f) + n * 0.2f, t, n, w / 2 + 0.12f, WOOD_D);
}
// pointed-arch window / opening (church): glass rectangle + triangular top + stone frame
static void archWindow(Mesh& m, P3 c, P3 t, P3 n, float w, float h, Col glass, float mat, bool frame){
    const P3 Y = {0, 1, 0}, o = n * 0.03f, top = c + Y * (h / 2);
    quadN(m, c + o - t * (w / 2) - Y * (h / 2), c + o + t * (w / 2) - Y * (h / 2), c + o + t * (w / 2) + Y * (h / 2), c + o - t * (w / 2) + Y * (h / 2), n, glass, mat);
    tri(m, top + o - t * (w / 2), top + o + t * (w / 2), top + o + Y * (w * 0.75f), n, glass, mat);
    if (frame){ const float f = 0.12f;
        obox(m, c + t * (w / 2 + f / 2) + n * 0.04f, t, n, f / 2, h / 2 + 0.02f, 0.05f, STONE, 2); obox(m, c - t * (w / 2 + f / 2) + n * 0.04f, t, n, f / 2, h / 2 + 0.02f, 0.05f, STONE, 2);
        obox(m, c - Y * (h / 2 + 0.05f) + n * 0.07f, t, n, w / 2 + 0.2f, 0.06f, 0.09f, STONE, 2); }
}

// ======================================================= the chalet =======================================================
static void buildChalet(Mesh& m){
    const float hw = 3.5f, hd = 4.25f, yw = 5.1f, tn = 0.404f /* tan 22 deg */, wu = hw + 0.12f, du = hd + 0.12f;
    const float yr = yw + 0.12f + wu * tn;                                                         // ridge height (roof plane through the wall top)
    const P3 X = {1, 0, 0}, Z = {0, 0, 1};
    // --- stone ground floor (with a deep foundation, so a house on a slope never floats)
    box(m, 0, 0.45f, 0, hw + 0.12f, 1.95f, hd + 0.12f, STONE, 2);                                  // y -1.5 .. 2.4
    box(m, 0, 2.43f, 0, hw + 0.2f, 0.05f, hd + 0.2f, STONE, 2);                                    // stone ledge under the wooden storey
    // --- wooden upper storey (horizontal logs) + the two gables
    box(m, 0, 3.75f, 0, wu, 1.35f, du, WOOD, 1);                                                   // y 2.4 .. 5.1
    for (float zs : {du, -du}){
        tri(m, {-wu, yw, zs}, {wu, yw, zs}, {0, yr - 0.17f, zs}, Z * zs, WOOD_L, 1);
        for (int k = -2; k <= 2; k++) obox(m, {k * 0.55f, yw + 0.3f + (2 - std::abs(k)) * 0.2f - 0.15f, zs * 1.0f}, X, Z, 0.012f, 0.0f + 0.01f, 0.012f, WOOD_D, 0);  // (tiny batten ticks)
    }
    // --- the broad, low roof: two slabs, big overhang at the eaves and over the balcony, ridge cap
    const float ex = 5.1f, ey = yr - ex * tn, zf = hd + 1.9f, zb = -(hd + 1.0f);
    slab(m, {-ex, ey, zf}, {0, yr, zf}, {0, yr, zb}, {-ex, ey, zb}, 0.17f, ROOF, 3);
    slab(m, {ex, ey, zf}, {0, yr, zf}, {0, yr, zb}, {ex, ey, zb}, 0.17f, ROOF, 3);
    box(m, 0, yr + 0.05f, (zf + zb) / 2, 0.13f, 0.07f, (zf - zb) / 2 + 0.02f, ROOF, 0);
    // --- stone chimney
    box(m, 1.7f, 6.7f, -1.6f, 0.42f, 1.5f, 0.42f, STONE, 2); box(m, 1.7f, 8.25f, -1.6f, 0.55f, 0.07f, 0.55f, STONE, 2);
    // --- front door + steps (ground floor), door to the balcony (upper floor)
    box(m, 0, 1.0f, du + 0.04f, 0.58f, 1.0f, 0.05f, WOOD_D, 0); box(m, 0, 2.08f, du + 0.05f, 0.75f, 0.08f, 0.07f, WHITE, 0);
    box(m, -0.66f, 1.04f, du + 0.05f, 0.07f, 1.04f, 0.07f, WHITE, 0); box(m, 0.66f, 1.04f, du + 0.05f, 0.07f, 1.04f, 0.07f, WHITE, 0);
    box(m, 0, 0.05f, du + 0.45f, 1.0f, 0.12f, 0.4f, STONE, 2);
    box(m, 0, 3.55f, du + 0.04f, 0.58f, 1.02f, 0.05f, WOOD_D, 0); box(m, 0, 4.62f, du + 0.05f, 0.75f, 0.07f, 0.07f, WHITE, 0);
    // --- balcony: deck, posts, railing with balusters, flower boxes on the rail
    const float bz0 = du, bz1 = du + 1.55f, bx = 3.3f, rail = 3.5f;
    box(m, 0, 2.46f, (bz0 + bz1) / 2, bx, 0.06f, (bz1 - bz0) / 2, WOOD_L, 1);
    for (int k = 0; k < 5; k++) box(m, -bx + 0.4f + k * (2 * bx - 0.8f) / 4.f, 2.28f, (bz0 + bz1) / 2, 0.06f, 0.14f, (bz1 - bz0) / 2, WOOD_D, 1);   // joists
    for (float px : {-3.2f, 3.2f}) box(m, px, 2.6f, bz1 - 0.1f, 0.09f, 2.6f, 0.09f, WOOD_D, 1);                                                          // corner posts up to the roof
    box(m, 0, rail, bz1 - 0.1f, bx, 0.045f, 0.06f, WOOD_L, 1); box(m, 0, 2.62f, bz1 - 0.1f, bx, 0.04f, 0.05f, WOOD_L, 1);                               // front rails
    for (float sx : {-3.2f, 3.2f}){ box(m, sx, rail, (bz0 + bz1) / 2, 0.06f, 0.045f, (bz1 - bz0) / 2, WOOD_L, 1); box(m, sx, 2.62f, (bz0 + bz1) / 2, 0.05f, 0.04f, (bz1 - bz0) / 2, WOOD_L, 1); }
    for (int k = 0; k <= 20; k++) box(m, -3.1f + k * 0.31f, 3.06f, bz1 - 0.1f, 0.025f, 0.44f, 0.025f, WOOD_L, 1);                                         // balusters (front)
    for (float sx : {-3.2f, 3.2f}) for (int k = 1; k <= 4; k++) box(m, sx, 3.06f, bz0 + k * (bz1 - bz0) / 5.f, 0.025f, 0.44f, 0.025f, WOOD_L, 1);          // balusters (sides)
    for (float px : {-2.0f, 0.0f, 2.0f}) flowerBox(m, {px, rail + 0.15f, bz1 - 0.1f}, X, Z, 0.7f, WOOD_D);
    // --- windows
    for (float sx : {-2.1f, 2.1f}){
        window(m, {sx, 1.35f, du}, X, Z, 0.9f, 1.1f, true, true);                                   // ground floor, with flower boxes
        window(m, {sx, 3.7f, du}, X, Z, 0.9f, 1.2f, true, false);                                   // upper floor (behind the balcony rail)
    }
    window(m, {0, 5.75f, du}, X, Z, 0.55f, 0.55f, true, false);                                     // little attic window in the gable
    for (int sd : {1, -1}){
        const P3 n = {(float)sd, 0, 0}, t = {0, 0, 1};
        for (float zz : {-1.6f, 1.5f}){ window(m, {sd * wu, 1.35f, zz}, t, n, 0.9f, 1.1f, true, false); window(m, {sd * wu, 3.65f, zz}, t, n, 0.9f, 1.2f, true, true); }
    }
    window(m, {-1.4f, 3.65f, -du}, X, {0, 0, -1}, 0.9f, 1.2f, true, false); window(m, {1.4f, 1.35f, -du}, X, {0, 0, -1}, 0.9f, 1.1f, false, false);
    // --- woodpile against the side wall
    for (int r = 0; r < 3; r++) for (int k = 0; k < 4 - r; k++) obox(m, {-(wu + 0.3f), 0.2f + r * 0.32f, -2.4f + k * 0.34f + r * 0.17f}, X, Z, 0.28f, 0.15f, 0.15f, WOOD_L, 1);
}

// ======================================================= the church =======================================================
static void clockFace(Mesh& m, P3 c, P3 t, P3 n){
    obox(m, c, t, n, 0.85f, 0.85f, 0.03f, STONE, 2); obox(m, c + n * 0.03f, t, n, 0.72f, 0.72f, 0.02f, WHITE, 0);
    obox(m, c + n * 0.06f + P3{0, 0.28f, 0}, t, n, 0.04f, 0.3f, 0.015f, BLACK, 0); obox(m, c + n * 0.06f + t * 0.2f, t, n, 0.24f, 0.04f, 0.015f, BLACK, 0);
}
static void buildChurch(Mesh& m){
    const P3 X = {1, 0, 0}, Z = {0, 0, 1};
    // --- nave (white plaster, steep tiled roof), on a stone plinth with a deep foundation
    const float nw = 3.8f, nz0 = -7.0f, wy = 6.5f, tn = 0.839f;
    box(m, 0, -0.45f, 0, nw + 0.15f, 1.05f, 7.15f, STONE, 2);
    box(m, 0, 3.25f, 0, nw, 3.25f, 7.0f, PLASTER, 6);
    const float yr = wy + 0.1f + nw * tn, ex = nw + 0.55f, ey = yr - ex * tn;
    slab(m, {-ex, ey, 7.2f}, {0, yr, 7.2f}, {0, yr, nz0 - 0.5f}, {-ex, ey, nz0 - 0.5f}, 0.2f, TILE, 3);
    slab(m, {ex, ey, 7.2f}, {0, yr, 7.2f}, {0, yr, nz0 - 0.5f}, {ex, ey, nz0 - 0.5f}, 0.2f, TILE, 3);
    tri(m, {-nw, wy, nz0 - 0.01f}, {nw, wy, nz0 - 0.01f}, {0, yr - 0.22f, nz0 - 0.01f}, -Z, PLASTER, 6);
    for (int sd : {1, -1}){ const P3 n = {(float)sd, 0, 0}, t = {0, 0, 1};
        for (float zz : {-4.6f, -1.6f, 1.4f}) archWindow(m, {sd * nw, 3.6f, zz}, t, n, 1.15f, 2.6f, GLASS, 4, true);
    }
    // --- choir at the back
    const float cw = 2.4f, cz0 = -10.3f, cy = 4.8f, ct = 0.781f, cyr = cy + 0.1f + cw * ct, cex = cw + 0.4f, cey = cyr - cex * ct;
    box(m, 0, -0.45f, (cz0 + nz0) / 2, cw + 0.1f, 1.05f, (nz0 - cz0) / 2 + 0.05f, STONE, 2);        // plinth + foundation of the choir
    box(m, 0, 3.4f, (cz0 + nz0) / 2, cw, 1.4f, (nz0 - cz0) / 2, PLASTER, 6);
    slab(m, {-cex, cey, nz0 + 0.1f}, {0, cyr, nz0 + 0.1f}, {0, cyr, cz0 - 0.4f}, {-cex, cey, cz0 - 0.4f}, 0.18f, TILE, 3);
    slab(m, {cex, cey, nz0 + 0.1f}, {0, cyr, nz0 + 0.1f}, {0, cyr, cz0 - 0.4f}, {cex, cey, cz0 - 0.4f}, 0.18f, TILE, 3);
    tri(m, {-cw, cy, cz0 - 0.01f}, {cw, cy, cz0 - 0.01f}, {0, cyr - 0.2f, cz0 - 0.01f}, -Z, PLASTER, 6);
    archWindow(m, {0, 3.2f, cz0}, X, -Z, 0.9f, 1.9f, GLASS, 4, true);
    // --- tower: shaft, cornices, belfry with openings, four little gables, needle spire, gilded ball
    const float tz = 7.3f, th = 2.3f;
    box(m, 0, -0.45f, tz, th + 0.2f, 1.05f, th + 0.2f, STONE, 2);                                  // plinth
    box(m, 0, 6.2f, tz, th, 7.8f, th, PLASTER, 6);                                                  // shaft y -1.6 .. 14
    for (float cx : {-th, th}) for (float cz : {tz - th, tz + th}) box(m, cx, 6.5f, cz, 0.16f, 6.5f, 0.16f, STONE, 2);   // corner stones
    box(m, 0, 13.98f, tz, th + 0.22f, 0.14f, th + 0.22f, STONE, 2);                                // cornice
    box(m, 0, 15.75f, tz, 2.0f, 1.75f, 2.0f, PLASTER, 6);                                          // belfry y 14 .. 17.5
    box(m, 0, 17.55f, tz, 2.22f, 0.12f, 2.22f, STONE, 2);                                          // cornice under the spire
    for (int sd = 0; sd < 4; sd++){ const float a = sd * 1.5707963f; const P3 n = {std::sin(a), 0, std::cos(a)}, t = {n.z, 0, -n.x};
        const P3 fc = P3{0, 0, tz} + n * 2.0f;
        archWindow(m, fc + P3{0, 15.9f, 0}, t, n, 1.15f, 2.1f, DARK, 0, true);                      // belfry opening
        for (int k = 0; k < 4; k++) obox(m, fc + P3{0, 15.0f + k * 0.5f, 0} + n * 0.05f, t, n, 0.55f, 0.04f, 0.04f, WOOD_D, 0);   // louvre slats
        tri(m, fc + t * -1.55f + P3{0, 17.55f, 0} + n * 0.15f, fc + t * 1.55f + P3{0, 17.55f, 0} + n * 0.15f, fc + P3{0, 19.9f, 0} + n * 0.15f, n, PLASTER, 6);   // gable
    }
    clockFace(m, {0, 11.2f, tz + th + 0.02f}, X, Z); clockFace(m, {th + 0.02f, 11.2f, tz}, {0, 0, -1}, X); clockFace(m, {-th - 0.02f, 11.2f, tz}, {0, 0, 1}, -X);
    for (int sd : {1, -1}) archWindow(m, {sd * (th + 0.01f), 6.5f, tz}, {0, 0, 1}, {(float)sd, 0, 0}, 0.65f, 1.5f, GLASS, 4, true);
    archWindow(m, {0, 7.0f, tz + th + 0.01f}, X, Z, 0.8f, 1.8f, GLASS, 4, true);
    // front door with pointed arch and stone surround, steps
    const float fz = tz + th;
    box(m, 0, 1.5f, fz + 0.03f, 0.95f, 1.5f, 0.05f, WOOD_D, 0); tri(m, {-0.95f, 3.0f, fz + 0.08f}, {0.95f, 3.0f, fz + 0.08f}, {0, 4.1f, fz + 0.08f}, Z, WOOD_D, 0);
    box(m, -1.12f, 1.65f, fz + 0.06f, 0.14f, 1.65f, 0.08f, STONE, 2); box(m, 1.12f, 1.65f, fz + 0.06f, 0.14f, 1.65f, 0.08f, STONE, 2); box(m, 0, 0.08f, fz + 0.6f, 1.6f, 0.18f, 0.6f, STONE, 2);
    // the needle: octagonal, very slender, slate; gilded ball + cross on top
    const P3 apex = {0, 31.0f, tz};
    pyramid(m, {0, 17.6f, tz}, 2.3f, 8, 0.3926991f, apex, SLATE, 3);
    obox(m, {0, 31.2f, tz}, X, Z, 0.22f, 0.22f, 0.22f, GOLD, 0);
}

// ======================================================= SUMMIT: restaurant, petrol station, pump island, car park =======================================================
static const Col ASPH = {0.20f, 0.21f, 0.22f}, PAINT = {0.93f, 0.93f, 0.90f}, PRED = {0.78f, 0.08f, 0.08f}, PYEL = {0.95f, 0.78f, 0.12f};

// the alpine lodge restaurant: stone base, plaster ground floor with big windows, log upper floor, broad roof, terrace with tables + parasols, roof sign. FRONT = +Z.
static void buildRestaurant(Mesh& m){
    const float hx = 11.f, hz = 6.f, wallTop = 7.1f, tn = 0.42f, wu = hx + 0.1f, du = hz + 0.1f;
    const float yr = wallTop + 0.12f + du * tn, zE = du + 2.0f, ey = yr - zE * tn, xe = wu + 1.4f;
    const P3 X = {1, 0, 0}, Z = {0, 0, 1};
    box(m, 0, 0.05f, 0, hx + 0.1f, 0.55f, hz + 0.1f, STONE, 2);                      // foundation y -0.5 .. 0.6
    box(m, 0, 2.4f, 0, hx, 1.8f, hz, PLASTER, 6);                                    // ground floor y 0.6 .. 4.2
    box(m, 0, 4.2f, 0, hx + 0.15f, 0.1f, hz + 0.15f, WOOD_D, 1);                     // floor band
    box(m, 0, 5.65f, 0, wu, 1.45f, du, WOOD, 1);                                     // log upper floor y 4.2 .. 7.1
    for (float xs : {wu, -wu}) tri(m, {xs, wallTop, -du}, {xs, wallTop, du}, {xs, yr - 0.17f, 0}, X * xs, WOOD_L, 1);   // gables
    slab(m, {-xe, ey, zE}, {xe, ey, zE}, {xe, yr, 0}, {-xe, yr, 0}, 0.2f, ROOF, 3);
    slab(m, {-xe, ey, -zE}, {xe, ey, -zE}, {xe, yr, 0}, {-xe, yr, 0}, 0.2f, ROOF, 3);
    box(m, 0, yr + 0.05f, 0, xe + 0.02f, 0.07f, 0.13f, ROOF, 0);                     // ridge cap
    for (float cx : {-5.5f, 5.5f}){ box(m, cx, yr + 0.2f, -1.6f, 0.5f, 1.4f, 0.5f, STONE, 2); box(m, cx, yr + 1.65f, -1.6f, 0.62f, 0.07f, 0.62f, STONE, 2); }   // chimneys
    // --- front: entrance (glazed double door) + big windows, upper-floor windows with shutters + flower boxes
    window(m, {0, 1.75f, hz}, X, Z, 2.0f, 2.2f, false, false);
    for (float wx : {-8.8f, -6.0f, -3.2f, 3.2f, 6.0f, 8.8f}) window(m, {wx, 2.5f, hz}, X, Z, 2.2f, 1.9f, false, false);
    for (float wx : {-8.f, -4.f, 0.f, 4.f, 8.f}) window(m, {wx, 5.6f, du}, X, Z, 1.0f, 1.2f, true, true);
    for (int sd : {1, -1}){ const P3 n = {(float)sd, 0, 0}, t = {0, 0, 1};
        for (float zz : {-3.f, 0.f, 3.f}){ window(m, {sd * hx, 2.5f, zz}, t, n, 1.4f, 1.6f, false, false); window(m, {sd * wu, 5.6f, zz}, t, n, 1.0f, 1.2f, true, false); } }
    for (float wx : {-8.f, -4.f, 0.f, 4.f, 8.f}){ window(m, {wx, 2.5f, -hz}, X, {0, 0, -1}, 1.6f, 1.6f, false, false); window(m, {wx, 5.6f, -du}, X, {0, 0, -1}, 1.0f, 1.2f, true, false); }
    // --- terrace in front: deck, rail with a gap for the steps, tables, chairs, parasols
    box(m, 0, 0.2f, 7.75f, 10.4f, 0.3f, 1.75f, WOOD_L, 1);                           // deck y -0.1 .. 0.5, z 6 .. 9.5
    box(m, 0, 0.15f, 9.9f, 1.3f, 0.15f, 0.4f, STONE, 2);                             // steps
    for (int k = 0; k <= 8; k++){ const float px = -10.3f + k * 2.575f; if (std::fabs(px) < 1.5f) continue; box(m, px, 1.0f, 9.4f, 0.07f, 0.5f, 0.07f, WOOD_D, 1); }
    for (float sg : {-1.f, 1.f}){ const float cx = sg * 5.9f, hw = 4.4f; box(m, cx, 1.5f, 9.4f, hw, 0.04f, 0.06f, WOOD_L, 1); box(m, cx, 1.0f, 9.4f, hw, 0.03f, 0.04f, WOOD_L, 1); }
    for (float sx : {-10.3f, 10.3f}){ for (float pz : {6.2f, 7.8f}) box(m, sx, 1.0f, pz, 0.07f, 0.5f, 0.07f, WOOD_D, 1); box(m, sx, 1.5f, 7.8f, 0.06f, 0.04f, 1.7f, WOOD_L, 1); box(m, sx, 1.0f, 7.8f, 0.04f, 0.03f, 1.7f, WOOD_L, 1); }
    int pi = 0;
    for (float tx : {-8.f, -4.f, 4.f, 8.f}){
        box(m, tx, 1.2f, 8.0f, 0.6f, 0.03f, 0.6f, WHITE, 0); box(m, tx, 0.85f, 8.0f, 0.04f, 0.35f, 0.04f, DARK, 0);               // table
        for (float cz : {-0.95f, 0.95f}){ box(m, tx, 0.95f, 8.0f + cz, 0.22f, 0.025f, 0.22f, WOOD_D, 1); box(m, tx, 1.2f, 8.0f + cz * 1.2f, 0.22f, 0.25f, 0.02f, WOOD_D, 1); }   // chairs
        box(m, tx, 2.0f, 8.0f, 0.03f, 1.5f, 0.03f, DARK, 0);                                                                       // parasol pole (y 0.5 .. 3.5)
        pyramid(m, {tx, 3.0f, 8.0f}, 1.7f, 8, 0.3927f, {tx, 3.7f, 8.0f}, (pi++ & 1) ? FWHITE : PRED, 0);
    }
    // --- roof sign: red board with a gold fork and knife, readable from the front and from the back
    const float sy = yr + 1.55f;
    box(m, -2.6f, yr + 0.45f, 0, 0.07f, 0.45f, 0.07f, DARK, 0); box(m, 2.6f, yr + 0.45f, 0, 0.07f, 0.45f, 0.07f, DARK, 0);
    box(m, 0, sy, 0, 3.35f, 1.05f, 0.08f, WHITE, 0); box(m, 0, sy, 0, 3.2f, 0.9f, 0.1f, PRED, 0);
    for (float zs : {0.115f, -0.115f}){
        box(m, -1.0f, sy - 0.25f, zs, 0.07f, 0.45f, 0.012f, GOLD, 0); box(m, -1.0f, sy + 0.2f, zs, 0.17f, 0.04f, 0.012f, GOLD, 0);
        for (float d : {-0.14f, 0.f, 0.14f}) box(m, -1.0f + d, sy + 0.42f, zs, 0.025f, 0.22f, 0.012f, GOLD, 0);
        box(m, 1.0f, sy - 0.3f, zs, 0.06f, 0.4f, 0.012f, GOLD, 0); box(m, 1.05f, sy + 0.25f, zs, 0.1f, 0.32f, 0.012f, GOLD, 0);
        box(m, 0, sy, zs, 0.75f, 0.06f, 0.012f, FWHITE, 0); box(m, 0, sy - 0.3f, zs, 0.55f, 0.06f, 0.012f, FWHITE, 0);              // text-like bars
    }
}

// petrol station: shop at the back, big open canopy in front (the car drives under it), price pylon beside it. FRONT = +Z, canopy spans z -1.2 .. 13.2
static void buildPetrol(Mesh& m){
    const P3 X = {1, 0, 0}, Z = {0, 0, 1};
    box(m, 0, 1.9f, -6.f, 8.f, 1.9f, 3.f, PLASTER, 6);                               // shop y 0 .. 3.8, z -9 .. -3
    box(m, 0, 0.0f, -6.f, 8.15f, 0.25f, 3.15f, STONE, 2);                            // plinth
    box(m, 0, 3.95f, -6.f, 8.3f, 0.2f, 3.3f, WHITE, 0);                              // flat roof
    box(m, 0, 3.55f, -2.9f, 8.1f, 0.25f, 0.06f, PRED, 0);                            // red band over the glazing
    for (float wx : {-5.5f, -2.f, 2.f, 5.5f}) window(m, {wx, 1.9f, -3.0f}, X, Z, 2.6f, 2.0f, false, false);
    box(m, 0, 1.1f, -2.97f, 0.9f, 1.1f, 0.05f, WOOD_D, 0);
    for (int sd : {1, -1}) window(m, {sd * 8.0f, 1.9f, -6.f}, {0, 0, 1}, {(float)sd, 0, 0}, 1.6f, 1.6f, false, false);
    // canopy
    box(m, 0, 5.15f, 6.f, 10.2f, 0.3f, 7.2f, WHITE, 0);                              // roof slab y 4.85 .. 5.45
    box(m, 0, 5.15f, 13.3f, 10.3f, 0.4f, 0.1f, PRED, 0); box(m, 0, 5.15f, -1.3f, 10.3f, 0.4f, 0.1f, PRED, 0);
    for (float sx : {-10.3f, 10.3f}) box(m, sx, 5.15f, 6.f, 0.1f, 0.4f, 7.3f, PRED, 0);
    box(m, 0, 5.62f, 6.f, 10.2f, 0.04f, 7.2f, PYEL, 0);                              // yellow top strip
    for (float px : {-8.f, 8.f}) for (float pz : {1.5f, 10.5f}){ box(m, px, 2.45f, pz, 0.28f, 2.45f, 0.28f, WHITE, 0); box(m, px, 0.6f, pz, 0.31f, 0.6f, 0.31f, PRED, 0); }
    // price pylon (3 price boards, readable from both sides)
    box(m, -12.8f, 4.2f, 14.f, 0.18f, 4.2f, 0.18f, DARK, 0);
    box(m, -12.8f, 8.9f, 14.f, 1.35f, 1.5f, 0.1f, WHITE, 0); box(m, -12.8f, 10.15f, 14.f, 1.35f, 0.35f, 0.12f, PRED, 0);
    for (float zs : {0.07f, -0.07f}) for (int k = 0; k < 3; k++){
        box(m, -12.8f, 9.4f - k * 0.62f, 14.f + zs, 1.1f, 0.24f, 0.012f, DARK, 0);
        box(m, -12.1f, 9.4f - k * 0.62f, 14.f + zs * 1.2f, 0.4f, 0.1f, 0.012f, PYEL, 0);
    }
}

// one pump island (low kerb + two pumps). Long side along local Z.
static void buildPump(Mesh& m){
    box(m, 0, 0.1f, 0, 0.6f, 0.1f, 2.6f, STONE, 2);                                  // island y 0 .. 0.2
    for (float pz : {-1.2f, 1.2f}){
        box(m, 0, 1.05f, pz, 0.3f, 0.85f, 0.22f, WHITE, 0);                           // body y 0.2 .. 1.9
        box(m, 0, 1.95f, pz, 0.34f, 0.07f, 0.26f, PRED, 0);                           // red cap
        box(m, 0, 0.35f, pz, 0.32f, 0.15f, 0.24f, PRED, 0);                           // red base
        for (int sd : {1, -1}){
            box(m, sd * 0.305f, 1.5f, pz, 0.012f, 0.22f, 0.15f, GLASS, 4);              // display
            box(m, sd * 0.33f, 1.05f, pz + 0.12f, 0.035f, 0.12f, 0.035f, DARK, 0);       // nozzle holder
            box(m, sd * 0.30f, 0.9f, pz, 0.02f, 0.02f, 0.2f, BLACK, 0);                   // hose
        }
    }
}

// the car park: asphalt disc (radius R - 3.9, the ring road is the outer lane) with painted bays. Pad-local frame = world axes; ground y of the instance = pad height + 0.06.
//  th = direction of the road entry. Block of two rows in front of the restaurant + one ring of bays all round the pad.
static void paintLine(Mesh& m, float x0, float z0, float x1, float z1, float w){
    const float dx = x1 - x0, dz = z1 - z0, L = std::sqrt(dx * dx + dz * dz); if (L < 1e-4f) return;
    obox(m, {(x0 + x1) / 2, 0.03f, (z0 + z1) / 2}, {dx / L, 0, dz / L}, {-dz / L, 0, dx / L}, L / 2 + w / 2, 0.012f, w / 2, PAINT, 8);
}
// ---------- the rim of the summit: rock wall, wooden rail, viewpoint (all in the pad-local frame, y = 0 is the pad surface) ----------
static inline float rnf(uint32_t& s){ s = s * 1664525u + 1013904223u; return (float)(s >> 8) / 16777216.f; }
static inline Col shade(Col c, float f){ return {c.r * f, c.g * f, c.b * f}; }
// one boulder: 7-sided jittered frustum + lumpy top, sunk 1.2 m into the ground
static void rock(Mesh& m, float cx, float cz, float r, float h, uint32_t& s, Col base){
    const int S = 7; P3 B[S], T[S]; const float a0 = rnf(s) * 6.2831853f, yt = h * (0.8f + 0.4f * rnf(s));
    for (int k = 0; k < S; k++){
        const float a = a0 + k * 6.2831853f / S + (rnf(s) - 0.5f) * 0.35f, rr = r * (0.72f + 0.56f * rnf(s)), tr = rr * (0.40f + 0.30f * rnf(s));
        B[k] = {cx + std::cos(a) * rr, -1.2f, cz + std::sin(a) * rr}; T[k] = {cx + std::cos(a) * tr, yt * (0.85f + 0.30f * rnf(s)), cz + std::sin(a) * tr};
    }
    const P3 C = {cx + (rnf(s) - 0.5f) * r * 0.3f, yt + h * 0.12f * rnf(s) + 0.2f, cz + (rnf(s) - 0.5f) * r * 0.3f};
    const float tone = 0.80f + 0.40f * rnf(s); const Col col = shade(base, tone), top = shade(base, tone * 1.18f);
    for (int k = 0; k < S; k++){
        const int k2 = (k + 1) % S; const P3 mid = (B[k] + B[k2] + T[k] + T[k2]) * 0.25f;
        quad(m, B[k], B[k2], T[k2], T[k], {mid.x - cx, 0.2f, mid.z - cz}, shade(col, 0.88f + 0.24f * rnf(s)), 2);
        tri(m, T[k], T[k2], C, {0, 1, 0}, top, 2);
    }
}
typedef std::function<int(double, double&)> EdgeFn;       // angle (world) -> kind (0 none, 1 rail, 2 rock wall, 3 viewpoint), radius
typedef std::function<float(float, float)> ClrFn;         // pad-local x, z -> distance to the nearest road edge
static void buildPadEdge(Mesh& m, float R, float th, float viewRel, const EdgeFn& edge, const ClrFn& clr){
    static const Col ROCK = {0.50f, 0.48f, 0.45f};
    // ---- rock wall: three rows of boulders (low front, higher behind), only where edgeKind() says 2 and the road is not in the way
    { uint32_t s = 7u; const float step = 3.0f / (R + 10.f); const int total = (int)(6.2831853f / step);
      for (int i = 0; i < total; i++){
        const double a = th + i * (double)step; double rad; if (edge(a, rad) != 2) continue; const float ca = (float)std::cos(a), sa = (float)std::sin(a);
        const float rr[3] = {(float)rad - 0.3f, (float)rad + 1.6f, (float)rad + 4.6f}, rs[3] = {1.3f + 0.6f * rnf(s), 2.6f + 0.9f * rnf(s), 3.2f + 0.8f * rnf(s)}, hs[3] = {1.2f + 1.2f * rnf(s), 3.4f + 2.6f * rnf(s), 5.0f + 4.0f * rnf(s)};
        for (int l = 0; l < 3; l++){ const float x = ca * rr[l] + (rnf(s) - 0.5f) * 1.2f, z = sa * rr[l] + (rnf(s) - 0.5f) * 1.2f; if (clr(x, z) < rs[l] + 0.5f) continue; rock(m, x, z, rs[l], hs[l], s, ROCK); }
      } }
    // ---- wooden guardrail round the rim: posts every ~2.4 m, two rails
    { const float step = 2.4f / (R + 5.2f); const int total = (int)(6.2831853f / step);
      for (int i = 0; i < total; i++){
        double r0, r1; const double a0 = th + i * (double)step, a1 = th + (i + 1) * (double)step; if (edge(a0, r0) != 1) continue;
        const float x0 = (float)(std::cos(a0) * r0), z0 = (float)(std::sin(a0) * r0);
        box(m, x0, 0.45f, z0, 0.09f, 0.70f, 0.09f, WOOD_D, 1); box(m, x0, 1.17f, z0, 0.11f, 0.03f, 0.11f, WOOD_D, 1);   // post + cap
        if (edge(a1, r1) != 1) continue; const float x1 = (float)(std::cos(a1) * r1), z1 = (float)(std::sin(a1) * r1), dx = x1 - x0, dz = z1 - z0, L = std::sqrt(dx * dx + dz * dz); if (L < 0.1f) continue;
        const P3 t = {dx / L, 0, dz / L}, n = {-dz / L, 0, dx / L};
        obox(m, {(x0 + x1) / 2, 0.98f, (z0 + z1) / 2}, t, n, L / 2 + 0.04f, 0.075f, 0.05f, WOOD_L, 1); obox(m, {(x0 + x1) / 2, 0.55f, (z0 + z1) / 2}, t, n, L / 2 + 0.04f, 0.06f, 0.04f, WOOD, 1);
      } }
    // ---- viewpoint: timber deck beside the car park, rail on the 3 open sides, two benches, a coin binocular, a panorama board and a Swiss flag
    { const float av = th + viewRel, cn = std::cos(av), sn = std::sin(av); const P3 N = {cn, 0, sn}, T = {-sn, 0, cn};
      auto Q = [&](float lat, float rad, float y){ return P3{T.x * lat + N.x * rad, y, T.z * lat + N.z * rad}; };
      const float r0 = R + 5.0f, r1 = R + 14.5f, rm = (r0 + r1) / 2, hw = 8.0f;
      obox(m, Q(0, rm, -0.55f), T, N, hw, 0.7f, (r1 - r0) / 2 - 0.1f, STONE, 2);                                  // stone footing (sunk, so it never floats)
      obox(m, Q(0, rm, 0.12f), T, N, hw, 0.12f, (r1 - r0) / 2, WOOD_L, 1);                                         // deck, top at y = 0.24
      for (int k = -7; k <= 7; k++) obox(m, Q(k * 1.07f, rm, 0.245f), T, N, 0.015f, 0.01f, (r1 - r0) / 2, WOOD_D, 0);   // plank seams
      auto post = [&](float lat, float rad){ const P3 p = Q(lat, rad, 0.0f); box(m, p.x, 0.80f, p.z, 0.10f, 0.60f, 0.10f, WOOD_D, 1); box(m, p.x, 1.43f, p.z, 0.12f, 0.03f, 0.12f, WOOD_D, 1); };
      const float rr1 = r1 - 0.3f, ex = hw - 0.3f;
      for (float lat = -ex; lat <= ex + 0.01f; lat += 2.0f) post(lat, rr1);                                        // outer rail along the drop
      obox(m, Q(0, rr1, 1.28f), T, N, ex + 0.1f, 0.075f, 0.05f, WOOD_L, 1); obox(m, Q(0, rr1, 0.82f), T, N, ex + 0.1f, 0.06f, 0.04f, WOOD, 1);
      for (int sd = -1; sd <= 1; sd += 2){                                                                          // side rails
        for (float rad = r0 + 0.3f; rad <= rr1; rad += 2.1f) post(sd * ex, rad);
        obox(m, Q(sd * ex, rm, 1.28f), N, T, (r1 - r0) / 2, 0.075f, 0.05f, WOOD_L, 1); obox(m, Q(sd * ex, rm, 0.82f), N, T, (r1 - r0) / 2, 0.06f, 0.04f, WOOD, 1); }
      for (int sd = -1; sd <= 1; sd += 2){                                                                          // benches facing the view
        const float lat = sd * 4.2f, rad = r1 - 2.2f; obox(m, Q(lat, rad, 0.72f), T, N, 0.95f, 0.04f, 0.24f, WOOD_L, 1); obox(m, Q(lat, rad - 0.3f, 1.05f), T, N, 0.95f, 0.22f, 0.03f, WOOD_L, 1);
        for (float o : {-0.8f, 0.8f}) obox(m, Q(lat + o, rad, 0.48f), T, N, 0.05f, 0.24f, 0.2f, WOOD_D, 1); }
      { const P3 p = Q(0, rr1 - 1.3f, 0.24f); box(m, p.x, 0.85f, p.z, 0.09f, 0.62f, 0.09f, SLATE, 0);                  // coin binocular on a post
        const P3 q = Q(0, rr1 - 1.45f, 1.55f); obox(m, q, T, N, 0.20f, 0.10f, 0.22f, BLACK, 0); for (float o : {-0.1f, 0.1f}){ const P3 e = Q(o, rr1 - 1.75f, 1.55f); box(m, e.x, e.y, e.z, 0.05f, 0.05f, 0.12f, GLASS, 4); } }
      { const P3 a = Q(-5.8f, r0 + 2.6f, 0.0f), b = Q(-3.6f, r0 + 2.6f, 0.0f), c = Q(-4.7f, r0 + 2.6f, 1.8f);          // panorama board (faces the car park)
        box(m, a.x, 0.9f, a.z, 0.08f, 0.9f, 0.08f, WOOD_D, 1); box(m, b.x, 0.9f, b.z, 0.08f, 0.9f, 0.08f, WOOD_D, 1); obox(m, c, T, N, 1.25f, 0.6f, 0.04f, {0.12f, 0.30f, 0.24f}, 0);
        const P3 f = N * -0.05f; for (int k = 0; k < 3; k++){ const float lx = -5.5f + k * 0.8f, ph = 0.35f + 0.2f * (k % 2); const P3 p0 = Q(lx - 0.45f, r0 + 2.6f, 1.55f) + f, p1 = Q(lx + 0.45f, r0 + 2.6f, 1.55f) + f, p2 = Q(lx, r0 + 2.6f, 1.55f + ph + 0.35f) + f; tri(m, p0, p1, p2, N * -1.f, FWHITE, 0); } }
      { const P3 p = Q(6.4f, r0 + 2.2f, 0.0f); box(m, p.x, 3.3f, p.z, 0.06f, 3.3f, 0.06f, WHITE, 0);                       // flag pole + Swiss flag
        const P3 fl = Q(6.4f, r0 + 2.2f, 5.2f) + T * 0.0f + N * 0.0f; const P3 fc = {fl.x + T.x * 0.7f, fl.y, fl.z + T.z * 0.7f};
        obox(m, fc, T, N, 0.7f, 0.7f, 0.02f, RED, 0); obox(m, fc + N * 0.025f, T, N, 0.42f, 0.11f, 0.01f, FWHITE, 0); obox(m, fc + N * 0.025f, T, N, 0.11f, 0.42f, 0.01f, FWHITE, 0); } }
}

static void buildPad(Mesh& m, float R, float th, const EdgeFn& edge = EdgeFn(), const ClrFn& clr = ClrFn(), float viewRel = 0.f){
    const float Rd = R - 3.9f; const int N = 120;
    { const uint16_t base = (uint16_t)m.count(); const float c0[10] = {0, 0, 0, 0, 1, 0, ASPH.r, ASPH.g, ASPH.b, 7.f}; m.v.insert(m.v.end(), c0, c0 + 10);
      for (int k = 0; k < N; k++){ const float a = 6.2831853f * k / N, f[10] = {Rd * std::cos(a), 0, Rd * std::sin(a), 0, 1, 0, ASPH.r, ASPH.g, ASPH.b, 7.f}; m.v.insert(m.v.end(), f, f + 10); }
      for (int k = 0; k < N; k++){ m.i.push_back(base); m.i.push_back(base + 1 + (k + 1) % N); m.i.push_back(base + 1 + k); } }   // fan, facing up
    const float cu = std::cos(th), su = std::sin(th);
    auto W = [&](float u, float v, float& x, float& z){ x = cu * u - su * v; z = su * u + cu * v; };              // (u,v) -> pad-local world offset
    auto L = [&](float u0, float v0, float u1, float v1){ float x0, z0, x1, z1; W(u0, v0, x0, z0); W(u1, v1, x1, z1); paintLine(m, x0, z0, x1, z1, 0.14f); };
    // ring of bays (radial lines + inner and outer arc)
    { const float r0 = 54.5f, r1 = 60.f; const int n = (int)(6.2831853f * 0.5f * (r0 + r1) / 2.7f);
      if (Rd > r1 + 3.f){
        for (int k = 0; k < n; k++){ const float a = 6.2831853f * k / n; paintLine(m, r0 * std::cos(a), r0 * std::sin(a), r1 * std::cos(a), r1 * std::sin(a), 0.14f); }
        for (float r : {r0, r1}) for (int k = 0; k < 160; k++){ const float a = 6.2831853f * k / 160, b = 6.2831853f * (k + 1) / 160; paintLine(m, r * std::cos(a), r * std::sin(a), r * std::cos(b), r * std::sin(b), 0.14f); }
      } }
    // double row of bays in front of the restaurant
    { const int nb = 18; const float v0 = -24.3f, sp = 2.7f;
      for (int k = 0; k <= nb; k++){ const float v = v0 + k * sp; L(7.f, v, 12.2f, v); L(18.2f, v, 23.4f, v); }
      for (float u : {7.f, 12.2f, 18.2f, 23.4f}) L(u, v0, u, v0 + nb * sp); }
    if (edge && clr) buildPadEdge(m, R, th, viewRel, edge, clr);
}


// ======================================================= the mountain cabin (old log house with a low slate roof, coloured shutters, wooden fence) =======================================================
static void buildCabin(Mesh& m){
    const float hw = 5.f, hd = 3.6f, wallTop = 3.5f, tn = 0.30f;
    const float yr = wallTop + 0.1f + hd * tn, zE = hd + 1.4f, ey = yr - zE * tn, xe = hw + 0.9f;
    const P3 X = {1, 0, 0}, Z = {0, 0, 1};
    static const Col SLATEG = {0.42f, 0.42f, 0.40f}, GREEN = {0.10f, 0.36f, 0.30f};
    box(m, 0, -0.3f, 0, hw + 0.1f, 1.2f, hd + 0.1f, STONE, 2);                       // stone plinth y -1.5 .. 0.9 (deep, so it never floats on a slope)
    box(m, 0, 2.2f, 0, hw, 1.3f, hd, WOOD, 1);                                       // log walls y 0.9 .. 3.5
    for (float cx : {-hw, hw}) for (float cz : {-hd, hd}) box(m, cx, 2.2f, cz, 0.17f, 1.3f, 0.17f, WOOD_D, 1);   // log corners
    for (float xs : {hw, -hw}) tri(m, {xs, wallTop, -hd}, {xs, wallTop, hd}, {xs, yr - 0.1f, 0}, X * xs, WOOD_L, 1);   // gables
    slab(m, {-xe, ey, zE}, {xe, ey, zE}, {xe, yr, 0}, {-xe, yr, 0}, 0.14f, SLATEG, 3);   // wide, low roof
    slab(m, {-xe, ey, -zE}, {xe, ey, -zE}, {xe, yr, 0}, {-xe, yr, 0}, 0.14f, SLATEG, 3);
    box(m, 0, yr + 0.05f, 0, xe + 0.02f, 0.06f, 0.12f, SLATEG, 0);
    box(m, -3.2f, yr + 0.5f, -0.6f, 0.4f, 1.0f, 0.4f, STONE, 2); box(m, -3.2f, yr + 1.55f, -0.6f, 0.5f, 0.06f, 0.5f, STONE, 2);   // chimney
    box(m, 0.8f, 1.95f, hd + 0.03f, 0.55f, 1.05f, 0.05f, GREEN, 0); box(m, 0.8f, 3.05f, hd + 0.04f, 0.7f, 0.06f, 0.06f, WHITE, 0);   // green door
    const float wxs[4] = {-3.5f, -1.6f, 2.5f, 3.9f};
    for (int k = 0; k < 4; k++) window(m, {wxs[k], 2.3f, hd}, X, Z, 0.7f, 0.9f, true, k == 0 || k == 3);
    for (int sd : {1, -1}) window(m, {sd * hw, 2.3f, 0}, {0, 0, 1}, {(float)sd, 0, 0}, 0.7f, 0.9f, true, false);
    window(m, {-1.5f, 2.3f, -hd}, X, {0, 0, -1}, 0.7f, 0.9f, true, false); window(m, {2.0f, 2.3f, -hd}, X, {0, 0, -1}, 0.7f, 0.9f, true, false);
    // porch under the roof overhang: deck, two posts, a little bench
    box(m, 0, 0.3f, hd + 0.8f, hw - 0.3f, 0.2f, 0.8f, WOOD_L, 1);
    for (float px : {-(hw - 0.4f), hw - 0.4f}) box(m, px, 1.8f, hd + 1.45f, 0.09f, 1.3f, 0.09f, WOOD_D, 1);
    box(m, -2.6f, 0.95f, hd + 0.35f, 0.9f, 0.04f, 0.22f, WOOD_L, 1); box(m, -3.3f, 0.7f, hd + 0.35f, 0.05f, 0.2f, 0.2f, WOOD_D, 1); box(m, -1.9f, 0.7f, hd + 0.35f, 0.05f, 0.2f, 0.2f, WOOD_D, 1);
    // woodpile at the side wall
    for (int r = 0; r < 3; r++) for (int k = 0; k < 5 - r; k++) obox(m, {-(hw + 0.35f), 1.15f + r * 0.32f, -2.0f + k * 0.34f + r * 0.17f}, X, Z, 0.28f, 0.15f, 0.15f, WOOD_L, 1);
    // post-and-rail fence in front of the house (as on the farms of the Alps)
    const float fz = hd + 3.0f, fx = 9.0f;
    for (int k = 0; k <= 8; k++) box(m, -fx + k * (2 * fx / 8.f), 0.4f, fz, 0.06f, 0.85f, 0.06f, WOOD_D, 1);
    box(m, 0, 0.55f, fz, fx, 0.04f, 0.035f, WOOD_L, 1); box(m, 0, 0.95f, fz, fx, 0.04f, 0.035f, WOOD_L, 1);
}

} // namespace VillageMesh
