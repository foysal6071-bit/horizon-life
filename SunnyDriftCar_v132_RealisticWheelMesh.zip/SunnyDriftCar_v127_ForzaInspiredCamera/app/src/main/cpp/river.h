// Sunny Drift - river: C++ port of the HTML "River constants" / groundH() block (pure C++, no OpenGL).
//  * RIVER_CTRL is the same hand-traced centre line as in the HTML, sampled with the same Catmull-Rom spline
//  * riverSd() = signed distance from that line (the bridges, the road cuts, the walls and the trees all use it)
//  * riverGroundH() = the carved river bed (bank slope + noise), terrainMesh()/waterMesh() build the visible river
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <unordered_map>
#include <vector>

namespace River {

static const double RIVER_WALL = 24, RIVER_DEPTH = 3.2, WATER_Y = -1.3;
static const int RV_CELL = 64; static const double RV_RANGE = 280;

// ---- the carved patch = the whole 5 m ground lattice (Terrain uses the same numbers) ----
//  world 1.5x bigger than the first version: lattice x -1350..1350, z -960..960
static const double GX0 = -1350, GX1 = 1350, GZ0 = -960, GZ1 = 960, GCELL = 5.0;
static const int PNX = 540, PNZ = 384;                                              // cells of the patch (2700 / 5, 1920 / 5)
static const double PZ1 = GZ0 + PNZ * GCELL;                                        // real far edge of the patch (960)

// River system: the main river runs west -> east through the valley; two tributaries come down from the mountains and join it.
//  RV_X / RV_Z = main river only (kept for old users), RV_LINES = every river as x,z pairs (minimap).
static std::vector<double> RV_X, RV_Z;
static std::vector<std::vector<float>> RV_LINES;
struct Seg { double ax, az, bx, bz; };
static std::vector<Seg> SEGS;                                                       // every river segment, all rivers
static std::unordered_map<int, std::vector<int>> rvGrid;                            // cell -> indices into SEGS
static double gGx = 0, gGz = 1;          // unit vector pointing away from the river centre line (gradient of riverSd)
static bool ready = false;
static double FSEED0 = 0.5;               // per-launch noise seed (FSEED[0] in the HTML); Terrain::setSeed() overwrites it

static inline double sstep(double a, double b, double x){ double t = std::min(std::max((x - a) / (b - a), 0.0), 1.0); return t*t*(3 - 2*t); }

typedef std::vector<std::pair<double, double>> Pts;
// Catmull-Rom (same spline as the original river) sampled every ~10 m; consecutive samples become segments of THIS river only
static void addRiver(const Pts& P, bool isMain){
    const int n = (int)P.size(); std::vector<double> xs, zs;
    for (int i = 0; i < n - 1; i++){
        const double *p0 = &P[std::max(i-1, 0)].first, *p1 = &P[i].first, *p2 = &P[i+1].first, *p3 = &P[std::min(i+2, n-1)].first;
        const int m = std::max(2, (int)std::ceil(std::hypot(p2[0]-p1[0], p2[1]-p1[1]) / 10));
        for (int k = 0; k < m; k++){
            const double t = (double)k / m, t2 = t*t, t3 = t2*t;
            for (int c = 0; c < 2; c++){
                const double v = 0.5 * ((2*p1[c]) + (-p0[c]+p2[c])*t + (2*p0[c]-5*p1[c]+4*p2[c]-p3[c])*t2 + (-p0[c]+3*p1[c]-3*p2[c]+p3[c])*t3);
                (c ? zs : xs).push_back(v);
            }
        }
    }
    xs.push_back(P[n-1].first); zs.push_back(P[n-1].second);
    for (size_t i = 0; i + 1 < xs.size(); i++) SEGS.push_back({xs[i], zs[i], xs[i+1], zs[i+1]});
    std::vector<float> line; for (size_t i = 0; i < xs.size(); i++){ line.push_back((float)xs[i]); line.push_back((float)zs[i]); }
    RV_LINES.push_back(line);
    if (isMain){ RV_X = xs; RV_Z = zs; }
}
// z of the main river centre line at a given x (to land a tributary exactly on it)
static double mainZAt(double x){
    for (size_t i = 0; i + 1 < RV_X.size(); i++) if ((RV_X[i] - x) * (RV_X[i+1] - x) <= 0){
        const double d = RV_X[i+1] - RV_X[i], t = d == 0 ? 0 : (x - RV_X[i]) / d; return RV_Z[i] + (RV_Z[i+1] - RV_Z[i]) * t; }
    return 0;
}

static void init(){
    if (ready) return; ready = true;
    // main river: the original hand-traced line (x -882 .. 881) prolonged at both ends towards the mountain ring (x -1300 .. 1300)
    static const double P[][2] = {{-1341.0,-829.0},{-1216.2,-745.8},{-1091.4,-662.6},{-1056.3,-639.2},{-1021.8,-616.3},{-984.4,-593.7},{-948.8,-564.4},{-924.3,-530.7},{-907.2,-494.1},{-896.4,-452.1},{-888.0,-410.1},{-864.2,-376.7},{-825.1,-362.0},{-780.0,-353.3},{-738.5,-343.9},{-695.5,-328.5},{-653.2,-309.5},{-615.5,-289.7},{-575.4,-274.5},{-530.7,-254.7},{-495.3,-225.4},{-465.4,-198.7},{-433.3,-173.5},{-394.0,-160.8},{-351.4,-157.1},{-308.5,-154.1},{-266.4,-145.2},{-225.9,-132.1},{-187.1,-114.3},{-151.1,-94.0},{-117.2,-72.1},{-79.2,-45.9},{-42.9,-20.7},{-9.0,0.8},{30.2,17.0},{73.0,34.3},{110.8,51.7},{146.5,70.2},{179.2,93.6},{205.0,124.6},{225.8,159.0},{241.1,202.7},{248.4,242.2},{256.3,284.0},{274.5,323.7},{305.3,356.1},{340.4,377.1},{377.4,396.2},{413.4,415.0},{450.2,436.6},{489.5,454.7},{526.8,470.3},{562.9,491.5},{600.8,510.0},{639.5,522.9},{680.7,534.2},{723.6,540.5},{768.3,543.8},{809.5,547.8},{855.6,552.3},{895.7,557.8},{941.2,568.8},{981.2,584.1},{1019.2,608.0},{1047.8,636.6},{1073.7,672.1},{1098.3,726.9},{1159.7,863.8},{1221.1,1000.6}};
    Pts main; for (auto& q : P) main.push_back({q[0], q[1]});
    addRiver(main, true);
    for (int cx = -24; cx <= 24; cx++) for (int cz = -24; cz <= 24; cz++){
        const double mx = (cx + 0.5) * RV_CELL, mz = (cz + 0.5) * RV_CELL, lim = RV_RANGE + 0.72 * RV_CELL; std::vector<int> list;
        for (size_t i = 0; i < SEGS.size(); i++){
            const double ax = SEGS[i].ax, az = SEGS[i].az, bx = SEGS[i].bx - ax, bz = SEGS[i].bz - az, bb = bx*bx + bz*bz;
            const double t = std::min(std::max(((mx-ax)*bx + (mz-az)*bz) / (bb == 0 ? 1 : bb), 0.0), 1.0), dx = mx - ax - bx*t, dz = mz - az - bz*t;
            if (dx*dx + dz*dz < lim*lim) list.push_back((int)i);
        }
        if (!list.empty()) rvGrid[(cx + 32) * 128 + (cz + 32)] = list;
    }
}

static double riverSd(double x, double z){
    auto it = rvGrid.find((int)(std::floor(x / RV_CELL) + 32) * 128 + (int)(std::floor(z / RV_CELL) + 32));
    if (it == rvGrid.end()){ gGx = 0; gGz = 1; return 9999; }
    double bd = 1e18, bs = 1, bgx = 0, bgz = 1;
    for (int i : it->second){
        const double ax = SEGS[i].ax, az = SEGS[i].az, bx = SEGS[i].bx - ax, bz = SEGS[i].bz - az; double bb = bx*bx + bz*bz; if (bb == 0) bb = 1;
        const double t = std::min(std::max(((x-ax)*bx + (z-az)*bz) / bb, 0.0), 1.0), ox = x - ax - bx*t, oz = z - az - bz*t, d2 = ox*ox + oz*oz;
        if (d2 < bd){
            bd = d2; const double bl = std::sqrt(bb); bs = (ox*bz - oz*bx) >= 0 ? 1 : -1; bgx = bz / bl; bgz = -bx / bl;
            if (d2 > 1e-8){ const double d = std::sqrt(d2); bgx = ox / d * bs; bgz = oz / d * bs; }
        }
    }
    gGx = bgx; gGz = bgz; return bs * std::sqrt(bd);
}

// ---- fNoise (value noise) used to make the bank wander in and out ----
static double fHash(double x, double y){ const double h = std::sin(x*127.1 + y*311.7 + FSEED0 * 0.37) * 43758.5453; return h - std::floor(h); }
static double fNoise(double x, double y){
    const double ix = std::floor(x), iy = std::floor(y), fx = x - ix, fy = y - iy, u = fx*fx*(3 - 2*fx), v = fy*fy*(3 - 2*fy);
    return (fHash(ix, iy)*(1-u) + fHash(ix+1, iy)*u)*(1-v) + (fHash(ix, iy+1)*(1-u) + fHash(ix+1, iy+1)*u)*v;
}
// height of the carved river bed (groundH in the HTML without the sea part): 0 on dry land, down to -3.2 m in the channel
static double groundH(double x, double z){
    double d = std::fabs(riverSd(x, z)), rv = 0;
    if (d < 33){
        d += (fNoise(x/46 + 3.1, z/46 - 1.7) - 0.5) * 5.0 + (fNoise(x/13 - 4.2, z/13 + 8.8) - 0.5) * 1.7;
        const double t = std::min(std::max((d - 11) / 17, 0.0), 1.0);
        rv = d >= 28 ? 0 : -RIVER_DEPTH * (1 - t*t*(3 - 2*t) * (0.88 + 0.12*t));
    }
    return rv;
}

// ---- visible river: terrain patch (grass -> wet mud -> gravel) + water surface ----
// terrain vertex = pos(3) colour(3) normal(3);  water vertex = pos(3) depth(1)
struct TerrainMesh { std::vector<float> v; std::vector<uint32_t> idx; };
struct WaterMesh   { std::vector<float> v; std::vector<uint32_t> idx; };

// optional extras supplied by Terrain: hill height added to the bed, and the grass base colour (hills / sand / dirt tint)
struct Hooks {
    double (*fieldH)(double x, double z) = nullptr;
    void (*grass)(double x, double z, double fieldH, double& r, double& g, double& b) = nullptr;
};

static Hooks gHooks;                                                                // filled by Terrain::init

static void buildTerrain(TerrainMesh& tm, WaterMesh& wm, const Hooks* hk = nullptr){
    const int nx = PNX, nz = PNZ, W = nx + 1;
    auto hAt = [&](double x, double z){ return groundH(x, z) + (hk && hk->fieldH ? hk->fieldH(x, z) : 0.0); };
    std::vector<float> H((size_t)W * (nz + 1)), D((size_t)W * (nz + 1)), F((size_t)W * (nz + 1));
    for (int j = 0; j <= nz; j++) for (int i = 0; i <= nx; i++){
        const double x = GX0 + i * GCELL, z = GZ0 + j * GCELL; const size_t k = (size_t)j*W + i;
        const double f = hk && hk->fieldH ? hk->fieldH(x, z) : 0.0;
        F[k] = (float)f; H[k] = (float)(groundH(x, z) + f); D[k] = (float)std::fabs(riverSd(x, z));
    }
    // height with one extra ring around the patch so the edge normals are true central differences (they must match the neighbouring hill strips)
    auto hv = [&](int i, int j) -> double {
        if (i >= 0 && i <= nx && j >= 0 && j <= nz) return H[(size_t)j*W + i];
        return hAt(GX0 + i * GCELL, GZ0 + j * GCELL);
    };
    tm.v.reserve((size_t)W * (nz + 1) * 9);
    for (int j = 0; j <= nz; j++) for (int i = 0; i <= nx; i++){
        const size_t k = (size_t)j*W + i; const double h = H[k], x = GX0 + i * GCELL, z = GZ0 + j * GCELL;
        const double hxm = hv(i-1, j), hxp = hv(i+1, j), hzm = hv(i, j-1), hzp = hv(i, j+1);
        double nxv = (hxm - hxp) / (2*GCELL), nzv = (hzm - hzp) / (2*GCELL), l = std::sqrt(nxv*nxv + nzv*nzv + 1);
        // colours: project grass -> pale dry lip -> dark wet mud at the water line -> gravel / sand under the water
        double r = 0.300, g = 0.450, b = 0.190;
        if (hk && hk->grass) hk->grass(x, z, F[k], r, g, b);
        const double dwl = h - WATER_Y;                                  // metres above the water line
        const double bank = 1 - sstep(21, 33, D[k]);                     // damp strip along the river
        auto mix3 = [&](double a0, double a1, double a2, double t){ r += (a0 - r) * t; g += (a1 - g) * t; b += (a2 - b) * t; };
        mix3(0.42, 0.36, 0.22, bank * 0.55);                              // dry pale soil lip above the water
        if (dwl < 0.9) mix3(0.20, 0.16, 0.10, 1 - sstep(0.0, 0.9, dwl));  // dark wet mud at the water line
        if (dwl < 0) mix3(0.46, 0.42, 0.30, sstep(0.0, 0.6, -dwl));       // gravel / sand under the water
        float row[9] = {(float)x, (float)h, (float)z, (float)r, (float)g, (float)b, (float)(nxv / l), (float)(1 / l), (float)(nzv / l)};
        tm.v.insert(tm.v.end(), row, row + 9);
    }
    // cells are emitted tile by tile (16 x 16 cells) so that every 3000-index culling chunk is a compact square block of ground, not a 2.7 km long row
    const int TB = 16;
    for (int tj = 0; tj < nz; tj += TB) for (int ti = 0; ti < nx; ti += TB)
        for (int j = tj; j < std::min(tj + TB, nz); j++) for (int i = ti; i < std::min(ti + TB, nx); i++){
            const uint32_t a = j*W + i, b = a + 1, c = a + W, d = c + 1; const uint32_t t[6] = {a, c, b, b, c, d};
            tm.idx.insert(tm.idx.end(), t, t + 6);
        }
    // water: cells that touch at least one wet vertex. depth = metres of water above the bed (negative = dry)
    std::vector<int> map((size_t)W * (nz + 1), -1);
    auto vert = [&](int i, int j) -> uint32_t {
        int& m = map[(size_t)j*W + i];
        if (m < 0){ m = (int)(wm.v.size() / 4); const float row[4] = {(float)(GX0 + i*GCELL), (float)WATER_Y, (float)(GZ0 + j*GCELL), (float)(WATER_Y - H[(size_t)j*W + i])}; wm.v.insert(wm.v.end(), row, row + 4); }
        return (uint32_t)m;
    };
    for (int tj = 0; tj < nz; tj += TB) for (int ti = 0; ti < nx; ti += TB)
        for (int j = tj; j < std::min(tj + TB, nz); j++) for (int i = ti; i < std::min(ti + TB, nx); i++){
            const float *h0 = &H[(size_t)j*W + i], *h1 = &H[(size_t)(j+1)*W + i];
            if (!(h0[0] < WATER_Y + 0.05 || h0[1] < WATER_Y + 0.05 || h1[0] < WATER_Y + 0.05 || h1[1] < WATER_Y + 0.05)) continue;
            const uint32_t a = vert(i, j), b = vert(i+1, j), c = vert(i, j+1), d = vert(i+1, j+1); const uint32_t t[6] = {a, c, b, b, c, d};
            wm.idx.insert(wm.idx.end(), t, t + 6);
        }
}

} // namespace River
