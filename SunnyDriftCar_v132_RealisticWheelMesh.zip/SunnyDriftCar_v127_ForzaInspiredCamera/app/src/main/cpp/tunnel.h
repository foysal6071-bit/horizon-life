// Sunny Drift - tunnel portals at the two dead ends of the dirt track (pure C++, no OpenGL).
//  * a concrete arch + an earth mound with a dark tunnel mouth, so the track seems to disappear underground
//  * an invisible wall (oriented box in front of the arch and around the mound): the car cannot get in
//  * blocked() keeps the pine forest from growing through the mound
#pragma once
#include <algorithm>
#include <cmath>
#include <vector>
#include "terrain.h"
#include "fence.h"          // bounceOff

namespace Tunnel {

struct Portal { double x, z, bx, bz, y0; };         // (x, z) = centre of the arch front; (bx, bz) = unit vector pointing INTO the tunnel; y0 = ground height there
static std::vector<Portal> gP;

static const double ARCH_R = 4.2, SIDE_H = 2.6, WALL_T = 3.0, DEPTH = 16.0, MOUND_L = 26.0, MOUND_SPREAD = 1.7;
static const double HALF_U = 13.0, W_FRONT = -1.0, W_BACK = 27.0;      // the invisible wall: lateral half width, in front of the arch, behind the mound

static void toLocal(const Portal& P, double x, double z, double& u, double& w){
    const double dx = x - P.x, dz = z - P.z; u = dx * (-P.bz) + dz * P.bx; w = dx * P.bx + dz * P.bz;
}

// call after Terrain::init(): one portal at each end of the dirt track
static void plan(){
    gP.clear(); if (!Terrain::TRK.on || Terrain::TRK.n < 6 || Terrain::PEAK.on) return;   // no tunnel mouths on the hill road
    const std::vector<float>& p = Terrain::TRK.pts; const int n = Terrain::TRK.n;
    auto add = [&](int e, int nb){
        double x = p[e*2], z = p[e*2+1], dx = x - p[nb*2], dz = z - p[nb*2+1]; const double l = std::hypot(dx, dz); if (l < 1e-6) return;
        Portal P; P.x = x; P.z = z; P.bx = dx / l; P.bz = dz / l; P.y0 = Terrain::meshH(x, z); gP.push_back(P);     // away from the track = into the tunnel
    };
    add(0, 3); add(n - 1, n - 4);
}

static bool blocked(double x, double z, double margin){
    for (const Portal& P : gP){ double u, w; toLocal(P, x, z, u, w); if (std::fabs(u) < HALF_U + margin && w > W_FRONT - margin && w < W_BACK + margin) return true; }
    return false;
}

// the invisible wall: three circles along the car, each pushed out of the box (same scheme as the houses)
static void collide(CarState& S){
    if (gP.empty()) return;
    const double sH = std::sin(S.heading), cH = std::cos(S.heading), R = 1.05; static const double OFS[3] = {-1.5, 0.0, 1.5};
    for (const Portal& P : gP){
        const double dx = P.x - S.x, dz = P.z - S.z; if (dx*dx + dz*dz > 70.0 * 70.0) continue;
        for (double o : OFS){
            double u, w; toLocal(P, S.x + sH * o, S.z + cH * o, u, w);
            const double cu = std::max(-HALF_U, std::min(HALF_U, u)), cw = std::max(W_FRONT, std::min(W_BACK, w)), vu = u - cu, vw = w - cw, d = std::sqrt(vu*vu + vw*vw);
            double nu, nw, pen;
            if (d > 1e-6){ if (d >= R) continue; nu = vu / d; nw = vw / d; pen = R - d; }
            else {                                                                                  // centre inside the box: leave through the nearest side
                const double e[4] = {HALF_U - u, u + HALF_U, W_BACK - w, w - W_FRONT}; int k = 0; for (int j = 1; j < 4; j++) if (e[j] < e[k]) k = j;
                nu = (k == 0) ? 1.0 : (k == 1 ? -1.0 : 0.0); nw = (k == 2) ? 1.0 : (k == 3 ? -1.0 : 0.0); pen = e[k] + R;
            }
            const double wx = -P.bz * nu + P.bx * nw, wz = P.bx * nu + P.bz * nw;                   // local -> world direction
            S.x += wx * pen; S.z += wz * pen;
            Fence::bounceOff(S, wx, wz, 0.22, 0.30);
        }
    }
}

// ---------- geometry (world space; vertex = pos(3) + normal(3)) ----------
enum { PART_FRAME = 0, PART_MOUND = 1, PART_DARK = 2, PART_FLOOR = 3, PARTS = 4 };
static const float PART_COL[PARTS][3] = {{0.55f, 0.54f, 0.51f}, {0.28f, 0.40f, 0.22f}, {0.045f, 0.045f, 0.05f}, {0.34f, 0.33f, 0.31f}};

static void build(std::vector<float> out[PARTS]){
    for (int i = 0; i < PARTS; i++) out[i].clear();
    typedef std::pair<double, double> UV;
    for (const Portal& P : gP){
        auto W = [&](double u, double v, double w, double* o){ o[0] = P.x - P.bz * u + P.bx * w; o[1] = P.y0 + v; o[2] = P.z + P.bx * u + P.bz * w; };
        auto groundV = [&](double u, double w){ double q[3]; W(u, 0, w, q); return Terrain::meshH(q[0], q[2]) - P.y0; };
        // triangle with a flat normal turned away from (away = true) or towards (false) the reference point (ru, rv, rw)
        auto tri = [&](int part, const double* a, const double* b, const double* c, const double* ref, bool away){
            double e1[3] = {b[0]-a[0], b[1]-a[1], b[2]-a[2]}, e2[3] = {c[0]-a[0], c[1]-a[1], c[2]-a[2]};
            double nx = e1[1]*e2[2] - e1[2]*e2[1], ny = e1[2]*e2[0] - e1[0]*e2[2], nz = e1[0]*e2[1] - e1[1]*e2[0];
            const double l = std::sqrt(nx*nx + ny*ny + nz*nz); if (l < 1e-9) return; nx /= l; ny /= l; nz /= l;
            const double d = nx*(a[0]-ref[0]) + ny*(a[1]-ref[1]) + nz*(a[2]-ref[2]); if ((d < 0) == away){ nx = -nx; ny = -ny; nz = -nz; }
            for (const double* q : {a, b, c}){ out[part].push_back((float)q[0]); out[part].push_back((float)q[1]); out[part].push_back((float)q[2]); out[part].push_back((float)nx); out[part].push_back((float)ny); out[part].push_back((float)nz); }
        };
        auto quad = [&](int part, const double* a, const double* b, const double* c, const double* d, const double* ref, bool away){ tri(part, a, b, c, ref, away); tri(part, a, c, d, ref, away); };
        // arch outline: left wall up, half circle over the top, right wall down (same point count for every radius -> matching rings)
        auto outline = [&](double r, double vbL, double vbR){
            std::vector<UV> o; const int ns = 3, na = 14;
            for (int i = 0; i < ns; i++) o.push_back({-r, vbL + (SIDE_H - vbL) * i / ns});
            for (int k = 0; k <= na; k++){ const double th = M_PI * (1.0 - (double)k / na); o.push_back({r * std::cos(th), SIDE_H + r * std::sin(th)}); }
            for (int i = 1; i <= ns; i++) o.push_back({r, SIDE_H + (vbR - SIDE_H) * i / ns});
            return o;
        };
        const double RO = ARCH_R + WALL_T, FLOOR = 0.14;
        const std::vector<UV> in = outline(ARCH_R, FLOOR - 0.02, FLOOR - 0.02);
        const std::vector<UV> outr = outline(RO, groundV(-RO, 0) - 0.4, groundV(RO, 0) - 0.4);
        const size_t N = in.size();
        const double inside[3] = {0, 3, 14}, axisFront[3] = {0, SIDE_H, 0}, axisTube[3] = {0, SIDE_H, DEPTH * 0.5};
        double a[3], b[3], c[3], d[3];
        // 1) concrete frame: front ring (0.5 m proud of the mound), rim between ring and mound, reveal inside the opening
        for (size_t i = 0; i + 1 < N; i++){
            W(in[i].first, in[i].second, -0.5, a);   W(in[i+1].first, in[i+1].second, -0.5, b);
            W(outr[i+1].first, outr[i+1].second, -0.5, c); W(outr[i].first, outr[i].second, -0.5, d);
            quad(PART_FRAME, a, b, c, d, inside, true);
            W(outr[i].first, outr[i].second, 0, a); W(outr[i+1].first, outr[i+1].second, 0, b);
            quad(PART_FRAME, d, c, b, a, inside, true);
            double e[3], f[3]; W(in[i].first, in[i].second, 0, e); W(in[i+1].first, in[i+1].second, 0, f);
            double g[3], h[3]; W(in[i].first, in[i].second, -0.5, g); W(in[i+1].first, in[i+1].second, -0.5, h);
            quad(PART_FRAME, g, h, f, e, axisFront, false);
        }
        // 2) earth mound: from the outer ring back to the ground, spreading sideways like a hillside
        std::vector<std::vector<double>> back(N, std::vector<double>(3));
        for (size_t i = 0; i < N; i++){ const double ub = outr[i].first * MOUND_SPREAD; double q[3]; W(ub, groundV(ub, MOUND_L) - 0.5, MOUND_L, q); back[i] = {q[0], q[1], q[2]}; }
        for (size_t i = 0; i + 1 < N; i++){
            W(outr[i].first, outr[i].second, 0, a); W(outr[i+1].first, outr[i+1].second, 0, b);
            quad(PART_MOUND, a, b, back[i+1].data(), back[i].data(), inside, true);
        }
        // 3) dark tunnel: inner walls + black back wall
        for (size_t i = 0; i + 1 < N; i++){
            W(in[i].first, in[i].second, 0, a); W(in[i+1].first, in[i+1].second, 0, b); W(in[i+1].first, in[i+1].second, DEPTH, c); W(in[i].first, in[i].second, DEPTH, d);
            quad(PART_DARK, a, b, c, d, axisTube, false);
            double ctr[3]; W(0, SIDE_H, DEPTH, ctr); tri(PART_DARK, ctr, c, d, axisFront, false);
        }
        { double ctr[3], l0[3], l1[3]; W(0, SIDE_H, DEPTH, ctr); W(in[N-1].first, in[N-1].second, DEPTH, l0); W(in[0].first, in[0].second, DEPTH, l1); tri(PART_DARK, ctr, l0, l1, axisFront, false); }
        // 4) the track carries on into the tunnel: dirt floor
        W(-ARCH_R, FLOOR + 0.01, -3.0, a); W(ARCH_R, FLOOR + 0.01, -3.0, b); W(ARCH_R, FLOOR + 0.01, DEPTH, c); W(-ARCH_R, FLOOR + 0.01, DEPTH, d);
        { const double up[3] = {0, 50, 0}; quad(PART_FLOOR, a, b, c, d, up, false); }
    }
}

} // namespace Tunnel
