// Sunny Drift - rocks and boulders scattered over the alpine meadow on the slopes of the big mountain (cosmetic, no collision).
//  * placed once at start-up (CPU): every size from pebbles to house-sized boulders, in patches; big boulders have smaller rocks and pebbles tumbled round them
//    (mostly downhill, like scree), only on meadow ground (Terrain::alpineBand), never on the road / verge, the summit or beside the houses
//  * EIGHT different angular rock shapes (block, flat slab, tall pillar, wedge, rounded boulder, irregular chunk, long shard, stubby top) built as the
//    intersection of random planes; on top of that every single rock has its own stretch (x / y / z), spin, tone, moss amount and leans with the slope
//  * two levels of detail (320 / 80 triangles); small rocks are only drawn near the camera, boulders from far away
#pragma once
#include <GLES3/gl3.h>
#include <cmath>
#include <cstdint>
#include <random>
#include <vector>
#include <algorithm>
#include "sun_light.h"
#include "terrain.h"
#include "village.h"

namespace StonesGL {

static const int NVAR = 8, NLOD = 2;
static GLuint gProg = 0, gVao[NVAR * NLOD], gVbo[NVAR * NLOD], gInst[NVAR * NLOD]; static GLsizei gVerts[NVAR * NLOD]; static GLint uVP = -1, uCam = -1; static bool gOk = false;
// x, y, z, size | yaw, tone, moss, seed | sx, sy, sz, variant | tilt axis x, z, tilt angle, -
struct Stone { float x, y, z, s, rot, tone, moss, seed, sx, sy, sz, var, ax, az, tilt; };
static std::vector<Stone> gSt;

static const char* VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in vec3 n;
layout(location=2) in vec4 ia; layout(location=3) in vec4 ib; layout(location=4) in vec4 ic; layout(location=5) in vec4 id;   // ia = (x, y, z, size)  ib = (yaw, tone, moss, seed)  ic = (stretch x, y, z, -)  id = (tilt axis x, z, tilt angle, -)
uniform mat4 uVP;
out vec3 vn; out vec3 wp; out float vT; out float vM; out float vS; out float vH;
void main(){
  float cs = cos(ib.x), sn = sin(ib.x); mat3 Ry = mat3(cs, 0., -sn, 0., 1., 0., sn, 0., cs);
  vec3 v = Ry * (p * ic.xyz * ia.w); vec3 nn = Ry * (n / max(ic.xyz, vec3(0.05)));
  float ca = cos(id.z), sa = sin(id.z); vec3 ax = vec3(id.x, 0., id.y);                       // the rock leans with the slope (rotation about a horizontal axis)
  v  = v  * ca + cross(ax, v)  * sa + ax * dot(ax, v)  * (1. - ca);
  nn = nn * ca + cross(ax, nn) * sa + ax * dot(ax, nn) * (1. - ca);
  wp = v + ia.xyz; vn = normalize(nn); vT = ib.y; vM = ib.z; vS = ib.w; vH = p.y;
  gl_Position = uVP * vec4(wp, 1.0);
}
)GLSL";

static const char* FS = R"GLSL(#version 300 es
precision highp float;
in vec3 vn; in vec3 wp; in float vT; in float vM; in float vS; in float vH;
uniform vec3 uCam;
out vec4 o;
float h3(vec3 p){ p = fract(p * 0.1031); p += dot(p, p.yzx + 33.33); return fract((p.x + p.y) * p.z); }
void main(){
  vec3 V = uCam - wp; float dist = length(V); V /= dist;
  vec3 N = normalize(vn);
  float g1 = h3(floor(wp * 3.0)), g2 = h3(floor(wp * 9.0)), g3 = h3(floor(wp * 24.0));
  float grain = g1 * 0.35 + g2 * 0.40 + g3 * 0.25;
  vec3 cD = vec3(0.30, 0.30, 0.32), cC = vec3(0.47, 0.47, 0.48), cW = vec3(0.58, 0.55, 0.50), cP = vec3(0.60, 0.54, 0.54);       // dark basalt, cool granite, warm limestone, pinkish gneiss
  float t = vT; vec3 alb = t < 0.15 ? mix(cD, cC, t / 0.15) : (t < 0.55 ? mix(cC, cW, (t - 0.15) / 0.40) : mix(cW, cP, (t - 0.55) / 0.45));
  alb *= 0.70 + 0.55 * grain;
  float strata = smoothstep(0.55, 0.95, sin(dot(wp, vec3(0.9, 4.0 + 3.0 * vS, 0.7)) * 3.0 + vS * 40.0) * 0.5 + 0.5);               // faint layers / cracks, different for every rock
  alb *= 1.0 - 0.14 * strata;
  float lich = smoothstep(0.72, 0.92, h3(floor(wp * 6.0)) * 0.6 + g1 * 0.4) * step(0.45, fract(vS * 5.7));                              // pale grey-green lichen patches on some rocks
  alb = mix(alb, vec3(0.64, 0.66, 0.50), lich * 0.55);
  float mo = smoothstep(0.30, 0.70, N.y * 0.95 + (h3(floor(wp * 5.0)) - 0.5) * 0.55) * vM;                                                // moss and grass on the sunny top
  vec3 mossC = mix(vec3(0.22, 0.38, 0.10), vec3(0.38, 0.42, 0.17), fract(vS * 11.3)) * (0.70 + 0.60 * h3(floor(wp * 12.0)));
  alb = mix(alb, mossC, mo);
  alb *= mix(0.62, 1.0, smoothstep(-0.9, 0.3, vH));                                                                                      // darker where the rock meets the ground
  vec3 L = SUNL;
  float nd = dot(N, L); float d = max(nd, 0.0), wrap = max(nd * 0.6 + 0.4, 0.0);
  vec3 amb = mix(vec3(0.24, 0.28, 0.16), vec3(0.50, 0.66, 0.95), N.y * 0.5 + 0.5) * 0.85;
  vec3 col = alb * (amb + vec3(1.00, 0.93, 0.80) * (0.85 * d + 0.24 * wrap));
  float fog = 1.0 - exp(-pow(dist / 2850.0, 1.35));
  col = mix(col, vec3(0.72, 0.87, 0.98), clamp(fog, 0.0, 1.0));
  o = vec4(col, 1.0);
}
)GLSL";

static GLuint compile(GLenum t, const char* s){ GLuint x = glCreateShader(t); SunLight::shaderSource(x, s); glCompileShader(x); return x; }

struct V3 { float x, y, z; };
static V3 nrm(V3 a){ const float l = std::sqrt(a.x*a.x + a.y*a.y + a.z*a.z); return l > 1e-9f ? V3{a.x / l, a.y / l, a.z / l} : V3{0, 1, 0}; }
static float dot3(V3 a, V3 b){ return a.x*b.x + a.y*b.y + a.z*b.z; }

// unit sphere as triangles (icosahedron split `sub` times)
static std::vector<V3> sphereTris(int sub){
    const float t = (1.f + std::sqrt(5.f)) / 2.f; std::vector<V3> v = {{-1,t,0},{1,t,0},{-1,-t,0},{1,-t,0},{0,-1,t},{0,1,t},{0,-1,-t},{0,1,-t},{t,0,-1},{t,0,1},{-t,0,-1},{-t,0,1}};
    for (V3& a : v) a = nrm(a);
    const int F[20][3] = {{0,11,5},{0,5,1},{0,1,7},{0,7,10},{0,10,11},{1,5,9},{5,11,4},{11,10,2},{10,7,6},{7,1,8},{3,9,4},{3,4,2},{3,2,6},{3,6,8},{3,8,9},{4,9,5},{2,4,11},{6,2,10},{8,6,7},{9,8,1}};
    std::vector<V3> tr; for (auto& f : F){ tr.push_back(v[f[0]]); tr.push_back(v[f[1]]); tr.push_back(v[f[2]]); }
    for (int s = 0; s < sub; s++){ std::vector<V3> nt; nt.reserve(tr.size() * 4);
        auto mid = [&](V3 a, V3 b){ return nrm(V3{(a.x + b.x) / 2, (a.y + b.y) / 2, (a.z + b.z) / 2}); };
        for (size_t i = 0; i + 2 < tr.size(); i += 3){ const V3 a = tr[i], b = tr[i+1], c = tr[i+2], ab = mid(a, b), bc = mid(b, c), ca = mid(c, a);
            const V3 q[12] = {a, ab, ca, ab, b, bc, ca, bc, c, ab, bc, ca}; nt.insert(nt.end(), q, q + 12); }
        tr.swap(nt); }
    return tr;
}

// one rock shape = intersection of half-spaces (6 tilted "box" planes + a few cuts): angular, flat faces. Same seed -> same shape at both levels of detail.
static std::vector<float> buildVariant(int variant, int sub){
    std::mt19937 rng(9100u + (unsigned)variant * 131u); auto U = [&]{ return std::uniform_real_distribution<float>(0.f, 1.f)(rng); };
    struct Pl { V3 n; float d; }; std::vector<Pl> pl;
    //                      dx    dy    dz    cuts  dmin  dmax  jitter
    static const float T[NVAR][7] = {{1.00f, 0.85f, 0.95f, 5, 1.05f, 1.30f, 0.20f},      // 0 blocky boulder
                                     {1.15f, 0.38f, 0.95f, 4, 0.95f, 1.20f, 0.15f},      // 1 flat slab
                                     {0.62f, 1.15f, 0.60f, 5, 0.80f, 1.05f, 0.18f},      // 2 tall block
                                     {1.10f, 0.80f, 0.90f, 3, 0.85f, 1.10f, 0.15f},      // 3 wedge (one big slanted face)
                                     {1.00f, 0.85f, 1.00f, 14, 0.88f, 1.00f, 0.10f},     // 4 rounded boulder
                                     {0.95f, 0.80f, 0.90f, 8, 0.70f, 1.00f, 0.30f},      // 5 irregular chunk
                                     {1.45f, 0.50f, 0.55f, 5, 0.70f, 1.20f, 0.25f},      // 6 long shard
                                     {0.90f, 0.55f, 0.90f, 9, 0.85f, 1.10f, 0.20f}};     // 7 stubby, flat-topped
    const float* c = T[variant]; const float D[3] = {c[0], c[1], c[2]};
    for (int ax = 0; ax < 3; ax++) for (int sg = -1; sg <= 1; sg += 2){
        V3 n = {0, 0, 0}; (ax == 0 ? n.x : (ax == 1 ? n.y : n.z)) = (float)sg;
        n.x += (U() - 0.5f) * 2.f * c[6]; n.y += (U() - 0.5f) * 2.f * c[6]; n.z += (U() - 0.5f) * 2.f * c[6];
        pl.push_back({nrm(n), D[ax] * (0.92f + 0.16f * U())}); }
    if (variant == 3) pl.push_back({nrm(V3{0.55f, 0.85f, 0.1f}), 0.55f});                                // the wedge's long slanted face
    for (int k = 0; k < (int)c[3]; k++){ V3 n = nrm(V3{U() * 2.f - 1.f, U() * 1.4f - 0.55f, U() * 2.f - 1.f}); pl.push_back({n, c[4] + (c[5] - c[4]) * U()}); }
    const std::vector<V3> tr = sphereTris(sub); std::vector<float> out;
    auto shape = [&](V3 u){ float r = 3.f; for (const Pl& p : pl){ const float dn = dot3(u, p.n); if (dn > 1e-3f) r = std::min(r, p.d / dn); } return V3{u.x * r, u.y * r, u.z * r}; };
    for (size_t i = 0; i + 2 < tr.size(); i += 3){
        V3 a = shape(tr[i]), b = shape(tr[i+1]), cc = shape(tr[i+2]);
        const V3 e1 = {b.x - a.x, b.y - a.y, b.z - a.z}, e2 = {cc.x - a.x, cc.y - a.y, cc.z - a.z}; V3 n = nrm(V3{e1.y*e2.z - e1.z*e2.y, e1.z*e2.x - e1.x*e2.z, e1.x*e2.y - e1.y*e2.x});
        if (dot3(n, V3{a.x + b.x + cc.x, a.y + b.y + cc.y, a.z + b.z + cc.z}) < 0){ n = {-n.x, -n.y, -n.z}; std::swap(b, cc); }
        for (const V3& p : {a, b, cc}){ const float f[6] = {p.x, p.y, p.z, n.x, n.y, n.z}; out.insert(out.end(), f, f + 6); }
    }
    return out;
}

// plan once (needs Terrain::init + Village::plan / planSummit done)
static void plan(){
    gSt.clear(); if (!Terrain::PEAK.on) return;
    std::mt19937 rng(777123u); auto U = [&]{ return std::uniform_real_distribution<float>(0.f, 1.f)(rng); };
    const double R = Terrain::PEAK.R;
    auto ground = [&](double x, double z, double margin, double& gy, double& band){
        band = Terrain::alpineBand(x, z); if (band < 0.25) return false;
        if (Terrain::latSlope(x, z) > 0.95) return false;                                         // not on sheer cliffs
        if (Terrain::trackDist(x, z) < Terrain::TRK_W * 0.5 + 3.0 + margin || Terrain::summitCleared(x, z, margin) || Village::blocked((float)x, (float)z, 3.f + (float)margin)) return false;
        gy = Terrain::meshH(x, z); return true; };
    // one rock: size s (half extent, m); its own stretch, spin, tone, moss; leans downhill with the slope and sits a little sunk in
    auto put = [&](double x, double z, double gy, float s, bool fromCluster){
        const double e = 2.0; const double gx = (Terrain::meshH(x + e, z) - Terrain::meshH(x - e, z)) / (2 * e), gz = (Terrain::meshH(x, z + e) - Terrain::meshH(x, z - e)) / (2 * e);
        const double sl = std::sqrt(gx*gx + gz*gz); const double dx = sl > 1e-4 ? -gx / sl : 0, dz = sl > 1e-4 ? -gz / sl : 0;                   // downhill direction
        Stone st; st.s = s; st.sx = 0.75f + 0.70f * U(); st.sy = 0.55f + 0.70f * U(); st.sz = 0.75f + 0.70f * U();
        if (s > 0.9f){ st.sy *= 0.9f; }                                                                  // big ones a little more squat
        st.var = (float)(int)(U() * NVAR); if (st.var > NVAR - 1) st.var = NVAR - 1;
        st.rot = U() * 6.2831853f; st.tone = U(); st.seed = U();
        st.moss = (U() < (s > 0.5f ? 0.75f : 0.5f)) ? (0.35f + 0.65f * U()) : 0.f;
        st.ax = (float)dz; st.az = (float)(-dx); st.tilt = (float)(std::atan(sl) * (0.45 + 0.5 * U()) + (U() - 0.5f) * 0.30f);
        st.x = (float)x; st.z = (float)z; st.y = (float)gy + (0.30f + 0.30f * U()) * s * st.sy - 0.30f * s * (float)std::min(1.0, sl);   // shapes span -1..+1: about a quarter of the rock is sunk into the ground, a bit deeper on a slope
        gSt.push_back(st); (void)fromCluster; return st; };
    for (int t = 0; t < 160000 && gSt.size() < 6500; t++){
        const double a = U() * 6.2831853, r = std::sqrt((double)U()) * R * 1.15, x = Terrain::PEAK.x + r * std::cos(a), z = Terrain::PEAK.z + r * std::sin(a); double gy, band;
        if (!ground(x, z, 0.0, gy, band)) continue;
        const float cl = Terrain::fNoise(x / 13.0 + 5.1, z / 13.0 - 2.7) * 0.6f + Terrain::fNoise(x / 4.0 - 1.3, z / 4.0 + 8.8) * 0.4f;           // rocks come in patches
        if (U() > 0.08f + 0.92f * std::max(0.f, (cl - 0.45f) / 0.35f)) continue;
        // size class: pebbles, small, medium, large, huge (the big ones are rare)
        const float q = U(); float s = q < 0.40f ? 0.07f + 0.13f * U() : (q < 0.70f ? 0.20f + 0.30f * U() : (q < 0.87f ? 0.50f + 0.45f * U() : (q < 0.97f ? 0.95f + 0.75f * U() : 1.70f + 1.10f * U())));
        if (s > 0.5f && !ground(x, z, 1.2 * s, gy, band)) continue;                                      // big rocks keep further from the road / houses
        const Stone main = put(x, z, gy, s, false);
        if (s >= 0.5f){                                                                                  // smaller rocks and pebbles tumbled round it, mostly downhill (scree)
            const int n = 2 + (int)(U() * (4.0f + 3.0f * s));
            for (int k = 0; k < n; k++){
                const double pa = (U() < 0.6f ? std::atan2(-main.az, -main.ax) + (U() - 0.5f) * 1.8f : U() * 6.2831853), pr = (0.9 + 2.4 * U()) * s, px = x + pr * std::cos(pa), pz = z + pr * std::sin(pa); double g2, b2;
                const float cs = s * (0.05f + 0.40f * U() * U()); if (!ground(px, pz, 0.0, g2, b2)) continue;
                put(px, pz, g2, std::max(0.06f, cs), true); }
        }
    }
}

static void init(){
    plan(); if (gSt.empty()) return;
    gProg = glCreateProgram(); glAttachShader(gProg, compile(GL_VERTEX_SHADER, VS)); glAttachShader(gProg, compile(GL_FRAGMENT_SHADER, FS)); glLinkProgram(gProg); SunLight::attach(gProg);
    uVP = glGetUniformLocation(gProg, "uVP"); uCam = glGetUniformLocation(gProg, "uCam");
    for (int v = 0; v < NVAR; v++) for (int l = 0; l < NLOD; l++){
        const int k = v * NLOD + l; const std::vector<float> m = buildVariant(v, l == 0 ? 2 : 1); gVerts[k] = (GLsizei)(m.size() / 6);
        glGenVertexArrays(1, &gVao[k]); glBindVertexArray(gVao[k]);
        glGenBuffers(1, &gVbo[k]); glBindBuffer(GL_ARRAY_BUFFER, gVbo[k]); glBufferData(GL_ARRAY_BUFFER, m.size() * 4, m.data(), GL_STATIC_DRAW);
        glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 24, (void*)0);
        glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 24, (void*)12);
        glGenBuffers(1, &gInst[k]); glBindBuffer(GL_ARRAY_BUFFER, gInst[k]);
        for (int a = 0; a < 4; a++){ glEnableVertexAttribArray(2 + a); glVertexAttribPointer(2 + a, 4, GL_FLOAT, GL_FALSE, 64, (void*)(16 * a)); glVertexAttribDivisor(2 + a, 1); }
        glBindVertexArray(0);
    }
    gOk = true;
}

static void draw(const float* VP, const float* eye){
    if (!gOk) return;
    static std::vector<float> B[NVAR * NLOD]; for (auto& b : B) b.clear();
    float pl[6][4];
    for (int i = 0; i < 6; i++){ const int a = i >> 1; const float sg = (i & 1) ? 1.f : -1.f;
        for (int j = 0; j < 4; j++) pl[i][j] = VP[j*4 + 3] + sg * VP[j*4 + a];
        const float l = std::sqrt(pl[i][0]*pl[i][0] + pl[i][1]*pl[i][1] + pl[i][2]*pl[i][2]); if (l > 1e-6f) for (int j = 0; j < 4; j++) pl[i][j] /= l; }
    for (const Stone& s : gSt){
        const float dx = s.x - eye[0], dz = s.z - eye[2], d2 = dx*dx + dz*dz;
        const float lim = std::min(420.f, 90.f + 230.f * s.s); if (d2 > lim * lim) continue;              // pebbles only close up, boulders from far away
        const float rad = 1.6f * s.s * std::max(s.sx, std::max(s.sy, s.sz)) + 0.3f; bool out = false;
        for (int i = 0; i < 6 && !out; i++) if (pl[i][0]*s.x + pl[i][1]*s.y + pl[i][2]*s.z + pl[i][3] < -rad) out = true;
        if (out) continue;
        const int lod = d2 < 75.f * 75.f ? 0 : 1, k = (int)s.var * NLOD + lod;
        const float f[16] = {s.x, s.y, s.z, s.s, s.rot, s.tone, s.moss, s.seed, s.sx, s.sy, s.sz, 0.f, s.ax, s.az, s.tilt, 0.f}; B[k].insert(B[k].end(), f, f + 16);
    }
    glEnable(GL_DEPTH_TEST); glDepthMask(GL_TRUE); glDisable(GL_BLEND); glDisable(GL_CULL_FACE);
    glUseProgram(gProg); glUniformMatrix4fv(uVP, 1, GL_FALSE, VP); glUniform3fv(uCam, 1, eye);
    for (int k = 0; k < NVAR * NLOD; k++){ const int cnt = (int)(B[k].size() / 16); if (!cnt) continue;
        glBindVertexArray(gVao[k]); glBindBuffer(GL_ARRAY_BUFFER, gInst[k]); glBufferData(GL_ARRAY_BUFFER, B[k].size() * 4, B[k].data(), GL_STREAM_DRAW);
        glDrawArraysInstanced(GL_TRIANGLES, 0, gVerts[k], cnt); }
    glBindVertexArray(0);
}

} // namespace StonesGL
