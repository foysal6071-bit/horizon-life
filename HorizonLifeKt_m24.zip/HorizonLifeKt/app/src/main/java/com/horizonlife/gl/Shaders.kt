package com.horizonlife.gl

/** GLSL ES 3.00 shaders. Sky + ground are simplified ports of the JS procedural look (full versions come later). */
object Shaders {
    const val SKY_VS = """#version 300 es
out vec2 vUv;
void main(){ vec2 p = vec2((gl_VertexID==1)?3.0:-1.0, (gl_VertexID==2)?3.0:-1.0); vUv = p; gl_Position = vec4(p, 0.9999, 1.0); }"""

    const val SKY_FS = """#version 300 es
precision highp float;
in vec2 vUv; out vec4 o;
uniform vec3 uRight, uUp, uFwd; uniform vec2 uTan; uniform vec3 uSun, uMoon, uHor, uMid, uZen, uCl, uCs, uCubeTint;
uniform float uNight, uTw, uTime, uCubeAmt, uMtnAmt, uInset;
uniform sampler2D uCubeTex, uMtnTex, uMtnData;
float h31(vec3 p){ p=fract(p*0.1031); p+=dot(p,p.yzx+33.33); return fract((p.x+p.y)*p.z); }
float hash(vec2 p){ p=fract(p*vec2(123.34,456.21)); p+=dot(p,p+45.32); return fract(p.x*p.y); }
float noise(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.-2.*f);
  return mix(mix(hash(i),hash(i+vec2(1.,0.)),f.x), mix(hash(i+vec2(0.,1.)),hash(i+vec2(1.,1.)),f.x), f.y); }
float fbm(vec2 p){ float a=.5, s=0.; for(int i=0;i<4;i++){ s+=a*noise(p); p=p*2.03+vec2(17.1,9.7); a*=.5; } return s; }
// photo cubemap stored as a 3x2 atlas (faces 0..3 = sides turning right: -z,+x,+z,-x ; face 4 = zenith)
vec3 skyTex(vec3 d){
  vec3 a = abs(d); vec2 uv; float f;
  if (a.y > a.x && a.y > a.z){ uv = vec2(d.x, d.z)/a.y; f = 4.; }
  else if (a.z >= a.x){ if (d.z < 0.){ uv = vec2(d.x, d.y)/a.z; f = 0.; } else { uv = vec2(-d.x, d.y)/a.z; f = 2.; } }
  else { if (d.x > 0.){ uv = vec2(d.z, d.y)/a.x; f = 1.; } else { uv = vec2(-d.z, d.y)/a.x; f = 3.; } }
  uv = clamp(uv*.5+.5, vec2(uInset), vec2(1.-uInset));
  float c = mod(f,3.), r = floor(f/3.);
  return textureLod(uCubeTex, vec2((c+uv.x)/3., (1.-r+uv.y)/2.), 0.0).rgb;
}
vec3 star(vec3 d,float S,float dens,float r){
  vec3 g=d*S, id=floor(g), f=fract(g);
  float e=h31(id+3.3); if(e>dens) return vec3(0.);
  vec3 rp=.2+.6*vec3(h31(id),h31(id+19.19),h31(id+47.7));
  float dd=length(f-rp), b=exp(-dd*dd/(r*r));
  float tw=.78+.22*sin(uTime*(1.5+e*20./dens)+e*90.);
  return b*tw*(.3+.7*h31(id+8.1))*mix(vec3(.7,.82,1.),vec3(1.,.86,.68),h31(id+5.5));
}
void main(){
  vec3 d = normalize(uFwd + uRight*vUv.x*uTan.x + uUp*vUv.y*uTan.y); float h = d.y;
  vec3 S = normalize(uSun);
  vec3 col = mix(uHor, uMid, smoothstep(0.,.28,h));
  col = mix(col, uZen, smoothstep(.25,.95,h));
  if (h < 0.) col = mix(uHor, uHor*vec3(.55,.7,.5), clamp(-h*6.0,0.,1.));
  if (uCubeAmt > .001){
    float cr = uTime*.0025, cs = sin(cr), cc = cos(cr);                       // very slow drift of the whole cloud deck
    vec3 dr = normalize(vec3(cc*d.x - cs*d.z, max(d.y,0.), cs*d.x + cc*d.z));
    vec3 sc = skyTex(dr);
    sc = pow(max(sc,vec3(0.)), vec3(.72)) * uCubeTint;                         // time-of-day light
    sc = mix(sc, uHor, (1.-smoothstep(0.,.14,h))*.35);                         // melt into the distance haze
    col = mix(col, sc, uCubeAmt*smoothstep(-.03,.0,h));
  }
  float sd = max(dot(d,S),0.); float sv = smoothstep(-.12,.04,S.y);
  col += (vec3(1.,.80,.50)*pow(sd,5.)*.22 + vec3(1.,.90,.70)*pow(sd,40.)*.45)*sv;
  col += vec3(1.,.4,.12)*pow(sd,3.)*uTw*.55*(1.-smoothstep(0.,.5,h));
  col += mix(vec3(1.,.97,.88),vec3(1.,.55,.28),uTw)*smoothstep(.9993,.9997,sd)*2.*sv;
  if (uNight > .01 && h > -.02){
    float vis = uNight*smoothstep(-.02,.18,h);
    vec3 M = normalize(uMoon); float md = dot(d,M);
    vec3 mwN = normalize(vec3(.35,.75,-.55)), mA = normalize(cross(mwN,vec3(0.,1.,0.))), mB = cross(mwN,mA);
    float dn = dot(d,mwN), band = exp(-dn*dn/.03), mw = 0.;
    if (band > .02){ vec2 mp = vec2(dot(d,mA),dot(d,mB))*4.;
      mw = band*(.4+.9*fbm(mp))*(.6+.6*fbm(mp*3.1+7.))*(1.-.5*smoothstep(.5,.8,fbm(mp*2.+3.))); }
    vec3 st = star(d,26.,.09,.2)*1.7 + star(d,55.,.35,.16) + star(d,115.,.4+.35*band,.2)*.7;
    float wash = 1.-clamp(pow(max(md,0.),6.)*1.4,0.,1.);
    col += (st + vec3(.5,.58,.85)*mw*.2)*wash*vis;
    col += vec3(.5,.62,.95)*(pow(max(md,0.),70.)*.4 + pow(max(md,0.),7.)*.08)*uNight;
    float MR = .034;
    if (md > cos(MR) && M.y > -0.5){
      vec3 r = normalize(cross(vec3(0.,1.,0.),M)); vec3 u = cross(M,r);
      vec2 q = vec2(dot(d,r),dot(d,u))/sin(MR); float q2 = dot(q,q);
      if (q2 < 1.){
        vec3 n = vec3(q,sqrt(1.-q2)); vec3 L = normalize(vec3(.75,.25,.6));
        float lit = smoothstep(-.05,.12,dot(n,L));
        vec3 alb = vec3(.88,.86,.80)*(.62+.5*fbm(q*2.6+5.))*(.85+.3*fbm(q*9.+1.));
        alb *= mix(1.,.55,smoothstep(.55,.7,fbm(q*2.+11.)));
        col = mix(col, alb*(lit+.05)*1.5, smoothstep(1.,.95,sqrt(q2)));
      }
    }
  }
  if (h > 0.01){
    vec2 uv = d.xz/(h+.12)*1.4 + vec2(uTime*.012, uTime*.004);
    float n = fbm(uv*.9);
    float c = smoothstep(.52,.80,n) * smoothstep(.0,.16,h);
    if (c > .004){
      float lit = fbm(uv*.9 + S.xz*.35);
      vec3 cc = mix(uCs, uCl, clamp(1.-(lit-n)*2.4,0.,1.));
      cc += vec3(1.,.85,.6)*pow(sd,8.)*.25*(1.-uNight)*sv;
      cc += vec3(.25,.3,.45)*pow(max(dot(d,normalize(uMoon)),0.),12.)*uNight*.5;
      col = mix(col, cc, c*.92*(1.-.88*uCubeAmt));
    }
  }
  if (uMtnAmt > .001){   // distant mountains: baked 360 deg terrain render (colour + coverage/haze), tinted by the live sky haze
    float hz = max(length(d.xz),1e-3); float e = d.y/hz;
    float v = (e+.05)/.37;
    if (v > 0. && v < 1.){
      vec2 muv = vec2(atan(d.z,d.x)/6.2831853+.5, v);
      vec3 mc = textureLod(uMtnTex, muv, 0.0).rgb; vec2 md2 = textureLod(uMtnData, muv, 0.0).rg;
      float light = clamp(dot(uHor,vec3(.299,.587,.114))*1.35,.05,1.);
      mc *= light * mix(vec3(1.), vec3(1.25,.88,.66), uTw*.7);
      float haze = clamp(md2.g + (1.-smoothstep(-.02,.014,e))*.8, 0., .97);
      mc = mix(mc, uHor, haze);
      mc += vec3(1.,.55,.25)*pow(sd,4.)*uTw*.25*(1.-haze*.4);
      col = mix(col, mc, md2.r*uMtnAmt*smoothstep(-.05,-.03,e));
    }
  }
  o = vec4(col, 1.0);
}"""

    const val TERRAIN_VS = """#version 300 es
layout(location=0) in vec3 aP; layout(location=1) in vec3 aC; layout(location=2) in vec3 aN;
uniform mat4 uVP;
out vec3 vW; out vec3 vC; out vec3 vN;
void main(){ vW = aP; vC = aC; vN = aN; gl_Position = uVP * vec4(aP,1.0); }"""

    const val TERRAIN_FS = """#version 300 es
precision highp float;
in vec3 vW; in vec3 vC; in vec3 vN; out vec4 o;
uniform vec3 uCam; uniform vec3 uFog; uniform vec3 uSun; uniform vec3 uSunCol, uAmbCol;
float hash(vec2 p){ p=fract(p*vec2(123.34,456.21)); p+=dot(p,p+45.32); return fract(p.x*p.y); }
float noise(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.-2.*f);
  return mix(mix(hash(i),hash(i+vec2(1.,0.)),f.x), mix(hash(i+vec2(0.,1.)),hash(i+vec2(1.,1.)),f.x), f.y); }
void main(){
  float n = noise(vW.xz*0.9)*0.5 + noise(vW.xz*4.3)*0.5;
  vec3 c = vC * (0.85 + 0.3*n);
  vec3 nn = normalize(vN);
  float dif = max(dot(nn, normalize(uSun)), 0.0), hemi = 0.5 + 0.5*nn.y;
  c *= uAmbCol*hemi + uSunCol*dif;
  float d = length(vW - uCam);
  float f = 1.0 - exp(-pow(max(d-120.0,0.0)/330.0, 1.6));
  o = vec4(mix(c, uFog, clamp(f,0.0,1.0)), 1.0);
}"""

    const val WATER_VS = """#version 300 es
layout(location=0) in vec2 aXZ;
uniform mat4 uVP; uniform vec2 uCenter; uniform float uY;
out vec3 vW;
void main(){ vec3 w = vec3(aXZ.x*2200.0 + uCenter.x, uY, aXZ.y*2200.0 + uCenter.y); vW = w; gl_Position = uVP * vec4(w,1.0); }"""

    // JS Ocean (patchSea): 6 travelling peaked waves -> analytic normals, crest glow + foam, depth-map driven shallows / waterline fade /
    // lapping shore foam, and the see-through teal-green river (uDepth = metres of water, 512x512 over +-1150 m, R8)
    const val WATER_FS = """#version 300 es
precision highp float;
in vec3 vW; out vec4 o;
uniform vec3 uCam, uFog, uSun, uSunCol, uAmbCol, uHor, uMid, uZen; uniform float uTime, uDay, uDepthOk; uniform sampler2D uDepth;
const float SW_L[6] = float[6](15.0, 9.5, 6.0, 3.8, 2.4, 1.5);
const float SW_A[6] = float[6](-0.55, 0.30, -0.20, 0.65, 0.05, -0.85);
const float SW_S[6] = float[6](0.045, 0.055, 0.060, 0.060, 0.050, 0.040);
vec3 seaWave(vec2 p, float fadeFine){
  vec2 g = vec2(0.0); float h = 0.0;
  for (int i=0;i<6;i++){
    float k = 6.2832/SW_L[i]; vec2 dr = vec2(cos(SW_A[i]), sin(SW_A[i]));
    float ph = k*dot(dr,p) - sqrt(9.8*k)*uTime*0.9 + float(i)*1.7;
    float s = 0.5 + 0.5*sin(ph);
    float f = 2.0*pow(s,1.6) - 1.0, df = 1.6*pow(s,0.6)*cos(ph);
    float sl = SW_S[i]*(i>=3 ? fadeFine : 1.0);
    g += dr*(sl*df); h += sl/k*f*3.0;
  }
  return vec3(g,h);
}
vec3 skyEnv(vec3 R){            // analytic stand-in for the JS env-map (sky gradient the surface mirrors)
  float h = R.y; vec3 c = mix(uHor, uMid, smoothstep(0.,.28,h)); c = mix(c, uZen, smoothstep(.2,.9,h));
  if (h < 0.) c = mix(uHor, uHor*vec3(.55,.7,.5), clamp(-h*6.,0.,1.));
  return c;
}
void main(){
  vec2 p = vW.xz; vec3 Vv = uCam - vW; float dist = length(Vv); vec3 V = Vv/dist;
  float fadeAll = 1.0 - smoothstep(180.0, 700.0, dist), fadeFine = 1.0 - smoothstep(35.0, 150.0, dist);
  vec3 w = seaWave(p, fadeFine); float seaH = w.z;
  vec3 n = normalize(vec3(-w.x*2.2*fadeAll, 1.0, -w.y*2.2*fadeAll));
  float nz = 0.5 + 0.5*sin(p.x*4.6 + sin(p.y*3.8 + uTime*0.8))*sin(p.y*5.4 - uTime*0.6 + sin(p.x*2.6));
  float seaF = smoothstep(0.52, 0.85, seaH)*smoothstep(0.35, 0.8, nz)*fadeFine;
  float ndv = clamp(dot(n,V), 0.0, 1.0), fr = pow(1.0 - ndv, 3.0);
  float lit = 0.25 + 0.75*uDay;
  vec3 deep = vec3(0.10,0.46,0.54)*(uAmbCol*1.3+0.12);
  vec3 Rf = reflect(-V, n); Rf.y = abs(Rf.y);
  vec3 c = mix(deep, skyEnv(Rf)*(0.55+0.45*uDay), fr*0.85 + 0.1);
  vec3 H = normalize(normalize(uSun)+V);
  c += uSunCol * pow(max(dot(n,H),0.0), 260.0) * 2.2;
  float dep = uDepthOk > 0.5 ? texture(uDepth, (p + 1150.0)/2300.0).r*12.0 - 3.0 : 6.0;     // metres of water here
  float dw = dep + seaH*0.10 + 0.07*sin(uTime*0.9 + p.x*0.05 + p.y*0.04);                    // waves wash a little up and down the shore
  float shallow = 1.0 - smoothstep(0.0, 2.6, dw);
  c *= 0.86 + 0.26*clamp(seaH+0.4, 0.0, 1.0);
  c += vec3(0.04,0.26,0.27)*smoothstep(0.05,0.8,seaH)*uDay*0.7;
  c = mix(c, vec3(0.50,0.90,0.84)*lit, shallow*0.30);                                         // clear, sandy-green shallows
  c *= mix(1.0, 0.80, smoothstep(2.5, 8.0, dw));                                              // deeper = darker
  c = mix(c, vec3(0.92,0.98,1.0)*lit, seaF*0.45);
  float rvM = 1.0 - smoothstep(505.0, 575.0, length(p));                                      // 1 on the river (inland), 0 out at sea
  float rvD = smoothstep(0.0, 1.9, dw);
  vec3 rvCol = mix(vec3(0.30,0.46,0.38), vec3(0.09,0.26,0.27), rvD)*lit;
  c = mix(c, rvCol + c*0.22, rvM*0.80);
  float edge = smoothstep(0.0, 0.07, dw);
  float lap = smoothstep(0.35, 0.95, sin(dw*11.0 - uTime*1.7 + seaH*3.0)) * (1.0 - smoothstep(0.05, 1.3, dw));
  float rim = 1.0 - smoothstep(0.0, 0.22, dw);
  float shoreFoam = clamp(lap*0.55 + rim*0.9, 0.0, 1.0) * step(0.0, dw);
  c = mix(c, vec3(0.95,0.99,1.0)*lit, shoreFoam*0.85);
  float baseA = mix(0.72, 0.97, fr) * smoothstep(0.0, 0.75, dw);
  baseA = mix(baseA, (0.30 + 0.30*rvD + 0.30*fr) * smoothstep(0.0, 0.75, dw), rvM);          // river: you can see the bed
  float a = clamp(max(baseA, shoreFoam*0.8*edge), 0.0, 1.0);
  float f = clamp(1.0 - exp(-pow(max(dist-120.0,0.0)/330.0, 1.6)), 0.0, 1.0);
  o = vec4(mix(c, uFog, f), a);
}"""

    const val MESH_VS = """#version 300 es
layout(location=0) in vec3 aP; layout(location=1) in vec3 aN;
uniform mat4 uVP; uniform mat4 uM; uniform float uMudMode; uniform vec3 uMudC;
out vec3 vN; out vec3 vW; out vec3 vMudP;
void main(){
  vec4 w = uM*vec4(aP,1.0); vW = w.xyz; vN = mat3(uM)*aN; gl_Position = uVP*w;
  // mud space: wheel-local (disc = xy, axle = z) or car frame (x forward, y up, z lateral) = JS vMudP
  vec3 d = aP - uMudC;
  vMudP = uMudMode < 1.5 ? vec3(d.z, d.y, d.x) : vec3(aP.z, aP.y, aP.x);
}"""

    const val MESH_FS = """#version 300 es
precision highp float;
in vec3 vN; in vec3 vW; in vec3 vMudP; out vec4 o;
uniform vec3 uColor, uSun, uCam, uFog, uSunCol, uAmbCol; uniform float uGloss, uAlpha, uEmis;
uniform float uMudMode, uMud, uMudDry, uMudSeed, uMudSide, uMudPart, uEnvK; uniform vec3 uHor, uMid, uZen;
float gMudM = 0.0, gMudH = 0.0, gMudR = 0.9;
float mudH(vec3 p){ p = fract(p*.1031); p += dot(p, p.yzx+33.33); return fract((p.x+p.y)*p.z); }
float mudN(vec3 x){ vec3 i = floor(x), f = fract(x); f = f*f*(3.-2.*f);
  return mix(mix(mix(mudH(i),mudH(i+vec3(1.,0.,0.)),f.x), mix(mudH(i+vec3(0.,1.,0.)),mudH(i+vec3(1.,1.,0.)),f.x), f.y),
             mix(mix(mudH(i+vec3(0.,0.,1.)),mudH(i+vec3(1.,0.,1.)),f.x), mix(mudH(i+vec3(0.,1.,1.)),mudH(i+vec3(1.,1.,1.)),f.x), f.y), f.z); }
float mudF(vec3 p){ return .5*mudN(p) + .27*mudN(p*2.03+7.1) + .15*mudN(p*4.1+3.7) + .08*mudN(p*8.3+1.9); }
vec3 skyEnv(vec3 R){
  float h = R.y; vec3 c = mix(uHor, uMid, smoothstep(0.,.28,h)); c = mix(c, uZen, smoothstep(.2,.9,h));
  if (h < 0.) c = mix(uHor, uHor*vec3(.55,.7,.5), clamp(-h*6.,0.,1.));
  return c;
}
vec3 mudShade(vec3 base, vec3 mp, float fine, float film, float spkW){
  float spkM = smoothstep(.80,.86,mudN(mp*95.+uMudSeed))*spkW*smoothstep(.0,.45,uMud);
  gMudM = max(gMudM, spkM); gMudH = max(gMudH, spkM*.9);
  float crackL = 1. - abs(2.*mudN(mp*22.+4.)-1.);
  float crack = smoothstep(.90,.985,crackL)*uMudDry*gMudM;
  float edge = clamp(gMudM*(1.-gMudM)*4., 0., 1.);
  vec3 mc = mix(vec3(.040,.026,.016), vec3(.20,.135,.08), uMudDry*(.55+.45*fine));
  mc *= .72 + .55*mudF(mp*52.+9.);
  mc = mix(mc*.8, mc*1.18, clamp(gMudH,0.,1.));
  mc *= 1. - .55*crack;
  mc *= 1. - .35*edge*(1.-uMudDry);
  mc = mix(mc, mc*1.35+vec3(.02,.014,.008), .35*uMudDry*smoothstep(.55,.9,mudF(mp*14.+2.)));
  gMudR = clamp(mix(.34,.97,uMudDry)*(.88+.24*fine) - .12*edge*(1.-uMudDry) + .10*crack, .2, 1.);
  return mix(base, mc*1.1, max(gMudM*.97, film));
}
void main(){
  vec3 n = normalize(vN), L = normalize(uSun); if (!gl_FrontFacing) n = -n;
  vec3 col = uColor;
  if (uMudMode > 0.5 && uMud > 0.001) {
    vec3 mp = vMudP;
    if (uMudMode < 1.5) {          // wheel: tyre (part 0) / rim (part 1)
      float rr = length(mp.xy), ao = mp.z*uMudSide; vec2 dir = mp.xy/max(rr,.001);
      float fine = mudF(mp*34.+uMudSeed), coarse = mudF(mp*9.+uMudSeed*1.7+3.1), clump = smoothstep(.55,.8,mudF(mp*15.+uMudSeed*.6+11.));
      float streak = mudN(vec3(dir*7., rr*2.5+ao*3.)+uMudSeed);
      float w = uMudPart < .5 ? .30 + .55*smoothstep(.285,.325,rr) + .12*smoothstep(-.03,.11,ao)
                              : -.12 + .40*smoothstep(.20,.27,rr) + .12*smoothstep(-.05,.12,ao);
      float f = w + .75*(coarse-.5) + .45*(fine-.5) + .40*(streak-.5)*smoothstep(.22,.30,rr)*(1.-smoothstep(.30,.33,rr));
      gMudM = smoothstep(1.05-1.2*uMud, 1.17-1.2*uMud, f);
      gMudH = gMudM*(.35 + .35*fine + .8*clump);
      float film = .20*uMud*max(w,0.)*(1.-gMudM);
      col = mudShade(col, mp, fine, film, uMudPart < .5 ? .55 : .35);
    } else {                       // body: lower skirt, wheel arches, rear panel
      float hy = mp.y;
      float fine = mudF(mp*38.+7.3), coarse = mudF(mp*8.+2.1), clump = smoothstep(.55,.8,mudF(mp*16.+5.));
      float low = 1. - smoothstep(.04,.30,hy);
      float ax1 = mp.x-1.4, ax2 = mp.x+1.4;
      float d1 = length(vec2(ax1*(ax1 < 0. ? .55 : 1.5), hy-.32)), d2 = length(vec2(ax2*(ax2 < 0. ? .55 : 1.5), hy-.32));
      float arch = exp(-pow(min(d1,d2)/.30, 2.));
      float rear = (1. - smoothstep(-1.9,.4,mp.x))*(1. - smoothstep(.04,.30,hy));
      float drip = mudN(vec3(mp.x*9., hy*1.6, mp.z*9.)+2.7);
      float w = .50*low + .20*arch + .08*rear;
      float f = w + .70*(coarse-.5) + .50*(fine-.5) + .22*(drip-.5)*(1.-smoothstep(.15,.45,hy));
      gMudM = smoothstep(1.02-1.15*uMud, 1.16-1.15*uMud, f);
      gMudH = gMudM*(.35 + .35*fine + .8*clump);
      float film = .03*uMud*w*(1.-gMudM);
      float spkW = (1. - smoothstep(.10,.50,hy))*(.35 + .65*max(arch, low));
      col = mudShade(col, mp, fine, film, spkW);
    }
    // bump shading from the mud height (screen-space derivatives)
    vec3 sx = dFdx(vW), sy = dFdy(vW);
    if (length(sx) > 1e-6 && length(sy) > 1e-6) {
      sx = normalize(sx); sy = normalize(sy);
      vec2 dH = vec2(dFdx(gMudH), dFdy(gMudH))*3.0;
      vec3 R1 = cross(sy, n), R2 = cross(n, sx);
      float det = dot(sx, R1);
      vec3 grad = sign(det)*(dH.x*R1 + dH.y*R2);
      n = normalize(abs(det)*n - grad);
    }
  }
  float gloss = uMudMode > 0.5 ? mix(uGloss, (1.0-gMudR)*0.9, gMudM) : uGloss;
  float dif = max(dot(n,L),0.0), hemi = 0.5+0.5*n.y;
  vec3 V = normalize(uCam - vW), H = normalize(L+V);
  float spec = pow(max(dot(n,H),0.0), 64.0) * gloss;
  vec3 c = col*(uAmbCol*0.8*hemi + uSunCol*1.05*dif) + spec*uSunCol;
  if (uEnvK > 0.5) {                // env-map reflection (clear-coat paint / glass / chrome): Fresnel-weighted sky + sun glint
    vec3 Rv = reflect(-V, n); float frn = 0.04 + 0.96*pow(1.0 - max(dot(n,V),0.0), 5.0);
    vec3 e = skyEnv(Rv) + uSunCol*pow(max(dot(Rv,L),0.0), 220.0)*3.0;
    c += e * (frn*0.9 + 0.10*gloss) * gloss * (1.0 - gMudM) * 0.6;
  }
  c = mix(c, col*1.6, uEmis);
  float f = 1.0 - exp(-pow(max(length(uCam-vW)-120.0,0.0)/330.0, 1.6));
  o = vec4(mix(c, uFog, clamp(f,0.0,1.0)), uAlpha);
}"""

    const val MAPLE_VS = """#version 300 es
layout(location=0) in vec3 aP; layout(location=1) in vec3 aN; layout(location=2) in vec3 aC;
layout(location=3) in vec4 aI; layout(location=4) in float aRot;
uniform mat4 uVP; uniform float uTime, uLeaf;
out vec3 vN; out vec3 vW; out vec3 vC;
void main(){
  float s = aI.w, c = cos(aRot), sn = sin(aRot);
  vec3 p = aP * s;
  if (uLeaf > 0.5) {
    float hh = max(aP.y - 2.0, 0.0) / 5.0;
    float wv = sin(uTime*1.5 + aI.x*.11 + aI.z*.09)*.6 + sin(uTime*2.9 + aP.x*1.3 + aP.z*1.1 + aI.x*.2)*.4;
    p.x += wv * 0.09 * hh * s; p.z += wv * 0.05 * hh * s;
  }
  vec3 r = vec3(c*p.x + sn*p.z, p.y, -sn*p.x + c*p.z);
  vec3 n = vec3(c*aN.x + sn*aN.z, aN.y, -sn*aN.x + c*aN.z);
  vW = r + aI.xyz; vN = n; vC = aC; gl_Position = uVP * vec4(vW, 1.0);
}"""

    const val MAPLE_FS = """#version 300 es
precision highp float;
in vec3 vN; in vec3 vW; in vec3 vC; out vec4 o;
uniform vec3 uSun, uCam, uFog, uSunCol, uAmbCol; uniform float uLeaf;
void main(){
  vec3 n = normalize(vN); if (!gl_FrontFacing) n = -n;
  float dif = max(dot(n, normalize(uSun)), 0.0), hemi = 0.5 + 0.5*n.y;
  vec3 emi = uLeaf > 0.5 ? vec3(.23,.063,.024)*.35 : vec3(.11,.10,.086)*.3;   // JS emissive 0x3a1006 / 0x1c1a16
  vec3 c = vC * (uAmbCol*0.9*hemi + uSunCol*0.95*dif + uAmbCol*0.1) + emi;
  float f = 1.0 - exp(-pow(max(length(uCam-vW)-120.0,0.0)/330.0, 1.6));
  o = vec4(mix(c, uFog, clamp(f,0.0,1.0)), 1.0);
}"""

    const val TREE_VS = """#version 300 es
layout(location=0) in vec3 aP; layout(location=1) in vec3 aN; layout(location=2) in vec2 aUV;
layout(location=3) in vec4 aI; layout(location=4) in float aRot;
uniform mat4 uVP; uniform float uTime, uLeaf;
out vec2 vUV; out vec3 vN; out vec3 vW;
void main(){
  float s = aI.w * 1.25, c = cos(aRot), sn = sin(aRot);
  vec3 p = aP * s;
  if (uLeaf > 0.5) {   // gentle wind sway, grows with height
    float hh = max(aP.y - 2.0, 0.0) / 5.0;
    float wv = sin(uTime*1.5 + aI.x*.11 + aI.z*.09)*.6 + sin(uTime*2.9 + aP.x*1.3 + aP.z*1.1 + aI.x*.2)*.4;
    p.x += wv * 0.09 * hh * s; p.z += wv * 0.05 * hh * s;
  }
  vec3 r = vec3(c*p.x + sn*p.z, p.y, -sn*p.x + c*p.z);
  vec3 n = vec3(c*aN.x + sn*aN.z, aN.y, -sn*aN.x + c*aN.z);
  vW = r + aI.xyz; vN = n; vUV = aUV; gl_Position = uVP * vec4(vW, 1.0);
}"""

    const val TREE_FS = """#version 300 es
precision highp float;
in vec2 vUV; in vec3 vN; in vec3 vW; out vec4 o;
uniform sampler2D uTex; uniform vec3 uSun, uCam, uFog, uSunCol, uAmbCol; uniform float uLeaf;
void main(){
  vec4 t = texture(uTex, vUV);
  if (uLeaf > 0.5 && t.a < 0.5) discard;
  vec3 n = normalize(vN); if (!gl_FrontFacing) n = -n;
  float dif = max(dot(n, normalize(uSun)), 0.0), hemi = 0.5 + 0.5*n.y;
  vec3 base = t.rgb * (uLeaf > 0.5 ? vec3(1.1,1.15,.95) : vec3(1.0));
  vec3 c = base * (uAmbCol*0.9*hemi + uSunCol*0.95*dif + uAmbCol*0.1);
  float f = 1.0 - exp(-pow(max(length(uCam-vW)-120.0,0.0)/330.0, 1.6));
  o = vec4(mix(c, uFog, clamp(f,0.0,1.0)), 1.0);
}"""

    const val ROAD_VS = """#version 300 es
layout(location=0) in vec3 aP; layout(location=1) in vec3 aL;   // lat, v, hw
uniform mat4 uVP;
out vec3 vW; out vec3 vL;
void main(){ vW = aP; vL = aL; gl_Position = uVP * vec4(aP,1.0); }"""

    // simplified procedural port of makeDirtRoadMaps(): wet clay, two wheel ruts, pebbles, verge fading into the grass
    const val ROAD_FS = """#version 300 es
precision highp float;
in vec3 vW; in vec3 vL; out vec4 o;
uniform vec3 uCam, uFog, uSun, uSunCol, uAmbCol;
float hash(vec2 p){ p=fract(p*vec2(123.34,456.21)); p+=dot(p,p+45.32); return fract(p.x*p.y); }
float noise(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.-2.*f);
  return mix(mix(hash(i),hash(i+vec2(1.,0.)),f.x), mix(hash(i+vec2(0.,1.)),hash(i+vec2(1.,1.)),f.x), f.y); }
void main(){
  float hw = vL.z, lat = vL.x, v = vL.y, al = abs(lat);
  float u = (lat/hw)*0.5 + 0.5;                                    // 0..1 across the roadway
  vec2 q = vec2(lat, v);
  float lo = noise(q*0.18)*0.5 + noise(q*0.55)*0.3 + noise(q*1.7)*0.2;
  float fine = noise(q*5.0), grit = noise(q*24.0);
  float wob = (noise(vec2(v*0.05, 1.0)) - 0.5)*0.05;
  float dl = (u-wob-0.27)/0.07, dr = (u-wob-0.73)/0.07;
  float rut = clamp(max(exp(-dl*dl), exp(-dr*dr)) * (0.55 + 0.9*noise(vec2(v*0.2,3.0))), 0.0, 1.0);
  float crown = exp(-pow((u-0.5)/0.13, 2.0));
  float wet = clamp(0.58 + 0.30*rut + 0.18*(0.5-lo), 0.0, 1.0);
  vec3 dry = vec3(0.478,0.373,0.259), mud = vec3(0.275,0.204,0.141), rutC = vec3(0.18,0.133,0.094);
  vec3 c = mix(dry, mud, wet);
  c = mix(c, dry, crown*0.35*(1.0-wet*0.5));
  c = mix(c, rutC, clamp(rut*0.75, 0.0, 1.0));
  c *= 0.80 + 0.30*fine + 0.12*(grit-0.5) + 0.16*(lo-0.5);
  vec3 edgeC = vec3(0.384,0.314,0.247);                            // colour of the road at its very edge
  c = mix(c, edgeC, smoothstep(0.9, 1.0, al/hw)*0.85);
  float out_ = max(al - hw, 0.0);                                  // metres beyond the road edge
  vec3 grass = vec3(0.30,0.40,0.20);
  c = mix(c, mix(vec3(0.40,0.34,0.27), grass, smoothstep(0.5,8.0,out_)*(0.35+0.65*lo)), smoothstep(0.0,2.0,out_)*0.9);
  c *= 0.9 + 0.2*noise(q*0.9);
  float alpha = 1.0 - smoothstep(1.0, 8.0, out_);                  // verge melts into the ground
  float dif = max(normalize(uSun).y, 0.0);                         // roads are flat
  c *= uAmbCol + uSunCol*dif*0.9;
  float d = length(vW - uCam);
  float f = 1.0 - exp(-pow(max(d-120.0,0.0)/330.0, 1.6));
  o = vec4(mix(c, uFog, clamp(f,0.0,1.0)), alpha);
}"""

    // timber bridge: procedural planks (kind 0) / weathered beams (kind 1), double-sided lighting
    const val BRIDGE_VS = """#version 300 es
layout(location=0) in vec3 aP; layout(location=1) in vec3 aN; layout(location=2) in vec3 aT;
uniform mat4 uVP;
out vec3 vW; out vec3 vN; out vec3 vT;
void main(){ vW = aP; vN = aN; vT = aT; gl_Position = uVP * vec4(aP,1.0); }"""

    const val BRIDGE_FS = """#version 300 es
precision highp float;
in vec3 vW; in vec3 vN; in vec3 vT; out vec4 o;
uniform vec3 uCam, uFog, uSun, uSunCol, uAmbCol;
float hash(vec2 p){ p=fract(p*vec2(123.34,456.21)); p+=dot(p,p+45.32); return fract(p.x*p.y); }
float noise(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.-2.*f);
  return mix(mix(hash(i),hash(i+vec2(1.,0.)),f.x), mix(hash(i+vec2(0.,1.)),hash(i+vec2(1.,1.)),f.x), f.y); }
void main(){
  vec3 n = normalize(vN); if (dot(n, uCam - vW) < 0.0) n = -n;
  vec2 q = vT.xy; vec3 c;
  if (vT.z < 0.5){
    float pi_ = floor(q.y/0.22), g = fract(q.y/0.22), h = hash(vec2(pi_, 3.7));
    float grain = noise(vec2(q.x*9.0, q.y*1.2 + pi_*7.0));
    c = vec3(0.50,0.38,0.26) * (0.72 + 0.4*h) * (0.85 + 0.3*grain);
    c *= 0.45 + 0.55*smoothstep(0.0,0.06,g)*smoothstep(0.0,0.06,1.0-g);
  } else {
    float grain = noise(vec2(q.x*14.0, q.y*0.9)), g2 = noise(vec2(q.x*40.0, q.y*3.0));
    c = vec3(0.34,0.24,0.15) * (0.7 + 0.5*grain) * (0.85 + 0.3*g2);
  }
  float dif = max(dot(n, normalize(uSun)), 0.0);
  c *= uAmbCol + uSunCol*dif*0.9;
  float d = length(vW - uCam);
  float f = 1.0 - exp(-pow(max(d-120.0,0.0)/330.0, 1.6));
  o = vec4(mix(c, uFog, clamp(f,0.0,1.0)), 1.0);
}"""

    // additive soft light sprites: ground light pools (flat) and halos (camera-facing), no vertex buffers (gl_VertexID quad)
    const val GLOW_VS = """#version 300 es
uniform mat4 uVP; uniform vec3 uC, uA, uB; uniform vec2 uS;
out vec2 vP;
void main(){ vec2 p = vec2(float(gl_VertexID & 1), float((gl_VertexID >> 1) & 1))*2.0 - 1.0; vP = p;
  gl_Position = uVP * vec4(uC + uA*p.x*uS.x + uB*p.y*uS.y, 1.0); }"""

    const val GLOW_FS = """#version 300 es
precision mediump float;
in vec2 vP; out vec4 o; uniform vec3 uCol; uniform float uAlpha;
void main(){ float r = length(vP); float a = pow(max(1.0 - r, 0.0), 2.0); o = vec4(uCol*a*uAlpha, 1.0); }"""

    // pothole decal: one gl_VertexID quad per hole (JS plane 2x2 with a radial dark-wet-mud canvas gradient), alpha-blended, lit, fogged
    const val POTH_VS = """#version 300 es
uniform mat4 uVP; uniform vec3 uC, uA, uB;
out vec2 vP; out vec3 vW;
void main(){ vec2 p = vec2(float(gl_VertexID & 1), float((gl_VertexID >> 1) & 1))*2.0 - 1.0; vP = p;
  vec3 w = uC + uA*p.x + uB*p.y; vW = w; gl_Position = uVP * vec4(w, 1.0); }"""

    const val POTH_FS = """#version 300 es
precision highp float;
in vec2 vP; in vec3 vW; out vec4 o;
uniform vec3 uCam, uFog, uSun, uSunCol, uAmbCol;
void main(){
  float t = clamp((length(vP)*64.0 - 4.0)/58.0, 0.0, 1.0);
  vec3 c0 = vec3(14.,10.,7.)/255., c1 = vec3(26.,19.,13.)/255., c2 = vec3(44.,33.,23.)/255.;
  vec3 c = t < 0.55 ? mix(c0, c1, t/0.55) : c2;
  float a = t < 0.55 ? mix(0.92, 0.80, t/0.55) : (t < 0.80 ? mix(0.80, 0.42, (t-0.55)/0.25) : mix(0.42, 0.0, (t-0.80)/0.20));
  if (length(vP) > 0.97) a = 0.0;
  if (a < 0.01) discard;
  vec3 V = normalize(uCam - vW), H = normalize(normalize(uSun) + V);
  c = c*(uAmbCol + uSunCol*0.5*max(normalize(uSun).y,0.0)) + uSunCol*pow(max(H.y,0.0), 120.0)*0.12*(1.0-t);   // wet sheen
  float f = 1.0 - exp(-pow(max(length(uCam-vW)-120.0,0.0)/330.0, 1.6));
  o = vec4(mix(c, uFog, clamp(f,0.0,1.0)), a);
}"""

    // ---- tyre marks: procedural tread / smear / rubber (JS used a height-map atlas + normal map; this keeps the section layout: uv.x = mode/3 + lateral/3) ----
    const val MARK_VS = """#version 300 es
layout(location=0) in vec3 aP; layout(location=1) in vec4 aC; layout(location=2) in vec2 aUV;
uniform mat4 uVP;
out vec3 vW; out vec4 vC; out vec2 vUV;
void main(){ vW = aP; vC = aC; vUV = aUV; gl_Position = uVP * vec4(aP,1.0); }"""

    const val MARK_FS = """#version 300 es
precision highp float;
in vec3 vW; in vec4 vC; in vec2 vUV; out vec4 o;
uniform vec3 uCam, uFog, uSun, uSunCol, uAmbCol;
float hash(vec2 p){ p=fract(p*vec2(123.34,456.21)); p+=dot(p,p+45.32); return fract(p.x*p.y); }
float noise(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.-2.*f);
  return mix(mix(hash(i),hash(i+vec2(1.,0.)),f.x), mix(hash(i+vec2(0.,1.)),hash(i+vec2(1.,1.)),f.x), f.y); }
void main(){
  float m = floor(vUV.x*3.0 - 0.0005); float s = abs((vUV.x*3.0 - m)*2.0 - 1.0); float v = vUV.y;
  vec3 c = vC.rgb; float mask;
  if (m < 0.5) {                                                    // rolling tread: chevron lugs, squeezed-up berm on both sides
    float tyre = 1.0 - smoothstep(0.52, 0.62, s);
    float lug = smoothstep(0.30, 0.50, abs(fract(v*2.2 + s*0.7) - 0.5));
    float berm = smoothstep(0.58, 0.72, s) * (1.0 - smoothstep(0.80, 1.0, s)) * (0.6 + 0.4*noise(vec2(v*6.0, s*4.0)));
    mask = clamp(tyre*(0.78 + 0.22*lug) + berm*0.5, 0.0, 1.0);
    c = mix(c*1.35, c*(0.55 + 0.5*lug), tyre);
  } else if (m < 1.5) {                                             // locked / spinning wheel: smooth ploughed channel, lengthwise streaks
    float chan = 1.0 - smoothstep(0.55, 0.70, s);
    float streak = noise(vec2(vUV.x*90.0, v*1.5));
    float berm = smoothstep(0.62, 0.78, s) * (1.0 - smoothstep(0.84, 1.0, s)) * (0.5 + 0.5*noise(vec2(v*5.0, s*3.0)));
    mask = clamp(chan*(0.85 + 0.15*streak) + berm*0.55, 0.0, 1.0);
    c = mix(c*1.3, c*0.8, chan);
  } else {                                                          // rubber on hard ground: flat black smear
    mask = (1.0 - smoothstep(0.72, 1.0, s)) * (0.8 + 0.2*noise(vec2(vUV.x*70.0, v*9.0)));
  }
  float a = vC.a * mask; if (a < 0.01) discard;
  vec3 n = vec3(0.0,1.0,0.0);
  c *= uAmbCol + uSunCol*0.55*max(normalize(uSun).y, 0.0);
  float f = 1.0 - exp(-pow(max(length(uCam-vW)-120.0,0.0)/330.0, 1.6));
  o = vec4(mix(c, uFog, clamp(f,0.0,1.0)), a);
}"""

    // ---- mud spray: lumpy clumps stretched along their screen-space motion (JS mudPts), soft mist puffs, splats on the road ----
    const val CLUMP_VS = """#version 300 es
layout(location=0) in vec3 aP; layout(location=1) in vec3 aVel; layout(location=2) in vec3 aColor; layout(location=3) in float aSize; layout(location=4) in float aAlpha; layout(location=5) in vec2 aMisc;
uniform mat4 uView, uProj; uniform float uScale; uniform vec2 uRes;
out vec3 vCol; out float vA; out float vK; out vec2 vDir; out vec2 vMisc;
void main(){
  vCol = aColor; vMisc = aMisc; vK = 1.0; vDir = vec2(1.0,0.0);
  vec4 mv = uView*vec4(aP,1.0);
  vA = aAlpha*smoothstep(1.2,3.5,-mv.z);
  if (aSize <= 0.0 || mv.z > -0.15){ gl_Position = vec4(2.0,2.0,2.0,1.0); gl_PointSize = 0.0; return; }
  vec4 c0 = uProj*mv;
  vec4 mv1 = mv + vec4(mat3(uView)*aVel*0.02, 0.0);
  float len = 0.0;
  if (mv1.z < -0.1){
    vec4 c1 = uProj*mv1; vec2 d = (c1.xy/c1.w - c0.xy/c0.w)*0.5*uRes; float dl = length(d);
    if (dl > 0.01){ vDir = d/dl; len = dl; }
  }
  float px = max(aSize*uScale/(-mv.z), 1.6);
  vK = clamp((px+len)/px, 1.0, 2.8);
  gl_Position = c0; gl_PointSize = min(px*vK, 140.0);
}"""

    const val CLUMP_FS = """#version 300 es
precision highp float;
uniform float uLight; in vec3 vCol; in float vA; in float vK; in vec2 vDir; in vec2 vMisc; out vec4 o;
void main(){
  vec2 p = (vec2(gl_PointCoord.x, 1.0-gl_PointCoord.y)-0.5)*2.0;
  vec2 q = vec2(dot(p,vDir), dot(p,vec2(-vDir.y,vDir.x)));
  q.y *= vK;
  float ang = atan(q.y,q.x+1e-5), rr = length(q);
  float edge = 0.80 + 0.09*sin(ang*3.0+vMisc.x*6.28) + 0.06*sin(ang*5.0+vMisc.x*17.0) + 0.04*sin(ang*9.0+vMisc.x*31.0);
  float d = rr/edge;
  float a = 1.0-smoothstep(0.72,1.0,d);
  if (a < 0.01) discard;
  vec3 c = vCol*(1.08-0.32*smoothstep(0.35,1.0,d));
  float hl = smoothstep(0.42,0.0,length(p-vec2(-0.26,0.30)));
  c += vec3(0.34,0.29,0.22)*hl*hl*vMisc.y;
  o = vec4(c*uLight, vA*a);
}"""

    const val MIST_VS = """#version 300 es
layout(location=0) in vec3 aP; layout(location=1) in vec3 aColor; layout(location=2) in float aSize; layout(location=3) in float aAlpha; layout(location=4) in float aSeed;
uniform mat4 uView, uProj; uniform float uScale;
out vec3 vCol; out float vA; out float vS;
void main(){ vCol = aColor; vS = aSeed; vec4 mv = uView*vec4(aP,1.0); vA = aAlpha*smoothstep(0.8,3.0,-mv.z);
  if (aSize <= 0.0 || mv.z > -0.3){ gl_Position = vec4(2.0,2.0,2.0,1.0); gl_PointSize = 0.0; return; }
  gl_Position = uProj*mv; gl_PointSize = min(aSize*uScale/(-mv.z), 150.0); }"""

    const val MIST_FS = """#version 300 es
precision highp float;
uniform float uLight; in vec3 vCol; in float vA; in float vS; out vec4 o;
void main(){
  vec2 p = (gl_PointCoord-0.5)*2.0; float r = length(p), ang = atan(p.y,p.x+1e-5);
  r *= 1.0 + 0.22*sin(ang*3.0+vS*6.28) + 0.12*sin(ang*5.0-vS*11.0);
  float a = smoothstep(1.0,0.0,r); a *= a;
  o = vec4(vCol*uLight, a*vA);
}"""

    const val SPLAT_VS = """#version 300 es
layout(location=0) in vec3 aP; layout(location=1) in vec2 aUV; layout(location=2) in vec4 aCol; layout(location=3) in vec2 aMisc;
uniform mat4 uVP;
out vec2 vUV; out vec4 vCol; out vec2 vMisc;
void main(){ vUV = aUV; vCol = aCol; vMisc = aMisc; gl_Position = uVP*vec4(aP,1.0); }"""

    const val SPLAT_FS = """#version 300 es
precision highp float;
uniform float uTime, uLife, uLight; in vec2 vUV; in vec4 vCol; in vec2 vMisc; out vec4 o;
void main(){
  float age = (uTime-vMisc.x)/uLife; if (age >= 1.0) discard;
  float ang = atan(vUV.y,vUV.x+1e-5), r = length(vUV);
  float edge = 0.78 + 0.11*sin(ang*3.0+vMisc.y*6.28) + 0.07*sin(ang*7.0+vMisc.y*19.0) + 0.04*sin(ang*13.0+vMisc.y*7.0);
  float a = 1.0-smoothstep(edge-0.20,edge,r);
  if (a < 0.01) discard;
  vec3 c = vCol.rgb*(0.82+0.30*smoothstep(0.9,0.2,r));
  o = vec4(c*uLight, a*vCol.a*(1.0-smoothstep(0.55,1.0,age)));
}"""

    // bushes / rocks / grass: instanced, flat lit like the JS MeshLambertMaterial; grass blades are procedural (alpha test) and sway in the wind
    const val SCAT_VS = """#version 300 es
layout(location=0) in vec3 aP; layout(location=1) in vec3 aN; layout(location=2) in vec3 iP; layout(location=3) in vec3 iS; layout(location=4) in float iR; layout(location=5) in vec3 iC; layout(location=6) in vec2 aUV;
uniform mat4 uVP; uniform float uTime, uGrass, uFlower;
out vec3 vN; out vec3 vW; out vec3 vC; out vec2 vUV;
void main(){
  vec3 p = aP * iS;
  if (uGrass > 0.5 || uFlower > 0.5) {
    float h = aP.y;
    p.x += (sin(uTime*1.7 + iP.x*0.15 + iP.z*0.11)*0.14 + 0.05*sin(uTime*3.1 + iP.z*0.5)) * h*h;
    p.z += cos(uTime*1.3 + iP.z*0.2) * 0.09 * h*h;
  }
  float c = cos(iR), s = sin(iR);
  vec3 r = vec3(c*p.x + s*p.z, p.y, -s*p.x + c*p.z);
  vec3 n = normalize(aN / max(iS, vec3(0.001)));
  vN = vec3(c*n.x + s*n.z, n.y, -s*n.x + c*n.z); vW = r + iP; vC = iC; vUV = aUV;
  gl_Position = uVP * vec4(vW, 1.0);
}"""

    const val SCAT_FS = """#version 300 es
precision highp float;
in vec3 vN; in vec3 vW; in vec3 vC; in vec2 vUV; out vec4 o;
uniform vec3 uSun, uCam, uFog, uSunCol, uAmbCol; uniform float uGrass, uReed, uFlower;
float hash(float n){ return fract(sin(n*91.7)*43758.5453); }
void main(){
  vec3 base = vC;
  if (uReed > 0.5) {                        // reed blades: green base -> straw tips
    float t = vUV.y;
    base = t < 0.5 ? mix(vec3(0.239,0.353,0.149), vec3(0.427,0.541,0.227), t*2.0) : mix(vec3(0.427,0.541,0.227), vec3(0.702,0.678,0.400), (t-0.5)*2.0);
  }
  if (uFlower > 0.5) {                      // flower clump: uv.x 0 = stem/leaf green, 0.5 = darker cup, 1 = petal colour (instance colour)
    float u = vUV.x;
    base = u < 0.25 ? vec3(0.22,0.44,0.10) * (0.8 + 0.4*hash(floor(vW.x*3.0)+floor(vW.z*3.0))) : (u > 0.75 ? vC : vC*vec3(1.0,0.72,0.30));
  }
  if (uGrass > 0.5) {                       // ~22 curved blades of different height / width (JS draws them into a 128 px canvas)
    float a = 0.0; float u = vUV.x, v = vUV.y;
    for (int i = 0; i < 9; i++) {
      float fi = float(i);
      float bx = 0.06 + 0.88*hash(fi + 1.0), h = 0.40 + 0.60*hash(fi + 7.0), lean = (hash(fi + 13.0) - 0.5)*0.55, w = 0.035 + 0.04*hash(fi + 19.0);
      float cx = bx + lean*v*v, wd = w*(1.0 - v/h);
      if (v < h && abs(u - cx) < wd) a = 1.0;
    }
    if (a < 0.5) discard;
    base *= mix(0.55, 1.45, v);
  }
  vec3 n = normalize(vN);
  float dif = max(dot(n, normalize(uSun)), 0.0), hemi = 0.5 + 0.5*n.y;
  vec3 c = base * (uAmbCol*0.9*hemi + uSunCol*0.95*dif + uAmbCol*0.1);
  if (uFlower > 0.5) c += base * (uAmbCol * 0.25);
  float f = 1.0 - exp(-pow(max(length(uCam - vW) - 120.0, 0.0)/330.0, 1.6));
  o = vec4(mix(c, uFog, clamp(f, 0.0, 1.0)), 1.0);
}"""

    // tyre smoke (JS smokePts): soft white puffs that rise, grow and fade
    const val SMOKE_VS = """#version 300 es
layout(location=0) in vec3 aP; layout(location=1) in float aSize; layout(location=2) in float aAlpha;
uniform mat4 uView, uProj; uniform float uScale;
out float vA;
void main(){
  vA = aAlpha; vec4 mv = uView*vec4(aP,1.0);
  if (aSize <= 0.0 || mv.z > -0.1){ gl_Position = vec4(2.0,2.0,2.0,1.0); gl_PointSize = 0.0; return; }
  gl_Position = uProj*mv; gl_PointSize = min(aSize*uScale/(-mv.z), 150.0);
}"""

    const val SMOKE_FS = """#version 300 es
precision highp float;
uniform float uLight; in float vA; out vec4 o;
void main(){ float r = length(gl_PointCoord - 0.5)*2.0; float a = smoothstep(1.0, 0.0, r); a *= a; o = vec4(vec3(0.94,0.94,0.96)*uLight, a*vA); }"""

    // harbor: pier deck (planks), concrete apron, flat-coloured boxes / boats, shore foam (blended), gantry sign (texture).
    // vertex: aP aN aC(colour) aT(u, v, kind)  kind 0 flat, 1 planks, 2 concrete, 3 foam, 4 sign
    const val HARBOR_VS = """#version 300 es
layout(location=0) in vec3 aP; layout(location=1) in vec3 aN; layout(location=2) in vec3 aC; layout(location=3) in vec3 aT;
uniform mat4 uVP; uniform mat4 uM;
out vec3 vW; out vec3 vN; out vec3 vC; out vec3 vT;
void main(){ vec4 w = uM*vec4(aP,1.0); vW = w.xyz; vN = mat3(uM)*aN; vC = aC; vT = aT; gl_Position = uVP*w; }"""

    const val HARBOR_FS = """#version 300 es
precision highp float;
in vec3 vW; in vec3 vN; in vec3 vC; in vec3 vT; out vec4 o;
uniform vec3 uCam, uFog, uSun, uSunCol, uAmbCol; uniform float uTime; uniform sampler2D uSign;
float hash(vec2 p){ p=fract(p*vec2(123.34,456.21)); p+=dot(p,p+45.32); return fract(p.x*p.y); }
float noise(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.-2.*f);
  return mix(mix(hash(i),hash(i+vec2(1.,0.)),f.x), mix(hash(i+vec2(0.,1.)),hash(i+vec2(1.,1.)),f.x), f.y); }
void main(){
  vec3 n = normalize(vN); if (dot(n, uCam - vW) < 0.0) n = -n;
  float k = vT.z; vec3 c = vC; float a = 1.0; float emis = 0.0;
  float d = length(vW - uCam);
  float fg = clamp(1.0 - exp(-pow(max(d-120.0,0.0)/330.0, 1.6)), 0.0, 1.0);
  if (k > 3.5){
    c = textureLod(uSign, vec2(vT.x, 1.0 - vT.y), 0.0).rgb; emis = 0.35;
  } else if (k > 2.5){
    float band = sin(clamp(vT.y,0.0,1.0)*3.14159);
    float nn = noise(vec2(vT.x*3.0 + uTime*0.12, vT.y*9.0));
    a = band*band*smoothstep(0.22,0.7,nn)*(0.78+0.22*sin(uTime*1.3))*0.85;
    float L = clamp(dot(uSunCol + uAmbCol, vec3(0.33)), 0.0, 1.0);
    o = vec4(mix(vec3(0.96)*(0.3+0.7*L), uFog, fg), a*(1.0-fg*0.6)); return;
  } else if (k > 1.5){
    float s = noise(vT.xy*0.9)*0.5 + noise(vT.xy*5.0)*0.35 + noise(vT.xy*23.0)*0.15;
    c = vC*(0.82+0.3*s);
    vec2 q = fract(vT.xy/6.0); float e = min(min(q.x,1.0-q.x), min(q.y,1.0-q.y));
    c *= 1.0 - 0.25*(1.0 - smoothstep(0.0,0.02,e));
  } else if (k > 0.5 && n.y > 0.5){
    float id = floor(vT.y/0.36), g = fract(vT.y/0.36);
    float off = hash(vec2(id,1.7))*3.0, jx = vT.x/2.8 + off;
    float h = hash(vec2(id, floor(jx))), grain = noise(vec2(vT.x*3.0, vT.y*14.0));
    c = vec3(0.55,0.42,0.27)*(0.78+0.35*h)*(0.88+0.24*grain);
    c *= 0.5 + 0.5*smoothstep(0.0,0.07,g)*smoothstep(0.0,0.07,1.0-g);
    c *= 0.6 + 0.4*smoothstep(0.0,0.02,fract(jx));
  }
  float dif = max(dot(n, normalize(uSun)), 0.0);
  vec3 col = c*(uAmbCol*0.8*(0.5+0.5*n.y) + uSunCol*1.05*dif);
  col = mix(col, c*1.1, emis);
  o = vec4(mix(col, uFog, fg), 1.0);
}"""

    // birds (JS birdVS/birdFS): wing flap in the vertex shader, thin wings let sunlight through
    const val BIRD_VS = """#version 300 es
layout(location=0) in vec3 aP; layout(location=1) in vec3 aN; layout(location=2) in float aS; layout(location=3) in vec3 aCol;
layout(location=4) in vec3 iPos; layout(location=5) in vec3 iRot; layout(location=6) in vec3 iMisc; layout(location=7) in float iTint;
uniform mat4 uVP; uniform float uL, uRx;
out vec3 vC; out vec3 vN; out vec3 vW; out float vS;
vec3 rot(vec3 v){      // three.js Euler 'YXZ': Rz first, then Rx, then Ry
  float cx=cos(iRot.y), sx=sin(iRot.y), cy=cos(iRot.x), sy=sin(iRot.x), cz=cos(iRot.z), sz=sin(iRot.z);
  v = vec3(cz*v.x - sz*v.y, sz*v.x + cz*v.y, v.z);
  v = vec3(v.x, cx*v.y - sx*v.z, sx*v.y + cx*v.z);
  return vec3(cy*v.x + sy*v.z, v.y, -sy*v.x + cy*v.z);
}
void main(){
  float iPh = iMisc.y, iAmp = iMisc.z;
  vec3 p = aP, n = aN;
  if (aS >= 0.) { float sd = p.x < 0. ? -1. : 1.; float w = aS*uL;
    float a = iAmp*.95*sin(iPh - 1.15*aS)*(.3 + .7*aS) + .1*aS + .12*aS*aS*(1. - iAmp);
    p.x = sd*(uRx + w*cos(a)); p.y += w*sin(a); p.z -= .1*w*abs(sin(a)); n = vec3(-sd*sin(a), cos(a), 0.); }
  p.y += iAmp*.03*uL*cos(iPh);
  vec3 wp = rot(p*iMisc.x) + iPos;
  vN = normalize(rot(n)); vC = aCol*iTint; vW = wp; vS = aS;
  gl_Position = uVP*vec4(wp, 1.);
}"""

    const val BIRD_FS = """#version 300 es
precision highp float;
in vec3 vC; in vec3 vN; in vec3 vW; in float vS; out vec4 o;
uniform vec3 uSun, uSunCol, uAmbCol, uFog, uCam;
void main(){
  vec3 n = normalize(vN); if (!gl_FrontFacing) n = -n;
  vec3 L = normalize(uSun);
  float tr = (vS >= 0. ? .35 : 0.)*max(dot(-n, L), 0.);
  vec3 c = vC*(uAmbCol*1.6 + uSunCol*(max(dot(n, L), 0.) + tr));
  c = mix(c, uFog, smoothstep(320., 1900., distance(vW, uCam)));
  o = vec4(c, 1.);
}"""
}
