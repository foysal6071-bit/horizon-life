package com.horizonlife.gl

import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.os.SystemClock
import com.horizonlife.game.CarState
import com.horizonlife.game.Fence
import com.horizonlife.game.Game
import com.horizonlife.game.Lamps
import com.horizonlife.game.Mud
import com.horizonlife.game.Potholes
import com.horizonlife.game.Settings
import com.horizonlife.game.VehiclePhysics
import com.horizonlife.game.World
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.*

/** Milestone-1 renderer: sky, streamed terrain chunks, water, ring road, a box-built stand-in car. Audi R8 mesh etc. come later. */
class GameRenderer(val game: Game, private val ctx: android.content.Context) : GLSurfaceView.Renderer {
    private var w = 1; private var h = 1
    private var skyP = 0; private var terrainP = 0; private var waterP = 0; private var meshP = 0
    private val terrain = Terrain(); private var r8: R8Model? = null; private var trees: Trees? = null; private var maple: MapleTrees? = null; private var mapleP = 0; private val mapleBuf = FloatArray(MapleTrees.MAX * 5); private var mapleN = -1; private var mapleT = 0.0; private var mapleX = 0.0; private var mapleZ = 0.0; private var treeP = 0; private var roadP = 0; private var roads: RoadMesh? = null; private var track: TrackMesh? = null; private var bridgeP = 0; private var glowP = 0; private var pothP = 0; private var mudR: MudRenderer? = null; private var scatter: ScatterRenderer? = null; private var birdR: BirdRenderer? = null; private var bridgeM: BridgeMesh? = null; private var harbor: HarborRenderer? = null; private var seaTex = 0; @Volatile private var seaData: ByteArray? = null; private var cubeTex = 0; private var mtnTex = 0; private var mtnDat = 0; private var t0 = 0L
    private var cubeVao = 0; private var quadVao = 0
    private var last = 0L
    private val proj = FloatArray(16); private val view = FloatArray(16); private val vp = FloatArray(16)
    private val m = FloatArray(16); private val tmp = FloatArray(16); private val base = FloatArray(16)
    private val env get() = game.env
    private val sun get() = env.sunDir
    private val fog get() = env.fog
    @Volatile var fps = 0f
    private var fpsAcc = 0f; private var fpsN = 0

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glClearColor(0.7f, 0.86f, 0.96f, 1f)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glEnable(GLES30.GL_CULL_FACE)
        skyP = GlUtil.program(Shaders.SKY_VS, Shaders.SKY_FS)
        seaTex = 0
        if (seaData == null) Thread {                                   // depth map: metres of water over the whole island (JS seaDepthTex)
            val N = 512; val R = 1150.0; val a = ByteArray(N * N)
            for (j in 0 until N) for (i in 0 until N) {
                val x = (i + 0.5) / N * 2 * R - R; val z = (j + 0.5) / N * 2 * R - R
                val depth = World.WATER_Y - World.groundH(x, z)
                a[j * N + i] = Math.round(min(max((depth + 3) / 12, 0.0), 1.0) * 255).toInt().toByte()
            }
            seaData = a
        }.apply { isDaemon = true; start() }
        cubeTex = loadTex("sky_atlas.jpg", false); mtnTex = loadTex("mtn_col.jpg", true); mtnDat = loadTex("mtn_data.png", true)
        terrainP = GlUtil.program(Shaders.TERRAIN_VS, Shaders.TERRAIN_FS)
        waterP = GlUtil.program(Shaders.WATER_VS, Shaders.WATER_FS)
        locCache.clear(); terrain.init(); t0 = SystemClock.elapsedRealtime()
        meshP = GlUtil.program(Shaders.MESH_VS, Shaders.MESH_FS)
        quadVao = makeQuad(); cubeVao = makeCube()
        roadP = GlUtil.program(Shaders.ROAD_VS, Shaders.ROAD_FS); roads = RoadMesh()
        track = try { TrackMesh() } catch (e: Exception) { android.util.Log.e("Track", "track mesh failed", e); null }
        glowP = GlUtil.program(Shaders.GLOW_VS, Shaders.GLOW_FS)
        pothP = GlUtil.program(Shaders.POTH_VS, Shaders.POTH_FS)
        scatter = try { ScatterRenderer() } catch (e: Exception) { android.util.Log.e("Scatter", "scatter renderer failed", e); null }
        birdR = try { BirdRenderer() } catch (e: Exception) { android.util.Log.e("Birds", "bird renderer failed", e); null }
        mudR = try { MudRenderer() } catch (e: Exception) { android.util.Log.e("Mud", "mud renderer failed", e); null }
        harbor = try { HarborRenderer() } catch (e: Exception) { android.util.Log.e("Harbor", "harbor renderer failed", e); null }
        bridgeP = GlUtil.program(Shaders.BRIDGE_VS, Shaders.BRIDGE_FS)
        bridgeM = try { BridgeMesh() } catch (e: Exception) { android.util.Log.e("Bridge", "bridge mesh failed", e); null }
        treeP = GlUtil.program(Shaders.TREE_VS, Shaders.TREE_FS)
        trees = try { Trees(ctx) } catch (e: Exception) { android.util.Log.e("Trees", "tree load failed", e); null }
        mapleP = GlUtil.program(Shaders.MAPLE_VS, Shaders.MAPLE_FS)
        maple = try { MapleTrees(ctx) } catch (e: Exception) { android.util.Log.e("Maple", "maple load failed", e); null }
        r8 = try { R8Model(ctx) } catch (e: Exception) { android.util.Log.e("R8", "model failed, using box car", e); null }
        last = SystemClock.elapsedRealtimeNanos()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        w = width; h = height; GLES30.glViewport(0, 0, w, h)
    }

    override fun onDrawFrame(gl: GL10?) {
        if (Settings.optFrameCap) {            // JS OPT.frameCap: 90/120 Hz screens draw at ~60 fps
            val el = (SystemClock.elapsedRealtimeNanos() - last) / 1e6; if (el < 15.5) try { Thread.sleep((16.0 - el).toLong().coerceAtLeast(1)) } catch (_: InterruptedException) {}
        }
        val now = SystemClock.elapsedRealtimeNanos(); val dt = (now - last) / 1e9; last = now
        game.update(dt)
        fpsAcc += dt.toFloat(); fpsN++; if (fpsAcc > 0.5f) { fps = fpsN / fpsAcc; fpsAcc = 0f; fpsN = 0 }

        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)
        val cam = game.cam
        val aspect = w.toFloat() / h
        Matrix.perspectiveM(proj, 0, cam.fov.toFloat(), aspect, 0.6f, 2000f)
        Matrix.setLookAtM(view, 0,
            cam.pos[0].toFloat(), cam.pos[1].toFloat(), cam.pos[2].toFloat(),
            cam.target[0].toFloat(), cam.target[1].toFloat(), cam.target[2].toFloat(), 0f, 1f, 0f)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)

        drawSky(cam.fov.toFloat(), aspect)
        terrain.update(cam.pos[0], cam.pos[2])
        drawGround()
        drawTrees(); drawMaples()
        drawScatter()
        birdR?.draw(vp, env, cam.pos[0].toFloat(), cam.pos[1].toFloat(), cam.pos[2].toFloat())
        drawHarbor(false)
        drawWater()
        drawLamps()
        drawFence()
        if (!game.cam.hideCar) drawCar(game.car)
        mudR?.drawParticles(vp, view, proj, w, h, cam.fov.toFloat(), env)
        drawGlow()
    }

    private fun lightUniforms(p: Int) {
        GLES30.glUniform3fv(loc(p, "uSunCol"), 1, env.sunCol, 0); GLES30.glUniform3fv(loc(p, "uAmbCol"), 1, env.ambCol, 0)
    }

    /** asset image -> GL texture (flipped like Three.js flipY, linear, no mips). 0 if the file is missing. */
    private fun loadTex(name: String, wrapS: Boolean): Int = try {
        val src = ctx.assets.open(name).use { android.graphics.BitmapFactory.decodeStream(it) }
        val fm = android.graphics.Matrix().apply { postScale(1f, -1f) }
        val bmp = android.graphics.Bitmap.createBitmap(src, 0, 0, src.width, src.height, fm, false); src.recycle()
        val id = IntArray(1); GLES30.glGenTextures(1, id, 0); GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, id[0])
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR); GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, if (wrapS) GLES30.GL_REPEAT else GLES30.GL_CLAMP_TO_EDGE); GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        android.opengl.GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0); bmp.recycle(); id[0]
    } catch (e: Exception) { android.util.Log.e("Sky", "texture $name failed", e); 0 }

    private fun drawSky(fovDeg: Float, aspect: Float) {
        GLES30.glDisable(GLES30.GL_DEPTH_TEST); GLES30.glDisable(GLES30.GL_CULL_FACE)
        GLES30.glUseProgram(skyP)
        // camera basis from the view matrix rows
        val r = floatArrayOf(view[0], view[4], view[8]); val u = floatArrayOf(view[1], view[5], view[9])
        val f = floatArrayOf(-view[2], -view[6], -view[10])
        val t = tan(Math.toRadians(fovDeg / 2.0)).toFloat()
        GLES30.glUniform3fv(loc(skyP, "uRight"), 1, r, 0); GLES30.glUniform3fv(loc(skyP, "uUp"), 1, u, 0)
        GLES30.glUniform3fv(loc(skyP, "uFwd"), 1, f, 0)
        GLES30.glUniform2f(loc(skyP, "uTan"), t * aspect, t)
        GLES30.glUniform3fv(loc(skyP, "uSun"), 1, env.skySun, 0)
        GLES30.glUniform3fv(loc(skyP, "uCubeTint"), 1, env.cubeTint, 0)
        val haveCube = cubeTex != 0; val haveMtn = mtnTex != 0 && mtnDat != 0
        GLES30.glUniform1f(loc(skyP, "uCubeAmt"), if (haveCube) 1f else 0f); GLES30.glUniform1f(loc(skyP, "uMtnAmt"), if (haveMtn) 1f else 0f)
        GLES30.glUniform1f(loc(skyP, "uInset"), 1.5f / 512f)
        for ((i, t) in intArrayOf(cubeTex, mtnTex, mtnDat).withIndex()) {
            GLES30.glActiveTexture(GLES30.GL_TEXTURE1 + i); GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, if (t != 0) t else 0)
        }
        GLES30.glUniform1i(loc(skyP, "uCubeTex"), 1); GLES30.glUniform1i(loc(skyP, "uMtnTex"), 2); GLES30.glUniform1i(loc(skyP, "uMtnData"), 3)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glUniform3fv(loc(skyP, "uMoon"), 1, env.moonDir, 0)
        GLES30.glUniform3fv(loc(skyP, "uHor"), 1, env.hor, 0); GLES30.glUniform3fv(loc(skyP, "uMid"), 1, env.mid, 0); GLES30.glUniform3fv(loc(skyP, "uZen"), 1, env.zen, 0)
        GLES30.glUniform3fv(loc(skyP, "uCl"), 1, env.cloudLit, 0); GLES30.glUniform3fv(loc(skyP, "uCs"), 1, env.cloudShade, 0)
        GLES30.glUniform1f(loc(skyP, "uTime"), ((SystemClock.elapsedRealtime() - t0) / 1000.0).toFloat())
        GLES30.glUniform1f(loc(skyP, "uNight"), env.night); GLES30.glUniform1f(loc(skyP, "uTw"), env.twilight)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST); GLES30.glEnable(GLES30.GL_CULL_FACE)
    }

    private fun drawGround() {
        val c = game.cam
        GLES30.glUseProgram(terrainP)
        GLES30.glUniformMatrix4fv(loc(terrainP, "uVP"), 1, false, vp, 0)
        GLES30.glUniform3f(loc(terrainP, "uCam"), c.pos[0].toFloat(), c.pos[1].toFloat(), c.pos[2].toFloat())
        GLES30.glUniform3fv(loc(terrainP, "uFog"), 1, fog, 0)
        GLES30.glUniform3fv(loc(terrainP, "uSun"), 1, sun, 0); lightUniforms(terrainP)
        terrain.draw()
        drawRoads()
        drawPotholes()
        mudR?.drawMarks(vp, env, sun, fog, game.cam.pos[0].toFloat(), game.cam.pos[1].toFloat(), game.cam.pos[2].toFloat())
        drawBridges()
    }

    private fun drawRoads() {
        val c = game.cam
        GLES30.glUseProgram(roadP)
        GLES30.glUniformMatrix4fv(loc(roadP, "uVP"), 1, false, vp, 0)
        GLES30.glUniform3f(loc(roadP, "uCam"), c.pos[0].toFloat(), c.pos[1].toFloat(), c.pos[2].toFloat())
        GLES30.glUniform3fv(loc(roadP, "uFog"), 1, fog, 0); GLES30.glUniform3fv(loc(roadP, "uSun"), 1, sun, 0); lightUniforms(roadP)
        GLES30.glDisable(GLES30.GL_CULL_FACE)
        GLES30.glEnable(GLES30.GL_BLEND); GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)
        GLES30.glEnable(GLES30.GL_POLYGON_OFFSET_FILL); GLES30.glPolygonOffset(-2f, -2f)
        roads?.draw()
        track?.draw()
        GLES30.glDisable(GLES30.GL_POLYGON_OFFSET_FILL); GLES30.glDisable(GLES30.GL_BLEND); GLES30.glEnable(GLES30.GL_CULL_FACE)
    }

    /** wet pothole decals on the roads (JS POTH instanced planes): only those within 250 m of the camera */
    private fun drawPotholes() {
        val c = game.cam
        GLES30.glUseProgram(pothP)
        GLES30.glUniformMatrix4fv(loc(pothP, "uVP"), 1, false, vp, 0)
        GLES30.glUniform3f(loc(pothP, "uCam"), c.pos[0].toFloat(), c.pos[1].toFloat(), c.pos[2].toFloat())
        GLES30.glUniform3fv(loc(pothP, "uFog"), 1, fog, 0); GLES30.glUniform3fv(loc(pothP, "uSun"), 1, sun, 0); lightUniforms(pothP)
        GLES30.glDisable(GLES30.GL_CULL_FACE); GLES30.glEnable(GLES30.GL_BLEND); GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)
        GLES30.glDepthMask(false); GLES30.glEnable(GLES30.GL_POLYGON_OFFSET_FILL); GLES30.glPolygonOffset(-5f, -5f)
        GLES30.glBindVertexArray(0)
        for (p in Potholes.list) {
            val dx = p.x - c.pos[0]; val dz = p.z - c.pos[2]; if (dx * dx + dz * dz > 250.0 * 250.0) continue
            val ca = cos(p.a); val sa = sin(p.a); val sx = p.r * p.e * 1.15; val sz = p.r * 1.15      // plane rotated about Y like three.js rotation.y
            GLES30.glUniform3f(loc(pothP, "uC"), p.x.toFloat(), (p.y + 0.09).toFloat(), p.z.toFloat())
            GLES30.glUniform3f(loc(pothP, "uA"), (ca * sx).toFloat(), 0f, (-sa * sx).toFloat())
            GLES30.glUniform3f(loc(pothP, "uB"), (sa * sz).toFloat(), 0f, (ca * sz).toFloat())
            GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
        }
        GLES30.glDisable(GLES30.GL_POLYGON_OFFSET_FILL); GLES30.glDepthMask(true); GLES30.glDisable(GLES30.GL_BLEND); GLES30.glEnable(GLES30.GL_CULL_FACE)
    }

    private fun drawBridges() {
        val bm = bridgeM ?: return; val c = game.cam
        GLES30.glUseProgram(bridgeP)
        GLES30.glUniformMatrix4fv(loc(bridgeP, "uVP"), 1, false, vp, 0)
        GLES30.glUniform3f(loc(bridgeP, "uCam"), c.pos[0].toFloat(), c.pos[1].toFloat(), c.pos[2].toFloat())
        GLES30.glUniform3fv(loc(bridgeP, "uFog"), 1, fog, 0); GLES30.glUniform3fv(loc(bridgeP, "uSun"), 1, sun, 0); lightUniforms(bridgeP)
        GLES30.glDisable(GLES30.GL_CULL_FACE)
        bm.draw()
        GLES30.glEnable(GLES30.GL_CULL_FACE)
    }

    /** roadside post-and-rope fence: posts within 130 m of the camera; knocked posts tip over (Fence.Post.ang) and drop their ropes */
    private fun drawFence() {
        val cam = game.cam
        GLES30.glUseProgram(meshP)
        GLES30.glUniformMatrix4fv(loc(meshP, "uVP"), 1, false, vp, 0)
        GLES30.glUniform3fv(loc(meshP, "uSun"), 1, sun, 0); lightUniforms(meshP)
        GLES30.glUniform3f(loc(meshP, "uCam"), cam.pos[0].toFloat(), cam.pos[1].toFloat(), cam.pos[2].toFloat())
        GLES30.glUniform3fv(loc(meshP, "uFog"), 1, fog, 0)
        GLES30.glUniform1f(loc(meshP, "uAlpha"), 1f); GLES30.glUniform1f(loc(meshP, "uEmis"), 0f)
        GLES30.glBindVertexArray(cubeVao)
        val wood = floatArrayOf(0.40f, 0.30f, 0.20f); val rope = floatArrayOf(0.62f, 0.52f, 0.36f)
        val R = 130.0; val c0 = Fence.cell(cam.pos[0] - R); val c1 = Fence.cell(cam.pos[0] + R); val d0 = Fence.cell(cam.pos[2] - R); val d1 = Fence.cell(cam.pos[2] + R)
        for (i in c0..c1) for (j in d0..d1) {
            val g = Fence.posts(i, j) ?: continue
            for (p in g) {
                Matrix.setIdentityM(base, 0); Matrix.translateM(base, 0, p.x.toFloat(), p.y.toFloat(), p.z.toFloat())
                if (p.broken) Matrix.rotateM(base, 0, Math.toDegrees(p.ang).toFloat(), p.dz.toFloat(), 0f, (-p.dx).toFloat())
                box(0f, 0.57f, 0f, 0.14f, 1.14f, 0.14f, wood, 0.05f)
                val q = p.next
                if (q != null && !p.broken && !q.broken) {
                    val dx = q.x - p.x; val dz = q.z - p.z; val dy = q.y - p.y; val hl = sqrt(dx * dx + dz * dz)
                    val yaw = Math.toDegrees(atan2(dx, dz)).toFloat(); val pitch = Math.toDegrees(atan2(dy, hl)).toFloat()
                    Matrix.setIdentityM(base, 0)
                    box(((p.x + q.x) / 2).toFloat(), ((p.y + q.y) / 2 + 0.85).toFloat(), ((p.z + q.z) / 2).toFloat(), 0.04f, 0.04f, sqrt(hl * hl + dy * dy).toFloat(), rope, 0f) { mm ->
                        Matrix.rotateM(mm, 0, yaw, 0f, 1f, 0f); Matrix.rotateM(mm, 0, -pitch, 1f, 0f, 0f) }
                }
            }
        }
    }

    /** wooden street lamps (pole + cross-arm + lantern), nearest ones only; hit poles lean (Lamps.tilt) */
    private fun drawLamps() {
        val cam = game.cam; val nt = env.night
        GLES30.glUseProgram(meshP)
        GLES30.glUniformMatrix4fv(loc(meshP, "uVP"), 1, false, vp, 0)
        GLES30.glUniform3fv(loc(meshP, "uSun"), 1, sun, 0); lightUniforms(meshP)
        GLES30.glUniform3f(loc(meshP, "uCam"), cam.pos[0].toFloat(), cam.pos[1].toFloat(), cam.pos[2].toFloat())
        GLES30.glUniform3fv(loc(meshP, "uFog"), 1, fog, 0)
        GLES30.glUniform1f(loc(meshP, "uAlpha"), 1f)
        GLES30.glBindVertexArray(cubeVao)
        val wood = floatArrayOf(0.36f, 0.26f, 0.17f); val iron = floatArrayOf(0.14f, 0.15f, 0.17f)
        val lens = floatArrayOf(0.55f + 0.45f * nt, 0.48f + 0.34f * nt, 0.30f + 0.2f * nt)
        val H = Lamps.H.toFloat()
        for (i in 0 until Lamps.count) {
            val dx = Lamps.x[i] - cam.pos[0]; val dz = Lamps.z[i] - cam.pos[2]; if (dx * dx + dz * dz > 260.0 * 260.0) continue
            Matrix.setIdentityM(base, 0)
            Matrix.translateM(base, 0, Lamps.x[i].toFloat(), Lamps.by[i].toFloat(), Lamps.z[i].toFloat())
            val tl = Lamps.tilt[i]
            if (tl > 0.0) { val d = Lamps.tiltDir[i]; Matrix.rotateM(base, 0, Math.toDegrees(tl).toFloat(), sin(d).toFloat(), 0f, (-cos(d)).toFloat()) }
            val ix = (-cos(Lamps.ang[i])).toFloat(); val iz = (-sin(Lamps.ang[i])).toFloat()        // direction from the pole towards the road
            val yaw = Math.toDegrees(atan2(ix.toDouble(), iz.toDouble())).toFloat()
            GLES30.glUniform1f(loc(meshP, "uEmis"), 0f)
            box(0f, H / 2, 0f, 0.30f, H, 0.30f, wood, 0.05f)
            box(ix * 0.75f, H - 0.25f, iz * 0.75f, 0.14f, 0.14f, 1.7f, wood, 0.05f) { mm -> Matrix.rotateM(mm, 0, yaw, 0f, 1f, 0f) }
            box(ix * 1.45f, H - 0.75f, iz * 1.45f, 0.5f, 0.12f, 0.5f, iron, 0.5f)
            GLES30.glUniform1f(loc(meshP, "uEmis"), nt)
            box(ix * 1.45f, H - 1.0f, iz * 1.45f, 0.3f, 0.14f, 0.3f, lens, 0f)
        }
        GLES30.glUniform1f(loc(meshP, "uEmis"), 0f)
    }

    /** night light: ground pool + halo at each lantern, and the pool in front of the car's headlights (JS pools / halos / hlM) */
    private fun drawGlow() {
        val nt = env.night; if (nt < 0.02f) return
        val cam = game.cam; val s = game.car; val p = game.pose
        GLES30.glUseProgram(glowP)
        GLES30.glUniformMatrix4fv(loc(glowP, "uVP"), 1, false, vp, 0)
        GLES30.glDisable(GLES30.GL_CULL_FACE); GLES30.glEnable(GLES30.GL_BLEND); GLES30.glBlendFunc(GLES30.GL_ONE, GLES30.GL_ONE); GLES30.glDepthMask(false)
        GLES30.glBindVertexArray(0)
        fun quad(cx: Float, cy: Float, cz: Float, a: FloatArray, b: FloatArray, sx: Float, sy: Float, r: Float, g: Float, bl: Float, alpha: Float) {
            GLES30.glUniform3f(loc(glowP, "uC"), cx, cy, cz); GLES30.glUniform3fv(loc(glowP, "uA"), 1, a, 0); GLES30.glUniform3fv(loc(glowP, "uB"), 1, b, 0)
            GLES30.glUniform2f(loc(glowP, "uS"), sx, sy); GLES30.glUniform3f(loc(glowP, "uCol"), r, g, bl); GLES30.glUniform1f(loc(glowP, "uAlpha"), alpha)
            GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
        }
        val ex = floatArrayOf(1f, 0f, 0f); val ez = floatArrayOf(0f, 0f, 1f)
        val cr = floatArrayOf(view[0], view[4], view[8]); val cu = floatArrayOf(view[1], view[5], view[9])
        for (i in 0 until Lamps.count) {
            val dx = Lamps.x[i] - cam.pos[0]; val dz = Lamps.z[i] - cam.pos[2]; if (dx * dx + dz * dz > 220.0 * 220.0) continue
            val lx = (Lamps.x[i] - cos(Lamps.ang[i]) * 1.45).toFloat(); val lz = (Lamps.z[i] - sin(Lamps.ang[i]) * 1.45).toFloat(); val y = Lamps.by[i].toFloat()
            quad(lx, y + 0.14f, lz, ex, ez, 7.5f, 7.5f, 1f, 0.72f, 0.38f, 0.6f * nt)
            quad(lx, y + Lamps.H.toFloat() - 1.0f, lz, cr, cu, 4f, 4f, 1f, 0.78f, 0.45f, 0.5f * nt)
        }
        val sH = sin(s.heading).toFloat(); val cH = cos(s.heading).toFloat()      // headlight pool: 10 x 24 m, centred 12 m ahead
        quad((p.x + sH * 12).toFloat(), p.y.toFloat() + 0.06f, (p.z + cH * 12).toFloat(), floatArrayOf(cH, 0f, -sH), floatArrayOf(sH, 0f, cH), 5f, 12f, 1f, 0.94f, 0.78f, 0.5f * nt)
        if (!game.cam.hideCar) for (sd in intArrayOf(-1, 1)) {      // headlight lenses: two bright halos on the nose
            val hx = (p.x + sH * 2.05 + cH * 0.66 * sd).toFloat(); val hz = (p.z + cH * 2.05 - sH * 0.66 * sd).toFloat()
            quad(hx, p.y.toFloat() + 0.62f, hz, cr, cu, 1.1f, 1.1f, 1f, 0.95f, 0.80f, 0.85f * nt)
        }
        GLES30.glDepthMask(true); GLES30.glDisable(GLES30.GL_BLEND); GLES30.glEnable(GLES30.GL_CULL_FACE)
    }

    private fun drawTrees() {
        val t = trees ?: return; val c = game.cam
        GLES30.glUseProgram(treeP)
        GLES30.glUniformMatrix4fv(loc(treeP, "uVP"), 1, false, vp, 0)
        GLES30.glUniform3f(loc(treeP, "uCam"), c.pos[0].toFloat(), c.pos[1].toFloat(), c.pos[2].toFloat())
        GLES30.glUniform3fv(loc(treeP, "uFog"), 1, fog, 0); GLES30.glUniform3fv(loc(treeP, "uSun"), 1, sun, 0); lightUniforms(treeP)
        t.draw(treeP, terrain.treeLists(), c.pos[0], c.pos[2], ((SystemClock.elapsedRealtime() - t0) / 1000.0).toFloat()) { n -> loc(treeP, n) }
    }

    private fun drawMaples() {
        val m = maple ?: return; val t = trees ?: return; val c = game.cam
        val nowT = SystemClock.elapsedRealtime() / 1000.0
        val moved = abs(c.pos[0] - mapleX) + abs(c.pos[2] - mapleZ)
        if (!(Settings.optTreeThrottle && mapleN >= 0 && (nowT - mapleT < 0.25 || (nowT - mapleT < 1.5 && moved < 3)))) {
            mapleN = t.pickMaples(terrain.treeLists(), c.pos[0], c.pos[2], mapleBuf); mapleT = nowT; mapleX = c.pos[0]; mapleZ = c.pos[2]
        }
        val n = mapleN
        if (n <= 0) return
        GLES30.glUseProgram(mapleP)
        GLES30.glUniformMatrix4fv(loc(mapleP, "uVP"), 1, false, vp, 0)
        GLES30.glUniform3f(loc(mapleP, "uCam"), c.pos[0].toFloat(), c.pos[1].toFloat(), c.pos[2].toFloat())
        GLES30.glUniform3fv(loc(mapleP, "uFog"), 1, fog, 0); GLES30.glUniform3fv(loc(mapleP, "uSun"), 1, sun, 0); lightUniforms(mapleP)
        m.draw(mapleBuf, n, ((SystemClock.elapsedRealtime() - t0) / 1000.0).toFloat()) { nm -> loc(mapleP, nm) }
    }

    /** bushes, rocks and grass tufts (JS scatterInstanced + grass block) around the camera */
    private fun drawScatter() {
        val c = game.cam
        scatter?.draw(vp, env, sun, fog, c.pos[0].toFloat(), c.pos[1].toFloat(), c.pos[2].toFloat(), ((SystemClock.elapsedRealtime() - t0) / 1000.0).toFloat())
    }

    /** pier + yard + boats + coast rail before the water (opaque), shore foam after it (blended) */
    private fun drawHarbor(foamPass: Boolean) {
        val h = harbor ?: return; val c = game.cam; val t = ((SystemClock.elapsedRealtime() - t0) / 1000.0).toFloat()
        if (foamPass) h.drawFoam(vp, env, sun, fog, c.pos[0].toFloat(), c.pos[1].toFloat(), c.pos[2].toFloat(), t)
        else h.drawSolid(vp, env, sun, fog, c.pos[0].toFloat(), c.pos[1].toFloat(), c.pos[2].toFloat(), t)
    }

    private fun drawWater() {
        val c = game.cam
        GLES30.glDisable(GLES30.GL_CULL_FACE); GLES30.glEnable(GLES30.GL_BLEND)
        GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA); GLES30.glDepthMask(false)
        GLES30.glUseProgram(waterP)
        GLES30.glUniformMatrix4fv(loc(waterP, "uVP"), 1, false, vp, 0)
        GLES30.glUniform2f(loc(waterP, "uCenter"), c.pos[0].toFloat(), c.pos[2].toFloat())
        GLES30.glUniform1f(loc(waterP, "uY"), World.WATER_Y.toFloat())
        GLES30.glUniform3f(loc(waterP, "uCam"), c.pos[0].toFloat(), c.pos[1].toFloat(), c.pos[2].toFloat())
        GLES30.glUniform3fv(loc(waterP, "uFog"), 1, fog, 0)
        GLES30.glUniform3fv(loc(waterP, "uSun"), 1, sun, 0); lightUniforms(waterP); GLES30.glUniform3fv(loc(waterP, "uHor"), 1, env.hor, 0); GLES30.glUniform3fv(loc(waterP, "uMid"), 1, env.mid, 0); GLES30.glUniform3fv(loc(waterP, "uZen"), 1, env.zen, 0)
        GLES30.glUniform1f(loc(waterP, "uTime"), ((SystemClock.elapsedRealtime() - t0) / 1000.0).toFloat())
        if (seaTex == 0) seaData?.let { d ->
            val id = IntArray(1); GLES30.glGenTextures(1, id, 0); seaTex = id[0]; GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, seaTex)
            GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 1)
            GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_R8, 512, 512, 0, GLES30.GL_RED, GLES30.GL_UNSIGNED_BYTE, ByteBuffer.wrap(d))
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR); GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE); GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        }
        GLES30.glActiveTexture(GLES30.GL_TEXTURE4); GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, seaTex); GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glUniform1i(loc(waterP, "uDepth"), 4); GLES30.glUniform1f(loc(waterP, "uDepthOk"), if (seaTex != 0) 1f else 0f); GLES30.glUniform1f(loc(waterP, "uDay"), env.day)
        GLES30.glBindVertexArray(quadVao)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
        GLES30.glDepthMask(true); GLES30.glDisable(GLES30.GL_BLEND); GLES30.glEnable(GLES30.GL_CULL_FACE)
    }

    private fun box(cx: Float, cy: Float, cz: Float, sx: Float, sy: Float, sz: Float, rgb: FloatArray, gloss: Float,
                    pre: ((FloatArray) -> Unit)? = null) {
        System.arraycopy(base, 0, m, 0, 16)
        Matrix.translateM(m, 0, cx, cy, cz)
        pre?.invoke(m)
        Matrix.scaleM(m, 0, sx, sy, sz)
        GLES30.glUniformMatrix4fv(loc(meshP, "uM"), 1, false, m, 0)
        GLES30.glUniform3fv(loc(meshP, "uColor"), 1, rgb, 0)
        GLES30.glUniform1f(loc(meshP, "uGloss"), gloss)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 36)
    }

    /** Stand-in car built from boxes (local frame: +Z forward, +X left). Replaced by the R8 mesh in a later milestone. */
    private fun drawCar(s: CarState) {
        val p = game.pose; val cam = game.cam
        GLES30.glUseProgram(meshP)
        GLES30.glUniformMatrix4fv(loc(meshP, "uVP"), 1, false, vp, 0)
        GLES30.glUniform3fv(loc(meshP, "uSun"), 1, sun, 0); lightUniforms(meshP)
        GLES30.glUniform3f(loc(meshP, "uCam"), cam.pos[0].toFloat(), cam.pos[1].toFloat(), cam.pos[2].toFloat())
        GLES30.glUniform3fv(loc(meshP, "uFog"), 1, fog, 0)
        GLES30.glBindVertexArray(cubeVao)
        Matrix.setIdentityM(base, 0)
        Matrix.translateM(base, 0, p.x.toFloat(), p.y.toFloat(), p.z.toFloat())
        Matrix.rotateM(base, 0, Math.toDegrees(s.heading).toFloat(), 0f, 1f, 0f)
        Matrix.rotateM(base, 0, Math.toDegrees(game.pitch).toFloat(), 1f, 0f, 0f)
        Matrix.rotateM(base, 0, Math.toDegrees(game.roll).toFloat(), 0f, 0f, 1f)
        GLES30.glUniform1f(loc(meshP, "uAlpha"), 1f); GLES30.glUniform1f(loc(meshP, "uEmis"), 0f)
        GLES30.glUniform3fv(loc(meshP, "uHor"), 1, env.hor, 0); GLES30.glUniform3fv(loc(meshP, "uMid"), 1, env.mid, 0); GLES30.glUniform3fv(loc(meshP, "uZen"), 1, env.zen, 0)
        r8?.let {
            GLES30.glUniform1f(loc(meshP, "uEnvK"), 1f)
            it.draw(base, Math.toDegrees(s.steerAngle).toFloat(), Math.toDegrees(s.wheelSpin).toFloat(), s.brake.toFloat(), game.wheelDy, Mud.lvl, Mud.tdry) { n -> loc(meshP, n) }
            GLES30.glUniform1f(loc(meshP, "uEnvK"), 0f)
            return
        }
        val body = floatArrayOf(0.9f, 0.9f, 0.92f); val glass = floatArrayOf(0.08f, 0.1f, 0.14f); val tyre = floatArrayOf(0.05f, 0.05f, 0.05f)
        box(0f, 0.50f, 0f, 1.9f, 0.42f, 4.4f, body, 0.8f)
        box(0f, 0.86f, -0.2f, 1.6f, 0.36f, 2.0f, glass, 1.0f)
        box(0f, 0.30f, 0f, 1.95f, 0.18f, 4.5f, floatArrayOf(0.12f, 0.12f, 0.13f), 0.2f)
        val spin = Math.toDegrees(s.wheelSpin).toFloat()
        val steer = Math.toDegrees(s.steerAngle).toFloat()
        for ((wx, wz) in listOf(0.88f to 1.4f, -0.88f to 1.4f, 0.88f to -1.45f, -0.88f to -1.45f)) {
            val front = wz > 0
            box(wx, 0.40f, wz, 0.28f, 0.8f, 0.8f, tyre, 0.1f) { mm ->
                if (front) Matrix.rotateM(mm, 0, steer, 0f, 1f, 0f)
                Matrix.rotateM(mm, 0, spin, 1f, 0f, 0f)
            }
        }
    }

    private val locCache = HashMap<Long, Int>()
    private fun loc(p: Int, n: String): Int = locCache.getOrPut((p.toLong() shl 32) xor n.hashCode().toLong()) { GLES30.glGetUniformLocation(p, n) }

    private fun fb(a: FloatArray): FloatBuffer =
        ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(a).also { it.position(0) }

    private fun makeQuad(): Int {
        val vao = IntArray(1); GLES30.glGenVertexArrays(1, vao, 0); GLES30.glBindVertexArray(vao[0])
        val vb = IntArray(1); GLES30.glGenBuffers(1, vb, 0); GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vb[0])
        val d = fb(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, 32, d, GLES30.GL_STATIC_DRAW)
        GLES30.glEnableVertexAttribArray(0); GLES30.glVertexAttribPointer(0, 2, GLES30.GL_FLOAT, false, 8, 0)
        return vao[0]
    }

    private fun makeCube(): Int {
        // 6 faces * 2 tris, CCW from outside; position + normal
        val faces = arrayOf(
            floatArrayOf(1f, 0f, 0f), floatArrayOf(-1f, 0f, 0f), floatArrayOf(0f, 1f, 0f),
            floatArrayOf(0f, -1f, 0f), floatArrayOf(0f, 0f, 1f), floatArrayOf(0f, 0f, -1f))
        val out = ArrayList<Float>()
        for (n in faces) {
            val a = if (abs(n[0]) > 0.5f) floatArrayOf(0f, 1f, 0f) else if (abs(n[1]) > 0.5f) floatArrayOf(0f, 0f, 1f) else floatArrayOf(1f, 0f, 0f)
            // b = n x a
            val b = floatArrayOf(n[1] * a[2] - n[2] * a[1], n[2] * a[0] - n[0] * a[2], n[0] * a[1] - n[1] * a[0])
            fun v(sa: Float, sb: Float) = floatArrayOf(
                (n[0] + a[0] * sa + b[0] * sb) * 0.5f, (n[1] + a[1] * sa + b[1] * sb) * 0.5f, (n[2] + a[2] * sa + b[2] * sb) * 0.5f)
            val q = arrayOf(v(-1f, -1f), v(1f, -1f), v(1f, 1f), v(-1f, 1f))
            for (i in intArrayOf(0, 1, 2, 0, 2, 3)) { out.addAll(q[i].toList()); out.addAll(n.toList()) }
        }
        val vao = IntArray(1); GLES30.glGenVertexArrays(1, vao, 0); GLES30.glBindVertexArray(vao[0])
        val vb = IntArray(1); GLES30.glGenBuffers(1, vb, 0); GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vb[0])
        val data = fb(out.toFloatArray())
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, out.size * 4, data, GLES30.GL_STATIC_DRAW)
        GLES30.glEnableVertexAttribArray(0); GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 24, 0)
        GLES30.glEnableVertexAttribArray(1); GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 24, 12)
        return vao[0]
    }
}
