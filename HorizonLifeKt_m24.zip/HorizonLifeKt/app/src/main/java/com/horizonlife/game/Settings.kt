package com.horizonlife.game

import android.content.Context
import android.content.SharedPreferences

/** JS `settings` object (Settings panel): persisted in SharedPreferences, read by camera / sound / HUD / GL surface. */
object Settings {
    enum class CamMode(val label: String) { CHASE("Chase"), CLOSE("Close"), HOOD("Hood"), BUMPER("Bumper") }

    @Volatile var camMode = CamMode.CHASE
    @Volatile var camDist = 4.7          // m behind the car
    @Volatile var camPitch = 0.05        // rad: camera height
    @Volatile var fov = 69.0
    @Volatile var sky = 0.4              // look-up lift
    @Volatile var speedFov = 10.0
    @Volatile var shake = 0.3
    @Volatile var vol = 0.55
    @Volatile var resScale = 1.0         // GL surface scale (fixed size = native * resScale)
    @Volatile var hudScale = 1.0
    @Volatile var hudAlpha = 1.0
    @Volatile var ctrlWheel = false      // steering: on-screen buttons or drag-to-turn wheel (JS ctrlMode)
    @Volatile var steerSens = 1.8        // JS steerSens 0.6..3
    @Volatile var renderDist = 770.0     // ground streaming radius in metres (JS renderDist)
    @Volatile var treeMax = 40           // number of full-detail trees (JS treeLod)
    @Volatile var flocks = 7             // bird flocks 0..7 (JS QUAL.flocks)
    val hudShow = booleanArrayOf(true, true, false, true)   // minimap, speed, fps, buttons
    @Volatile var paused = false
    // ---- Optimization switches (JS OPT: every one starts OFF on every launch, never persisted) ----
    @Volatile var optTerrain = false        // JS: tiled terrain with frustum culling (native build always streams culled chunks -> no extra effect)
    @Volatile var optFrameCap = false       // cap at ~60 fps on 90/120 Hz screens
    @Volatile var optTreeThrottle = false   // re-pick the full-detail trees only every 0.25 s / when the camera moved
    @Volatile var optMapThrottle = false    // full-screen map redraws at ~30 fps
    @Volatile var optHiddenPause = false    // pause when the app goes to the background
    fun optSet(on: Boolean?) { optTerrain = on ?: false; optFrameCap = on ?: false; optTreeThrottle = on ?: false; optMapThrottle = on ?: false; optHiddenPause = on ?: false }
    // ---- HUD layout (JS settings.hudPos): item key -> offset in dp from its default place ----
    val hudPos = HashMap<String, FloatArray>()
    /** bumped whenever resScale changes so MainActivity re-applies the surface size */
    @Volatile var resVersion = 0

    private var prefs: SharedPreferences? = null
    private val HUD_KEYS = arrayOf("minimap", "speed", "fps", "buttons")

    fun load(ctx: Context) {
        val p = ctx.getSharedPreferences("horizon_settings", Context.MODE_PRIVATE); prefs = p
        camMode = CamMode.values().getOrNull(p.getInt("camMode", 0)) ?: CamMode.CHASE
        camDist = p.getFloat("camDist", 4.7f).toDouble().coerceIn(3.5, 14.0)
        camPitch = p.getFloat("camPitch", 0.05f).toDouble().coerceIn(0.05, 0.8)
        fov = p.getFloat("fov", 69f).toDouble().coerceIn(50.0, 85.0)
        sky = p.getFloat("sky", 0.4f).toDouble().coerceIn(0.0, 4.0)
        speedFov = p.getFloat("speedFov", 10f).toDouble().coerceIn(0.0, 20.0)
        shake = p.getFloat("shake", 0.3f).toDouble().coerceIn(0.0, 1.0)
        vol = p.getFloat("vol", 0.55f).toDouble().coerceIn(0.0, 1.0)
        resScale = p.getFloat("resScale", 1f).toDouble().coerceIn(0.3, 1.0)
        hudScale = p.getFloat("hudScale", 1f).toDouble().coerceIn(0.7, 1.3)
        hudAlpha = p.getFloat("hudAlpha", 1f).toDouble().coerceIn(0.3, 1.0)
        ctrlWheel = p.getBoolean("ctrlWheel", false); steerSens = p.getFloat("steerSens", 1.8f).toDouble().coerceIn(0.6, 3.0)
        renderDist = p.getFloat("renderDist", 770f).toDouble().coerceIn(380.0, 770.0); treeMax = p.getInt("treeMax", 40).coerceIn(10, 40); flocks = p.getInt("flocks", 7).coerceIn(0, 7)
        for (i in HUD_KEYS.indices) hudShow[i] = p.getBoolean("hud_" + HUD_KEYS[i], i != 2)
        hudPos.clear()
        for (it in (p.getString("hudPos", "") ?: "").split(';')) { val a = it.split(':'); if (a.size == 2) { val v = a[1].split(','); if (v.size == 2) hudPos[a[0]] = floatArrayOf(v[0].toFloatOrNull() ?: 0f, v[1].toFloatOrNull() ?: 0f) } }
        EngineSound.vol = vol; EngineSound.muted = p.getBoolean("muted", false)
    }

    fun save() {
        val p = prefs ?: return
        p.edit().putInt("camMode", camMode.ordinal).putFloat("camDist", camDist.toFloat()).putFloat("camPitch", camPitch.toFloat())
            .putFloat("fov", fov.toFloat()).putFloat("sky", sky.toFloat()).putFloat("speedFov", speedFov.toFloat())
            .putFloat("shake", shake.toFloat()).putFloat("vol", vol.toFloat()).putFloat("resScale", resScale.toFloat())
            .putBoolean("ctrlWheel", ctrlWheel).putFloat("steerSens", steerSens.toFloat()).putFloat("renderDist", renderDist.toFloat()).putInt("treeMax", treeMax).putInt("flocks", flocks)
            .putString("hudPos", hudPos.entries.joinToString(";") { "${it.key}:${it.value[0]},${it.value[1]}" }).putFloat("hudScale", hudScale.toFloat()).putFloat("hudAlpha", hudAlpha.toFloat()).putBoolean("muted", EngineSound.muted)
            .also { e -> for (i in HUD_KEYS.indices) e.putBoolean("hud_" + HUD_KEYS[i], hudShow[i]) }.apply()
    }

    fun hudReset() { hudPos.clear(); hudScale = 1.0; hudAlpha = 1.0; hudShow[0] = true; hudShow[1] = true; hudShow[2] = false; hudShow[3] = true; save() }
    fun camReset() { camDist = 4.7; camPitch = 0.05; fov = 69.0; sky = 0.4; speedFov = 10.0; shake = 0.3; save() }
}
