package com.horizonlife.gl

import android.content.Context
import android.opengl.GLES30
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** JS maple (MAPLE_B64): vertex-coloured bark + 3600 leaf quads, decoded offline into assets/maple.bin. Instanced: x, y, z, scale, rot. */
class MapleTrees(ctx: Context) {
    private class Prim(val vao: Int, val nIdx: Int, val leaf: Boolean)
    private val prims = ArrayList<Prim>()
    private var inst = 0
    private val fbuf = ByteBuffer.allocateDirect(MAX * 5 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()

    companion object { const val MAX = 40 }

    init {
        val ids = IntArray(1); GLES30.glGenBuffers(1, ids, 0); inst = ids[0]
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, inst); GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, MAX * 5 * 4, null, GLES30.GL_DYNAMIC_DRAW)
        val raw = ctx.assets.open("maple.bin").use { it.readBytes() }
        val bb = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN)
        val nb = bb.getInt(0); val nbi = bb.getInt(4); val nl = bb.getInt(8); val nli = bb.getInt(12)
        var o = 16
        fun floats(n: Int): FloatArray { val a = FloatArray(n) { bb.getFloat(o + it * 4) }; o += n * 4; return a }
        fun shorts(n: Int): ShortArray { val a = ShortArray(n) { bb.getShort(o + it * 2) }; o += n * 2; return a }
        val bp = floats(nb * 3); val bn = floats(nb * 3); val bc = floats(nb * 3); val bi = shorts(nbi)
        val lp = floats(nl * 3); val ln = floats(nl * 3); val lc = floats(nl * 3); val li = shorts(nli)
        prims.add(make(nb, bp, bn, bc, bi, false)); prims.add(make(nl, lp, ln, lc, li, true))
        GLES30.glBindVertexArray(0)
    }

    private fun make(nv: Int, p: FloatArray, n: FloatArray, c: FloatArray, idx: ShortArray, leaf: Boolean): Prim {
        val vert = FloatArray(nv * 9)
        for (i in 0 until nv) for (a in 0..2) { vert[i * 9 + a] = p[i * 3 + a]; vert[i * 9 + 3 + a] = n[i * 3 + a]; vert[i * 9 + 6 + a] = c[i * 3 + a] }
        val id = IntArray(1)
        GLES30.glGenVertexArrays(1, id, 0); val vao = id[0]; GLES30.glBindVertexArray(vao)
        GLES30.glGenBuffers(1, id, 0); GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, id[0])
        val fb = ByteBuffer.allocateDirect(vert.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(vert).also { it.position(0) }
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, vert.size * 4, fb, GLES30.GL_STATIC_DRAW)
        for (a in 0..2) { GLES30.glEnableVertexAttribArray(a); GLES30.glVertexAttribPointer(a, 3, GLES30.GL_FLOAT, false, 36, a * 12) }
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, inst)
        GLES30.glEnableVertexAttribArray(3); GLES30.glVertexAttribPointer(3, 4, GLES30.GL_FLOAT, false, 20, 0); GLES30.glVertexAttribDivisor(3, 1)
        GLES30.glEnableVertexAttribArray(4); GLES30.glVertexAttribPointer(4, 1, GLES30.GL_FLOAT, false, 20, 16); GLES30.glVertexAttribDivisor(4, 1)
        GLES30.glGenBuffers(1, id, 0); GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, id[0])
        val sb = ByteBuffer.allocateDirect(idx.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer().put(idx).also { it.position(0) }
        GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, idx.size * 2, sb, GLES30.GL_STATIC_DRAW)
        GLES30.glBindVertexArray(0)
        return Prim(vao, idx.size, leaf)
    }

    /** @param a x,y,z,scale,rot of n maples (nearest first) */
    fun draw(a: FloatArray, n: Int, time: Float, loc: (String) -> Int) {
        if (n <= 0) return
        fbuf.clear(); fbuf.put(a, 0, n * 5); fbuf.position(0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, inst); GLES30.glBufferSubData(GLES30.GL_ARRAY_BUFFER, 0, n * 20, fbuf)
        GLES30.glDisable(GLES30.GL_CULL_FACE); GLES30.glUniform1f(loc("uTime"), time)
        for (p in prims) {
            GLES30.glUniform1f(loc("uLeaf"), if (p.leaf) 1f else 0f)
            GLES30.glBindVertexArray(p.vao)
            GLES30.glDrawElementsInstanced(GLES30.GL_TRIANGLES, p.nIdx, GLES30.GL_UNSIGNED_SHORT, 0, n)
        }
        GLES30.glBindVertexArray(0); GLES30.glEnable(GLES30.GL_CULL_FACE)
    }
}
