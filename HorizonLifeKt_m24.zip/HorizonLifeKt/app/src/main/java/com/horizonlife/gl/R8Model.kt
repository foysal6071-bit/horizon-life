package com.horizonlife.gl

import android.content.Context
import android.opengl.GLES30
import android.opengl.Matrix
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.*

/**
 * Audi R8 (46k verts / 51k tris) decoded from the JS blobs (assets/r8.bin + r8_meta.json).
 * Bin layout: n*3 uint16 positions, n*4 int8 normals, ni uint16 indices.  Game frame: nose +Z, left +X, up +Y,
 * axle mid-point at the origin, tyres touching y = 0.   Neon underglow is skipped (the JS version removed it too).
 */
class R8Model(ctx: Context) {
    private class Mat(val color: FloatArray, val gloss: Float, val alpha: Float, val emis: Float)
    private class Part(val start: Int, val count: Int, val mat: Mat, val wheel: Int, val spinning: Boolean, val kind: Int)   // kind: 0 none, 1 tyre, 2 rim, 3 body

    private val parts = ArrayList<Part>()
    private val centre = Array(4) { FloatArray(3) }       // wheel centres, game order: front L/R, rear L/R
    private val rawOrder = intArrayOf(0, 2, 1, 3)           // game wheel k -> raw wheel index
    private var vao = 0
    private val tailMats = ArrayList<Mat>()

    // ---- 3D mud lumps stuck in the tread (JS TYRE_MUD.lumps): 34 per wheel, more of them show as the tyre gets muddier ----
    private val NL = 34
    private val lumpM = Array(4) { FloatArray(NL * 16) }
    private val lumpC = Array(4) { FloatArray(NL * 3) }
    private var lumpVao = 0; private var lumpN = 0

    companion object {
        const val WH0 = 54432; const val WHN = 24570; const val NEON0 = 152712
        private const val S = 2.8 / 2643.1; private const val ZC = -104.45
        private fun hex(h: String, k: Int) = (h.substring(1 + k * 2, 3 + k * 2).toInt(16) / 255f)
    }

    init {
        val bin = ctx.assets.open("r8.bin").use { it.readBytes() }
        val meta = JSONObject(ctx.assets.open("r8_meta.json").use { String(it.readBytes()) })
        val n = meta.getInt("n"); val ni = meta.getInt("ni")
        val mn = meta.getJSONArray("mn"); val sz = meta.getJSONArray("sz")
        val bb = ByteBuffer.wrap(bin).order(ByteOrder.LITTLE_ENDIAN)
        val vert = FloatArray(n * 6)
        for (i in 0 until n) {
            val u = bb.getShort(i * 6).toInt() and 0xffff; val v = bb.getShort(i * 6 + 2).toInt() and 0xffff; val w = bb.getShort(i * 6 + 4).toInt() and 0xffff
            val rx = mn.getDouble(0) + u / 65535.0 * sz.getDouble(0); val ry = mn.getDouble(1) + v / 65535.0 * sz.getDouble(1)
            val rz = mn.getDouble(2) + w / 65535.0 * sz.getDouble(2)
            vert[i * 6] = (rx * S).toFloat(); vert[i * 6 + 1] = (ry * S).toFloat(); vert[i * 6 + 2] = ((rz - ZC) * S).toFloat()
            val nx = bin[n * 6 + i * 4] / 127f; val ny = bin[n * 6 + i * 4 + 1] / 127f; val nz = bin[n * 6 + i * 4 + 2] / 127f
            val l = sqrt(nx * nx + ny * ny + nz * nz).let { if (it == 0f) 1f else it }
            vert[i * 6 + 3] = nx / l; vert[i * 6 + 4] = ny / l; vert[i * 6 + 5] = nz / l
        }
        val idx = ShortArray(ni) { bb.getShort(n * 10 + it * 2) }
        // wheel centres from the bounding boxes of each raw wheel's index range
        for (k in 0..3) {
            val wi = rawOrder[k]; val lo = FloatArray(3) { 1e9f }; val hi = FloatArray(3) { -1e9f }
            for (q in WH0 + wi * WHN until WH0 + (wi + 1) * WHN) {
                val v = idx[q].toInt() and 0xffff
                for (a in 0..2) { lo[a] = min(lo[a], vert[v * 6 + a]); hi[a] = max(hi[a], vert[v * 6 + a]) }
            }
            for (a in 0..2) centre[k][a] = (lo[a] + hi[a]) / 2
        }
        // groups -> parts
        val groups = meta.getJSONArray("groups"); val cache = HashMap<String, Mat>()
        for (gi in 0 until groups.length()) {
            val g = groups.getJSONArray(gi)
            val name = g.getString(0); val start = g.getInt(2); val count = g.getInt(3); val col = g.getString(4)
            val em = g.getInt(6); val a = g.getDouble(7).toFloat()
            if (count == 0 || em == 2 || start >= NEON0) continue
            var wheel = -1; var spinning = false
            if (start >= WH0) {
                val wi = (start - WH0) / WHN; val off = start - WH0 - wi * WHN
                wheel = rawOrder.indexOf(wi); spinning = !(off in 666 until 1944)
            }
            val key = "$name|$col|$em|$a"
            val mat = cache.getOrPut(key) {
                var c = floatArrayOf(hex(col, 0), hex(col, 1), hex(col, 2)); var gloss = 0.3f; var alpha = 1f; var emis = 0f
                if (em == 1) { emis = 1f; c = if (name == "light") floatArrayOf(0.95f, 0.98f, 1f) else floatArrayOf(1f, 0.16f, 0.16f) }
                else if (a < 1) { alpha = min(0.9f, a * 1.5f); gloss = 1f }
                else gloss = when (name) {
                    "body_color" -> 0.9f; "black_gloss", "trim" -> 0.7f; "chrome", "rims_1" -> 1f
                    "Aluminium_1", "Aluminum_2" -> 0.6f; "tyre" -> 0.03f; "interior_1", "interior_2", "interior_roof" -> 0.08f
                    "black_matt", "tail_light_red_2", "tail_light_red_3", "grille" -> 0.35f; else -> 0.3f
                }
                Mat(c, gloss, alpha, emis).also { if (em == 1 && name != "light") tailMats.add(it) }
            }
            val kind = when {
                wheel >= 0 -> if (name == "tyre") 1 else if (name.startsWith("rims") || name.startsWith("Alum") || name == "chrome") 2 else 0
                mat.alpha < 1f || mat.emis > 0f -> 0
                name == "body_color" || name == "black_gloss" || name == "trim" || name.startsWith("Alum") -> 3
                else -> 0
            }
            parts.add(Part(start, count, mat, wheel, spinning, kind))
        }
        parts.sortBy { it.mat.alpha < 1f }      // opaque first, glass last

        val ids = IntArray(1)
        GLES30.glGenVertexArrays(1, ids, 0); vao = ids[0]; GLES30.glBindVertexArray(vao)
        val vb = IntArray(1); GLES30.glGenBuffers(1, vb, 0); GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vb[0])
        val fb = ByteBuffer.allocateDirect(vert.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(vert).also { it.position(0) }
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, vert.size * 4, fb, GLES30.GL_STATIC_DRAW)
        GLES30.glEnableVertexAttribArray(0); GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 24, 0)
        GLES30.glEnableVertexAttribArray(1); GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 24, 12)
        val eb = IntArray(1); GLES30.glGenBuffers(1, eb, 0); GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, eb[0])
        val sb = ByteBuffer.allocateDirect(ni * 2).order(ByteOrder.nativeOrder()).asShortBuffer().put(idx).also { it.position(0) }
        GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, ni * 2, sb, GLES30.GL_STATIC_DRAW)
        GLES30.glBindVertexArray(0)
        buildLumps()
    }

    private fun buildLumps() {
        // icosphere (1 subdivision = 80 faces) with the JS per-position bump so the lump stays closed
        val t = (1.0 + sqrt(5.0)) / 2
        var v = arrayListOf(floatArrayOf(-1f, t.toFloat(), 0f), floatArrayOf(1f, t.toFloat(), 0f), floatArrayOf(-1f, -t.toFloat(), 0f), floatArrayOf(1f, -t.toFloat(), 0f),
            floatArrayOf(0f, -1f, t.toFloat()), floatArrayOf(0f, 1f, t.toFloat()), floatArrayOf(0f, -1f, -t.toFloat()), floatArrayOf(0f, 1f, -t.toFloat()),
            floatArrayOf(t.toFloat(), 0f, -1f), floatArrayOf(t.toFloat(), 0f, 1f), floatArrayOf(-t.toFloat(), 0f, -1f), floatArrayOf(-t.toFloat(), 0f, 1f))
        val f0 = intArrayOf(0,11,5, 0,5,1, 0,1,7, 0,7,10, 0,10,11, 1,5,9, 5,11,4, 11,10,2, 10,7,6, 7,1,8, 3,9,4, 3,4,2, 3,2,6, 3,6,8, 3,8,9, 4,9,5, 2,4,11, 6,2,10, 8,6,7, 9,8,1)
        val tris = ArrayList<FloatArray>()
        fun nrm(a: FloatArray): FloatArray { val l = sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]); return floatArrayOf(a[0] / l, a[1] / l, a[2] / l) }
        fun mid(a: FloatArray, b: FloatArray) = nrm(floatArrayOf((a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2))
        for (i in 0 until 20) {
            val a = nrm(v[f0[i * 3]]); val b = nrm(v[f0[i * 3 + 1]]); val c = nrm(v[f0[i * 3 + 2]])
            val ab = mid(a, b); val bc = mid(b, c); val ca = mid(c, a)
            for (tr in arrayOf(arrayOf(a, ab, ca), arrayOf(b, bc, ab), arrayOf(c, ca, bc), arrayOf(ab, bc, ca))) tris.add(floatArrayOf(*tr[0], *tr[1], *tr[2]))
        }
        val data = FloatArray(tris.size * 3 * 6)
        for ((ti, tr) in tris.withIndex()) {
            val p = Array(3) { k ->
                val x = tr[k * 3]; val y = tr[k * 3 + 1]; val z = tr[k * 3 + 2]
                val h = sin(x * 12.9898 + y * 78.233 + z * 37.719) * 43758.5453; val kk = (0.78 + 0.34 * (h - floor(h))).toFloat()
                floatArrayOf(x * kk, y * kk, z * kk)
            }
            val e1 = floatArrayOf(p[1][0] - p[0][0], p[1][1] - p[0][1], p[1][2] - p[0][2]); val e2 = floatArrayOf(p[2][0] - p[0][0], p[2][1] - p[0][1], p[2][2] - p[0][2])
            val fn = nrm(floatArrayOf(e1[1] * e2[2] - e1[2] * e2[1], e1[2] * e2[0] - e1[0] * e2[2], e1[0] * e2[1] - e1[1] * e2[0]))
            val cen = floatArrayOf(p[0][0] + p[1][0] + p[2][0], p[0][1] + p[1][1] + p[2][1], p[0][2] + p[1][2] + p[2][2])
            val sgn = if (fn[0] * cen[0] + fn[1] * cen[1] + fn[2] * cen[2] < 0) -1f else 1f      // outward facing
            for (k in 0..2) { val o = (ti * 3 + k) * 6; for (a in 0..2) { data[o + a] = p[k][a]; data[o + 3 + a] = fn[a] * sgn } }
        }
        lumpN = tris.size * 3
        val id = IntArray(1); GLES30.glGenVertexArrays(1, id, 0); lumpVao = id[0]; GLES30.glBindVertexArray(lumpVao)
        GLES30.glGenBuffers(1, id, 0); GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, id[0])
        val fb = ByteBuffer.allocateDirect(data.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(data).also { it.position(0) }
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, data.size * 4, fb, GLES30.GL_STATIC_DRAW)
        GLES30.glEnableVertexAttribArray(0); GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 24, 0)
        GLES30.glEnableVertexAttribArray(1); GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 24, 12)
        GLES30.glBindVertexArray(0)
        // lump placement = JS (LCG seed i*977+13); JS wheel frame (x,y = disc, z = axle) -> game frame (Z, Y = disc, X = axle)
        for (w in 0..3) {
            var sd = (w * 977L + 13L); fun R(): Double { sd = (sd * 16807L) % 2147483647L; return sd / 2147483647.0 }
            val side = if (centre[w][0] >= 0f) 1.0 else -1.0
            val m = FloatArray(16)
            for (k in 0 until NL) {
                val th = R() * PI * 2; val onTread = R() < 0.62
                val r = if (onTread) 0.326 + R() * 0.004 else 0.285 + R() * 0.035
                val zz = if (onTread) (R() - 0.5) * 0.17 else side * (0.105 + R() * 0.02)
                val sz = if (onTread) 0.014 + R() * R() * 0.022 else 0.009 + R() * 0.014
                Matrix.setIdentityM(m, 0)
                Matrix.translateM(m, 0, zz.toFloat(), (r * sin(th)).toFloat(), (r * cos(th)).toFloat())
                Matrix.rotateM(m, 0, Math.toDegrees(R() * 6.28).toFloat(), 1f, 0f, 0f); Matrix.rotateM(m, 0, Math.toDegrees(R() * 6.28).toFloat(), 0f, 1f, 0f); Matrix.rotateM(m, 0, Math.toDegrees(R() * 6.28).toFloat(), 0f, 0f, 1f)
                Matrix.scaleM(m, 0, (sz * (1 + R() * 0.7)).toFloat(), (sz * (0.55 + R() * 0.4)).toFloat(), (sz * (1 + R() * 0.7)).toFloat())
                System.arraycopy(m, 0, lumpM[w], k * 16, 16)
                val c = (0.75 + 0.5 * R()).toFloat(); lumpC[w][k * 3] = c; lumpC[w][k * 3 + 1] = c * 0.97f; lumpC[w][k * 3 + 2] = c * 0.93f
            }
        }
    }

    /** lumps of mud in the tread of wheel w (visible count grows with the mud level) */
    private fun drawLumps(base: FloatArray, w: Int, steerDeg: Float, spinDeg: Float, dy: Float, lvl: Double, dry: Double, loc: (String) -> Int) {
        val cnt = min(NL, floor(NL * max(0.0, (lvl - 0.35) / 0.65)).toInt()); if (cnt <= 0) return
        val c = centre[w]; val wm = FloatArray(16); val lm = FloatArray(16)
        System.arraycopy(base, 0, wm, 0, 16)
        Matrix.translateM(wm, 0, 0f, dy, 0f); Matrix.translateM(wm, 0, c[0], c[1], c[2])
        if (w < 2) Matrix.rotateM(wm, 0, steerDeg, 0f, 1f, 0f)
        Matrix.rotateM(wm, 0, spinDeg, 1f, 0f, 0f)
        val d = dry.toFloat(); val rr = 0.040f + 0.16f * d; val gg = 0.026f + 0.109f * d; val bb = 0.016f + 0.064f * d
        GLES30.glUniform1f(loc("uMudMode"), 0f); GLES30.glUniform1f(loc("uGloss"), 0.12f); GLES30.glUniform1f(loc("uAlpha"), 1f); GLES30.glUniform1f(loc("uEmis"), 0f)
        GLES30.glBindVertexArray(lumpVao)
        for (k in 0 until cnt) {
            Matrix.multiplyMM(lm, 0, wm, 0, lumpM[w], k * 16)
            GLES30.glUniformMatrix4fv(loc("uM"), 1, false, lm, 0)
            GLES30.glUniform3f(loc("uColor"), rr * lumpC[w][k * 3], gg * lumpC[w][k * 3 + 1], bb * lumpC[w][k * 3 + 2])
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, lumpN)
        }
    }

    /**
     * @param base car rig matrix (position + heading + roll/pitch). Program must already be in use with uVP/uSun/uCam/uFog set.
     * @param loc uniform-location lookup for the mesh program.
     */
    fun draw(base: FloatArray, steerDeg: Float, spinDeg: Float, brake: Float, wheelDy: FloatArray, mudLvl: DoubleArray, mudDry: DoubleArray, loc: (String) -> Int) {
        val m = FloatArray(16); GLES30.glBindVertexArray(vao); GLES30.glDisable(GLES30.GL_CULL_FACE)
        var glass = false
        for (p in parts) {
            if (p.mat.alpha < 1f && !glass) { glass = true; GLES30.glEnable(GLES30.GL_BLEND); GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA); GLES30.glDepthMask(false) }
            System.arraycopy(base, 0, m, 0, 16)
            if (p.wheel >= 0) {
                val c = centre[p.wheel]
                Matrix.translateM(m, 0, 0f, wheelDy[p.wheel], 0f)          // pothole travel
                Matrix.translateM(m, 0, c[0], c[1], c[2])
                if (p.wheel < 2) Matrix.rotateM(m, 0, steerDeg, 0f, 1f, 0f)
                if (p.spinning) Matrix.rotateM(m, 0, spinDeg, 1f, 0f, 0f)
                Matrix.translateM(m, 0, -c[0], -c[1], -c[2])
            }
            GLES30.glUniformMatrix4fv(loc("uM"), 1, false, m, 0)
            GLES30.glUniform3fv(loc("uColor"), 1, p.mat.color, 0); GLES30.glUniform1f(loc("uGloss"), p.mat.gloss)
            if (p.kind == 1 || p.kind == 2) {             // mud layer stuck to the wheel (JS TYRE_MUD, procedural shader)
                val c = centre[p.wheel]; val w = p.wheel
                GLES30.glUniform1f(loc("uMudMode"), 1f); GLES30.glUniform3f(loc("uMudC"), c[0], c[1], c[2])
                GLES30.glUniform1f(loc("uMud"), mudLvl[w].toFloat()); GLES30.glUniform1f(loc("uMudDry"), mudDry[w].toFloat())
                GLES30.glUniform1f(loc("uMudSeed"), w * 13.7f + 1.3f); GLES30.glUniform1f(loc("uMudSide"), if (c[0] >= 0f) 1f else -1f)
                GLES30.glUniform1f(loc("uMudPart"), if (p.kind == 1) 0f else 1f)
            } else if (p.kind == 3) {                      // splashed body
                GLES30.glUniform1f(loc("uMudMode"), 2f); GLES30.glUniform3f(loc("uMudC"), 0f, 0f, 0f)
                GLES30.glUniform1f(loc("uMud"), max(0.05, mudLvl.sum() / 4 * 0.55).toFloat()); GLES30.glUniform1f(loc("uMudDry"), (mudDry.sum() / 4).toFloat())
                GLES30.glUniform1f(loc("uMudSeed"), 3.7f); GLES30.glUniform1f(loc("uMudSide"), 1f); GLES30.glUniform1f(loc("uMudPart"), 0f)
            } else GLES30.glUniform1f(loc("uMudMode"), 0f)
            GLES30.glUniform1f(loc("uAlpha"), p.mat.alpha)
            GLES30.glUniform1f(loc("uEmis"), if (p.mat.emis > 0f && p.mat in tailMats) 0.55f + 0.45f * brake else p.mat.emis)
            GLES30.glDrawElements(GLES30.GL_TRIANGLES, p.count, GLES30.GL_UNSIGNED_SHORT, p.start * 2)
        }
        if (glass) { GLES30.glDepthMask(true); GLES30.glDisable(GLES30.GL_BLEND) }
        for (w in 0..3) if (mudLvl[w] > 0.35) drawLumps(base, w, steerDeg, spinDeg, wheelDy[w], mudLvl[w], mudDry[w], loc)
        GLES30.glUniform1f(loc("uMudMode"), 0f)
        GLES30.glEnable(GLES30.GL_CULL_FACE); GLES30.glBindVertexArray(0)
    }
}
