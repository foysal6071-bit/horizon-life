# R8 shrinks/optimises all app code; the manifest keeps MainActivity automatically (no reflection or JNI is used).
-dontwarn **
