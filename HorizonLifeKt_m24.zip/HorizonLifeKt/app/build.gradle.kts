plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.horizonlife"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.horizonlife.game"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "0.1-kotlin-port"
    }
    signingConfigs {
        create("release") {
            storeFile = file("horizon-release.jks")
            storePassword = "horizon123"; keyAlias = "horizon"; keyPassword = "horizon123"
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            isDebuggable = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
