# Horizon Life — Native Kotlin port (Milestones 1–18 ≈ 99% of the live JS features)

Android Studio project: Kotlin + OpenGL ES 3.0 (no WebView, no Three.js).
Open the folder in Android Studio (Koala+), run on a device (minSdk 24, landscape).
Android Studio will generate the Gradle wrapper jar on first sync.

## Done in this milestone
| JS (game_6_realistic_mud_tracks.html) | Kotlin |
|---|---|
| `Veh` vehicle physics (bicycle model, gearbox, ABS/TCS, handbrake drift) | `game/VehiclePhysics.kt` (1:1 port) |
| `carState`, `_surf`, input flags | `game/CarState.kt` |
| `surfaceAt` (grip / rolling resistance blend) | `game/World.kt` (road + grass only for now) |
| chase camera, drag-orbit, pinch zoom, speed FOV | `game/CameraRig.kt` |
| animate() step, smoothed dt, body roll/pitch, resetCar | `game/Game.kt` |
| touch buttons (L/R/Gas/Brake/Handbrake), speed+gear HUD | `ui/ControlsView.kt` |
| sky gradient + sun, ground + road shader, fog, stand-in box car | `gl/*` |

## Milestone 2 (added)
| JS | Kotlin |
|---|---|
| `groundH`, `coastDist`, `riverSd` (Catmull-Rom river + grid), `fieldNoise/fieldMask/fieldH` | `game/World.kt` (fixed hill seed) |
| ground vertex colours (grass/sand/mud/river bed/sea floor) | `gl/Terrain.kt` |
| 2000 m ground mesh | 128 m chunks streamed around the camera on 2 worker threads, 2 uploads/frame |
| ocean/river water | simple animated water plane at y=-1.3 (`WATER_FS`), full Ocean/Phillips shader later |
| `carGroundH`, 4-wheel ride height / slope / roll | `game/Game.kt` |

Placeholder: the ring road (R=220 m) is a flat "bridge" over the river; no dirt track / house pads / pier yet.

## Milestone 3 (added): Audi R8 model
`gl/R8Model.kt` decodes `assets/r8.bin` + `r8_meta.json` (extracted from `R8_B64` / `R8_META`): 46k verts, per-group colours/gloss,
glass pass, brake-light glow, 4 wheels that spin + steer. Falls back to the box car if loading fails (see Logcat tag `R8`).
Simplified vs JS: no env-map reflections / clearcoat (plain Blinn-Phong), no neon, no mud overlay.

## Milestone 4 (added): trees
`gl/Trees.kt` + `assets/tree_*.{bin,png,jpg}`: the supplied tree decoded offline from `TREE_B64` (node script logic = `parseTreeMini`),
instanced with leaf alpha-test, wind sway, bark texture. Placement: deterministic scatter per terrain chunk (`Terrain.plantTrees`).
Limitation: one tree is ~40k triangles, so only the nearest 40 trees within 220 m are drawn. TODO: far impostor billboards (JS tree LOD),
maple variant (`MAPLE_B64`), bushes/rocks/flowers, fences.

## Milestone 5 (added): road network + day/night
- `game/Roads.kt`: `ringRad` winding rings (R=220/420), river-angle picker, radial connector, Catmull-Rom sampling, `roadClearance` / `fieldClear` grid (24 m cells). Start line = first point of the inner ring.
- `gl/RoadMesh.kt` + `ROAD_FS`: one static mesh, muddy dirt roadway with wheel ruts, verges that fade into the grass (procedural, simplified from `makeDirtRoadMaps`).
- `game/Environment.kt`: port of `updateEnv` (sun/moon path, sky gradient, twilight, fog colour, light colours). Clock is frozen at 13:00 like the JS; the ☀/☾ button (top right) runs the cycle at 20x. Sky shader got moon + stars.
- All shaders now use env light colours (`uSunCol`, `uAmbCol`).
Still missing: bridges (roads are a flat deck over the river), headlights / night lamps, rain, clouds, sun glare, birds.

## Next milestones (rough share of the whole port)
1. ~~Terrain~~ done (dirt track `trackQ` still missing)
2. ~~Road network~~ done (bridges, puddles, potholes, roadside fence still open)
3. ~~Audi R8 mesh~~ done
4. ~~Tree~~ done; bushes / rocks / fences / houses / maple / tree LOD still open
5. ~~Day/night~~ done; rain, clouds, sky dome textures (`SKY_FACES`, `MTN_COL`), ocean waves open
6. Mud: tyre mud, spray particles, tyre marks, puddles                                   (~10%)
7. Collision, walker mode, audio (engine loops), minimap, settings UI                    (~20%)

Not compiled here (no Android SDK in the sandbox) — expect to fix small compile errors on first build.

## Milestone 6 (added): bridges + river walls
| JS | Kotlin |
|---|---|
| `buildBridges`, `bridgeArch`, `bridges[]` | `game/Bridges.kt` + `gl/BridgeMesh.kt` (+ `Road.at(s)` in Roads.kt) |
| `bridgeLift`, bridge slope -> car height/pitch | `Bridges.lift`, `Game.update` |
| `riverCollide` (rail walls, bank wall) | `Bridges.riverCollide` |
| `carGroundH` (field only, no river bed) | `World.fieldH` in Game; fake road deck removed from `groundH` |
Road mesh is skipped under bridge spans. Wood is procedural (shader `BRIDGE_FS`).

## Milestone 7 (added): lamps, collision, night light
| JS | Kotlin |
|---|---|
| `lampPos`, `lampBlocked`, `lampCollide`, `lampTilt` | `game/Lamps.kt` |
| `bounceOff`, `hitCooldown`, `checkCollisions` (edge wall) | `game/Collision.kt` |
| poles / arms / lantern meshes | `GameRenderer.drawLamps` (box primitives) |
| light `pools`, `halos`, headlight pool `hlM` | `GameRenderer.drawGlow` + `GLOW_VS/FS` (additive, night only) |

## Milestone 8 (added): engine sound
JS `sfx` (R8 V10 recording, `R8_SND`) -> `game/EngineSound.kt`: software mixer thread + AudioTrack (22050 Hz mono), loops in `assets/engine_idle.pcm` / `engine_main.pcm`.

## Milestone 9 (added): fence, minimap, mute
| JS | Kotlin |
|---|---|
| roadside fence block (`FENCE`, `fencePosts`, `breakPost`) | `game/Fence.kt` + `GameRenderer.drawFence` (simplified look: box posts + rope boxes, no bark texture / rope drop physics) |
| `mmBase` + `drawMinimap` (rotating, forward = up) | `ui/Minimap.kt` + `ControlsView.drawMinimap` |
| `sfx.toggle` | mute button in `ControlsView` -> `EngineSound.muted` |

## Milestone 10 (added): potholes, tree collision, coast wall, clouds
| JS | Kotlin |
|---|---|
| `POTH`, `pothAt`, wheel spring `wy/wv` + body nod | `game/Potholes.kt`, `Game.potholes`, `R8Model.draw(wheelDy)`, `POTH_VS/FS` + `GameRenderer.drawPotholes` |
| `collideWith(roadObstacles)` (tree trunks, r = 0.6*scale) | `game/Obstacles.kt` + `game/TreeField.kt` (shared placement) |
| `coastGuard` (wall at coastR-52, no pier yet) | `Obstacles.coastGuard` |
| sky clouds (`fbm` deck, `uCl/uCs`) | `SKY_FS` + `Environment.cloudLit/cloudShade` |
Not ported on purpose: puddles (disabled in JS: `n = 0`) and rain / thunder (`wthr.target = 0`, JS never rains).
Also fixed: missing `;` in `Terrain.plantTrees` that would have failed compilation.

## Milestone 11 (added): mud
| JS | Kotlin |
|---|---|
| `mudAt`, `updateTyreMud` | `game/Mud.kt` (`Mud.at`, `lvl/tdry`), tyres + rims tinted in `R8Model.draw` |
| `updateMud` clumps / mist / splats (`mudPts`, `mistPts`, `splMesh`) | `game/Mud.kt` + `gl/MudRenderer.drawParticles` (point sprites, lumpy blobs stretched along motion) |
| `updateMarks`, `addMarkQuad` (tread / locked-wheel smear / rubber) | `game/Marks.kt` + `MudRenderer.drawMarks` (procedural shader) |

## Milestone 12 (added): dirt track, bushes / rocks / grass, tyre smoke
| JS | Kotlin |
|---|---|
| `buildTrack`, `trackQ`, `trackDist`, fieldH grading, surfaceAt dirt, mudAt track | `game/Track.kt` + hooks in `World`, `Mud`, `TreeField` |
| dirt strip ribbons (rows follow the real ground triangles) | `gl/TrackMesh.kt` (ROAD shader) |
| bare earth beside the track, minimap line | `Terrain.color`, `ui/Minimap.kt` |
| `scatterInstanced` bushes / rocks, 1000 grass tufts | `game/Scatter.kt` + `gl/ScatterRenderer.kt` (`SCAT_VS/FS`) |
| `updateSmoke` | `game/Smoke.kt` + `MudRenderer` (`SMOKE_VS/FS`) |
Simplified: track hill phases are fixed; grass blades are procedural (no canvas texture); bush/rock shading is plain Lambert-style (no shadows).

## Milestone 13 (added): river-bank life + shore rocks
| JS | Kotlin |
|---|---|
| `buildRiverBank` boulders + pebbles, reed clumps | `Scatter.riverBank` + `ScatterRenderer` (`bank`, `reeds`) |
| island block shore rocks (160 dodecahedra) | `Scatter.chunk` (merged into `rock`) |

## Milestone 14 (added): harbor pier, yard, boats, coast rail, shore foam
| JS | Kotlin |
|---|---|
| `PIER` placement (`find`), `pierLocal`, `nearPier`, pier part of `coastGuard`, yard `roadObstacles` | `game/Harbor.kt` (+ `Obstacles`, `World.fieldMask` flat ground, nearPier exclusions in TreeField / Scatter / Fence / Potholes) |
| pier deck + piles + rails, gantry sign, concrete yard, warehouse, containers | `gl/HarborRenderer.kt` (one merged mesh, `HARBOR_VS/FS`) |
| `makeBoat` x7 + bobbing in `islandObj.update` | `HarborRenderer` (per-boat mesh + model matrix) |
| wooden coast rail (posts + 2 rails), shore foam band | `HarborRenderer` ring mesh / blended foam pass |
| minimap harbor | `ui/Minimap.kt` |
Not compiled here (no Android SDK) — braces/parens checked only.

## Milestone 15 (added): photo sky, mountains, moon, ocean waves, full map
| JS | Kotlin |
|---|---|
| `SKY_FACES` cubemap atlas, `skyTex`, `uCubeTint` | `assets/sky_atlas.jpg`, `SKY_FS`, `Environment.cubeTint` |
| `MTN_COL` / `MTN_DATA` baked mountain ring | `assets/mtn_col.jpg`, `mtn_data.png`, `SKY_FS` |
| moon disc, Milky Way, star layers | `SKY_FS` (`Environment.skySun` = true sun) |
| `patchSea` (waves, depth map, shore foam, river tint) | `WATER_FS` + depth texture in `GameRenderer.drawWater` |
| `showToast`, full-screen map | `Game.showToast`, `ControlsView.drawFullMap` |
Not compiled here (no Android SDK).

## Milestone 16 (added): settings window, camera modes, pause
| JS | Kotlin |
|---|---|
| `settings` object + localStorage | `game/Settings.kt` (SharedPreferences) |
| Settings window (Graphics / Sound / Camera / Regulation / HUD) | `ui/SettingsPanel.kt` (Canvas), gear button top right |
| `camMode` chase / close / hood / bumper, `camDesired`, `isFP`, shake, speed FOV | `game/CameraRig.kt` |
| `resScale` | `MainActivity.applyResolution` (GLSurfaceView fixed size) |
| pause button, `showToast('Bump!' / 'Car reset')` | `Settings.paused` in `Game.update`, `ControlsView`, `Game` |
Not compiled here (no Android SDK).

## Milestone 17 (added): ambient sound, steering wheel, quality settings
| JS | Kotlin |
|---|---|
| `initAmb` / `updateExtras` (wind, crickets, bird chirps) | `EngineSound` (ambient bed in the same mixer) |
| `tWheel` drag-to-turn wheel, `steerSens`, `touchState.analog` | `ControlsView` wheel + `Settings.ctrlWheel/steerSens` -> `DriveInput` |
| `renderDist`, `treeLod` | `Settings.renderDist` (Terrain.RAD), `Settings.treeMax` (Trees) |
Walker mode and ramps are dead code in the JS, so they are intentionally not ported. Not compiled here (no Android SDK).

## Milestone 18 (added): birds + flower gardens
| JS | Kotlin |
|---|---|
| `BSP`, `birdGeo`, `birdVS/FS`, `mkFlock`, `respawn`, `updateBirds` | `game/Birds.kt`, `gl/BirdRenderer.kt` (`BIRD_VS/FS`), `Settings.flocks` |
| `buildGardens` (marigold / daffodil / tulip bands along the roads) | `game/Gardens.kt` + flower clump meshes in `gl/ScatterRenderer.kt` (`uFlower` mode) |
Not compiled here (no Android SDK).

## Milestone 20: fixed first CI compile errors (Mud.kt array ops, ControlsView local funs, Int hex literal).

## Milestone 19: far trees, headlight lenses, quality presets, CI
Far-LOD tree crowns (200-540 m, `ScatterRenderer.gatherFar`), two headlight halos on the car nose at night, Graphics presets now also set flocks / tree count / render distance,
`.github/workflows/build.yml` (push the CONTENTS of this folder as the repo root; Actions -> Build APK -> artifact `HorizonLife-debug-apk`).

## Milestone 21: release build
`assembleRelease`: R8 minify + resource shrink, not debuggable, signed with `app/horizon-release.jks` (password horizon123, alias horizon; hobby key, fixed so updates install over older builds).

## Milestone 22: car-body + tyre mud shader
JS `TYRE_MUD` (COLOR_W / COLOR_B / bump normal) -> procedural mud in `MESH_FS` (uMudMode 1 = tyre/rim in wheel space, 2 = body lower skirt / arches / rear). `R8Model.draw` sets the uniforms per part; `Mud.lvl` now starts at 0.62 with floor 0.45 (JS FLOOR). Not ported: 3D mud lumps on the tread. NOT COMPILED.

## Milestone 23: flower gardens removed (user request)
Gardens.start() is no longer called and the flower pass in ScatterRenderer is disabled. Gardens.kt is left in place but unused.

## Milestone 24: maple, env reflections, 3D mud lumps, Optimization, HUD drag
| JS | Kotlin |
|---|---|
| `MAPLE_B64` (bark + 3600 leaf quads), 70/400 trees | `assets/maple.bin` (decoded offline), `gl/MapleTrees.kt`, `MAPLE_VS/FS`; `TreeField` marks a maple with rot + 10 (17.5 %) |
| env-map reflections (car clear-coat / glass, water) | analytic sky reflection (`skyEnv` from Environment hor/mid/zen) + Fresnel + sun glint in `MESH_FS` (`uEnvK`) and `WATER_FS` — NOT a real cube-map |
| `TYRE_MUD.lumps` (34 per wheel) | `R8Model.buildLumps/drawLumps` (bumpy icospheres, count grows with mud level) |
| Optimization switches (`OPT`) | Settings tab "Optimization": frame cap (60 fps sleep), tree throttle, map throttle, pause when hidden; "terrain tiles" switch exists but has no effect (native chunks are already culled) |
| HUD drag-to-move (`hudPos`, `hudEdit`) | HUD tab > "Move HUD items": drag buttons / minimap / speed, DONE; offsets persisted (`Settings.hudPos`), "Reset HUD" clears |
Flower gardens stay removed. NOT COMPILED (no Android SDK here).
