// Sunny Drift - Swiss village: where the wooden chalets and the church stand (pure C++, no OpenGL; drawing is in village_render.h).
//  * the village is laid out beside one stretch of a ring road: chalets on both sides, facing the road, the church with its pointed
//    spire in the middle, set back a little further so a small square opens in front of it
//  * a stretch is only used if every house has dry, fairly level ground, no other road / the river / the dirt track nearby
//  * blocked() keeps the trees and pines away from the houses (tree_render.h asks it), collide() makes the houses solid for the car
//  Call plan() once, after Road::init() and Terrain::init() and BEFORE the trees are planted.
#pragma once
#include <algorithm>
#include <cmath>
#include <random>
#include <vector>
#include "car_core.h"
#include "road.h"
#include "river.h"
#include "terrain.h"
#include "fence.h"

namespace Village {

enum { CHALET = 0, CHURCH = 1, RESTAURANT = 2, PETROL = 3, PUMP = 4, CABIN = 5, NTYPES = 6 };   // 5 = lone log cabins on the meadows (planCabins)   // 2..4 stand on the summit (planSummit)

struct Building {
    float x, z, y;            // position (y = ground height under the middle of the house)
    float rot;                // yaw: local +Z (the front, balcony / door side) points to (sin rot, cos rot) in the world
    float scale, ws;          // overall size, extra width factor (chalets only)
    float var;                // 0..1: wood tone + shutter colour
    int type;
    float hx, zMin, zMax;     // footprint in the house's own frame (already scaled): |x| <= hx, zMin <= z <= zMax
};
static std::vector<Building> gB;
static bool gPlanned = false;

// chalet footprint (local, before scaling): 7 m wide, 8.5 m deep + 1.6 m balcony at the front; church: 8.6 m wide, 19.6 m long (tower at the front)
static void footprint(Building& b){
    if (b.type == CHURCH){ b.hx = 4.4f * b.scale; b.zMin = -10.4f * b.scale; b.zMax = 9.9f * b.scale; }
    else if (b.type == RESTAURANT){ b.hx = 11.3f; b.zMin = -6.3f; b.zMax = 9.7f; }       // lodge 22.6 m wide, 12.6 m deep + front terrace
    else if (b.type == PETROL){ b.hx = 8.2f; b.zMin = -9.2f; b.zMax = -2.8f; }          // only the shop is solid: the canopy in front of it is open, the car drives under it
    else if (b.type == CABIN){ b.hx = 5.1f; b.zMin = -3.7f; b.zMax = 5.2f; }             // log cabin 10 m x 7 m + porch
    else if (b.type == PUMP){ b.hx = 0.8f; b.zMin = -2.6f; b.zMax = 2.6f; }             // pump island with two pumps
    else { b.hx = (3.65f * b.ws + 0.15f) * b.scale; b.zMin = -4.5f * b.scale; b.zMax = 6.0f * b.scale; }
}

static inline void toLocal(const Building& b, float x, float z, float& lx, float& lz){
    const float dx = x - b.x, dz = z - b.z, c = std::cos(b.rot), s = std::sin(b.rot); lx = c * dx - s * dz; lz = s * dx + c * dz;
}
static inline void toWorldDir(const Building& b, float lx, float lz, float& wx, float& wz){
    const float c = std::cos(b.rot), s = std::sin(b.rot); wx = c * lx + s * lz; wz = -s * lx + c * lz;
}

// ---------- the summit: restaurant + petrol station + a big car park on the levelled hilltop ----------
struct SummitT { bool on = false; double x = 0, z = 0, R = 0, y = 0, a = 0; };   // centre, ring-road radius, pad height, direction of the road entry
static SummitT gSummit;
// true on the asphalt of the car park (inside the ring road): full tarmac grip
static inline bool onPad(float x, float z){
    if (!gSummit.on) return false;
    const double dx = x - gSummit.x, dz = z - gSummit.z, r = gSummit.R - 3.9; return dx*dx + dz*dz < r*r;
}

// ---------- the rim of the summit: rock wall behind the restaurant, wooden rail round the rest, a viewpoint platform ----------
//  edgeKind(angle) -> 0 nothing, 1 wooden rail (radius R + 5.2), 2 rock wall (front face R + 8.5), 3 viewpoint platform (outer rail R + 14.2); rad = radius of that line.
//  Used by the mesh (village_mesh.h buildPad) and by the car collision, so what you see is what you hit. The hill road is Terrain::TRK, not Road::gNet.
static const double PAD_VIEW_REL = 1.13;                                   // viewpoint: 65 deg to the left of the road entry (the entry road comes in from the other side)
static inline double wrapPi(double a){ const double P2 = 6.283185307179586; a = std::fmod(a, P2); if (a > 3.141592653589793) a -= P2; if (a < -3.141592653589793) a += P2; return a; }
static inline float roadClr(float x, float z){ float c = Road::clearance(x, z); if (Terrain::TRK.on){ const float t = (float)(Terrain::trackDist(x, z) - Terrain::TRK_W * 0.5); if (t < c) c = t; } return c; }
static int edgeKind(double ang, double& rad){
    rad = 0; if (!gSummit.on) return 0;
    const double R = gSummit.R, rel = wrapPi(ang - gSummit.a), ar = std::fabs(rel), hv = 7.0 / (R + 5.2); int k; double r;
    if (ar > 2.0){ k = 2; r = R + 8.5; } else if (std::fabs(rel - PAD_VIEW_REL) < hv){ k = 3; r = R + 14.2; } else { k = 1; r = R + 5.2; }
    const float px = (float)(gSummit.x + std::cos(ang) * r), pz = (float)(gSummit.z + std::sin(ang) * r);
    if (k != 3){ const float c = roadClr(px, pz); if (k == 2 ? c < 4.5f : c < 1.6f) return 0; }          // the road (approach) crosses here: leave a gap
    rad = r; return k;
}
// the car body (3 circles) cannot leave the pad through the rail / rock wall
static void collidePadEdge(CarState& S){
    if (!gSummit.on) return;
    const double dx0 = S.x - gSummit.x, dz0 = S.z - gSummit.z, d0 = std::sqrt(dx0*dx0 + dz0*dz0); if (d0 < gSummit.R - 6.0 || d0 > gSummit.R + 22.0) return;
    const double sH = std::sin(S.heading), cH = std::cos(S.heading); static const double OFS[3] = {-1.5, 0.0, 1.5};
    for (double o : OFS){
        const double px = S.x + sH * o, pz = S.z + cH * o, dx = px - gSummit.x, dz = pz - gSummit.z, d = std::sqrt(dx*dx + dz*dz); if (d < 1e-3) continue;
        double rad; const int k = edgeKind(std::atan2(dz, dx), rad); if (!k) continue;
        const double lim = rad - (k == 2 ? 1.05 : 1.0), top = rad + (k == 2 ? 4.0 : 1.2); if (d <= lim || d >= top) continue;
        const double ux = dx / d, uz = dz / d, pen = d - lim; S.x -= ux * pen; S.z -= uz * pen;
        Fence::bounceOff(S, -ux, -uz, 0.22, 0.30);
    }
}

// true if (x,z) is within `margin` metres of any house (used to keep trees away)
static bool blocked(float x, float z, float margin){
    if (Terrain::summitCleared(x, z, margin)) return true;                                  // the whole hilltop stays free of trees / flowers / shrubs
    for (const Building& b : gB){
        const float dx = x - b.x, dz = z - b.z; if (dx*dx + dz*dz > 900.f) continue;          // houses are < 25 m across: cheap reject
        float lx, lz; toLocal(b, x, z, lx, lz);
        if (std::fabs(lx) < b.hx + margin && lz > b.zMin - margin && lz < b.zMax + margin) return true;
    }
    return false;
}

static float groundAt(float x, float z){ return (float)Terrain::fieldH(x, z); }

// is a house of this type OK at (x,z) facing rot? fills the ground height
static bool siteOk(const Building& b, float expectClear, float& gy){
    if (std::fabs(River::riverSd(b.x, b.z)) < 48.0 || Terrain::trackDist(b.x, b.z) < 22.0) return false;
    if (Road::clearance(b.x, b.z) < expectClear - 3.5f) return false;                          // another road comes closer than the one we stand beside
    const float cr = std::cos(b.rot), sr = std::sin(b.rot); float lo = 1e9f, hi = -1e9f, sum = 0; int n = 0;
    const float xs[3] = {-b.hx, 0.f, b.hx}, zs[3] = {b.zMin, 0.5f * (b.zMin + b.zMax), b.zMax};
    for (float lx : xs) for (float lz : zs){
        const float wx = b.x + cr * lx + sr * lz, wz = b.z - sr * lx + cr * lz;
        if (std::fabs(River::riverSd(wx, wz)) < 40.0 || Road::clearance(wx, wz) < 5.5f) return false;   // no corner on the road / its verge
        const float h = groundAt(wx, wz); lo = std::min(lo, h); hi = std::max(hi, h); sum += h; n++;
    }
    if (hi - lo > (b.type == CHURCH ? 2.4f : 1.5f)) return false;
    gy = sum / n; return true;
}

static bool overlaps(const Building& a, float gap){
    for (const Building& b : gB){
        const float dx = a.x - b.x, dz = a.z - b.z, r = (a.type == CHURCH ? 15.f : 8.5f) * a.scale + (b.type == CHURCH ? 15.f : 8.5f) * b.scale;
        if (dx*dx + dz*dz < (r - gap) * (r - gap)) return true;
    }
    return false;
}

// lay the village out along `cv` starting at arc fraction u0; returns how many houses fit (placed into out)
static int layout(const Road::Curve& cv, double u0, uint32_t seed, std::vector<Building>& out){
    gB.clear();
    std::mt19937 rng(seed); auto U = [&]{ return std::uniform_real_distribution<float>(0.f, 1.f)(rng); };
    const double len = cv.length(), hw = cv.hw; const int SLOTS = 8; const double STEP = 16.0;
    int placed = 0; bool churchDone = false;
    const int churchSlot = 3, churchSide = (seed & 1) ? 1 : -1;
    for (int i = 0; i < SLOTS; i++) for (int sd : {1, -1}){
        const bool isChurch = (i == churchSlot && sd == churchSide);
        if (sd == churchSide && (i == churchSlot - 1 || i == churchSlot + 1) ) continue;             // the church needs the room of its neighbours
        const double s = (u0 * len + i * STEP + (sd > 0 ? 0.0 : STEP * 0.5) + (U() - 0.5) * 3.0) / len;
        const Road::V3 p = cv.getPointAt(std::fmod(s, 1.0)), tg = cv.getTangentAt(std::fmod(s, 1.0));
        const double tl = std::hypot(tg.x, tg.z); if (tl < 1e-6) continue;
        const double nx = -tg.z / tl, nz = tg.x / tl;                                                    // left normal of the road
        Building b; b.type = isChurch ? CHURCH : CHALET; b.scale = isChurch ? 1.0f : 0.95f + 0.2f * U(); b.ws = isChurch ? 1.f : 0.9f + 0.4f * U();
        b.var = U(); footprint(b);
        // distance of the house's centre from the road centre line: front edge (balcony / steps) ends ~8 m from the tarmac edge
        const double frontReach = isChurch ? b.zMax : b.zMax + 0.6;
        const double off = hw + (isChurch ? 11.0 : 8.0) + frontReach + (isChurch ? 0.0 : U() * 2.5);
        b.x = (float)(p.x + nx * sd * off); b.z = (float)(p.z + nz * sd * off);
        const double fx = -nx * sd, fz = -nz * sd;                                                       // front of the house points to the road
        b.rot = (float)std::atan2(fx, fz) + (isChurch ? 0.f : (U() - 0.5f) * 0.10f);
        float gy; if (!siteOk(b, (float)(off - hw), gy)) continue;
        if (overlaps(b, 1.5f)) continue;
        b.y = gy; out.push_back(b); gB.push_back(b); placed++; if (isChurch) churchDone = true;
    }
    return churchDone ? placed : 0;                                                                       // no church, no village
}

static void plan(){
    if (gPlanned) return; gPlanned = true; gB.clear();
    std::vector<Building> best; int bestN = 0;
    std::vector<const Road::Curve*> rings;                                                           // every road of the web, nearest to the start line first
    { double sx, sz, sh; Road::startPose(sx, sz, sh);
      for (const Road::Curve* c : Road::all()) if (c->length() > 190) rings.push_back(c);
      auto dS = [&](const Road::Curve* c){ const Road::V3 p = c->getPointAt(0.5); return std::hypot(p.x - sx, p.z - sz); };
      std::sort(rings.begin(), rings.end(), [&](const Road::Curve* a, const Road::Curve* b){ return dS(a) < dS(b); }); }
    for (int attempt = 0; attempt < 4 && bestN < 13; attempt++){
        const bool nearStart = attempt < 2;                                                              // SWISS: first try to put the village right after the start line, so the player drives into it at once
        for (int ri = 0; ri < (int)rings.size() && ri < (nearStart ? 6 : 40) && bestN < 13; ri++){
            const Road::Curve& cv = *rings[ri]; const double len = cv.length(), span = (8 * 16.0 + 20.0) / len;
            for (int k = 0; k < 60 && bestN < 13; k++){
                const double f = (double)((k * 37) % 60) / 60.0;
                const double u0 = nearStart ? 0.06 + 0.16 * f : 0.12 + (0.76 - span) * f;
                if (u0 + span > 0.97) continue;                                                          // open road: the houses must fit between its two ends
                std::vector<Building> out; const int n = layout(cv, u0, 7001u + (uint32_t)((attempt & 1) * 2 + (k & 1)), out);
                if (n > bestN){ bestN = n; best = out; }
            }
        }
    }
    gB = best;
}

// SUMMIT layout, in the pad's own frame: u = towards the road entry, v = to its left. Call after Terrain::init() and Village::plan(), before the trees.
//  restaurant at the back of the pad facing the entry; petrol station (shop + canopy + 3 pump islands) on the left side facing the middle;
//  a double row of bays in front of the restaurant, and one ring of bays round the whole pad (painted by VillageMesh::buildPad)
static void planSummit(){
    gSummit = SummitT();
    if (!Terrain::PEAK.on || !Terrain::PEAK.padOn || Road::gPark[2] < 45.f) return;
    gSummit.x = Terrain::PEAK.x; gSummit.z = Terrain::PEAK.z; gSummit.R = Road::gPark[2]; gSummit.y = Terrain::PEAK.padY; gSummit.a = Terrain::gPadA; gSummit.on = true;
    const double th = gSummit.a, ux = std::cos(th), uz = std::sin(th), vx = -std::sin(th), vz = std::cos(th);
    auto put = [&](int type, double u, double v, double fu, double fv, float var){
        Building b; b.type = type; b.scale = 1.f; b.ws = 1.f; b.var = var; footprint(b);
        b.x = (float)(gSummit.x + ux * u + vx * v); b.z = (float)(gSummit.z + uz * u + vz * v); b.y = (float)gSummit.y;
        const double fx = ux * fu + vx * fv, fz = uz * fu + vz * fv; b.rot = (float)std::atan2(fx, fz);
        gB.push_back(b); return b;
    };
    put(RESTAURANT, -24.0, 0.0, 1.0, 0.0, 0.3f);
    const Building pt = put(PETROL, 0.0, 40.0, 0.0, -1.0, 0.5f);
    for (float lx : {-6.f, 0.f, 6.f}){                                                       // 3 pump islands under the canopy, long side along the petrol station's own +Z
        Building b; b.type = PUMP; b.scale = 1.f; b.ws = 1.f; b.var = 0.f; footprint(b); b.rot = pt.rot; b.y = pt.y;
        const float c = std::cos(pt.rot), s = std::sin(pt.rot), lz = 6.5f;
        b.x = pt.x + c * lx + s * lz; b.z = pt.z - s * lx + c * lz; gB.push_back(b);
    }
}

// CABINS: lone wooden mountain houses on knolls of the meadow, set back from the roads, facing the nearest road. Call after plan() / planSummit(), before the trees.
static void planCabins(){
    if (!Terrain::gReady) return;
    std::mt19937 rng(424242u); auto U = [&]{ return std::uniform_real_distribution<float>(0.f, 1.f)(rng); };
    struct Cand { Building b; float score; }; std::vector<Cand> cs;
    for (int t = 0; t < 9000; t++){
        const float x = (U() * 2 - 1) * 1180.f, z = (U() * 2 - 1) * 840.f;
        const float cl = Road::clearance(x, z); if (cl < 30.f || cl > 95.f) continue;                       // near enough to be seen from the road, far enough to feel remote
        if (std::fabs(River::riverSd(x, z)) < 70.0 || Terrain::trackDist(x, z) < 60.0 || Terrain::coastDist(x, z) > -160.0) continue;
        if (Terrain::gLake.on && Terrain::lakeDn(x, z) < 2.1) continue;
        if (Terrain::summitCleared(x, z, 40.0) || Terrain::PEAK.on && std::hypot(x - Terrain::PEAK.x, z - Terrain::PEAK.z) < Terrain::PEAK.R * 1.25) continue;   // not on the big mountain
        bool near = false; for (const Building& o : gB){ const float dx = x - o.x, dz = z - o.z; if (dx*dx + dz*dz < 70.f * 70.f){ near = true; break; } } if (near) continue;
        float gx = Road::clearance(x + 6, z) - Road::clearance(x - 6, z), gz = Road::clearance(x, z + 6) - Road::clearance(x, z - 6); const float gl = std::sqrt(gx*gx + gz*gz);
        if (gl < 0.2f) continue; gx /= gl; gz /= gl;
        Building b; b.type = CABIN; b.scale = 0.95f + 0.2f * U(); b.ws = 1.f; b.var = U(); footprint(b); b.x = x; b.z = z;
        b.rot = std::atan2(-gx, -gz) + (U() - 0.5f) * 0.25f;                                                  // front (porch) towards the nearest road
        float gy; if (!siteOk(b, cl, gy)) continue;
        const float h0 = groundAt(x, z); float sum = 0; int n = 0;                                            // knoll: higher than the ground 45 m around
        for (int k = 0; k < 8; k++){ const float a = k * 0.7853982f; sum += groundAt(x + 45.f * std::cos(a), z + 45.f * std::sin(a)); n++; }
        if (h0 - sum / n < -0.3f) continue;
        b.y = gy; cs.push_back({b, (h0 - sum / n) + 0.8f * U()});
    }
    std::sort(cs.begin(), cs.end(), [](const Cand& a, const Cand& c){ return a.score > c.score; });
    int placed = 0;
    for (const Cand& c : cs){
        if (placed >= 12) break; bool ok = true;
        for (const Building& o : gB) if (o.type == CABIN){ const float dx = c.b.x - o.x, dz = c.b.z - o.z; if (dx*dx + dz*dz < 170.f * 170.f){ ok = false; break; } }
        if (!ok) continue; gB.push_back(c.b); placed++;
    }
}

// ---------- hamlets + farmhouses: single chalets and small groups beside the country roads wherever the ground allows (level, dry, off the river, clear of junctions) ----------
//  Call after plan() + planCabins(), before planSummit() and the trees.
static void planHamlets(){
    if (!Terrain::gReady) return;
    std::mt19937 rng(777123u); auto U = [&]{ return std::uniform_real_distribution<float>(0.f, 1.f)(rng); };
    int placed = 0;
    for (const Road::Curve* cp : Road::all()){
        const Road::Curve& cv = *cp; const double len = cv.length(), hw = cv.hw; if (len < 140) continue;
        double s = 45.0 + U() * 40.0;
        while (s < len - 45.0 && placed < 140){
            const int grp = U() < 0.30f ? 2 + (int)(U() * 2.f) : 1;                                       // a lone farmhouse, or a group of 2 - 3 along the road
            const int sd = U() < 0.5f ? 1 : -1; bool any = false;
            for (int g = 0; g < grp; g++){
                const double ss = s + g * (17.0 + 4.0 * U());
                if (ss > len - 40.0) break;
                const Road::V3 p = cv.getPointAt(ss / len), tg = cv.getTangentAt(ss / len); const double tl = std::hypot(tg.x, tg.z); if (tl < 1e-6) continue;
                const double nx = -tg.z / tl, nz = tg.x / tl;
                Building b; b.type = CHALET; b.scale = 0.95f + 0.2f * U(); b.ws = 0.9f + 0.4f * U(); b.var = U(); footprint(b);
                const double off = hw + 8.0 + b.zMax + 0.6 + U() * 6.0;
                b.x = (float)(p.x + nx * sd * off); b.z = (float)(p.z + nz * sd * off);
                b.rot = (float)std::atan2(-nx * sd, -nz * sd) + (U() - 0.5f) * 0.12f;
                float gy; if (!siteOk(b, (float)(off - hw), gy)) continue;
                if (Terrain::gLake.on && Terrain::lakeDn(b.x, b.z) < 1.8) continue;
                if (Terrain::summitCleared(b.x, b.z, 40.0) || (Terrain::PEAK.on && std::hypot(b.x - Terrain::PEAK.x, b.z - Terrain::PEAK.z) < Terrain::PEAK.R * 1.1)) continue;
                if (overlaps(b, -6.f)) continue;                                                           // keep at least ~6 m between houses
                b.y = gy; gB.push_back(b); placed++; any = true;
            }
            s += (any ? 70.0 : 25.0) + U() * 90.0;                                                          // quiet gaps of open meadow between the houses
        }
    }
}

// ---------- the houses are solid ----------
// the car body is 3 circles along its length; each is pushed out of the house's footprint (a rectangle in the house's own frame)
static void collide(CarState& S){
    collidePadEdge(S);
    if (gB.empty()) return;
    const double sH = std::sin(S.heading), cH = std::cos(S.heading), R = 1.05; static const double OFS[3] = {-1.5, 0.0, 1.5};
    for (const Building& b : gB){
        const double dx = b.x - S.x, dz = b.z - S.z; if (dx*dx + dz*dz > 32.0 * 32.0) continue;
        for (double o : OFS){
            const float px = (float)(S.x + sH * o), pz = (float)(S.z + cH * o); float lx, lz; toLocal(b, px, pz, lx, lz);
            const float cx = std::max(-b.hx, std::min(b.hx, lx)), cz = std::max(b.zMin, std::min(b.zMax, lz)), vx = lx - cx, vz = lz - cz; float nlx, nlz, pen;
            const float d = std::sqrt(vx*vx + vz*vz);
            if (d > 1e-4f){ if (d >= R) continue; nlx = vx / d; nlz = vz / d; pen = (float)R - d; }
            else {                                                                                        // centre is inside the footprint: leave through the nearest side
                const float e[4] = {b.hx - lx, lx + b.hx, b.zMax - lz, lz - b.zMin}; int k = 0; for (int j = 1; j < 4; j++) if (e[j] < e[k]) k = j;
                nlx = (k == 0) ? 1.f : (k == 1 ? -1.f : 0.f); nlz = (k == 2) ? 1.f : (k == 3 ? -1.f : 0.f); pen = e[k] + (float)R;
            }
            float wx, wz; toWorldDir(b, nlx, nlz, wx, wz);
            S.x += wx * pen; S.z += wz * pen;
            Fence::bounceOff(S, wx, wz, 0.22, 0.30);
        }
    }
}

} // namespace Village
