// Sunny Drift - post-processing: the whole scene is drawn into an off-screen texture, then one full-screen pass adds
//   * god rays (sun beams through the gaps in the trees, from the depth buffer)
//   * bloom (soft glow round the sun, bright sky and the car's lights; taken from the blurry high mip levels of the scene, so it is cheap)
//   * cinematic colour grading (gentle S-curve contrast, a little more saturation, cool shadows / warm highlights)
//   * a soft vignette
// Low / Normal / High each have their own bloom quality (see uBQ). If the off-screen buffer can not be created the game simply draws straight to the screen as before.
#pragma once
#include <GLES3/gl3.h>

namespace Post {

static GLuint gFbo = 0, gTex = 0, gDepth = 0, gProg = 0, gVao = 0; static int gW = 0, gH = 0; static bool gFailed = false;
static GLint uBloomL=-1,uBQL,uSpdL,uTimeL,uVanL,uCarUVL,uBTintL,uBPL,uRayL;
static GLint uS, uRes, uD, uWx, uNF, uCF, uCR, uCU, uTH, uSunD, uSunUV;
// time of day: the depth buffer is a texture while post effects are on, so god rays and warm haze can tell sky from trees / hills per pixel
static bool gDepthIsTex = false, wantDepth = false;
static float wx[3] = {0.f, 0.f, 0.f};                                    // unused, unused, warm low-sun light (0..1)
static float camF[3] = {0, 0, 1}, camR[3] = {1, 0, 0}, camU[3] = {0, 1, 0}, camTH[2] = {1.f, 1.f}, sunD[3] = {0, 1, 0}, sunUV[3] = {0.5f, 0.5f, 0.f};
static float bloom = 1.0f;                    // 0 = off, 1 = default
static int bloomQ = 1;                        // bloom quality = graphics level: 0 Low (cheap), 1 Normal, 2 High (smoothest)
static float bTint[3] = {1.1f, 1.f, .88f}, bThr = .66f, bGain = 1.35f, bSoft = .045f, bRad = 1.f;   // bloom look (set per time of day)
static float rays = 0.f;                      // god rays strength (0 = off, 1 = default); needs the depth texture
static float fxSpeed = 0.f, fxTime = 0.f, fxVan[2] = {0.5f, 0.55f}, fxCar[2] = {0.5f, 0.3f};   // speed effects: 0..1 speed, clock, vanishing point + car position on screen (0..1)

static const char* VS = R"GLSL(#version 300 es
void main(){ vec2 p = vec2((gl_VertexID == 1) ? 3.0 : -1.0, (gl_VertexID == 2) ? 3.0 : -1.0); gl_Position = vec4(p, 0.0, 1.0); }
)GLSL";
static const char* FS = R"GLSL(#version 300 es
precision highp float;
uniform sampler2D uS; uniform highp sampler2D uD; uniform vec2 uRes; uniform float uBloom;
uniform vec4 uWx; uniform vec2 uNF; uniform vec3 uCF, uCR, uCU, uSunD, uSunUV; uniform vec2 uTH; uniform float uSpd; uniform float uTime; uniform vec2 uVan; uniform vec2 uCarUV; uniform float uRay; uniform vec3 uBTint; uniform vec4 uBP; uniform int uBQ; out vec4 o;   // uBP = threshold, gain, softness, spread
float hs(float n){ return fract(sin(n*127.1 + 311.7)*43758.5453); }
void main(){
  vec2 uv = gl_FragCoord.xy / uRes;
  float asp = uRes.x / uRes.y;
  vec3 c = texture(uS, uv).rgb;
  // speed: radial motion blur towards the vanishing point of the road. The car itself (and its surroundings) stays sharp, the road and the sides streak.
  if (uSpd > 0.02){
    vec2 q = (uv - uCarUV) * vec2(asp, 1.35);
    float keep = smoothstep(0.17, 0.32, length(q));
    vec2 d = (uVan - uv) * (0.075 * uSpd * keep);
    vec3 acc = vec3(0.0);
    for (int i = 0; i < 8; i++) acc += textureLod(uS, uv + d * (float(i) / 7.0), 0.0).rgb;
    c = acc * 0.125;
  }
  // ---- time of day: warm low sun (morning, afternoon, sunset): golden key light, soft haze that thickens with distance, glow round the sun ----
  float sunK = uWx.z;
  if (sunK > 0.002){
    float d0 = texture(uD, uv).r;
    bool sky = d0 > 0.99999;
    vec3 vd = normalize(uCF + (uv.x*2.0 - 1.0)*uTH.x*uCR + (uv.y*2.0 - 1.0)*uTH.y*uCU);
    float zn = d0*2.0 - 1.0;
    float ld = 2.0*uNF.x*uNF.y / (uNF.y + uNF.x - zn*(uNF.y - uNF.x));
    float dist = sky ? 7000.0 : ld / max(dot(vd, uCF), 0.25);
    float sd = max(dot(vd, uSunD), 0.0);
    float fa = sky ? 0.0 : 1.0 - exp(-dist*0.00040*sunK);
    vec3 fc = mix(vec3(0.78, 0.82, 0.86), vec3(1.00, 0.70, 0.42), sunK*(0.40 + 0.60*pow(sd, 3.0)));   // warm mist, brightest towards the sun
    fc += vec3(1.0, 0.82, 0.55)*pow(sd, 16.0)*0.35*sunK;
    c = mix(c, fc, fa);
    c *= mix(vec3(1.0), vec3(1.14, 0.96, 0.78), sunK);                                   // warm key light
    c += vec3(1.0, 0.60, 0.26)*pow(sd, 8.0)*0.30*sunK;                                   // glow round the low sun
  }
  // ---- god rays: sunlight streaming through the gaps between the trees ----
  // The depth buffer tells which pixels are open sky (depth = far plane). From every pixel we march towards the sun and count how much open sky we meet:
  // leaves / trunks / hills block it, the gaps let it through, so beams fan out from the sun between the branches. A little per-pixel jitter hides the banding.
  if (uRay > 0.001 && uSunUV.z > 0.0 && uSunD.y > -0.03){
    float dayK = smoothstep(-0.03, 0.08, uSunD.y) * (1.0 + 0.6*uWx.z);        // low sun = long strong beams
    vec2 toSun = uSunUV.xy - uv;
    float sdist = length(toSun * vec2(asp, 1.0));
    vec2 step1 = toSun * (0.92 / 16.0);
    float jit = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));   // interlaved-gradient noise
    vec2 sp = uv + step1 * jit; float acc = 0.0, w = 1.0, wsum = 0.0;
    for (int i = 0; i < 16; i++){
      sp += step1;
      float inside = step(0.0, sp.x) * step(sp.x, 1.0) * step(0.0, sp.y) * step(sp.y, 1.0);
      float open = step(0.99999, textureLod(uD, sp, 0.0).r) * inside;
      acc += open * w; wsum += w; w *= 0.93;
    }
    acc /= wsum;
    float here = step(0.99999, texture(uD, uv).r);                  // this pixel is open sky: shafts are only a faint glow there, so the sky does not wash out
    float reach = exp(-0.85*sdist) * 0.85 + 0.15;                    // strongest close to the sun, a soft tail far away
    float sh = acc * reach * uSunUV.z * dayK * uRay * mix(1.0, 0.22, here);
    vec3 rc = mix(vec3(1.00, 0.90, 0.70), vec3(1.00, 0.68, 0.38), uWx.z);   // warm white, golden at sunset
    c += rc * sh * 0.34;
  }
  // bloom (realistic glare): only the really bright parts glow - a tight halo plus a wide soft veil from blurry mips (both thresholded, so shadows and
  // the sky gradient stay clean), tinted only slightly by the light's colour and SCREEN-blended, so highlights roll off softly and never clip into flat white blobs
  vec2 px = 1.0 / uRes;
  const vec3 LW = vec3(0.299, 0.587, 0.114);
  vec3 b = vec3(0.0);
  // bloom quality per graphics level:  Low (uBQ 0) = 1 tap on 2 blurred mips (cheap soft glow),  Normal (1) = 5 taps on 2 mips (the original),
  //                                    High (2) = 9 taps on 3 mips (smoother, rounder halo with a longer, softer falloff)
  int nJ = (uBQ == 2) ? 3 : 2, nK = (uBQ == 0) ? 1 : ((uBQ == 1) ? 5 : 9);
  for (int j = 0; j < nJ; j++){
    float lod = (j == 0) ? 3.0 : ((j == 1) ? ((nJ == 3) ? 4.0 : 5.0) : 5.5);
    float rad = (((j == 0) ? 6.0 : ((j == 1) ? ((nJ == 3) ? 13.0 : 22.0) : 30.0))) * uBP.w;
    float wt = (nJ == 3) ? ((j == 0) ? 0.40 : ((j == 1) ? 0.33 : 0.27)) : ((j == 0) ? 0.55 : 0.45);
    float cw = (nK == 1) ? 1.0 : 0.36, ow = (nK == 5) ? 0.16 : 0.08;                  // tap weights always add up to 1
    vec3 a = vec3(0.0);
    for (int k = 0; k < nK; k++){
      vec2 off = vec2(0.0);
      if (k > 0 && k < 5) off = vec2(((k & 1) == 0) ? -1.0 : 1.0, (k < 3) ? -1.0 : 1.0) * 0.75;     // 4 diagonal taps
      else if (k >= 5) { float an = float(k - 5) * 1.5707963; off = vec2(cos(an), sin(an)) * 1.3; }       // High: 4 more taps on the axes, further out
      vec3 sm = textureLod(uS, uv + off * rad * px, lod).rgb;
      float lm = dot(sm, LW);
      float kn = clamp((lm - uBP.x) / 0.40, 0.0, 1.0);                    // soft knee: starts gently, no hard edge
      a += sm * (kn * kn * (3.0 - 2.0*kn)) * ((k == 0) ? cw : ow);
    }
    b += a * wt;
  }
  vec3 bt = mix(vec3(1.0), uBTint, 0.65);                                    // mostly white glare, a hint of the light colour
  vec3 wide = textureLod(uS, uv, 6.5).rgb;
  wide *= smoothstep(uBP.x*0.75, 1.0, dot(wide, LW));                        // the wide veil comes from bright areas only (no milky black level)
  vec3 glow = (b * uBP.y * 0.80 + wide * uBP.z * 2.0) * bt * uBloom;
  c = 1.0 - (1.0 - clamp(c, 0.0, 1.0)) * (1.0 - clamp(glow, 0.0, 0.92));    // screen blend
  // ---- look of each time of day (from the sun's height + side): morning cool/misty, noon clear and contrasty, afternoon golden, dusk blue-violet ----
  {
    float el = uSunD.y;
    float lowSun = 1.0 - smoothstep(0.10, 0.60, el);
    float noonK = smoothstep(0.55, 0.92, el);
    float morn = 1.0 - smoothstep(-0.25, 0.25, uSunD.x);
    float dayUp = smoothstep(-0.03, 0.10, el);
    float dusk = smoothstep(-0.24, -0.06, el) * (1.0 - smoothstep(-0.02, 0.06, el));
    float lm = dot(c, vec3(0.299, 0.587, 0.114));
    // morning: lifted, slightly bluish shadows + pale gold highlights, softer contrast
    float mK = lowSun * morn * dayUp;
    c = mix(c, c + vec3(0.020, 0.028, 0.040)*(1.0 - lm), mK*0.9);
    c *= mix(vec3(1.0), vec3(1.03, 1.00, 0.93), mK*smoothstep(0.35, 0.8, lm));
    // afternoon: rich golden light, warm shadows are kept deep
    float aK = lowSun * (1.0 - morn) * dayUp;
    c *= mix(vec3(1.0), vec3(1.08, 1.00, 0.86), aK*0.8);
    c = mix(vec3(dot(c, vec3(0.299, 0.587, 0.114))), c, 1.0 + 0.10*aK);
    // noon: crisp, neutral-white light, a little more contrast and saturation
    c = mix(c, c*c*(3.0 - 2.0*c), noonK*0.16);
    c = mix(vec3(dot(c, vec3(0.299, 0.587, 0.114))), c, 1.0 + 0.06*noonK);
    // dusk / blue hour: cool violet shadows, desaturated, a warm band is kept near the sun by the glow above
    float dl = dot(c, vec3(0.299, 0.587, 0.114));
    c = mix(c, vec3(dl)*vec3(0.78, 0.82, 1.12) + c*vec3(0.18, 0.14, 0.28)*0.5, dusk*0.55);
  }
  // colour grade
  c = mix(c, c*c*(3.0 - 2.0*c), 0.26);                                         // S-curve: deeper shadows, brighter highlights
  float l = dot(c, vec3(0.299, 0.587, 0.114));
  c = mix(vec3(l), c, 1.10);                                                   // a bit more colour
  c *= mix(vec3(0.96, 1.00, 1.05), vec3(1.04, 1.00, 0.94), smoothstep(0.20, 0.80, l));   // cool shadows, warm highlights
  float r = length((uv - 0.5)*vec2(1.0, 0.9));
  c *= 1.0 - 0.26*smoothstep(0.40, 0.88, r);                                   // vignette
  // speed lines: thin white streaks rushing outwards from the vanishing point, only near the edges of the screen, from ~100 km/h
  float lk = smoothstep(0.30, 0.85, uSpd);
  if (lk > 0.001){
    vec2 p = (uv - uVan) * vec2(asp, 1.0); float rr = length(p); float a = atan(p.y, p.x) * (64.0 / 6.2831853);
    float id = floor(a), f = fract(a);
    float h1 = hs(id), h2 = hs(id + 17.0), h3 = hs(id + 41.0), h4 = hs(id + 73.0);
    float t = fract(uTime * (1.1 + 1.6*h2) + h1);
    float head = mix(0.30, 1.35, t), len = 0.22 + 0.35*h3;
    float along = smoothstep(head - len, head, rr) * (1.0 - smoothstep(head, head + 0.03, rr));
    float lat = abs(f - 0.5) * (6.2831853 / 64.0) * rr;
    float line = (1.0 - smoothstep(0.0007, 0.0024, lat)) * along * step(0.42, h4);
    float edge = smoothstep(0.40, 0.80, rr);
    c += vec3(0.92, 0.96, 1.0) * line * edge * 0.40 * lk;
    c *= 1.0 - 0.14 * uSpd * smoothstep(0.35, 0.95, rr);                    // edges darken a little with speed
  }
  o = vec4(clamp(c, 0.0, 1.0), 1.0);
}
)GLSL";

static GLuint comp(GLenum t, const char* s){ GLuint sh = glCreateShader(t); glShaderSource(sh, 1, &s, nullptr); glCompileShader(sh); return sh; }
static void freeFbo(){ if (gFbo) glDeleteFramebuffers(1, &gFbo); if (gTex) glDeleteTextures(1, &gTex); if (gDepth){ if (gDepthIsTex) glDeleteTextures(1, &gDepth); else glDeleteRenderbuffers(1, &gDepth); } gFbo = gTex = gDepth = 0; }

static bool ensure(int W, int H){
    if (gFailed) return false;
    if (gFbo && gW == W && gH == H && gDepthIsTex == wantDepth) return true;
    if (!gProg){
        gProg = glCreateProgram(); glAttachShader(gProg, comp(GL_VERTEX_SHADER, VS)); glAttachShader(gProg, comp(GL_FRAGMENT_SHADER, FS)); glLinkProgram(gProg);
        GLint ok = 0; glGetProgramiv(gProg, GL_LINK_STATUS, &ok); if (!ok){ gFailed = true; return false; }
        uS = glGetUniformLocation(gProg, "uS"); uRes = glGetUniformLocation(gProg, "uRes"); glGenVertexArrays(1, &gVao);
        uD = glGetUniformLocation(gProg, "uD"); uWx = glGetUniformLocation(gProg, "uWx"); uNF = glGetUniformLocation(gProg, "uNF"); uCF = glGetUniformLocation(gProg, "uCF");
        uCR = glGetUniformLocation(gProg, "uCR"); uCU = glGetUniformLocation(gProg, "uCU"); uTH = glGetUniformLocation(gProg, "uTH");
        uSunD = glGetUniformLocation(gProg, "uSunD"); uSunUV = glGetUniformLocation(gProg, "uSunUV");
        uBloomL = glGetUniformLocation(gProg, "uBloom"); uBQL = glGetUniformLocation(gProg, "uBQ"); uSpdL = glGetUniformLocation(gProg, "uSpd"); uTimeL = glGetUniformLocation(gProg, "uTime");
        uVanL = glGetUniformLocation(gProg, "uVan"); uCarUVL = glGetUniformLocation(gProg, "uCarUV"); uBTintL = glGetUniformLocation(gProg, "uBTint"); uBPL = glGetUniformLocation(gProg, "uBP"); uRayL = glGetUniformLocation(gProg, "uRay");
    }
    freeFbo(); gW = W; gH = H; gDepthIsTex = wantDepth;
    glGenTextures(1, &gTex); glBindTexture(GL_TEXTURE_2D, gTex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, W, H, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glGenFramebuffers(1, &gFbo); glBindFramebuffer(GL_FRAMEBUFFER, gFbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, gTex, 0);
    if (gDepthIsTex){      // weather: sampled depth (distance fog, sky mask)
        glGenTextures(1, &gDepth); glBindTexture(GL_TEXTURE_2D, gDepth);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT24, W, H, 0, GL_DEPTH_COMPONENT, GL_UNSIGNED_INT, nullptr);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, gDepth, 0);
    } else {
        glGenRenderbuffers(1, &gDepth); glBindRenderbuffer(GL_RENDERBUFFER, gDepth); glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT24, W, H);
        glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, gDepth);
    }
    const bool ok = glCheckFramebufferStatus(GL_FRAMEBUFFER) == GL_FRAMEBUFFER_COMPLETE;
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    if (!ok){ freeFbo(); gFailed = true; return false; }
    return true;
}

// start of the frame: redirect drawing into the off-screen buffer. Returns false when post-processing is off (then draw to the screen as usual).
static bool begin(int W, int H, bool wanted){
    if (!wanted || W < 16 || H < 16 || !ensure(W, H)) return false;
    glBindFramebuffer(GL_FRAMEBUFFER, gFbo); glViewport(0, 0, W, H); return true;
}
// end of the frame: bloom + grade + vignette onto the screen
static void end(int W, int H){
    if (!gDepthIsTex && gFbo){ glBindFramebuffer(GL_FRAMEBUFFER, gFbo); const GLenum inv[1] = {GL_DEPTH_ATTACHMENT}; glInvalidateFramebuffer(GL_FRAMEBUFFER, 1, inv); }   // depth is not needed after the scene: skip the memory write-back (tile GPUs)
    glBindFramebuffer(GL_FRAMEBUFFER, 0); glViewport(0, 0, W, H);
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, gTex); glGenerateMipmap(GL_TEXTURE_2D);
    glDisable(GL_DEPTH_TEST); glDisable(GL_BLEND); glDisable(GL_CULL_FACE); glDepthMask(GL_FALSE);
    glUseProgram(gProg); glUniform1i(uS, 0); glUniform2f(uRes, (float)W, (float)H); glUniform1f(uBloomL, bloom); glUniform1i(uBQL, bloomQ);
    glUniform1f(uSpdL, fxSpeed); glUniform1f(uTimeL, fxTime);
    glUniform2f(uVanL, fxVan[0], fxVan[1]); glUniform2f(uCarUVL, fxCar[0], fxCar[1]);
    glUniform3fv(uBTintL, 1, bTint); glUniform4f(uBPL, bThr, bGain, bSoft, bRad);
    glUniform1f(uRayL, gDepthIsTex ? rays : 0.f);
    if (gDepthIsTex) glUniform4f(uWx, wx[0], wx[1], wx[2], 0.f); else glUniform4f(uWx, 0.f, 0.f, 0.f, 0.f); glUniform2f(uNF, 0.4f, 7000.f);
    glUniform3fv(uCF, 1, camF); glUniform3fv(uCR, 1, camR); glUniform3fv(uCU, 1, camU); glUniform2fv(uTH, 1, camTH); glUniform3fv(uSunD, 1, sunD); glUniform3fv(uSunUV, 1, sunUV);
    if (gDepthIsTex){ glActiveTexture(GL_TEXTURE1); glBindTexture(GL_TEXTURE_2D, gDepth); glUniform1i(uD, 1); glActiveTexture(GL_TEXTURE0); }
    glBindVertexArray(gVao); glDrawArrays(GL_TRIANGLES, 0, 3); glBindVertexArray(0);
    glDepthMask(GL_TRUE); glEnable(GL_DEPTH_TEST);
}

}   // namespace Post
