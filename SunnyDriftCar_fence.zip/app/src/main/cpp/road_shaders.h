// Sunny Drift - GLSL ES 3.00 shaders for the muddy road and its sand verge.
// Port of the HTML roadMat.onBeforeCompile (world-space "no puddle" mask, colour grading, wet roughness, bump map)
// and of the sand-verge material. Lighting uses the same sun / ambient / fog as the rest of this project.
#pragma once

static const char* ROAD_VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in vec2 uv; layout(location=2) in vec3 n;
uniform mat4 uVP;
out vec2 vUv; out vec3 vN; out vec3 wp;
void main(){ vUv = uv; vN = n; wp = p; gl_Position = uVP * vec4(p, 1.0); }
)GLSL";

static const char* ROAD_FS = R"GLSL(#version 300 es
precision highp float;
in vec2 vUv; in vec3 vN; in vec3 wp;
uniform sampler2D uCol1;   // rgb = colour, a = roughness   (road with puddles)
uniform sampler2D uCol2;   //                                (same road, puddle-free variant)
uniform sampler2D uHgt1;   // r = height (0.5 = road level)
uniform sampler2D uHgt2;
uniform vec3 uCam;
out vec4 o;

float rwH(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float rwN(vec2 p){ vec2 i = floor(p), f = fract(p); f = f*f*(3.0 - 2.0*f);
  return mix(mix(rwH(i), rwH(i + vec2(1, 0)), f.x), mix(rwH(i + vec2(0, 1)), rwH(i + vec2(1, 1)), f.x), f.y); }
float noW;
// height used for bump mapping: both height maps blended + a fine grit layer so the mud keeps detail up close
float hf(vec2 uv){ return mix(texture(uHgt1, uv).r, texture(uHgt2, uv).r, noW) + (texture(uHgt1, uv * 6.7).r - 0.5) * 0.16; }

void main(){
  vec2 rw = wp.xz;
  noW = smoothstep(0.46, 0.54, rwN(rw / 30.0) * 0.6 + rwN(rw / 11.0 + 3.7) * 0.4);   // 1 = hollows removed (about half the road)
  vec4 t1 = texture(uCol1, vUv), t2 = texture(uCol2, vUv);
  vec4 tx = mix(t1, t2, noW);
  vec3 alb = pow(tx.rgb, vec3(2.2));                                                  // sRGB -> linear
  alb *= 0.78;                                                                        // richer, darker earth
  float lm = dot(alb, vec3(0.3, 0.59, 0.11)); alb = mix(vec3(lm), alb, 1.3);
  { float tv = rwN(rw / 7.0) * 0.6 + rwN(rw / 2.2) * 0.4;
    vec3 hue = mix(vec3(1.06, 1.0, 0.90), vec3(0.94, 0.98, 1.06), rwN(rw / 19.0 + 5.1));
    alb *= hue * (0.84 + 0.32 * tv) * (0.94 + 0.12 * rwN(rw * 13.0)); }              // world-space colour variation: no visible tiling
  float rough = clamp(tx.a * 0.88, 0.08, 1.0);                                        // wet look: glossy road

  // bump map (three.js perturbNormalArb, bumpScale 2.2)
  vec3 N0 = normalize(vN);
  vec2 dSx = dFdx(vUv), dSy = dFdy(vUv);
  float bs = 2.2 * (1.0 - 0.85 * smoothstep(40.0, 160.0, length(uCam - wp)));                  // far away the fine bump would only shimmer
  float Hll = bs * hf(vUv), dBx = bs * hf(vUv + dSx) - Hll, dBy = bs * hf(vUv + dSy) - Hll;
  vec3 sX = dFdx(wp), sY = dFdy(wp), R1 = cross(sY, N0), R2 = cross(N0, sX);
  float fDet = dot(sX, R1);
  vec3 N = normalize(abs(fDet) * N0 - sign(fDet) * (dBx * R1 + dBy * R2));

  vec3 L = normalize(vec3(0.4, 0.8, 0.3)), V = normalize(uCam - wp), H = normalize(L + V);
  float d = max(dot(N, L), 0.0), smo = 1.0 - rough;
  float ex = mix(6.0, 500.0, smo * smo * smo);
  float s3 = smo * smo * smo;
  float spec = pow(max(dot(N, H), 0.0), ex) * (0.03 + 1.2 * s3);                    // sun glints on wet mud / puddles
  float fr = 0.04 + 0.96 * pow(1.0 - max(dot(N, V), 0.0), 5.0);
  vec3 sky = vec3(0.62, 0.80, 0.95);
  vec3 lin = alb * (0.35 + 0.75 * d) + vec3(spec) + pow(sky, vec3(2.2)) * fr * s3 * 0.55;   // sky mirrored mostly by puddles
  vec3 c = pow(lin, vec3(1.0 / 2.2));
  c = mix(c, sky, clamp(length(uCam - wp) / 2500.0, 0.0, 1.0));
  o = vec4(c, 1.0);
}
)GLSL";

static const char* VERGE_FS = R"GLSL(#version 300 es
precision highp float;
in vec2 vUv; in vec3 vN; in vec3 wp;
uniform sampler2D uTex; uniform vec3 uCam;
out vec4 o;
void main(){
  vec4 tx = texture(uTex, vUv);
  vec3 alb = pow(tx.rgb, vec3(2.2));
  vec3 N = normalize(vN);
  float d = max(dot(N, normalize(vec3(0.4, 0.8, 0.3))), 0.0);
  vec3 c = pow(alb * (0.35 + 0.75 * d), vec3(1.0 / 2.2));
  c = mix(c, vec3(0.62, 0.80, 0.95), clamp(length(uCam - wp) / 2500.0, 0.0, 1.0));
  o = vec4(c, tx.a);
}
)GLSL";
