package com.sunny.car;

import android.app.Activity;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MainActivity extends Activity {
    static { System.loadLibrary("car"); }
    static native void nInit(AssetManager am);
    static native void nResize(int w, int h);
    static native void nDraw();
    static native void nInput(int mask);
    static native float nSpeed();

    int mask = 0;   // 1=left 2=right 4=gas 8=brake 16=handbrake
    GLSurfaceView gl; TextView speed;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        gl = new GLSurfaceView(this);
        gl.setEGLContextClientVersion(3);
        gl.setEGLConfigChooser(8, 8, 8, 8, 24, 0);
        gl.setRenderer(new GLSurfaceView.Renderer() {
            public void onSurfaceCreated(GL10 g, EGLConfig c) { nInit(getAssets()); }
            public void onSurfaceChanged(GL10 g, int w, int h) { nResize(w, h); }
            public void onDrawFrame(GL10 g) { nDraw(); }
        });
        FrameLayout root = new FrameLayout(this);
        root.addView(gl);
        add(root, "<", 1, Gravity.BOTTOM | Gravity.START, 24, 24);
        add(root, ">", 2, Gravity.BOTTOM | Gravity.START, 24 + 150, 24);
        add(root, "GAS", 4, Gravity.BOTTOM | Gravity.END, 24, 24 + 110);
        add(root, "BRAKE", 8, Gravity.BOTTOM | Gravity.END, 24, 24);
        add(root, "HAND", 16, Gravity.BOTTOM | Gravity.END, 24 + 200, 24);
        speed = new TextView(this);
        speed.setTextColor(Color.WHITE); speed.setTextSize(26);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END);
        lp.setMargins(0, 20, 30, 0);
        root.addView(speed, lp);
        setContentView(root);
        final Handler h = new Handler();
        h.post(new Runnable() { public void run() {
            speed.setText((int) nSpeed() + " km/h"); h.postDelayed(this, 100); } });
    }

    void add(FrameLayout root, String text, final int bit, int grav, int mx, int my) {
        Button bt = new Button(this);
        bt.setText(text); bt.setAlpha(0.6f);
        bt.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent e) {
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN) mask |= bit;
                else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) mask &= ~bit;
                nInput(mask);
                return true;
            }
        });
        int w = (bit <= 2) ? 140 : 190, hh = 100;
        float d = getResources().getDisplayMetrics().density;
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int) (w * d), (int) (hh * d), grav);
        if ((grav & Gravity.START) != 0) lp.leftMargin = (int) (mx * d); else lp.rightMargin = (int) (mx * d);
        lp.bottomMargin = (int) (my * d);
        root.addView(bt, lp);
    }

    @Override protected void onPause() { super.onPause(); gl.onPause(); }
    @Override protected void onResume() { super.onResume(); gl.onResume(); }
}
