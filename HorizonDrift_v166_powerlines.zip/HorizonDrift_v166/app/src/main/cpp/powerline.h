// Horizon Drift - roadside POWER LINE: a row of wooden utility poles (crossarm + 3 ceramic insulators) beside every road,
// with 3 sagging (catenary) wires hanging between neighbouring poles.
//  * poles stand on the side of the road OPPOSITE to the street lamps, every ~42 m, 4.6 m outside the tarmac edge
//  * left out: near the river / bridges, the coast, the dirt track, junctions with other roads, houses, lamps
//  * all geometry is built once into ONE static vertex buffer, split into chunks (6 poles + their wires) that are drawn only when near the camera
//  * pure decoration (no collision): poles stand well off the driving line
#pragma once
#include <GLES3/gl3.h>
#include <algorithm>
#include <cmath>
#include <vector>
#include "fence.h"
#include "village.h"
#include "sun_light.h"
#include "quality.h"

namespace PowerLine {

static const double SPACING  = 42.0;     // distance between poles (m)
static const double OFFSET   = 4.6;      // pole distance from the tarmac edge (m)
static const double POLE_H   = 9.0;      // pole height (m)
static const double ARM_Y    = 8.35;     // crossarm height on the pole (m)
static const double ARM_HALF = 1.05;     // half length of the crossarm (m)
static const double SAG      = 0.85;     // how far the wires hang down in the middle of a span (m)
static const int    WSEG     = 9;        // straight pieces per wire span
static const int    CHUNK    = 6;        // poles per draw chunk

struct Chunk { uint32_t first = 0, count = 0; float cx = 0, cz = 0, r = 0; };
static std::vector<float>    gV;          // x y z  nx ny nz  r g b   (9 floats)
static std::vector<uint32_t> gI;
static std::vector<Chunk>    gChunks;
static GLuint gProg = 0, gVao = 0, gVbo = 0, gIbo = 0; static GLint uVP = -1, uCam = -1, uFar = -1; static bool gOk = false;

struct P3 { double x, y, z; };
static inline P3 sub(P3 a, P3 b){ return {a.x - b.x, a.y - b.y, a.z - b.z}; }
static inline P3 cross(P3 a, P3 b){ return {a.y*b.z - a.z*b.y, a.z*b.x - a.x*b.z, a.x*b.y - a.y*b.x}; }
static inline P3 norm(P3 a){ double l = std::sqrt(a.x*a.x + a.y*a.y + a.z*a.z); if (l < 1e-9) return {0, 1, 0}; return {a.x / l, a.y / l, a.z / l}; }

// ------------------------------------------------------------------ tiny emitters (everything goes straight into gV / gI)
static void vtx(P3 p, P3 n, float r, float g, float b){
    gV.push_back((float)p.x); gV.push_back((float)p.y); gV.push_back((float)p.z);
    gV.push_back((float)n.x); gV.push_back((float)n.y); gV.push_back((float)n.z);
    gV.push_back(r); gV.push_back(g); gV.push_back(b);
}
// tapered round tube from a (radius ra) to b (radius rb), `n` sides
static void tube(P3 a, P3 b, double ra, double rb, int n, float r, float g, float bl, bool caps = true){
    const P3 ax = norm(sub(b, a)); P3 u = std::fabs(ax.y) < 0.95 ? norm(cross(ax, {0, 1, 0})) : P3{1, 0, 0}; const P3 v = norm(cross(ax, u));
    const uint32_t base = (uint32_t)(gV.size() / 9);
    for (int i = 0; i < n; i++){
        const double th = i * 6.283185307 / n, c = std::cos(th), s = std::sin(th);
        const P3 d = {u.x * c + v.x * s, u.y * c + v.y * s, u.z * c + v.z * s};
        vtx({a.x + d.x * ra, a.y + d.y * ra, a.z + d.z * ra}, d, r, g, bl);
        vtx({b.x + d.x * rb, b.y + d.y * rb, b.z + d.z * rb}, d, r, g, bl);
    }
    for (int i = 0; i < n; i++){
        const uint32_t a0 = base + i * 2, a1 = a0 + 1, b0 = base + ((i + 1) % n) * 2, b1 = b0 + 1;
        gI.insert(gI.end(), {a0, b0, a1, a1, b0, b1});
    }
    if (caps) for (int e = 0; e < 2; e++){
        const P3 c0 = e ? b : a, nn = e ? ax : P3{-ax.x, -ax.y, -ax.z}; const double rr = e ? rb : ra; if (rr <= 0) continue;
        const uint32_t ctr = (uint32_t)(gV.size() / 9); vtx(c0, nn, r, g, bl);
        const uint32_t r0 = (uint32_t)(gV.size() / 9);
        for (int i = 0; i < n; i++){ const double th = i * 6.283185307 / n, c = std::cos(th), s = std::sin(th); vtx({c0.x + (u.x*c + v.x*s) * rr, c0.y + (u.y*c + v.y*s) * rr, c0.z + (u.z*c + v.z*s) * rr}, nn, r, g, bl); }
        for (int i = 0; i < n; i++){ const uint32_t p0 = r0 + i, p1 = r0 + (i + 1) % n; if (e) gI.insert(gI.end(), {p0, p1, ctr}); else gI.insert(gI.end(), {p1, p0, ctr}); }
    }
}
// oriented box: centre c, half sizes (hx along `ex`, hy along up, hz along `ez`)
static void obox(P3 c, P3 ex, P3 ez, double hx, double hy, double hz, float r, float g, float b){
    const P3 ey = {0, 1, 0};
    static const int S[6][3] = {{1,0,0},{-1,0,0},{0,1,0},{0,-1,0},{0,0,1},{0,0,-1}};
    for (int f = 0; f < 6; f++){
        const P3 n = {ex.x*S[f][0] + ey.x*S[f][1] + ez.x*S[f][2], ex.y*S[f][0] + ey.y*S[f][1] + ez.y*S[f][2], ex.z*S[f][0] + ey.z*S[f][1] + ez.z*S[f][2]};
        // two tangent axes of this face
        P3 t1, t2; double h1, h2;
        if (S[f][0]) { t1 = ey; h1 = hy; t2 = ez; h2 = hz; } else if (S[f][1]) { t1 = ex; h1 = hx; t2 = ez; h2 = hz; } else { t1 = ex; h1 = hx; t2 = ey; h2 = hy; }
        const double hn = S[f][0] ? hx : (S[f][1] ? hy : hz);
        const P3 fc = {c.x + n.x * hn, c.y + n.y * hn, c.z + n.z * hn}; const uint32_t base = (uint32_t)(gV.size() / 9);
        for (int a = -1; a <= 1; a += 2) for (int bb = -1; bb <= 1; bb += 2)
            vtx({fc.x + t1.x * h1 * a + t2.x * h2 * bb, fc.y + t1.y * h1 * a + t2.y * h2 * bb, fc.z + t1.z * h1 * a + t2.z * h2 * bb}, n, r, g, b);
        gI.insert(gI.end(), {base, base + 1, base + 2, base + 1, base + 3, base + 2, base, base + 2, base + 1, base + 1, base + 2, base + 3});   // both windings: never culled / flipped
    }
}

// one pole: tapered wooden trunk, crossarm + 2 braces, 3 insulators.  `tx,tz` = road direction (unit), ground height gy.
// Returns the 3 wire attachment points (above each insulator).
static void pole(double px, double pz, double gy, double tx, double tz, P3 out[3]){
    const double nx = -tz, nz = tx;                                                              // across the road
    const double v = 0.30;
    tube({px, gy - 0.3, pz}, {px, gy + POLE_H, pz}, 0.16, 0.115, 10, 0.34f * (float)(v / 0.30), 0.25f, 0.17f);        // trunk (dark creosoted wood)
    { const P3 a = {px, gy + 0.0, pz}, b = {px, gy + 0.55, pz}; tube(a, b, 0.175, 0.175, 10, 0.20f, 0.19f, 0.17f); } // darker ground sleeve
    const P3 ex = {nx, 0, nz}, ez = {tx, 0, tz}; const double ay = gy + ARM_Y;
    obox({px, ay, pz}, ex, ez, ARM_HALF, 0.055, 0.055, 0.40f, 0.30f, 0.21f);                                           // crossarm
    for (int s = -1; s <= 1; s += 2){                                                             // diagonal braces from the trunk to the arm
        tube({px, ay - 0.80, pz}, {px + nx * s * 0.62, ay - 0.04, pz + nz * s * 0.62}, 0.022, 0.022, 5, 0.30f, 0.28f, 0.27f);
    }
    obox({px, gy + POLE_H + 0.07, pz}, ex, ez, 0.06, 0.07, 0.06, 0.36f, 0.27f, 0.19f);                                   // top cap
    static const double slot[3] = {-0.95, 0.0, 0.95};
    for (int k = 0; k < 3; k++){
        const double off = slot[k], bx = px + nx * off, bz = pz + nz * off, by = (k == 1 ? ay + 0.52 : ay);                // middle wire sits on top of the pole
        if (k == 1){ tube({px, gy + POLE_H - 0.10, pz}, {px, by + 0.06, pz}, 0.03, 0.03, 5, 0.30f, 0.30f, 0.30f); }
        tube({bx, by + 0.04, bz}, {bx, by + 0.22, bz}, 0.050, 0.030, 8, 0.78f, 0.74f, 0.66f);                                // ceramic insulator
        tube({bx, by + 0.22, bz}, {bx, by + 0.30, bz}, 0.032, 0.012, 8, 0.80f, 0.76f, 0.68f);
        out[k] = {bx, by + 0.31, bz};
    }
}
// sagging wire between a and b (catenary-like parabola)
static void wire(P3 a, P3 b, double sag){
    P3 prev = a;
    for (int i = 1; i <= WSEG; i++){
        const double t = (double)i / WSEG; P3 q = {a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t - sag * 4.0 * t * (1.0 - t), a.z + (b.z - a.z) * t};
        tube(prev, q, 0.022, 0.022, 4, 0.045f, 0.045f, 0.05f, false); prev = q;
    }
}

struct Pl { double x, z, gy, tx, tz; bool ok; };

static void build(){
    if (gOk) return;
    const std::vector<const Road::Curve*> ROADS = Road::all(); const int NRD = (int)ROADS.size();
    // road samples (to keep clear of OTHER roads at junctions)
    std::vector<std::vector<double>> pts(NRD);
    for (int r = 0; r < NRD; r++){ const Road::Curve& cv = *ROADS[r]; const int n = std::max(8, (int)std::ceil(cv.length() / 3.0));
        for (int k = 0; k <= n; k++){ Road::V3 p = cv.getPointAt(cv.open ? std::min((double)k / n, 0.99999) : (double)(k % n) / n); pts[r].push_back(p.x); pts[r].push_back(p.z); } }
    auto nearOther = [&](double x, double z, int ci){ for (int r = 0; r < NRD; r++){ if (r == ci) continue; const double lim = ROADS[r]->hw + 12.0, l2 = lim * lim; const auto& a = pts[r];
        for (size_t k = 0; k < a.size(); k += 2){ const double dx = x - a[k], dz = z - a[k+1]; if (dx*dx + dz*dz < l2) return true; } } return false; };
    auto blocked = [&](double x, double z, int ci){
        if (std::fabs(River::riverSd(x, z)) < 34.0) return true;                                  // river banks + bridges
        if (Terrain::trackDist(x, z) < 16.0 || Terrain::coastDist(x, z) > -52.0) return true;      // dirt track, coast
        if (nearOther(x, z, ci)) return true;
        for (const Village::Building& b : Village::gB){ const double dx = x - b.x, dz = z - b.z; if (dx*dx + dz*dz < 14.0 * 14.0) return true; }
        for (const Fence::Lamp& l : Fence::gLamps){ const double dx = x - l.x, dz = z - l.z; if (dx*dx + dz*dz < 5.0 * 5.0) return true; }
        return false; };

    for (int ci = 0; ci < NRD; ci++){
        const Road::Curve& cv = *ROADS[ci]; const double L = cv.length(); const int n = std::max(2, (int)std::floor(L / SPACING)); const bool closed = !cv.open; const int cnt = closed ? n : n + 1;
        // side = the one the street lamps do NOT use (they go on the side where nx*p.x + nz*p.z >= 0)
        std::vector<Pl> row; row.reserve(cnt);
        for (int k = 0; k < cnt; k++){
            const double t = closed ? (double)k / n : std::min((double)k / n, 0.99999); Road::V3 p = cv.getPointAt(t), tg = cv.getTangentAt(t);
            double tl = std::hypot(tg.x, tg.z); if (tl < 1e-9) tl = 1; const double tx = tg.x / tl, tz = tg.z / tl; double nx = -tz, nz = tx;
            if (nx * p.x + nz * p.z > 0){ nx = -nx; nz = -nz; }                                  // lamps are on the +side, so we take the other one
            const double d = cv.hw + OFFSET, x = p.x + nx * d, z = p.z + nz * d;
            Pl q; q.x = x; q.z = z; q.gy = Terrain::fieldH(x, z); q.tx = tx; q.tz = tz; q.ok = !blocked(x, z, ci);
            row.push_back(q);
        }
        // chunks: CHUNK poles + the wire spans that join them to the next pole (so a chunk always contains whole spans)
        for (int k0 = 0; k0 < cnt; k0 += CHUNK){
            Chunk ch; ch.first = (uint32_t)gI.size(); double sx = 0, sz = 0; int m = 0; double minx = 1e18, maxx = -1e18, minz = 1e18, maxz = -1e18;
            const int k1 = std::min(cnt, k0 + CHUNK);
            for (int k = k0; k < k1; k++){
                const Pl& a = row[k]; if (!a.ok) continue;
                P3 pa[3]; pole(a.x, a.z, a.gy, a.tx, a.tz, pa);
                sx += a.x; sz += a.z; m++; minx = std::min(minx, a.x); maxx = std::max(maxx, a.x); minz = std::min(minz, a.z); maxz = std::max(maxz, a.z);
                const int kn = (k + 1 < cnt) ? k + 1 : (closed ? 0 : -1);
                if (kn < 0) continue; const Pl& b = row[kn]; if (!b.ok) continue;
                const double dd = std::hypot(b.x - a.x, b.z - a.z); if (dd > SPACING * 1.8 || dd < 3.0) continue;                // never a wire across a gap / a closed-loop seam glitch
                P3 pb[3]; const size_t sv = gV.size(), si = gI.size();
                pole(b.x, b.z, b.gy, b.tx, b.tz, pb);                                                                          // (only to get b's attachment points)
                gV.resize(sv); gI.resize(si);                                                                                  // ... its geometry is emitted when its own turn comes
                for (int w = 0; w < 3; w++) wire(pa[w], pb[w], SAG * (dd / SPACING) * (dd / SPACING) * (w == 1 ? 1.05 : 1.0));
            }
            if (!m) continue;
            ch.count = (uint32_t)(gI.size() - ch.first); if (!ch.count) continue;
            ch.cx = (float)(sx / m); ch.cz = (float)(sz / m);
            ch.r = (float)(std::hypot(maxx - minx, maxz - minz) * 0.5 + SPACING + 12.0); gChunks.push_back(ch);
        }
    }
}

static const char* VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in vec3 n; layout(location=2) in vec3 c;
uniform mat4 uVP; out vec3 vn; out vec3 wp; out vec3 vc;
void main(){ wp = p; vn = n; vc = c; gl_Position = uVP * vec4(p, 1.0); }
)GLSL";
static const char* FS = R"GLSL(#version 300 es
precision highp float;
in vec3 vn; in vec3 wp; in vec3 vc; uniform vec3 uCam; out vec4 o;
void main(){
  vec3 N = normalize(vn); if (!gl_FrontFacing) N = -N;
  vec3 base = pow(vc, vec3(2.2));
  vec3 L = SUNL; float d = max(dot(N, L), 0.0), wrap = max(dot(N, L) * 0.5 + 0.5, 0.0);
  vec3 amb = mix(vec3(0.20, 0.18, 0.13), vec3(0.32, 0.39, 0.50), N.y * 0.5 + 0.5);
  vec3 sun = vec3(1.0, 0.93, 0.78);
  vec3 lit = base * (amb + sun * (0.78 * d + 0.12 * wrap));
  vec3 c = pow(lit, vec3(1.0 / 2.2));
  c = mix(c, vec3(0.62, 0.80, 0.95), clamp(length(uCam - wp) / 3750.0, 0.0, 1.0));
  o = vec4(c, 1.0);
}
)GLSL";

static GLuint sh(GLenum t, const char* s){ GLuint x = glCreateShader(t); SunLight::shaderSource(x, s); glCompileShader(x); return x; }

// call once with a current GL context, after Fence::init() (needs the road + lamp layout)
static void init(){
    if (gOk) return;
    build(); if (gI.empty()) return;
    gProg = glCreateProgram(); glAttachShader(gProg, sh(GL_VERTEX_SHADER, VS)); glAttachShader(gProg, sh(GL_FRAGMENT_SHADER, FS)); glLinkProgram(gProg); SunLight::attach(gProg);
    uVP = glGetUniformLocation(gProg, "uVP"); uCam = glGetUniformLocation(gProg, "uCam");
    glGenVertexArrays(1, &gVao); glBindVertexArray(gVao);
    glGenBuffers(1, &gVbo); glBindBuffer(GL_ARRAY_BUFFER, gVbo); glBufferData(GL_ARRAY_BUFFER, gV.size() * 4, gV.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 36, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 36, (void*)12);
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 36, (void*)24);
    glGenBuffers(1, &gIbo); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gIbo); glBufferData(GL_ELEMENT_ARRAY_BUFFER, gI.size() * 4, gI.data(), GL_STATIC_DRAW);
    glBindVertexArray(0);
    std::vector<float>().swap(gV); std::vector<uint32_t>().swap(gI);                              // CPU copies are no longer needed
    gOk = true;
}

static void draw(const float* VP, const float* eye){
    if (!gOk) return;
    const float far_ = 330.f * Quality::distScale(); const float f2 = far_ * far_;
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glDisable(GL_BLEND);
    glUseProgram(gProg); glUniformMatrix4fv(uVP, 1, GL_FALSE, VP); glUniform3fv(uCam, 1, eye);
    glBindVertexArray(gVao);
    for (const Chunk& c : gChunks){
        const float dx = c.cx - eye[0], dz = c.cz - eye[2], lim = far_ + c.r;
        if (dx * dx + dz * dz > lim * lim) continue; (void)f2;
        glDrawElements(GL_TRIANGLES, (GLsizei)c.count, GL_UNSIGNED_INT, (void*)(uintptr_t)(c.first * 4));
    }
    glBindVertexArray(0);
}

} // namespace PowerLine
