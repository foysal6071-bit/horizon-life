// Sunny Drift - GLSL ES 3.00 shaders for the asphalt road (procedural tarmac + lane paint) and its gravel shoulder.
// Port of the HTML roadMat.onBeforeCompile (world-space "no puddle" mask, colour grading, wet roughness, bump map)
// and of the sand-verge material. Lighting uses the same sun / ambient / fog as the rest of this project.
#pragma once
#include "env_glsl.h"

static const char* ROAD_VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in vec2 uv; layout(location=2) in vec3 n; layout(location=3) in vec2 aux;
uniform mat4 uVP;
out vec2 vUv; out vec3 vN; out vec3 wp; out vec2 vAux;
void main(){ vUv = uv; vN = n; wp = p; vAux = aux; gl_Position = uVP * vec4(p, 1.0); }
)GLSL";

static const char* ROAD_FS = R"GLSL(#version 300 es
precision highp float;
in vec2 vUv; in vec3 vN; in vec3 wp; in vec2 vAux;   // vUv.x = metres from the centre line, vUv.y = road half width, vAux.x = metres along the road, vAux.y = bend curvature (1 / radius)
uniform vec3 uCam;
uniform float uEndR, uEndL;   // connector road: no lane paint within uEndR metres (along the road) of either end = the junction mouths; uEndL = its length (uEndR = 0 elsewhere)
uniform sampler2D uNoise;   // 256x256 RGBA white noise (1 texel = 1 stone chip at scale 1), mipmapped -> detail fades by itself, no shimmer
uniform sampler2D uFbm;     // 256x256 RGBA tileable fbm (4 independent channels), smooth large-scale variation
uniform vec3 uPk;   // summit parking ring: centre x, z, radius (0 = none)
uniform float uLite;   // 1 on the Low graphics level: the detail tier ends at ~half the distance
uniform float uWet, uRip, uSunK, uClk; uniform vec3 uRef, uSunD;   // weather: wetness, rain ripples, golden light, clock, reflection tint, direction to the sun
out vec4 o;

// value-noise lookups: 1 texture fetch each. They use textureGrad with the screen derivatives of the world position taken once at the top, so they may sit inside
// the distance branches below (far pixels skip most of them) without breaking the derivative rules.
vec2 gX, gY;
vec4 aTg(vec2 p, float sc){ return textureGrad(uNoise, p * (1.0 / 256.0), gX * (sc / 256.0), gY * (sc / 256.0)); }
vec4 aFg(vec2 p, float sc){ return textureGrad(uFbm, p, gX * sc, gY * sc); }
)GLSL" ENV_GLSL R"GLSL(
// anti-aliased painted stripe: coverage of a line of half width hwl centred on c (metres across the road)
float stripe(float x, float c, float hwl, float aa){ return clamp((hwl - abs(x - c)) / aa + 0.5, 0.0, 1.0); }

void main(){
  vec2 rw = wp.xz; gX = dFdx(rw); gY = dFdy(rw);
  vec3 toCam = uCam - wp;
  float dist = length(toCam);
  float u = vUv.x, hw = vUv.y;
  float sEnd = uEndR > 0.0 ? min(vAux.x, uEndL - vAux.x) : 1e4;                       // connector: metres to the nearest junction
  float jn = smoothstep(6.0, 8.0, sEnd);                                              // 0 on the ring road itself (the connector only overlays it there), 1 outside the junction
  float edgeD = mix(6.0, hw - abs(u), jn);                                            // metres to the nearest road edge (no edge wear on the part that lies on the ring road)
  float aa = max(fwidth(u) * 1.0, 0.0007), aaS = max(fwidth(vAux.x) * 1.0, 0.0007);
  float sc = uLite > 0.5 ? 0.5 : 1.0;                                                  // detail distance scale (Low level = half)
  float w3 = 1.0 - smoothstep(2.5 * sc, 11.0 * sc, dist), w2 = 1.0 - smoothstep(6.0 * sc, 28.0 * sc, dist);   // fine chip detail fades sooner: it only shimmers once it gets close to the pixel size
  bool nearPix = dist < 38.0 * sc;
  bool farPix = dist > 230.0 * sc;                                                    // very far: the big soft patches are sub-pixel, skip their fetches
                                                          // detail tier: everything below fades to nothing by 90 m, so the switch is invisible

  // ---- asphalt: stone chips (3 scales from the baked noise), large patches, repair tone ----
  float g1 = aTg(rw * 9.0, 9.0).r, g2 = 0.5, g3 = 0.5;
  if (nearPix){ g2 = aTg(rw * 37.0 + 13.7, 37.0).g; g3 = aTg(rw * 140.0 + 41.3, 140.0).b; }
  float grain = 0.5 + (g1 - 0.5) * 0.5 + (g2 - 0.5) * 0.45 * w2 + (g3 - 0.5) * 0.5 * w3;
  vec4 f1 = aFg(rw / 56.0, 1.0 / 56.0), f2 = vec4(0.5), f3 = vec4(0.5);
  if (!farPix){ f2 = aFg(rw / 360.0 + 0.31, 1.0 / 360.0); f3 = aFg(rw / 152.0 + 0.57, 1.0 / 152.0); }
  float pat = f1.r, big = f2.g;
  float repair = smoothstep(0.58, 0.64, f3.b);                                        // a few darker, fresher patches
  vec3 alb = L2(vec3(0.50, 0.51, 0.525));                                             // light alpine-pass grey
  alb *= (0.88 + 0.24 * grain) * (0.95 + 0.10 * pat) * (0.97 + 0.06 * big);   // smoother, freshly laid surface
  alb *= mix(1.0, 0.92, repair);

  // ---- wear: polished wheel paths, dust on the edges, weeds in the edge cracks, hairline + sealed cracks ----
  float lane = abs(abs(u) - hw * 0.5);                                                // distance from a lane centre
  float wheel = exp(-pow((lane - 0.85) / 0.42, 2.0)) * (0.55 + 0.45 * f1.g) * jn;
  float wheel2 = exp(-pow(lane / 0.30, 2.0)) * 0.5 * f2.b * jn;                            // oil drip between the wheels
  alb *= 1.0 - 0.06 * wheel - 0.04 * wheel2;
  float dustN = 0.5; if (!farPix) dustN = aTg(rw * 1.7, 1.7).a;
  float dust = (1.0 - smoothstep(0.0, 1.6, edgeD)) * (0.35 + 0.65 * dustN);
  alb = mix(alb, L2(vec3(0.50, 0.49, 0.46)), 0.12 * dust);                          // sand / earth washed onto the tarmac
  alb = mix(alb, L2(vec3(0.34, 0.31, 0.27)), (1.0 - smoothstep(0.0, 0.25, edgeD)) * 0.18);   // faint rim
  float crack = 0.0, seal = 0.0;
  if (nearPix){
    vec4 f4 = aFg(rw / 224.0 + 0.83, 1.0 / 224.0);
    vec2 wq = rw * 0.1 + 0.6 * (aTg(rw * 2.3 + 5.0, 2.3).rg - 0.5);
    crack = (1.0 - smoothstep(0.0, 0.040, abs(aFg(wq, 0.1).a - 0.5))) * smoothstep(0.52, 0.72, f4.r) * (1.0 - smoothstep(6.0 * sc, 22.0 * sc, dist));
    // sealed cracks ("tar snakes"): long, thin, slightly glossy black lines the road crews pour over old cracks
    vec2 sq = rw * 0.06 + 0.9 * (aTg(rw * 0.7 + 9.0, 0.7).rg - 0.5);
    seal = (1.0 - smoothstep(0.0, 0.016, abs(aFg(sq, 0.06).b - 0.5))) * smoothstep(0.50, 0.66, f3.r) * (1.0 - smoothstep(7.0 * sc, 26.0 * sc, dist));
    // weeds / moss creeping in from the verge where the edge has broken up (only in some stretches)
    float weed = (1.0 - smoothstep(0.04, 0.12 + 0.55 * aTg(rw * 3.1 + 7.7, 3.1).b, edgeD)) * smoothstep(0.56, 0.70, f2.r) * (1.0 - smoothstep(15.0 * sc, 55.0 * sc, dist));
    alb = mix(alb, L2(vec3(0.20, 0.25, 0.10)) * (0.8 + 0.4 * g3), 0.10 * weed);
  }
  alb *= 1.0 - 0.15 * crack;
  alb *= 1.0 - 0.20 * seal;

  // ---- lane paint: white edge lines + yellow centre line. Dashed (passing allowed) on straight stretches, solid double in bends / no-passing zones ----
  float zone = floor(vAux.x / 140.0), zh = fract(sin(zone * 12.9898 + 4.1) * 43758.5453);
  float passOK = step(0.38, zh) * (1.0 - smoothstep(1.0 / 320.0, 1.0 / 200.0, vAux.y));
  float dashCov = stripe(mod(vAux.x + 2.0, 12.0), 6.0, 2.0, aaS);                     // 4 m of paint, 8 m gap (like the alpine road)
  float cl = max(stripe(u, 0.0, 0.07, aa), 0.0);
  float yel = cl * mix(1.0, dashCov, max(passOK, 1.0 - smoothstep(1.0 / 320.0, 1.0 / 200.0, vAux.y)));   // single centre line: dashed on straights, solid in tight bends
  float whi = max(stripe(u, hw - 0.35, 0.09, aa), stripe(u, -(hw - 0.35), 0.09, aa));
  float mask = uEndR > 0.0 ? smoothstep(uEndR, uEndR + 1.5, sEnd) : 1.0;     // measured along the road, so the flared fillets are covered too
  float wornN = 0.5; if (!farPix) wornN = aFg(rw / 20.8 + 0.4, 1.0 / 20.8).g;
  float worn = 1.0 - 0.12 * smoothstep(0.50, 0.78, wornN) - 0.05 * wheel;     // paint scuffed off, chips showing through
  float chip = 0.80 + 0.20 * smoothstep(0.25, 0.60, mix(0.5, grain, w2));
  float py = yel * mask * worn * chip, pw = whi * mask * worn * chip;
  alb = mix(alb, L2(vec3(0.90, 0.91, 0.90)) * (0.92 + 0.08 * pat), py);             // white centre line
  alb = mix(alb, L2(vec3(0.92, 0.93, 0.92)) * (0.92 + 0.08 * pat), pw);             // traffic white
  float pk = 0.0;                                                                     // PARKING_AREA: painted bays along the outer side of the summit ring
  if (uPk.z > 0.0){
    vec2 q = wp.xz - uPk.xy; float d = length(q), nb = floor(6.2831853 * uPk.z / 3.2), cell = abs(fract(atan(q.y, q.x) / 6.2831853 * nb + 0.5) - 0.5) * 6.2831853 * d / nb;
    float aaP = max(fwidth(d), 0.02), inB = step(uPk.z + 1.0, d) * step(d, uPk.z + 6.6);
    pk = max(inB * (1.0 - smoothstep(0.05, 0.05 + aaP, cell)), (1.0 - smoothstep(0.06, 0.06 + aaP, abs(d - (uPk.z + 1.0)))) * step(d, uPk.z + 6.8));
  }
  alb = mix(alb, L2(vec3(0.92, 0.93, 0.92)), pk * 0.95);
  float paint = max(max(py, pw), pk);
  float rough = clamp(0.90 - 0.12 * wheel - 0.10 * paint - 0.25 * seal, 0.5, 1.0);

  // ---- wet road (weather): darker asphalt, glossy sheen, standing puddles in the wheel ruts ----
  float pud = 0.0;
  if (uWet > 0.001){
    float pn = aFg(rw / 31.0 + 0.19, 1.0 / 31.0).r * 0.65 + aFg(rw / 9.0 + 0.71, 1.0 / 9.0).g * 0.35;
    pud = smoothstep(0.54 - 0.07 * wheel, 0.61 - 0.07 * wheel, pn) * uWet * (1.0 - smoothstep(0.0, 0.5, edgeD) * 0.8) * (1.0 - smoothstep(60.0, 220.0, dist) * 0.6);
    alb *= mix(1.0, 0.58, uWet);
    alb *= mix(1.0, 0.55, pud);
    rough = mix(rough, 0.16, uWet * 0.85);
    rough = mix(rough, 0.03, pud);
  }

  // ---- micro relief -> bump. Derivatives are taken unconditionally (H is 0 beyond 90 m anyway, no extra fetches there) ----
  float H = (g1 - 0.5) * 0.010 + (g2 - 0.5) * 0.006 * w2 + (g3 - 0.5) * 0.004 * w3 - crack * 0.012 - seal * 0.004 + paint * 0.0015;
  H *= 1.0 - smoothstep(3.0 * sc, 14.0 * sc, dist);   // micro bump only right under the car: further out it crawls / glitters
  vec3 N0 = normalize(vN);
  vec3 sX = dFdx(wp), sY = dFdy(wp), R1 = cross(sY, N0), R2 = cross(N0, sX);
  float fDet = dot(sX, R1);
  vec3 N = normalize(abs(fDet) * N0 - sign(fDet) * (dFdx(H) * R1 + dFdy(H) * R2) * 4.0);
  if (pud > 0.001){
    N = normalize(mix(N, N0, clamp(pud * 1.2, 0.0, 1.0)));                            // standing water is flat
    if (uRip > 0.001 && dist < 60.0){                                                 // rain: expanding rings on the puddles
      vec2 gq = rw * 1.7; vec2 gid = floor(gq), fr = fract(gq) - 0.5;
      vec4 hq = texelFetch(uNoise, ivec2(mod(gid, 256.0)), 0);
      vec2 cc = (hq.rg - 0.5) * 0.6; float ph = fract(uClk * (0.8 + 0.5 * hq.b) + hq.a);
      vec2 dv = fr - cc; float rr = length(dv), q = rr - ph * 0.45;
      float qq = q * 14.0; float ring = exp(-qq * qq) * (1.0 - ph) * step(0.45, hq.b);
      vec2 dir = dv / max(rr, 1e-3);
      N = normalize(N + vec3(dir.x, 0.0, dir.y) * ring * 0.55 * uRip * pud * (1.0 - smoothstep(25.0, 60.0, dist)));
    }
  }

  vec3 L = SUNL, V = toCam / dist, Hh = normalize(L + V);
  float d = max(dot(N, L), 0.0), smo = 1.0 - rough;
  float NoV = max(dot(N, V), 1e-3);
  float spec = pow(max(dot(N, Hh), 0.0), mix(6.0, 120.0, smo * smo * 4.0)) * (0.02 + 0.5 * smo * smo * smo);   // dry tarmac: faint sheen
  // sky reflection: full analytic env only close to the car; far away a cheap fresnel-weighted sky tint
  vec3 refl;
  vec3 Rf = reflect(-V, N);
  if (dist < 70.0 * sc){ vec2 ab = envBRDF(rough, NoV); refl = envC(Rf, rough) * (0.04 * ab.x + ab.y); }
  else { float fr = 0.04 + 0.96 * pow(1.0 - NoV, 5.0); refl = L2(vec3(0.62, 0.78, 0.95)) * fr * (1.0 - rough * 0.5); }
  // grazing-angle sheen: real tarmac turns glossy towards the horizon
  float graze = pow(1.0 - NoV, 4.0) * 0.12;
  float rl = dot(refl, vec3(0.299, 0.587, 0.114));
  refl = mix(refl, vec3(rl) * 0.85, uRip * 0.7) * uRef;                                // grey rainy sky / golden sky in the reflection
  float rScale = 0.32 + uWet * 0.30 + pud * 0.75;
  vec3 glint = vec3(1.0, 0.62, 0.28) * pow(max(dot(Rf, uSunD), 0.0), mix(60.0, 600.0, 1.0 - rough)) * uSunK * uWet * (1.2 + 2.5 * pud);   // low sun glittering on the wet tarmac
  vec3 lin = alb * (0.35 + 0.75 * d) + vec3(spec) + refl * rScale + glint + L2(vec3(0.7, 0.8, 0.95)) * graze * (1.0 - smoothstep(60.0, 400.0, dist)) * 0.5;
  vec3 c = pow(lin, vec3(1.0 / 2.2));
  c = mix(c, vec3(0.62, 0.80, 0.95), clamp(dist / 3750.0, 0.0, 1.0));
  o = vec4(c, 1.0);
}
)GLSL";

static const char* VERGE_FS = R"GLSL(#version 300 es
precision highp float;
in vec2 vUv; in vec3 vN; in vec3 wp;
uniform sampler2D uTex; uniform sampler2D uNoise; uniform vec3 uCam; uniform float uWet;
out vec4 o;
void main(){
  vec4 tx = texture(uTex, vUv);
  float dist = length(uCam - wp);
  vec3 soil = pow(tx.rgb, vec3(2.2));
  // asphalt shoulder: grey-tan gravel and dust (noise from the baked texture: 3 fetches instead of 12 sin-hashes)
  vec3 nz = vec3(0.5);
  if (dist < 140.0) nz = vec3(texture(uNoise, wp.xz * (5.0 / 256.0)).r, texture(uNoise, wp.xz * (31.0 / 256.0)).g, texture(uNoise, wp.xz * (1.0 / 6.0 / 256.0)).b);   // far shoulder: flat average tone, no fetches
  float gr = 0.75 + 0.3 * nz.x + 0.2 * nz.y * (1.0 - smoothstep(10.0, 50.0, dist));
  // realistic roadside: u = vUv.x runs from the tarmac edge (0) out to the meadow (1)
  float e = vUv.x;
  float fine = (dist < 140.0) ? nz.y : 0.5;
  vec3 gravel = pow(vec3(0.47, 0.45, 0.41), vec3(2.2)) * gr * (0.85 + 0.3 * nz.z);
  gravel *= 1.0 + 0.55 * step(0.84, fine) - 0.35 * step(fine, 0.14);                         // loose light stones + dark pits in the gravel
  vec3 dirt = mix(soil, pow(vec3(0.36, 0.28, 0.19), vec3(2.2)), 0.55) * (0.8 + 0.4 * nz.x);   // bare earth
  vec3 grassA = pow(vec3(0.20, 0.38, 0.10), vec3(2.2));                                      // lush, dark
  vec3 grassB = pow(vec3(0.42, 0.48, 0.17), vec3(2.2));                                      // sun-dried
  vec3 grass = mix(grassA, grassB, smoothstep(0.35, 0.8, nz.z)) * (0.62 + 0.75 * nz.x) * (0.8 + 0.4 * fine);   // clumps, blades, dry patches
  float rag = (nz.z - 0.5) * 0.26 + (nz.x - 0.5) * 0.12;                                      // ragged, irregular boundaries
  float gMask = 1.0 - smoothstep(0.26, 0.46, e + rag);                                        // gravel shoulder next to the tarmac
  float dMask = (1.0 - smoothstep(0.42, 0.78, e + rag * 1.6)) * 0.65;                         // bare earth patches fading into the grass
  vec3 alb = mix(grass, dirt, dMask);
  alb = mix(alb, gravel, gMask);
  alb *= mix(0.74, 1.0, smoothstep(0.08, 0.30, e));                                           // dust / oil darkening right at the edge of the asphalt
  alb *= mix(1.0, 0.62, uWet);                                                          // wet shoulder
  vec3 N = normalize(vN);
  float d = max(dot(N, SUNL), 0.0);
  vec3 c = pow(alb * (0.35 + 0.75 * d), vec3(1.0 / 2.2));
  c = mix(c, vec3(0.62, 0.80, 0.95), clamp(dist / 3750.0, 0.0, 1.0));
  o = vec4(c, tx.a);
}
)GLSL";
