// Sunny Drift - green tree: C++ port of parseTreeMini() / makeTreeProto() from the HTML game.
// Pure C++ (no OpenGL): decodes the compact tree blob into two meshes (leaves + bark).
#pragma once
#include <functional>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <sstream>
#include <string>
#include <vector>

namespace TreeModel {

const float TREE_SCALE = 1.25f;   // the model is ~6.7 m tall; each planted tree is then scaled 0.8x-1.7x on top of this

struct Meta {
    int nl = 0, nc = 0, R = 0, nrc = 0, nrv = 0, nrt = 0, t0 = 0, t1 = 0;
    double llo[3], lhi[3], glo[3], rlo[3], rhi[3], vc[4];
    double As = 0, QC = 0, QR = 0, gus = 0, u0lo = 0, u0hi = 0;
};

inline bool parseMeta(const std::string& text, Meta& M){
    std::istringstream s(text);
    s >> M.nl >> M.nc >> M.R >> M.nrc >> M.nrv >> M.nrt >> M.t0 >> M.t1;
    for (double& v : M.llo) s >> v;
    for (double& v : M.lhi) s >> v;
    for (double& v : M.glo) s >> v;
    for (double& v : M.rlo) s >> v;
    for (double& v : M.rhi) s >> v;
    for (double& v : M.vc)  s >> v;
    s >> M.As >> M.QC >> M.QR >> M.gus >> M.u0lo >> M.u0hi;
    return (bool)s;
}

struct Mesh {
    std::vector<float> pos, nrm, uv;     // 3, 3, 2 floats per vertex
    std::vector<uint16_t> idx;
    int vertexCount() const { return (int)(pos.size() / 3); }
};

struct Model {
    Mesh leaf, bark;
    float minY = 0, maxY = 0, halfWidth = 0;   // bounds of the scaled model (used for the far billboard)
};

// raw = the inflated blob (geometry first, then the two textures; only the geometry part is read here)
inline bool parse(const uint8_t* raw, size_t size, const Meta& M, Model& out){
    size_t o = 0; bool ok = true;
    auto U8 = [&](size_t n) -> const uint8_t* { if (o + n > size){ ok = false; return raw; } const uint8_t* a = raw + o; o += n; return a; };
    auto I8 = [&](size_t n) -> const int8_t* { return (const int8_t*)U8(n); };
    // byte planes, axis-major: m planes of n high bytes then m planes of n low bytes -> unsigned 16-bit values
    auto I16 = [&](int n, int m){
        const uint8_t* h = U8((size_t)n * m); const uint8_t* l = U8((size_t)n * m);
        std::vector<int> a((size_t)n * m); if (ok) for (int i = 0; i < n * m; i++) a[i] = (h[i] << 8) | l[i];
        return a; };
    auto s16 = [](int v){ return (int)(int16_t)(uint16_t)v; };

    // ---------------- leaves ----------------
    const int nl = M.nl;
    const uint8_t* lbd = U8((size_t)nl * 3); const int8_t* lA = I8((size_t)nl * 3);
    const uint8_t* lphi = U8(nl); const uint8_t* lty = U8(nl);
    if (!ok) return false;
    Mesh& L = out.leaf;
    int nlv = 0; for (int i = 0; i < nl; i++) nlv += lty[i] ? 4 : 6;
    L.pos.resize((size_t)nlv * 3); L.nrm.resize((size_t)nlv * 3); L.uv.resize((size_t)nlv * 2);
    L.idx.reserve((size_t)nl * 12);
    int lv = 0; int qa[3] = {0, 0, 0};
    static const double UVF[6][2] = {{.5,1},{0,2./3},{0,1./3},{.5,0},{1,1./3},{1,2./3}};
    for (int i = 0; i < nl; i++){
        double B[3], A[3];
        for (int a = 0; a < 3; a++){
            qa[a] = (qa[a] + lbd[a * nl + i]) & 255;
            B[a] = M.llo[a] + qa[a] / 255.0 * (M.lhi[a] - M.llo[a]);
            A[a] = lA[a * nl + i] * M.As;
        }
        double Ln = std::sqrt(A[0]*A[0] + A[1]*A[1] + A[2]*A[2]); if (Ln == 0) Ln = 1e-6;
        double ab[3] = {A[0]/Ln, A[1]/Ln, A[2]/Ln};
        double ref[3] = {0, 1, 0}; if (!(std::fabs(ab[1]) < .95)){ ref[0] = 1; ref[1] = 0; }
        double e1[3] = {ab[1]*ref[2]-ab[2]*ref[1], ab[2]*ref[0]-ab[0]*ref[2], ab[0]*ref[1]-ab[1]*ref[0]};
        double l1 = std::sqrt(e1[0]*e1[0] + e1[1]*e1[1] + e1[2]*e1[2]); if (l1 == 0) l1 = 1;
        for (double& x : e1) x /= l1;
        double e2[3] = {ab[1]*e1[2]-ab[2]*e1[1], ab[2]*e1[0]-ab[0]*e1[2], ab[0]*e1[1]-ab[1]*e1[0]};
        double ph = lphi[i] / 256.0 * M_PI * 2, cp = std::cos(ph) * .1 * Ln, sp = std::sin(ph) * .1 * Ln;
        double Wv[3] = {e1[0]*cp+e2[0]*sp, e1[1]*cp+e2[1]*sp, e1[2]*cp+e2[2]*sp};
        double nx = A[1]*Wv[2]-A[2]*Wv[1], ny = A[2]*Wv[0]-A[0]*Wv[2], nz = A[0]*Wv[1]-A[1]*Wv[0];
        double nn = std::sqrt(nx*nx + ny*ny + nz*nz); if (nn == 0) nn = 1; nx /= nn; ny /= nn; nz /= nn;
        if (ny < 0){ nx = -nx; ny = -ny; nz = -nz; }
        // point along the axis t (0 base .. 1 tip), sideways s (-1 left .. 1 right)
        auto pt = [&](double t, double s, double* r){ for (int a = 0; a < 3; a++) r[a] = B[a] + A[a]*t + Wv[a]*s; };
        double v[6][3]; pt(1,0,v[0]); pt(2./3,-1,v[1]); pt(1./3,-1,v[2]); pt(0,0,v[3]); pt(1./3,1,v[4]); pt(2./3,1,v[5]);
        int ty = lty[i];
        int sel6[6] = {0,1,2,3,4,5}, sel4a[4] = {0,1,2,3}, sel4b[4] = {0,3,4,5};
        const int* us = ty == 0 ? sel6 : (ty == 1 ? sel4a : sel4b);
        int cnt = ty == 0 ? 6 : 4;
        int b0 = lv;
        for (int k = 0; k < cnt; k++){
            const double* P = v[us[k]];
            L.pos[lv*3] = (float)P[0]; L.pos[lv*3+1] = (float)P[1]; L.pos[lv*3+2] = (float)P[2];
            L.nrm[lv*3] = (float)nx; L.nrm[lv*3+1] = (float)ny; L.nrm[lv*3+2] = (float)nz;
            L.uv[lv*2] = (float)UVF[us[k]][0]; L.uv[lv*2+1] = (float)UVF[us[k]][1]; lv++;
        }
        for (int k = 1; k <= cnt - 2; k++){ L.idx.push_back(b0); L.idx.push_back(b0 + k); L.idx.push_back(b0 + k + 1); }
    }

    // ---------------- bark tubes ----------------
    const int nc = M.nc, R = M.R, nrc = M.nrc, nrv = M.nrv, nrt = M.nrt;
    const uint8_t* Kc = U8(nc);
    std::vector<int> gu = I16(nc, 3), u0q = I16(nc, 1), c0 = I16(nc, 3);
    const uint8_t* r0 = U8(nc); const int8_t* dc = I8((size_t)R * 3); const int8_t* dr = I8(R);
    std::vector<int> rvc = I16(nrc, 1), rgu = I16(nrc, 3), ru0 = I16(nrc, 1), rdp = I16(nrv, 3), rdi = I16(nrt * 3, 1);
    if (!ok) return false;
    int totRings = 0; for (int c = 0; c < nc; c++) totRings += Kc[c];
    const int nbv = totRings * 6 + nrv;
    Mesh& Bk = out.bark;
    Bk.pos.assign((size_t)nbv * 3, 0.f); Bk.uv.assign((size_t)nbv * 2, 0.f);
    Bk.idx.reserve((size_t)(totRings * 12 + nrt) * 3);
    int bv = 0, ri = 0;
    const double u0s = (M.u0hi - M.u0lo) / 65535.0;
    auto setUV = [&](int v, double cx, double cy, double cz, double g0, double g1, double g2, double u0){
        double x = Bk.pos[v*3], y = Bk.pos[v*3+1], z = Bk.pos[v*3+2];
        Bk.uv[v*2]   = (float)(u0 + g0*(x-cx) + g1*(y-cy) + g2*(z-cz));
        Bk.uv[v*2+1] = (float)(M.vc[0]*x + M.vc[1]*y + M.vc[2]*z + M.vc[3]);
    };
    for (int c = 0; c < nc; c++){
        const int K = Kc[c];
        int cq[3] = {c0[c], c0[nc + c], c0[2*nc + c]}; int rq = r0[c];
        std::vector<std::array<double,3>> cen; std::vector<double> rad;
        for (int k = 0; k < K; k++){
            if (k > 0){ for (int a = 0; a < 3; a++) cq[a] += dc[a * R + ri]; rq += dr[ri]; ri++; }
            cen.push_back({M.glo[0] + cq[0]*M.QC, M.glo[1] + cq[1]*M.QC, M.glo[2] + cq[2]*M.QC}); rad.push_back(rq * M.QR);
        }
        double g0 = s16(gu[c]) * M.gus, g1 = s16(gu[nc + c]) * M.gus, g2 = s16(gu[2*nc + c]) * M.gus, u0 = M.u0lo + u0q[c] * u0s;
        const std::array<double,3> cr = cen[0];
        bool haveN = false; double nrm[3] = {0, 0, 0}; int first = bv;
        for (int k = 0; k < K; k++){
            const auto& pa = cen[std::max(k - 1, 0)]; const auto& pb = cen[std::min(k + 1, K - 1)];
            double tx = pb[0]-pa[0], ty = pb[1]-pa[1], tz = pb[2]-pa[2];
            double tl = std::sqrt(tx*tx + ty*ty + tz*tz); if (tl == 0) tl = 1; tx /= tl; ty /= tl; tz /= tl;
            if (!haveN){
                double rx = std::fabs(ty) < .9 ? 0 : 1, ry = std::fabs(ty) < .9 ? 1 : 0;
                nrm[0] = ty*0 - tz*ry; nrm[1] = tz*rx - tx*0; nrm[2] = tx*ry - ty*rx; haveN = true;   // t x ref
            } else {
                double d = nrm[0]*tx + nrm[1]*ty + nrm[2]*tz;
                nrm[0] -= tx*d; nrm[1] -= ty*d; nrm[2] -= tz*d;
            }
            double nn = std::sqrt(nrm[0]*nrm[0] + nrm[1]*nrm[1] + nrm[2]*nrm[2]); if (nn == 0) nn = 1;
            nrm[0] /= nn; nrm[1] /= nn; nrm[2] /= nn;
            double bb[3] = {ty*nrm[2]-tz*nrm[1], tz*nrm[0]-tx*nrm[2], tx*nrm[1]-ty*nrm[0]};
            for (int j = 0; j < 6; j++){
                double ang = j * M_PI / 3, ca = std::cos(ang) * rad[k], sa = std::sin(ang) * rad[k];
                Bk.pos[bv*3]   = (float)(cen[k][0] + nrm[0]*ca + bb[0]*sa);
                Bk.pos[bv*3+1] = (float)(cen[k][1] + nrm[1]*ca + bb[1]*sa);
                Bk.pos[bv*3+2] = (float)(cen[k][2] + nrm[2]*ca + bb[2]*sa);
                setUV(bv, cr[0], cr[1], cr[2], g0, g1, g2, u0); bv++;
            }
        }
        for (int k = 0; k < K - 1; k++) for (int j = 0; j < 6; j++){
            int jm = (j + 5) % 6, a = first + k*6 + j, a1 = first + k*6 + jm, b = first + (k+1)*6 + j, b1 = first + (k+1)*6 + jm;
            Bk.idx.push_back(a); Bk.idx.push_back(b); Bk.idx.push_back(b1); Bk.idx.push_back(a); Bk.idx.push_back(b1); Bk.idx.push_back(a1);
        }
    }
    // raw junction pieces
    {
        const int rb = bv; int q[3] = {0, 0, 0};
        for (int i = 0; i < nrv; i++) for (int a = 0; a < 3; a++){
            q[a] = (q[a] + rdp[a * nrv + i]) & 65535;
            Bk.pos[(rb + i)*3 + a] = (float)(M.rlo[a] + q[a] / 65535.0 * (M.rhi[a] - M.rlo[a]));
        }
        int vi = 0;
        for (int c = 0; c < nrc; c++){
            int n = rvc[c], s = rb + vi;
            double g0 = s16(rgu[c]) * M.gus, g1 = s16(rgu[nrc + c]) * M.gus, g2 = s16(rgu[2*nrc + c]) * M.gus, u0 = M.u0lo + ru0[c] * u0s;
            double cx = Bk.pos[s*3], cy = Bk.pos[s*3+1], cz = Bk.pos[s*3+2];
            for (int k = 0; k < n; k++) setUV(s + k, cx, cy, cz, g0, g1, g2, u0);
            vi += n;
        }
        int acc = 0;
        for (int j = 0; j < nrt * 3; j++){ int d = rdi[j]; if (d >= 32768) d -= 65536; acc += d; Bk.idx.push_back((uint16_t)(rb + acc)); }
        bv += nrv;
    }
    Bk.pos.resize((size_t)bv * 3); Bk.uv.resize((size_t)bv * 2);

    // ---------------- scale, smooth bark normals (computeVertexNormals), bounds ----------------
    for (float& v : L.pos) v *= TREE_SCALE;
    for (float& v : Bk.pos) v *= TREE_SCALE;
    Bk.nrm.assign(Bk.pos.size(), 0.f);
    for (size_t t = 0; t + 2 < Bk.idx.size(); t += 3){
        const float *A = &Bk.pos[Bk.idx[t]*3], *B = &Bk.pos[Bk.idx[t+1]*3], *C = &Bk.pos[Bk.idx[t+2]*3];
        float cb[3] = {C[0]-B[0], C[1]-B[1], C[2]-B[2]}, ab2[3] = {A[0]-B[0], A[1]-B[1], A[2]-B[2]};
        float n[3] = {cb[1]*ab2[2]-cb[2]*ab2[1], cb[2]*ab2[0]-cb[0]*ab2[2], cb[0]*ab2[1]-cb[1]*ab2[0]};
        for (int k = 0; k < 3; k++) for (int a = 0; a < 3; a++) Bk.nrm[Bk.idx[t+k]*3 + a] += n[a];
    }
    for (size_t v = 0; v + 2 < Bk.nrm.size(); v += 3){
        float l = std::sqrt(Bk.nrm[v]*Bk.nrm[v] + Bk.nrm[v+1]*Bk.nrm[v+1] + Bk.nrm[v+2]*Bk.nrm[v+2]); if (l == 0) l = 1;
        Bk.nrm[v] /= l; Bk.nrm[v+1] /= l; Bk.nrm[v+2] /= l;
    }
    out.minY = 1e9f; out.maxY = -1e9f; out.halfWidth = 0;
    for (const Mesh* m : {&L, &Bk})
        for (size_t v = 0; v + 2 < m->pos.size(); v += 3){
            out.minY = std::min(out.minY, m->pos[v+1]); out.maxY = std::max(out.maxY, m->pos[v+1]);
            out.halfWidth = std::max(out.halfWidth, std::max(std::fabs(m->pos[v]), std::fabs(m->pos[v+2])));
        }
    return ok;
}

// ---------------- pine / spruce: straight, dark green stacked cones (procedural, 3 levels of detail) ----------------
// Vertex = pos(3) normal(3) colour(3). Unit height H = 16 m; the planted instance scale multiplies it.
// vertex = pos(3) normal(3) colour(3) uv(2) branchFlag(1)  (12 floats). Flag 1 = a flat needle-covered branch (uv drives the needle pattern in the shader).
struct ConiferMesh { std::vector<float> v; std::vector<uint16_t> idx; int count() const { return (int)idx.size(); } };

// species 5 = Sycamore maple (Acer pseudoplatanus), species 6 = Rowan (Sorbus aucuparia, smaller + airier, silvery bark, clusters of red berries): the BROADLEAF species. A thick grey-brown trunk with a few limbs carries a wide, rounded crown made of
// overlapping lumpy domes (flag 0, so the shader gives them the same leaf-clump shading as the conifer cores). Fresh mid-green, brighter on top, dark underneath.
// detail 3 = close-up, 2 = middle distance, 1 = far / low quality. Same 12-float vertex layout and 16 m unit height as the conifers.
inline void buildBroadleaf(ConiferMesh& m, int detail, int species){
    const bool rw = species == 6, ch = species == 7;   // ch = CHERRY BLOSSOM: wide spreading crown of pink florets on dark limbs
    const float base[3] = {ch ? 0.97f : (rw ? 0.19f : 0.150f), ch ? 0.58f : (rw ? 0.37f : 0.340f), ch ? 0.72f : (rw ? 0.09f : 0.075f)}, bk[3] = {ch ? 0.20f : (rw ? 0.42f : 0.27f), ch ? 0.14f : (rw ? 0.38f : 0.22f), ch ? 0.12f : (rw ? 0.34f : 0.17f)};
    auto push = [&](float x, float y, float z, float nx, float ny, float nz, const float* col, float c, float fl){
        const float l = std::sqrt(nx*nx + ny*ny + nz*nz) + 1e-6f; const float a[12] = {x, y, z, nx/l, ny/l, nz/l, col[0]*c, col[1]*c, col[2]*c, 0.f, 0.f, fl};
        m.v.insert(m.v.end(), a, a + 12); return (uint16_t)(m.v.size() / 12 - 1); };
    uint32_t seed = 9001u + (uint32_t)species * 131u; auto rnd = [&]{ seed = seed * 1664525u + 1013904223u; return (float)(seed >> 8) / 16777216.f; };
    // a tapered prism from p0 (radius r0) to p1 (radius r1): trunk and limbs
    auto prism = [&](const float* p0, float r0, const float* p1, float r1, int n){
        float u[3] = {p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]}; const float ul = std::sqrt(u[0]*u[0] + u[1]*u[1] + u[2]*u[2]) + 1e-6f; for (int k = 0; k < 3; k++) u[k] /= ul;
        const float hp[3] = {std::fabs(u[1]) < 0.9f ? 0.f : 1.f, std::fabs(u[1]) < 0.9f ? 1.f : 0.f, 0.f};
        float e1[3] = {u[1]*hp[2] - u[2]*hp[1], u[2]*hp[0] - u[0]*hp[2], u[0]*hp[1] - u[1]*hp[0]}; const float el = std::sqrt(e1[0]*e1[0] + e1[1]*e1[1] + e1[2]*e1[2]) + 1e-6f; for (int k = 0; k < 3; k++) e1[k] /= el;
        const float e2[3] = {u[1]*e1[2] - u[2]*e1[1], u[2]*e1[0] - u[0]*e1[2], u[0]*e1[1] - u[1]*e1[0]};
        for (int j = 0; j < n; j++){
            const float a0 = j * 6.2831853f / n, a1 = (j + 1) * 6.2831853f / n, am = (a0 + a1) * 0.5f;
            float d0[3], d1[3], dm[3]; for (int k = 0; k < 3; k++){ d0[k] = e1[k]*std::cos(a0) + e2[k]*std::sin(a0); d1[k] = e1[k]*std::cos(a1) + e2[k]*std::sin(a1); dm[k] = e1[k]*std::cos(am) + e2[k]*std::sin(am); }
            const uint16_t a = push(p0[0] + d0[0]*r0, p0[1] + d0[1]*r0, p0[2] + d0[2]*r0, dm[0], dm[1], dm[2], bk, 1.f, 2.f), b = push(p0[0] + d1[0]*r0, p0[1] + d1[1]*r0, p0[2] + d1[2]*r0, dm[0], dm[1], dm[2], bk, 1.f, 2.f),
                           c = push(p1[0] + d0[0]*r1, p1[1] + d0[1]*r1, p1[2] + d0[2]*r1, dm[0], dm[1], dm[2], bk, 0.9f, 2.f), d = push(p1[0] + d1[0]*r1, p1[1] + d1[1]*r1, p1[2] + d1[2]*r1, dm[0], dm[1], dm[2], bk, 0.9f, 2.f);
            const uint16_t t[6] = {a, b, c, b, d, c}; m.idx.insert(m.idx.end(), t, t + 6);
        }
    };
    struct Blob { float x, y, z, R; }; Blob B[8]; int nb = 0;
    if (ch){ B[nb++] = {0.f, 8.6f, 0.f, 6.2f}; B[nb++] = {0.3f, 11.0f, -0.2f, 3.8f}; } else {
    B[nb++] = {0.f, rw ? 9.4f : 10.6f, 0.f, rw ? 3.3f : 4.5f}; B[nb++] = {0.3f, rw ? 11.6f : 13.3f, -0.2f, rw ? 2.3f : 3.1f}; }                            // main dome + top
    for (int k = 0; k < 6; k++){ const float a = k * 1.0471976f + 0.4f * rnd(), dist = ch ? 5.6f + 1.6f * rnd() : (rw ? 2.2f : 3.0f) + (rw ? 0.4f : 0.5f) * rnd();   // six side domes round the middle
        B[nb++] = {std::cos(a) * dist, ch ? 7.0f + 2.2f * rnd() : (rw ? 7.6f : 8.5f) + (rw ? 2.0f : 2.2f) * rnd(), std::sin(a) * dist, ch ? 3.4f + 0.9f * rnd() : (rw ? 2.0f : 2.8f) + (rw ? 0.5f : 0.7f) * rnd()}; }
    // trunk + limbs
    { const float p0[3] = {0.f, -3.f, 0.f}, p1[3] = {0.f, ch ? 8.0f : (rw ? 9.0f : 10.5f), 0.f}; prism(p0, ch ? 0.62f : (rw ? 0.42f : 0.60f), p1, ch ? 0.26f : (rw ? 0.16f : 0.22f), detail >= 2 ? 6 : 5); }
    if (detail >= 2) for (int k = 1; k < nb; k += 1){ const float p0[3] = {0.f, ch ? 3.6f + 0.45f * k : (rw ? 4.2f : 4.8f) + 0.35f * k, 0.f}, p1[3] = {B[k].x * (ch ? 0.80f : 0.62f), B[k].y - 1.3f, B[k].z * (ch ? 0.80f : 0.62f)}; if (ch){ const float md[3] = {p0[0] + (p1[0] - p0[0]) * 0.30f + (rnd() - 0.5f) * 0.6f, p0[1] + (p1[1] - p0[1]) * 0.72f, p0[2] + (p1[2] - p0[2]) * 0.30f + (rnd() - 0.5f) * 0.6f}; prism(p0, 0.34f, md, 0.20f, 4); prism(md, 0.20f, p1, 0.10f, 4); } else prism(p0, ch ? 0.30f : 0.24f, p1, 0.11f, 4); }
    // crown domes
    const int nLon = detail >= 3 ? 12 : (detail == 2 ? 9 : 6), nLat = detail >= 3 ? 7 : (detail == 2 ? 5 : 3);
    for (int b = 1; detail <= 1 && b < nb; b++){   // far/cheap model only: b = 0 (the solid inner dome) is skipped: only the outer leaf clusters remain
        const float tone = (0.88f + 0.26f * rnd()) * (0.92f + 0.016f * (B[b].y - 8.f));                   // higher domes a little lighter
        std::vector<float> lump((size_t)(nLat + 1) * nLon); for (int j = 0; j <= nLat; j++) for (int i = 0; i < nLon; i++) lump[(size_t)j*nLon + i] = (j == 0 || j == nLat) ? -1.f : 0.80f + 0.36f * rnd();
        const float poleLo = 0.86f + 0.2f * rnd(), poleHi = 0.90f + 0.2f * rnd();
        const uint16_t first = (uint16_t)(m.v.size() / 12);
        for (int j = 0; j <= nLat; j++){
            const float ph = -1.5707963f + 3.1415927f * j / nLat;
            for (int i = 0; i <= nLon; i++){
                const float th = 6.2831853f * i / nLon; const int im = i % nLon;
                float lp = lump[(size_t)j*nLon + im]; if (lp < 0.f) lp = (j == 0) ? poleLo : poleHi;
                const float dx = std::cos(ph) * std::cos(th), dy = std::sin(ph), dz = std::cos(ph) * std::sin(th);
                const float R = B[b].R * lp;
                push(B[b].x + dx*R, B[b].y + dy*R*0.82f, B[b].z + dz*R, dx, dy + 0.25f, dz, base, tone * (0.52f + 0.62f * (dy * 0.5f + 0.5f)), 0.f);
            }
        }
        for (int j = 0; j < nLat; j++) for (int i = 0; i < nLon; i++){
            const uint16_t a = (uint16_t)(first + j * (nLon + 1) + i), b2 = (uint16_t)(a + 1), c = (uint16_t)(a + nLon + 1), d = (uint16_t)(c + 1);
            const uint16_t t[6] = {a, b2, c, b2, d, c}; m.idx.insert(m.idx.end(), t, t + 6);
        }
    }

    if (detail >= 2){   // ---- REAL LEAVES: hundreds of individual leaf cards (flag 3: the shader cuts the maple/rowan leaf shape + veins out of each card) on twigs, no solid domes ----
        auto pushL = [&](const float* P, const float* nrm, const float* col, float c, float u, float v){
            const float a[12] = {P[0], P[1], P[2], nrm[0], nrm[1], nrm[2], col[0]*c, col[1]*c, col[2]*c, u, v, (rw || ch) ? 3.f : 3.2f};
            m.v.insert(m.v.end(), a, a + 12); return (uint16_t)(m.v.size() / 12 - 1); };
        auto nrmz = [](float* v){ const float l = std::sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]) + 1e-6f; v[0] /= l; v[1] /= l; v[2] /= l; };
        const float per = (detail >= 3 ? 30.f : 13.f) * (ch ? 1.25f : 1.f), lenS = detail >= 3 ? 1.0f : 1.45f;
        for (int b = 1; b < nb; b++){
            const float* C = &B[b].x;   // x, y, z, R
            if (detail >= 3) for (int t = 0; t < 4; t++){   // fine twigs from the limb tip out into the crown
                const float a = rnd() * 6.2831853f, dy = -0.3f + 0.9f * rnd(), cr = std::sqrt(1.f - dy*dy), rr = 0.78f * B[b].R;
                const float p0[3] = {B[b].x * 0.62f, B[b].y - 1.3f, B[b].z * 0.62f}, p1[3] = {B[b].x + std::cos(a)*cr*rr, B[b].y + dy*rr*0.82f, B[b].z + std::sin(a)*cr*rr};
                prism(p0, 0.10f, p1, 0.025f, 3);
            }
            const int nl = (int)(per * B[b].R * B[b].R);
            for (int i = 0; i < nl; i++){
                float o[3]; { const float a = rnd() * 6.2831853f, dy = -0.80f + 1.75f * rnd(), cr = std::sqrt(std::max(0.f, 1.f - dy*dy)); o[0] = std::cos(a)*cr; o[1] = dy; o[2] = std::sin(a)*cr; }
                const float rad = 0.58f + 0.42f * std::sqrt(rnd());                              // more leaves on the outside, some inside
                const float P[3] = {B[b].x + o[0]*B[b].R*rad, B[b].y + o[1]*B[b].R*rad*0.82f, B[b].z + o[2]*B[b].R*rad};
                float nl3[3] = {o[0] + 0.55f*(rnd()-0.5f), o[1] + 0.35f + 0.55f*(rnd()-0.5f), o[2] + 0.55f*(rnd()-0.5f)}; nrmz(nl3);
                float ax[3] = {rnd()-0.5f, rnd()-0.5f - 0.18f, rnd()-0.5f}; const float dn = ax[0]*nl3[0] + ax[1]*nl3[1] + ax[2]*nl3[2];
                for (int k = 0; k < 3; k++) ax[k] -= nl3[k]*dn; nrmz(ax);
                const float sd[3] = {nl3[1]*ax[2] - nl3[2]*ax[1], nl3[2]*ax[0] - nl3[0]*ax[2], nl3[0]*ax[1] - nl3[1]*ax[0]};
                const float len = (0.75f + 0.55f * rnd()) * lenS * (rw ? 0.80f : 1.f), hw = len * (rw ? 0.34f : 0.52f);
                const float B0[3] = {P[0] - ax[0]*len*0.15f, P[1] - ax[1]*len*0.15f, P[2] - ax[2]*len*0.15f};
                const float sh = (0.80f + 0.30f * rnd()) * (0.60f + 0.55f * ((rad - 0.58f) / 0.42f)) * (0.80f + 0.40f * (nl3[1] * 0.5f + 0.5f));   // inner leaves in shade, upper faces lit
                float col[3] = {base[0], base[1], base[2]}; const float yel = (!ch && rnd() < 0.12f) ? 1.f : 0.f; col[0] *= 1.f + 0.9f*yel; col[1] *= 1.f + 0.25f*yel; if (ch){ const float w = rnd(); col[1] *= 0.85f + 0.35f * w; col[2] *= 0.92f + 0.12f * w; }
                float ln[3] = {o[0]*0.7f, o[1]*0.7f + 0.5f, o[2]*0.7f}; nrmz(ln);                        // soft crown-shape lighting normal
                const float e[4][3] = {{B0[0] - sd[0]*hw, B0[1] - sd[1]*hw, B0[2] - sd[2]*hw}, {B0[0] + sd[0]*hw, B0[1] + sd[1]*hw, B0[2] + sd[2]*hw},
                                       {B0[0] + ax[0]*len - sd[0]*hw, B0[1] + ax[1]*len - sd[1]*hw, B0[2] + ax[2]*len - sd[2]*hw}, {B0[0] + ax[0]*len + sd[0]*hw, B0[1] + ax[1]*len + sd[1]*hw, B0[2] + ax[2]*len + sd[2]*hw}};
                const uint16_t q0 = pushL(e[0], ln, col, sh, -1.f, 0.f), q1 = pushL(e[1], ln, col, sh, 1.f, 0.f), q2 = pushL(e[2], ln, col, sh, -1.f, 1.f), q3 = pushL(e[3], ln, col, sh, 1.f, 1.f);
                const uint16_t t[6] = {q0, q1, q2, q1, q3, q2}; m.idx.insert(m.idx.end(), t, t + 6);
            }
            (void)C;
        }
    }
    if (rw && detail >= 2){                                                                              // rowan: bunches of red berries hanging on the outside of the crown
        const float red[3] = {0.80f, 0.12f, 0.07f};
        for (int k = 0; k < 16; k++){
            const Blob& bl = B[1 + (int)(rnd() * (nb - 1)) % (nb - 1)]; const float a = rnd() * 6.2831853f, dy = -0.15f + 0.85f * rnd(), cr = std::sqrt(1.f - dy*dy);
            const float cx = bl.x + std::cos(a) * cr * bl.R * 1.10f, cy = bl.y + dy * bl.R * 0.84f, cz = bl.z + std::sin(a) * cr * bl.R * 1.10f, br = 0.34f + 0.12f * rnd();
            const uint16_t first = (uint16_t)(m.v.size() / 12); const int bLon = 5, bLat = 3;
            for (int j = 0; j <= bLat; j++){ const float ph = -1.5707963f + 3.1415927f * j / bLat;
                for (int i = 0; i <= bLon; i++){ const float th = 6.2831853f * i / bLon; const float dx = std::cos(ph) * std::cos(th), ey = std::sin(ph), dz = std::cos(ph) * std::sin(th);
                    push(cx + dx*br, cy + ey*br, cz + dz*br, dx, ey + 0.2f, dz, red, 0.75f + 0.45f * (ey * 0.5f + 0.5f), 0.f); } }
            for (int j = 0; j < bLat; j++) for (int i = 0; i < bLon; i++){
                const uint16_t a0 = (uint16_t)(first + j * (bLon + 1) + i), b0 = (uint16_t)(a0 + 1), c0 = (uint16_t)(a0 + bLon + 1), d0 = (uint16_t)(c0 + 1);
                const uint16_t t[6] = {a0, b0, c0, b0, d0, c0}; m.idx.insert(m.idx.end(), t, t + 6); }
        }
    }
}

// species 0 = spruce (narrow, dense, blue-green), 1 = pine (a little broader, warmer green),
// 2 = Norway spruce (Picea abies: tall, slim cone, very dark green, long branches that hang down in "curtains" with up-turned tips),
// 3 = Silver fir (Abies alba: broad regular cone, flat horizontal branch layers, greyer silvery-green needles, pale grey bark),
// 4 = European larch (Larix decidua: slender, open feathery crown, light fresh yellow-green soft needles, drooping twigs)
inline float spPick(int s, float spruce, float pine, float norway, float fir, float larch){ return s == 0 ? spruce : (s == 1 ? pine : (s == 2 ? norway : (s == 3 ? fir : larch))); }

// ======================= CHERRY BLOSSOM TREE (species 7) - its own model =======================
// Short thick trunk that forks into 5 spreading limbs; every limb branches again and again (4 levels, curved, drooping twigs); blossom clusters (pink floret cards)
// sit along the twigs and at every tip, so the crown follows the branches like a real flowering cherry. detail 3 = close-up, 2 = middle, 1 = far.
inline void buildCherry(ConiferMesh& m, int detail){
    const float bk[3] = {0.24f, 0.17f, 0.15f}, pk[3] = {0.99f, 0.78f, 0.86f};   // dark grey-brown wood, pale soft pink blossom
    uint32_t seed = 7331u; auto rnd = [&]{ seed = seed * 1664525u + 1013904223u; return (float)(seed >> 8) / 16777216.f; };
    auto nrmz = [](float* a){ const float l = std::sqrt(a[0]*a[0] + a[1]*a[1] + a[2]*a[2]) + 1e-6f; a[0] /= l; a[1] /= l; a[2] /= l; };
    auto push = [&](const float* P, const float* N, const float* col, float c, float u, float v, float fl){
        const float a[12] = {P[0], P[1], P[2], N[0], N[1], N[2], col[0]*c, col[1]*c, col[2]*c, u, v, fl};
        m.v.insert(m.v.end(), a, a + 12); return (uint16_t)(m.v.size() / 12 - 1); };
    auto prism = [&](const float* p0, float r0, const float* p1, float r1, int n){
        float u[3] = {p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]}; nrmz(u);
        const float h[3] = {std::fabs(u[1]) < 0.9f ? 0.f : 1.f, std::fabs(u[1]) < 0.9f ? 1.f : 0.f, 0.f};
        float e1[3] = {u[1]*h[2] - u[2]*h[1], u[2]*h[0] - u[0]*h[2], u[0]*h[1] - u[1]*h[0]}; nrmz(e1);
        const float e2[3] = {u[1]*e1[2] - u[2]*e1[1], u[2]*e1[0] - u[0]*e1[2], u[0]*e1[1] - u[1]*e1[0]};
        const uint16_t first = (uint16_t)(m.v.size() / 12);
        for (int j = 0; j <= n; j++){
            const float a = j * 6.2831853f / n; const float d[3] = {e1[0]*std::cos(a) + e2[0]*std::sin(a), e1[1]*std::cos(a) + e2[1]*std::sin(a), e1[2]*std::cos(a) + e2[2]*std::sin(a)};
            const float A[3] = {p0[0] + d[0]*r0, p0[1] + d[1]*r0, p0[2] + d[2]*r0}, B[3] = {p1[0] + d[0]*r1, p1[1] + d[1]*r1, p1[2] + d[2]*r1};
            push(A, d, bk, 1.f, 0.f, 0.f, 2.f); push(B, d, bk, 0.9f, 0.f, 0.f, 2.f);
        }
        for (int j = 0; j < n; j++){ const uint16_t a = (uint16_t)(first + 2*j), b = (uint16_t)(a + 1), c = (uint16_t)(a + 2), d = (uint16_t)(a + 3); const uint16_t t[6] = {a, b, c, b, d, c}; m.idx.insert(m.idx.end(), t, t + 6); }
    };
    const float cardLen = detail >= 3 ? 0.95f : (detail == 2 ? 1.35f : 2.0f);
    auto card = [&](const float* P, const float* on){      // one flower card (the shader draws pink florets inside it)
        if (m.v.size() / 12 > 60000) return;
        float ax[3] = {rnd() - 0.5f, rnd() - 0.55f, rnd() - 0.5f}; nrmz(ax);
        float sd[3] = {on[1]*ax[2] - on[2]*ax[1], on[2]*ax[0] - on[0]*ax[2], on[0]*ax[1] - on[1]*ax[0]}; const float sl = std::sqrt(sd[0]*sd[0] + sd[1]*sd[1] + sd[2]*sd[2]); if (sl < 0.05f) return; nrmz(sd);
        const float len = cardLen * (0.8f + 0.5f * rnd()), hw = len * 0.55f, w = rnd();
        const float col[3] = {pk[0], pk[1] * (0.85f + 0.35f * w), pk[2] * (0.92f + 0.12f * w)}, sh = 0.82f + 0.32f * rnd() * (0.6f + 0.5f * (on[1] * 0.5f + 0.5f));
        const float B0[3] = {P[0] - ax[0]*len*0.15f, P[1] - ax[1]*len*0.15f, P[2] - ax[2]*len*0.15f};
        const float e[4][3] = {{B0[0] - sd[0]*hw, B0[1] - sd[1]*hw, B0[2] - sd[2]*hw}, {B0[0] + sd[0]*hw, B0[1] + sd[1]*hw, B0[2] + sd[2]*hw},
                               {B0[0] + ax[0]*len - sd[0]*hw, B0[1] + ax[1]*len - sd[1]*hw, B0[2] + ax[2]*len - sd[2]*hw}, {B0[0] + ax[0]*len + sd[0]*hw, B0[1] + ax[1]*len + sd[1]*hw, B0[2] + ax[2]*len + sd[2]*hw}};
        const uint16_t q0 = push(e[0], on, col, sh, -1.f, 0.f, 3.f), q1 = push(e[1], on, col, sh, 1.f, 0.f, 3.f), q2 = push(e[2], on, col, sh, -1.f, 1.f, 3.f), q3 = push(e[3], on, col, sh, 1.f, 1.f, 3.f);
        const uint16_t t[6] = {q0, q1, q2, q1, q3, q2}; m.idx.insert(m.idx.end(), t, t + 6);
    };
    auto cluster = [&](const float* P, int n, float spread){
        for (int i = 0; i < n; i++){ float o[3] = {rnd() - 0.5f, rnd() - 0.5f, rnd() - 0.5f}; nrmz(o); const float k = spread * (0.25f + 0.75f * rnd());
            const float Q[3] = {P[0] + o[0]*k, P[1] + o[1]*k, P[2] + o[2]*k}; float on[3] = {o[0], o[1] + 0.35f, o[2]}; nrmz(on); card(Q, on); }
    };
    const int maxDepth = detail >= 3 ? 4 : (detail == 2 ? 3 : 2), nS = detail >= 2 ? 3 : 2, sides = detail >= 3 ? 8 : (detail == 2 ? 6 : 4);   // round, smooth tubes
    const int tipCards = detail >= 3 ? 5 : (detail == 2 ? 3 : 3), nodeCards = detail >= 3 ? 2 : (detail == 2 ? 1 : 0);   // few cards: the dark branches stay visible between the blossom clusters
    std::function<void(const float*, const float*, float, float, int)> grow = [&](const float* P0, const float* d0, float len, float r0, int depth){
        float P[3] = {P0[0], P0[1], P0[2]}, d[3] = {d0[0], d0[1], d0[2]}; float r = r0;
        for (int s = 0; s < nS; s++){
            d[0] += (rnd() - 0.5f) * 0.20f; d[2] += (rnd() - 0.5f) * 0.20f; d[1] += (depth >= 2 ? -0.06f : 0.03f) + (rnd() - 0.5f) * 0.08f; nrmz(d);   // curved, twigs droop
            const float sl = len / nS; const float Q[3] = {P[0] + d[0]*sl, P[1] + d[1]*sl, P[2] + d[2]*sl}; const float r1 = r * 0.84f;
            prism(P, r, Q, r1, sides); P[0] = Q[0]; P[1] = Q[1]; P[2] = Q[2]; r = r1;
            if (depth >= 2 && nodeCards) cluster(P, nodeCards, 0.65f);
        }
        if (depth >= maxDepth){ cluster(P, tipCards, 0.8f); return; }
        { float dl[3] = {d[0], d[1], d[2]}; grow(P, dl, len * 0.74f, r * 0.85f, depth + 1); }                                  // the branch carries on
        for (int k = 0; k < 2; k++){                                                                                          // and two side branches
            const float az = rnd() * 6.2831853f, an = 0.70f + 0.50f * rnd();
            float h[3] = {std::fabs(d[1]) < 0.9f ? 0.f : 1.f, std::fabs(d[1]) < 0.9f ? 1.f : 0.f, 0.f};
            float e1[3] = {d[1]*h[2] - d[2]*h[1], d[2]*h[0] - d[0]*h[2], d[0]*h[1] - d[1]*h[0]}; nrmz(e1);
            const float e2[3] = {d[1]*e1[2] - d[2]*e1[1], d[2]*e1[0] - d[0]*e1[2], d[0]*e1[1] - d[1]*e1[0]};
            float nd[3]; for (int c = 0; c < 3; c++) nd[c] = d[c] * std::cos(an) + (e1[c] * std::cos(az) + e2[c] * std::sin(az)) * std::sin(an); nd[1] += 0.16f; nrmz(nd);
            grow(P, nd, len * 0.62f, r * 0.70f, depth + 1);
        }
    };
    // trunk: short, thick, a little crooked, then the fork
    { const float t0[3] = {0.f, -3.f, 0.f}, t1[3] = {0.12f, 1.4f, 0.08f}, t2[3] = {0.18f, 4.2f, 0.f};
      prism(t0, 0.80f, t1, 0.60f, detail >= 2 ? 10 : 6); prism(t1, 0.60f, t2, 0.48f, detail >= 2 ? 10 : 6);
      for (int k = 0; k < 5; k++){ const float a = k * 1.2566371f + 0.5f * rnd(), el = 1.00f + 0.30f * rnd();
          float d[3] = {std::cos(a) * std::sin(el), std::cos(el), std::sin(a) * std::sin(el)}; nrmz(d); grow(t2, d, 6.0f + 1.2f * rnd(), 0.42f, 1); } }
}

inline void buildConifer(ConiferMesh& m, int species, int tiers, int seg, bool jagged){
    if (species == 7){ buildCherry(m, seg >= 10 ? 3 : (seg >= 9 ? 2 : 1)); return; }
    if (species >= 5){ buildBroadleaf(m, seg >= 10 ? 3 : (seg >= 9 ? 2 : 1), species); return; }      // broadleaf
    const float H = 16.f, R = H * spPick(species, 0.17f, 0.22f, 0.150f, 0.190f, 0.160f);
    const float base[3] = {spPick(species, 0.105f, 0.150f, 0.072f, 0.112f, 0.200f), spPick(species, 0.225f, 0.255f, 0.195f, 0.215f, 0.350f), spPick(species, 0.135f, 0.095f, 0.112f, 0.140f, 0.120f)};    // real conifer foliage: dark, muted blue-green spruce / olive-green pine (red : green ~ 0.5-0.6, not a neon green)
    auto push = [&](float x, float y, float z, float nx, float ny, float nz, float c, float u = 0.f, float vv = 0.f, float fl = 0.f){
        const float l = std::sqrt(nx*nx + ny*ny + nz*nz); const float a[12] = {x, y, z, nx/l, ny/l, nz/l, base[0]*c, base[1]*c, base[2]*c, u, vv, fl};
        m.v.insert(m.v.end(), a, a + 12); return (uint16_t)(m.v.size() / 12 - 1); };
    // trunk: thin 5-sided prism, buried 3 m below the foot so it never floats on a slope
    { const bool dt = true;   // every LOD (was: close-up only): no solid green core any more, so the trunk must carry the branches up the whole tree
      const float tr = dt ? 0.50f : 0.45f, top = dt ? H * 0.97f : H * 0.16f, tt = dt ? 0.06f : 0.6f; const float bk[3] = {species == 3 ? 0.36f : (species == 2 ? 0.31f : (species == 4 ? 0.33f : 0.22f)), species == 3 ? 0.33f : (species == 2 ? 0.17f : (species == 4 ? 0.19f : 0.15f)), species == 3 ? 0.29f : (species == 2 ? 0.11f : (species == 4 ? 0.12f : 0.09f))};
      for (int j = 0; j < 5; j++){
          const float a0 = j * 6.2831853f / 5, a1 = (j + 1) * 6.2831853f / 5, am = (a0 + a1) * 0.5f; const float nx = std::cos(am), nz = std::sin(am);
          const float P[4][3] = {{tr*std::cos(a0), -3.f, tr*std::sin(a0)}, {tr*std::cos(a1), -3.f, tr*std::sin(a1)}, {tr*tt*std::cos(a0), top, tr*tt*std::sin(a0)}, {tr*tt*std::cos(a1), top, tr*tt*std::sin(a1)}};
          uint16_t ix[4]; for (int k = 0; k < 4; k++){ ix[k] = push(P[k][0], P[k][1], P[k][2], nx, 0.f, nz, 1.f, 0.f, 0.f, 2.f); float* c = &m.v[(size_t)ix[k]*12 + 6]; c[0] = bk[0]; c[1] = bk[1]; c[2] = bk[2]; }
          const uint16_t t[6] = {ix[0], ix[1], ix[2], ix[1], ix[3], ix[2]}; m.idx.insert(m.idx.end(), t, t + 6);
      } }
    const bool detailed = true;   // no solid green cone core at any distance: only trunk + branches
    // stacked cones (the whole tree at a distance; a smaller, darker core behind the branches up close)
    const float rs = detailed ? 0.90f : 1.f, dark = detailed ? 2.5f : 1.f;
    for (int i = 0; i < (detailed ? 0 : tiers); i++){   // detailed: the solid green core is removed, only trunk + real needle branches remain
        const float f = tiers > 1 ? (float)i / (tiers - 1) : 0.f;
        const float y0 = H * (0.10f + 0.60f * f), y1 = H * (tiers > 1 ? 0.40f + 0.60f * f : 1.0f), r = R * rs * (1.f - 0.80f * f), ht = y1 - y0;
        const float shade = (0.82f + 0.30f * f) * dark;                                  // upper tiers a little lighter
        for (int j = 0; j < seg; j++){
            const float a0 = j * 6.2831853f / seg, a1 = (j + 1) * 6.2831853f / seg, am = (a0 + a1) * 0.5f;
            const float r0 = r * ((jagged && (j & 1)) ? 0.88f : 1.f), r1 = r * ((jagged && ((j + 1) & 1)) ? 0.88f : 1.f);   // ragged skirt = branch tips
            const float yb = y0 - (jagged ? 0.04f * H : 0.f);
            const uint16_t a = push(r0*std::cos(a0), yb, r0*std::sin(a0), std::cos(a0)*ht, r, std::sin(a0)*ht, 0.80f * shade);
            const uint16_t b = push(r1*std::cos(a1), yb, r1*std::sin(a1), std::cos(a1)*ht, r, std::sin(a1)*ht, 0.80f * shade);
            const uint16_t c = push(0.f, y1, 0.f, std::cos(am)*ht, r, std::sin(am)*ht, 1.18f * shade);
            m.idx.push_back(a); m.idx.push_back(b); m.idx.push_back(c);
        }
    }
    if (!detailed) return;
    // individual branches: whorls up the trunk, each branch a flat tapered blade that droops (upper ones lift), needles come from the shader
    uint32_t seed = 12345u + (uint32_t)species * 777u; auto rnd = [&]{ seed = seed * 1664525u + 1013904223u; return (float)(seed >> 8) / 16777216.f; };
    const int whorls = species == 4 ? 18 : (species == 3 ? 26 : (species == 2 ? 34 : (species == 0 ? 26 : 22))), per = species == 0 ? 14 : (species == 4 ? 9 : (species == 2 ? 11 : (species == 3 ? 9 : 12)));
    const float brFl = species == 2 ? 1.3f : (species == 3 ? 1.45f : (species == 4 ? 1.1f : 1.f));   // 1.45 = silver fir branch: flat dark-green top, silvery underside   // 1.3 = Norway spruce branch: the shader draws denser needles + pale new-growth tips
    for (int w = 0; w < whorls; w++){
        const float f = (w + 0.5f) / whorls, y = species == 2 ? H * (0.19f + 0.78f * f) : H * (0.13f + 0.84f * f);   // Norway spruce: bare lower trunk
        const float Rw = R * spPick(species, 1.30f, 1.25f, 1.28f, 1.32f, 1.15f) * std::pow(1.f - 0.93f * f, spPick(species, 0.95f, 0.8f, 1.05f, 0.85f, 0.90f));
        for (int b = 0; b < per; b++){
            const float ang = ((float)b + 0.5f * (w & 1) + 0.4f * rnd()) * 6.2831853f / per + w * 0.9f;
            if (seg < 9 && (b & 1)) continue;   // far model: half the branches
            if (species == 2 && f < 0.22f && rnd() < 0.45f) continue;   // lower crown thins out: dead branches have fallen
            const float L = std::max(0.45f, Rw * (0.85f + 0.3f * rnd())), hwid = L * spPick(species, 0.55f, 0.62f, 0.48f, 0.70f, 0.45f);
            const float droop = spPick(species, 0.34f, 0.16f, 0.62f, 0.10f, 0.30f) * (1.f - f) - 0.30f * f * f;        // tip drop (+) / lift (-) per unit length
            const float dx = std::cos(ang), dz = std::sin(ang), px = -dz, pz = dx, y0 = y + (rnd() - 0.5f) * 0.25f;
            const float tone = (0.80f + 0.45f * rnd()) * (0.85f + 0.35f * f) * (species == 2 && f < 0.22f ? 0.72f : 1.f);
            const float S[5] = {0.f, 0.25f, 0.50f, 0.75f, 1.f}, Wd[5] = {0.15f, 0.80f, 1.0f, 0.70f, 0.f};
            const float curl = spPick(species, 0.05f, 0.20f, 0.45f, 0.08f, 0.15f) * L, bend = (rnd() - 0.5f) * 0.30f * L, roll = (rnd() - 0.5f) * (species == 3 ? 0.35f : 1.3f), cr = std::cos(roll), sr = std::sin(roll);   // roll: the blade is tilted about its own axis, so the crown has volume from every side
            uint16_t lv[4], rv[4], tip = 0;
            for (int k = 0; k < 5; k++){
                const float s = S[k], d = 0.25f + L * s, yy = y0 - droop * L * s * (0.4f + 0.6f * s) + curl * s * s * s * s, wd = hwid * Wd[k], cc = tone * (0.90f + 0.35f * s), bo = bend * s * s;
                const float nx = dx * 0.35f, nz = dz * 0.35f;                                       // soft, mostly upward normal
                if (k < 4){
                    lv[k] = push(dx*d + px*cr*(wd + bo), yy + sr*(wd + bo), dz*d + pz*cr*(wd + bo), nx, 0.95f, nz, cc, s, -1.f, brFl);
                    rv[k] = push(dx*d - px*cr*(wd - bo), yy - sr*(wd - bo), dz*d - pz*cr*(wd - bo), nx, 0.95f, nz, cc, s, 1.f, brFl);
                } else tip = push(dx*d + px*cr*bo, yy - 0.03f * L + sr*bo, dz*d + pz*cr*bo, nx, 0.95f, nz, cc, 1.f, 0.f, brFl);
            }
            for (int k = 0; k < 3; k++){ m.idx.push_back(lv[k]); m.idx.push_back(rv[k]); m.idx.push_back(lv[k+1]); m.idx.push_back(rv[k]); m.idx.push_back(rv[k+1]); m.idx.push_back(lv[k+1]); }
            m.idx.push_back(lv[3]); m.idx.push_back(rv[3]); m.idx.push_back(tip);
            if (species == 4 && f > 0.25f && rnd() < 0.30f){   // small upright rose-shaped cones
                const float s0 = 0.3f + 0.5f * rnd(), d0 = 0.25f + L * s0, cy = y0 - droop * L * s0 * (0.4f + 0.6f * s0) + curl * s0 * s0 * s0 * s0 + 0.04f, cl = 0.34f + 0.1f * rnd(), crd = 0.10f, cb[3] = {0.36f, 0.20f, 0.11f}; uint16_t r[4];
                for (int k = 0; k < 4; k++){ const float a = k * 1.5707963f; r[k] = push(dx*d0 + crd*std::cos(a), cy, dz*d0 + crd*std::sin(a), std::cos(a), 0.f, std::sin(a), 1.f, 0.f, 0.f, 2.f); float* c = &m.v[(size_t)r[k]*12 + 6]; c[0] = cb[0]; c[1] = cb[1]; c[2] = cb[2]; }
                const uint16_t pt = push(dx*d0, cy + cl, dz*d0, 0.f, 1.f, 0.f, 1.f, 0.f, 0.f, 2.f); { float* c = &m.v[(size_t)pt*12 + 6]; c[0] = cb[0]*0.9f; c[1] = cb[1]*0.9f; c[2] = cb[2]*0.9f; }
                for (int k = 0; k < 4; k++){ m.idx.push_back(r[(k+1)%4]); m.idx.push_back(r[k]); m.idx.push_back(pt); }
            }
            if (species == 3){   // silver fir: flat herringbone spray, pairs of side-twigs in the branch plane, growing shorter towards the tip
                for (int t = 0; t < 4; t++){ for (int sd = 0; sd < 2; sd++){
                    const float side = sd ? 1.f : -1.f, s0 = 0.18f + 0.17f * t + 0.03f * rnd(), d0 = 0.25f + L * s0;
                    const float by = y0 - droop * L * s0 * (0.4f + 0.6f * s0) + curl * s0 * s0 * s0 * s0;
                    const float tl = L * (0.46f - 0.09f * t) * (0.9f + 0.2f * rnd()), tw = tl * 0.20f;
                    const float ox = dx * 0.55f + px * side * 0.80f, oz = dz * 0.55f + pz * side * 0.80f, ol = std::sqrt(ox*ox + oz*oz), wx = -oz / ol, wz = ox / ol;
                    const float tt = tone * (0.90f + 0.20f * rnd()); uint16_t a[2], b[2], e = 0;
                    for (int k = 0; k < 3; k++){ const float u = k * 0.5f, cx = dx*d0 + ox/ol*u*tl, cz = dz*d0 + oz/ol*u*tl, cy = by - 0.10f * tl * u, w = tw * (k == 0 ? 0.5f : (k == 1 ? 1.f : 0.f));
                        if (k < 2){ a[k] = push(cx + wx*w, cy, cz + wz*w, 0.f, 1.f, 0.f, tt, 0.4f + 0.6f * u, -1.f, brFl); b[k] = push(cx - wx*w, cy, cz - wz*w, 0.f, 1.f, 0.f, tt, 0.4f + 0.6f * u, 1.f, brFl); }
                        else e = push(cx, cy, cz, 0.f, 1.f, 0.f, tt, 1.f, 0.f, brFl); }
                    m.idx.push_back(a[0]); m.idx.push_back(b[0]); m.idx.push_back(a[1]); m.idx.push_back(b[0]); m.idx.push_back(b[1]); m.idx.push_back(a[1]); m.idx.push_back(a[1]); m.idx.push_back(b[1]); m.idx.push_back(e);
                } }
                if (f > 0.72f && rnd() < 0.35f){   // upright candle-like cones on top of the upper branches
                    const float s0 = 0.35f + 0.4f * rnd(), d0 = 0.25f + L * s0, cy = y0 - droop * L * s0 * (0.4f + 0.6f * s0) + 0.05f, cl = 0.8f + 0.25f * rnd(), crd = 0.15f, cb[3] = {0.26f, 0.24f, 0.13f}; uint16_t r[4];
                    for (int k = 0; k < 4; k++){ const float a = k * 1.5707963f; r[k] = push(dx*d0 + crd*std::cos(a), cy, dz*d0 + crd*std::sin(a), std::cos(a), 0.f, std::sin(a), 1.f, 0.f, 0.f, 2.f); float* c = &m.v[(size_t)r[k]*12 + 6]; c[0] = cb[0]; c[1] = cb[1]; c[2] = cb[2]; }
                    const uint16_t pt = push(dx*d0, cy + cl, dz*d0, 0.f, 1.f, 0.f, 1.f, 0.f, 0.f, 2.f); { float* c = &m.v[(size_t)pt*12 + 6]; c[0] = cb[0]*0.9f; c[1] = cb[1]*0.9f; c[2] = cb[2]*0.9f; }
                    for (int k = 0; k < 4; k++){ m.idx.push_back(r[(k+1)%4]); m.idx.push_back(r[k]); m.idx.push_back(pt); }
                }
            }
            if (species == 2 && f > 0.45f && f < 0.95f && rnd() < 0.22f){   // long hanging brown cones
                const float s0 = 0.55f + 0.35f * rnd(), d0 = 0.25f + L * s0, cy = y0 - droop * L * s0 * (0.4f + 0.6f * s0) + curl * s0 * s0 * s0 * s0 - 0.05f, cl = 0.75f + 0.30f * rnd(), crd = 0.13f;
                const float cb[3] = {0.30f, 0.17f, 0.09f}; uint16_t r[4];
                for (int k = 0; k < 4; k++){ const float a = k * 1.5707963f; r[k] = push(dx*d0 + crd*std::cos(a), cy, dz*d0 + crd*std::sin(a), std::cos(a), 0.f, std::sin(a), 1.f, 0.f, 0.f, 2.f); float* c = &m.v[(size_t)r[k]*12 + 6]; c[0] = cb[0]; c[1] = cb[1]; c[2] = cb[2]; }
                const uint16_t pt = push(dx*d0, cy - cl, dz*d0, 0.f, -1.f, 0.f, 1.f, 0.f, 0.f, 2.f); { float* c = &m.v[(size_t)pt*12 + 6]; c[0] = cb[0]*0.8f; c[1] = cb[1]*0.8f; c[2] = cb[2]*0.8f; }
                for (int k = 0; k < 4; k++){ m.idx.push_back(r[k]); m.idx.push_back(r[(k+1)%4]); m.idx.push_back(pt); }
            }
            if (species == 2 || species == 4){   // Norway spruce: side-twigs; larch: long slender pendulous twigs hang down from every branch like a curtain, tips curl up
                const int nt = species == 4 ? 5 : 6;
                for (int t = 0; t < nt; t++){
                    const float s0 = 0.22f + 0.72f * ((float)t + 0.6f * rnd()) / (float)nt, d0 = 0.25f + L * s0, side = (t & 1) ? 1.f : -1.f;
                    const float by = y0 - droop * L * s0 * (0.4f + 0.6f * s0) + curl * s0 * s0 * s0 * s0;
                    const float tl = std::max(0.35f, L * (species == 4 ? 0.75f - 0.35f * s0 : 0.55f - 0.30f * s0) * (0.8f + 0.4f * rnd())), tw = tl * (species == 4 ? 0.09f : 0.17f);
                    const float ox = dx * 0.30f + px * side * 0.40f, oz = dz * 0.30f + pz * side * 0.40f, ol = std::sqrt(ox*ox + oz*oz) + 1e-4f, wx = -oz / ol, wz = ox / ol;
                    const float tt = tone * (0.86f + 0.22f * rnd()), U[4] = {0.f, 0.33f, 0.66f, 1.f}, TW[4] = {0.30f, 1.0f, 0.75f, 0.f};
                    uint16_t a[3], b[3], e = 0;
                    for (int k = 0; k < 4; k++){
                        const float u = U[k], cx = dx*d0 + ox*u*tl, cz = dz*d0 + oz*u*tl, cy = by - (species == 4 ? 1.0f : 0.92f) * tl * u + (species == 4 ? 0.06f : 0.22f) * tl * u * u * u * u, w = tw * TW[k], c2 = tt * (0.90f + 0.30f * u);
                        if (k < 3){ a[k] = push(cx + wx*w, cy, cz + wz*w, ox, 0.5f, oz, c2, s0 + u * 0.4f, -1.f, brFl); b[k] = push(cx - wx*w, cy, cz - wz*w, ox, 0.5f, oz, c2, s0 + u * 0.4f, 1.f, brFl); }
                        else e = push(cx, cy - 0.02f * tl, cz, ox, 0.5f, oz, c2, 1.f, 0.f, brFl);
                    }
                    for (int k = 0; k < 2; k++){ m.idx.push_back(a[k]); m.idx.push_back(b[k]); m.idx.push_back(a[k+1]); m.idx.push_back(b[k]); m.idx.push_back(b[k+1]); m.idx.push_back(a[k+1]); }
                    m.idx.push_back(a[2]); m.idx.push_back(b[2]); m.idx.push_back(e);
                }
            }
        }
    }
    // leader (the very top): a little upright tuft
    for (int b = 0; b < 4; b++){ const float a = b * 1.5707963f + 0.4f; const uint16_t p0 = push(0.f, H * 0.93f, 0.f, 0.f, 1.f, 0.f, 0.9f), p1 = push(0.18f*std::cos(a), H * 0.95f, 0.18f*std::sin(a), 0.f, 1.f, 0.f, 1.1f), p2 = push(0.f, H * 1.02f, 0.f, 0.f, 1.f, 0.f, 1.2f);
        m.idx.push_back(p0); m.idx.push_back(p1); m.idx.push_back(p2); }
}

// ---------------- MEDIUM-QUALITY pine / spruce: a hand-designed "star tier" model (Normal graphics level) ----------------
// Between the faceted low-poly tree and the full needle-branch tree. Every tier is a STAR-SHAPED skirt: 10 branch tips, long and short ones alternating, with a
// little random spread and droop, so the silhouette already looks like real branch whorls. Tiers overlap and each is turned against the one below. Smooth-ish lighting
// per facet, a dark underside under every skirt (self-shadow), lit tips on the top, a small leader spike. ~130 triangles per tree, no shader needles needed.
inline void buildConiferMid(ConiferMesh& m, int species){
    if (species == 7){ buildCherry(m, 2); return; }
    if (species >= 5){ buildBroadleaf(m, 2, species); return; }
    const float H = 16.f, R = H * spPick(species, 0.17f, 0.22f, 0.150f, 0.190f, 0.160f);
    const float base[3] = {spPick(species, 0.105f, 0.150f, 0.072f, 0.112f, 0.200f), spPick(species, 0.225f, 0.255f, 0.195f, 0.215f, 0.350f), spPick(species, 0.135f, 0.095f, 0.112f, 0.140f, 0.120f)};
    auto push = [&](float x, float y, float z, float nx, float ny, float nz, const float* col, float c, float fl){
        const float l = std::sqrt(nx*nx + ny*ny + nz*nz); const float a[12] = {x, y, z, nx/l, ny/l, nz/l, col[0]*c, col[1]*c, col[2]*c, 0.f, 0.f, fl};
        m.v.insert(m.v.end(), a, a + 12); return (uint16_t)(m.v.size() / 12 - 1); };
    uint32_t seed = 4242u + (uint32_t)species * 911u; auto rnd = [&]{ seed = seed * 1664525u + 1013904223u; return (float)(seed >> 8) / 16777216.f; };
    { const float bk[3] = {species == 3 ? 0.36f : (species == 2 ? 0.31f : (species == 4 ? 0.33f : 0.22f)), species == 3 ? 0.33f : (species == 2 ? 0.17f : (species == 4 ? 0.19f : 0.15f)), species == 3 ? 0.29f : (species == 2 ? 0.11f : (species == 4 ? 0.12f : 0.09f))}, tr = 0.50f, top = H * 0.97f, tt = 0.10f;       // trunk runs up through the crown (visible between the tiers)
      for (int j = 0; j < 5; j++){
          const float a0 = j * 6.2831853f / 5, a1 = (j + 1) * 6.2831853f / 5, am = (a0 + a1) * 0.5f, nx = std::cos(am), nz = std::sin(am);
          const uint16_t p0 = push(tr*std::cos(a0), -3.f, tr*std::sin(a0), nx, 0.f, nz, bk, 1.f, 2.f), p1 = push(tr*std::cos(a1), -3.f, tr*std::sin(a1), nx, 0.f, nz, bk, 1.f, 2.f),
                         p2 = push(tr*tt*std::cos(a0), top, tr*tt*std::sin(a0), nx, 0.f, nz, bk, 0.9f, 2.f), p3 = push(tr*tt*std::cos(a1), top, tr*tt*std::sin(a1), nx, 0.f, nz, bk, 0.9f, 2.f);
          const uint16_t t[6] = {p0, p1, p2, p1, p3, p2}; m.idx.insert(m.idx.end(), t, t + 6); } }
    const int tiers = species == 3 ? 8 : (species >= 4 ? 7 : (species == 2 ? 10 : (species == 0 ? 7 : 5))), N = 10;
    for (int i = 0; i < tiers; i++){
        const float f = tiers > 1 ? (float)i / (tiers - 1) : 0.f;
        const float y0 = H * (0.13f + 0.64f * f), ht = H * spPick(species, 0.30f, 0.36f, 0.25f, 0.30f, 0.27f) * (1.f - 0.30f * f), y1 = y0 + ht;
        const float r = R * (1.18f - 0.80f * f), rot = i * 0.61f;                                    // each tier turned by a different angle
        const float droop = spPick(species, 0.050f, 0.025f, 0.100f, 0.030f, 0.085f) * H * (1.f - 0.5f * f);                 // spruce branches hang lower than pine
        const float cb = 0.55f + 0.18f * f, ct = 1.10f + 0.14f * f;                                  // dark rim -> lit crown
        float tx[N], tz[N], ty[N];
        for (int j = 0; j < N; j++){
            const float a = rot + (j + 0.35f * (rnd() - 0.5f)) * 6.2831853f / N, rr = r * ((j & 1) ? 0.70f : 1.f) * (0.92f + 0.16f * rnd());   // long / short tips alternate
            tx[j] = rr * std::cos(a); tz[j] = rr * std::sin(a); ty[j] = y0 - droop * (rr / r) + 0.25f * (rnd() - 0.5f);
        }
        for (int j = 0; j < N; j++){
            const int k = (j + 1) % N;
            const float mx = (tx[j] + tx[k]) * 0.5f, mz = (tz[j] + tz[k]) * 0.5f, ml = std::sqrt(mx*mx + mz*mz) + 1e-4f;
            const float nx = mx / ml * ht, nz = mz / ml * ht, ny = r * 0.9f;
            const uint16_t a = push(tx[j], ty[j], tz[j], nx, ny, nz, base, cb * (0.92f + 0.16f * ((j & 1) ? 1.f : 0.f)), 0.f);
            const uint16_t b = push(tx[k], ty[k], tz[k], nx, ny, nz, base, cb * (0.92f + 0.16f * (((k) & 1) ? 1.f : 0.f)), 0.f);
            const uint16_t c = push(0.f, y1, 0.f, nx, ny, nz, base, ct, 0.f);
            m.idx.push_back(a); m.idx.push_back(b); m.idx.push_back(c);
            const uint16_t d = push(0.f, y0 + 0.15f * ht, 0.f, 0.f, -1.f, 0.f, base, cb * 0.55f, 0.f);   // underside: dark, in the shade of the tier
            const uint16_t e = push(tx[j], ty[j], tz[j], 0.f, -1.f, 0.f, base, cb * 0.65f, 0.f);
            const uint16_t g = push(tx[k], ty[k], tz[k], 0.f, -1.f, 0.f, base, cb * 0.65f, 0.f);
            m.idx.push_back(d); m.idx.push_back(e); m.idx.push_back(g);
        }
    }
    for (int b = 0; b < 4; b++){ const float a = b * 1.5707963f + 0.4f;                                // leader: a little upright spike at the very top
        const uint16_t p0 = push(0.f, H * 0.90f, 0.f, 0.f, 1.f, 0.f, base, 0.95f, 0.f), p1 = push(0.20f*std::cos(a), H * 0.91f, 0.20f*std::sin(a), std::cos(a), 0.4f, std::sin(a), base, 1.1f, 0.f),
                       p2 = push(0.f, H * 1.00f, 0.f, 0.f, 1.f, 0.f, base, 1.25f, 0.f);
        m.idx.push_back(p0); m.idx.push_back(p1); m.idx.push_back(p2); }
}

// ---- Climbing vines (ivy-like): three irregular vines that creep up a conifer trunk (species 0-4 share the same trunk: radius 0.5 m at y=-3 tapering to 0.03 m at y=15.5).
// Thick woody foot with a root flare, wandering (not a perfect spiral) path, leaves folded along the midrib and overlapping like shingles, drooping side shoots.
// Same 12-float vertex layout as the conifers; stem = flag 2 (bark shader), leaves = flag 3.2 (palmate) / 3.0 (simple). Unit tree height 16 m, scaled by the tree instance.
inline void buildVine(ConiferMesh& m){
    auto push = [&](const float* P, const float* N, const float* col, float c, float u, float v, float fl){
        const float l = std::sqrt(N[0]*N[0] + N[1]*N[1] + N[2]*N[2]) + 1e-6f; const float a[12] = {P[0], P[1], P[2], N[0]/l, N[1]/l, N[2]/l, col[0]*c, col[1]*c, col[2]*c, u, v, fl};
        m.v.insert(m.v.end(), a, a + 12); return (uint16_t)(m.v.size() / 12 - 1); };
    uint32_t seed = 777u; auto rnd = [&]{ seed = seed * 1664525u + 1013904223u; return (float)(seed >> 8) / 16777216.f; };
    auto trunkR = [](float y){ return 0.5f * (1.f - 0.94f * std::min(1.f, std::max(0.f, (y + 3.f) / 18.52f))); };
    auto norm3 = [](float* v){ const float l = std::sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]) + 1e-6f; v[0] /= l; v[1] /= l; v[2] /= l; };
    auto cross3 = [](const float* a, const float* b, float* o){ o[0] = a[1]*b[2] - a[2]*b[1]; o[1] = a[2]*b[0] - a[0]*b[2]; o[2] = a[0]*b[1] - a[1]*b[0]; };
    const float stemCol[3] = {0.17f, 0.12f, 0.07f};
    // one leaf, folded along its midrib (two quads, the centre line lifted away from the surface): P = leaf base, ax = leaf axis, sd = side, nrm = lighting normal
    auto leaf = [&](const float* P, const float* ax, const float* sd, const float* R, float ll, float hw, float shade, bool palm, float bulge){
        const float fl = palm ? 3.2f : 3.0f; float col[3] = {0.15f + 0.05f * rnd(), 0.33f + 0.08f * rnd(), 0.07f + 0.03f * rnd()};
        if (rnd() < 0.07f){ col[0] *= 2.0f; col[1] *= 1.15f; }                                        // a few yellowing leaves
        float nA[3] = {R[0] * 0.8f - sd[0] * 0.5f, 0.45f - sd[1] * 0.5f, R[2] * 0.8f - sd[2] * 0.5f}, nB[3] = {R[0] * 0.8f + sd[0] * 0.5f, 0.45f + sd[1] * 0.5f, R[2] * 0.8f + sd[2] * 0.5f};
        const float lift[3] = {R[0] * hw * bulge, R[1] * hw * bulge, R[2] * hw * bulge};
        uint16_t q[6]; const float us[3] = {-1.f, 0.f, 1.f};
        for (int r = 0; r < 2; r++) for (int c = 0; c < 3; c++){
            const float sx = us[c] * hw, along = r * ll, mid = (c == 1) ? 1.f : 0.f;
            const float Q[3] = {P[0] + ax[0]*along + sd[0]*sx + lift[0]*mid, P[1] + ax[1]*along + sd[1]*sx + lift[1]*mid, P[2] + ax[2]*along + sd[2]*sx + lift[2]*mid};
            q[r*3 + c] = push(Q, c == 0 ? nA : (c == 2 ? nB : R), col, shade, us[c], (float)r, fl); }
        const uint16_t t[12] = {q[0], q[1], q[3], q[1], q[4], q[3], q[1], q[2], q[4], q[2], q[5], q[4]}; m.idx.insert(m.idx.end(), t, t + 12); };
    struct VineDef { float y0, y1, turns, ph0, thick; };
    const VineDef D[3] = {{-0.4f, 13.5f, 1.5f, 0.4f, 1.0f}, {-0.4f, 9.0f, 1.1f, 2.7f, 0.8f}, {-0.4f, 5.5f, 0.8f, 4.9f, 0.6f}};
    for (int vi = 0; vi < 3; vi++){
        const VineDef& d = D[vi]; const int N = 40;
        const float w1 = 5.f + 3.f * rnd(), w2 = 11.f + 5.f * rnd(), p1 = rnd() * 6.28f, p2 = rnd() * 6.28f;
        auto pos = [&](float f, float* P, float* R, float* T){
            const float y = d.y0 + (d.y1 - d.y0) * f;
            const float th = d.ph0 + 6.2831853f * d.turns * f + 0.55f * std::sin(f * w1 + p1) + 0.22f * std::sin(f * w2 + p2);   // wanders left and right instead of a regular spiral
            const float flare = 1.f + 0.9f * std::exp(-(y + 0.4f) * 1.6f);                              // root flare: hugs / spreads at the foot
            const float r = trunkR(y) * 0.90f + 0.028f * flare + 0.010f * std::sin(f * 31.f + vi);
            R[0] = std::cos(th); R[1] = 0.f; R[2] = std::sin(th); P[0] = R[0] * r; P[1] = y; P[2] = R[2] * r;
            const float f2 = std::min(1.f, f + 0.01f); const float y2 = d.y0 + (d.y1 - d.y0) * f2, th2 = d.ph0 + 6.2831853f * d.turns * f2 + 0.55f * std::sin(f2 * w1 + p1) + 0.22f * std::sin(f2 * w2 + p2);
            const float r2 = trunkR(y2) * 0.90f + 0.028f; T[0] = std::cos(th2) * r2 - P[0]; T[1] = y2 - y; T[2] = std::sin(th2) * r2 - P[2]; norm3(T); };
        // woody stem: 4-sided tube, thick at the foot, thinning with height
        const uint16_t first = (uint16_t)(m.v.size() / 12);
        for (int i = 0; i <= N; i++){
            const float f = (float)i / N; float P[3], R[3], T[3]; pos(f, P, R, T);
            float B[3]; cross3(T, R, B); norm3(B);
            const float sr = 0.045f * d.thick * (1.9f - 1.5f * std::pow(f, 0.7f)) * (1.f + 0.12f * std::sin(f * 60.f + vi * 3.f));
            for (int k = 0; k < 4; k++){ const float a = k * 1.5707963f, ca = std::cos(a), sa = std::sin(a);
                const float n[3] = {R[0]*ca + B[0]*sa, R[1]*ca + B[1]*sa, R[2]*ca + B[2]*sa}; const float q[3] = {P[0] + n[0]*sr, P[1] + n[1]*sr, P[2] + n[2]*sr};
                push(q, n, stemCol, 0.9f + 0.2f * rnd(), 0.f, 0.f, 2.f); }
        }
        for (int i = 0; i < N; i++) for (int k = 0; k < 4; k++){
            const uint16_t a = (uint16_t)(first + i*4 + k), b = (uint16_t)(first + i*4 + (k + 1) % 4), c = (uint16_t)(first + (i + 1)*4 + k), e = (uint16_t)(first + (i + 1)*4 + (k + 1) % 4);
            const uint16_t t[6] = {a, b, c, b, e, c}; m.idx.insert(m.idx.end(), t, t + 6); }
        // leaves: dense, overlapping like ivy; big ones low, small young ones high; lying against the bark, tips tilting out
        const float len = std::sqrt(std::pow(6.2831853f * d.turns * 0.35f, 2.f) + std::pow(d.y1 - d.y0, 2.f));
        const int nl = (int)(len / 0.15f);
        for (int i = 0; i < nl; i++){
            const float f = (i + rnd()) / nl; if (f > 1.f) continue;
            float P[3], R[3], T[3]; pos(f, P, R, T);
            const float tang[3] = {-R[2], 0.f, R[0]}; const float side = rnd() < 0.5f ? -1.f : 1.f;
            const float phi = (rnd() - 0.5f) * 3.0f + (rnd() < 0.3f ? 3.14159f : 0.f);                // mostly pointing up, some hanging down, some sideways
            const float out = 0.10f + 0.40f * rnd();
            float ax[3] = {tang[0]*std::sin(phi)*side + R[0]*out, std::cos(phi), tang[2]*std::sin(phi)*side + R[2]*out}; norm3(ax);
            float sd[3]; cross3(ax, R, sd); norm3(sd);
            const float ll = (0.20f + 0.20f * rnd()) * (1.15f - 0.45f * f), hw = ll * 0.50f;
            leaf(P, ax, sd, R, ll, hw, 0.72f + 0.42f * rnd(), rnd() < 0.72f, 0.28f + 0.2f * rnd());
            // every so often a short side shoot droops away from the trunk with a few leaves on it
            if (i % 9 == 4 && f > 0.08f && f < 0.97f && vi < 2){
                const float a0 = (rnd() - 0.5f) * 1.6f; float dir[3] = {R[0] + tang[0]*a0, 0.15f, R[2] + tang[2]*a0}; norm3(dir);
                const float sl = 0.45f + 0.65f * rnd(); const int ns = 4;
                float cur[3] = {P[0], P[1], P[2]}; float prev[3] = {P[0], P[1], P[2]};
                for (int s2 = 1; s2 <= ns; s2++){
                    const float u = (float)s2 / ns; prev[0] = cur[0]; prev[1] = cur[1]; prev[2] = cur[2];
                    cur[0] = P[0] + dir[0] * sl * u; cur[1] = P[1] + dir[1] * sl * u - 0.55f * sl * u * u; cur[2] = P[2] + dir[2] * sl * u;       // gravity bends it down
                    float sax[3] = {cur[0] - prev[0], cur[1] - prev[1], cur[2] - prev[2]}; const float seg = std::sqrt(sax[0]*sax[0] + sax[1]*sax[1] + sax[2]*sax[2]); norm3(sax);
                    float sn[3]; const float upv[3] = {0.f, 1.f, 0.f}; cross3(sax, upv, sn); norm3(sn);
                    const float sw = 0.010f * (1.2f - 0.6f * u);                                           // a thin stem segment as a flat ribbon
                    const float e[4][3] = {{prev[0] - sn[0]*sw, prev[1] - sn[1]*sw, prev[2] - sn[2]*sw}, {prev[0] + sn[0]*sw, prev[1] + sn[1]*sw, prev[2] + sn[2]*sw},
                                           {cur[0] - sn[0]*sw, cur[1] - sn[1]*sw, cur[2] - sn[2]*sw}, {cur[0] + sn[0]*sw, cur[1] + sn[1]*sw, cur[2] + sn[2]*sw}}; const float nn[3] = {R[0], 0.3f, R[2]};
                    const uint16_t q0 = push(e[0], nn, stemCol, 1.f, 0.f, 0.f, 2.f), q1 = push(e[1], nn, stemCol, 1.f, 0.f, 0.f, 2.f), q2 = push(e[2], nn, stemCol, 1.f, 0.f, 0.f, 2.f), q3 = push(e[3], nn, stemCol, 1.f, 0.f, 0.f, 2.f);
                    const uint16_t t[6] = {q0, q1, q2, q1, q3, q2}; m.idx.insert(m.idx.end(), t, t + 6);
                    (void)seg;
                    // leaf hanging off this node: points along the shoot and sags
                    float lax[3] = {sax[0] + (rnd() - 0.5f) * 0.8f, sax[1] - 0.35f - 0.4f * rnd(), sax[2] + (rnd() - 0.5f) * 0.8f}; norm3(lax);
                    float lsd[3]; const float nrm0[3] = {dir[0], 0.6f, dir[2]}; cross3(lax, nrm0, lsd); norm3(lsd);
                    float nrm[3] = {nrm0[0], nrm0[1], nrm0[2]}; norm3(nrm);
                    const float ll2 = (0.16f + 0.18f * rnd()) * (1.1f - 0.3f * u);
                    leaf(cur, lax, lsd, nrm, ll2, ll2 * 0.5f, 0.78f + 0.40f * rnd(), rnd() < 0.7f, 0.25f);
                }
            }
        }
    }
}

} // namespace TreeModel
