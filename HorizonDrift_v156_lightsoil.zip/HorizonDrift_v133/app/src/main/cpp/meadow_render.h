// Sunny Drift - Alpine meadow: wildflowers, tall meadow grass and shrubs (replaces the dense roadside forest).
//  Three ring-buffer layers that follow the camera, built exactly like GrassGL (only cells that newly come into range are computed, one instanced draw each):
//   * FLOWERS    - small wildflowers (daisy, buttercup, bellflower, pink, poppy, lilac) growing in colour patches, from ~2.5 m off the road edge outwards
//   * TALL GRASS - taller, swaying meadow grass clumps (golden-green, a few dry blades) beside the road; the short GrassGL carpet stays underneath
//   * BUSHES     - low leafy shrubs (dark green / olive / juniper blue-green, some with alpine-rose blossom), mostly 5-45 m from the road
//  Everything is made in the vertex shader from gl_VertexID (no meshes, no per-instance CPU work). Cells are only filled where the ground is real grass.
#pragma once
#include <GLES3/gl3.h>
#include <cmath>
#include <climits>
#include <vector>
#include <algorithm>
#include "sun_light.h"
#include "quality.h"
#include "terrain.h"
#include "road.h"
#include "river.h"
#include "village.h"
#include "tunnel.h"
#include "nature_plan.h"

namespace MeadowGL {

static inline float hash2(long a, long b, int s){ unsigned x = (unsigned)(a*374761393L + b*668265263L + s*2246822519L); x = (x ^ (x >> 13)) * 1274126177u; x ^= x >> 16; return (x & 0xFFFFFF) / 16777216.f; }
static inline float ss(float a, float b, float x){ x = std::min(1.f, std::max(0.f, (x - a) / (b - a))); return x*x*(3 - 2*x); }
static inline float hs(float x, float y){ const float h = std::sin(x*127.1f + y*311.7f) * 43758.5453f; return h - std::floor(h); }
static float vn(float x, float y){ const float ix = std::floor(x), iy = std::floor(y), fx = x - ix, fy = y - iy, u = fx*fx*(3 - 2*fx), v = fy*fy*(3 - 2*fy);
    return (hs(ix, iy)*(1-u) + hs(ix+1, iy)*u)*(1-v) + (hs(ix, iy+1)*(1-u) + hs(ix+1, iy+1)*u)*v; }

// ---------------------------------------------------------------------------------------------------------------------------------
// shaders
// ---------------------------------------------------------------------------------------------------------------------------------
#define MEADOW_WIND \
  "const vec2 WD = vec2(0.85, 0.53);\n" \
  "float windAt(vec3 b, float sd){ return sin(dot(b.xz, WD)*0.6 - uTime*2.6 + sd*1.5)*0.5 + sin(b.x*0.31 + b.z*0.23 - uTime*1.7)*0.5; }\n"

#define MEADOW_HEAD \
  "#version 300 es\n" \
  "layout(location=0) in vec4 aP; layout(location=1) in vec4 aC;\n" \
  "uniform mat4 uVP; uniform vec3 uCam; uniform vec3 uCar; uniform float uTime;\n" \
  "float h(float n){ return fract(sin(n*91.345 + 17.7)*43758.5453); }\n" \
  MEADOW_WIND

// ---- wildflowers: curved stem (9 v) + 2 leaves (6 v) + 10 petal slots (2 triangles each = 60 v) + centre disc (8 triangles = 24 v) = 99 vertices ----
// the species (0 daisy, 1 buttercup, 2 bellflower, 3 pink, 4 poppy, 5 cranesbill) is packed into aC.w: species = floor(aC.w*6)
static const char* FL_VS = MEADOW_HEAD R"GLSL(
out vec3 vCol; out float vPart; out float vR; out float vD; out float vH; out float vSp; out float vA; out vec3 vN; out vec3 vV; out float vU;
void main(){
  if (aP.w < 0.01){ gl_Position = vec4(2.0, 2.0, 2.0, 1.0); vCol = vec3(0.0); vPart = 0.0; vR = 0.0; vD = 0.0; vH = 0.0; vSp = 0.0; vA = 0.0; vN = vec3(0.0, 1.0, 0.0); vV = vec3(0.0, 1.0, 0.0); vU = 0.0; return; }
  int k = gl_VertexID;
  float sp = floor(aC.w*6.0); float seed = aC.w*61.0;
  vec3 base = aP.xyz;
  float d = length(base.xz - uCam.xz);
  float fade = 1.0 - smoothstep(26.0, 36.0, d);
  float press = mix(0.25, 1.0, smoothstep(1.0, 2.6, length(base.xz - uCar.xz)));
  float hgt = (0.22 + 0.28*h(seed + 2.7))*aP.w*fade*press;
  float w = windAt(base, h(seed));
  vec3 lean = vec3(WD.x, 0.0, WD.y)*(w*0.5 + 0.4)*hgt*0.30 + vec3(h(seed + 5.0) - 0.5, 0.0, h(seed + 6.0) - 0.5)*0.35*hgt;
  vec3 tip = base + vec3(0.0, hgt, 0.0) + lean;
  // per-species head: petal count, petal length / half-width, how far the petals cup upwards, size
  float nP = 8.0, pl = 1.0, hw = 0.20, cup = 0.05, size = 0.060;
  if (sp < 0.5){ nP = 10.0; pl = 1.0; hw = 0.30; cup = 0.04; size = 0.050; }        // daisy: many thin white rays
  else if (sp < 1.5){ nP = 5.0; pl = 0.85; hw = 0.50; cup = 0.55; size = 0.055; }   // buttercup: 5 broad glossy cups
  else if (sp < 2.5){ nP = 5.0; pl = 0.80; hw = 0.42; cup = 0.95; size = 0.062; }   // bellflower: deep nodding bell
  else if (sp < 3.5){ nP = 5.0; pl = 1.0; hw = 0.46; cup = 0.15; size = 0.052; }    // pink: flat, 5 wide petals
  else if (sp < 4.5){ nP = 4.0; pl = 1.15; hw = 0.80; cup = 0.60; size = 0.078; }   // poppy: 4 big papery cups
  else { nP = 5.0; pl = 1.0; hw = 0.44; cup = 0.25; size = 0.058; }                 // cranesbill: 5 rounded petals
  vec3 pos; float part = 0.0, rr = 0.0, hv = 0.0, uu = 0.0; vec3 nrm = vec3(0.0, 1.0, 0.0);
  float ang = h(seed + 4.1)*3.14159265;
  vec3 sv = vec3(cos(ang), 0.0, sin(ang));
  if (k < 9){                                                                       // curved stem: root -> mid -> head
    const int LV[9] = int[9](0, 0, 1, 0, 1, 1, 1, 1, 2);
    const int SD[9] = int[9](-1, 1, -1, 1, 1, -1, -1, 1, 0);
    int lv = LV[k]; float sd = float(SD[k]);
    float t = (lv == 0) ? 0.0 : ((lv == 1) ? 0.5 : 1.0);
    float wid = 0.0042*(1.0 - 0.35*t)*(lv == 2 ? 0.5 : 1.0);
    pos = base + sv*wid*sd + lean*t*t + vec3(0.0, hgt*t, 0.0) - vec3(0.0, 0.03*(1.0 - t), 0.0);
    hv = t; uu = sd; nrm = normalize(cross(sv, vec3(lean.x*2.0*t, hgt, lean.z*2.0*t)));
  } else if (k < 15){                                                               // two small leaves low on the stem
    int q = k - 9; int lf = q/3; int v = q - lf*3;
    float la = ang + float(lf)*3.14159265 + 0.6*h(seed + 11.0);
    vec3 dir = vec3(cos(la), 0.0, sin(la));
    vec3 at = base + vec3(0.0, hgt*(0.22 + 0.18*float(lf)), 0.0) + lean*0.05;
    float ll = (0.06 + 0.05*h(seed + 12.0))*(0.6 + 0.4*aP.w)*fade;
    vec3 sd2 = vec3(-dir.z, 0.0, dir.x)*ll*0.16;
    if (v == 0) pos = at - sd2; else if (v == 1) pos = at + sd2; else pos = at + dir*ll + vec3(0.0, ll*0.35, 0.0);
    hv = (v == 2) ? 0.8 : 0.3; nrm = normalize(vec3(0.0, 1.0, 0.0) + dir*0.35); part = 3.0; rr = (v == 2) ? 1.0 : 0.0; uu = (v == 0) ? -1.0 : ((v == 1) ? 1.0 : 0.0);
  } else {
    float R = size*(0.6 + 0.4*aP.w)*fade*(0.85 + 0.30*h(seed + 9.1));
    vec3 toCam = vec3(uCam.x - base.x, 0.0, uCam.z - base.z); toCam /= max(length(toCam), 0.001);
    float nod = (sp > 1.5 && sp < 2.5) ? 1.0 : 0.0;
    vec3 n = normalize(vec3(0.0, 0.70, 0.0) + toCam*(0.50 - 0.30*nod) + sv*(0.18 - 0.5*nod)*(h(seed + 7.0) - 0.2) + vec3(h(seed + 7.0) - 0.5, 0.0, h(seed + 8.0) - 0.5)*0.55 + lean*0.5);
    vec3 t1 = normalize(cross(n, vec3(0.0, 0.0, 1.0))); vec3 t2 = cross(n, t1);
    vec3 ctr = tip + n*0.004;
    int q = k - 15;
    if (q < 60){                                                                    // petal slots: kite = centre, left edge, tip, right edge
      int pi_ = q/6; int vv = q - pi_*6;
      if (float(pi_) >= nP){ pos = ctr; part = 1.0; rr = 0.0; }                     // unused slot collapses into the centre
      else {
        float a0 = float(pi_)*6.2831853/nP + h(seed + 3.3)*6.2831853 + 0.25*h(seed + float(pi_));
        float pw = 6.2831853/nP*hw;                                                 // half angular width of this petal
        float pj = pl*(0.90 + 0.20*h(seed + float(pi_)*1.7));                       // slightly uneven petal length
        float cupP = cup*(0.70 + 0.60*h(seed + float(pi_)*2.9));                    // every petal curls a little differently
        // petal = kite of 2 triangles: (centre, left edge, tip) + (centre, tip, right edge)
        int idx = (vv == 0 || vv == 3) ? 0 : ((vv == 1) ? 1 : ((vv == 2 || vv == 4) ? 4 : 3));
        float aa = a0; float rad = 0.0; float lift = 0.0; float ry = 0.0;
        if (idx == 1){ aa = a0 - pw; rad = 0.66*pj; lift = cupP*0.45*pj; ry = 0.55; uu = -1.0; }        // widest point, left
        else if (idx == 3){ aa = a0 + pw; rad = 0.66*pj; lift = cupP*0.45*pj; ry = 0.55; uu = 1.0; }   // widest point, right
        else if (idx == 4){ aa = a0; rad = pj; lift = cupP*pj; ry = 1.0; }                  // tip
        if (nod > 0.5) rad *= 0.75;
        pos = ctr + (t1*cos(aa) + t2*sin(aa))*R*rad + n*R*lift;
        part = 1.0; rr = ry; nrm = normalize(n*0.8 + (t1*cos(a0) + t2*sin(a0))*0.5);
      }
    } else {                                                                        // flower centre: 8-triangle fan, a little domed
      int qq = q - 60; int tr = qq/3; int vv = qq - tr*3;
      float Rc = R*((sp < 0.5) ? 0.36 : (sp > 3.5 && sp < 4.5) ? 0.30 : 0.22);
      pos = ctr + n*R*0.06;
      if (vv != 0){
        float aa = (float(tr) + float(vv - 1))*0.7853982;
        pos = ctr + (t1*cos(aa) + t2*sin(aa))*Rc + n*R*0.02;
      }
      part = 2.0; rr = (vv == 0) ? 0.0 : 1.0; nrm = n;
    }
    hv = 1.0;
  }
  vCol = aC.rgb; vPart = part; vR = rr; vH = hv; vD = length(pos - uCam); vSp = sp; vA = fade; vU = uu; vN = nrm; vV = normalize(uCam - pos);
  gl_Position = uVP*vec4(pos, 1.0);
}
)GLSL";
static const char* FL_FS = R"GLSL(#version 300 es
precision mediump float;
in vec3 vCol; in float vPart; in float vR; in float vD; in float vH; in float vSp; in float vA; in vec3 vN; in vec3 vV; in float vU; out vec4 o;
void main(){
  // petals and leaves are cut out of the kite / triangle they are built on: rounded tips, lanceolate leaves
  if (vPart > 2.5){
    float al = 0.90*sin(3.14159*pow(clamp(vR, 0.0, 1.0), 0.6)) + 0.05;
    if (abs(vU) > al) discard;
  } else if (vPart > 0.5 && vPart < 1.5){
    float rt = max(vR - 0.5, 0.0)*2.0;
    if (vU*vU*1.12 + rt*rt > 1.0) discard;
  }
  vec3 L = SUNL; vec3 V = normalize(vV);
  vec3 N = normalize(vN); if (dot(N, V) < 0.0) N = -N;
  float nd = dot(N, L); float d = max(nd, 0.0), wrap = max(nd*0.5 + 0.5, 0.0);
  vec3 amb = mix(vec3(0.26, 0.30, 0.20), vec3(0.55, 0.68, 0.95), N.y*0.5 + 0.5)*0.85;
  vec3 lit = amb + vec3(1.08, 1.0, 0.82)*(0.45*d + 0.40*wrap);
  vec3 c;
  if (vPart > 2.5){                                                                 // leaf: pale midrib, darker blade, glows when backlit
    vec3 g = mix(vec3(0.05, 0.17, 0.03), vec3(0.22, 0.46, 0.09), 0.30 + 0.70*vR);
    g = mix(g, g*1.55 + vec3(0.03, 0.04, 0.0), smoothstep(0.12, 0.0, abs(vU))*(1.0 - 0.5*vR));
    c = g*lit + g*vec3(0.30, 0.34, 0.04)*pow(max(dot(-V, L), 0.0), 2.0);
  } else if (vPart < 0.5){                                                          // stem: darker at the root, a lit edge
    vec3 g = mix(vec3(0.07, 0.20, 0.04), vec3(0.26, 0.48, 0.11), vH);
    g *= 0.88 + 0.22*smoothstep(1.0, 0.0, abs(vU));
    c = g*lit;
  } else if (vPart < 1.5){                                                          // petals: colour deepens toward the throat, paler / thinner at the rim, fine veins
    vec3 pc = vCol;
    float edge = smoothstep(0.55, 1.0, vR);
    vec3 col = mix(pc*0.78, pc*1.04 + vec3(0.03), edge);                            // throat a bit darker, rim lighter
    float vein = 0.5 + 0.5*cos(vU/max(vR*0.9 + 0.12, 0.12)*9.0);                    // veins radiate from the throat
    col *= 1.0 - 0.11*vein*(1.0 - 0.6*edge);
    col = mix(col, col*0.86, smoothstep(0.85, 1.0, abs(vU))*0.7);                   // slightly darker, thinner side edges
    if (vSp > 1.5 && vSp < 2.5) col = mix(col*0.78, col*1.05, edge);                // bellflower: deeper violet inside
    if (vSp > 2.5 && vSp < 3.5) col = mix(col*0.55, col, smoothstep(0.15, 0.55, vR));   // pink: dark eye ring
    if (vSp > 4.5) col = mix(col*0.55, col, smoothstep(0.10, 0.55, vR));            // cranesbill: veins darken the base
    if (vSp > 3.5 && vSp < 4.5) col = mix(vec3(0.14, 0.02, 0.02), col, smoothstep(0.08, 0.30, vR));   // poppy: dark blotch at the base of every petal
    float thin = (vSp > 3.5 && vSp < 4.5) ? 0.55 : 0.30;                            // poppy petals are papery: they glow most
    c = col*lit + col*vec3(thin, thin*0.88, thin*0.50)*pow(max(dot(-V, L), 0.0), 2.0);   // petals are thin: they glow when the sun is behind them
    if (vSp > 0.5 && vSp < 1.5) c += vec3(0.20, 0.17, 0.04)*pow(max(dot(reflect(-L, N), V), 0.0), 18.0);   // buttercup: glossy shine
    if (vSp > 3.5 && vSp < 4.5) c += vec3(0.06, 0.03, 0.02)*pow(max(dot(reflect(-L, N), V), 0.0), 8.0);    // poppy: silky sheen
  } else {                                                                          // flower centre: domed, darker rim, bright middle
    vec3 cc = vec3(0.96, 0.72, 0.08);                                               // daisy / default: golden disc
    if (vSp > 0.5 && vSp < 1.5) cc = vec3(0.78, 0.66, 0.10);                        // buttercup: green-gold seed head
    else if (vSp > 1.5 && vSp < 2.5) cc = vec3(0.95, 0.92, 0.72);                   // bellflower: pale stamens
    else if (vSp > 2.5 && vSp < 3.5) cc = vec3(0.50, 0.08, 0.22);                   // pink: magenta eye
    else if (vSp > 3.5 && vSp < 4.5) cc = vec3(0.08, 0.06, 0.06);                   // poppy: black centre
    else if (vSp > 4.5) cc = vec3(0.90, 0.88, 0.60);                                // cranesbill: pale centre
    cc *= (0.80 + 0.35*(1.0 - vR))*mix(1.0, 0.62, smoothstep(0.65, 1.0, vR));
    c = cc*(0.55 + 0.55*lit);
  }
  float fog = 1.0 - exp(-pow(vD/2850.0, 1.35));
  c = mix(c, vec3(0.70, 0.88, 0.97), clamp(fog, 0.0, 1.0));
  o = vec4(c, 1.0);
}
)GLSL";

// ---- tall meadow grass: a clump of 6 curved, lit blades = 54 vertices ----
static const char* TG_VS = MEADOW_HEAD R"GLSL(
out float vT; out vec3 vCol; out float vD; out float vW; out float vS; out vec3 vN; out vec3 vV; out float vU;
const int LV[9] = int[9](0, 0, 1, 0, 1, 1, 1, 1, 2);
const int SD[9] = int[9](-1, 1, -1, 1, 1, -1, -1, 1, 0);
void main(){
  if (aP.w < 0.01){ gl_Position = vec4(2.0, 2.0, 2.0, 1.0); vT = 0.0; vCol = vec3(0.0); vD = 0.0; vW = 0.0; vS = 0.0; vN = vec3(0.0, 1.0, 0.0); vV = vec3(0.0, 1.0, 0.0); vU = 0.0; return; }
  int b = gl_VertexID/9, k = gl_VertexID - b*9;
  int lv = LV[k]; float sd = float(SD[k]);
  float seed = aC.w*61.0 + float(b)*7.31;
  float a = h(seed)*6.2831853, rad = h(seed + 1.3)*0.34;
  vec3 base = aP.xyz + vec3(cos(a), 0.0, sin(a))*rad;
  float d = length(base.xz - uCam.xz);
  float fade = 1.0 - smoothstep(40.0, 54.0, d);
  float press = mix(0.30, 1.0, smoothstep(1.0, 2.8, length(base.xz - uCar.xz)));
  float hgt = (0.40 + 0.52*h(seed + 2.7))*aP.w*fade*press;
  float ang = h(seed + 4.1)*3.14159265;
  vec3 sv = vec3(cos(ang), 0.0, sin(ang));
  vec3 ld = vec3(cos(ang + 1.5708), 0.0, sin(ang + 1.5708));
  float lean = (h(seed + 5.5) - 0.5)*2.0;
  float w = windAt(base, h(seed));
  float t = (lv == 0) ? 0.0 : ((lv == 1) ? 0.55 : 1.0);
  float bend = 0.60 + 0.40*h(seed + 9.4);
  vec3 over = (vec3(WD.x, 0.0, WD.y)*(w*0.5 + 0.45) + ld*lean*0.95)*0.40;
  float wid = (0.020 + 0.012*h(seed + 6.2))*(1.0 - 0.60*t)*(lv == 2 ? 0.0 : 1.0);
  vec3 pos = base + sv*wid*sd;
  pos += over*hgt*bend*t*t*1.35;
  pos.y += hgt*t*(1.0 - 0.34*bend*t) - 0.03*(1.0 - t) - hgt*0.08*abs(w)*t*t;
  vec3 tang = normalize(vec3(over.x*bend*2.7*t, 1.0 - 0.68*bend*t, over.z*bend*2.7*t) + vec3(0.0001));
  vT = t; vCol = aC.rgb; vW = w; vD = length(pos - uCam); vS = h(seed + 8.3); vN = normalize(cross(sv, tang)); vV = normalize(uCam - pos); vU = sd;
  gl_Position = uVP*vec4(pos, 1.0);
}
)GLSL";
static const char* TG_FS = R"GLSL(#version 300 es
precision mediump float;
in float vT; in vec3 vCol; in float vD; in float vW; in float vS; in vec3 vN; in vec3 vV; in float vU; out vec4 o;
void main(){
  vec3 L = SUNL; vec3 V = normalize(vV);
  vec3 N = normalize(vN); if (dot(N, V) < 0.0) N = -N;
  N = normalize(N + vec3(0.0, 0.30, 0.0));
  vec3 root = vec3(0.05, 0.15, 0.03), tip = vec3(0.34, 0.66, 0.09);
  vec3 tint = clamp(vec3((vCol.r/max(vCol.g, 0.01))/0.667, 1.0, (vCol.b/max(vCol.g, 0.01))/0.422), 0.75, 1.35);
  vec3 alb = mix(root, tip, smoothstep(0.0, 0.95, vT)) * tint;
  alb *= 0.80 + 0.40*vS;
  float dry = smoothstep(0.70, 0.92, vS);                                           // ~1 blade in 4 is a golden, sun-dried stalk
  alb = mix(alb, vec3(0.85, 0.70, 0.16)*(0.55 + 0.55*vT), dry*0.75);
  alb *= 1.0 - 0.20*(1.0 - smoothstep(0.0, 0.55, abs(vU)));                                 // midrib
  float ao = 0.38 + 0.74*pow(vT, 0.75);
  float nd = dot(N, L); float d = max(nd, 0.0), wrap = max(nd*0.5 + 0.5, 0.0);
  vec3 amb = mix(vec3(0.22, 0.27, 0.15), vec3(0.50, 0.66, 0.95), N.y*0.5 + 0.5)*0.85;
  vec3 c = alb*(amb + vec3(1.08, 1.0, 0.82)*(0.45*d + 0.40*wrap))*ao;
  float back = pow(max(dot(-V, L), 0.0), 3.0);
  c += vec3(0.42, 0.40, 0.08) * back * vT * (0.4 + 0.6*vS);                          // backlit golden stalks
  c += vec3(0.05, 0.06, 0.01) * max(vW, 0.0) * vT;
  float fog = 1.0 - exp(-pow(vD/2850.0, 1.35));
  c = mix(c, vec3(0.70, 0.88, 0.97), clamp(fog, 0.0, 1.0));
  o = vec4(c, 1.0);
}
)GLSL";

// ---- bushes: 3 overlapping lumpy domes, each 8 x 4 quads = 192 vertices (576 per bush); leaf texture, ragged silhouette and blossom are done in the fragment shader ----
static const char* BU_VS = MEADOW_HEAD R"GLSL(
out vec3 vN; out vec3 vWp; out vec3 vCol; out float vSeed; out float vD; out float vY; out vec3 vV;
uniform int uNT; uniform int uNP;
void main(){
  int NT = uNT; int NP = uNP; int PER = NT*NP*6;
  if (aP.w < 0.01){ gl_Position = vec4(2.0, 2.0, 2.0, 1.0); vN = vec3(0.0, 1.0, 0.0); vWp = vec3(0.0); vCol = vec3(0.0); vSeed = 0.0; vD = 0.0; vY = 0.0; vV = vec3(0.0, 1.0, 0.0); return; }
  int b = gl_VertexID/PER; int lv = gl_VertexID - b*PER; int q = lv/6; int v = lv - q*6;
  int i = q - (q/NT)*NT, j = q/NT;
  int ci = i + ((v == 1 || v == 2 || v == 4) ? 1 : 0);
  int cj = j + ((v == 2 || v == 4 || v == 5) ? 1 : 0);
  int cm = ci - (ci/NT)*NT; if (cj == NP) cm = 0;
  float seed = aC.w*61.0 + float(b)*13.7;
  float th = float(ci)*6.2831853/float(NT), ph = float(cj)*1.5707963/float(NP);
  // smooth, continuous lobes (sum of low-frequency waves in angle): round soft dome at any tessellation, no per-vertex spikes
  float k1 = 2.0 + floor(h(seed + 1.3)*2.0), k2 = 3.0 + floor(h(seed + 2.9)*3.0);
  float lump = 0.88 + 0.10*sin(th*k1 + h(seed)*6.28) + 0.06*sin(th*k2 + h(seed + 4.1)*6.28 + ph*2.0);
  if (cj == NP) lump = 0.90;
  float a1 = h(aC.w*61.0 + 3.3)*6.2831853;
  vec2 off = vec2(0.0); float Rb = 1.0;
  if (b == 1){ off = vec2(cos(a1), sin(a1))*0.75; Rb = 0.72; }
  else if (b == 2){ off = vec2(cos(a1 + 2.3), sin(a1 + 2.3))*0.70; Rb = 0.62; }
  float d0 = length(aP.xz - uCam.xz);
  float fade = 1.0 - smoothstep(105.0, 135.0, d0);
  float R = 0.78*aP.w*fade*Rb;
  vec3 dir = vec3(cos(ph)*cos(th), sin(ph), cos(ph)*sin(th));
  vec3 loc = vec3(dir.x, dir.y*0.80, dir.z)*R*lump;
  loc.y -= 0.10*R;
  vec3 lp = vec3(off.x, 0.0, off.y)*0.78*aP.w*fade + loc;                           // position relative to the bush root (no wind): the leaf pattern sticks to the bush
  vec3 pos = aP.xyz + lp;
  float w = windAt(pos, h(aC.w*61.0));
  pos.x += w*0.035*max(loc.y, 0.0); pos.z += w*0.022*max(loc.y, 0.0);
  vN = normalize(vec3(dir.x, dir.y*1.25 + 0.1, dir.z)); vWp = lp + vec3(aC.w*37.0, aC.w*11.0, aC.w*23.0); vCol = aC.rgb; vSeed = aC.w; vD = length(pos - uCam); vY = dir.y; vV = normalize(uCam - pos);
  gl_Position = uVP*vec4(pos, 1.0);
}
)GLSL";
static const char* BU_FS = R"GLSL(#version 300 es
precision highp float;
in vec3 vN; in vec3 vWp; in vec3 vCol; in float vSeed; in float vD; in float vY; in vec3 vV; out vec4 o;
float h3(vec3 p){ p = fract(p*0.1031); p += dot(p, p.yzx + 33.33); return fract((p.x + p.y)*p.z); }
vec3 h33(vec3 p){ return vec3(h3(p), h3(p + 17.1), h3(p + 41.7)); }
void main(){
  vec3 V = normalize(vV); vec3 N0 = normalize(vN); vec3 L = SUNL;
  float near = 1.0 - smoothstep(45.0, 100.0, vD);                                    // fine leaf detail fades out with distance (no shimmer far away)
  float rim = 1.0 - abs(dot(N0, V));
  float hole = h3(floor(vWp*44.0));                                                 // ragged, leafy silhouette: leaf-sized bits fall away near the edge, a few gaps inside
  if (hole < (0.03 + 0.42*smoothstep(0.45, 0.98, rim))*near) discard;
  float inside = smoothstep(0.02, -0.20, dot(N0, V));                               // looking at the inside of the dome through a gap: dark
  vec3 cell = floor(vWp*30.0);
  vec3 N = normalize(N0 + (h33(cell) - 0.5)*0.40);                                  // every leaf cluster faces a slightly different way
  float nd = dot(N, L); float d = max(nd, 0.0), wrap = max(nd*0.5 + 0.5, 0.0);
  float lf = h3(cell + 3.7), lf2 = h3(floor(vWp*5.0));
  lf = mix(0.5, lf, 0.6);
  vec3 alb = vCol*mix(vec3(0.70, 0.80, 0.58), vec3(1.30, 1.25, 0.82), lf*0.7 + lf2*0.3);
  alb = mix(alb, alb*vec3(1.35, 1.30, 0.55) + vec3(0.02, 0.05, 0.0), smoothstep(0.78, 0.95, lf2)*smoothstep(0.2, 0.8, vY));   // young, yellow-green shoots on the sunny top
  // individual pointed leaves (random orientation per cluster) with a lighter midrib and a dark gap between neighbours; fades to a plain tone with distance
  vec3 Tt = normalize(cross(N0, abs(N0.y) < 0.9 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0))); vec3 Bt = cross(N0, Tt);
  vec3 lc = vWp*20.0; vec3 lcell = floor(lc); vec3 lfr = fract(lc) - 0.5;
  float lan = h3(lcell + 5.1)*6.2831853; float ca = cos(lan), sa = sin(lan);
  vec2 lu = vec2(dot(lfr, Tt), dot(lfr, Bt)); lu = vec2(ca*lu.x - sa*lu.y, sa*lu.x + ca*lu.y);
  float lw = 0.23*max(1.0 - pow(abs(lu.x)/0.48, 2.0), 0.0);                           // leaf outline: widest in the middle, pointed at both ends
  float inLeaf = smoothstep(lw, lw*0.55, abs(lu.y))*step(abs(lu.x), 0.48);
  float rib = smoothstep(0.022, 0.0, abs(lu.y))*step(abs(lu.x), 0.44);
  float lt = h3(lcell + 11.3);
  alb *= 0.80 + 0.40*lt;                                                           // leaf-to-leaf colour variation
  alb = mix(alb, alb*1.30 + vec3(0.03, 0.04, 0.0), rib*0.55*near);                 // pale midrib
  alb = mix(alb, alb*vec3(1.15, 1.0, 0.75), step(0.9, lt)*0.5);                    // an odd yellowing leaf
  float leafShade = mix(1.0, 0.50 + 0.50*inLeaf, near);                            // dark gaps between leaves = depth
  float ao = (0.40 + 0.62*smoothstep(0.0, 0.85, vY))*(0.80 + 0.30*lf) * leafShade;              // deep inside dark, outer top bright
  if (vSeed > 0.60){                                                                // flowering shrub: 5-petal blossoms in clusters (white spirea, pink rose, lilac, yellow broom)
    vec3 bp = vWp*11.0; vec3 bc = floor(bp); vec3 fb = fract(bp) - 0.5;
    vec3 ctr = (h33(bc + 7.0) - 0.5)*0.30;
    float present = step(0.70, h3(bc + 9.0))*smoothstep(0.03, 0.40, vY);               // denser than before, mostly on the sunny top
    vec2 bu = vec2(dot(fb - ctr, Tt), dot(fb - ctr, Bt)); float dd = length(bu);
    float rad = 0.30 + 0.10*h3(bc + 2.0); float ba = atan(bu.y, bu.x) + h3(bc + 3.0)*6.2831853;
    float pr = rad*(0.62 + 0.38*abs(cos(2.5*ba)));                                   // 5 rounded petals
    float pet = smoothstep(pr, pr*0.80, dd)*present;
    vec3 pcol = (vSeed > 0.88) ? vec3(0.98, 0.97, 0.93) : (vSeed > 0.80) ? vec3(0.98, 0.84, 0.18) : (vSeed > 0.70) ? vec3(0.93, 0.34, 0.50) : vec3(0.66, 0.50, 0.86);
    pcol *= 0.88 + 0.20*h3(bc + 5.0);
    pcol = mix(pcol, pcol*0.78, smoothstep(rad*0.25, rad*0.9, dd)*0.45);               // petals shade towards the tips and the throat is brighter
    pcol = mix(pcol, vec3(0.95, 0.76, 0.12), smoothstep(rad*0.26, rad*0.10, dd));      // yellow stamens
    float stam = step(0.80, h3(vec3(floor(bu*90.0), 0.0) + bc))*smoothstep(rad*0.5, rad*0.2, dd); // stamen dots around the centre
    pcol = mix(pcol, vec3(0.45, 0.30, 0.05), stam*0.6);
    alb = mix(alb, pcol, pet); ao = mix(ao, 1.0, pet*0.7);
    float bud = step(0.93, h3(bc + 21.0))*(1.0 - present)*smoothstep(0.05, 0.4, vY)*smoothstep(0.12, 0.06, dd);   // unopened buds
    alb = mix(alb, mix(pcol, vec3(0.25, 0.4, 0.15), 0.35), bud);
  }
  vec3 amb = mix(vec3(0.22, 0.28, 0.14), vec3(0.50, 0.66, 0.95), N.y*0.5 + 0.5)*0.85;
  vec3 c = alb*(amb*ao + vec3(1.08, 1.0, 0.82)*(0.55*d + 0.35*wrap)*mix(0.45, 1.0, ao));
  c += alb*vec3(0.55, 0.60, 0.10)*pow(max(dot(-V, L), 0.0), 3.0)*0.80*smoothstep(0.2, 0.9, vY);   // sunlight shining through the leaves
  c += vec3(0.16, 0.15, 0.10)*pow(max(dot(reflect(-L, N), V), 0.0), 24.0)*(0.4 + 0.6*lf)*near;    // glossy leaf glints
  c *= 1.0 - 0.60*inside;
  float fog = 1.0 - exp(-pow(vD/2850.0, 1.35));
  c = mix(c, vec3(0.70, 0.88, 0.97), clamp(fog, 0.0, 1.0));
  o = vec4(c, 1.0);
}
)GLSL";

// ---------------------------------------------------------------------------------------------------------------------------------
// ring-buffer layers
// ---------------------------------------------------------------------------------------------------------------------------------
struct Layer {
    int N = 0; float S = 1.f; int per = 0; int vpi = 0; float cull = 0.6f;
    const char* vs = nullptr; const char* fs = nullptr; void (*comp)(long, long, float*) = nullptr;
    GLuint prog = 0, vbo = 0, vao = 0; GLint uVP = -1, uCam = -1, uCar = -1, uTime = -1, uNT = -1, uNP = -1;
    std::vector<float> data; std::vector<long> kx, kz; bool ok = false; std::vector<float> vis;
};
static Layer gFl, gTg, gBu;

// does a meadow plant stand here? true = the ground is real grass; cl = distance from the road edge, gk = greenness 0..1, r/g/b = ground colour
static bool grassHere(double x, double z, float& cl, float& gk, double& r, double& g, double& b){
    cl = Road::clearance((float)x, (float)z);
    if (Terrain::TRK.on){ const double td = Terrain::trackDist(x, z); if (td < 1e8) cl = std::min(cl, (float)(td - 0.5 * Terrain::TRK_W)); }   // the winding hill road (WINDING_ROAD_HILL) gets the same flowery / bushy roadsides as the ring roads
    if (cl < 1.6f) return false;
    if (Terrain::gLake.on && Terrain::lakeDn(x, z) < 1.30) return false;
    if (River::groundH(x, z) < -0.10) return false;
    r = 0.300; g = 0.450; b = 0.190; Terrain::grassColor(x, z, Terrain::fieldH(x, z), r, g, b);
    gk = ss(1.04f, 1.14f, (float)(g / std::max(r, 0.01))) * (g > b * 1.5 ? 1.f : 0.f);
    return gk > 0.f;
}
static bool freeOfThings(double x, double z, float margin){
    if (Terrain::trackDist(x, z) < 2.5 + margin * 0.4) return false;                                // dirt track
    if (Village::blocked((float)x, (float)z, 2.5f + margin)) return false;                          // chalets + church
    if (Tunnel::blocked(x, z, 3.0 + margin)) return false;
    return true;
}

static void compFlower(long cx, long cz, float* o){
    const double S = gFl.S;
    const double x = (cx + 0.1 + 0.8*hash2(cx, cz, 11)) * S, z = (cz + 0.1 + 0.8*hash2(cx, cz, 12)) * S;
    o[0] = (float)x; o[2] = (float)z; o[1] = 0; o[3] = 0; o[4] = o[5] = o[6] = 0; o[7] = 0.f;
    // colour patches: big drifts of one species, like a real alpine meadow
    const float patch = vn((float)x*0.050f + 31.f, (float)z*0.050f + 17.f);
    const float dryK = (float)Terrain::dryW(x, z);                                                   // the 10 % dry-grass patches are also where the small flowers are thickest
    const float alp = (float)Terrain::alpineBand(x, z);                                              // alpine meadow on the middle slopes of the big mountain: flowers everywhere
    const float dens = std::max(std::max(0.04f + 0.80f * ss(0.46f, 0.68f, patch), 0.70f * dryK), 0.55f * alp) * (0.55f + 0.45f * ss(0.30f, 0.60f, patch + 0.35f * dryK + 0.5f * alp));
    if (hash2(cx, cz, 14) > dens) return;
    float cl, gk; double r, g, b; if (!grassHere(x, z, cl, gk, r, g, b)) return;
    if (cl > 70.f && dryK < 0.3f && alp < 0.25f) return;                                                           // flowers near the roads, and out in the field wherever the dry / flowery patches are
    if (!freeOfThings(x, z, 0.f)) return;
    const float bandK = ss(2.4f, 4.2f, cl) * std::max(std::max(1.f - 0.55f * ss(35.f, 70.f, cl) * (cl > 70.f ? 0.f : 1.f), dryK), alp);
    if (hash2(cx, cz, 15) > bandK) return;
    float sp = vn((float)x*0.021f + 91.f, (float)z*0.021f + 5.f);                                    // which species grows in this drift
    if (hash2(cx, cz, 16) < 0.12f) sp = hash2(cx, cz, 17);                                           // a few strays of another colour
    static const float PAL[6][3] = { {0.97,0.96,0.90}, {1.00,0.84,0.10}, {0.36,0.38,0.95}, {0.96,0.46,0.68}, {0.95,0.26,0.14}, {0.72,0.46,0.88} };
    int k; if (sp < 0.26f) k = 1; else if (sp < 0.46f) k = 0; else if (sp < 0.64f) k = 2; else if (sp < 0.78f) k = 3; else if (sp < 0.90f) k = 5; else k = 4;
    const float j = 0.88f + 0.24f * hash2(cx, cz, 18);
    o[4] = PAL[k][0]*j; o[5] = PAL[k][1]*j; o[6] = PAL[k][2]*j;
    { static const int SPM[6] = {0, 1, 2, 3, 4, 5}; o[7] = (SPM[k] + 0.02f + 0.96f*hash2(cx, cz, 13)) / 6.f; }   // species 0 daisy 1 buttercup 2 bellflower 3 pink 4 poppy 5 cranesbill + a random seed in the fraction
    o[3] = gk * (0.75f + 0.55f * hash2(cx, cz, 19));
    o[1] = (float)Terrain::meshH(x, z);
}

static void compTall(long cx, long cz, float* o){
    const double S = gTg.S;
    const double x = (cx + 0.1 + 0.8*hash2(cx, cz, 21)) * S, z = (cz + 0.1 + 0.8*hash2(cx, cz, 22)) * S;
    o[0] = (float)x; o[2] = (float)z; o[1] = 0; o[3] = 0; o[4] = o[5] = o[6] = 0; o[7] = hash2(cx, cz, 23);
    const float alp = (float)Terrain::alpineBand(x, z);
    const float dens = std::max(0.30f + 0.65f * ss(0.28f, 0.62f, vn((float)x*0.035f + 7.f, (float)z*0.035f + 63.f)), 0.85f * alp);
    if (hash2(cx, cz, 24) > dens) return;
    float cl, gk; double r, g, b; if (!grassHere(x, z, cl, gk, r, g, b)) return;
    if (cl < 2.4f || (cl > 120.f && alp < 0.25f)) return;
    if (!freeOfThings(x, z, 0.f)) return;
    o[3] = gk * ss(2.4f, 5.0f, cl) * (0.65f + 0.60f * hash2(cx, cz, 25));
    o[1] = (float)Terrain::meshH(x, z); o[4] = (float)r; o[5] = (float)g; o[6] = (float)b;
}

static void compBush(long cx, long cz, float* o){
    const double S = gBu.S;
    const double x = (cx + 0.1 + 0.8*hash2(cx, cz, 31)) * S, z = (cz + 0.1 + 0.8*hash2(cx, cz, 32)) * S;
    o[0] = (float)x; o[2] = (float)z; o[1] = 0; o[3] = 0; o[4] = o[5] = o[6] = 0; o[7] = hash2(cx, cz, 33);
    float cl, gk; double r, g, b; if (!grassHere(x, z, cl, gk, r, g, b)) return;
    if (cl < 4.5f || gk < 0.5f) return;                                                              // never on the verge
    const float thick = 0.12f + 0.55f * ss(0.45f, 0.70f, vn((float)x*0.018f + 3.f, (float)z*0.018f + 44.f));   // shrubby patches
    const float dens = thick * ss(4.5f, 8.f, cl) * (1.f - 0.65f * ss(45.f, 100.f, cl)) * (1.f - 0.75f * (float)Terrain::alpineBand(x, z));   // open meadow on the mountain: few shrubs
    if (hash2(cx, cz, 34) > dens) return;
    if (!freeOfThings(x, z, 2.f) || NatureFx::nearFall((float)x, (float)z, 6.f)) return;
    const float s = hash2(cx, cz, 35);
    static const float LEAF[6][3] = { {0.10,0.28,0.07}, {0.24,0.36,0.10}, {0.10,0.30,0.20}, {0.18,0.40,0.10}, {0.30,0.40,0.08}, {0.07,0.21,0.11} };
    const int k = s < 0.28f ? 0 : (s < 0.50f ? 1 : (s < 0.66f ? 2 : (s < 0.80f ? 3 : (s < 0.92f ? 4 : 5))));
    o[4] = LEAF[k][0]; o[5] = LEAF[k][1]; o[6] = LEAF[k][2];
    o[3] = 0.6f + 1.5f * hash2(cx, cz, 36);
    o[1] = (float)Terrain::meshH(x, z);
}

static bool build(Layer& L){
    L.data.assign((size_t)L.N*L.N*8, 0.f); L.kx.assign((size_t)L.N*L.N, LONG_MIN); L.kz.assign((size_t)L.N*L.N, LONG_MIN);
    GLuint v = glCreateShader(GL_VERTEX_SHADER), f = glCreateShader(GL_FRAGMENT_SHADER);
    SunLight::shaderSource(v, L.vs); glCompileShader(v); SunLight::shaderSource(f, L.fs); glCompileShader(f);
    L.prog = glCreateProgram(); glAttachShader(L.prog, v); glAttachShader(L.prog, f); glLinkProgram(L.prog);
    GLint ok = 0; glGetProgramiv(L.prog, GL_LINK_STATUS, &ok); if (!ok){ L.ok = false; return false; }
    SunLight::attach(L.prog);
    L.uVP = glGetUniformLocation(L.prog, "uVP"); L.uCam = glGetUniformLocation(L.prog, "uCam"); L.uCar = glGetUniformLocation(L.prog, "uCar"); L.uTime = glGetUniformLocation(L.prog, "uTime"); L.uNT = glGetUniformLocation(L.prog, "uNT"); L.uNP = glGetUniformLocation(L.prog, "uNP");
    glGenVertexArrays(1, &L.vao); glBindVertexArray(L.vao);
    glGenBuffers(1, &L.vbo); glBindBuffer(GL_ARRAY_BUFFER, L.vbo); glBufferData(GL_ARRAY_BUFFER, L.data.size()*4, L.data.data(), GL_DYNAMIC_DRAW);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 32, (void*)0); glVertexAttribDivisor(0, 1);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 32, (void*)16); glVertexAttribDivisor(1, 1);
    glBindVertexArray(0); L.ok = true; return true;
}

static void init(){
    gFl.N = 128; gFl.S = 0.55f; gFl.per = 1100; gFl.vpi = 99;  gFl.cull = 0.5f; gFl.vs = FL_VS; gFl.fs = FL_FS; gFl.comp = compFlower; build(gFl);     // 70 m window
    gTg.N = 96;  gTg.S = 1.10f; gTg.per = 700;  gTg.vpi = 54;  gTg.cull = 1.2f; gTg.vs = TG_VS; gTg.fs = TG_FS; gTg.comp = compTall;   build(gTg);     // 105 m window
    gBu.N = 56;  gBu.S = 4.00f; gBu.per = 160;  gBu.vpi = 3*16*8*6; gBu.cull = 2.5f; gBu.vs = BU_VS; gBu.fs = BU_FS; gBu.comp = compBush;   build(gBu);     // 224 m window
}

static void update(Layer& L, const float* eye){
    if (!L.ok) return;
    const long ccx = (long)std::floor(eye[0] / L.S), ccz = (long)std::floor(eye[2] / L.S), x0 = ccx - L.N/2, z0 = ccz - L.N/2; int budget = L.per; const int N = L.N;
    for (int j = 0; j < N; j++){
        const long cz = z0 + (((j - z0) % N) + N) % N;
        for (int i = 0; i < N; i++){
            const long cx = x0 + (((i - x0) % N) + N) % N; const size_t s = (size_t)j*N + i;
            if (L.kx[s] == cx && L.kz[s] == cz) continue;
            if (budget <= 0){ if (L.kx[s] == LONG_MIN) continue; L.data[s*8+3] = 0; continue; }          // out of budget: hide the stale plant until its turn
            L.comp(cx, cz, &L.data[s*8]); L.kx[s] = cx; L.kz[s] = cz; budget--;
        }
    }
}

static void drawLayer(Layer& L, const float* VP, const float* eye, const float* car, float tSec, float pl[5][4], float topY){
    if (!L.ok) return;
    update(L, eye);
    L.vis.clear(); L.vis.reserve((size_t)L.N*L.N*2);
    const size_t total = (size_t)L.N*L.N;
    for (size_t s = 0; s < total; s++){
        const float* d = &L.data[s*8]; if (d[3] < 0.01f) continue;
        if (&L != &gBu){ const float gdx = d[0] - eye[0], gdz = d[2] - eye[2], gr = L.N * L.S * 0.5f * Quality::grassScale; if (gdx*gdx + gdz*gdz > gr*gr) continue; }
        bool out = false; const float cy = d[1] + topY*0.5f, m = -(0.6f + L.cull + topY*d[3]*0.3f);
        for (int i = 0; i < 5 && !out; i++) if (pl[i][0]*d[0] + pl[i][1]*cy + pl[i][2]*d[2] + pl[i][3] < m) out = true;
        if (out) continue;
        L.vis.insert(L.vis.end(), d, d + 8);
    }
    const int cnt = (int)(L.vis.size() / 8); if (!cnt) return;
    glBindVertexArray(L.vao); glBindBuffer(GL_ARRAY_BUFFER, L.vbo); glBufferData(GL_ARRAY_BUFFER, L.vis.size()*4, L.vis.data(), GL_STREAM_DRAW);
    glUseProgram(L.prog); glUniformMatrix4fv(L.uVP, 1, GL_FALSE, VP); glUniform3fv(L.uCam, 1, eye); glUniform3fv(L.uCar, 1, car); glUniform1f(L.uTime, tSec);
    int vpi = L.vpi;
    if (L.uNT >= 0){   // bush mesh detail follows Settings > Graphics: Low 8x4, Normal 12x6, High 16x8 segments per dome
        const int lvl = Quality::flat ? 0 : Quality::level; const int NT = lvl == 0 ? 8 : (lvl == 1 ? 12 : 16), NP = lvl == 0 ? 4 : (lvl == 1 ? 6 : 8);
        glUniform1i(L.uNT, NT); glUniform1i(L.uNP, NP); vpi = 3*NT*NP*6;
    }
    glDrawArraysInstanced(GL_TRIANGLES, 0, vpi, cnt);
    glBindVertexArray(0);
}

// level: 0 = Low (only the bushes, cheap), 1 / 2 = bushes + tall grass + wildflowers
static void draw(const float* VP, const float* eye, const float* car, float tSec, int level){
    float pl[5][4];
    for (int i = 0; i < 5; i++){ const int a = i >> 1; const float sg = (i & 1) ? 1.f : -1.f;
        for (int j = 0; j < 4; j++) pl[i][j] = VP[j*4 + 3] + sg * VP[j*4 + a];
        const float l = std::sqrt(pl[i][0]*pl[i][0] + pl[i][1]*pl[i][1] + pl[i][2]*pl[i][2]); if (l > 1e-6f) for (int j = 0; j < 4; j++) pl[i][j] /= l; }
    glEnable(GL_DEPTH_TEST); glDepthMask(GL_TRUE); glDisable(GL_BLEND); glDisable(GL_CULL_FACE);
    drawLayer(gBu, VP, eye, car, tSec, pl, 1.6f);
    if (level > 0){ drawLayer(gTg, VP, eye, car, tSec, pl, 1.0f); drawLayer(gFl, VP, eye, car, tSec, pl, 0.5f); }
}

}   // namespace MeadowGL
