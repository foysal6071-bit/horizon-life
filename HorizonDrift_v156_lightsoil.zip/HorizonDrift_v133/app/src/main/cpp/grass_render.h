// Sunny Drift - real 3D grass: thousands of small curved, sun-lit blades (tufts of 4, 9 vertices per blade) standing on the meadow around the camera, swaying in the wind.
//  * a ring-buffer grid of tufts (0.195 m spacing = 8x denser, ~20 m radius) follows the camera: only cells that newly come into range are computed, a few hundred per frame,
//    so there is no stall. A cell gets a tuft only where the ground is really grass (colour test on the ground colour, away from road / dirt track / sand / river / lake).
//  * one instanced draw call; the blade shape, lean and wind sway are made in the vertex shader (no per-blade CPU work)
//  * tufts fade out by shrinking with distance and are pressed lower around the car
#pragma once
#include <GLES3/gl3.h>
#include <cmath>
#include <climits>
#include <vector>
#include <algorithm>
#include "terrain.h"
#include "sun_light.h"
#include "quality.h"

namespace GrassGL {

static const int   N = 160;                // grid cells per side
static const float S = 0.21f;              // metres per cell  (window = 40.6 m): 8x as many tufts per m2 as the old 0.55 m grid (~130 blades / m2)
static const int   PER_FRAME = 1200;        // max new cells computed per frame
// second, coarse grid for the FAR grass: 240 x 0.5 m = 120 m window (radius 60 m), billboards only. The fine grid above ends at ~20 m, this one carries the lawn out to ~60 m.
static const int   N2 = 180;
static const float S2 = 0.5f;
static const int   PER_FRAME2 = 800;
// graphics level (0 Low, 1 Normal, 2 High): grass is ALWAYS drawn, but Low gets a smaller 3D zone, thinner billboards and a shorter far range
static const float Q_NEAR[3]  = {2.5f, 5.f, 7.f};      // radius (m) of real 3D blades around the camera / car
static const float Q_KEEP[3]  = {0.50f, 0.80f, 1.00f}; // share of fine-grid cells (beyond the 3D zone) that get a billboard
static const float Q_KEEP2[3] = {0.65f, 1.00f, 1.00f}; // share of coarse-grid cells that get a billboard
static const float Q_RANGE[3] = {0.70f, 0.85f, 1.00f}; // multiplies the far grass distance

static GLuint gProg = 0, gVbo = 0, gVao = 0; static GLint uVP, uCam, uCar, uTime;
static std::vector<float> gData;            // N*N*8 : x, y, z, scale | r, g, b, seed
static std::vector<long> gKX, gKZ;
static std::vector<float> gData2; static std::vector<long> gKX2, gKZ2;   // coarse far grid
static bool gOk = false, gDirty = false;
static GLuint gProgF = 0, gVboF = 0, gVaoF = 0; static GLint uVPF, uCamF, uCarF, uTimeF, uFadeF, uSzF; static bool gOkF = false;   // far 2D billboard layer

static const char* VS = R"GLSL(#version 300 es
layout(location=0) in vec4 aP; layout(location=1) in vec4 aC;
uniform mat4 uVP; uniform vec3 uCam; uniform vec3 uCar; uniform float uTime;
out float vT; out vec3 vCol; out float vD; out float vW; out float vS; out vec3 vN; out vec3 vV; out float vU;
float h(float n){ return fract(sin(n*91.345 + 17.7)*43758.5453); }
// one blade = 9 vertices: a lower quad (root -> bend), an upper quad-ish part and a pointed tip, so the blade really CURVES instead of being one flat triangle
const int LV[9] = int[9](0, 0, 1, 0, 1, 1, 1, 1, 2);
const int SD[9] = int[9](-1, 1, -1, 1, 1, -1, -1, 1, 0);
void main(){
  if (aP.w < 0.01){ gl_Position = vec4(2.0, 2.0, 2.0, 1.0); vT = 0.0; vCol = vec3(0.0); vD = 0.0; vW = 0.0; vS = 0.0; vN = vec3(0.0, 1.0, 0.0); vV = vec3(0.0, 1.0, 0.0); vU = 0.0; return; }
  int b = gl_VertexID/9, k = gl_VertexID - b*9;
  int lv = LV[k]; float sd = float(SD[k]);
  float seed = aC.w*61.0 + float(b)*7.31;
  float a = h(seed)*6.2831853, rad = h(seed + 1.3)*0.17;
  vec3 base = aP.xyz + vec3(cos(a), 0.0, sin(a))*rad;
  float d = length(base.xz - uCam.xz);
  float fade = 1.0 - smoothstep(14.0, 20.0, d);                                      // far tufts shrink away
  float dc = length(base.xz - uCar.xz);
  float press = mix(0.30, 1.0, smoothstep(1.0, 2.8, dc));                            // grass is pressed down under / beside the car
  float tall = h(seed + 2.7);
  float hgt = (0.10 + 0.30*tall*tall + 0.08*tall) * 1.8 * aP.w * fade * press;       // x1.8: tall Swiss-meadow grass             // many short blades, a few taller ones: uneven like a real lawn
  float ang = h(seed + 4.1)*3.14159265;
  vec3 sv = vec3(cos(ang), 0.0, sin(ang));                                            // blade width direction
  vec3 ld = vec3(cos(ang + 1.5708), 0.0, sin(ang + 1.5708));                          // the way the blade leans
  float lean = (h(seed + 5.5) - 0.5)*2.0;
  const vec2 WD = vec2(0.85, 0.53);
  float w = sin(dot(base.xz, WD)*0.6 - uTime*2.6 + h(seed)*1.5)*0.5 + sin(base.x*0.31 + base.z*0.23 - uTime*1.7)*0.5;   // -1..1: gust wave + ripple
  float flutter = sin(uTime*5.0 + seed*3.0)*0.08*abs(w);                             // fine flutter of the tip in a gust
  float t = (lv == 0) ? 0.0 : ((lv == 1) ? 0.55 : 1.0);
  float bend = 0.55 + 0.45*h(seed + 9.4);                                             // how much this blade arches over
  vec3 over = (vec3(WD.x, 0.0, WD.y)*(w*0.5 + 0.40) + ld*lean*0.75)*0.42 + sv*flutter; // total sideways lean of the tip, as a fraction of the height
  vec2 awy = base.xz - uCar.xz; vec3 pushDir = normalize(vec3(awy.x, 0.0, awy.y) + vec3(0.0001, 0.0, 0.0));
  float push = 1.0 - smoothstep(1.3, 3.6, dc);                                        // blades near the car are bent away from it, like a car flattening a lawn
  over += pushDir*push*(0.55 + 0.35*h(seed + 3.3));                                   // (each blade a bit different), on top of being pressed lower
  float wid = (0.011 + 0.0075*h(seed + 6.2)) * (1.0 - 0.62*t) * (lv == 2 ? 0.0 : 1.0);
  vec3 pos = base + sv*wid*sd;
  pos += over*hgt*bend*t*t*1.35;                                                      // quadratic arc: stiff at the root, bent at the tip
  pos.y += hgt*t*(1.0 - 0.28*bend*t) - 0.03*(1.0 - t) - hgt*0.05*abs(w)*t*t;         // a bent blade is lower
  vec3 tang = normalize(vec3(over.x*bend*1.35*2.0*t, 1.0 - 0.56*bend*t, over.z*bend*1.35*2.0*t) + vec3(0.0001));
  vec3 nrm = normalize(cross(sv, tang));
  vT = t; vCol = aC.rgb; vW = w; vD = length(pos - uCam); vS = h(seed + 8.3); vN = nrm; vV = normalize(uCam - pos); vU = sd;
  gl_Position = uVP*vec4(pos, 1.0);
}
)GLSL";
static const char* FS = R"GLSL(#version 300 es
precision mediump float;
in float vT; in vec3 vCol; in float vD; in float vW; in float vS; in vec3 vN; in vec3 vV; in float vU; out vec4 o;
void main(){
  vec3 L = SUNL; vec3 V = normalize(vV);
  vec3 N = normalize(vN); if (dot(N, V) < 0.0) N = -N;                               // blades are two-sided
  N = normalize(N + vec3(0.0, 0.35, 0.0));                                           // a lawn shades like one soft surface, not like single sticks
  vec3 root = vec3(0.045, 0.15, 0.03), tip = vec3(0.30, 0.64, 0.07);                 // deep green root -> natural fresh green tip (no neon lime)
  vec3 tint = clamp(vec3((vCol.r/max(vCol.g, 0.01))/0.667, 1.0, (vCol.b/max(vCol.g, 0.01))/0.422), 0.7, 1.4);
  vec3 alb = mix(root, tip, smoothstep(0.0, 0.95, vT)) * tint * clamp(vCol.g/0.534, 0.6, 1.3);
  alb *= 0.78 + 0.44*vS;                                                             // every blade its own shade
  float dry = smoothstep(0.80, 0.96, vS);                                            // ~1 blade in 6 is older, yellowish-dry
  alb = mix(alb, vec3(0.72, 0.62, 0.14)*(0.60 + 0.50*vT), dry*0.65);
  float rib = 1.0 - 0.22*(1.0 - smoothstep(0.0, 0.55, abs(vU)));                             // darker central midrib line, lighter edges
  alb *= rib;
  float ao = 0.40 + 0.70*pow(vT, 0.7);                                               // dark in the depth of the lawn (self-shadow), lit tips
  float nd = dot(N, L); float d = max(nd, 0.0), wrap = max(nd*0.5 + 0.5, 0.0);
  vec3 amb = mix(vec3(0.22, 0.27, 0.15), vec3(0.50, 0.66, 0.95), N.y*0.5 + 0.5)*0.85;
  vec3 c = alb*(amb + vec3(1.08, 1.0, 0.82)*(0.45*d + 0.40*wrap))*ao;
  float back = pow(max(dot(-V, L), 0.0), 3.0);                                       // looking toward the sun: thin blades glow (translucency)
  c += vec3(0.30, 0.46, 0.06) * back * vT * (0.5 + 0.5*vS) * (1.0 - dry*0.6);
  c += vec3(0.95, 0.95, 0.80) * pow(max(dot(reflect(-L, N), V), 0.0), 28.0) * 0.10 * vT;   // faint waxy sheen on the blade
  c += vec3(0.05, 0.07, 0.01) * max(vW, 0.0) * vT;                                   // gust: tips catch a little more light
  float fog = 1.0 - exp(-pow(vD/2850.0, 1.35));
  c = mix(c, vec3(0.70, 0.88, 0.97), clamp(fog, 0.0, 1.0));
  o = vec4(c, 1.0);
}
)GLSL";

// ---- far layer: ONE camera-facing quad (6 vertices) per tuft instead of 36; the three blades are cut out in the fragment shader (alpha test, no sorting needed) ----
static const char* VSF = R"GLSL(#version 300 es
layout(location=0) in vec4 aP; layout(location=1) in vec4 aC;
uniform mat4 uVP; uniform vec3 uCam; uniform vec3 uCar; uniform float uTime; uniform vec4 uFade; uniform vec2 uSz;
out vec2 vUv; out vec3 vCol; out float vD; out float vS; out float vW;
float h(float n){ return fract(sin(n*91.345 + 17.7)*43758.5453); }
const vec2 Q[6] = vec2[6](vec2(-1.0, 0.0), vec2(1.0, 0.0), vec2(1.0, 1.0), vec2(-1.0, 0.0), vec2(1.0, 1.0), vec2(-1.0, 1.0));
void main(){
  if (aP.w < 0.01){ gl_Position = vec4(2.0, 2.0, 2.0, 1.0); vUv = vec2(0.0); vCol = vec3(0.0); vD = 0.0; vS = 0.0; vW = 0.0; return; }
  vec2 q = Q[gl_VertexID];
  float seed = aC.w*61.0;
  vec3 base = aP.xyz;
  float d = length(base.xz - uCam.xz);
  float fade = smoothstep(uFade.x, uFade.y, d) * (1.0 - smoothstep(uFade.z, uFade.w, d));   // grows in / shrinks away at the edges of its ring
  float dc = length(base.xz - uCar.xz);
  float press = mix(0.30, 1.0, smoothstep(1.0, 2.8, dc));
  float tall = h(seed + 2.7);
  float hgt = (0.17 + 0.20*tall) * uSz.y * aP.w * fade * press;
  vec2 tc = uCam.xz - base.xz; vec3 fw = normalize(vec3(tc.x, 0.0, tc.y) + vec3(0.0001, 0.0, 0.0));
  vec3 right = vec3(fw.z, 0.0, -fw.x);
  const vec2 WD = vec2(0.85, 0.53);
  float w = sin(dot(base.xz, WD)*0.6 - uTime*2.6 + h(seed)*1.5)*0.5 + sin(base.x*0.31 + base.z*0.23 - uTime*1.7)*0.5;
  vec3 pos = base + right*q.x*uSz.x*(0.9 + 0.3*tall);
  pos.y += q.y*hgt - 0.03*(1.0 - q.y);
  pos += vec3(WD.x, 0.0, WD.y)*(w*0.5 + 0.40)*0.16*hgt*q.y*q.y;
  vUv = q; vCol = aC.rgb; vW = w; vD = length(pos - uCam); vS = h(seed + 8.3);
  gl_Position = uVP*vec4(pos, 1.0);
}
)GLSL";
static const char* FSF = R"GLSL(#version 300 es
precision mediump float;
in vec2 vUv; in vec3 vCol; in float vD; in float vS; in float vW; out vec4 o;
void main(){
  float x = vUv.x, y = vUv.y;
  float a = 0.0, bid = 0.0, by = 0.0;
  for (int k = 0; k < 6; k++){                                                          // 6 curved blades, narrow pointed tips, each its own lean / height
    float fk = float(k); float r = fract(vS*(7.0 + fk*6.3) + fk*0.37);
    float c = (fk - 2.5)*0.30 + (r - 0.5)*0.16;
    float hk = 0.55 + 0.45*fract(vS*(11.0 + fk*9.0) + fk*0.19);
    float lean = (fract(r*13.1) - 0.5)*0.9 + vW*0.08;
    float yy = y/hk;
    float wd = 0.16*(1.0 - yy)*(1.0 - 0.35*yy);
    float cx = c + lean*yy*yy*0.55;                                                     // blade arches over
    float m = step(y, hk)*(1.0 - smoothstep(wd*0.7, wd, abs(x - cx)));
    if (m > a){ a = m; bid = fk + r; by = yy; }
  }
  // flowers on some tufts: stem + 5-petal head (random colour), looks like a real meadow flower from the side
  float fl = step(0.80, fract(vS*13.7));
  float fx = (fract(vS*5.3) - 0.5)*0.6, fh = 0.58 + 0.28*fract(vS*17.1);
  float fa = 0.0; vec3 fc = vec3(0.0);
  if (fl > 0.5){
    float stem = step(y, fh)*(1.0 - smoothstep(0.018, 0.03, abs(x - fx - 0.12*y*y)));
    vec2 p = vec2((x - fx - 0.12*fh*fh)*0.62, y - fh); float rr = length(p), th = atan(p.y, p.x);
    float pr = 0.085*(1.0 + 0.38*cos(5.0*th + vS*30.0));
    float head = 1.0 - smoothstep(pr*0.85, pr, rr);
    float kind = fract(vS*31.7);
    vec3 pet = kind < 0.35 ? vec3(0.96, 0.96, 0.92) : (kind < 0.6 ? vec3(0.98, 0.82, 0.12) : (kind < 0.8 ? vec3(0.86, 0.32, 0.60) : vec3(0.52, 0.38, 0.84)));
    vec3 cen = vec3(0.95, 0.72, 0.08);
    vec3 hc = mix(pet, cen, 1.0 - smoothstep(0.0, 0.032, rr));
    hc *= 0.78 + 0.3*clamp((p.y + 0.09)/0.18, 0.0, 1.0);                                // lit top, shaded underside
    if (head > 0.5){ fa = 1.0; fc = hc; }
    else if (stem > 0.5 && a < 0.5){ fa = 1.0; fc = vec3(0.13, 0.32, 0.06); }
  }
  if (a < 0.5 && fa < 0.5) discard;
  vec3 c;
  if (fa > 0.5 && !(a > 0.5 && fl < 0.5 && false)){
    c = fc * (0.55 + 0.75*clamp(0.5 + 0.5*dot(normalize(SUNL), vec3(0.0, 1.0, 0.0)), 0.0, 1.0));
  } else {
    vec3 L = SUNL;
    vec3 root = vec3(0.045, 0.15, 0.03), tip = vec3(0.30, 0.64, 0.07);
    vec3 tint = clamp(vec3((vCol.r/max(vCol.g, 0.01))/0.667, 1.0, (vCol.b/max(vCol.g, 0.01))/0.422), 0.7, 1.4);
    vec3 alb = mix(root, tip, smoothstep(0.0, 0.95, by)) * tint * clamp(vCol.g/0.534, 0.6, 1.3);
    alb *= 0.70 + 0.55*fract(bid*3.17 + vS*5.0);                                        // every blade its own shade
    float dry = smoothstep(0.80, 0.96, fract(bid*1.7 + vS));
    alb = mix(alb, vec3(0.72, 0.62, 0.14)*(0.60 + 0.50*by), dry*0.65);
    alb *= 1.0 - 0.18*(1.0 - smoothstep(0.0, 0.12, abs(fract(bid)-0.5)));
    float ao = 0.35 + 0.75*pow(clamp(by, 0.0, 1.0), 0.7);
    float nd = L.y*0.8 + 0.2; float d = max(nd, 0.0), wrap = max(nd*0.5 + 0.5, 0.0);
    vec3 amb = mix(vec3(0.22, 0.27, 0.15), vec3(0.50, 0.66, 0.95), 0.95)*0.85;
    c = alb*(amb + vec3(1.08, 1.0, 0.82)*(0.45*d + 0.40*wrap))*ao;
    c += vec3(0.28, 0.42, 0.05) * pow(max(L.y, 0.0), 0.5) * by * 0.18;                  // thin blades glow in the sun (translucency)
    c += vec3(0.05, 0.07, 0.01) * max(vW, 0.0) * by;
  }
  float fog = 1.0 - exp(-pow(vD/2850.0, 1.35));
  c = mix(c, vec3(0.70, 0.88, 0.97), clamp(fog, 0.0, 1.0));
  o = vec4(c, 1.0);
}
)GLSL";

static inline float hash2(long a, long b, int s){ unsigned x = (unsigned)(a*374761393L + b*668265263L + s*2246822519L); x = (x ^ (x >> 13)) * 1274126177u; x ^= x >> 16; return (x & 0xFFFFFF) / 16777216.f; }
static inline float ss(float a, float b, float x){ x = std::min(1.f, std::max(0.f, (x - a) / (b - a))); return x*x*(3 - 2*x); }

static void init(){
    gData.assign((size_t)N*N*8, 0.f); gData2.assign((size_t)N2*N2*8, 0.f); gKX2.assign((size_t)N2*N2, LONG_MIN); gKZ2.assign((size_t)N2*N2, LONG_MIN); gKX.assign((size_t)N*N, LONG_MIN); gKZ.assign((size_t)N*N, LONG_MIN);
    GLuint v = glCreateShader(GL_VERTEX_SHADER), f = glCreateShader(GL_FRAGMENT_SHADER);
    SunLight::shaderSource(v, VS); glCompileShader(v); SunLight::shaderSource(f, FS); glCompileShader(f);
    gProg = glCreateProgram(); glAttachShader(gProg, v); glAttachShader(gProg, f); glLinkProgram(gProg);
    GLint ok = 0; glGetProgramiv(gProg, GL_LINK_STATUS, &ok); if (!ok){ gOk = false; return; }
    SunLight::attach(gProg);
    uVP = glGetUniformLocation(gProg, "uVP"); uCam = glGetUniformLocation(gProg, "uCam"); uCar = glGetUniformLocation(gProg, "uCar"); uTime = glGetUniformLocation(gProg, "uTime");
    glGenVertexArrays(1, &gVao); glBindVertexArray(gVao);
    glGenBuffers(1, &gVbo); glBindBuffer(GL_ARRAY_BUFFER, gVbo); glBufferData(GL_ARRAY_BUFFER, gData.size()*4, gData.data(), GL_DYNAMIC_DRAW);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 32, (void*)0); glVertexAttribDivisor(0, 1);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 32, (void*)16); glVertexAttribDivisor(1, 1);
    glBindVertexArray(0); gOk = true;
    // far billboard layer (if it fails to build, the 3D layer simply draws everything as before)
    GLuint vf = glCreateShader(GL_VERTEX_SHADER), ff = glCreateShader(GL_FRAGMENT_SHADER);
    SunLight::shaderSource(vf, VSF); glCompileShader(vf); SunLight::shaderSource(ff, FSF); glCompileShader(ff);
    gProgF = glCreateProgram(); glAttachShader(gProgF, vf); glAttachShader(gProgF, ff); glLinkProgram(gProgF);
    GLint okf = 0; glGetProgramiv(gProgF, GL_LINK_STATUS, &okf);
    if (okf){
        SunLight::attach(gProgF);
        uVPF = glGetUniformLocation(gProgF, "uVP"); uCamF = glGetUniformLocation(gProgF, "uCam"); uCarF = glGetUniformLocation(gProgF, "uCar"); uTimeF = glGetUniformLocation(gProgF, "uTime"); uFadeF = glGetUniformLocation(gProgF, "uFade"); uSzF = glGetUniformLocation(gProgF, "uSz");
        glGenVertexArrays(1, &gVaoF); glBindVertexArray(gVaoF);
        glGenBuffers(1, &gVboF); glBindBuffer(GL_ARRAY_BUFFER, gVboF); glBufferData(GL_ARRAY_BUFFER, 32, nullptr, GL_STREAM_DRAW);
        glEnableVertexAttribArray(0); glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 32, (void*)0); glVertexAttribDivisor(0, 1);
        glEnableVertexAttribArray(1); glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 32, (void*)16); glVertexAttribDivisor(1, 1);
        glBindVertexArray(0); gOkF = true;
    }
}

// one cell: where its tuft stands, how big it is (0 = no grass here) and the ground colour under it
static void compute(long cx, long cz, float S, float* o){
    const double x = (cx + 0.1 + 0.8*hash2(cx, cz, 1)) * S, z = (cz + 0.1 + 0.8*hash2(cx, cz, 2)) * S;
    o[0] = (float)x; o[2] = (float)z; o[1] = 0; o[3] = 0; o[4] = o[5] = o[6] = 0; o[7] = hash2(cx, cz, 3);
    const float cl = Road::clearance((float)x, (float)z);
    // keep tall grass OFF the road: the cut-off is larger than before because blades lean ~0.5 m and billboards are wide (the coarse grid needs the most margin)
    const float cut = S > 0.4f ? 3.0f : 2.3f; if (cl < cut) return;                                   // road + verge
    if (Terrain::summitCleared(x, z, 0.0)) return;                                                 // the hilltop is paved / built over
    if (Terrain::gLake.on && Terrain::lakeDn(x, z) < 1.15) return;                                 // lake + beach
    if (River::groundH(x, z) < -0.10) return;                                                      // river bed
    double r = 0.300, g = 0.450, b = 0.190; Terrain::grassColor(x, z, Terrain::fieldH(x, z), r, g, b);
    const float gk = ss(1.04f, 1.14f, (float)(g / std::max(r, 0.01))) * (g > b * 1.5 ? 1.f : 0.f);   // sand, dirt, rock and snow are not green
    if (gk <= 0.f) return;
    o[3] = gk * ss(cut, cut + 2.6f, cl) * (0.75f + 0.5f * hash2(cx, cz, 4));
    o[1] = (float)Terrain::meshH(x, z); o[4] = (float)r; o[5] = (float)g; o[6] = (float)b;
}

static void updateGrid(const float* eye, int N, float S, std::vector<float>& data, std::vector<long>& kx, std::vector<long>& kz, int budget){
    const long ccx = (long)std::floor(eye[0] / S), ccz = (long)std::floor(eye[2] / S), x0 = ccx - N/2, z0 = ccz - N/2;
    for (int j = 0; j < N; j++){
        const long cz = z0 + (((j - z0) % N) + N) % N;
        for (int i = 0; i < N; i++){
            const long cx = x0 + (((i - x0) % N) + N) % N; const size_t s = (size_t)j*N + i;
            if (kx[s] == cx && kz[s] == cz) continue;
            if (budget <= 0) { if (kx[s] == LONG_MIN) continue; data[s*8+3] = 0; continue; }       // out of budget: hide the stale tuft until its turn
            compute(cx, cz, S, &data[s*8]); kx[s] = cx; kz[s] = cz; budget--; gDirty = true;
        }
    }
}
static void update(const float* eye){
    if (!gOk) return;
    updateGrid(eye, N, S, gData, gKX, gKZ, PER_FRAME);
    if (gOkF) updateGrid(eye, N2, S2, gData2, gKX2, gKZ2, PER_FRAME2);
}

static void draw(const float* VP, const float* eye, const float* car, float tSec){
    if (!gOk) return;
    update(eye);
    // only tufts that exist and are inside the view are sent to the GPU (8x more tufts than before, so this keeps the draw cheap)
    float pl[5][4];
    for (int i = 0; i < 5; i++){ const int a = i >> 1; const float sg = (i & 1) ? 1.f : -1.f;
        for (int j = 0; j < 4; j++) pl[i][j] = VP[j*4 + 3] + sg * VP[j*4 + a];
        const float l = std::sqrt(pl[i][0]*pl[i][0] + pl[i][1]*pl[i][1] + pl[i][2]*pl[i][2]); if (l > 1e-6f) for (int j = 0; j < 4; j++) pl[i][j] /= l; }
    static std::vector<float> vis, visF, visC; static int gCullTick = 0; const bool recull = (gCullTick++ & 1) == 0;   // visible lists are rebuilt every 2nd frame (wider margin below hides the edge), the other frames reuse them
    if (recull){ vis.clear(); visF.clear(); visC.clear(); }
    const int lv = Quality::level < 0 ? 0 : (Quality::level > 2 ? 2 : Quality::level);
    const int gm = Quality::grassMode;                                          // 0 mixed, 1 all 3D, 2 all 2D
    const float nearR = gm == 2 ? 0.f : (gm == 1 ? 1000.f : Q_NEAR[lv]), nr2 = nearR*nearR, keep = gm == 2 ? 1.01f : Q_KEEP[lv], keep2 = gm == 2 ? 1.01f : Q_KEEP2[lv];
    const float rangeK = Q_RANGE[lv] * Quality::grassScale;                     // far grass distance factor (Low shorter, "Grass distance" setting still applies)
    const float fineR = N * S * 0.5f * Quality::grassScale;                     // fine grid radius (~20 m)
    const float farR  = N2 * S2 * 0.5f * rangeK;                                // coarse grid radius (up to ~60 m)
    const float farIn0 = std::min(16.f, fineR * 0.8f), farIn1 = std::min(22.f, fineR * 1.1f);
    // fine grid: 3D blades near the camera / car, billboards beyond
    if (recull) for (size_t s = 0; s < (size_t)N*N; s++){
        const float* d = &gData[s*8]; if (d[3] < 0.01f) continue;
        { const float gdx = d[0] - eye[0], gdz = d[2] - eye[2]; if (gdx*gdx + gdz*gdz > fineR*fineR) continue; }
        bool out = false; const float cy = d[1] + 0.2f;
        for (int i = 0; i < 5 && !out; i++) if (pl[i][0]*d[0] + pl[i][1]*cy + pl[i][2]*d[2] + pl[i][3] < -2.5f) out = true;
        if (out) continue;
        const float ex = d[0] - eye[0], ez = d[2] - eye[2], cx = d[0] - car[0], cz = d[2] - car[2];
        if (!gOkF || ex*ex + ez*ez < nr2 || cx*cx + cz*cz < nr2) vis.insert(vis.end(), d, d + 8);       // close to the camera / car: real 3D blades
        else if (d[7] < keep) visF.insert(visF.end(), d, d + 8);                                        // beyond: one flat billboard (only some of the cells)
    }
    const int cntNear = (int)(vis.size() / 8), cntMid = (int)(visF.size() / 8);
    // coarse grid: billboards only, from the end of the fine grid out to ~60 m
    if (recull && gOkF) for (size_t s = 0; s < (size_t)N2*N2; s++){
        const float* d = &gData2[s*8]; if (d[3] < 0.01f) continue;
        { const float gdx = d[0] - eye[0], gdz = d[2] - eye[2], q = gdx*gdx + gdz*gdz; if (q > farR*farR || q < farIn0*farIn0) continue; }
        if (d[7] >= keep2) continue;
        bool out = false; const float cy = d[1] + 0.2f;
        for (int i = 0; i < 5 && !out; i++) if (pl[i][0]*d[0] + pl[i][1]*cy + pl[i][2]*d[2] + pl[i][3] < -2.5f) out = true;
        if (out) continue;
        visC.insert(visC.end(), d, d + 8);
    }
    const int cntC = (int)(visC.size() / 8);
    if (!cntNear && !cntMid && !cntC) return;
    glEnable(GL_DEPTH_TEST); glDepthMask(GL_TRUE); glDisable(GL_BLEND); glDisable(GL_CULL_FACE);
    if (cntNear){
        glBindVertexArray(gVao); glBindBuffer(GL_ARRAY_BUFFER, gVbo); glBufferData(GL_ARRAY_BUFFER, vis.size()*4, vis.data(), GL_STREAM_DRAW);
        glUseProgram(gProg); glUniformMatrix4fv(uVP, 1, GL_FALSE, VP); glUniform3fv(uCam, 1, eye); glUniform3fv(uCar, 1, car); glUniform1f(uTime, tSec);
        glDrawArraysInstanced(GL_TRIANGLES, 0, 54, cntNear);   // 6 blades per tuft (was 4)
    }
    if (gOkF && (cntMid || cntC)){
        glUseProgram(gProgF); glUniformMatrix4fv(uVPF, 1, GL_FALSE, VP); glUniform3fv(uCamF, 1, eye); glUniform3fv(uCarF, 1, car); glUniform1f(uTimeF, tSec);
        glBindVertexArray(gVaoF); glBindBuffer(GL_ARRAY_BUFFER, gVboF);
        if (cntMid){                                                                                      // fine-grid billboards: appear outside the 3D zone, shrink away at ~20 m
            glUniform4f(uFadeF, nearR - 1.f, nearR, fineR * 0.7f, fineR); glUniform2f(uSzF, 0.34f, 1.9f);
            glBufferData(GL_ARRAY_BUFFER, visF.size()*4, visF.data(), GL_STREAM_DRAW); glDrawArraysInstanced(GL_TRIANGLES, 0, 6, cntMid);
        }
        if (cntC){                                                                                        // coarse-grid billboards: grow in at ~16-22 m, shrink away at the far limit
            glUniform4f(uFadeF, farIn0, farIn1, farR * 0.82f, farR); glUniform2f(uSzF, 0.50f, 2.4f);
            glBufferData(GL_ARRAY_BUFFER, visC.size()*4, visC.data(), GL_STREAM_DRAW); glDrawArraysInstanced(GL_TRIANGLES, 0, 6, cntC);
        }
    }
    glBindVertexArray(0);
}

}   // namespace GrassGL
