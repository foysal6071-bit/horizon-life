// Sunny Drift - rolling hills, distant mountains and the dirt track: C++ port of the HTML terrain blocks (pure C++, no OpenGL).
//  * fieldNoise / fieldMask / fieldH   = "Gentle natural rolling terrain on the green fields" (hills + mountain massifs up to 25 m,
//                                        flat next to the roads and the river, graded along the dirt track)
//  * buildTrack / trackQ                = "Narrow dirt track winding over the mountains" (centre line, graded height, nearest distance)
//  * distant mountain ring              = "Distant mountain ranges" (ridged noise height field, forest -> meadow -> rock -> snow)
//  * the ground mesh heights/colours    = "Apply the rolling terrain to the grass mesh"; carGroundH / meshH = what the tyres touch
//  Like the HTML (FSEED, Math.random) the hills and the track are different on every launch: call setSeed() before anything else.
//  Not part of this port (the C++ game has no sea / pier / houses): coast and pier masks of the HTML are reduced to the coast
//  distance that keeps the hills away from the island edge.
//  WORLD x1.5: playable disc radius 1440 m (was 960), 5 m ground lattice x -1350..1350, z -960..960 (it is also the river patch), mountain ring r 1320..2175.
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <random>
#include <thread>
#include <unordered_map>
#include <vector>
#include "road.h"

namespace Terrain {

using River::sstep;
static const double FIELD_MAX = 52, FIELD_AMP = 31;            // random hills / mountains rise up to 25 m
static double FSEED[4] = {0.5, 100, 200, 300};
static bool gReady = false;                                     // FIELD_READY in the HTML

static inline double clamp01(double v){ return v < 0 ? 0 : v > 1 ? 1 : v; }

// ---------- noise (fHash / fNoise / fFbm) ----------
static inline double fHash(double x, double y){ const double h = std::sin(x*127.1 + y*311.7 + FSEED[0]*0.37) * 43758.5453; return h - std::floor(h); }
static double fNoise(double x, double y){
    const double ix = std::floor(x), iy = std::floor(y), fx = x - ix, fy = y - iy, u = fx*fx*(3 - 2*fx), v = fy*fy*(3 - 2*fy);
    return (fHash(ix, iy)*(1-u) + fHash(ix+1, iy)*u)*(1-v) + (fHash(ix, iy+1)*(1-u) + fHash(ix+1, iy+1)*u)*v;
}
static double fFbm(double x, double y, int o){
    double a = 0.5, s = 0, f = 1, n = 0;
    for (int i = 0; i < o; i++){ s += a * fNoise(x*f + i*17.3, y*f - i*9.1); n += a; f *= 2.03; a *= 0.5; }
    return s / n;
}

// ---------- island coast (only used to keep the hills away from the edge of the land) ----------
static const double PI_2 = 1.57079632679489661923;
static const double COAST0 = 1350;
static inline double coastR(double a){ return COAST0 + std::sin(a*2 + 0.7)*51 + std::cos(a*3 - 1.1)*33 + std::sin(a*5 + 2.0)*15; }
// hills fade out between HF0 and HF1 (they grow again beyond the mountain ring, HF2 .. HF3)
static const double HF0 = 1350, HF1 = 1575, HF2 = 2175, HF3 = 2400;
static inline double coastDist(double x, double z){ return std::hypot(x, z) - coastR(std::atan2(z, x)); }     // < 0 = inland

// like Road::clearance but looks 4 cells (96 m) around, so the terrain fade is smooth
static double fieldClear(double x, double z){
    const long cx = (long)std::floor(x / Road::RG), cz = (long)std::floor(z / Road::RG); double best = 1e9;
    for (int i = -4; i <= 4; i++) for (int j = -4; j <= 4; j++){
        auto it = Road::gNet.grid.find(Road::cellKey(cx + i, cz + j)); if (it == Road::gNet.grid.end()) continue;
        const std::vector<float>& l = it->second;
        for (size_t k = 0; k < l.size(); k += 3){ const double dx = x - l[k], dz = z - l[k+1], d = std::sqrt(dx*dx + dz*dz) - l[k+2]; if (d < best) best = d; }
    }
    return best;
}

// ---------- dirt track ----------
static const double TRK_HW = 7.2, TRK_BL = 38, TRK_W = 8.5;     // flat half-width, banks blend width, visible dirt width (m)
struct Track {
    bool on = false; int n = 0; double cell = 48;
    std::vector<float> pts, g, clr, L;                         // pts = x,z pairs; g = graded height; clr = distance from the tarmac edge; L = segment length
    std::unordered_map<long long, std::vector<int>> grid;
};
static Track TRK;
static thread_local double tkD = 1e9, tkG = 0;                               // _tkD / _tkG
static inline long long tkKey(long cx, long cz){ return (long long)(cx + 100000) * 200003LL + (cz + 100000); }
static void trackQ(double x, double z){                         // nearest distance to the track (tkD) and its graded height there (tkG)
    tkD = 1e9; tkG = 0; if (!TRK.on) return;
    const long cx = (long)std::floor(x / TRK.cell), cz = (long)std::floor(z / TRK.cell); const int n = TRK.n; const float* P = TRK.pts.data();
    static thread_local std::vector<std::pair<float, float>> cand; cand.clear();        // (distance, graded height) of every nearby segment
    for (int i = -1; i <= 1; i++) for (int j = -1; j <= 1; j++){
        auto it = TRK.grid.find(tkKey(cx + i, cz + j)); if (it == TRK.grid.end()) continue;
        for (int q : it->second) for (int k = q - 1; k <= q; k++){
            if (k < 0 || k >= n - 1) continue;
            const double ax = P[k*2], az = P[k*2+1], ex = P[k*2+2] - ax, ez = P[k*2+3] - az;
            double t = ((x - ax)*ex + (z - az)*ez) / (ex*ex + ez*ez); t = t < 0 ? 0 : t > 1 ? 1 : t;
            const double dx = x - (ax + ex*t), dz = z - (az + ez*t), d = std::sqrt(dx*dx + dz*dz);
            const float gk = (float)(TRK.g[k] + (TRK.g[k+1] - TRK.g[k]) * t);
            if (d < tkD){ tkD = d; tkG = gk; }
            cand.push_back({(float)d, gk});
        }
    }
    if (cand.size() < 2) return;
    // switchbacks: two legs of the road lie only ~34 m apart at different heights. Weight every nearby segment by exp(-(d^2 - dmin^2) / 2s^2)
    // (s = 8 m): on the road the nearest segment dominates completely, half-way between two legs both count equally -> a smooth cut / fill bank, no cliff.
    const double inv = 1.0 / (2 * 8.0 * 8.0), d0 = tkD * tkD; double sw = 0, sg = 0;
    for (const auto& c : cand){ const double w = std::exp(-((double)c.first * c.first - d0) * inv); sw += w; sg += w * c.second; }
    if (sw > 0) tkG = sg / sw;
}
static double trackDist(double x, double z){ trackQ(x, z); return tkD; }

// ---------- rolling hills (fieldNoise / fieldMask / fieldH) ----------
static double fieldNoise(double x, double z){            // realistic: mountain massifs with ridged crests, eroded flanks, terraces and soft meadows between
    // domain warp so ridges meander instead of looking like grid noise
    const double wx = x + 38*(fFbm(x/190 + FSEED[2], z/190 + 7.3, 2) - 0.5), wz = z + 38*(fFbm(x/190 - 5.1, z/190 + FSEED[1], 2) - 0.5);
    const double big  = fFbm(wx/420 + FSEED[1], wz/420 + FSEED[2], 3);
    const double vd = std::fabs(z - 40*std::sin(x/300 + 0.5));                                   // distance from the valley axis
    const double mass = clamp01(0.35*sstep(0.37, 0.61, big) + sstep(200, 500, vd));               // Swiss valley: soft meadow floor, mountain walls on both sides
    const double det  = fFbm(wx/150 + FSEED[3], wz/150 - FSEED[1], 3);
    const double roll = fFbm(wx/160 - FSEED[2], wz/160 + FSEED[3], 2);
    // ridged multifractal: sharp crests and gullies on the mountains
    double rg = 0, a = 0.5, f = 1.0 / 110, w = 1;
    for (int i = 0; i < 4; i++){ double n = 1 - std::fabs(fNoise(wx*f + FSEED[3] + i*3.1, wz*f - FSEED[2] + i*5.7)*2 - 1); n *= n; n *= w; w = clamp01(n*1.6); rg += n*a; f *= 2.1; a *= 0.5; }
    const double crest = sstep(0.45, 0.9, mass);
    double h = FIELD_AMP*mass*(0.35 + 0.45*det + 0.55*rg*crest) + 3.0*roll;
    h += 0.9*(fFbm(x/14 + 31.7, z/14 - 12.9, 2) - 0.5) * (0.4 + mass);     // small bumps, rocks and hummocks
    h += 2.2*(fFbm(x/62 + 53.1, z/62 - 27.4, 2) - 0.5) + 0.8*(fFbm(x/26 - 8.8, z/26 + 41.2, 2) - 0.5);   // soft rolling swells (wavy meadow floor, tens of metres across)
    { const double st = h / 3.2; const double fl = std::floor(st), fr = st - fl; h = (fl + sstep(0.35, 0.65, fr) * 0.35 + fr*0.65) * 3.2 * mass + h*(1 - mass); }   // faint terracing on slopes
    return std::max(0.0, std::min(FIELD_MAX, h));
}
static double fieldMask(double x, double z){
    const double edge = std::min(std::min(x - River::GX0, River::GX1 - x), std::min(z - River::GZ0, River::GZ1 - z));      // distance to the edge of the lattice; the outer ground continues from there
    if (edge <= 0) return 0;
    double m = 1 - sstep(HF0, HF1, std::hypot(x, z));                   // same radial fade as the outer ground (outerH): the hills die away under the mountain ring
    if (m <= 0) return 0;
    const double rd = std::fabs(River::riverSd(x, z)); if (rd < 120) m *= sstep(40, 120, rd);   // keep the river banks as they were
    if (m <= 0) return 0;
    return m * sstep(10, 80, fieldClear(x, z));                           // roads stay perfectly level, hills grow away from them
}
// ===================================================================================================
//  WINDING_ROAD_HILL  <- tell Claude: "put the winding road on WINDING_ROAD_HILL"
//  The big empty mountain (PEAK, centre PEAK.x / PEAK.z, radius PEAK.R, height PEAK.H) is placed by buildPeak() below.
//  Its height comes from peakH(). A road for it would go into buildTrack() (old dirt-track code, now unused) or a new function.
// ===================================================================================================
// ---------- big empty mountain (replaces the dirt track: a blank hill for the player's own winding road) ----------
// SWISS tall mountain: R = foot radius, H = height of the summit above the valley floor, PLATEAU = fraction of the outline radius that is the flat summit
//  (the parking ring PAD_R lives on it: 72 m = 3 x the old 24 m). padOn / padY / padR: the summit pad is levelled exactly to the road height (see fieldH).
static const double PEAK_PLATEAU = 0.45, PEAK_PAD_R = 72.0;
struct PeakT { bool on = false; double x = 0, z = 0, R = 285, H = 140, ph1 = 0, ph2 = 0; bool padOn = false; double padY = 0, padR = 0; };
static PeakT PEAK;
// SUMMIT: direction (angle from the summit centre) where the hill road reaches the summit ring, and the cleared hilltop (no trees / grass / flowers / shrubs)
static double gPadA = 0;
static inline double summitClearR(){ return Road::gPark[2] + 28.0; }
static inline bool summitCleared(double x, double z, double margin){
    if (!PEAK.on || !PEAK.padOn) return false;
    const double dx = x - PEAK.x, dz = z - PEAK.z, r = summitClearR() + margin; return dx*dx + dz*dz < r*r;
}
static inline double peakRe(double a){ return PEAK.R * (1 + 0.16*std::sin(3*a + PEAK.ph1) + 0.09*std::sin(5*a + PEAK.ph2) + 0.05*std::sin(8*a + 1.7)); }
static const double PK_CX = 771.4, PK_CZ = 149.3, PK_AX = 311.8, PK_AZ = 391.5, PK_ZS = 408.9, PK_ZP = -121.8;   // mountain footprint (ellipse) and the z of the road start / summit: the climb rises towards the north
static double peakH(double x, double z){
    if (!PEAK.on) return 0;
    const double ex = (x - PK_CX) / PK_AX, ez = (z - PK_CZ) / PK_AZ, q = std::sqrt(ex*ex + ez*ez); if (q >= 1.5) return 0;
    const double m = 1.0 - sstep(0.85, 1.5, q);
    double u = (PK_ZS - z) / (PK_ZS - PK_ZP); u = std::min(1.0, std::max(0.0, u));
    const double g = 0.5*u + 0.5*(u*u*(3 - 2*u));
    const double bump = (1.0 - sstep(0.85, 1.0, u)) * sstep(0.0, 0.12, u);
    return PEAK.H * g * m * (1 + bump * (0.05*std::sin(x*0.021 + PEAK.ph1)*std::sin(z*0.027 + PEAK.ph2) + 0.03*std::sin(x*0.06 + z*0.05)));
}
// ALPINE MEADOW: the middle slopes of the big mountain (above the foot, below the summit car park) are fresh green meadow with flowers and small stones.
//  returns 0..1 (1 = the heart of the band); the callers also look at the steepness, so cliffs stay bare rock
static inline double alpineBand(double x, double z){
    if (!PEAK.on) return 0;
    const double h = peakH(x, z); if (h <= 0) return 0;
    const double t = h / PEAK.H;                                  // 0 = foot .. 1 = summit
    return sstep(0.10, 0.22, t) * (1 - sstep(0.80, 0.92, t));
}
struct LakeT { bool on = false; double x = 0, z = 0, r = 150, y = 0, ce = 1.58; };     // ce = shore radius where the beach / bank has merged into the hills
static LakeT gLake;
static const double LAKE_DEPTH = 6.0;
static inline double lakeDn(double x, double z){ return gLake.on ? std::hypot(x - gLake.x, z - gLake.z) / gLake.r : 1e9; }   // 1 = shoreline
static inline double lakeBed(double dn){ return dn < 1 ? -LAKE_DEPTH * (1 - dn*dn) : 0.1; }
static inline double lakeCarve(double x, double z, double h){
    if (!gLake.on) return h;
    const double dn = lakeDn(x, z); if (dn >= gLake.ce) return h;
    if (dn < 1.0) return lakeBed(dn);                                                    // bowl inside
    const double bank = 0.1 + 3.0 * (dn - 1.0), w = sstep(1.15, gLake.ce, dn);           // BEACH: a gentle ~3 % sand slope (drivable), then it blends into the hills / mountain foot
    return bank * (1 - w) + h * w;
}
// how much of this point is beach sand (1 = sand, 0 = meadow): the whole lake shore, fading out at 1.30 .. 1.58 shore radii
static inline double beachK(double x, double z){ const double dn = lakeDn(x, z); return dn >= 1.58 ? 0.0 : 1.0 - sstep(1.30, 1.58, dn); }
static double fieldH(double x, double z){
    if (!gReady) return 0;
    const double m = fieldMask(x, z);
    double h = 0;
    if (m > 0) h = fieldNoise(x, z) * m;
    h += peakH(x, z);
    h = lakeCarve(x, z, h);
    if (TRK.on){ trackQ(x, z); if (tkD < TRK_HW + TRK_BL) h += (tkG - h) * (1 - sstep(TRK_HW, TRK_HW + TRK_BL, tkD)); }   // grade the ground along the dirt track
    if (PEAK.padOn){ const double dd = std::hypot(x - PEAK.x, z - PEAK.z); if (dd < PEAK.padR + 45) h += (PEAK.padY - h) * (1 - sstep(PEAK.padR + 5, PEAK.padR + 45, dd)); }   // the summit parking pad is perfectly level
    { const double W = h > 3 ? std::min(85.0, std::max(10.0, h / 0.30)) : 10.0;   // a raised hairpin mound needs a longer, gentler run-out to the level tarmac (fieldClear sees 96 m, Road::clearance only ~24 m)
      const double rc = W > 10.0 ? fieldClear(x, z) : (double)Road::clearance((float)x, (float)z); if (rc < 4 + W) h *= sstep(4, 4 + W, rc); }   // the tarmac always wins: exactly 0 within 4 m of a road edge; a raised hairpin mound falls to it at <= 30 % grade
    return h;
}

// WINDING_ROAD_HILL: picks where the empty mountain stands (called from Terrain::init instead of buildTrack)
static void buildPeak(std::mt19937& rng){
    std::uniform_real_distribution<double> U(0.0, 1.0);
    PEAK = PeakT(); PEAK.ph1 = U(rng) * 6.283; PEAK.ph2 = U(rng) * 6.283;
    PEAK.x = 870.0; PEAK.z = -121.8; PEAK.R = 650; PEAK.H = 185; PEAK.on = true; const double bx = PEAK.x, bz = PEAK.z;
    std::vector<float> pl;                                                                              // the hill road of the map: hairpin switchbacks up to the summit pad, sampled every 3 m
    { Road::Curve hc = Road::makeEdge(Road::hillPts()); const double L = hc.length();
      for (double s = 0; s < L; s += 3.0){ const Road::V3 p = hc.getPointAt(s / L); pl.push_back((float)p.x); pl.push_back((float)p.z); }
      const Road::V3 pe = hc.getPointAt(1.0); pl.push_back((float)pe.x); pl.push_back((float)pe.z); }
    {   // PARKING_AREA: on the summit the road closes into a flat circular asphalt pad (one full lap at the last radius) where the car can be parked
        const int m = (int)pl.size() / 2; const double lx = pl[(m-1)*2] - bx, lz = pl[(m-1)*2+1] - bz, r = std::max(16.0, std::sqrt(lx*lx + lz*lz)), a1 = std::atan2(lz, lx); gPadA = a1;
        Road::gPark[0] = (float)bx; Road::gPark[1] = (float)bz; Road::gPark[2] = (float)r;
        for (double da = 3.0 / r; da < 2 * PI_2 * 2; da += 3.0 / r){ pl.push_back((float)(bx + std::cos(a1 + da) * r)); pl.push_back((float)(bz + std::sin(a1 + da) * r)); }
    }
    const int n = (int)pl.size() / 2; if (n < 20) return;
    { const double hx0 = (double)pl[2] - pl[0], hz0 = (double)pl[3] - pl[1], hl = std::hypot(hx0, hz0);        // the paved road from the valley road (Road::MTN_NODE) to the first point of the hill road: the mountain is part of the road network
      if (hl > 1e-6) Road::addConnector(pl[0], pl[1], hx0 / hl, hz0 / hl); }
    Track T; T.n = n; T.pts = pl; T.clr.assign(n, 0); T.L.assign(n, 0); std::vector<float> G(n);
    for (int i = 0; i < n; i++){ G[i] = (float)peakH(pl[i*2], pl[i*2+1]); T.clr[i] = (float)fieldClear(pl[i*2], pl[i*2+1]); if (i < n - 1) T.L[i] = (float)std::hypot((double)pl[i*2+2] - pl[i*2], (double)pl[i*2+3] - pl[i*2+1]); }
    auto smooth = [&](const std::vector<float>& A, int w){ std::vector<float> B(n); for (int i = 0; i < n; i++){ float sm = 0; int c = 0; for (int k = -w; k <= w; k++){ int j = i + k; if (j < 0 || j >= n) continue; sm += A[j]; c++; } B[i] = sm / c; } return B; };
    auto pin = [&](std::vector<float>& V){ for (int i = 0; i < n; i++) if (T.clr[i] < 12 || i < 4) V[i] = 0; };           // level where it meets the tarmac
    for (int r = 0; r < 3; r++) G = smooth(G, 10);
    pin(G);
    for (int r = 0; r < 3; r++){ for (int i = 1; i < n; i++) G[i] = std::min(G[i], G[i-1] + 0.08f * T.L[i-1]); }          // never steeper than 8 %
    { const int pad = (int)std::ceil(2 * PI_2 * 2 * std::max(16.0, (double)Road::gPark[2]) / 3.0) + 2; for (int i = std::max(1, n - pad); i < n; i++) G[i] = G[std::max(0, n - pad - 1)]; }   // PARKING_AREA lap: dead level
    G = smooth(G, 2); pin(G); T.g = G;
    PEAK.padY = G[n - 1]; PEAK.padR = Road::gPark[2]; PEAK.padOn = true;                                                    // level the whole summit pad to the road
    for (int i = 0; i < n; i++) T.grid[tkKey((long)std::floor(pl[i*2] / 48.0), (long)std::floor(pl[i*2+1] / 48.0))].push_back(i);
    T.on = true; TRK = T;
}

static void buildTrack(std::mt19937& rng){
    std::uniform_real_distribution<double> U(0.0, 1.0);
    const double rvC = std::cos(Road::gNet.riverAng), rvS = std::sin(Road::gNet.riverAng);
    const double nx = rvC, nz = -rvS, ph1 = U(rng) * 6.283, ph2 = U(rng) * 6.283;     // runs parallel to the river, on one side of it
    double bestScore = -1, bo = 0, bt0 = 0, bt1 = 0; bool have = false;
    for (double o0 : {-690.0, -670.0, 670.0, 690.0}){      // the outer ring road (z up to +-530) lies between the track and the middle of the valley
        auto P = [&](double t, double& px, double& pz){ const double o = o0 + 45*std::sin(t/140 + ph1) + 20*std::sin(t/60 + ph2); px = rvS*t + nx*o; pz = rvC*t + nz*o; };
        double t0 = 0, t1 = 0, qx, qz;
        while (t0 > -1350){ P(t0 - 3, qx, qz); if (coastDist(qx, qz) > -75) break; t0 -= 3; }
        while (t1 <  1350){ P(t1 + 3, qx, qz); if (coastDist(qx, qz) > -75) break; t1 += 3; }
        if (t1 - t0 < 500) continue;
        {   // the rivers must not cut across the dirt track: keep the longest stretch that stays clear of every river (the tributaries cross the 2 outer candidate lines)
            double bA = t0, bB = t0, cA = t0; bool open = false;
            for (double t = t0; t <= t1 + 1e-9; t += 6){ P(t, qx, qz); const bool bad = std::fabs(River::riverSd(qx, qz)) < 70;
                if (bad) open = false; else { if (!open){ open = true; cA = t; } if (t - cA > bB - bA){ bA = cA; bB = t; } } }
            t0 = bA; t1 = bB;
        }
        if (t1 - t0 < 500) continue;
        double sc = 0; int cnt = 0; for (double t = t0; t <= t1; t += 30){ P(t, qx, qz); sc += fieldH(qx, qz); cnt++; }
        sc /= cnt; if (sc > bestScore){ bestScore = sc; bo = o0; bt0 = t0; bt1 = t1; have = true; }
    }
    if (!have) return;
    auto Pb = [&](double t, double& px, double& pz){ const double o = bo + 45*std::sin(t/140 + ph1) + 20*std::sin(t/60 + ph2); px = rvS*t + nx*o; pz = rvC*t + nz*o; };
    // ---- hairpin climb: the track leaves the valley floor and zig-zags up a mountain flank in tight switchbacks ----
    //  local frame: adv = along the river axis, lat = across it. entry arc -> 6 legs of 50 m joined by 5 hairpins (two 90-degree arcs R 9 m + a 14 m landing,
    //  legs 32 m apart) -> exit arc back onto the axis. The graded height climbs ~5.5 % along the whole zone (see E below).
    const double HP_R = 9, HP_S = 32, HP_LEG = 50; const int HP_K = 5; const double HP_ADV = 2*HP_R + HP_K*HP_S;     // 178 m along the axis
    auto oOf = [&](double t){ return bo + 45*std::sin(t/140 + ph1) + 20*std::sin(t/60 + ph2); };
    std::vector<std::pair<double, double>> Z;                                          // zone centre line in (adv, lat), first point = entry (0,0)
    {
        const double R = HP_R, STEP = 2.5, STR = HP_S - 2*HP_R, HP = PI_2; const int na = std::max(4, (int)std::ceil(R * HP / STEP));
        for (int k = 1; k <= na; k++){ const double f = k * HP / na; Z.push_back({R*std::sin(f), R*(1 - std::cos(f))}); }          // entry arc: +adv -> +lat
        for (int j = 0; j <= HP_K; j++){
            const double adv = R + j*HP_S; const int s = (j % 2 == 0) ? 1 : -1;
            const double lStart = s > 0 ? R : R + HP_LEG, lEnd = s > 0 ? R + HP_LEG : R; const int nl = (int)std::ceil(HP_LEG / STEP);
            for (int k = 1; k <= nl; k++) Z.push_back({adv, lStart + s * HP_LEG * k / nl});                                           // straight leg
            for (int k = 1; k <= na; k++){ const double f = k * HP / na; Z.push_back({adv + R*(1 - std::cos(f)), lEnd + s*R*std::sin(f)}); }   // 90 deg turn
            if (j == HP_K) break;                                                                                                     // last leg: that turn leads back onto the axis
            const int ns = std::max(1, (int)std::ceil(STR / STEP));
            for (int k = 1; k <= ns; k++) Z.push_back({adv + R + STR * k / ns, lEnd + s*R});                                          // landing
            for (int k = 1; k <= na; k++){ const double f = k * HP / na; Z.push_back({adv + R + STR + R*std::sin(f), lEnd + s*R - s*R*(1 - std::cos(f))}); }   // second 90 deg turn
        }
    }
    double zBest = -1, zT = 0; int zSg = 1;
    for (double te = bt0 + 60; te <= bt1 - HP_ADV - 240; te += 10) for (int sg : {1, -1}){           // where does the climb start? (valid: clear of roads / river / coast, on the highest ground)
        double ex, ez; Pb(te, ex, ez); bool ok = true; double sum = 0; int cnt = 0;
        for (size_t k = 0; k < Z.size(); k += 3){
            const double wx = ex + rvS*Z[k].first + nx*sg*Z[k].second, wz = ez + rvC*Z[k].first + nz*sg*Z[k].second;
            if (fieldClear(wx, wz) < 28 || std::fabs(River::riverSd(wx, wz)) < 80 || coastDist(wx, wz) > -80){ ok = false; break; }
            sum += fieldH(wx, wz); cnt++;
        }
        if (ok && cnt && sum / cnt > zBest){ zBest = sum / cnt; zT = te; zSg = sg; }
    }
    std::vector<float> pl; int zi0 = -1, zi1 = -1; double Hc = 0;
    if (zBest >= 0){
        const double te = zT, tx2 = zT + HP_ADV, oe = oOf(te); double ex, ez; Pb(te, ex, ez);
        for (double t = bt0; t <= te; t += 3){ const double o = oOf(t) + (oe - oOf(t)) * sstep(te - 100, te, t); pl.push_back((float)(rvS*t + nx*o)); pl.push_back((float)(rvC*t + nz*o)); }   // approach straightens out into the entry
        zi0 = (int)pl.size() / 2;
        for (const auto& q : Z){ pl.push_back((float)(ex + rvS*q.first + nx*zSg*q.second)); pl.push_back((float)(ez + rvC*q.first + nz*zSg*q.second)); }
        zi1 = (int)pl.size() / 2 - 1;
        for (double t = tx2 + 3; t <= bt1; t += 3){ const double o = oe + (oOf(t) - oOf(tx2)) * sstep(tx2, tx2 + 120, t); pl.push_back((float)(rvS*t + nx*o)); pl.push_back((float)(rvC*t + nz*o)); }
        double Lz = 0; for (int i = zi0; i < zi1; i++) Lz += std::hypot((double)pl[i*2+2] - pl[i*2], (double)pl[i*2+3] - pl[i*2+1]);
        Hc = std::min(26.0, std::min(0.055 * Lz, 0.055 * (bt1 - tx2) * 0.9));
    } else {
        for (double t = bt0; t <= bt1; t += 3){ double qx, qz; Pb(t, qx, qz); pl.push_back((float)qx); pl.push_back((float)qz); }
    }
    const int n = (int)pl.size() / 2; Track T; T.n = n; T.pts = pl; T.clr.assign(n, 0); T.L.assign(n, 0);
    std::vector<float> H0(n);
    for (int i = 0; i < n; i++){
        H0[i] = (float)fieldH(pl[i*2], pl[i*2+1]); T.clr[i] = (float)fieldClear(pl[i*2], pl[i*2+1]);
        if (i < n - 1) T.L[i] = (float)std::hypot((double)pl[i*2+2] - pl[i*2], (double)pl[i*2+3] - pl[i*2+1]);
    }
    if (zi0 >= 0){ double m = 0; for (int i = zi0; i <= zi1; i++) m += H0[i]; m /= (zi1 - zi0 + 1); for (int i = zi0; i <= zi1; i++) H0[i] = (float)m; }   // the climb itself supplies the slope there
    auto smooth = [&](const std::vector<float>& A, int w){ std::vector<float> B(n); for (int i = 0; i < n; i++){ float sm = 0; int c = 0; for (int k = -w; k <= w; k++){ int j = i + k; if (j < 0 || j >= n) continue; sm += A[j]; c++; } B[i] = sm / c; } return B; };
    auto pin = [&](std::vector<float>& G){ for (int i = 0; i < n; i++) if (T.clr[i] < 12 || i < 4 || i > n - 5) G[i] = 0; };   // level where it meets the tarmac roads and the beach
    std::vector<float> G = H0;
    for (int r = 0; r < 3; r++) G = smooth(G, 12);                       // follow the average of the mountains, not every bump
    pin(G);
    for (int r = 0; r < 3; r++){                                          // never steeper than ~11 %: cuts through ridges, fills the dips
        for (int i = 1; i < n; i++) G[i] = std::min(G[i], G[i-1] + 0.11f * T.L[i-1]);
        for (int i = n - 2; i >= 0; i--) G[i] = std::min(G[i], G[i+1] + 0.11f * T.L[i]);
    }
    if (zi0 >= 0 && Hc > 1){                                              // add the switchback climb on top of the valley grade, then ease back down after the zone
        std::vector<double> s(n, 0.0); for (int i = 1; i < n; i++) s[i] = s[i-1] + T.L[i-1];
        std::vector<float> E(n, 0.f);
        for (int i = zi0; i < n; i++) E[i] = (float)(i <= zi1 ? Hc * (s[i] - s[zi0]) / (s[zi1] - s[zi0]) : std::max(0.0, Hc - 0.055 * (s[i] - s[zi1])));
        auto pinnedE = [&](int i){ return T.clr[i] < 12 || i < 4 || i > n - 5; };
        for (int i = 0; i < n; i++){ if (pinnedE(i)){ E[i] = 0; continue; } if (i > 0) E[i] = std::min(E[i], E[i-1] + 0.06f * T.L[i-1]); }        // never climb faster than 6 % away from a pinned (level) point ...
        for (int i = n - 1; i >= 0; i--){ if (pinnedE(i)){ E[i] = 0; continue; } if (i + 1 < n) E[i] = std::min(E[i], E[i+1] + 0.06f * T.L[i]); }   // ... in either direction
        for (int i = 0; i < n; i++) G[i] += E[i];
    }
    G = smooth(G, 2); pin(G);
    T.g = G;
    for (int i = 0; i < n; i++) T.grid[tkKey((long)std::floor(pl[i*2] / 48.0), (long)std::floor(pl[i*2+1] / 48.0))].push_back(i);
    T.on = true; TRK = T;
}

// ---------- ground height lattice: the rendered hill strips + the river patch share it (4 m cells) ----------
//  x = LX0 + 4 i (i = 0..LNX),  z = LZ0 + 4 k (k = 0..LNZ). The lattice and the river patch are one and the same grid.
static const double LX0 = River::GX0, LZ0 = River::GZ0, LC = River::GCELL;      // 5 m cells: x -1350..1350, z -960..960
static const int LNX = River::PNX, LNZ = River::PNZ;                            // the river patch IS the whole lattice now (no separate hill strips)
static std::vector<float> HL, FL;                                                  // ground height (river + hills) and hill part only
static inline size_t lix(int i, int k){ return (size_t)k * (LNX + 1) + i; }

// ---------- outer ground: everything beyond the 4 m lattice (foothills up to the mountain ring, rolling plains behind it) ----------
// ---------- mountain lake (carved into the foothills; the water surface itself is drawn by TerrainGL::drawLake with the river-water look) ----------
static double outerH(double x, double z){
    if (!gReady) return 0;
    const double r = std::hypot(x, z); const bool inLat = x >= River::GX0 && x <= River::GX1 && z >= River::GZ0 && z <= River::GZ1;
    const double amp = (inLat ? 0.0 : 1.0) * std::max(1 - sstep(HF0, HF1, r), sstep(HF2, HF3, r));
    double h = 0;
    if (amp > 0){ const double rd = std::fabs(River::riverSd(x, z)); h = fieldNoise(x, z) * amp * (rd < 120 ? sstep(40, 120, rd) : 1.0); }
    return lakeCarve(x, z, h);
}
static inline bool inLattice(double x, double z){ return x >= LX0 && z >= LZ0 && x <= LX0 + LNX*LC && z <= LZ0 + LNZ*LC; }
static inline double latSlope(double x, double z){          // steepness (rise/run) of the hill part, from the lattice (or the outer ground)
    if (!inLattice(x, z)){ const double e = 2.0; const double dx = (outerH(x+e, z) - outerH(x-e, z)) / (2*e), dz = (outerH(x, z+e) - outerH(x, z-e)) / (2*e); return std::sqrt(dx*dx + dz*dz); }
    if (FL.empty()) return 0;
    const int i = std::max(1, std::min(LNX - 1, (int)std::lround((x - LX0) / LC))), k = std::max(1, std::min(LNZ - 1, (int)std::lround((z - LZ0) / LC)));
    const double dx = (FL[lix(i+1, k)] - FL[lix(i-1, k)]) / (2*LC), dz = (FL[lix(i, k+1)] - FL[lix(i, k-1)]) / (2*LC);
    return std::sqrt(dx*dx + dz*dz);
}

// height of the rendered ground triangles at (x,z) (meshH in the HTML); outside the lattice there are no hills
static double meshH(double x, double z){
    const double fx = (x - LX0) / LC, fz = (z - LZ0) / LC;
    if (fx < 0 || fz < 0 || fx > LNX || fz > LNZ || HL.empty()) return River::groundH(x, z) + outerH(x, z);
    int i = (int)std::floor(fx), k = (int)std::floor(fz); i = std::max(0, std::min(LNX - 1, i)); k = std::max(0, std::min(LNZ - 1, k));
    const double u = fx - i, v = fz - k, ha = HL[lix(i, k)], hb = HL[lix(i + 1, k)], hc = HL[lix(i, k + 1)], hd = HL[lix(i + 1, k + 1)];
    return (u + v <= 1) ? ha + u*(hb - ha) + v*(hc - ha) : hb*(1 - v) + hc*(1 - u) + hd*(u + v - 1);     // the two triangles of the grid cell (a,c,b) + (b,c,d)
}
// what the tyres touch: the hill function, but exactly the rendered triangles (+ the raised dirt strip) on and next to the track
static double carGroundH(double x, double z){
    if (!inLattice(x, z)) return River::groundH(x, z) + outerH(x, z);
    const double f = fieldH(x, z);
    if (!TRK.on) return f;
    trackQ(x, z); const double d = tkD, hwT = TRK_W / 2;
    if (d > hwT + 8) return f;
    const double k = 1 - sstep(hwT + 4, hwT + 8, d);
    const double off = (Road::clearance((float)x, (float)z) > 1.2f) ? 0.15 * (1 - sstep(hwT + 1.5, hwT + 6, d)) : 0;
    return f*(1 - k) + (meshH(x, z) + off + 0.01) * k;
}

// ---------- meadow colour classes: 60 % green, 20 % light green, 10 % dark green, 10 % dry grass + small flowers ----------
//  Two independent noise fields (A = shade of green, B = dry patches). Their thresholds are calibrated once from sampled quantiles,
//  so the shares come out as asked whatever the noise happens to do: B > its 90 % quantile = dry; of the rest (A) the lowest 1/9 = dark, the top 2/9 = light, the middle = normal green.
static inline double shadeNoiseA(double x, double z){ return fFbm(x/85 + 11.3, z/85 - 4.7, 3)*0.75 + fNoise(x/17 + 2.2, z/17 + 9.1)*0.25; }
static inline double dryNoiseB(double x, double z){ return fFbm(x/60 - 21.7, z/60 + 13.9, 3)*0.8 + fNoise(x/11 + 5.5, z/11 - 3.3)*0.2; }
struct MeadowCal { double seed = -1, aDark = 0, aLight = 1, bDry = 1, soft = 0.02; };
static MeadowCal gMc;
static void meadowCalibrate(){
    if (gMc.seed == FSEED[0] + FSEED[1]*3 + FSEED[2]*7 + FSEED[3]*11) return;
    gMc.seed = FSEED[0] + FSEED[1]*3 + FSEED[2]*7 + FSEED[3]*11;
    const int N = 24000; std::vector<double> A, B; A.reserve(N); B.reserve(N);
    uint32_t st = 12345u;
    auto rnd = [&](){ st = st*1664525u + 1013904223u; return (st >> 8) / 16777216.0; };
    for (int i = 0; i < N; i++){ const double x = (rnd() - 0.5)*3600, z = (rnd() - 0.5)*3600; A.push_back(shadeNoiseA(x, z)); B.push_back(dryNoiseB(x, z)); }
    std::sort(A.begin(), A.end()); std::sort(B.begin(), B.end());
    gMc.aDark = A[(size_t)(N*(1.0/9.0))]; gMc.aLight = A[(size_t)(N*(7.0/9.0))]; gMc.bDry = B[(size_t)(N*0.80)];
    gMc.soft = std::max(0.006, (A[(size_t)(N*0.75)] - A[(size_t)(N*0.25)])*0.12);
}
// weights 0..1 of each class at (x, z); wDry also tells the flower planter where the dry / flowery patches are
static void meadowClass(double x, double z, double& wDark, double& wLight, double& wDry){
    meadowCalibrate();
    const double a = shadeNoiseA(x, z), b = dryNoiseB(x, z), s = gMc.soft;
    wDry = sstep(gMc.bDry - s, gMc.bDry + s, b);
    wDark = (1 - sstep(gMc.aDark - s, gMc.aDark + s, a)) * (1 - wDry);
    wLight = sstep(gMc.aLight - s, gMc.aLight + s, a) * (1 - wDry);
}
static inline double dryW(double x, double z){ double d, l, r; meadowClass(x, z, d, l, r); return r; }

// ---------- ground colour (the vertex colours of the grass mesh in the HTML, as a tint on this project's grass green) ----------
static inline double latSlope(double x, double z);
static void grassColor(double x, double z, double f, double& r, double& g, double& b){
    struct C3 { double r, g, b; };
    static const C3 c1 = {0x4a/255.0, 0x73/255.0, 0x34/255.0}, c2 = {0x6c/255.0, 0x92/255.0, 0x42/255.0}, dry = {0x98/255.0, 0x94/255.0, 0x58/255.0},
                    dark = {0x44/255.0, 0x59/255.0, 0x2f/255.0}, sandC = {0x7a/255.0, 0x7a/255.0, 0x6c/255.0}, dirtC = {0x76/255.0, 0x73/255.0, 0x69/255.0};   // SWISS: grey alpine gravel instead of golden sand / brown earth
    const double y = -z;
    const double t = (std::sin(x*0.05) + std::cos(y*0.07))*0.25 + std::sin(x*0.17 + y*0.11)*0.15 + std::sin(x*0.011 - y*0.013)*0.25 + 0.5 + (fHash(std::floor(x*0.7), std::floor(y*0.7)) - 0.5)*0.06;
    const double tt = clamp01(t);
    C3 c = {c1.r + (c2.r - c1.r)*tt, c1.g + (c2.g - c1.g)*tt, c1.b + (c2.b - c1.b)*tt};
    auto lerp = [&](const C3& o, double a){ c.r += (o.r - c.r)*a; c.g += (o.g - c.g)*a; c.b += (o.b - c.b)*a; };
    double wDk, wLt, wDr; meadowClass(x, z, wDk, wLt, wDr);                  // 60 % green / 20 % light / 10 % dark / 10 % dry grass (see meadowClass)
    double bare = 0;                                                          // how much sand / earth (not grass) this point is
    { const double rc = Road::clearance((float)x, (float)z);                // dusty sand / earth bleeding from the road into the grass, patchy
      if (rc < 10){ const double n = 0.9 + 0.2*fNoise(x/80, z/80), kr = std::min(1.0, (1 - sstep(2, 10, std::max(rc, 0.0))) * 0.35 * n); lerp(sandC, kr); bare = std::max(bare, kr); } }
    if (TRK.on){ trackQ(x, z); if (tkD < TRK_HW + 3) { const double kd = (1 - sstep(TRK_HW - 1.5, TRK_HW + 3, tkD)) * 0.75; lerp(dirtC, kd); bare = std::max(bare, kd); } }   // bare earth beside the track
    const double k = 1 + 0.10 * (std::min(f, FIELD_MAX) / FIELD_AMP);                              // crests catch a little more sun, hollows are a little darker
    const double mr = (c1.r + c2.r) / 2, mg = (c1.g + c2.g) / 2, mb = (c1.b + c2.b) / 2;     // mid grass = this project's base green
    c.r = c.r * k / mr; c.g = c.g * k / mg; c.b = c.b * k / mb;
    { const double w = 1 - bare;                                              // natural meadow green: healthy but not neon (red : green ~ 0.62, some blue kept)
      c.r *= 1 - 0.10*w; c.g *= 1 + 0.20*w; c.b *= 1 - 0.30*w;
      c.r *= 1 + 0.22*wLt*w;  c.g *= 1 + 0.22*wLt*w;  c.b *= 1 - 0.10*wLt*w;                // light, fresh yellow-green (20 %)
      c.r *= 1 - 0.35*wDk*w;  c.g *= 1 - 0.28*wDk*w;  c.b *= 1 - 0.30*wDk*w;                // deep dark green (10 %)
      { const double dk = 0.80*wDr*w; c.r += (2.10 - c.r)*dk; c.g += (1.30 - c.g)*dk; c.b += (0.55 - c.b)*dk; }   // dry straw-coloured grass (10 %)
      { const double sp = fNoise(x/1.7 + 3.3, z/1.7 - 8.1), sp2 = fNoise(x/0.9 - 4.1, z/0.9 + 6.2);               // tiny grass-to-grass variation everywhere
        const double v = (sp - 0.5)*0.10 + (sp2 - 0.5)*0.06; c.r *= 1 + v; c.g *= 1 + v*1.3; c.b *= 1 + v*0.6; }
    }
    {   // rock on steep faces, scree / dry earth on upper slopes, patches of forest floor, snow caps on the very top
        const double sl = latSlope(x, z), n1 = fNoise(x/9 + 4.4, z/9 - 2.2), n2 = fNoise(x/2.5, z/2.5);
        const double ak = alpineBand(x, z) * (1 - sstep(0.45, 0.85, sl));            // alpine meadow band: gentle middle slopes stay lush green
        const double rockA = sstep(0.55, 0.95, sl + (n1 - 0.5)*0.3) * (1 - 0.85*ak);
        const double alt = f + (n1 - 0.5)*5;
        const double high = sstep(14, 30, alt) * (1 - ak);
        const double rr = 0.46 + 0.12*n2, rgc = 0.42 + 0.10*n2, rb = 0.37 + 0.09*n2;
        auto mixc = [&](double R, double G, double B, double a){ c.r += (R/mr*0.5 - c.r)*a; c.g += (G/mg*0.5 - c.g)*a; c.b += (B/mb*0.5 - c.b)*a; };
        mixc(0.40, 0.55, 0.20, high*0.30*(1 - rockA));                      // dry alpine grass
        mixc(rr, rgc, rb, std::min(1.0, rockA*0.8));            // grey-brown rock
        const double snow = sstep(31, 37, alt + (n1 - 0.5)*4) * (1 - sstep(0.30, 0.62, sl));
        mixc(0.93, 0.95, 0.98, snow*0.0);
    }
    r = std::min(1.4, r * c.r); g = std::min(1.4, g * c.g); b = std::min(1.4, b * c.b);
    {   // lake beach: warm golden sand with soft ripples, darker wet sand at the waterline
        const double dn0 = lakeDn(x, z), sk = beachK(x, z) * (1 - sstep(1.03, 1.16, dn0));   // SWISS: only a thin grey-pebble waterline, the rest of the shore stays green meadow
        if (sk > 0){
            const double dn = dn0, n = fNoise(x/7 + 3.1, z/7 - 1.7)*0.6 + fNoise(x/1.6, z/1.6)*0.4;
            double sr = 0.50 + 0.08*n, sg = 0.50 + 0.08*n, sb = 0.46 + 0.07*n;
            const double wet = (1 - sstep(1.0, 1.10, dn)) * 0.45;
            sr *= 1 - wet*0.38; sg *= 1 - wet*0.36; sb *= 1 - wet*0.30;
            r += (sr - r)*sk; g += (sg - g)*sk; b += (sb - b)*sk;
        }
    }
}

// ---------- meshes ----------
struct GMesh { std::vector<float> v; std::vector<uint32_t> idx; };            // vertex = pos(3) colour(3) normal(3)

// hill strip between two lattice rows (inclusive)
static void buildStrip(GMesh& m, int k0, int k1){
    const int W = LNX + 1; const uint32_t base = (uint32_t)(m.v.size() / 9);
    for (int k = k0; k <= k1; k++) for (int i = 0; i <= LNX; i++){
        const double x = LX0 + i*LC, z = LZ0 + k*LC, h = HL[lix(i, k)];
        const double hxm = HL[lix(std::max(i-1, 0), k)], hxp = HL[lix(std::min(i+1, LNX), k)], hzm = HL[lix(i, std::max(k-1, 0))], hzp = HL[lix(i, std::min(k+1, LNZ))];
        const double nx = (hxm - hxp) / (2*LC), nz = (hzm - hzp) / (2*LC), l = std::sqrt(nx*nx + nz*nz + 1);
        double r = 0.300, g = 0.450, b = 0.190; grassColor(x, z, FL[lix(i, k)], r, g, b);
        const float row[9] = {(float)x, (float)h, (float)z, (float)r, (float)g, (float)b, (float)(nx / l), (float)(1 / l), (float)(nz / l)};
        m.v.insert(m.v.end(), row, row + 9);
    }
    for (int k = 0; k < k1 - k0; k++) for (int i = 0; i < LNX; i++){
        const uint32_t a = base + k*W + i, b = a + 1, c = a + W, d = c + 1; const uint32_t t[6] = {a, c, b, b, c, d};
        m.idx.insert(m.idx.end(), t, t + 6);
    }
}

// outer ground: 16 m grid from -2880..2880 around the lattice (the lattice itself is skipped); same colours / shader as the hill strips
static void buildOuter(GMesh& m){
    const int N = 361; const double S = 16.0, X0 = -2880, Z0 = -2880;
    std::vector<float> H((size_t)N*N);
    for (int k = 0; k < N; k++) for (int i = 0; i < N; i++) H[(size_t)k*N + i] = (float)(River::groundH(X0 + i*S, Z0 + k*S) + outerH(X0 + i*S, Z0 + k*S));
    auto hh = [&](int i, int k){ return (double)H[(size_t)std::max(0, std::min(N-1, k))*N + std::max(0, std::min(N-1, i))]; };
    for (int k = 0; k < N; k++) for (int i = 0; i < N; i++){
        const double x = X0 + i*S, z = Z0 + k*S, h = hh(i, k);
        const double nx = (hh(i-1, k) - hh(i+1, k)) / (2*S), nz = (hh(i, k-1) - hh(i, k+1)) / (2*S), l = std::sqrt(nx*nx + nz*nz + 1);
        double r = 0.300, g = 0.450, b = 0.190; grassColor(x, z, outerH(x, z), r, g, b);
        const float row[9] = {(float)x, (float)(h - 0.02), (float)z, (float)r, (float)g, (float)b, (float)(nx / l), (float)(1 / l), (float)(nz / l)};
        m.v.insert(m.v.end(), row, row + 9);
    }
    const int TB = 16;                                                  // cells are emitted in 16 x 16 tiles so the culling chunks are compact blocks of ground
    for (int tk = 0; tk < N - 1; tk += TB) for (int ti = 0; ti < N - 1; ti += TB)
        for (int k = tk; k < std::min(tk + TB, N - 1); k++) for (int i = ti; i < std::min(ti + TB, N - 1); i++){
            const double x0 = X0 + i*S, z0 = Z0 + k*S;
            if (x0 >= LX0 && x0 + S <= LX0 + LNX*LC && z0 >= LZ0 && z0 + S <= LZ0 + LNZ*LC - 8) continue;      // inside the lattice: the river patch (= lattice) is there
            const uint32_t a = (uint32_t)(k*N + i), b = a + 1, c = a + N, d = c + 1; const uint32_t q[6] = {a, c, b, b, c, d};
            m.idx.insert(m.idx.end(), q, q + 6);
        }
}

// height grid of the mountain ring (filled by buildMountains) + bilinear lookup, used to plant the forest on the slopes
static int MTN_NA = 0, MTN_NR = 0; static const double MTN_R0 = 1320, MTN_R1 = 2175; static std::vector<float> MTN_H;
static double mtnH(double x, double z){                       // -1 outside the ring
    if (MTN_H.empty()) return -1;
    const double r = std::hypot(x, z); if (r < MTN_R0 || r >= MTN_R1) return -1;
    double a = std::atan2(z, x); if (a < 0) a += 2*Road::PI;
    double fi = a / (2*Road::PI) * MTN_NA; int i0 = (int)std::floor(fi); fi -= i0; i0 %= MTN_NA; const int i1 = (i0 + 1) % MTN_NA;
    double fj = (r - MTN_R0) / (MTN_R1 - MTN_R0) * MTN_NR; int j0 = std::min((int)std::floor(fj), MTN_NR - 1); fj -= j0;
    const double h00 = MTN_H[(size_t)j0*MTN_NA + i0], h10 = MTN_H[(size_t)j0*MTN_NA + i1], h01 = MTN_H[(size_t)(j0+1)*MTN_NA + i0], h11 = MTN_H[(size_t)(j0+1)*MTN_NA + i1];
    return (h00*(1-fi) + h10*fi)*(1-fj) + (h01*(1-fi) + h11*fi)*fj;
}
// distant mountain ring (one ridged-noise height field: forest foothills -> alpine meadow -> rock -> snow)
static void buildMountains(GMesh& m){
    auto hash = [](double x, double y){ const double h = std::sin(x*127.1 + y*311.7) * 43758.5453; return h - std::floor(h); };
    auto vnoise = [&](double x, double y){ const double ix = std::floor(x), iy = std::floor(y), fx = x - ix, fy = y - iy, u = fx*fx*(3 - 2*fx), v = fy*fy*(3 - 2*fy);
        return (hash(ix, iy)*(1-u) + hash(ix+1, iy)*u)*(1-v) + (hash(ix, iy+1)*(1-u) + hash(ix+1, iy+1)*u)*v; };
    auto fbm = [&](double x, double y, int o){ double a = 0.5, s = 0, f = 1; for (int i = 0; i < o; i++){ s += a*vnoise(x*f, y*f); f *= 2.07; a *= 0.5; } return s; };
    auto ridge = [&](double x, double y, int o){ double a = 0.5, s = 0, f = 1, w = 1; for (int i = 0; i < o; i++){ double n = 1 - std::fabs(vnoise(x*f, y*f)*2 - 1); n *= n; n *= w; w = clamp01(n*1.8); s += n*a; f *= 2.1; a *= 0.5; } return s; };
    const double R0 = MTN_R0, R1 = MTN_R1; const int NA = 1080, NR = 135;                                 // same cell size as before (~12 m round, ~6 m radial)
    const double PEAK = 800;                                                                           // tallest summit (m): steep, sharp Alps
    std::vector<float> pos((size_t)NA*(NR+1)*3), hh((size_t)NA*(NR+1)); double hmax = 1;
    double bhx = 0, bhz = 0; bool bOn = false;                                                          // SNOWY BACKDROP: a tall snow-covered massif straight behind the summit restaurant (the -u direction of the car park)
    if (Terrain::PEAK.on && Terrain::PEAK.padOn){ const double dx = std::cos(gPadA + Road::PI), dz = std::sin(gPadA + Road::PI), b = Terrain::PEAK.x*dx + Terrain::PEAK.z*dz, c = Terrain::PEAK.x*Terrain::PEAK.x + Terrain::PEAK.z*Terrain::PEAK.z - 1750.0*1750.0, q = b*b - c;
        if (q > 0){ const double sd = -b + std::sqrt(q); bhx = Terrain::PEAK.x + dx*sd; bhz = Terrain::PEAK.z + dz*sd; bOn = true; } }
    // SWISS SHAPES: sharp pyramid "horns" (Matterhorn / Weisshorn style) with knife-edge arretes and steep faces, joined by lower ridges and wide glacial valleys.
    //  Each horn is a concave cone (needle-like tip, steep faces) whose outline is modulated by 3-4 ridges around the summit; the distant range stays one height field.
    struct Horn { double x, z, rp, f, ph1, ph2; int k; };
    std::vector<Horn> horns; { const int NH = 27; for (int q = 0; q < NH; q++){
        const double ang = ((double)q + 0.15 + 0.7*hash(q*3.7, 1.3)) / NH * 2*Road::PI, rr = R0 + (R1 - R0)*(0.42 + 0.26*hash(q*5.1, 2.9));
        Horn H; H.x = std::cos(ang)*rr; H.z = std::sin(ang)*rr; H.rp = 300.0 + 360.0*hash(q*2.3, 7.1); H.f = 0.50 + 0.50*hash(q*9.7, 4.4); H.k = 3 + (int)(hash(q*1.9, 8.8)*2.0);
        H.ph1 = hash(q*6.1, 3.3)*6.2831853; H.ph2 = hash(q*4.3, 5.5)*6.2831853; horns.push_back(H); } }
    for (int j = 0; j <= NR; j++) for (int i = 0; i < NA; i++){
        const double a = (double)i / NA * (2*Road::PI), r = R0 + (R1 - R0)*j/NR, x = std::cos(a)*r, z = std::sin(a)*r, t = (double)j / NR;
        const double env = sstep(0, 0.30, t) * (1 - sstep(0.80, 1, t));
        const double mask = sstep(0.30, 0.62, fbm(x*0.0016 + 3.1, z*0.0016 + 7.7, 3));                 // some sectors are taller massifs, others lower passes (never flat)
        const double rg = ridge(x*0.0042 + 11, z*0.0042 + 5, 5), sharp = std::pow(rg, 2.1);            // high power = narrow, knife-edge crests
        const double bw = bOn ? std::exp(-((x - bhx)*(x - bhx) + (z - bhz)*(z - bhz)) / (2*400.0*400.0)) : 0.0;   // 1 at the backdrop, 0 beyond ~900 m
        double hornH = 0;                                                                                  // tallest horn here (0..1)
        for (const Horn& H : horns){ const double dx = x - H.x, dz = z - H.z, d = std::sqrt(dx*dx + dz*dz); if (d > H.rp*1.5) continue;
            const double th = std::atan2(dz, dx), arete = 1.0 + 0.30*std::cos(H.k*th + H.ph1) + 0.12*std::cos((H.k + 2)*th + H.ph2);   // ridges radiating from the summit
            const double prof = 1.0 - d*arete/H.rp; if (prof <= 0) continue;
            const double gul = ridge(x*0.011 + 2.0, z*0.011 + 9.0, 3);                                         // gullies / couloirs and rock ribs running down every face
            const double v = H.f * std::pow(prof, 1.45) * (0.70 + 0.34*rg + 0.28*gul);                                // concave: needle tip, steep faces, flaring foot; rock roughness from the ridged noise
            if (v > hornH) hornH = v; }
        double h = env * (40*fbm(x*0.004, z*0.004, 3) + (0.16 + 0.22*std::max(mask, bw)) * 1000 * sharp + hornH * 1000 + bw * 380 * (0.6 + rg));
        { const double lowK = 1.0 - sstep(0.0, 260.0, h*1.0);                                         // glacial U-valleys: the low ground between the horns is flattened into broad floors with steep walls
          h = h*(1.0 - 0.45*lowK*lowK*sstep(0.10, 0.20, t)) ; }
        h *= sstep(50, 230, std::fabs(River::riverSd(x, z)));                                          // the main river runs through a valley (the tributaries end inside the playable ground)
        const size_t k = (size_t)j*NA + i; hh[k] = (float)h; if (h > hmax) hmax = h;
        pos[k*3] = (float)x; pos[k*3+2] = (float)z;
    }
    const float sc = (float)(PEAK / hmax);                                                              // tallest peak = PEAK metres
    for (size_t k = 0; k < hh.size(); k++){ hh[k] = (float)lakeCarve(pos[k*3], pos[k*3+2], hh[k] * sc); pos[k*3+1] = hh[k] - 0.3f; }
    MTN_NA = NA; MTN_NR = NR; MTN_H = hh;
    std::vector<uint32_t> idx;
    for (int tj = 0; tj < NR; tj += 15) for (int ti = 0; ti < NA; ti += 30)                              // tiles of 15 x 30 cells: compact blocks for frustum culling
        for (int j = tj; j < tj + 15; j++) for (int i = ti; i < ti + 30; i++){
            const uint32_t a = j*NA + i, b = j*NA + (i+1) % NA, c = (j+1)*NA + i, d = (j+1)*NA + (i+1) % NA;
            const uint32_t t[6] = {a, b, c, b, d, c}; idx.insert(idx.end(), t, t + 6);
        }
    std::vector<double> nor((size_t)NA*(NR+1)*3, 0.0);                                                  // computeVertexNormals
    for (size_t f = 0; f < idx.size(); f += 3){
        const float *A = &pos[idx[f]*3], *B = &pos[idx[f+1]*3], *C = &pos[idx[f+2]*3];
        double cb[3] = {C[0]-B[0], C[1]-B[1], C[2]-B[2]}, ab[3] = {A[0]-B[0], A[1]-B[1], A[2]-B[2]};
        double n[3] = {cb[1]*ab[2] - cb[2]*ab[1], cb[2]*ab[0] - cb[0]*ab[2], cb[0]*ab[1] - cb[1]*ab[0]};
        for (int q = 0; q < 3; q++) for (int c = 0; c < 3; c++) nor[idx[f+q]*3 + c] += n[c];
    }
    {   // soften the faceted low-poly look: blend every vertex normal with its 8 neighbours on the (angle x radius) grid, 2 passes (build time only, no runtime cost)
        for (int pass = 0; pass < 2; pass++){
            std::vector<double> sm(nor.size(), 0.0);
            for (int j = 0; j <= NR; j++) for (int i = 0; i < NA; i++){
                double acc[3] = {0, 0, 0};
                for (int dj = -1; dj <= 1; dj++){ const int jj = std::min(std::max(j + dj, 0), NR);
                    for (int di = -1; di <= 1; di++){ const int ii = (i + di + NA) % NA; const double w = (di == 0 ? 2.0 : 1.0) * (dj == 0 ? 2.0 : 1.0);
                        const size_t q = ((size_t)jj*NA + ii)*3; acc[0] += w*nor[q]; acc[1] += w*nor[q+1]; acc[2] += w*nor[q+2]; } }
                const size_t k0 = ((size_t)j*NA + i)*3; sm[k0] = acc[0]; sm[k0+1] = acc[1]; sm[k0+2] = acc[2]; }
            nor.swap(sm); } }
    for (int k = 0; k < NA*(NR+1); k++){
        double l = std::sqrt(nor[k*3]*nor[k*3] + nor[k*3+1]*nor[k*3+1] + nor[k*3+2]*nor[k*3+2]); if (l == 0) l = 1;
        const double s = nor[k*3+1] < 0 ? -1.0 : 1.0; double nxv = nor[k*3]/l*s, nyv = nor[k*3+1]/l*s, nzv = nor[k*3+2]/l*s;
        const double x = pos[k*3], z = pos[k*3+2], h = hh[k], ny = nyv;
        const double n1 = fbm(x*0.03, z*0.03, 3), n2 = vnoise(x*0.22, z*0.22);
        auto mix = [](double A, double B, double mm){ return A + (B - A)*mm; };
        double R = 0.07 + 0.05*n1, G = 0.20 + 0.08*n1, B = 0.07 + 0.03*n1;                              // dark spruce forest on the lower slopes                              // green grass / forest at the foot
        double mm = sstep(95, 150, h + (n1 - 0.5)*70); R = mix(R, 0.30 + 0.07*n2, mm); G = mix(G, 0.45 + 0.06*n2, mm); B = mix(B, 0.15, mm);   // bright alpine pastures above the tree line
        mm = sstep(60, 100, h + (n1 - 0.5)*50) * (1 - sstep(95, 160, h + (n1 - 0.5)*70)) * sstep(0.55, 0.75, n2); R = mix(R, 0.07, mm*0.5); G = mix(G, 0.19, mm*0.5); B = mix(B, 0.08, mm*0.5);   // tongues of forest reaching up the gullies
        mm = std::max(sstep(150, 240, h + (n1 - 0.5)*80), sstep(0.86, 0.62, ny)); R = mix(R, 0.46 + 0.10*n2, mm); G = mix(G, 0.45 + 0.09*n2, mm); B = mix(B, 0.43 + 0.08*n2, mm);   // grey rock / steep faces
        { const double strat = 0.5 + 0.5*std::sin(h*0.28 + n1*7.0 + n2*1.5), bands = 0.84 + 0.16*strat;   // horizontal rock bands (layered limestone) on the cliffs
          const double cl = sstep(0.80, 0.50, ny) * sstep(130, 200, h); R *= 1 - cl*(1 - bands); G *= 1 - cl*(1 - bands); B *= 1 - cl*(1 - bands);
          const double scree = sstep(0.80, 0.90, ny) * (1 - sstep(0.93, 0.99, ny)) * sstep(120, 190, h) * (1 - sstep(260, 330, h)) * sstep(0.45, 0.70, n1);   // pale scree aprons below the cliffs
          R = mix(R, 0.58, scree*0.7); G = mix(G, 0.56, scree*0.7); B = mix(B, 0.53, scree*0.7); }
        {   // GLACIERS: blue-white ice tongues flowing down the gentle high valleys, just below the snow line, with dark crevasse lines across the flow
            const double gl = sstep(165, 215, h + (n1 - 0.5)*40) * (1 - sstep(345, 420, h)) * sstep(0.74, 0.90, ny) * sstep(0.46, 0.60, n1);
            const double crev = sstep(0.80, 0.97, vnoise(x*0.045 + 4.0, z*0.011)) * 0.35;
            R = mix(R, 0.74 - crev*0.5, gl*0.85); G = mix(G, 0.86 - crev*0.4, gl*0.85); B = mix(B, 0.95 - crev*0.15, gl*0.85); }
        // SNOW on the distant ranges, kept simple so it reads right from far away: a ragged snow line (lower on one side of every ridge, as real faces differ in sun),
        // continuous caps on the high gentle slopes, broken patches near the line, and bare dark rock where it is too steep for snow to lie (cliffs, ribs, couloirs).
        {   const double line = 240.0 + (n1 - 0.5)*120.0 - 28.0*nzv + 18.0*(n2 - 0.5);                 // snow-line altitude (m) here
            const double cover = sstep(line, line + 95.0, h);                                              // 0 below the line .. 1 well above it
            const double patchy = sstep(0.30, 0.58, n1 + (n2 - 0.5)*0.35);                                // near the line the snow lies in patches, higher up it is solid
            double snow = cover * (cover > 0.85 ? 1.0 : mix(patchy, 1.0, cover));
            const double steep = sstep(0.80, 0.50, ny + (n2 - 0.5)*0.16);                                  // 0 gentle .. 1 near-vertical: rock shows through, ribs and couloirs
            snow *= 1.0 - 0.92*steep;
            mm = std::min(1.0, snow);
            const double tone = 0.5 + 0.5*n2;                                                              // faint blue-white variation, no glare
            R = mix(R, 0.89 + 0.05*tone, mm); G = mix(G, 0.93 + 0.04*tone, mm); B = mix(B, 0.99, mm); }
        mm = 1 - sstep(0, 4, h); R = mix(R, 0.30, mm); G = mix(G, 0.42, mm); B = mix(B, 0.18, mm);        // foot blends into the meadow
        { const double sk = beachK(x, z) * sstep(0.62, 0.85, ny); if (sk > 0){ R += (0.46 - R)*sk; G += (0.47 - G)*sk; B += (0.42 - B)*sk; } }   // grey pebbles on the lake shore (was sand)
        const float row[9] = {pos[k*3], pos[k*3+1], pos[k*3+2], (float)R, (float)G, (float)B, (float)nxv, (float)nyv, (float)nzv};
        m.v.insert(m.v.end(), row, row + 9);
    }
    m.idx = idx;
}

// dirt strip + its soft earth verges, following the REAL rendered ground triangles (cut into ~2 m rows so the ground never pokes through)
static void buildTrackMeshes(Road::Mesh& strip, Road::Mesh& verge){
    if (!TRK.on) return;
    const int n = TRK.n; const float* P = TRK.pts.data();
    struct Row { double x, z, tx, tz, s; }; std::vector<Row> rows; std::vector<char> rowOk; double sAcc = 0;
    auto tanAt = [&](int i, double& tx, double& tz){ const int a = std::max(i-1, 0), b = std::min(i+1, n-1); tx = P[b*2] - P[a*2]; tz = P[b*2+1] - P[a*2+1]; double tl = std::hypot(tx, tz); if (tl == 0) tl = 1; tx /= tl; tz /= tl; };
    for (int i = 0; i < n - 1; i++){
        const bool ok = TRK.clr[i] > 1.2f && TRK.clr[i+1] > 1.2f; const double segL = TRK.L[i]; const int mm = std::max(1, (int)std::ceil(segL / 2));
        double t0x, t0z, t1x, t1z; tanAt(i, t0x, t0z); tanAt(i + 1, t1x, t1z);
        for (int k = 0; k < mm; k++){
            const double f = (double)k / mm; double tx = t0x + (t1x - t0x)*f, tz = t0z + (t1z - t0z)*f; double tl = std::hypot(tx, tz); if (tl == 0) tl = 1; tx /= tl; tz /= tl;
            rows.push_back({P[i*2] + (P[i*2+2] - P[i*2])*f, P[i*2+1] + (P[i*2+3] - P[i*2+1])*f, tx, tz, sAcc}); rowOk.push_back(ok); sAcc += segL / mm;
        }
    }
    { double tx, tz; tanAt(n - 1, tx, tz); rows.push_back({P[(n-1)*2], P[(n-1)*2+1], tx, tz, sAcc}); }
    auto ribbon = [&](Road::Mesh& out, const std::vector<double>& offs, const std::vector<double>& us, double vLen, double yOff, double vConst = -1){
        const int NC = (int)offs.size(); const uint32_t base = (uint32_t)(out.v.size() / Road::VSTRIDE);
        std::vector<double> pos(rows.size() * NC * 3), nor(rows.size() * NC * 3, 0.0); std::vector<float> uv(rows.size() * NC * 2);
        std::vector<double> kap(rows.size(), 0.0);                                               // signed curvature: the centre of a bend lies on the + side of the offset when > 0
        for (size_t r = 1; r + 1 < rows.size(); r++){
            const double ds = std::hypot(rows[r+1].x - rows[r-1].x, rows[r+1].z - rows[r-1].z); if (ds < 1e-6) continue;
            kap[r] = (rows[r-1].tx * rows[r+1].tz - rows[r-1].tz * rows[r+1].tx) / ds;
        }
        for (size_t r = 0; r < rows.size(); r++) for (int c = 0; c < NC; c++){
            double off = offs[c]; const double kk = kap[r];
            if (off * kk > 0 && std::fabs(off * kk) > 0.8) off = (off > 0 ? 1 : -1) * 0.8 / std::fabs(kk);   // hairpin inside: the shoulder must not fold past the bend centre
            const size_t q = r*NC + c; const double x = rows[r].x - rows[r].tz*off, z = rows[r].z + rows[r].tx*off;
            pos[q*3] = x; pos[q*3+1] = meshH(x, z) + yOff; pos[q*3+2] = z; uv[q*2] = (float)us[c]; uv[q*2+1] = (float)(vConst >= 0 ? vConst : rows[r].s / vLen);
        }
        std::vector<uint32_t> ix;
        for (size_t r = 0; r + 1 < rows.size(); r++) if (rowOk[r]) for (int c = 0; c < NC - 1; c++){
            const uint32_t A = (uint32_t)(r*NC + c), B = A + 1, C = (uint32_t)((r+1)*NC + c), D = C + 1; const uint32_t t[6] = {A, B, C, B, D, C}; ix.insert(ix.end(), t, t + 6);
        }
        for (size_t f = 0; f < ix.size(); f += 3){
            const double *A = &pos[ix[f]*3], *B = &pos[ix[f+1]*3], *C = &pos[ix[f+2]*3];
            double cb[3] = {C[0]-B[0], C[1]-B[1], C[2]-B[2]}, ab[3] = {A[0]-B[0], A[1]-B[1], A[2]-B[2]};
            double nn[3] = {cb[1]*ab[2] - cb[2]*ab[1], cb[2]*ab[0] - cb[0]*ab[2], cb[0]*ab[1] - cb[1]*ab[0]};
            for (int q = 0; q < 3; q++) for (int c = 0; c < 3; c++) nor[ix[f+q]*3 + c] += nn[c];
        }
        for (size_t q = 0; q < rows.size() * NC; q++){
            double l = std::sqrt(nor[q*3]*nor[q*3] + nor[q*3+1]*nor[q*3+1] + nor[q*3+2]*nor[q*3+2]); if (l == 0) l = 1;
            const double s = nor[q*3+1] < 0 ? -1.0 : 1.0;                                     // always face up
            const float row[Road::VSTRIDE] = {(float)pos[q*3], (float)pos[q*3+1], (float)pos[q*3+2], uv[q*2], uv[q*2+1], (float)(nor[q*3]/l*s), (float)(nor[q*3+1]/l*s), (float)(nor[q*3+2]/l*s), (float)rows[q / NC].s, (float)std::fabs(kap[q / NC])};
            out.v.insert(out.v.end(), row, row + Road::VSTRIDE);
        }
        for (uint32_t i : ix) out.idx.push_back(base + i);
    };
    const double hw = TRK_W / 2; const double HC[5] = {-1, -0.5, 0, 0.5, 1};
    std::vector<double> offs, us; for (double s : HC){ offs.push_back(s*hw); us.push_back((s + 1) / 2); }
    ribbon(strip, offs, offs, 8, 0.14, hw);                                                         // the track itself: same material and tile (road width x 8 m) as the wide dirt road
    const double DS[6] = {-1.5, 0, 1.5, 3.5, 5.5, 8}; auto SH_U = [](double d){ return (d + 1.5) / (8 + 1.5); };
    offs.clear(); us.clear(); for (double d : DS){ offs.push_back(hw + d); us.push_back(SH_U(d)); }
    ribbon(verge, offs, us, 2.5, 0.15);                                                       // right verge (u: 0 at the track, 1 at the outer edge)
    offs.clear(); us.clear(); for (int i = 5; i >= 0; i--){ offs.push_back(-(hw + DS[i])); us.push_back(SH_U(DS[i])); }
    ribbon(verge, offs, us, 2.5, 0.15);                                                       // left verge, mirrored
}

// hill height / grass tint for the river patch (it shares the lattice, so the hills line up exactly with the strips next to it)
static double patchFieldH(double x, double z){
    const double fx = (x - LX0) / LC, fz = (z - LZ0) / LC;
    if (fx < -0.01 || fz < -0.01 || fx > LNX + 0.01 || fz > LNZ + 0.01) return 0;
    return FL[lix((int)std::lround(fx), (int)std::lround(fz))];
}

// pick a spot just outside the playable square (far from roads and the river), build the water disc + the mountain skyline seen from it
static std::vector<float> LAKE_V; static std::vector<uint32_t> LAKE_I; static std::vector<uint8_t> LAKE_SKY; static const int LAKE_SKY_N = 720;
static void chooseLake(){ gLake.on = true; gLake.x = 0.0; gLake.z = -412.0; gLake.r = 88; gLake.y = 0; gLake.ce = 1.6; }   // the lake of the map: inside the valley, north of the church village
static void buildLake(){
    if (!gLake.on) return;
    const int NS = 48, NRG = 8; const double PI2 = 2 * Road::PI;
    for (int i = 0; i <= NRG; i++){
        const double dn = (double)i / NRG * 1.15, dep = dn <= 1 ? LAKE_DEPTH * (1 - dn*dn) : -(dn - 1) * 4;      // depth param for the water shader (0 at the shore)
        for (int j = 0; j < NS; j++){ const double a = (double)j / NS * PI2;
            const float row[4] = {(float)(gLake.x + std::cos(a) * dn * gLake.r), (float)gLake.y, (float)(gLake.z + std::sin(a) * dn * gLake.r), (float)dep};
            LAKE_V.insert(LAKE_V.end(), row, row + 4); }
    }
    for (int i = 0; i < NRG; i++) for (int j = 0; j < NS; j++){
        const uint32_t a = i*NS + j, b = i*NS + (j+1) % NS, c = (i+1)*NS + j, d = (i+1)*NS + (j+1) % NS; const uint32_t t[6] = {a, c, b, b, c, d}; LAKE_I.insert(LAKE_I.end(), t, t + 6);
    }
    // skyline: for every azimuth the highest mountain elevation seen from the lake centre (the shader mirrors it as the reflection)
    LAKE_SKY.assign((size_t)LAKE_SKY_N * 4, 0); std::vector<float> e(LAKE_SKY_N, 0.f), cr(LAKE_SKY_N, 0.f);
    for (int b = 0; b < LAKE_SKY_N; b++){
        const double az = ((b + 0.5) / LAKE_SKY_N - 0.5) * PI2, cx = std::cos(az), cz = std::sin(az);
        for (double d = 60; d < 2900; d += (d < 400 ? 6.0 : 14.0)){
            double h = mtnH(gLake.x + cx*d, gLake.z + cz*d); if (h < 0) continue;
            const float el = (float)std::atan2(h - gLake.y, d); if (el > e[b]){ e[b] = el; cr[b] = (float)h; }
        }
    }
    for (int pass = 0; pass < 2; pass++){ std::vector<float> e2 = e, c2 = cr;
        for (int b = 0; b < LAKE_SKY_N; b++){ const int l = (b + LAKE_SKY_N - 1) % LAKE_SKY_N, r = (b + 1) % LAKE_SKY_N;
            e2[b] = std::max(e[b], 0.25f*e[l] + 0.5f*e[b] + 0.25f*e[r]); c2[b] = std::max(cr[b], 0.25f*cr[l] + 0.5f*cr[b] + 0.25f*cr[r]); }
        e = e2; cr = c2; }
    for (int b = 0; b < LAKE_SKY_N; b++){ LAKE_SKY[b*4] = (uint8_t)std::min(255.f, e[b] * 255.f); LAKE_SKY[b*4+1] = (uint8_t)std::min(255.f, cr[b] / 850.f * 255.f); LAKE_SKY[b*4+2] = 0; LAKE_SKY[b*4+3] = 255; }
}

// ---------- init ----------
struct Meshes { GMesh southHills, northHills, mountains, outer; };
static Meshes gMeshes;

static void setSeed(uint32_t s){
    std::mt19937 r(s); std::uniform_real_distribution<double> U(0.0, 500.0);
    for (int i = 0; i < 4; i++) FSEED[i] = U(r);                                              // different hills on every load
    River::FSEED0 = FSEED[0];
}
// needs Road::init() done (road grid + river). Call before RoadGL::init / TreeGL::init / BridgeGL::init.
static void init(uint32_t seed){
    setSeed(seed); gReady = true;
    std::mt19937 rng(seed ^ 0x9e3779b9u);
    buildPeak(rng);                                                                          // dirt track (terrain along it is graded from now on)
    chooseLake();
    HL.assign((size_t)(LNX + 1) * (LNZ + 1), 0.f); FL = HL;
    {   // the ground heights of the whole lattice (~200 000 points): the slowest part of the start-up -> computed by several threads, one set of rows each
        const unsigned hw = std::thread::hardware_concurrency(); const int nT = (int)std::max(1u, std::min(6u, hw ? hw : 2u));
        auto rows = [&](int t0){ for (int k = t0; k <= LNZ; k += nT) for (int i = 0; i <= LNX; i++){
            const double x = LX0 + i*LC, z = LZ0 + k*LC, f = fieldH(x, z);
            FL[lix(i, k)] = (float)f; HL[lix(i, k)] = (float)(River::groundH(x, z) + f); } };
        std::vector<std::thread> th; for (int t = 1; t < nT; t++) th.emplace_back(rows, t); rows(0); for (std::thread& x : th) x.join();
    }
    River::gHooks.fieldH = patchFieldH; River::gHooks.grass = grassColor;
    // (no separate hill strips: the river patch carries the hills over the whole lattice)
    // lake bowl first: the mountain foot and the outer ground are carved around it
    buildMountains(gMeshes.mountains);
    buildLake();
    buildOuter(gMeshes.outer);
    buildTrackMeshes(Road::gNet.trk, Road::gNet.trkV);
}

} // namespace Terrain
