// Sunny Drift - road network: a web of roads (junction to junction) over the whole valley, plus the same three.js CatmullRom / buildStrip geometry as the HTML game (pure C++, no OpenGL).
//  * the road web = a table of junction nodes + a table of edges (each edge is an S-bend Catmull-Rom curve from node to node, T / X junctions with flared kerb returns)
//  * roadClearance() / surfaceAt() are used by the trees and by the car's grip
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <unordered_map>
#include <vector>
#include "river.h"

namespace Road {
static float gPark[3] = {0.f, 0.f, 0.f};   // PARKING_AREA on the hill summit: centre x, z and the radius of the asphalt ring (0 = none); the road shader paints the bays


const double ROAD_SURF = 0.08;                        // height of the road surface
const double PI = 3.14159265358979323846;

struct V3 { double x = 0, y = 0, z = 0; };
static inline V3 vsub(const V3& a, const V3& b){ return {a.x - b.x, a.y - b.y, a.z - b.z}; }
static inline double dist2(const V3& a, const V3& b){ V3 d = vsub(a, b); return d.x*d.x + d.y*d.y + d.z*d.z; }
static inline double jsRound(double v){ return std::floor(v + 0.5); }          // JS Math.round

// ---------- three.js CatmullRomCurve3 (centripetal) ----------
struct Curve {
    std::vector<V3> pts; bool closed = true, open = false; double hw = 0;
    double rA = 0, rB = 0;                             // connector only: half-width of the ring road it joins at its start / end (T-junction flare), 0 = none
    std::vector<double> lens;                          // cumulative arc lengths, 200 divisions (Curve.getLengths)

    static double cr(double x0, double x1, double x2, double x3, double dt0, double dt1, double dt2, double t){
        double t1 = (x1 - x0) / dt0 - (x2 - x0) / (dt0 + dt1) + (x2 - x1) / dt1;
        double t2 = (x2 - x1) / dt1 - (x3 - x1) / (dt1 + dt2) + (x3 - x2) / dt2;
        t1 *= dt1; t2 *= dt1;
        double c0 = x1, c1 = t1, c2 = -3*x1 + 3*x2 - 2*t1 - t2, c3 = 2*x1 - 2*x2 + t1 + t2;
        return c0 + c1*t + c2*t*t + c3*t*t*t;
    }
    V3 getPoint(double t) const {
        const long l = (long)pts.size();
        double p = (double)(l - (closed ? 0 : 1)) * t;
        long ip = (long)std::floor(p); double w = p - (double)ip;
        if (closed){ if (!(ip > 0)) ip += (long)(std::floor(std::fabs((double)ip) / (double)l) + 1) * l; }
        else if (w == 0 && ip == l - 1){ ip = l - 2; w = 1; }
        V3 p0, p3;
        if (closed || ip > 0) p0 = pts[(ip - 1) % l];
        else { const V3 &a = pts[0], &b = pts[1]; p0 = {2*a.x - b.x, 2*a.y - b.y, 2*a.z - b.z}; }
        const V3 p1 = pts[ip % l], p2 = pts[(ip + 1) % l];
        if (closed || ip + 2 < l) p3 = pts[(ip + 2) % l];
        else { const V3 &a = pts[l-1], &b = pts[l-2]; p3 = {2*a.x - b.x, 2*a.y - b.y, 2*a.z - b.z}; }
        double dt0 = std::pow(dist2(p0, p1), 0.25), dt1 = std::pow(dist2(p1, p2), 0.25), dt2 = std::pow(dist2(p2, p3), 0.25);
        if (dt1 < 1e-4) dt1 = 1.0;
        if (dt0 < 1e-4) dt0 = dt1;
        if (dt2 < 1e-4) dt2 = dt1;
        return { cr(p0.x, p1.x, p2.x, p3.x, dt0, dt1, dt2, w), cr(p0.y, p1.y, p2.y, p3.y, dt0, dt1, dt2, w), cr(p0.z, p1.z, p2.z, p3.z, dt0, dt1, dt2, w) };
    }
    void build(){
        const int DIV = 200; lens.assign(1, 0.0); V3 last = getPoint(0); double sum = 0;
        for (int p = 1; p <= DIV; p++){ V3 c = getPoint((double)p / DIV); sum += std::sqrt(dist2(c, last)); lens.push_back(sum); last = c; }
    }
    double length() const { return lens.back(); }
    double utoT(double u) const {                      // Curve.getUtoTmapping
        const long il = (long)lens.size(); double target = u * lens[il - 1];
        long low = 0, high = il - 1, i = 0;
        while (low <= high){
            i = low + (high - low) / 2; double cmp = lens[i] - target;
            if (cmp < 0) low = i + 1; else if (cmp > 0) high = i - 1; else { high = i; break; }
        }
        i = high < 0 ? 0 : high;
        if (lens[i] == target) return (double)i / (double)(il - 1);
        double before = lens[i], after = lens[i + 1];
        return ((double)i + (target - before) / (after - before)) / (double)(il - 1);
    }
    V3 getPointAt(double u) const { return getPoint(utoT(u)); }
    V3 getTangent(double t) const {
        const double d = 0.0001; double t1 = t - d, t2 = t + d; if (t1 < 0) t1 = 0; if (t2 > 1) t2 = 1;
        V3 a = getPoint(t1), b = getPoint(t2), v = vsub(b, a); double l = std::sqrt(v.x*v.x + v.y*v.y + v.z*v.z); if (l == 0) l = 1;
        return {v.x / l, v.y / l, v.z / l};
    }
    V3 getTangentAt(double u) const { return getTangent(utoT(u)); }
};


// direction the valley / river runs in (angle used by the terrain code): fixed, the river is hand-placed in river.h
static double pickRiverAngle(){ return PI / 2; }

// ---------- strip meshes (buildStrip in the HTML). vertex = pos(3) uv(2) normal(3) along(1) curv(1) = 10 floats ----------
//  along = metres travelled along the road (lets the shader paint dashed centre lines), curv = 1 / bend radius (solid line in tight bends).
struct Mesh { std::vector<float> v; std::vector<uint32_t> idx; };
static const int VSTRIDE = 10;
struct Prof { double o, y, u; };

// ts = sample positions along the curve; widen(t) = extra half width at t (junction flare; shifts every profile point outwards, asphalt uv with it)
static void buildStrip(Mesh& m, const Curve& curve, const std::vector<double>& ts, const std::vector<Prof>& prof, int vRepeat, double t0, double t1, bool closed, double vConst = -1,
                       double (*widen)(const Curve&, double) = nullptr){
    const int N = (int)ts.size() - 1, P = (int)prof.size(); const uint32_t base = (uint32_t)(m.v.size() / VSTRIDE); const double len = curve.length();
    const int nv = (N + 1) * P; std::vector<double> pos(nv * 3), nor(nv * 3, 0.0), aux(nv * 2); std::vector<float> uv(nv * 2);
    for (int i = 0; i <= N; i++){
        auto wr = [&](double q){ return closed ? std::fmod(std::fmod(q, 1.0) + 1.0, 1.0) : std::min(std::max(q, 0.0), 0.99999); };      // open roads never wrap round
        double t = wr(ts[i]);
        V3 p = curve.getPointAt(t), tan = curve.getTangentAt(t);
        double nl = std::hypot(tan.x, tan.z); if (nl == 0) nl = 1; double ux = -tan.z / nl, uz = tan.x / nl;
        const double d = 1.5 / len; V3 ta = curve.getTangentAt(wr(t - d)), tb = curve.getTangentAt(wr(t + d));
        const double kap = std::fabs(std::atan2(ta.x*tb.z - ta.z*tb.x, ta.x*tb.x + ta.z*tb.z)) / 3.0;
        const double ex = widen ? widen(curve, t) : 0.0, vr = (ts[i] - t0) / (t1 - t0) * vRepeat;
        for (int j = 0; j < P; j++){
            int k = i * P + j; const double o = prof[j].o + (prof[j].o < 0 ? -ex : ex);
            pos[k*3] = p.x + ux * o; pos[k*3+1] = prof[j].y; pos[k*3+2] = p.z + uz * o;
            uv[k*2] = (float)(vConst >= 0 ? prof[j].u + (prof[j].u < 0 ? -ex : ex) : prof[j].u); uv[k*2+1] = (float)(vConst >= 0 ? vConst + ex : vr);
            aux[k*2] = (double)(ts[i]) * len; aux[k*2+1] = kap;
        }
    }
    std::vector<uint32_t> idx;
    for (int i = 0; i < N; i++) for (int j = 0; j < P - 1; j++){
        uint32_t a = i*P + j, b = (i+1)*P + j; uint32_t t[6] = {a, b, a+1, a+1, b, b+1};
        idx.insert(idx.end(), t, t + 6);
    }
    for (size_t f = 0; f < idx.size(); f += 3){                                    // computeVertexNormals
        const double *A = &pos[idx[f]*3], *B = &pos[idx[f+1]*3], *C = &pos[idx[f+2]*3];
        double cb[3] = {C[0]-B[0], C[1]-B[1], C[2]-B[2]}, ab[3] = {A[0]-B[0], A[1]-B[1], A[2]-B[2]};
        double n[3] = {cb[1]*ab[2] - cb[2]*ab[1], cb[2]*ab[0] - cb[0]*ab[2], cb[0]*ab[1] - cb[1]*ab[0]};
        for (int q = 0; q < 3; q++) for (int c = 0; c < 3; c++) nor[idx[f+q]*3 + c] += n[c];
    }
    for (int j = 0; closed && j < P; j++){                                          // seamless shading where the loop closes
        int a = j, b = N*P + j;
        for (int c = 0; c < 3; c++){ double s = nor[a*3+c] + nor[b*3+c]; nor[a*3+c] = nor[b*3+c] = s; }
    }
    for (int k = 0; k < nv; k++){
        double l = std::sqrt(nor[k*3]*nor[k*3] + nor[k*3+1]*nor[k*3+1] + nor[k*3+2]*nor[k*3+2]); if (l == 0) l = 1;
        double s = nor[k*3+1] < 0 ? -1.0 : 1.0;                                     // always face up
        for (int c = 0; c < 3; c++) nor[k*3+c] = nor[k*3+c] / l * s;
        float row[VSTRIDE] = {(float)pos[k*3], (float)pos[k*3+1], (float)pos[k*3+2], uv[k*2], uv[k*2+1], (float)nor[k*3], (float)nor[k*3+1], (float)nor[k*3+2], (float)aux[k*2], (float)aux[k*2+1]};
        m.v.insert(m.v.end(), row, row + VSTRIDE);
    }
    for (uint32_t i : idx) m.idx.push_back(base + i);
}


// ---------- the road web ----------
//  Nodes (junctions = villages / crossroads) are scattered irregularly over the whole valley and joined like a real road map (each road links neighbouring junctions, nothing crosses); every edge joins two nodes. The big hole in the south-east is left empty on purpose: the mountain (Terrain::buildPeak) stands there.
//  No road runs along a river: every river crossing is short and nearly at right angles, so each gets an ordinary bridge (bridge.h).
static const double NODES[][2] = {
{-155,-476},
{-649,-543},
{957,-357},
{-4,402},
{365,-215},
{-995,306},
{-439,494},
{475,-672},
{-339,170},
{-124,715},
{-59,-161},
{-781,-161},
{977,92},
{244,687},
{191,71},
{65,-786},
{-1098,-138},
{-423,-279},
{634,-392},
{-773,540},
{-361,-746},
{213,-494},
{533,116},
};
static const int NODE_N = (int)(sizeof(NODES) / sizeof(NODES[0]));
// a, b = node indices, a1 / a2 / a3 = amplitude (m) of the three sideways bends of the edge
static const double EDGES[][5] = {
{0,10,9.7,3.1,1.7},
{0,15,17.4,6.8,-2.0},
{0,17,-1.8,6.5,0.2},
{0,20,-4.2,-4.4,0.1},
{0,21,6.6,-4.2,-1.2},
{1,11,-4.9,-0.1,2.4},
{1,17,7.7,3.7,-2.3},
{1,20,-17.3,-1.4,-2.3},
{2,12,3.1,-9.0,-3.0},
{2,18,10.5,-4.6,-0.6},
{3,6,-16.6,-7.9,0.3},
{3,8,-0.3,-5.5,-2.5},
{3,9,-10.0,-7.3,-1.0},
{3,13,-2.8,-6.2,0.7},
{3,14,10.3,-7.2,1.5},
{4,10,8.7,-7.4,1.5},
{4,14,6.0,6.5,1.9},
{4,18,14.9,-1.3,-1.4},
{4,21,11.8,1.4,-0.9},
{4,22,11.9,0.6,-0.3},
{5,16,20.9,5.8,-0.7},
{5,19,4.7,6.2,0.0},
{6,8,-6.9,-3.2,2.1},
{6,9,6.7,6.6,0.1},
{6,19,10.0,-5.8,-1.3},
{7,15,-7.5,1.5,-0.7},
{7,18,-9.6,5.7,-1.0},
{7,21,-1.4,2.0,-1.1},
{8,10,20.0,2.1,2.4},
{8,11,15.4,-0.4,4.2},
{8,14,-14.4,6.5,-3.0},
{8,17,-11.5,-7.1,-0.6},
{9,13,7.8,7.7,2.3},
{10,14,-11.2,3.6,-2.2},
{10,17,12.2,-2.7,-2.1},
{10,21,-12.6,-0.6,2.9},
{11,16,12.3,5.6,1.5},
{11,17,-0.6,-7.7,-2.5},
{12,22,-17.3,8.4,-2.2},
{14,22,-12.3,-1.8,-1.1},
{15,20,5.2,-1.5,1.9},
{15,21,15.8,-0.8,-1.3},
{17,20,13.4,-10.3,-2.5},
{18,21,7.7,-6.0,-1.7},
};
static const int START_EDGE = 15;                                   // the start line: middle of a long dry road near the centre, far from every bridge
static const int EDGE_N = (int)(sizeof(EDGES) / sizeof(EDGES[0]));

struct Net {
    std::vector<Curve> roads;                              // every road of the web (open curves, junction to junction)
    std::vector<Mesh> roadM;                               // one asphalt ribbon per road (paint stops 9 m before each end = the junction mouths)
    Mesh road, verge, trk, trkV;                           // road = bridge decks only (bridge.h appends there); verge = sand shoulders of all roads; trk / trkV = hill road (filled by Terrain)
    std::unordered_map<long long, std::vector<float>> grid;  // road centre samples (x, z, halfwidth) per 24 m cell
    double riverAng = 0; int startRoad = 0; bool ready = false;
};
static Net gNet;
static const int RG = 24;
static inline long long cellKey(long cx, long cz){ return (long long)(cx + 100000) * 200003LL + (cz + 100000); }
static std::vector<const Curve*> all(){ std::vector<const Curve*> v; for (const Curve& c : gNet.roads) v.push_back(&c); return v; }

// edge between two junctions: straight chord + two soft sideways bends (both vanish, with their slope, at the ends, so every road leaves a junction exactly along the chord)
static Curve makeEdge(const double* A, const double* B, double a1, double a2, double a3){
    const int K = 40; const double dx = B[0] - A[0], dz = B[1] - A[1], dl = std::hypot(dx, dz), px = -dz / dl, pz = dx / dl;
    Curve c; c.closed = false; c.open = true;
    c.hw = dl > 430.0 ? 4.8 : 3.55;             // broad two-lane valley road; narrower village / farm lanes
    for (int i = 0; i <= K; i++){ const double t = (double)i / K, s = std::sin(PI * t);
        // A little more terrain-following drift than a straight chord, while both ends still meet each junction cleanly.
        const double off = 1.28 * (a1 * std::sin(2*PI*t) * s + a2 * std::sin(3*PI*t) * s + a3 * std::sin(4*PI*t) * s);
        c.pts.push_back({A[0] + dx*t + px*off, ROAD_SURF, A[1] + dz*t + pz*off}); }
    c.build(); return c;
}
// T / X junction fillet: the road widens towards its end along a circular arc of radius FLARE (a real kerb return). Extra half width at arc length d from the start of the road.
static const double FLARE = 6.0;
static double connExtra(const Curve& c, double d){
    auto f = [](double dd, double rh){
        if (rh <= 0) return 0.0; const double x = rh + FLARE - dd;            // distance from the arc's centre, along the road
        if (x >= FLARE) return FLARE; if (x <= 0) return 0.0;
        return FLARE - std::sqrt(FLARE * FLARE - x * x);
    };
    return std::max(f(d, c.rA), f(c.length() - d, c.rB));
}
static double connWiden(const Curve& c, double t){ return connExtra(c, t * c.length()); }
// samples along the road (curve parameter t0..t1): 1.5 m, but every 0.3 m inside the fillets where the edge sweeps out quickly
static std::vector<double> connT(const Curve& c, double t0, double t1){
    const double len = c.length(); std::vector<double> ts; double s = t0 * len; const double e = t1 * len;
    while (s < e - 1e-6){ ts.push_back(s / len); const bool fine = s < c.rA + FLARE + 1.0 || s > len - c.rB - FLARE - 1.0; s += fine ? 0.3 : 1.5; }
    ts.push_back(t1); return ts;
}

// ribbon + sand verges of one road. No road / sand across a river: the bridge deck is the roadway there (same sampling as the old ring roads).
static void addEdge(Mesh& road, Mesh& vergeM, const Curve& c){
    const double len = c.length(), hw = c.hw, T1 = 0.99999;
    const int SS = (int)std::ceil(len / 1.2); std::vector<char> inRv(SS + 1);
    for (int i = 0; i <= SS; i++){ const V3 q = c.getPointAt(std::min((double)i / SS, T1)); inRv[i] = std::fabs(River::riverSd(q.x, q.z)) < River::RIVER_WALL + 5; }
    struct Run { double a, b; }; std::vector<Run> runs;
    for (int i = 0; i <= SS; ){ if (inRv[i]){ i++; continue; } int j = i; while (j <= SS && !inRv[j]) j++; runs.push_back({(double)i / SS, j > SS ? T1 : std::min((double)j / SS, T1)}); i = j; }
    static const double SP[4][2] = {{-1.5, 0.075}, {0, 0.08}, {3.5, 0.06}, {8, 0.045}};
    const double endT = std::min(0.35, c.hw * 1.5 / len);                                      // verges stop short of the junctions
    for (const Run& r : runs){
        if ((r.b - r.a) * len < 2.0) continue;
        buildStrip(road, c, connT(c, r.a, r.b), {{hw, ROAD_SURF, hw}, {-hw, ROAD_SURF, -hw}}, std::max(1, (int)jsRound((r.b - r.a) * len / 8)), r.a, r.b, false, hw, connWiden);
        const double s0 = std::max(r.a, endT), s1 = std::min(r.b, 1 - endT); if ((s1 - s0) * len < 2.0) continue;
        for (int sd : {1, -1}){
            std::vector<Prof> sh; for (auto& q : SP) sh.push_back({sd * (hw + q[0]), q[1], (q[0] + 1.5) / (8 + 1.5)});
            if (sd > 0) std::reverse(sh.begin(), sh.end());
            buildStrip(vergeM, c, connT(c, s0, s1), sh, std::max(1, (int)jsRound((s1 - s0) * len / 2.5)), s0, s1, false, -1, connWiden);
        }
    }
}

static void init(){
    Net& n = gNet; if (n.ready) return;
    River::init();
    n.riverAng = pickRiverAngle();
    n.roads.reserve(EDGE_N);
    for (int e = 0; e < EDGE_N; e++){
        const int a = (int)EDGES[e][0], b = (int)EDGES[e][1];
        Curve c = makeEdge(NODES[a], NODES[b], EDGES[e][2], EDGES[e][3], EDGES[e][4]); c.rA = c.rB = c.hw;      // T / X junction flares at both ends
        if (e == START_EDGE) n.startRoad = e;
        n.roads.push_back(c);
    }
    n.roadM.resize(n.roads.size());
    for (size_t e = 0; e < n.roads.size(); e++) addEdge(n.roadM[e], n.verge, n.roads[e]);
    // grid of centre-line samples -> distance from the nearest road EDGE
    for (const Curve& cv : n.roads){
        const int cnt = (int)std::ceil(cv.length() / 2);
        for (int i = 0; i <= cnt; i++){
            const double u = std::min((double)i / cnt, 0.99999); V3 p = cv.getPointAt(u);
            auto& l = n.grid[cellKey((long)std::floor(p.x / RG), (long)std::floor(p.z / RG))];
            l.push_back((float)p.x); l.push_back((float)p.z);
            l.push_back((float)(cv.hw + connExtra(cv, u * cv.length())));                          // flared junction mouths count as road
        }
    }
    n.ready = true;
}

// distance from the nearest road EDGE (negative = on the road)
static float clearance(float x, float z){
    long cx = (long)std::floor(x / RG), cz = (long)std::floor(z / RG); float best = 1e9f;
    for (int i = -1; i <= 1; i++) for (int j = -1; j <= 1; j++){
        auto it = gNet.grid.find(cellKey(cx + i, cz + j)); if (it == gNet.grid.end()) continue;
        const std::vector<float>& l = it->second;
        for (size_t k = 0; k < l.size(); k += 3){ float dx = x - l[k], dz = z - l[k+1], d = std::sqrt(dx*dx + dz*dz) - l[k+2]; if (d < best) best = d; }
    }
    return best;
}

// grip / drag / ride height under the tyres (surfaceAt in the HTML): tarmac-like road, softer verge, grass
struct SurfaceInfo { double mu, rr, rideY; };
static SurfaceInfo surfaceAt(float x, float z){
    double c = clearance(x, z), t = std::min(std::max((c - 0.8) / 2.2, 0.0), 1.0), g = t*t*(3 - 2*t);
    double u = std::min(std::max((c - 0.3) / 2.4, 0.0), 1.0);
    return {1.15 - 0.3 * g, 0.028 + 0.06 * g, ROAD_SURF * (1 - u*u*(3 - 2*u))};
}

// where the car starts: on the road web at the start line, facing along the road
static void startPose(double& x, double& z, double& heading){
    const Curve& c = gNet.roads[gNet.startRoad]; V3 p = c.getPointAt(0.5), t = c.getTangentAt(0.5); x = p.x; z = p.z; heading = std::atan2(t.x, t.z);
}

} // namespace Road
