// Sunny Drift - rolling hills, distant mountains and the dirt track: C++ port of the HTML terrain blocks (pure C++, no OpenGL).
//  * fieldNoise / fieldMask / fieldH   = "Gentle natural rolling terrain on the green fields" (hills + mountain massifs up to 25 m,
//                                        flat next to the roads and the river, graded along the dirt track)
//  * buildTrack / trackQ                = "Narrow dirt track winding over the mountains" (centre line, graded height, nearest distance)
//  * distant mountain ring              = "Distant mountain ranges" (ridged noise height field, forest -> meadow -> rock -> snow)
//  * the ground mesh heights/colours    = "Apply the rolling terrain to the grass mesh"; carGroundH / meshH = what the tyres touch
//  Like the HTML (FSEED, Math.random) the hills and the track are different on every launch: call setSeed() before anything else.
//  Not part of this port (the C++ game has no sea / pier / houses): coast and pier masks of the HTML are reduced to the coast
//  distance that keeps the hills away from the island edge.
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <random>
#include <unordered_map>
#include <vector>
#include "road.h"

namespace Terrain {

using River::sstep;
static const double FIELD_MAX = 52, FIELD_AMP = 31;            // random hills / mountains rise up to 25 m
static double FSEED[4] = {0.5, 100, 200, 300};
static bool gReady = false;                                     // FIELD_READY in the HTML

static inline double clamp01(double v){ return v < 0 ? 0 : v > 1 ? 1 : v; }

// ---------- noise (fHash / fNoise / fFbm) ----------
static inline double fHash(double x, double y){ const double h = std::sin(x*127.1 + y*311.7 + FSEED[0]*0.37) * 43758.5453; return h - std::floor(h); }
static double fNoise(double x, double y){
    const double ix = std::floor(x), iy = std::floor(y), fx = x - ix, fy = y - iy, u = fx*fx*(3 - 2*fx), v = fy*fy*(3 - 2*fy);
    return (fHash(ix, iy)*(1-u) + fHash(ix+1, iy)*u)*(1-v) + (fHash(ix, iy+1)*(1-u) + fHash(ix+1, iy+1)*u)*v;
}
static double fFbm(double x, double y, int o){
    double a = 0.5, s = 0, f = 1, n = 0;
    for (int i = 0; i < o; i++){ s += a * fNoise(x*f + i*17.3, y*f - i*9.1); n += a; f *= 2.03; a *= 0.5; }
    return s / n;
}

// ---------- island coast (only used to keep the hills away from the edge of the land) ----------
static const double PI_2 = 1.57079632679489661923;
static const double COAST0 = 900;
static inline double coastR(double a){ return COAST0 + std::sin(a*2 + 0.7)*34 + std::cos(a*3 - 1.1)*22 + std::sin(a*5 + 2.0)*10; }
static inline double coastDist(double x, double z){ return std::hypot(x, z) - coastR(std::atan2(z, x)); }     // < 0 = inland

// like Road::clearance but looks 4 cells (96 m) around, so the terrain fade is smooth
static double fieldClear(double x, double z){
    const long cx = (long)std::floor(x / Road::RG), cz = (long)std::floor(z / Road::RG); double best = 1e9;
    for (int i = -4; i <= 4; i++) for (int j = -4; j <= 4; j++){
        auto it = Road::gNet.grid.find(Road::cellKey(cx + i, cz + j)); if (it == Road::gNet.grid.end()) continue;
        const std::vector<float>& l = it->second;
        for (size_t k = 0; k < l.size(); k += 3){ const double dx = x - l[k], dz = z - l[k+1], d = std::sqrt(dx*dx + dz*dz) - l[k+2]; if (d < best) best = d; }
    }
    return best;
}

// ---------- dirt track ----------
static const double TRK_HW = 7.2, TRK_BL = 38, TRK_W = 8.5;     // flat half-width, banks blend width, visible dirt width (m)
struct Track {
    bool on = false; int n = 0; double cell = 48;
    std::vector<float> pts, g, clr, L;                         // pts = x,z pairs; g = graded height; clr = distance from the tarmac edge; L = segment length
    std::unordered_map<long long, std::vector<int>> grid;
};
static Track TRK;
static double tkD = 1e9, tkG = 0;                               // _tkD / _tkG
static inline long long tkKey(long cx, long cz){ return (long long)(cx + 100000) * 200003LL + (cz + 100000); }
static void trackQ(double x, double z){                         // nearest distance to the track (tkD) and its graded height there (tkG)
    tkD = 1e9; tkG = 0; if (!TRK.on) return;
    const long cx = (long)std::floor(x / TRK.cell), cz = (long)std::floor(z / TRK.cell); const int n = TRK.n; const float* P = TRK.pts.data();
    static thread_local std::vector<std::pair<float, float>> cand; cand.clear();        // (distance, graded height) of every nearby segment
    for (int i = -1; i <= 1; i++) for (int j = -1; j <= 1; j++){
        auto it = TRK.grid.find(tkKey(cx + i, cz + j)); if (it == TRK.grid.end()) continue;
        for (int q : it->second) for (int k = q - 1; k <= q; k++){
            if (k < 0 || k >= n - 1) continue;
            const double ax = P[k*2], az = P[k*2+1], ex = P[k*2+2] - ax, ez = P[k*2+3] - az;
            double t = ((x - ax)*ex + (z - az)*ez) / (ex*ex + ez*ez); t = t < 0 ? 0 : t > 1 ? 1 : t;
            const double dx = x - (ax + ex*t), dz = z - (az + ez*t), d = std::sqrt(dx*dx + dz*dz);
            const float gk = (float)(TRK.g[k] + (TRK.g[k+1] - TRK.g[k]) * t);
            if (d < tkD){ tkD = d; tkG = gk; }
            cand.push_back({(float)d, gk});
        }
    }
    if (cand.size() < 2) return;
    // switchbacks: two legs of the road lie only ~34 m apart at different heights. Weight every nearby segment by exp(-(d^2 - dmin^2) / 2s^2)
    // (s = 8 m): on the road the nearest segment dominates completely, half-way between two legs both count equally -> a smooth cut / fill bank, no cliff.
    const double inv = 1.0 / (2 * 8.0 * 8.0), d0 = tkD * tkD; double sw = 0, sg = 0;
    for (const auto& c : cand){ const double w = std::exp(-((double)c.first * c.first - d0) * inv); sw += w; sg += w * c.second; }
    if (sw > 0) tkG = sg / sw;
}
static double trackDist(double x, double z){ trackQ(x, z); return tkD; }

// ---------- rolling hills (fieldNoise / fieldMask / fieldH) ----------
static double fieldNoise(double x, double z){            // realistic: mountain massifs with ridged crests, eroded flanks, terraces and soft meadows between
    // domain warp so ridges meander instead of looking like grid noise
    const double wx = x + 38*(fFbm(x/190 + FSEED[2], z/190 + 7.3, 2) - 0.5), wz = z + 38*(fFbm(x/190 - 5.1, z/190 + FSEED[1], 2) - 0.5);
    const double big  = fFbm(wx/420 + FSEED[1], wz/420 + FSEED[2], 3);
    const double vd = std::fabs(z - 40*std::sin(x/300 + 0.5));                                   // distance from the valley axis
    const double mass = clamp01(0.35*sstep(0.37, 0.61, big) + sstep(200, 500, vd));               // Swiss valley: soft meadow floor, mountain walls on both sides
    const double det  = fFbm(wx/150 + FSEED[3], wz/150 - FSEED[1], 3);
    const double roll = fFbm(wx/160 - FSEED[2], wz/160 + FSEED[3], 2);
    // ridged multifractal: sharp crests and gullies on the mountains
    double rg = 0, a = 0.5, f = 1.0 / 110, w = 1;
    for (int i = 0; i < 4; i++){ double n = 1 - std::fabs(fNoise(wx*f + FSEED[3] + i*3.1, wz*f - FSEED[2] + i*5.7)*2 - 1); n *= n; n *= w; w = clamp01(n*1.6); rg += n*a; f *= 2.1; a *= 0.5; }
    const double crest = sstep(0.45, 0.9, mass);
    double h = FIELD_AMP*mass*(0.35 + 0.45*det + 0.55*rg*crest) + 3.0*roll;
    h += 0.9*(fFbm(x/14 + 31.7, z/14 - 12.9, 2) - 0.5) * (0.4 + mass);     // small bumps, rocks and hummocks
    { const double st = h / 3.2; const double fl = std::floor(st), fr = st - fl; h = (fl + sstep(0.35, 0.65, fr) * 0.35 + fr*0.65) * 3.2 * mass + h*(1 - mass); }   // faint terracing on slopes
    return std::max(0.0, std::min(FIELD_MAX, h));
}
static double fieldMask(double x, double z){
    const double edge = std::min(std::min(x + 640, 640 - x), std::min(z + 642, 646 - z));      // distance to the edge of the 4 m lattice; the outer ground continues from there
    if (edge <= 0) return 0;
    double m = 1;                                                       // no fade: the outer ground (outerH) continues exactly the same hill function, so the valley walls keep rising past the lattice edge
    const double rd = std::fabs(River::riverSd(x, z)); if (rd < 120) m *= sstep(40, 120, rd);   // keep the river banks as they were
    if (m <= 0) return 0;
    return m * sstep(10, 80, fieldClear(x, z));                           // roads stay perfectly level, hills grow away from them
}
static double fieldH(double x, double z){
    if (!gReady) return 0;
    const double m = fieldMask(x, z);
    double h = 0;
    if (m > 0) h = fieldNoise(x, z) * m;
    if (TRK.on){ trackQ(x, z); if (tkD < TRK_HW + TRK_BL) h += (tkG - h) * (1 - sstep(TRK_HW, TRK_HW + TRK_BL, tkD)); }   // grade the ground along the dirt track
    { const double W = h > 3 ? std::min(85.0, std::max(10.0, h / 0.30)) : 10.0;   // a raised hairpin mound needs a longer, gentler run-out to the level tarmac (fieldClear sees 96 m, Road::clearance only ~24 m)
      const double rc = W > 10.0 ? fieldClear(x, z) : (double)Road::clearance((float)x, (float)z); if (rc < 4 + W) h *= sstep(4, 4 + W, rc); }   // the tarmac always wins: exactly 0 within 4 m of a road edge; a raised hairpin mound falls to it at <= 30 % grade
    return h;
}

static void buildTrack(std::mt19937& rng){
    std::uniform_real_distribution<double> U(0.0, 1.0);
    const double rvC = std::cos(Road::gNet.riverAng), rvS = std::sin(Road::gNet.riverAng);
    const double nx = rvC, nz = -rvS, ph1 = U(rng) * 6.283, ph2 = U(rng) * 6.283;     // runs parallel to the river, on one side of it
    double bestScore = -1, bo = 0, bt0 = 0, bt1 = 0; bool have = false;
    for (double o0 : {-470.0, -450.0, 450.0, 470.0}){
        auto P = [&](double t, double& px, double& pz){ const double o = o0 + 45*std::sin(t/140 + ph1) + 20*std::sin(t/60 + ph2); px = rvS*t + nx*o; pz = rvC*t + nz*o; };
        double t0 = 0, t1 = 0, qx, qz;
        while (t0 > -900){ P(t0 - 3, qx, qz); if (coastDist(qx, qz) > -75) break; t0 -= 3; }
        while (t1 <  900){ P(t1 + 3, qx, qz); if (coastDist(qx, qz) > -75) break; t1 += 3; }
        if (t1 - t0 < 500) continue;
        { bool near = false; for (double t = t0; t <= t1; t += 6){ P(t, qx, qz); if (std::fabs(River::riverSd(qx, qz)) < 70){ near = true; break; } } if (near) continue; }   // the winding river must not cut across the dirt track
        double sc = 0; int cnt = 0; for (double t = t0; t <= t1; t += 30){ P(t, qx, qz); sc += fieldH(qx, qz); cnt++; }
        sc /= cnt; if (sc > bestScore){ bestScore = sc; bo = o0; bt0 = t0; bt1 = t1; have = true; }
    }
    if (!have) return;
    auto Pb = [&](double t, double& px, double& pz){ const double o = bo + 45*std::sin(t/140 + ph1) + 20*std::sin(t/60 + ph2); px = rvS*t + nx*o; pz = rvC*t + nz*o; };
    // ---- hairpin climb: the track leaves the valley floor and zig-zags up a mountain flank in tight switchbacks ----
    //  local frame: adv = along the river axis, lat = across it. entry arc -> 6 legs of 50 m joined by 5 hairpins (two 90-degree arcs R 9 m + a 14 m landing,
    //  legs 32 m apart) -> exit arc back onto the axis. The graded height climbs ~5.5 % along the whole zone (see E below).
    const double HP_R = 9, HP_S = 32, HP_LEG = 50; const int HP_K = 5; const double HP_ADV = 2*HP_R + HP_K*HP_S;     // 178 m along the axis
    auto oOf = [&](double t){ return bo + 45*std::sin(t/140 + ph1) + 20*std::sin(t/60 + ph2); };
    std::vector<std::pair<double, double>> Z;                                          // zone centre line in (adv, lat), first point = entry (0,0)
    {
        const double R = HP_R, STEP = 2.5, STR = HP_S - 2*HP_R, HP = PI_2; const int na = std::max(4, (int)std::ceil(R * HP / STEP));
        for (int k = 1; k <= na; k++){ const double f = k * HP / na; Z.push_back({R*std::sin(f), R*(1 - std::cos(f))}); }          // entry arc: +adv -> +lat
        for (int j = 0; j <= HP_K; j++){
            const double adv = R + j*HP_S; const int s = (j % 2 == 0) ? 1 : -1;
            const double lStart = s > 0 ? R : R + HP_LEG, lEnd = s > 0 ? R + HP_LEG : R; const int nl = (int)std::ceil(HP_LEG / STEP);
            for (int k = 1; k <= nl; k++) Z.push_back({adv, lStart + s * HP_LEG * k / nl});                                           // straight leg
            for (int k = 1; k <= na; k++){ const double f = k * HP / na; Z.push_back({adv + R*(1 - std::cos(f)), lEnd + s*R*std::sin(f)}); }   // 90 deg turn
            if (j == HP_K) break;                                                                                                     // last leg: that turn leads back onto the axis
            const int ns = std::max(1, (int)std::ceil(STR / STEP));
            for (int k = 1; k <= ns; k++) Z.push_back({adv + R + STR * k / ns, lEnd + s*R});                                          // landing
            for (int k = 1; k <= na; k++){ const double f = k * HP / na; Z.push_back({adv + R + STR + R*std::sin(f), lEnd + s*R - s*R*(1 - std::cos(f))}); }   // second 90 deg turn
        }
    }
    double zBest = -1, zT = 0; int zSg = 1;
    for (double te = bt0 + 60; te <= bt1 - HP_ADV - 240; te += 10) for (int sg : {1, -1}){           // where does the climb start? (valid: clear of roads / river / coast, on the highest ground)
        double ex, ez; Pb(te, ex, ez); bool ok = true; double sum = 0; int cnt = 0;
        for (size_t k = 0; k < Z.size(); k += 3){
            const double wx = ex + rvS*Z[k].first + nx*sg*Z[k].second, wz = ez + rvC*Z[k].first + nz*sg*Z[k].second;
            if (fieldClear(wx, wz) < 28 || std::fabs(River::riverSd(wx, wz)) < 80 || coastDist(wx, wz) > -80){ ok = false; break; }
            sum += fieldH(wx, wz); cnt++;
        }
        if (ok && cnt && sum / cnt > zBest){ zBest = sum / cnt; zT = te; zSg = sg; }
    }
    std::vector<float> pl; int zi0 = -1, zi1 = -1; double Hc = 0;
    if (zBest >= 0){
        const double te = zT, tx2 = zT + HP_ADV, oe = oOf(te); double ex, ez; Pb(te, ex, ez);
        for (double t = bt0; t <= te; t += 3){ const double o = oOf(t) + (oe - oOf(t)) * sstep(te - 100, te, t); pl.push_back((float)(rvS*t + nx*o)); pl.push_back((float)(rvC*t + nz*o)); }   // approach straightens out into the entry
        zi0 = (int)pl.size() / 2;
        for (const auto& q : Z){ pl.push_back((float)(ex + rvS*q.first + nx*zSg*q.second)); pl.push_back((float)(ez + rvC*q.first + nz*zSg*q.second)); }
        zi1 = (int)pl.size() / 2 - 1;
        for (double t = tx2 + 3; t <= bt1; t += 3){ const double o = oe + (oOf(t) - oOf(tx2)) * sstep(tx2, tx2 + 120, t); pl.push_back((float)(rvS*t + nx*o)); pl.push_back((float)(rvC*t + nz*o)); }
        double Lz = 0; for (int i = zi0; i < zi1; i++) Lz += std::hypot((double)pl[i*2+2] - pl[i*2], (double)pl[i*2+3] - pl[i*2+1]);
        Hc = std::min(26.0, std::min(0.055 * Lz, 0.055 * (bt1 - tx2) * 0.9));
    } else {
        for (double t = bt0; t <= bt1; t += 3){ double qx, qz; Pb(t, qx, qz); pl.push_back((float)qx); pl.push_back((float)qz); }
    }
    const int n = (int)pl.size() / 2; Track T; T.n = n; T.pts = pl; T.clr.assign(n, 0); T.L.assign(n, 0);
    std::vector<float> H0(n);
    for (int i = 0; i < n; i++){
        H0[i] = (float)fieldH(pl[i*2], pl[i*2+1]); T.clr[i] = (float)fieldClear(pl[i*2], pl[i*2+1]);
        if (i < n - 1) T.L[i] = (float)std::hypot((double)pl[i*2+2] - pl[i*2], (double)pl[i*2+3] - pl[i*2+1]);
    }
    if (zi0 >= 0){ double m = 0; for (int i = zi0; i <= zi1; i++) m += H0[i]; m /= (zi1 - zi0 + 1); for (int i = zi0; i <= zi1; i++) H0[i] = (float)m; }   // the climb itself supplies the slope there
    auto smooth = [&](const std::vector<float>& A, int w){ std::vector<float> B(n); for (int i = 0; i < n; i++){ float sm = 0; int c = 0; for (int k = -w; k <= w; k++){ int j = i + k; if (j < 0 || j >= n) continue; sm += A[j]; c++; } B[i] = sm / c; } return B; };
    auto pin = [&](std::vector<float>& G){ for (int i = 0; i < n; i++) if (T.clr[i] < 12 || i < 4 || i > n - 5) G[i] = 0; };   // level where it meets the tarmac roads and the beach
    std::vector<float> G = H0;
    for (int r = 0; r < 3; r++) G = smooth(G, 12);                       // follow the average of the mountains, not every bump
    pin(G);
    for (int r = 0; r < 3; r++){                                          // never steeper than ~11 %: cuts through ridges, fills the dips
        for (int i = 1; i < n; i++) G[i] = std::min(G[i], G[i-1] + 0.11f * T.L[i-1]);
        for (int i = n - 2; i >= 0; i--) G[i] = std::min(G[i], G[i+1] + 0.11f * T.L[i]);
    }
    if (zi0 >= 0 && Hc > 1){                                              // add the switchback climb on top of the valley grade, then ease back down after the zone
        std::vector<double> s(n, 0.0); for (int i = 1; i < n; i++) s[i] = s[i-1] + T.L[i-1];
        std::vector<float> E(n, 0.f);
        for (int i = zi0; i < n; i++) E[i] = (float)(i <= zi1 ? Hc * (s[i] - s[zi0]) / (s[zi1] - s[zi0]) : std::max(0.0, Hc - 0.055 * (s[i] - s[zi1])));
        auto pinnedE = [&](int i){ return T.clr[i] < 12 || i < 4 || i > n - 5; };
        for (int i = 0; i < n; i++){ if (pinnedE(i)){ E[i] = 0; continue; } if (i > 0) E[i] = std::min(E[i], E[i-1] + 0.06f * T.L[i-1]); }        // never climb faster than 6 % away from a pinned (level) point ...
        for (int i = n - 1; i >= 0; i--){ if (pinnedE(i)){ E[i] = 0; continue; } if (i + 1 < n) E[i] = std::min(E[i], E[i+1] + 0.06f * T.L[i]); }   // ... in either direction
        for (int i = 0; i < n; i++) G[i] += E[i];
    }
    G = smooth(G, 2); pin(G);
    T.g = G;
    for (int i = 0; i < n; i++) T.grid[tkKey((long)std::floor(pl[i*2] / 48.0), (long)std::floor(pl[i*2+1] / 48.0))].push_back(i);
    T.on = true; TRK = T;
}

// ---------- ground height lattice: the rendered hill strips + the river patch share it (4 m cells) ----------
//  x = LX0 + 4 i (i = 0..LNX),  z = LZ0 + 4 k (k = 0..LNZ). The lattice lines up with the river patch (patch row j = lattice row j + 103).
static const double LX0 = -640, LZ0 = -642, LC = 4.0;
static const int LNX = 320, LNZ = 322, LROW_PATCH0 = 103, LROW_PATCH1 = 276;     // rows 0..103 = southern strip, 276..322 = northern strip
static std::vector<float> HL, FL;                                                  // ground height (river + hills) and hill part only
static inline size_t lix(int i, int k){ return (size_t)k * (LNX + 1) + i; }

// ---------- outer ground: everything beyond the 4 m lattice (foothills up to the mountain ring, rolling plains behind it) ----------
// ---------- mountain lake (carved into the foothills; the water surface itself is drawn by TerrainGL::drawLake with the river-water look) ----------
struct LakeT { bool on = false; double x = 0, z = 0, r = 110, y = 0; };
static LakeT gLake;
static const double LAKE_DEPTH = 6.0;
static inline double lakeDn(double x, double z){ return gLake.on ? std::hypot(x - gLake.x, z - gLake.z) / gLake.r : 1e9; }   // 1 = shoreline
static inline double lakeBed(double dn){ return dn < 1 ? -LAKE_DEPTH * (1 - dn*dn) : 0.1; }
static inline double lakeCarve(double x, double z, double h){
    if (!gLake.on) return h;
    const double dn = lakeDn(x, z); if (dn >= 1.55) return h;
    const double k = 1 - sstep(1.0, 1.55, dn); return h * (1 - k) + lakeBed(dn) * k;      // bowl inside, bank that rises into the hills / mountain foot outside
}
static double outerH(double x, double z){
    if (!gReady) return 0;
    const double c = std::max(std::fabs(x), std::fabs(z)), r = std::hypot(x, z);
    const double amp = (c >= 640 ? 1.0 : 0.0) * std::max(1 - sstep(900, 1050, r), sstep(1450, 1600, r));
    double h = 0;
    if (amp > 0){ const double rd = std::fabs(River::riverSd(x, z)); h = fieldNoise(x, z) * amp * (rd < 120 ? sstep(40, 120, rd) : 1.0); }
    return lakeCarve(x, z, h);
}
static inline bool inLattice(double x, double z){ return x >= LX0 && z >= LZ0 && x <= LX0 + LNX*LC && z <= LZ0 + LNZ*LC; }
static inline double latSlope(double x, double z){          // steepness (rise/run) of the hill part, from the lattice (or the outer ground)
    if (!inLattice(x, z)){ const double e = 2.0; const double dx = (outerH(x+e, z) - outerH(x-e, z)) / (2*e), dz = (outerH(x, z+e) - outerH(x, z-e)) / (2*e); return std::sqrt(dx*dx + dz*dz); }
    if (FL.empty()) return 0;
    const int i = std::max(1, std::min(LNX - 1, (int)std::lround((x - LX0) / LC))), k = std::max(1, std::min(LNZ - 1, (int)std::lround((z - LZ0) / LC)));
    const double dx = (FL[lix(i+1, k)] - FL[lix(i-1, k)]) / (2*LC), dz = (FL[lix(i, k+1)] - FL[lix(i, k-1)]) / (2*LC);
    return std::sqrt(dx*dx + dz*dz);
}

// height of the rendered ground triangles at (x,z) (meshH in the HTML); outside the lattice there are no hills
static double meshH(double x, double z){
    const double fx = (x - LX0) / LC, fz = (z - LZ0) / LC;
    if (fx < 0 || fz < 0 || fx > LNX || fz > LNZ || HL.empty()) return River::groundH(x, z) + outerH(x, z);
    int i = (int)std::floor(fx), k = (int)std::floor(fz); i = std::max(0, std::min(LNX - 1, i)); k = std::max(0, std::min(LNZ - 1, k));
    const double u = fx - i, v = fz - k, ha = HL[lix(i, k)], hb = HL[lix(i + 1, k)], hc = HL[lix(i, k + 1)], hd = HL[lix(i + 1, k + 1)];
    return (u + v <= 1) ? ha + u*(hb - ha) + v*(hc - ha) : hb*(1 - v) + hc*(1 - u) + hd*(u + v - 1);     // the two triangles of the grid cell (a,c,b) + (b,c,d)
}
// what the tyres touch: the hill function, but exactly the rendered triangles (+ the raised dirt strip) on and next to the track
static double carGroundH(double x, double z){
    if (!inLattice(x, z)) return River::groundH(x, z) + outerH(x, z);
    const double f = fieldH(x, z);
    if (!TRK.on) return f;
    trackQ(x, z); const double d = tkD, hwT = TRK_W / 2;
    if (d > hwT + 8) return f;
    const double k = 1 - sstep(hwT + 4, hwT + 8, d);
    const double off = (Road::clearance((float)x, (float)z) > 1.2f) ? 0.15 * (1 - sstep(hwT + 1.5, hwT + 6, d)) : 0;
    return f*(1 - k) + (meshH(x, z) + off + 0.01) * k;
}

// ---------- ground colour (the vertex colours of the grass mesh in the HTML, as a tint on this project's grass green) ----------
static inline double latSlope(double x, double z);
static void grassColor(double x, double z, double f, double& r, double& g, double& b){
    struct C3 { double r, g, b; };
    static const C3 c1 = {0x5b/255.0, 0x7a/255.0, 0x3b/255.0}, c2 = {0x86/255.0, 0x99/255.0, 0x4e/255.0}, dry = {0xa0/255.0, 0x9a/255.0, 0x5c/255.0},
                    dark = {0x44/255.0, 0x59/255.0, 0x2f/255.0}, sandC = {0x9c/255.0, 0x84/255.0, 0x5f/255.0}, dirtC = {0x86/255.0, 0x68/255.0, 0x4a/255.0};
    const double y = -z;
    const double t = (std::sin(x*0.05) + std::cos(y*0.07))*0.25 + std::sin(x*0.17 + y*0.11)*0.15 + std::sin(x*0.011 - y*0.013)*0.25 + 0.5 + (fHash(std::floor(x*0.7), std::floor(y*0.7)) - 0.5)*0.06;
    const double tt = clamp01(t);
    C3 c = {c1.r + (c2.r - c1.r)*tt, c1.g + (c2.g - c1.g)*tt, c1.b + (c2.b - c1.b)*tt};
    auto lerp = [&](const C3& o, double a){ c.r += (o.r - c.r)*a; c.g += (o.g - c.g)*a; c.b += (o.b - c.b)*a; };
    const double dn = std::sin(x*0.007 + 1.3)*std::cos(y*0.006 - 0.7) + std::sin(x*0.021 + y*0.017)*0.4;     // large natural patches: sun-dried straw / shaded dark grass
    if (dn > 0.35) lerp(dry, std::min((dn - 0.35)*0.5, 0.14)); else if (dn < -0.5) lerp(dark, std::min((-0.5 - dn)*0.7, 0.5));
    double bare = 0;                                                          // how much sand / earth (not grass) this point is
    { const double rc = Road::clearance((float)x, (float)z);                // dusty sand / earth bleeding from the road into the grass, patchy
      if (rc < 22){ const double n = 0.9 + 0.2*fNoise(x/80, z/80), kr = std::min(1.0, (1 - sstep(4, 22, std::max(rc, 0.0))) * 0.8 * n); lerp(sandC, kr); bare = std::max(bare, kr); } }
    if (TRK.on){ trackQ(x, z); if (tkD < TRK_HW + 3) { const double kd = (1 - sstep(TRK_HW - 1.5, TRK_HW + 3, tkD)) * 0.75; lerp(dirtC, kd); bare = std::max(bare, kd); } }   // bare earth beside the track
    const double k = 1 + 0.10 * (f / FIELD_AMP);                              // crests catch a little more sun, hollows are a little darker
    const double mr = (c1.r + c2.r) / 2, mg = (c1.g + c2.g) / 2, mb = (c1.b + c2.b) / 2;     // mid grass = this project's base green
    c.r = c.r * k / mr; c.g = c.g * k / mg; c.b = c.b * k / mb;
    { const double w = 1 - bare;                                              // vivid, saturated meadow green (fresh lawn look)
      c.r *= 1 + 0.30*w; c.g *= 1 + 0.24*w; c.b *= 1 - 0.50*w; }
    {   // rock on steep faces, scree / dry earth on upper slopes, patches of forest floor, snow caps on the very top
        const double sl = latSlope(x, z), n1 = fNoise(x/9 + 4.4, z/9 - 2.2), n2 = fNoise(x/2.5, z/2.5);
        const double rockA = sstep(0.55, 0.95, sl + (n1 - 0.5)*0.3);
        const double alt = f + (n1 - 0.5)*5;
        const double high = sstep(14, 30, alt);
        const double rr = 0.46 + 0.12*n2, rgc = 0.42 + 0.10*n2, rb = 0.37 + 0.09*n2;
        auto mixc = [&](double R, double G, double B, double a){ c.r += (R/mr*0.5 - c.r)*a; c.g += (G/mg*0.5 - c.g)*a; c.b += (B/mb*0.5 - c.b)*a; };
        mixc(0.40, 0.55, 0.20, high*0.30*(1 - rockA));                      // dry alpine grass
        mixc(rr, rgc, rb, std::min(1.0, rockA*0.8));            // grey-brown rock
        const double snow = sstep(31, 37, alt + (n1 - 0.5)*4) * (1 - sstep(0.30, 0.62, sl));
        mixc(0.93, 0.95, 0.98, snow*0.0);
    }
    r = std::min(1.4, r * c.r); g = std::min(1.4, g * c.g); b = std::min(1.4, b * c.b);
}

// ---------- meshes ----------
struct GMesh { std::vector<float> v; std::vector<uint32_t> idx; };            // vertex = pos(3) colour(3) normal(3)

// hill strip between two lattice rows (inclusive)
static void buildStrip(GMesh& m, int k0, int k1){
    const int W = LNX + 1; const uint32_t base = (uint32_t)(m.v.size() / 9);
    for (int k = k0; k <= k1; k++) for (int i = 0; i <= LNX; i++){
        const double x = LX0 + i*LC, z = LZ0 + k*LC, h = HL[lix(i, k)];
        const double hxm = HL[lix(std::max(i-1, 0), k)], hxp = HL[lix(std::min(i+1, LNX), k)], hzm = HL[lix(i, std::max(k-1, 0))], hzp = HL[lix(i, std::min(k+1, LNZ))];
        const double nx = (hxm - hxp) / (2*LC), nz = (hzm - hzp) / (2*LC), l = std::sqrt(nx*nx + nz*nz + 1);
        double r = 0.441, g = 0.539, b = 0.269; grassColor(x, z, FL[lix(i, k)], r, g, b);
        const float row[9] = {(float)x, (float)h, (float)z, (float)r, (float)g, (float)b, (float)(nx / l), (float)(1 / l), (float)(nz / l)};
        m.v.insert(m.v.end(), row, row + 9);
    }
    for (int k = 0; k < k1 - k0; k++) for (int i = 0; i < LNX; i++){
        const uint32_t a = base + k*W + i, b = a + 1, c = a + W, d = c + 1; const uint32_t t[6] = {a, c, b, b, c, d};
        m.idx.insert(m.idx.end(), t, t + 6);
    }
}

// outer ground: 16 m grid from -1920..1920 around the lattice (the lattice itself is skipped); same colours / shader as the hill strips
static void buildOuter(GMesh& m){
    const int N = 241; const double S = 16.0, X0 = -1920, Z0 = -1922;
    std::vector<float> H((size_t)N*N);
    for (int k = 0; k < N; k++) for (int i = 0; i < N; i++) H[(size_t)k*N + i] = (float)(River::groundH(X0 + i*S, Z0 + k*S) + outerH(X0 + i*S, Z0 + k*S));
    auto hh = [&](int i, int k){ return (double)H[(size_t)std::max(0, std::min(N-1, k))*N + std::max(0, std::min(N-1, i))]; };
    for (int k = 0; k < N; k++) for (int i = 0; i < N; i++){
        const double x = X0 + i*S, z = Z0 + k*S, h = hh(i, k);
        const double nx = (hh(i-1, k) - hh(i+1, k)) / (2*S), nz = (hh(i, k-1) - hh(i, k+1)) / (2*S), l = std::sqrt(nx*nx + nz*nz + 1);
        double r = 0.441, g = 0.539, b = 0.269; grassColor(x, z, outerH(x, z), r, g, b);
        const float row[9] = {(float)x, (float)(h - 0.02), (float)z, (float)r, (float)g, (float)b, (float)(nx / l), (float)(1 / l), (float)(nz / l)};
        m.v.insert(m.v.end(), row, row + 9);
    }
    for (int k = 0; k < N - 1; k++) for (int i = 0; i < N - 1; i++){
        const double x0 = X0 + i*S, z0 = Z0 + k*S;
        if (x0 >= LX0 && x0 + S <= LX0 + LNX*LC && z0 >= LZ0 && z0 + S <= LZ0 + LNZ*LC - 8) continue;      // inside the lattice: the hill strips / river patch are there
        const uint32_t a = (uint32_t)(k*N + i), b = a + 1, c = a + N, d = c + 1; const uint32_t q[6] = {a, c, b, b, c, d};
        m.idx.insert(m.idx.end(), q, q + 6);
    }
}

// height grid of the mountain ring (filled by buildMountains) + bilinear lookup, used to plant the forest on the slopes
static int MTN_NA = 0, MTN_NR = 0; static const double MTN_R0 = 880, MTN_R1 = 1450; static std::vector<float> MTN_H;
static double mtnH(double x, double z){                       // -1 outside the ring
    if (MTN_H.empty()) return -1;
    const double r = std::hypot(x, z); if (r < MTN_R0 || r >= MTN_R1) return -1;
    double a = std::atan2(z, x); if (a < 0) a += 2*Road::PI;
    double fi = a / (2*Road::PI) * MTN_NA; int i0 = (int)std::floor(fi); fi -= i0; i0 %= MTN_NA; const int i1 = (i0 + 1) % MTN_NA;
    double fj = (r - MTN_R0) / (MTN_R1 - MTN_R0) * MTN_NR; int j0 = std::min((int)std::floor(fj), MTN_NR - 1); fj -= j0;
    const double h00 = MTN_H[(size_t)j0*MTN_NA + i0], h10 = MTN_H[(size_t)j0*MTN_NA + i1], h01 = MTN_H[(size_t)(j0+1)*MTN_NA + i0], h11 = MTN_H[(size_t)(j0+1)*MTN_NA + i1];
    return (h00*(1-fi) + h10*fi)*(1-fj) + (h01*(1-fi) + h11*fi)*fj;
}
// distant mountain ring (one ridged-noise height field: forest foothills -> alpine meadow -> rock -> snow)
static void buildMountains(GMesh& m){
    auto hash = [](double x, double y){ const double h = std::sin(x*127.1 + y*311.7) * 43758.5453; return h - std::floor(h); };
    auto vnoise = [&](double x, double y){ const double ix = std::floor(x), iy = std::floor(y), fx = x - ix, fy = y - iy, u = fx*fx*(3 - 2*fx), v = fy*fy*(3 - 2*fy);
        return (hash(ix, iy)*(1-u) + hash(ix+1, iy)*u)*(1-v) + (hash(ix, iy+1)*(1-u) + hash(ix+1, iy+1)*u)*v; };
    auto fbm = [&](double x, double y, int o){ double a = 0.5, s = 0, f = 1; for (int i = 0; i < o; i++){ s += a*vnoise(x*f, y*f); f *= 2.07; a *= 0.5; } return s; };
    auto ridge = [&](double x, double y, int o){ double a = 0.5, s = 0, f = 1, w = 1; for (int i = 0; i < o; i++){ double n = 1 - std::fabs(vnoise(x*f, y*f)*2 - 1); n *= n; n *= w; w = clamp01(n*1.8); s += n*a; f *= 2.1; a *= 0.5; } return s; };
    const double R0 = 880, R1 = 1450; const int NA = 720, NR = 90;
    const double PEAK = 800;                                                                           // tallest summit (m): steep, sharp Alps
    std::vector<float> pos((size_t)NA*(NR+1)*3), hh((size_t)NA*(NR+1)); double hmax = 1;
    for (int j = 0; j <= NR; j++) for (int i = 0; i < NA; i++){
        const double a = (double)i / NA * (2*Road::PI), r = R0 + (R1 - R0)*j/NR, x = std::cos(a)*r, z = std::sin(a)*r, t = (double)j / NR;
        const double env = sstep(0, 0.30, t) * (1 - sstep(0.80, 1, t));
        const double mask = sstep(0.30, 0.62, fbm(x*0.0016 + 3.1, z*0.0016 + 7.7, 3));                 // some sectors are taller massifs, others lower passes (never flat)
        const double rg = ridge(x*0.0042 + 11, z*0.0042 + 5, 5), sharp = std::pow(rg, 2.1);            // high power = narrow, knife-edge crests
        double h = env * (40*fbm(x*0.004, z*0.004, 3) + (0.45 + 0.55*mask) * 1000 * sharp);
        h *= sstep(50, 230, std::fabs(River::riverSd(x, z)));                                          // the river runs through a valley
        const size_t k = (size_t)j*NA + i; hh[k] = (float)h; if (h > hmax) hmax = h;
        pos[k*3] = (float)x; pos[k*3+2] = (float)z;
    }
    const float sc = (float)(PEAK / hmax);                                                              // tallest peak = PEAK metres
    for (size_t k = 0; k < hh.size(); k++){ hh[k] = (float)lakeCarve(pos[k*3], pos[k*3+2], hh[k] * sc); pos[k*3+1] = hh[k] - 0.3f; }
    MTN_NA = NA; MTN_NR = NR; MTN_H = hh;
    std::vector<uint32_t> idx;
    for (int j = 0; j < NR; j++) for (int i = 0; i < NA; i++){
        const uint32_t a = j*NA + i, b = j*NA + (i+1) % NA, c = (j+1)*NA + i, d = (j+1)*NA + (i+1) % NA;
        const uint32_t t[6] = {a, b, c, b, d, c}; idx.insert(idx.end(), t, t + 6);
    }
    std::vector<double> nor((size_t)NA*(NR+1)*3, 0.0);                                                  // computeVertexNormals
    for (size_t f = 0; f < idx.size(); f += 3){
        const float *A = &pos[idx[f]*3], *B = &pos[idx[f+1]*3], *C = &pos[idx[f+2]*3];
        double cb[3] = {C[0]-B[0], C[1]-B[1], C[2]-B[2]}, ab[3] = {A[0]-B[0], A[1]-B[1], A[2]-B[2]};
        double n[3] = {cb[1]*ab[2] - cb[2]*ab[1], cb[2]*ab[0] - cb[0]*ab[2], cb[0]*ab[1] - cb[1]*ab[0]};
        for (int q = 0; q < 3; q++) for (int c = 0; c < 3; c++) nor[idx[f+q]*3 + c] += n[c];
    }
    for (int k = 0; k < NA*(NR+1); k++){
        double l = std::sqrt(nor[k*3]*nor[k*3] + nor[k*3+1]*nor[k*3+1] + nor[k*3+2]*nor[k*3+2]); if (l == 0) l = 1;
        const double s = nor[k*3+1] < 0 ? -1.0 : 1.0; double nxv = nor[k*3]/l*s, nyv = nor[k*3+1]/l*s, nzv = nor[k*3+2]/l*s;
        const double x = pos[k*3], z = pos[k*3+2], h = hh[k], ny = nyv;
        const double n1 = fbm(x*0.03, z*0.03, 3), n2 = vnoise(x*0.22, z*0.22);
        auto mix = [](double A, double B, double mm){ return A + (B - A)*mm; };
        double R = 0.16 + 0.06*n1, G = 0.34 + 0.10*n1, B = 0.10 + 0.04*n1;                              // green grass / forest at the foot
        double mm = sstep(100, 175, h + (n1 - 0.5)*60); R = mix(R, 0.36 + 0.05*n2, mm); G = mix(G, 0.42 + 0.05*n2, mm); B = mix(B, 0.20, mm);   // upper meadow
        mm = std::max(sstep(150, 240, h + (n1 - 0.5)*80), sstep(0.86, 0.62, ny)); R = mix(R, 0.46 + 0.10*n2, mm); G = mix(G, 0.45 + 0.09*n2, mm); B = mix(B, 0.43 + 0.08*n2, mm);   // grey rock / steep faces
        mm = sstep(290, 380, h + (n1 - 0.5)*90) * sstep(0.26, 0.50, ny); R = mix(R, 0.95, mm); G = mix(G, 0.96, mm); B = mix(B, 0.99, mm);       // white snow on the summits
        mm = 1 - sstep(0, 4, h); R = mix(R, 0.30, mm); G = mix(G, 0.42, mm); B = mix(B, 0.18, mm);        // foot blends into the meadow
        const float row[9] = {pos[k*3], pos[k*3+1], pos[k*3+2], (float)R, (float)G, (float)B, (float)nxv, (float)nyv, (float)nzv};
        m.v.insert(m.v.end(), row, row + 9);
    }
    m.idx = idx;
}

// dirt strip + its soft earth verges, following the REAL rendered ground triangles (cut into ~2 m rows so the ground never pokes through)
static void buildTrackMeshes(Road::Mesh& strip, Road::Mesh& verge){
    if (!TRK.on) return;
    const int n = TRK.n; const float* P = TRK.pts.data();
    struct Row { double x, z, tx, tz, s; }; std::vector<Row> rows; std::vector<char> rowOk; double sAcc = 0;
    auto tanAt = [&](int i, double& tx, double& tz){ const int a = std::max(i-1, 0), b = std::min(i+1, n-1); tx = P[b*2] - P[a*2]; tz = P[b*2+1] - P[a*2+1]; double tl = std::hypot(tx, tz); if (tl == 0) tl = 1; tx /= tl; tz /= tl; };
    for (int i = 0; i < n - 1; i++){
        const bool ok = TRK.clr[i] > 1.2f && TRK.clr[i+1] > 1.2f; const double segL = TRK.L[i]; const int mm = std::max(1, (int)std::ceil(segL / 2));
        double t0x, t0z, t1x, t1z; tanAt(i, t0x, t0z); tanAt(i + 1, t1x, t1z);
        for (int k = 0; k < mm; k++){
            const double f = (double)k / mm; double tx = t0x + (t1x - t0x)*f, tz = t0z + (t1z - t0z)*f; double tl = std::hypot(tx, tz); if (tl == 0) tl = 1; tx /= tl; tz /= tl;
            rows.push_back({P[i*2] + (P[i*2+2] - P[i*2])*f, P[i*2+1] + (P[i*2+3] - P[i*2+1])*f, tx, tz, sAcc}); rowOk.push_back(ok); sAcc += segL / mm;
        }
    }
    { double tx, tz; tanAt(n - 1, tx, tz); rows.push_back({P[(n-1)*2], P[(n-1)*2+1], tx, tz, sAcc}); }
    auto ribbon = [&](Road::Mesh& out, const std::vector<double>& offs, const std::vector<double>& us, double vLen, double yOff, double vConst = -1){
        const int NC = (int)offs.size(); const uint32_t base = (uint32_t)(out.v.size() / 8);
        std::vector<double> pos(rows.size() * NC * 3), nor(rows.size() * NC * 3, 0.0); std::vector<float> uv(rows.size() * NC * 2);
        std::vector<double> kap(rows.size(), 0.0);                                               // signed curvature: the centre of a bend lies on the + side of the offset when > 0
        for (size_t r = 1; r + 1 < rows.size(); r++){
            const double ds = std::hypot(rows[r+1].x - rows[r-1].x, rows[r+1].z - rows[r-1].z); if (ds < 1e-6) continue;
            kap[r] = (rows[r-1].tx * rows[r+1].tz - rows[r-1].tz * rows[r+1].tx) / ds;
        }
        for (size_t r = 0; r < rows.size(); r++) for (int c = 0; c < NC; c++){
            double off = offs[c]; const double kk = kap[r];
            if (off * kk > 0 && std::fabs(off * kk) > 0.8) off = (off > 0 ? 1 : -1) * 0.8 / std::fabs(kk);   // hairpin inside: the shoulder must not fold past the bend centre
            const size_t q = r*NC + c; const double x = rows[r].x - rows[r].tz*off, z = rows[r].z + rows[r].tx*off;
            pos[q*3] = x; pos[q*3+1] = meshH(x, z) + yOff; pos[q*3+2] = z; uv[q*2] = (float)us[c]; uv[q*2+1] = (float)(vConst >= 0 ? vConst : rows[r].s / vLen);
        }
        std::vector<uint32_t> ix;
        for (size_t r = 0; r + 1 < rows.size(); r++) if (rowOk[r]) for (int c = 0; c < NC - 1; c++){
            const uint32_t A = (uint32_t)(r*NC + c), B = A + 1, C = (uint32_t)((r+1)*NC + c), D = C + 1; const uint32_t t[6] = {A, B, C, B, D, C}; ix.insert(ix.end(), t, t + 6);
        }
        for (size_t f = 0; f < ix.size(); f += 3){
            const double *A = &pos[ix[f]*3], *B = &pos[ix[f+1]*3], *C = &pos[ix[f+2]*3];
            double cb[3] = {C[0]-B[0], C[1]-B[1], C[2]-B[2]}, ab[3] = {A[0]-B[0], A[1]-B[1], A[2]-B[2]};
            double nn[3] = {cb[1]*ab[2] - cb[2]*ab[1], cb[2]*ab[0] - cb[0]*ab[2], cb[0]*ab[1] - cb[1]*ab[0]};
            for (int q = 0; q < 3; q++) for (int c = 0; c < 3; c++) nor[ix[f+q]*3 + c] += nn[c];
        }
        for (size_t q = 0; q < rows.size() * NC; q++){
            double l = std::sqrt(nor[q*3]*nor[q*3] + nor[q*3+1]*nor[q*3+1] + nor[q*3+2]*nor[q*3+2]); if (l == 0) l = 1;
            const double s = nor[q*3+1] < 0 ? -1.0 : 1.0;                                     // always face up
            const float row[8] = {(float)pos[q*3], (float)pos[q*3+1], (float)pos[q*3+2], uv[q*2], uv[q*2+1], (float)(nor[q*3]/l*s), (float)(nor[q*3+1]/l*s), (float)(nor[q*3+2]/l*s)};
            out.v.insert(out.v.end(), row, row + 8);
        }
        for (uint32_t i : ix) out.idx.push_back(base + i);
    };
    const double hw = TRK_W / 2; const double HC[5] = {-1, -0.5, 0, 0.5, 1};
    std::vector<double> offs, us; for (double s : HC){ offs.push_back(s*hw); us.push_back((s + 1) / 2); }
    ribbon(strip, offs, offs, 8, 0.14, hw);                                                         // the track itself: same material and tile (road width x 8 m) as the wide dirt road
    const double DS[6] = {-1.5, 0, 1.5, 3.5, 5.5, 8}; auto SH_U = [](double d){ return (d + 1.5) / (8 + 1.5); };
    offs.clear(); us.clear(); for (double d : DS){ offs.push_back(hw + d); us.push_back(SH_U(d)); }
    ribbon(verge, offs, us, 2.5, 0.15);                                                       // right verge (u: 0 at the track, 1 at the outer edge)
    offs.clear(); us.clear(); for (int i = 5; i >= 0; i--){ offs.push_back(-(hw + DS[i])); us.push_back(SH_U(DS[i])); }
    ribbon(verge, offs, us, 2.5, 0.15);                                                       // left verge, mirrored
}

// hill height / grass tint for the river patch (it shares the lattice, so the hills line up exactly with the strips next to it)
static double patchFieldH(double x, double z){
    const double fx = (x - LX0) / LC, fz = (z - LZ0) / LC;
    if (fx < -0.01 || fz < -0.01 || fx > LNX + 0.01 || fz > LNZ + 0.01) return 0;
    return FL[lix((int)std::lround(fx), (int)std::lround(fz))];
}

// pick a spot just outside the playable square (far from roads and the river), build the water disc + the mountain skyline seen from it
static std::vector<float> LAKE_V; static std::vector<uint32_t> LAKE_I; static std::vector<uint8_t> LAKE_SKY; static const int LAKE_SKY_N = 720;
static void chooseLake(){
    double best = -1, bx = 0, bz = 0;
    for (int q = 0; q < 4; q++) for (int o = -1; o <= 1; o++){
        const double a = q * Road::PI / 2 + o * 0.14, x = 850 * std::cos(a), z = 850 * std::sin(a);
        if (std::max(std::fabs(x), std::fabs(z)) < 822) continue;                       // keep the whole bowl outside the 640 m lattice
        const double m = std::min((double)Road::clearance((float)x, (float)z), std::fabs(River::riverSd(x, z)));
        if (m > best){ best = m; bx = x; bz = z; }
    }
    if (best >= 100){ gLake.on = true; gLake.x = bx; gLake.z = bz; gLake.r = 110; gLake.y = 0; }
}
static void buildLake(){
    if (!gLake.on) return;
    const int NS = 48, NRG = 8; const double PI2 = 2 * Road::PI;
    for (int i = 0; i <= NRG; i++){
        const double dn = (double)i / NRG * 1.15, dep = dn <= 1 ? LAKE_DEPTH * (1 - dn*dn) : -(dn - 1) * 4;      // depth param for the water shader (0 at the shore)
        for (int j = 0; j < NS; j++){ const double a = (double)j / NS * PI2;
            const float row[4] = {(float)(gLake.x + std::cos(a) * dn * gLake.r), (float)gLake.y, (float)(gLake.z + std::sin(a) * dn * gLake.r), (float)dep};
            LAKE_V.insert(LAKE_V.end(), row, row + 4); }
    }
    for (int i = 0; i < NRG; i++) for (int j = 0; j < NS; j++){
        const uint32_t a = i*NS + j, b = i*NS + (j+1) % NS, c = (i+1)*NS + j, d = (i+1)*NS + (j+1) % NS; const uint32_t t[6] = {a, c, b, b, c, d}; LAKE_I.insert(LAKE_I.end(), t, t + 6);
    }
    // skyline: for every azimuth the highest mountain elevation seen from the lake centre (the shader mirrors it as the reflection)
    LAKE_SKY.assign((size_t)LAKE_SKY_N * 4, 0); std::vector<float> e(LAKE_SKY_N, 0.f), cr(LAKE_SKY_N, 0.f);
    for (int b = 0; b < LAKE_SKY_N; b++){
        const double az = ((b + 0.5) / LAKE_SKY_N - 0.5) * PI2, cx = std::cos(az), cz = std::sin(az);
        for (double d = 60; d < 1900; d += (d < 400 ? 6.0 : 14.0)){
            double h = mtnH(gLake.x + cx*d, gLake.z + cz*d); if (h < 0) continue;
            const float el = (float)std::atan2(h - gLake.y, d); if (el > e[b]){ e[b] = el; cr[b] = (float)h; }
        }
    }
    for (int pass = 0; pass < 2; pass++){ std::vector<float> e2 = e, c2 = cr;
        for (int b = 0; b < LAKE_SKY_N; b++){ const int l = (b + LAKE_SKY_N - 1) % LAKE_SKY_N, r = (b + 1) % LAKE_SKY_N;
            e2[b] = std::max(e[b], 0.25f*e[l] + 0.5f*e[b] + 0.25f*e[r]); c2[b] = std::max(cr[b], 0.25f*cr[l] + 0.5f*cr[b] + 0.25f*cr[r]); }
        e = e2; cr = c2; }
    for (int b = 0; b < LAKE_SKY_N; b++){ LAKE_SKY[b*4] = (uint8_t)std::min(255.f, e[b] * 255.f); LAKE_SKY[b*4+1] = (uint8_t)std::min(255.f, cr[b] / 850.f * 255.f); LAKE_SKY[b*4+2] = 0; LAKE_SKY[b*4+3] = 255; }
}

// ---------- init ----------
struct Meshes { GMesh southHills, northHills, mountains, outer; };
static Meshes gMeshes;

static void setSeed(uint32_t s){
    std::mt19937 r(s); std::uniform_real_distribution<double> U(0.0, 500.0);
    for (int i = 0; i < 4; i++) FSEED[i] = U(r);                                              // different hills on every load
    River::FSEED0 = FSEED[0];
}
// needs Road::init() done (road grid + river). Call before RoadGL::init / TreeGL::init / BridgeGL::init.
static void init(uint32_t seed){
    setSeed(seed); gReady = true;
    std::mt19937 rng(seed ^ 0x9e3779b9u);
    buildTrack(rng);                                                                          // dirt track (terrain along it is graded from now on)
    HL.assign((size_t)(LNX + 1) * (LNZ + 1), 0.f); FL = HL;
    for (int k = 0; k <= LNZ; k++) for (int i = 0; i <= LNX; i++){
        const double x = LX0 + i*LC, z = LZ0 + k*LC, f = fieldH(x, z);
        FL[lix(i, k)] = (float)f; HL[lix(i, k)] = (float)(River::groundH(x, z) + f);
    }
    River::gHooks.fieldH = patchFieldH; River::gHooks.grass = grassColor;
    buildStrip(gMeshes.southHills, 0, LROW_PATCH0); buildStrip(gMeshes.northHills, LROW_PATCH1, LNZ);
    chooseLake();                                                                             // lake bowl first: the mountain foot and the outer ground are carved around it
    buildMountains(gMeshes.mountains);
    buildLake();
    buildOuter(gMeshes.outer);
    buildTrackMeshes(Road::gNet.trk, Road::gNet.trkV);
}

} // namespace Terrain
