// Sunny Drift - green trees: OpenGL ES 3 rendering + planting (C++ port of the HTML "Trees" + "Tree LOD" blocks).
//  * leaves: alpha-tested cards with the leaf texture, gentle wind sway (trSway in the HTML)
//  * bark: 6-sided tubes with the bark texture
//  * every tree is one instance (x, z, scale, rotation); trees within NEAR metres are drawn as the full model,
//    farther ones as a camera-facing billboard baked once from the model (same idea as bakeProto / updateTreeLOD)
#pragma once
#include <GLES3/gl3.h>
#include "sun_light.h"
#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <random>
#include <unordered_set>
#include <unordered_map>
#include "tree_model.h"
#include "road.h"
#include "terrain.h"
#include "village.h"        // houses: no trees on or next to them
#include "nature_plan.h"
#include "quality.h"
#include "tunnel.h"    // waterfall: no trees in the stream

namespace TreeGL {

// ---------- tunables (same numbers as the HTML) ----------
const float NEAR_DIST = 38.f, HYST = 8.f;            // low-poly LOD: full model only very close (was 70 / 14)
const float MAX_DIST = 600.f;                         // distance culling: nothing farther than this is drawn at all
const float CULL_R = 7.f;                             // bounding radius (m, before tree scale) used for frustum culling
const int   GREEN_TREES = 240, GROVE_TREES = 170;    // 400 total in the HTML = 330 green + 70 maple; maple is not part of this port

struct Tree { float x, z, s, r, y; };                 // y = ground height (the hills)

static std::vector<Tree> gTrees;
static std::vector<uint8_t> gIsNear;
static GLuint gMeshProg = 0, gBillProg = 0, gNearVBO = 0, gFarVBO = 0;
static GLuint gLeafVAO = 0, gBarkVAO = 0, gBillVAO = 0, gLeafTex = 0, gBarkTex = 0, gBillTex = 0;
static GLuint gLeafVBO = 0, gLeafIBO = 0, gBarkVBO = 0, gBarkIBO = 0, gQuadVBO = 0;
static int gLeafIdx = 0, gBarkIdx = 0;
static float gBbHalfW = 1, gBbY0 = 0, gBbH = 1;
static GLint uM_VP, uM_Wind, uM_Sway, uM_Tex, uM_Cam, uM_Tint, uM_Emis, uM_Alpha, uM_Leaf;
static GLint uB_VP, uB_Right, uB_Size, uB_Tex, uB_Cam;

static const char* MESH_VS =
    "#version 300 es\n"
    "layout(location=0) in vec3 p; layout(location=1) in vec3 n; layout(location=2) in vec2 t; layout(location=3) in vec4 inst; layout(location=4) in float instY;\n"
    "uniform mat4 uVP; uniform float uWind; uniform float uSway;\n"
    "out vec2 vt; out vec3 vn; out vec3 wp;\n"
    "void main(){\n"
    " vec3 q = p;\n"
    " if (uSway > 0.5){\n"                                   // trSway(): wind moves the upper part of the crown
    "  float wv = sin(uWind*1.5 + inst.x*.11 + inst.y*.09)*.6 + sin(uWind*2.9 + q.x*1.3 + q.z*1.1 + inst.x*.2)*.4;\n"
    "  float hh = max(q.y - 1.5, 0.);\n"
    "  q.x += wv*.03*hh; q.z += wv*.02*hh;\n"
    " }\n"
    " q *= inst.z;\n"
    " float c = cos(inst.w), s = sin(inst.w);\n"
    " mat3 Ry = mat3(c,0.,-s, 0.,1.,0., s,0.,c);\n"
    " wp = Ry*q + vec3(inst.x, instY, inst.y); vn = Ry*n; vt = t;\n"
    " gl_Position = uVP*vec4(wp,1.);\n"
    "}";
static const char* MESH_FS =
    "#version 300 es\n"
    "precision highp float;\n"
    "in vec2 vt; in vec3 vn; in vec3 wp;\n"
    "uniform sampler2D uTex; uniform vec3 uCam, uTint, uEmis; uniform float uAlpha, uLeaf;\n"
    "out vec4 o;\n"
    "float h3(vec3 p){ p = fract(p*0.1031); p += dot(p, p.yzx + 33.33); return fract((p.x + p.y)*p.z); }\n"
    "void main(){\n"
    " vec4 tx = texture(uTex, vt);\n"
    " if (uAlpha > 0. && tx.a < uAlpha) discard;\n"
    " vec3 V = uCam - wp; float dist = length(V); V /= dist;\n"
    " vec3 L = SUNL;\n"
    " vec3 N = normalize(vn); vec3 c;\n"
    " if (uLeaf < .5){\n"
    "  if (!gl_FrontFacing) N = -N;\n"
    "  float d = max(dot(N, L), 0.0);\n"
    "  c = tx.rgb*uTint*(0.35 + 0.75*d) + uEmis;\n"
    " } else {\n"
    "  float v = h3(floor(wp*1.6));\n"
    "  vec3 alb = tx.rgb*uTint*mix(vec3(0.80,0.90,0.68), vec3(1.10,1.05,0.78), v);\n"
    "  alb *= 0.86 + 0.14*smoothstep(0.0, 0.5, vt.y);\n"
    "  N = normalize(N + vec3(0.0, 0.55, 0.0));\n"
    "  float nd = dot(N, L); float d = max(nd, 0.0), wrap = max(nd*0.5 + 0.5, 0.0);\n"
    "  vec3 amb = mix(vec3(0.24,0.29,0.16), vec3(0.50,0.66,0.95), N.y*0.5 + 0.5)*0.85;\n"
    "  c = alb*(amb + vec3(1.08,1.0,0.82)*(0.55*d + 0.35*wrap));\n"
    "  c += alb*vec3(0.75,0.95,0.25)*pow(max(dot(-V, L), 0.0), 3.0)*0.45;\n"
    "  c += uEmis;\n"
    " }\n"
    " c = mix(c, vec3(0.62,0.80,0.95), clamp(dist/3750.0, 0.0, 1.0));\n"
    " o = vec4(c,1.);\n"
    "}\n";
static const char* BILL_VS =
    "#version 300 es\n"
    "layout(location=0) in vec2 q; layout(location=3) in vec4 inst; layout(location=4) in float instY;\n"
    "uniform mat4 uVP; uniform vec3 uRight; uniform vec3 uSize;\n"   // uSize = (half width, y0, height) of the baked model
    "out vec2 vt; out vec3 wp;\n"
    "void main(){\n"
    " wp = vec3(inst.x, instY, inst.y) + uRight*(q.x*uSize.x*inst.z) + vec3(0., (uSize.y + q.y*uSize.z)*inst.z, 0.);\n"
    " vt = vec2(q.x*.5 + .5, q.y); gl_Position = uVP*vec4(wp,1.);\n"
    "}";
static const char* BILL_FS =
    "#version 300 es\nprecision mediump float;\n"
    "in vec2 vt; in vec3 wp; uniform sampler2D uTex; uniform vec3 uCam; out vec4 o;\n"
    "void main(){\n"
    " vec4 tx = texture(uTex, vt); if (tx.a < 0.4) discard;\n"
    " vec3 c = tx.rgb / max(tx.a, 0.001);\n"                                                                          // un-darken: the baked picture is black where empty, mip levels / filtering blend that black into the edge colour
    " c = mix(c, vec3(0.62,0.80,0.95), clamp(length(uCam-wp)/3750.0, 0.0, 1.0));\n"
    " o = vec4(c,1.);\n"
    "}";

static GLuint compileSh(GLenum t, const char* s){ GLuint sh = glCreateShader(t); SunLight::shaderSource(sh, s); glCompileShader(sh); return sh; }
static GLuint makeProg(const char* vs, const char* fs){
    GLuint p = glCreateProgram(); glAttachShader(p, compileSh(GL_VERTEX_SHADER, vs)); glAttachShader(p, compileSh(GL_FRAGMENT_SHADER, fs));
    glLinkProgram(p); SunLight::attach(p); return p;
}

// raw RGBA file: int32 width, int32 height, then w*h*4 bytes
static GLuint makeTexture(const std::vector<char>& f){
    if (f.size() < 8) return 0;
    int w, h; memcpy(&w, f.data(), 4); memcpy(&h, f.data() + 4, 4);
    GLuint t; glGenTextures(1, &t); glBindTexture(GL_TEXTURE_2D, t);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, f.data() + 8);   // row 0 = v 0 (three.js flipY = false)
    glGenerateMipmap(GL_TEXTURE_2D);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_BASE_LEVEL, 1);                 // low texture quality: start at mip 1 (half resolution, a quarter of the bandwidth)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    return t;
}

static void makePart(const TreeModel::Mesh& m, GLuint tex, GLuint& vao, GLuint& vbo, GLuint& ibo, int& idxCount){
    (void)tex;
    const int n = m.vertexCount();
    std::vector<float> vb((size_t)n * 8);
    for (int i = 0; i < n; i++){
        for (int k = 0; k < 3; k++){ vb[i*8+k] = m.pos[i*3+k]; vb[i*8+3+k] = m.nrm[i*3+k]; }
        vb[i*8+6] = m.uv[i*2]; vb[i*8+7] = m.uv[i*2+1];
    }
    glGenVertexArrays(1, &vao); glBindVertexArray(vao);
    glGenBuffers(1, &vbo); glBindBuffer(GL_ARRAY_BUFFER, vbo); glBufferData(GL_ARRAY_BUFFER, vb.size() * 4, vb.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 32, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 32, (void*)12);
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 32, (void*)24);
    glGenBuffers(1, &ibo); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, m.idx.size() * 2, m.idx.data(), GL_STATIC_DRAW);
    idxCount = (int)m.idx.size();
    glBindBuffer(GL_ARRAY_BUFFER, gNearVBO);                                   // per-instance (x, z, scale, rotation, y)
    glEnableVertexAttribArray(3); glVertexAttribPointer(3, 4, GL_FLOAT, GL_FALSE, 20, (void*)0); glVertexAttribDivisor(3, 1);
    glEnableVertexAttribArray(4); glVertexAttribPointer(4, 1, GL_FLOAT, GL_FALSE, 20, (void*)16); glVertexAttribDivisor(4, 1);
    glBindVertexArray(0);
}

static void setMeshUniforms(const float* VP, const float* eye, float t){
    glUseProgram(gMeshProg);
    glUniformMatrix4fv(uM_VP, 1, GL_FALSE, VP); glUniform1f(uM_Wind, t); glUniform3fv(uM_Cam, 1, eye); glUniform1i(uM_Tex, 0);
}
static void drawModel(int instances){
    glActiveTexture(GL_TEXTURE0);
    // bark
    glBindTexture(GL_TEXTURE_2D, gBarkTex); glUniform1f(uM_Sway, 0); glUniform1f(uM_Alpha, 0); glUniform1f(uM_Leaf, 0);
    glUniform3f(uM_Tint, 1.f, 1.f, 1.f); glUniform3f(uM_Emis, 0.04f, 0.04f, 0.035f);
    glBindVertexArray(gBarkVAO); glDrawElementsInstanced(GL_TRIANGLES, gBarkIdx, GL_UNSIGNED_SHORT, (void*)0, instances);
    // leaves (alpha-tested, swaying, slightly warm green tint + soft green glow like the HTML material)
    glBindTexture(GL_TEXTURE_2D, gLeafTex); glUniform1f(uM_Sway, 1); glUniform1f(uM_Alpha, 0.5f); glUniform1f(uM_Leaf, 1);
    glUniform3f(uM_Tint, 1.0f, 1.05f, 0.88f); glUniform3f(uM_Emis, 0.012f, 0.03f, 0.008f);
    glBindVertexArray(gLeafVAO); glDrawElementsInstanced(GL_TRIANGLES, gLeafIdx, GL_UNSIGNED_SHORT, (void*)0, instances);
    glBindVertexArray(0);
}

// ---------- planting (plantTree / plantGrove / randClear from the HTML) ----------
// Trees stand on the rolling ground (Terrain::fieldH). "Clear" = at least ~16 m from the edge of every road (like farFromRoad(16) in the HTML).
static std::mt19937 gRng(20260101);
static float rnd(){ return std::uniform_real_distribution<float>(0.f, 1.f)(gRng); }
static float gauss(){ return (rnd() + rnd() + rnd() - 1.5f) / 0.75f; }          // ~N(0,1)-ish, in [-2,2]
static bool treeOk(float x, float z, float roadHalfWidth){ (void)roadHalfWidth; return Road::clearance(x, z) > 16.5f && std::fabs(River::riverSd(x, z)) > 34.0 && Terrain::trackDist(x, z) > 12.0 && !Village::blocked(x, z, 5.f); }   // also off the dirt track (HTML isClear: trackDist > 12)   // also keep the river clear (HTML: |riverSd| < r+32)
static void plant(float x, float z){ const float s = 0.8f + rnd() * 0.9f, r = rnd() * 6.2831853f; gTrees.push_back({x, z, s, r, (float)Terrain::fieldH(x, z)}); }   // stands on the hill
static bool randClear(float rw, float& x, float& z){
    for (int t = 0; t < 60; t++){
        float a = rnd() * 6.2831853f, d = 30.f + rnd() * 640.f; x = std::cos(a) * d; z = std::sin(a) * d;
        if (treeOk(x, z, rw)) return true;
    }
    return false;
}
static int plantGrove(int n, float rad, float rw){
    float cx, cz; if (!randClear(rw, cx, cz)) return 0;
    int done = 0;
    for (int k = 0; k < n * 8 && done < n; k++){
        float x = cx + gauss() * rad * 0.5f, z = cz + gauss() * rad * 0.5f;
        if (!treeOk(x, z, rw)) continue;
        bool tooClose = false;
        for (const Tree& t : gTrees){ float dx = t.x - x, dz = t.z - z; if (dx*dx + dz*dz < 9.f){ tooClose = true; break; } }
        if (tooClose) continue;
        plant(x, z); done++;
    }
    return done;
}
static void plantAll(float roadHalfWidth){
    gTrees.clear(); int guard = 0;
    while ((int)gTrees.size() < GROVE_TREES && guard++ < 400) plantGrove(8 + (int)(rnd() * 11), 14.f + rnd() * 10.f, roadHalfWidth);   // groves of 8-18
    while ((int)gTrees.size() < GREEN_TREES && guard++ < 2000){ float x, z; if (randClear(roadHalfWidth, x, z)) plant(x, z); }          // lone trees
    gIsNear.assign(gTrees.size(), 0);
}

// ---------- billboard bake: render the tree once from the side into a texture ----------
static void bakeBillboard(const TreeModel::Model& M){
    gBbHalfW = M.halfWidth * 1.02f; gBbY0 = M.minY; float y1 = M.maxY * 1.01f; gBbH = y1 - gBbY0;
    const int W = 256; int H = std::max(64, (int)std::lround(W * gBbH / (2 * gBbHalfW) / 8.0) * 8); if (H > 512) H = 512;   // 256 px wide: a sharp picture of the real tree
    GLint oldFbo = 0, vp[4]; glGetIntegerv(GL_FRAMEBUFFER_BINDING, &oldFbo); glGetIntegerv(GL_VIEWPORT, vp);
    glGenTextures(1, &gBillTex); glBindTexture(GL_TEXTURE_2D, gBillTex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, W, H, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    GLuint fbo, depth; glGenFramebuffers(1, &fbo); glBindFramebuffer(GL_FRAMEBUFFER, fbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, gBillTex, 0);
    glGenRenderbuffers(1, &depth); glBindRenderbuffer(GL_RENDERBUFFER, depth);
    glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT16, W, H);
    glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, depth);
    if (glCheckFramebufferStatus(GL_FRAMEBUFFER) == GL_FRAMEBUFFER_COMPLETE){
        glViewport(0, 0, W, H); glClearColor(0, 0, 0, 0); glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        glEnable(GL_DEPTH_TEST);
        float P[16] = {0}; P[0] = 1.f / gBbHalfW; P[5] = 2.f / gBbH; P[10] = -0.01f; P[13] = -(y1 + gBbY0) / gBbH; P[15] = 1;   // side-on orthographic
        const float one[5] = {0, 0, 1, 0, 0}, eye[3] = {0, 0, 0};
        glBindBuffer(GL_ARRAY_BUFFER, gNearVBO); glBufferData(GL_ARRAY_BUFFER, sizeof(one), one, GL_STREAM_DRAW);
        setMeshUniforms(P, eye, 0.f); drawModel(1);
    }
    glBindFramebuffer(GL_FRAMEBUFFER, oldFbo); glDeleteRenderbuffers(1, &depth); glDeleteFramebuffers(1, &fbo);
    glViewport(vp[0], vp[1], vp[2], vp[3]);
    glBindTexture(GL_TEXTURE_2D, gBillTex); glGenerateMipmap(GL_TEXTURE_2D);
}

// ---------- public API ----------
static bool gReady = false;

// Call once with a current GL context. rawBlob = tree_raw.bin, meta = tree_meta.txt, leafTex/barkTex = *.rgba assets.
static bool init(const std::vector<char>& rawBlob, const std::vector<char>& meta, const std::vector<char>& leafTex,
                 const std::vector<char>& barkTex, float roadHalfWidth){
    TreeModel::Meta M; if (!TreeModel::parseMeta(std::string(meta.begin(), meta.end()), M)) return false;
    if (rawBlob.size() < (size_t)(M.t0 + M.t1)) return false;
    TreeModel::Model model;
    if (!TreeModel::parse((const uint8_t*)rawBlob.data(), rawBlob.size() - M.t0 - M.t1, M, model)) return false;

    gMeshProg = makeProg(MESH_VS, MESH_FS); gBillProg = makeProg(BILL_VS, BILL_FS);
    uM_VP = glGetUniformLocation(gMeshProg, "uVP"); uM_Wind = glGetUniformLocation(gMeshProg, "uWind"); uM_Sway = glGetUniformLocation(gMeshProg, "uSway");
    uM_Tex = glGetUniformLocation(gMeshProg, "uTex"); uM_Cam = glGetUniformLocation(gMeshProg, "uCam"); uM_Tint = glGetUniformLocation(gMeshProg, "uTint");
    uM_Emis = glGetUniformLocation(gMeshProg, "uEmis"); uM_Alpha = glGetUniformLocation(gMeshProg, "uAlpha"); uM_Leaf = glGetUniformLocation(gMeshProg, "uLeaf");
    uB_VP = glGetUniformLocation(gBillProg, "uVP"); uB_Right = glGetUniformLocation(gBillProg, "uRight"); uB_Size = glGetUniformLocation(gBillProg, "uSize");
    uB_Tex = glGetUniformLocation(gBillProg, "uTex"); uB_Cam = glGetUniformLocation(gBillProg, "uCam");

    glGenBuffers(1, &gNearVBO); glGenBuffers(1, &gFarVBO);
    gLeafTex = makeTexture(leafTex); gBarkTex = makeTexture(barkTex);
    makePart(model.leaf, gLeafTex, gLeafVAO, gLeafVBO, gLeafIBO, gLeafIdx);
    makePart(model.bark, gBarkTex, gBarkVAO, gBarkVBO, gBarkIBO, gBarkIdx);

    const float quad[8] = {-1, 0,  1, 0,  -1, 1,  1, 1};                       // billboard quad: x -1..1, y 0..1
    glGenVertexArrays(1, &gBillVAO); glBindVertexArray(gBillVAO);
    glGenBuffers(1, &gQuadVBO); glBindBuffer(GL_ARRAY_BUFFER, gQuadVBO); glBufferData(GL_ARRAY_BUFFER, sizeof(quad), quad, GL_STATIC_DRAW);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 8, (void*)0);
    glBindBuffer(GL_ARRAY_BUFFER, gFarVBO);
    glEnableVertexAttribArray(3); glVertexAttribPointer(3, 4, GL_FLOAT, GL_FALSE, 20, (void*)0); glVertexAttribDivisor(3, 1);
    glEnableVertexAttribArray(4); glVertexAttribPointer(4, 1, GL_FLOAT, GL_FALSE, 20, (void*)16); glVertexAttribDivisor(4, 1);
    glBindVertexArray(0);

    bakeBillboard(model);
    plantAll(roadHalfWidth);
    gReady = true; return true;
}

// VP = projection*view (column-major), V = view matrix (for the billboard's right vector), eye = camera position
static void draw(const float* VP, const float* V, const float* eye, float timeSec){
    if (!gReady) return;
    static std::vector<float> nearB, farB; nearB.clear(); farB.clear();
    const float n2 = NEAR_DIST * NEAR_DIST, h2 = (NEAR_DIST + HYST) * (NEAR_DIST + HYST), m2 = MAX_DIST * MAX_DIST;
    float pl[6][4];                                                                   // frustum planes from the column-major view-projection matrix
    for (int i = 0; i < 6; i++){ const int a = i >> 1; const float sg = (i & 1) ? 1.f : -1.f;
        for (int j = 0; j < 4; j++) pl[i][j] = VP[j*4 + 3] + sg * VP[j*4 + a];
        const float l = std::sqrt(pl[i][0]*pl[i][0] + pl[i][1]*pl[i][1] + pl[i][2]*pl[i][2]); if (l > 1e-6f) for (int j = 0; j < 4; j++) pl[i][j] /= l; }
    for (size_t k = 0; k < gTrees.size(); k++){
        const Tree& t = gTrees[k]; float dx = t.x - eye[0], dz = t.z - eye[2], d2 = dx*dx + dz*dz;
        if (d2 > m2) { gIsNear[k] = 0; continue; }                                      // too far: culled
        { const float cy = t.y + 3.f * t.s, rad = CULL_R * t.s; bool out = false;      // outside the view: culled (no draw, no GPU upload)
          for (int i = 0; i < 6 && !out; i++) if (pl[i][0]*t.x + pl[i][1]*cy + pl[i][2]*t.z + pl[i][3] < -rad) out = true;
          if (out) continue; }
        bool near = gIsNear[k] ? d2 < h2 : d2 < n2; gIsNear[k] = near;               // hysteresis so trees do not flicker between LODs
        std::vector<float>& B = near ? nearB : farB; B.push_back(t.x); B.push_back(t.z); B.push_back(t.s); B.push_back(t.r); B.push_back(t.y);
    }
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glActiveTexture(GL_TEXTURE0);
    int nn = (int)(nearB.size() / 5), nf = (int)(farB.size() / 5);
    if (nn){
        glBindBuffer(GL_ARRAY_BUFFER, gNearVBO); glBufferData(GL_ARRAY_BUFFER, nearB.size() * 4, nearB.data(), GL_STREAM_DRAW);
        setMeshUniforms(VP, eye, timeSec); drawModel(nn);
    }
    if (nf){
        glBindBuffer(GL_ARRAY_BUFFER, gFarVBO); glBufferData(GL_ARRAY_BUFFER, farB.size() * 4, farB.data(), GL_STREAM_DRAW);
        glUseProgram(gBillProg); glUniformMatrix4fv(uB_VP, 1, GL_FALSE, VP); glUniform3fv(uB_Cam, 1, eye); glUniform1i(uB_Tex, 0);
        float rx = V[0], rz = V[8], l = std::sqrt(rx*rx + rz*rz); if (l < 1e-6f) l = 1;                  // camera-right, kept horizontal
        glUniform3f(uB_Right, rx / l, 0.f, rz / l); glUniform3f(uB_Size, gBbHalfW, gBbY0, gBbH);
        glBindTexture(GL_TEXTURE_2D, gBillTex);
        glBindVertexArray(gBillVAO); glDrawArraysInstanced(GL_TRIANGLE_STRIP, 0, 4, nf); glBindVertexArray(0);
    }
}

// =====================================================================================================================
// Pine & spruce forest: dark green cones planted densely on the mountain slopes, along the roads and on the foothills.
// Three levels of detail (full cones close, simple cones in the middle, 2-cone "needle" far away), all instanced:
// one draw call per species and level (6 in total), distance + frustum culled on the CPU.
// =====================================================================================================================
static const char* CO_VS =
    "#version 300 es\n"
    "layout(location=0) in vec3 p; layout(location=1) in vec3 n; layout(location=2) in vec3 c; layout(location=3) in vec4 inst; layout(location=4) in float instY; layout(location=5) in vec2 uv; layout(location=6) in float fl; layout(location=7) in vec2 sway;\n"
    "uniform mat4 uVP; uniform float uTime; out vec3 vc; out vec3 vn; out vec3 wp; out vec2 vuv; flat out float vfl;\n"
    "void main(){\n"
    " float cs = cos(inst.w), sn = sin(inst.w); mat3 Ry = mat3(cs,0.,-sn, 0.,1.,0., sn,0.,cs);\n"
    " vec3 q = p; float hh = max(q.y, 0.0)/16.0;\n"                                            // wind: the whole tree leans a little, branches also flutter
    " float ph = uTime*1.4 + inst.x*0.11 + inst.y*0.07;\n"
    " q.x += sin(ph)*0.35*hh*hh; q.z += cos(ph*0.8)*0.22*hh*hh;\n"
    " if (fl > 0.5 && fl < 1.5) q.y += sin(uTime*2.6 + p.x*2.1 + p.z*1.7 + inst.x*0.3)*0.10*uv.x*uv.x;\n"
    " wp = Ry*(q*inst.z) + vec3(inst.x, instY, inst.y); vn = Ry*n; vuv = uv; vfl = fl;\n"
    " wp.xz += sway * (hh*hh);\n"                                                            // a tree hit by the car swings: the foot stays, the crown moves most
    " float v = fract(sin(dot(inst.xy, vec2(12.9898, 78.233))) * 43758.5453);\n"      // each tree a slightly different green
    " vc = c * (0.85 + 0.32*v) * mix(vec3(1.0), vec3(1.08, 1.0, 0.86), fract(v*7.3));\n"
    " gl_Position = uVP*vec4(wp,1.);\n"
    "}";
static const char* CO_FS =
    "#version 300 es\nprecision highp float;\n"
    "in vec3 vc; in vec3 vn; in vec3 wp; in vec2 vuv; flat in float vfl; uniform vec3 uCam; uniform float uBake; out vec4 o;\n"
    "float h3(vec3 p){ p = fract(p*0.1031); p += dot(p, p.yzx + 33.33); return fract((p.x + p.y)*p.z); }\n"
    "void main(){\n"
    " vec3 V = uCam - wp; float dist = length(V); V /= dist;\n"
    " vec3 N = normalize(vn); if (!gl_FrontFacing) N = -N;\n"
    " vec3 L = (uBake > 0.5) ? normalize(vec3(0.4, 0.8, 0.3)) : SUNL;\n"
    " float nd = dot(N, L); float d = max(nd, 0.0), wrap = max(nd*0.5 + 0.5, 0.0);\n"
    " vec3 alb = vc;\n"
    " if (vfl > 1.5){\n"                                                                          // trunk: vertical bark furrows
    "   float br = h3(floor(vec3(wp.x*7.0, wp.y*0.7, wp.z*7.0))); alb *= 0.65 + 0.7*br;\n"
    " } else if (vfl > 0.5){\n"                                                                  // a branch: needles combed along both sides of a brown stem
    "   float sd = abs(vuv.y); float stem = 1.0 - smoothstep(0.02, 0.05, sd);\n"
    "   float pos = vuv.x*30.0 - sd*3.6 + step(0.0, vuv.y)*0.5; float id = floor(pos); float s = fract(pos);\n"
    "   float rn = dist < 70.0 ? h3(vec3(id, step(0.0, vuv.y), floor(wp.x*0.5 + wp.z*0.5))) : fract(id*0.618 + step(0.0, vuv.y)*0.37);\n"                  // every needle: its own length, tone
    "   float nd = smoothstep(0.0, 0.12, s) * (1.0 - smoothstep(0.50, 0.72, s));\n"
    "   float reach = (0.55 + 0.45*rn) * (1.0 - 0.45*vuv.x);\n"
    "   if (max(nd*step(sd, reach), stem) < 0.42) discard;\n"
    "   alb *= (0.85 + 0.35*rn) * (0.93 + 0.17*sd) * (0.50 + 0.50*smoothstep(0.0, 0.55, vuv.x));\n"                                            // paler needle tips, darker near the stem (self-shadow)
    "   alb = mix(alb, vec3(0.24, 0.16, 0.09), stem*0.35);\n"
    " } else if (dist < 160.0){ float nz = h3(floor(wp*vec3(2.2, 3.4, 2.2))) * 0.6 + h3(floor(wp*vec3(5.5, 8.0, 5.5))) * 0.4;\n"   // needle clumps / branch lumps
    "   alb *= mix(1.0, 0.80 + 0.45*nz, 1.0 - smoothstep(60.0, 160.0, dist)); }\n"
    " vec3 sky = vec3(0.50, 0.66, 0.95), gnd = vec3(0.26, 0.30, 0.18);\n"
    " vec3 amb = mix(gnd, sky, N.y*0.5 + 0.5) * 0.95 + vec3(0.06, 0.09, 0.05);\n"
    " vec3 col = alb * (amb + vec3(1.10, 1.00, 0.82)*(0.62*d + 0.32*wrap));\n"
    " col += alb * vec3(0.78, 0.92, 0.32) * pow(max(dot(-V, L), 0.0), 2.5) * 0.20;\n"                  // sun shining through the needles
    " col += vec3(0.34, 0.44, 0.32) * pow(1.0 - max(dot(N, V), 0.0), 3.0) * 0.06;\n"                     // soft sky rim
    " float lum = dot(col, vec3(0.299, 0.587, 0.114)); col = mix(vec3(lum), col, 0.90);\n col = pow(col, vec3(0.97));\n"
    " float fog = 1.0 - exp(-pow(dist/2850.0, 1.35));\n"
    " col = mix(col, vec3(0.72, 0.87, 0.98), clamp(fog, 0.0, 1.0));\n"
    " o = vec4(col, 1.0);\n"
    "}";

// ---- far trees as camera-facing billboards (Normal quality): the tree is baked once from the side into a texture and drawn as one quad that always turns to the camera ----
static const char* CB_VS =
    "#version 300 es\n"
    "layout(location=0) in vec2 q; layout(location=3) in vec4 inst; layout(location=4) in float instY;\n"
    "uniform mat4 uVP; uniform vec3 uCam; uniform vec3 uSize; uniform float uTime; out vec2 vuv; out vec3 vtint; out float vdist; flat out vec2 vlay; flat out float vmix;\n"      // uSize = half width, bottom y, height (tree scale 1)
    "void main(){\n"
    " vec2 d = uCam.xz - inst.xy; float l = max(length(d), 1e-3); vec2 f = d / l;\n"
    " vec3 right = vec3(f.y, 0., -f.x);\n"                                                                      // upright, turns round the vertical axis to face the camera
    " vec3 base = vec3(inst.x, instY, inst.y);\n"
    " vec3 wp = base + right * (q.x * uSize.x * inst.z) + vec3(0., uSize.y + q.y * uSize.z, 0.) * inst.z;\n"
    " { float hh = max(uSize.y + q.y * uSize.z, 0.0) / 16.0; float ph = uTime*1.4 + inst.x*0.11 + inst.y*0.07;\n"          // same wind lean as the 3D tree
    "   vec2 sw = vec2(sin(ph)*0.35, cos(ph*0.8)*0.22) * hh*hh * inst.z; float cs = cos(inst.w), sn = sin(inst.w);\n"
    "   wp.x += cs*sw.x + sn*sw.y; wp.z += -sn*sw.x + cs*sw.y; }\n"
    " vuv = vec2(q.x * 0.5 + 0.5, q.y);\n"
    // which of the 8 baked views (taken from 8 directions round the tree) looks like the real tree from here: the two nearest are cross-faded
    " float ang = atan(f.x, f.y); if (ang < 0.) ang += 6.2831853;\n"
    " float u = ang * (8.0 / 6.2831853); float l0 = floor(u); vmix = u - l0; if (l0 >= 8.) l0 -= 8.;\n"
    " vlay = vec2(l0, (l0 >= 7.) ? 0. : l0 + 1.);\n"
    " float v = fract(sin(dot(inst.xy, vec2(12.9898, 78.233))) * 43758.5453);\n"                                  // same per-tree green variation as the 3D trees
    " vtint = (0.85 + 0.32 * v) / 0.85 * mix(vec3(1.0), vec3(1.08, 1.0, 0.86), fract(v * 7.3));\n"
    " vdist = length(uCam - base);\n"
    " gl_Position = uVP * vec4(wp, 1.);\n"
    "}";
static const char* CB_FS =
    "#version 300 es\nprecision mediump float; precision mediump sampler2DArray;\n"
    "in vec2 vuv; in vec3 vtint; in float vdist; flat in vec2 vlay; flat in float vmix; uniform sampler2DArray uTex; out vec4 o;\n"
    "void main(){\n"
    " vec4 t = mix(texture(uTex, vec3(vuv, vlay.x)), texture(uTex, vec3(vuv, vlay.y)), vmix);\n"
    " if (t.a < 0.38) discard;\n"
    " vec3 c = t.rgb / max(t.a, 0.001) * vtint;\n"
    " float fg = 1.0 - exp(-pow(vdist / 2850.0, 1.35));\n"
    " o = vec4(mix(c, vec3(0.72, 0.87, 0.98), clamp(fg, 0.0, 1.0)), 1.0);\n"
    "}";
const int CB_VIEWS = 8, CB_W = 384, CB_H = 768;   // 8 views round the tree, each a lit 384x768 picture (keep CB_VIEWS = 8 in sync with the shader)
static GLuint gCbProg = 0, gCbTex[2] = {0, 0}, gCbVAO[2] = {0, 0}, gCbInst[2] = {0, 0}, gCbQuad = 0;
static float gCbHW[2] = {1, 1}, gCbY0[2] = {0, 0}, gCbH[2] = {1, 1};
static GLint uCb_VP = -1, uCb_Cam = -1, uCb_Size = -1, uCb_Tex = -1, uCb_Time = -1;
static bool gCbReady = false;
const float CO_BB_DIST = 330.f;   // billboards start where the 3D tree has already faded to its flat far colour, so there is no visible switch

struct CoTree { float x, z, s, r, y; uint8_t sp; };
static std::vector<CoTree> gCo;
static GLuint gCoProg = 0, gCoVAO[2][4], gCoVBO[2][4], gCoIBO[2][4], gCoInst[2][4]; static int gCoIdx[2][4]; static GLint uCo_VP = -1, uCo_Cam = -1, uCo_Time = -1, uCo_Bake = -1;
static bool gCoReady = false;
const float CO_MAX_DIST = 2300.f, CO_LOD0 = 80.f, CO_LOD1 = 260.f;

// Planting is spread over many frames (time-sliced) so the game starts at once instead of freezing while ~28000 trees are placed.
// Trees that are planted but not "loaded" yet (planting still running) are drawn as 2D pictures (billboards) only; the 3D models switch on when loading is done.
static bool gCoDone = false;                       // true once every tree is planted (3D models + collision are enabled then)
struct CoPlanter { std::mt19937 rng{0x5eed1234u}; std::unordered_set<long long> used; int phase = 0, t = 0, n = 0; };
static CoPlanter gPl;

// plant for at most budgetSec seconds; returns true when ALL trees are planted
static bool coPlantStep(double budgetSec){
    using Clk = std::chrono::steady_clock; const Clk::time_point t0 = Clk::now();
    auto over = [&]{ return std::chrono::duration<double>(Clk::now() - t0).count() > budgetSec; };
    CoPlanter& P = gPl; auto U = [&]{ return std::uniform_real_distribution<float>(0.f, 1.f)(P.rng); };
    auto freeCell = [&](float x, float z, float cell){ const long long k = ((long long)std::floor(x / cell) << 32) ^ (long long)(std::floor(z / cell) + 100000); return P.used.insert(k).second; };
    auto hs = [](float x, float y){ const float h = std::sin(x*127.1f + y*311.7f) * 43758.5453f; return h - std::floor(h); };
    auto vn = [&](float x, float y){ const float ix = std::floor(x), iy = std::floor(y), fx = x - ix, fy = y - iy, u = fx*fx*(3 - 2*fx), v = fy*fy*(3 - 2*fy);
        return (hs(ix, iy)*(1-u) + hs(ix+1, iy)*u)*(1-v) + (hs(ix, iy+1)*(1-u) + hs(ix+1, iy+1)*u)*v; };
    auto clump = [&](float x, float z){ return 0.65f*vn(x*0.012f + 9.f, z*0.012f + 4.f) + 0.35f*vn(x*0.05f, z*0.05f); };   // forest patches with glades
    auto sstep = [](float a, float b, float x){ x = std::min(1.f, std::max(0.f, (x - a) / (b - a))); return x*x*(3 - 2*x); };
    auto ground = [&](float x, float z){ return Terrain::inLattice(x, z) ? (float)Terrain::fieldH(x, z) : (float)Terrain::outerH(x, z); };
    auto add = [&](float x, float z, float y, float s){ gCo.push_back({x, z, s, U() * 6.2831853f, y, (uint8_t)(U() < 0.55f ? 0 : 1)}); };
    int& t = P.t; int& n = P.n;

    // 1) along the roads: dense bands of forest 12-70 m from the road edge
    if (P.phase == 0){
        for (; t < 260000 && n < 5200; t++){
            if ((t & 63) == 0 && over()) return false;
            const float x = (U() * 2 - 1) * 1350.f, z = (U() * 2 - 1) * 960.f;
            const float c = Road::clearance(x, z); if (c < 12.f || c > 75.f) continue;
            const float p = (0.20f + 0.80f * sstep(0.34f, 0.60f, clump(x, z))) * (1.f - 0.6f * sstep(40.f, 75.f, c)); if (U() > p) continue;
            if (Village::blocked(x, z, 6.f) || Tunnel::blocked(x, z, 8.0) || !freeCell(x, z, 5.f)) continue;
            if (std::fabs(River::riverSd(x, z)) < 36.0 || Terrain::trackDist(x, z) < 9.0) continue;
            add(x, z, ground(x, z), 0.75f + U() * 0.65f); n++;
        }
        P.phase = 1; t = 0; n = 0;
    }
    // 2) foothills between the playable ground and the mountain ring
    if (P.phase == 1){
        for (; t < 90000 && n < 3600; t++){
            if ((t & 63) == 0 && over()) return false;
            const float a = U() * 6.2831853f, r = 960.f + U() * 360.f, x = std::cos(a) * r, z = std::sin(a) * r;
            if (clump(x, z) < 0.40f && U() > 0.25f) continue;
            if (Terrain::lakeDn(x, z) < 1.95) continue;                                                    // no trees in the lake
            if (Road::clearance(x, z) < 12.f || Village::blocked(x, z, 6.f) || Tunnel::blocked(x, z, 8.0) || !freeCell(x, z, 6.f)) continue;
            if (std::fabs(River::riverSd(x, z)) < 40.0 || Terrain::trackDist(x, z) < 9.0) continue;
            add(x, z, ground(x, z), 0.9f + U() * 0.8f); n++;
        }
        P.phase = 2; t = 0; n = 0;
    }
    // 3) mountain slopes: forest up to the tree line (~230 m), thinning out; none on cliffs
    if (P.phase == 2){
        for (; t < 240000 && n < 19000; t++){
            if ((t & 63) == 0 && over()) return false;
            const float a = U() * 6.2831853f, r = (float)Terrain::MTN_R0 + 15.f + U() * (float)(Terrain::MTN_R1 - Terrain::MTN_R0 - 30.f), x = std::cos(a) * r, z = std::sin(a) * r;
            const float h = (float)Terrain::mtnH(x, z); if (h < 0.f) continue;
            const float tl = 1.f - sstep(150.f, 250.f, h + (vn(x*0.02f, z*0.02f) - 0.5f) * 90.f); if (U() > tl) continue;              // tree line
            const float cl = clump(x, z); if (U() > 0.35f + 0.65f * sstep(0.30f, 0.55f, cl)) continue;                                   // glades
            const float sx = (float)(Terrain::mtnH(x + 10, z) - Terrain::mtnH(x - 10, z)) / 20.f, sz = (float)(Terrain::mtnH(x, z + 10) - Terrain::mtnH(x, z - 10)) / 20.f;
            if (std::sqrt(sx*sx + sz*sz) > 0.85f) continue;                                                                               // too steep for trees
            if (Terrain::lakeDn(x, z) < 1.95) continue;
            if (NatureFx::nearFall(x, z, 9.f)) continue;                                                                                  // keep the waterfall clear
            if (!freeCell(x, z, 7.f)) continue;
            if (std::fabs(River::riverSd(x, z)) < 40.0) continue;
            add(x, z, h - 0.5f, 1.2f + U() * 1.0f); n++;                                                                                  // bigger trees: still readable from 1 km
        }
        P.phase = 3;
    }
    return true;
}

// =====================================================================================================================
// Trunk collision + sway + falling needles
//  * every pine / spruce trunk is solid (3 circles along the car vs a circle for the trunk, found through a 16 m grid)
//  * a hit makes that tree swing (damped oscillation, the crown moves most) and shakes needles loose, which flutter down to the ground
// =====================================================================================================================
static std::unordered_map<long long, std::vector<int>> gCoGrid; static const float CO_CELL = 16.f;
static inline long long coCell(long cx, long cz){ return ((long long)(cx + 100000) << 32) ^ (long long)(cz + 100000); }
static void coBuildGrid(){ gCoGrid.clear(); for (size_t k = 0; k < gCo.size(); k++) gCoGrid[coCell((long)std::floor(gCo[k].x / CO_CELL), (long)std::floor(gCo[k].z / CO_CELL))].push_back((int)k); }

struct Sway { int idx = -1; float t = 0, A = 0, dx = 0, dz = 0; };
static Sway gSw[16]; static std::vector<uint8_t> gSwSlot; static int gSwN = 0; static float gSwOff[16][2];
static inline void pushInst(std::vector<float>& v, const CoTree& t, bool withSway){
    v.push_back(t.x); v.push_back(t.z); v.push_back(t.s); v.push_back(t.r); v.push_back(t.y);
    if (!withSway) return;
    float sx = 0, sz = 0;
    if (gSwN){ const size_t k = (size_t)(&t - gCo.data()); if (k < gSwSlot.size() && gSwSlot[k]){ sx = gSwOff[gSwSlot[k] - 1][0]; sz = gSwOff[gSwSlot[k] - 1][1]; } }
    v.push_back(sx); v.push_back(sz);
}
static void swayOffsets(){                       // crown displacement now (metres): damped swing along the push direction
    for (int i = 0; i < 16; i++){ const Sway& w = gSw[i]; if (w.idx < 0) continue;
        const float a = w.A * std::exp(-0.9f * w.t) * std::sin(3.4f * w.t) + 0.12f * w.A * std::exp(-1.6f * w.t) * std::sin(8.5f * w.t);
        gSwOff[i][0] = w.dx * a; gSwOff[i][1] = w.dz * a; }
}

// ---- falling needles / leaves: a small pool of point sprites ----
struct Leaf { float x, y, z, vx, vy, vz, age, life, size, ph, spin; uint8_t kind; bool landed; };
static const int LEAF_MAX = 700; static Leaf gLeaf[LEAF_MAX]; static int gLeafHead = 0, gLeafAlive = 0;
static GLuint gLfProg = 0, gLfVAO = 0, gLfVBO = 0; static GLint uLf_VP = -1, uLf_Scale = -1;
static uint32_t gLfRng = 0x9e3779b9u;
static inline float frnd(){ gLfRng ^= gLfRng << 13; gLfRng ^= gLfRng >> 17; gLfRng ^= gLfRng << 5; return (gLfRng >> 8) / 16777216.f; }
static const char* LF_VS =
    "#version 300 es\n"
    "layout(location=0) in vec4 pa; layout(location=1) in vec4 pc; uniform mat4 uVP; uniform float uScale; out vec3 vcol; out float vrot;\n"
    "void main(){ gl_Position = uVP * vec4(pa.xyz, 1.0); float d = max(gl_Position.w, 0.5);\n"
    " gl_PointSize = (pa.w > 0.001) ? clamp(pa.w * uScale / d, 1.5, 26.0) : 0.0; vcol = pc.rgb; vrot = pc.a; }";
static const char* LF_FS =
    "#version 300 es\nprecision mediump float;\n"
    "in vec3 vcol; in float vrot; out vec4 o;\n"
    "void main(){ vec2 c = gl_PointCoord * 2.0 - 1.0; float cs = cos(vrot), sn = sin(vrot); vec2 r = vec2(cs*c.x - sn*c.y, sn*c.x + cs*c.y);\n"
    " float e = (r.x*r.x) / 0.30 + r.y*r.y * 3.2; if (e > 1.0) discard;\n"                          // a thin leaf / needle tuft
    " o = vec4(vcol * (0.72 + 0.38 * (r.x * 0.5 + 0.5)), 1.0); }";
static void leafInit(){
    gLfProg = makeProg(LF_VS, LF_FS); uLf_VP = glGetUniformLocation(gLfProg, "uVP"); uLf_Scale = glGetUniformLocation(gLfProg, "uScale");
    glGenVertexArrays(1, &gLfVAO); glBindVertexArray(gLfVAO); glGenBuffers(1, &gLfVBO); glBindBuffer(GL_ARRAY_BUFFER, gLfVBO);
    glBufferData(GL_ARRAY_BUFFER, LEAF_MAX * 8 * 4, nullptr, GL_STREAM_DRAW);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 32, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 32, (void*)16);
    glBindVertexArray(0);
    for (Leaf& l : gLeaf) l.life = 0;
    gSwSlot.assign(gCo.size(), 0); for (Sway& w : gSw) w.idx = -1; gSwN = 0;
}
static void spawnLeaves(const CoTree& t, float vx, float vz, int n){
    const float s = t.s, crownR = (t.sp == 0 ? 2.7f : 3.5f) * s;
    for (int i = 0; i < n; i++){
        Leaf& l = gLeaf[gLeafHead]; gLeafHead = (gLeafHead + 1) % LEAF_MAX;
        const float h = (2.0f + frnd() * 11.5f) * s, rho = crownR * (1.f - h / (16.f * s)) * (0.2f + 0.9f * frnd()), th = frnd() * 6.2831853f;
        l.x = t.x + std::cos(th) * rho; l.z = t.z + std::sin(th) * rho; l.y = t.y + h;
        l.vx = (frnd() - 0.5f) * 1.2f + vx * 0.10f; l.vz = (frnd() - 0.5f) * 1.2f + vz * 0.10f; l.vy = (frnd() - 0.3f) * 1.0f;
        l.age = 0; l.life = 4.0f + frnd() * 3.5f; l.size = 0.11f + frnd() * 0.10f; l.ph = frnd() * 6.2831853f; l.spin = (frnd() - 0.5f) * 8.f; l.landed = false;
        const float k = frnd(); l.kind = k < 0.45f ? 0 : (k < 0.80f ? 1 : 2);
    }
}
static void hitTree(int k, float nx, float nz, float vx, float vz, float vn){
    const CoTree& t = gCo[k]; if (gSwSlot.size() != gCo.size()) return;
    int slot = gSwSlot[k] ? gSwSlot[k] - 1 : -1;
    if (slot >= 0 && gSw[slot].t < 0.35f) return;                         // still shaking from the last hit: no new burst every frame
    float dl = std::sqrt(vx*vx + vz*vz); float dx = dl > 0.05f ? vx / dl : -nx, dz = dl > 0.05f ? vz / dl : -nz;
    const float A = std::min(1.8f, 0.25f + vn * 0.09f) / (0.6f + 0.4f * t.s);
    if (slot < 0){ int best = 0; slot = -1; for (int i = 0; i < 16; i++){ if (gSw[i].idx < 0){ slot = i; break; } if (gSw[i].t > gSw[best].t) best = i; }
        if (slot < 0){ slot = best; gSwSlot[gSw[slot].idx] = 0; gSwN--; } gSw[slot].idx = k; gSwSlot[k] = (uint8_t)(slot + 1); gSwN++; gSwOff[slot][0] = gSwOff[slot][1] = 0; }
    Sway& w = gSw[slot]; w.t = 0; w.A = A; w.dx = dx; w.dz = dz;
    spawnLeaves(t, vx, vz, (int)std::min(70.f, 8.f + vn * 2.4f));
}

// the trunks are solid
static void collide(CarState& S){
    if (!gCoReady || !gCoDone) return;
    const double sH = std::sin(S.heading), cH = std::cos(S.heading), R = 1.05; static const double OFS[3] = {-1.5, 0.0, 1.5};
    for (double o : OFS){
        const double px = S.x + sH * o, pz = S.z + cH * o; const long cx = (long)std::floor(px / CO_CELL), cz = (long)std::floor(pz / CO_CELL);
        for (long i = cx - 1; i <= cx + 1; i++) for (long j = cz - 1; j <= cz + 1; j++){
            auto it = gCoGrid.find(coCell(i, j)); if (it == gCoGrid.end()) continue;
            for (int k : it->second){
                const CoTree& t = gCo[k]; const double qx = S.x + sH * o - t.x, qz = S.z + cH * o - t.z, r = R + 0.43 * t.s, d2 = qx*qx + qz*qz;
                if (d2 >= r * r) continue;
                const double d = std::sqrt(d2); const double nx = d > 1e-4 ? qx / d : -sH, nz = d > 1e-4 ? qz / d : -cH, pen = r - d;
                S.x += nx * pen; S.z += nz * pen;
                const double vx = S.speed * sH + S.vy * cH, vz = S.speed * cH - S.vy * sH, vn = -(vx * nx + vz * nz);
                if (vn > 0){ Fence::bounceOff(S, nx, nz, 0.12, 0.35); if (vn > 1.2) hitTree(k, (float)nx, (float)nz, (float)vx, (float)vz, (float)vn); }
            }
        }
    }
}

static void updateFx(double dt){
    const float d = (float)dt;
    for (int i = 0; i < 16; i++){ Sway& w = gSw[i]; if (w.idx < 0) continue; w.t += d;
        if (w.A * std::exp(-0.9f * w.t) < 0.012f){ if (w.idx < (int)gSwSlot.size()) gSwSlot[w.idx] = 0; w.idx = -1; gSwN--; } }
    gLeafAlive = 0;
    for (Leaf& l : gLeaf){
        if (l.life <= 0) continue; l.age += d; if (l.age >= l.life){ l.life = 0; continue; } gLeafAlive++;
        if (l.landed) continue;
        const float k = 1.f - std::exp(-2.2f * d);
        l.vy += ((-1.5f - 0.5f * std::sin(l.age * 4.f + l.ph)) - l.vy) * k;                                  // drifts down at ~1.5 m/s, bobbing
        l.vx += ((0.35f + 0.5f * std::sin(l.age * 5.3f + l.ph)) - l.vx) * (1.f - std::exp(-1.1f * d));        // slow sideways flutter + a little wind
        l.vz += ((0.15f + 0.5f * std::cos(l.age * 4.7f + l.ph)) - l.vz) * (1.f - std::exp(-1.1f * d));
        l.x += l.vx * d; l.y += l.vy * d; l.z += l.vz * d;
        const float gy = (float)Terrain::meshH(l.x, l.z) + 0.03f; if (l.y <= gy){ l.y = gy; l.landed = true; }
    }
}

// pixelScale = viewport height / (2 tan(fov/2)): converts a world size at distance d into pixels
static void drawLeaves(const float* VP, float pixelScale){
    if (!gLfProg || gLeafAlive <= 0) return;
    static float buf[LEAF_MAX * 8]; int n = 0;
    static const float COL[3][3] = {{0.14f, 0.33f, 0.15f}, {0.22f, 0.42f, 0.16f}, {0.36f, 0.25f, 0.12f}};
    for (const Leaf& l : gLeaf){
        if (l.life <= 0) continue; float* o = buf + n * 8; const float fade = std::min(1.f, (l.life - l.age) / 0.8f);
        o[0] = l.x; o[1] = l.y; o[2] = l.z; o[3] = l.size * fade; o[4] = COL[l.kind][0]; o[5] = COL[l.kind][1]; o[6] = COL[l.kind][2]; o[7] = l.ph + (l.landed ? 0.f : l.age * l.spin); n++;
    }
    if (!n) return;
    glUseProgram(gLfProg); glUniformMatrix4fv(uLf_VP, 1, GL_FALSE, VP); glUniform1f(uLf_Scale, pixelScale);
    glEnable(GL_DEPTH_TEST); glDepthMask(GL_TRUE); glDisable(GL_BLEND); glDisable(GL_CULL_FACE);
    glBindVertexArray(gLfVAO); glBindBuffer(GL_ARRAY_BUFFER, gLfVBO); glBufferData(GL_ARRAY_BUFFER, n * 32, buf, GL_STREAM_DRAW);
    glDrawArrays(GL_POINTS, 0, n); glBindVertexArray(0);
}


// render each species once from the side into a texture (flat far-distance colour, like the 3D tree has beyond 330 m), then build the billboard quad buffers
static void coBakeBillboards(){
    gCbProg = makeProg(CB_VS, CB_FS);
    uCb_VP = glGetUniformLocation(gCbProg, "uVP"); uCb_Cam = glGetUniformLocation(gCbProg, "uCam"); uCb_Size = glGetUniformLocation(gCbProg, "uSize"); uCb_Tex = glGetUniformLocation(gCbProg, "uTex"); uCb_Time = glGetUniformLocation(gCbProg, "uTime");
    const float quad[8] = {-1, 0,  1, 0,  -1, 1,  1, 1};
    glGenBuffers(1, &gCbQuad); glBindBuffer(GL_ARRAY_BUFFER, gCbQuad); glBufferData(GL_ARRAY_BUFFER, sizeof(quad), quad, GL_STATIC_DRAW);
    GLint oldFbo = 0, vp[4]; glGetIntegerv(GL_FRAMEBUFFER_BINDING, &oldFbo); glGetIntegerv(GL_VIEWPORT, vp);
    bool ok = true;
    for (int sp = 0; sp < 2; sp++){
        int levels = 1; for (int m = std::max(CB_W, CB_H); m > 1; m >>= 1) levels++;
        glGenTextures(1, &gCbTex[sp]); glBindTexture(GL_TEXTURE_2D_ARRAY, gCbTex[sp]);
        glTexStorage3D(GL_TEXTURE_2D_ARRAY, levels, GL_RGBA8, CB_W, CB_H, CB_VIEWS);
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR); glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        GLuint fbo, depth; glGenFramebuffers(1, &fbo); glBindFramebuffer(GL_FRAMEBUFFER, fbo);
        glGenRenderbuffers(1, &depth); glBindRenderbuffer(GL_RENDERBUFFER, depth); glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT16, CB_W, CB_H);
        glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, depth);
        for (int k = 0; k < CB_VIEWS; k++){
            glFramebufferTextureLayer(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, gCbTex[sp], 0, k);
            if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE){ ok = false; continue; }
            glViewport(0, 0, CB_W, CB_H); glClearColor(0, 0, 0, 0); glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
            glEnable(GL_DEPTH_TEST); glDepthMask(GL_TRUE); glDisable(GL_BLEND); glDisable(GL_CULL_FACE);
            const float hw = gCbHW[sp], y0 = gCbY0[sp], hh = gCbH[sp];
            // the camera orbits the tree (the sun stays where it is in the world, so every view is lit exactly like the real 3D tree):
            // view k looks from direction (sin a, cos a); screen-x = (cos a, -sin a) . p, as the billboard quad's "right" vector at run time
            const float ang = 6.2831853f * (float)k / (float)CB_VIEWS, sa = std::sin(ang), ca = std::cos(ang);
            float P[16] = {0}; P[0] = ca / hw; P[8] = -sa / hw; P[2] = -0.01f * sa; P[10] = -0.01f * ca; P[5] = 2.f / hh; P[13] = -(2.f * y0 + hh) / hh; P[15] = 1;
            const float one[7] = {0, 0, 1, 0, 0, 0, 0}, eye[3] = {sa * 110.f, 8.f, ca * 110.f};      // viewer in the right direction (specular / needle glow use it)
            glUseProgram(gCoProg); glUniformMatrix4fv(uCo_VP, 1, GL_FALSE, P); glUniform3fv(uCo_Cam, 1, eye); glUniform1f(uCo_Time, 0.f); glUniform1f(uCo_Bake, 1.f);
            glBindVertexArray(gCoVAO[sp][1]); glBindBuffer(GL_ARRAY_BUFFER, gCoInst[sp][1]); glBufferData(GL_ARRAY_BUFFER, sizeof(one), one, GL_STREAM_DRAW);
            glDrawElementsInstanced(GL_TRIANGLES, gCoIdx[sp][1], GL_UNSIGNED_SHORT, (void*)0, 1);
            glUniform1f(uCo_Bake, 0.f); glBindVertexArray(0);
        }
        glBindTexture(GL_TEXTURE_2D_ARRAY, gCbTex[sp]); glGenerateMipmap(GL_TEXTURE_2D_ARRAY);
        glBindFramebuffer(GL_FRAMEBUFFER, oldFbo); glDeleteRenderbuffers(1, &depth); glDeleteFramebuffers(1, &fbo);
        glGenVertexArrays(1, &gCbVAO[sp]); glBindVertexArray(gCbVAO[sp]);
        glBindBuffer(GL_ARRAY_BUFFER, gCbQuad); glEnableVertexAttribArray(0); glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 8, (void*)0);
        glGenBuffers(1, &gCbInst[sp]); glBindBuffer(GL_ARRAY_BUFFER, gCbInst[sp]);
        glEnableVertexAttribArray(3); glVertexAttribPointer(3, 4, GL_FLOAT, GL_FALSE, 20, (void*)0); glVertexAttribDivisor(3, 1);
        glEnableVertexAttribArray(4); glVertexAttribPointer(4, 1, GL_FLOAT, GL_FALSE, 20, (void*)16); glVertexAttribDivisor(4, 1);
        glBindVertexArray(0);
    }
    glViewport(vp[0], vp[1], vp[2], vp[3]);
    gCbReady = ok;
}

static void coInit(){
    gCoProg = makeProg(CO_VS, CO_FS); uCo_VP = glGetUniformLocation(gCoProg, "uVP"); uCo_Cam = glGetUniformLocation(gCoProg, "uCam"); uCo_Time = glGetUniformLocation(gCoProg, "uTime"); uCo_Bake = glGetUniformLocation(gCoProg, "uBake");
    struct LodDef { int tiers, seg; bool jag; }; const LodDef L[3] = {{6, 10, true}, {6, 9, true}, {2, 5, false}};
    for (int sp = 0; sp < 2; sp++) for (int l = 0; l < 4; l++){      // l = 3: the hand-made low-poly tree used on the Low graphics level
        TreeModel::ConiferMesh m; if (l == 3) TreeModel::buildConiferLow(m, sp); else TreeModel::buildConifer(m, sp, L[l].tiers, L[l].seg, L[l].jag); gCoIdx[sp][l] = m.count();
        if (l == 1){ float mx = 0.f, y0 = 1e9f, y1 = -1e9f;   // size of the detailed model (scale 1): used to bake the far 2D picture
            for (size_t i = 0; i + 2 < m.v.size(); i += 12){ mx = std::max(mx, std::max(std::fabs(m.v[i]), std::fabs(m.v[i + 2]))); y0 = std::min(y0, m.v[i + 1]); y1 = std::max(y1, m.v[i + 1]); }
            gCbHW[sp] = mx * 1.03f; gCbY0[sp] = y0; gCbH[sp] = (y1 - y0) * 1.01f; }
        glGenVertexArrays(1, &gCoVAO[sp][l]); glBindVertexArray(gCoVAO[sp][l]);
        glGenBuffers(1, &gCoVBO[sp][l]); glBindBuffer(GL_ARRAY_BUFFER, gCoVBO[sp][l]); glBufferData(GL_ARRAY_BUFFER, m.v.size() * 4, m.v.data(), GL_STATIC_DRAW);
        for (int a = 0; a < 3; a++){ glEnableVertexAttribArray(a); glVertexAttribPointer(a, 3, GL_FLOAT, GL_FALSE, 48, (void*)(size_t)(a * 12)); }
        glEnableVertexAttribArray(5); glVertexAttribPointer(5, 2, GL_FLOAT, GL_FALSE, 48, (void*)36);
        glEnableVertexAttribArray(6); glVertexAttribPointer(6, 1, GL_FLOAT, GL_FALSE, 48, (void*)44);
        glGenBuffers(1, &gCoIBO[sp][l]); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gCoIBO[sp][l]); glBufferData(GL_ELEMENT_ARRAY_BUFFER, m.idx.size() * 2, m.idx.data(), GL_STATIC_DRAW);
        glGenBuffers(1, &gCoInst[sp][l]); glBindBuffer(GL_ARRAY_BUFFER, gCoInst[sp][l]);
        glEnableVertexAttribArray(3); glVertexAttribPointer(3, 4, GL_FLOAT, GL_FALSE, 28, (void*)0); glVertexAttribDivisor(3, 1);
        glEnableVertexAttribArray(4); glVertexAttribPointer(4, 1, GL_FLOAT, GL_FALSE, 28, (void*)16); glVertexAttribDivisor(4, 1);
        glEnableVertexAttribArray(7); glVertexAttribPointer(7, 2, GL_FLOAT, GL_FALSE, 28, (void*)20); glVertexAttribDivisor(7, 1);   // sway offset x, z
        glBindVertexArray(0);
    }
    gCo.clear(); gCo.reserve(28000); gCoReady = true; coBakeBillboards(); leafInit();   // trees are planted a little each frame (coLoadStep), see drawConifers
}

// call after Terrain::init() (needs the mountain heights) with a current GL context
static void initConifers(){ coInit(); }

// plant a few ms of trees per frame; when everything is planted: build the collision grid and allow the 3D models
static void coLoadStep(double budgetSec){
    if (gCoDone) return;
    if (coPlantStep(budgetSec)){ coBuildGrid(); gSwSlot.assign(gCo.size(), 0); gCoDone = true; }
}

static void drawConifers(const float* VP, const float* eye, float timeSec = 0.f){
    if (!gCoReady) return;
    coLoadStep(0.004);                                         // 4 ms per frame: the game runs while the forest is still being planted
    static std::vector<float> B[2][4], BB[2]; for (auto& a : B) for (auto& b : a) b.clear(); BB[0].clear(); BB[1].clear();
    const bool useBb = gCbReady && Quality::billboards();     // Normal quality: far trees are camera-facing pictures
    const bool all2D = useBb && !gCoDone;                      // still loading: EVERY tree is only a 2D picture until loading has finished
    float pl[6][4];
    for (int i = 0; i < 6; i++){ const int a = i >> 1; const float sg = (i & 1) ? 1.f : -1.f;
        for (int j = 0; j < 4; j++) pl[i][j] = VP[j*4 + 3] + sg * VP[j*4 + a];
        const float l = std::sqrt(pl[i][0]*pl[i][0] + pl[i][1]*pl[i][1] + pl[i][2]*pl[i][2]); if (l > 1e-6f) for (int j = 0; j < 4; j++) pl[i][j] /= l; }
    const float qs = Quality::distScale(), m2 = Quality::treeDist * Quality::treeDist, a2 = CO_LOD0 * qs * CO_LOD0 * qs, b2 = CO_LOD1 * qs * CO_LOD1 * qs, bb2 = Quality::bbDist * Quality::bbDist;
    const bool low = Quality::level == 0;                                                      // Low graphics: the dedicated low-poly tree instead of the branch model + cones
    const float lowD2 = std::max(bb2, 140.f * 140.f);                                          // low-poly tree up to here, then the 2D picture
    static std::vector<std::pair<float, const CoTree*>> nearL; nearL.clear();
    for (const CoTree& t : gCo){
        const float dx = t.x - eye[0], dz = t.z - eye[2], d2 = dx*dx + dz*dz; if (d2 > m2) continue;
        const float cy = t.y + 8.f * t.s, rad = 9.f * t.s; bool out = false;
        for (int i = 0; i < 6 && !out; i++) if (pl[i][0]*t.x + pl[i][1]*cy + pl[i][2]*t.z + pl[i][3] < -rad) out = true;
        if (out) continue;
        if (low && !all2D && d2 < lowD2){ pushInst(B[t.sp][3], t, true); continue; }
        if (!all2D && d2 < a2){ nearL.push_back({d2, &t}); continue; }                                   // close: full branch model (capped below)
        const bool toBb = useBb && (all2D || d2 >= bb2);
        std::vector<float>& v = toBb ? BB[t.sp] : B[t.sp][(d2 < b2 || useBb) ? 1 : 2];
        pushInst(v, t, !toBb);
    }
    // the detailed branch model is the costly one: only the nearest MAX_DETAIL trees get it, the rest use the cheaper mid-distance model
    const size_t MAX_DETAIL = 36;
    if (nearL.size() > MAX_DETAIL) std::nth_element(nearL.begin(), nearL.begin() + MAX_DETAIL, nearL.end(), [](const std::pair<float, const CoTree*>& a, const std::pair<float, const CoTree*>& b){ return a.first < b.first; });
    for (size_t k = 0; k < nearL.size(); k++){ const CoTree& t = *nearL[k].second; std::vector<float>& v = B[t.sp][k < MAX_DETAIL ? 0 : 1];
        pushInst(v, t, true); }
    swayOffsets();
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE);
    glUseProgram(gCoProg); glUniformMatrix4fv(uCo_VP, 1, GL_FALSE, VP); glUniform3fv(uCo_Cam, 1, eye); glUniform1f(uCo_Time, timeSec); glUniform1f(uCo_Bake, 0.f);
    for (int sp = 0; sp < 2; sp++) for (int l = 0; l < 4; l++){
        const int cnt = (int)(B[sp][l].size() / 7); if (!cnt) continue;
        glBindVertexArray(gCoVAO[sp][l]);
        glBindBuffer(GL_ARRAY_BUFFER, gCoInst[sp][l]); glBufferData(GL_ARRAY_BUFFER, B[sp][l].size() * 4, B[sp][l].data(), GL_STREAM_DRAW);
        glDrawElementsInstanced(GL_TRIANGLES, gCoIdx[sp][l], GL_UNSIGNED_SHORT, (void*)0, cnt);
    }
    if (useBb){
        glUseProgram(gCbProg); glUniformMatrix4fv(uCb_VP, 1, GL_FALSE, VP); glUniform3fv(uCb_Cam, 1, eye); glUniform1i(uCb_Tex, 0); glUniform1f(uCb_Time, timeSec); glActiveTexture(GL_TEXTURE0);
        for (int sp = 0; sp < 2; sp++){
            const int cnt = (int)(BB[sp].size() / 5); if (!cnt) continue;
            glUniform3f(uCb_Size, gCbHW[sp], gCbY0[sp], gCbH[sp]); glBindTexture(GL_TEXTURE_2D_ARRAY, gCbTex[sp]);
            glBindVertexArray(gCbVAO[sp]);
            glBindBuffer(GL_ARRAY_BUFFER, gCbInst[sp]); glBufferData(GL_ARRAY_BUFFER, BB[sp].size() * 4, BB[sp].data(), GL_STREAM_DRAW);
            glDrawArraysInstanced(GL_TRIANGLE_STRIP, 0, 4, cnt);
        }
    }
    glBindVertexArray(0);
}

} // namespace TreeGL
