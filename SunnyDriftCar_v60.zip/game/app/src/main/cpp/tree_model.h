// Sunny Drift - green tree: C++ port of parseTreeMini() / makeTreeProto() from the HTML game.
// Pure C++ (no OpenGL): decodes the compact tree blob into two meshes (leaves + bark).
#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <sstream>
#include <string>
#include <vector>

namespace TreeModel {

const float TREE_SCALE = 1.25f;   // the model is ~6.7 m tall; each planted tree is then scaled 0.8x-1.7x on top of this

struct Meta {
    int nl = 0, nc = 0, R = 0, nrc = 0, nrv = 0, nrt = 0, t0 = 0, t1 = 0;
    double llo[3], lhi[3], glo[3], rlo[3], rhi[3], vc[4];
    double As = 0, QC = 0, QR = 0, gus = 0, u0lo = 0, u0hi = 0;
};

inline bool parseMeta(const std::string& text, Meta& M){
    std::istringstream s(text);
    s >> M.nl >> M.nc >> M.R >> M.nrc >> M.nrv >> M.nrt >> M.t0 >> M.t1;
    for (double& v : M.llo) s >> v;
    for (double& v : M.lhi) s >> v;
    for (double& v : M.glo) s >> v;
    for (double& v : M.rlo) s >> v;
    for (double& v : M.rhi) s >> v;
    for (double& v : M.vc)  s >> v;
    s >> M.As >> M.QC >> M.QR >> M.gus >> M.u0lo >> M.u0hi;
    return (bool)s;
}

struct Mesh {
    std::vector<float> pos, nrm, uv;     // 3, 3, 2 floats per vertex
    std::vector<uint16_t> idx;
    int vertexCount() const { return (int)(pos.size() / 3); }
};

struct Model {
    Mesh leaf, bark;
    float minY = 0, maxY = 0, halfWidth = 0;   // bounds of the scaled model (used for the far billboard)
};

// raw = the inflated blob (geometry first, then the two textures; only the geometry part is read here)
inline bool parse(const uint8_t* raw, size_t size, const Meta& M, Model& out){
    size_t o = 0; bool ok = true;
    auto U8 = [&](size_t n) -> const uint8_t* { if (o + n > size){ ok = false; return raw; } const uint8_t* a = raw + o; o += n; return a; };
    auto I8 = [&](size_t n) -> const int8_t* { return (const int8_t*)U8(n); };
    // byte planes, axis-major: m planes of n high bytes then m planes of n low bytes -> unsigned 16-bit values
    auto I16 = [&](int n, int m){
        const uint8_t* h = U8((size_t)n * m); const uint8_t* l = U8((size_t)n * m);
        std::vector<int> a((size_t)n * m); if (ok) for (int i = 0; i < n * m; i++) a[i] = (h[i] << 8) | l[i];
        return a; };
    auto s16 = [](int v){ return (int)(int16_t)(uint16_t)v; };

    // ---------------- leaves ----------------
    const int nl = M.nl;
    const uint8_t* lbd = U8((size_t)nl * 3); const int8_t* lA = I8((size_t)nl * 3);
    const uint8_t* lphi = U8(nl); const uint8_t* lty = U8(nl);
    if (!ok) return false;
    Mesh& L = out.leaf;
    int nlv = 0; for (int i = 0; i < nl; i++) nlv += lty[i] ? 4 : 6;
    L.pos.resize((size_t)nlv * 3); L.nrm.resize((size_t)nlv * 3); L.uv.resize((size_t)nlv * 2);
    L.idx.reserve((size_t)nl * 12);
    int lv = 0; int qa[3] = {0, 0, 0};
    static const double UVF[6][2] = {{.5,1},{0,2./3},{0,1./3},{.5,0},{1,1./3},{1,2./3}};
    for (int i = 0; i < nl; i++){
        double B[3], A[3];
        for (int a = 0; a < 3; a++){
            qa[a] = (qa[a] + lbd[a * nl + i]) & 255;
            B[a] = M.llo[a] + qa[a] / 255.0 * (M.lhi[a] - M.llo[a]);
            A[a] = lA[a * nl + i] * M.As;
        }
        double Ln = std::sqrt(A[0]*A[0] + A[1]*A[1] + A[2]*A[2]); if (Ln == 0) Ln = 1e-6;
        double ab[3] = {A[0]/Ln, A[1]/Ln, A[2]/Ln};
        double ref[3] = {0, 1, 0}; if (!(std::fabs(ab[1]) < .95)){ ref[0] = 1; ref[1] = 0; }
        double e1[3] = {ab[1]*ref[2]-ab[2]*ref[1], ab[2]*ref[0]-ab[0]*ref[2], ab[0]*ref[1]-ab[1]*ref[0]};
        double l1 = std::sqrt(e1[0]*e1[0] + e1[1]*e1[1] + e1[2]*e1[2]); if (l1 == 0) l1 = 1;
        for (double& x : e1) x /= l1;
        double e2[3] = {ab[1]*e1[2]-ab[2]*e1[1], ab[2]*e1[0]-ab[0]*e1[2], ab[0]*e1[1]-ab[1]*e1[0]};
        double ph = lphi[i] / 256.0 * M_PI * 2, cp = std::cos(ph) * .1 * Ln, sp = std::sin(ph) * .1 * Ln;
        double Wv[3] = {e1[0]*cp+e2[0]*sp, e1[1]*cp+e2[1]*sp, e1[2]*cp+e2[2]*sp};
        double nx = A[1]*Wv[2]-A[2]*Wv[1], ny = A[2]*Wv[0]-A[0]*Wv[2], nz = A[0]*Wv[1]-A[1]*Wv[0];
        double nn = std::sqrt(nx*nx + ny*ny + nz*nz); if (nn == 0) nn = 1; nx /= nn; ny /= nn; nz /= nn;
        if (ny < 0){ nx = -nx; ny = -ny; nz = -nz; }
        // point along the axis t (0 base .. 1 tip), sideways s (-1 left .. 1 right)
        auto pt = [&](double t, double s, double* r){ for (int a = 0; a < 3; a++) r[a] = B[a] + A[a]*t + Wv[a]*s; };
        double v[6][3]; pt(1,0,v[0]); pt(2./3,-1,v[1]); pt(1./3,-1,v[2]); pt(0,0,v[3]); pt(1./3,1,v[4]); pt(2./3,1,v[5]);
        int ty = lty[i];
        int sel6[6] = {0,1,2,3,4,5}, sel4a[4] = {0,1,2,3}, sel4b[4] = {0,3,4,5};
        const int* us = ty == 0 ? sel6 : (ty == 1 ? sel4a : sel4b);
        int cnt = ty == 0 ? 6 : 4;
        int b0 = lv;
        for (int k = 0; k < cnt; k++){
            const double* P = v[us[k]];
            L.pos[lv*3] = (float)P[0]; L.pos[lv*3+1] = (float)P[1]; L.pos[lv*3+2] = (float)P[2];
            L.nrm[lv*3] = (float)nx; L.nrm[lv*3+1] = (float)ny; L.nrm[lv*3+2] = (float)nz;
            L.uv[lv*2] = (float)UVF[us[k]][0]; L.uv[lv*2+1] = (float)UVF[us[k]][1]; lv++;
        }
        for (int k = 1; k <= cnt - 2; k++){ L.idx.push_back(b0); L.idx.push_back(b0 + k); L.idx.push_back(b0 + k + 1); }
    }

    // ---------------- bark tubes ----------------
    const int nc = M.nc, R = M.R, nrc = M.nrc, nrv = M.nrv, nrt = M.nrt;
    const uint8_t* Kc = U8(nc);
    std::vector<int> gu = I16(nc, 3), u0q = I16(nc, 1), c0 = I16(nc, 3);
    const uint8_t* r0 = U8(nc); const int8_t* dc = I8((size_t)R * 3); const int8_t* dr = I8(R);
    std::vector<int> rvc = I16(nrc, 1), rgu = I16(nrc, 3), ru0 = I16(nrc, 1), rdp = I16(nrv, 3), rdi = I16(nrt * 3, 1);
    if (!ok) return false;
    int totRings = 0; for (int c = 0; c < nc; c++) totRings += Kc[c];
    const int nbv = totRings * 6 + nrv;
    Mesh& Bk = out.bark;
    Bk.pos.assign((size_t)nbv * 3, 0.f); Bk.uv.assign((size_t)nbv * 2, 0.f);
    Bk.idx.reserve((size_t)(totRings * 12 + nrt) * 3);
    int bv = 0, ri = 0;
    const double u0s = (M.u0hi - M.u0lo) / 65535.0;
    auto setUV = [&](int v, double cx, double cy, double cz, double g0, double g1, double g2, double u0){
        double x = Bk.pos[v*3], y = Bk.pos[v*3+1], z = Bk.pos[v*3+2];
        Bk.uv[v*2]   = (float)(u0 + g0*(x-cx) + g1*(y-cy) + g2*(z-cz));
        Bk.uv[v*2+1] = (float)(M.vc[0]*x + M.vc[1]*y + M.vc[2]*z + M.vc[3]);
    };
    for (int c = 0; c < nc; c++){
        const int K = Kc[c];
        int cq[3] = {c0[c], c0[nc + c], c0[2*nc + c]}; int rq = r0[c];
        std::vector<std::array<double,3>> cen; std::vector<double> rad;
        for (int k = 0; k < K; k++){
            if (k > 0){ for (int a = 0; a < 3; a++) cq[a] += dc[a * R + ri]; rq += dr[ri]; ri++; }
            cen.push_back({M.glo[0] + cq[0]*M.QC, M.glo[1] + cq[1]*M.QC, M.glo[2] + cq[2]*M.QC}); rad.push_back(rq * M.QR);
        }
        double g0 = s16(gu[c]) * M.gus, g1 = s16(gu[nc + c]) * M.gus, g2 = s16(gu[2*nc + c]) * M.gus, u0 = M.u0lo + u0q[c] * u0s;
        const std::array<double,3> cr = cen[0];
        bool haveN = false; double nrm[3] = {0, 0, 0}; int first = bv;
        for (int k = 0; k < K; k++){
            const auto& pa = cen[std::max(k - 1, 0)]; const auto& pb = cen[std::min(k + 1, K - 1)];
            double tx = pb[0]-pa[0], ty = pb[1]-pa[1], tz = pb[2]-pa[2];
            double tl = std::sqrt(tx*tx + ty*ty + tz*tz); if (tl == 0) tl = 1; tx /= tl; ty /= tl; tz /= tl;
            if (!haveN){
                double rx = std::fabs(ty) < .9 ? 0 : 1, ry = std::fabs(ty) < .9 ? 1 : 0;
                nrm[0] = ty*0 - tz*ry; nrm[1] = tz*rx - tx*0; nrm[2] = tx*ry - ty*rx; haveN = true;   // t x ref
            } else {
                double d = nrm[0]*tx + nrm[1]*ty + nrm[2]*tz;
                nrm[0] -= tx*d; nrm[1] -= ty*d; nrm[2] -= tz*d;
            }
            double nn = std::sqrt(nrm[0]*nrm[0] + nrm[1]*nrm[1] + nrm[2]*nrm[2]); if (nn == 0) nn = 1;
            nrm[0] /= nn; nrm[1] /= nn; nrm[2] /= nn;
            double bb[3] = {ty*nrm[2]-tz*nrm[1], tz*nrm[0]-tx*nrm[2], tx*nrm[1]-ty*nrm[0]};
            for (int j = 0; j < 6; j++){
                double ang = j * M_PI / 3, ca = std::cos(ang) * rad[k], sa = std::sin(ang) * rad[k];
                Bk.pos[bv*3]   = (float)(cen[k][0] + nrm[0]*ca + bb[0]*sa);
                Bk.pos[bv*3+1] = (float)(cen[k][1] + nrm[1]*ca + bb[1]*sa);
                Bk.pos[bv*3+2] = (float)(cen[k][2] + nrm[2]*ca + bb[2]*sa);
                setUV(bv, cr[0], cr[1], cr[2], g0, g1, g2, u0); bv++;
            }
        }
        for (int k = 0; k < K - 1; k++) for (int j = 0; j < 6; j++){
            int jm = (j + 5) % 6, a = first + k*6 + j, a1 = first + k*6 + jm, b = first + (k+1)*6 + j, b1 = first + (k+1)*6 + jm;
            Bk.idx.push_back(a); Bk.idx.push_back(b); Bk.idx.push_back(b1); Bk.idx.push_back(a); Bk.idx.push_back(b1); Bk.idx.push_back(a1);
        }
    }
    // raw junction pieces
    {
        const int rb = bv; int q[3] = {0, 0, 0};
        for (int i = 0; i < nrv; i++) for (int a = 0; a < 3; a++){
            q[a] = (q[a] + rdp[a * nrv + i]) & 65535;
            Bk.pos[(rb + i)*3 + a] = (float)(M.rlo[a] + q[a] / 65535.0 * (M.rhi[a] - M.rlo[a]));
        }
        int vi = 0;
        for (int c = 0; c < nrc; c++){
            int n = rvc[c], s = rb + vi;
            double g0 = s16(rgu[c]) * M.gus, g1 = s16(rgu[nrc + c]) * M.gus, g2 = s16(rgu[2*nrc + c]) * M.gus, u0 = M.u0lo + ru0[c] * u0s;
            double cx = Bk.pos[s*3], cy = Bk.pos[s*3+1], cz = Bk.pos[s*3+2];
            for (int k = 0; k < n; k++) setUV(s + k, cx, cy, cz, g0, g1, g2, u0);
            vi += n;
        }
        int acc = 0;
        for (int j = 0; j < nrt * 3; j++){ int d = rdi[j]; if (d >= 32768) d -= 65536; acc += d; Bk.idx.push_back((uint16_t)(rb + acc)); }
        bv += nrv;
    }
    Bk.pos.resize((size_t)bv * 3); Bk.uv.resize((size_t)bv * 2);

    // ---------------- scale, smooth bark normals (computeVertexNormals), bounds ----------------
    for (float& v : L.pos) v *= TREE_SCALE;
    for (float& v : Bk.pos) v *= TREE_SCALE;
    Bk.nrm.assign(Bk.pos.size(), 0.f);
    for (size_t t = 0; t + 2 < Bk.idx.size(); t += 3){
        const float *A = &Bk.pos[Bk.idx[t]*3], *B = &Bk.pos[Bk.idx[t+1]*3], *C = &Bk.pos[Bk.idx[t+2]*3];
        float cb[3] = {C[0]-B[0], C[1]-B[1], C[2]-B[2]}, ab2[3] = {A[0]-B[0], A[1]-B[1], A[2]-B[2]};
        float n[3] = {cb[1]*ab2[2]-cb[2]*ab2[1], cb[2]*ab2[0]-cb[0]*ab2[2], cb[0]*ab2[1]-cb[1]*ab2[0]};
        for (int k = 0; k < 3; k++) for (int a = 0; a < 3; a++) Bk.nrm[Bk.idx[t+k]*3 + a] += n[a];
    }
    for (size_t v = 0; v + 2 < Bk.nrm.size(); v += 3){
        float l = std::sqrt(Bk.nrm[v]*Bk.nrm[v] + Bk.nrm[v+1]*Bk.nrm[v+1] + Bk.nrm[v+2]*Bk.nrm[v+2]); if (l == 0) l = 1;
        Bk.nrm[v] /= l; Bk.nrm[v+1] /= l; Bk.nrm[v+2] /= l;
    }
    out.minY = 1e9f; out.maxY = -1e9f; out.halfWidth = 0;
    for (const Mesh* m : {&L, &Bk})
        for (size_t v = 0; v + 2 < m->pos.size(); v += 3){
            out.minY = std::min(out.minY, m->pos[v+1]); out.maxY = std::max(out.maxY, m->pos[v+1]);
            out.halfWidth = std::max(out.halfWidth, std::max(std::fabs(m->pos[v]), std::fabs(m->pos[v+2])));
        }
    return ok;
}

// ---------------- pine / spruce: straight, dark green stacked cones (procedural, 3 levels of detail) ----------------
// Vertex = pos(3) normal(3) colour(3). Unit height H = 16 m; the planted instance scale multiplies it.
// vertex = pos(3) normal(3) colour(3) uv(2) branchFlag(1)  (12 floats). Flag 1 = a flat needle-covered branch (uv drives the needle pattern in the shader).
struct ConiferMesh { std::vector<float> v; std::vector<uint16_t> idx; int count() const { return (int)idx.size(); } };

// species 0 = spruce (narrow, dense, blue-green), 1 = pine (a little broader, warmer green)
// seg >= 10 = the CLOSE-UP model: a dark inner core + ~100 individual drooping branches whose needles are drawn in the shader;
// smaller seg = the simple stacked-cone models used at a distance
inline void buildConifer(ConiferMesh& m, int species, int tiers, int seg, bool jagged){
    const float H = 16.f, R = H * (species == 0 ? 0.17f : 0.22f);
    const float base[3] = {species == 0 ? 0.105f : 0.150f, species == 0 ? 0.225f : 0.255f, species == 0 ? 0.135f : 0.095f};    // real conifer foliage: dark, muted blue-green spruce / olive-green pine (red : green ~ 0.5-0.6, not a neon green)
    auto push = [&](float x, float y, float z, float nx, float ny, float nz, float c, float u = 0.f, float vv = 0.f, float fl = 0.f){
        const float l = std::sqrt(nx*nx + ny*ny + nz*nz); const float a[12] = {x, y, z, nx/l, ny/l, nz/l, base[0]*c, base[1]*c, base[2]*c, u, vv, fl};
        m.v.insert(m.v.end(), a, a + 12); return (uint16_t)(m.v.size() / 12 - 1); };
    // trunk: thin 5-sided prism, buried 3 m below the foot so it never floats on a slope
    { const bool dt = seg >= 10;   // close-up: no solid green core any more, so the trunk must carry the branches up the whole tree
      const float tr = dt ? 0.50f : 0.45f, top = dt ? H * 0.97f : H * 0.16f, tt = dt ? 0.06f : 0.6f; const float bk[3] = {0.22f, 0.15f, 0.09f};
      for (int j = 0; j < 5; j++){
          const float a0 = j * 6.2831853f / 5, a1 = (j + 1) * 6.2831853f / 5, am = (a0 + a1) * 0.5f; const float nx = std::cos(am), nz = std::sin(am);
          const float P[4][3] = {{tr*std::cos(a0), -3.f, tr*std::sin(a0)}, {tr*std::cos(a1), -3.f, tr*std::sin(a1)}, {tr*tt*std::cos(a0), top, tr*tt*std::sin(a0)}, {tr*tt*std::cos(a1), top, tr*tt*std::sin(a1)}};
          uint16_t ix[4]; for (int k = 0; k < 4; k++){ ix[k] = push(P[k][0], P[k][1], P[k][2], nx, 0.f, nz, 1.f, 0.f, 0.f, 2.f); float* c = &m.v[(size_t)ix[k]*12 + 6]; c[0] = bk[0]; c[1] = bk[1]; c[2] = bk[2]; }
          const uint16_t t[6] = {ix[0], ix[1], ix[2], ix[1], ix[3], ix[2]}; m.idx.insert(m.idx.end(), t, t + 6);
      } }
    const bool detailed = seg >= 10;
    // stacked cones (the whole tree at a distance; a smaller, darker core behind the branches up close)
    const float rs = detailed ? 0.90f : 1.f, dark = detailed ? 2.5f : 1.f;
    for (int i = 0; i < (detailed ? 0 : tiers); i++){   // detailed: the solid green core is removed, only trunk + real needle branches remain
        const float f = tiers > 1 ? (float)i / (tiers - 1) : 0.f;
        const float y0 = H * (0.10f + 0.60f * f), y1 = H * (tiers > 1 ? 0.40f + 0.60f * f : 1.0f), r = R * rs * (1.f - 0.80f * f), ht = y1 - y0;
        const float shade = (0.82f + 0.30f * f) * dark;                                  // upper tiers a little lighter
        for (int j = 0; j < seg; j++){
            const float a0 = j * 6.2831853f / seg, a1 = (j + 1) * 6.2831853f / seg, am = (a0 + a1) * 0.5f;
            const float r0 = r * ((jagged && (j & 1)) ? 0.88f : 1.f), r1 = r * ((jagged && ((j + 1) & 1)) ? 0.88f : 1.f);   // ragged skirt = branch tips
            const float yb = y0 - (jagged ? 0.04f * H : 0.f);
            const uint16_t a = push(r0*std::cos(a0), yb, r0*std::sin(a0), std::cos(a0)*ht, r, std::sin(a0)*ht, 0.80f * shade);
            const uint16_t b = push(r1*std::cos(a1), yb, r1*std::sin(a1), std::cos(a1)*ht, r, std::sin(a1)*ht, 0.80f * shade);
            const uint16_t c = push(0.f, y1, 0.f, std::cos(am)*ht, r, std::sin(am)*ht, 1.18f * shade);
            m.idx.push_back(a); m.idx.push_back(b); m.idx.push_back(c);
        }
    }
    if (!detailed) return;
    // individual branches: whorls up the trunk, each branch a flat tapered blade that droops (upper ones lift), needles come from the shader
    uint32_t seed = 12345u + (uint32_t)species * 777u; auto rnd = [&]{ seed = seed * 1664525u + 1013904223u; return (float)(seed >> 8) / 16777216.f; };
    const int whorls = species == 0 ? 26 : 22, per = species == 0 ? 14 : 12;
    for (int w = 0; w < whorls; w++){
        const float f = (w + 0.5f) / whorls, y = H * (0.13f + 0.84f * f);
        const float Rw = R * (species == 0 ? 1.30f : 1.25f) * std::pow(1.f - 0.93f * f, species == 0 ? 0.95f : 0.8f);
        for (int b = 0; b < per; b++){
            const float ang = ((float)b + 0.5f * (w & 1) + 0.4f * rnd()) * 6.2831853f / per + w * 0.9f;
            const float L = std::max(0.45f, Rw * (0.85f + 0.3f * rnd())), hwid = L * (species == 0 ? 0.55f : 0.62f);
            const float droop = (species == 0 ? 0.34f : 0.16f) * (1.f - f) - 0.30f * f * f;        // tip drop (+) / lift (-) per unit length
            const float dx = std::cos(ang), dz = std::sin(ang), px = -dz, pz = dx, y0 = y + (rnd() - 0.5f) * 0.25f;
            const float tone = (0.80f + 0.45f * rnd()) * (0.85f + 0.35f * f);
            const float S[5] = {0.f, 0.25f, 0.50f, 0.75f, 1.f}, Wd[5] = {0.15f, 0.80f, 1.0f, 0.70f, 0.f};
            const float curl = (species == 0 ? 0.05f : 0.20f) * L, bend = (rnd() - 0.5f) * 0.30f * L, roll = (rnd() - 0.5f) * 1.3f, cr = std::cos(roll), sr = std::sin(roll);   // roll: the blade is tilted about its own axis, so the crown has volume from every side
            uint16_t lv[4], rv[4], tip = 0;
            for (int k = 0; k < 5; k++){
                const float s = S[k], d = 0.25f + L * s, yy = y0 - droop * L * s * (0.4f + 0.6f * s) + curl * s * s * s * s, wd = hwid * Wd[k], cc = tone * (0.90f + 0.35f * s), bo = bend * s * s;
                const float nx = dx * 0.35f, nz = dz * 0.35f;                                       // soft, mostly upward normal
                if (k < 4){
                    lv[k] = push(dx*d + px*cr*(wd + bo), yy + sr*(wd + bo), dz*d + pz*cr*(wd + bo), nx, 0.95f, nz, cc, s, -1.f, 1.f);
                    rv[k] = push(dx*d - px*cr*(wd - bo), yy - sr*(wd - bo), dz*d - pz*cr*(wd - bo), nx, 0.95f, nz, cc, s, 1.f, 1.f);
                } else tip = push(dx*d + px*cr*bo, yy - 0.03f * L + sr*bo, dz*d + pz*cr*bo, nx, 0.95f, nz, cc, 1.f, 0.f, 1.f);
            }
            for (int k = 0; k < 3; k++){ m.idx.push_back(lv[k]); m.idx.push_back(rv[k]); m.idx.push_back(lv[k+1]); m.idx.push_back(rv[k]); m.idx.push_back(rv[k+1]); m.idx.push_back(lv[k+1]); }
            m.idx.push_back(lv[3]); m.idx.push_back(rv[3]); m.idx.push_back(tip);
        }
    }
    // leader (the very top): a little upright tuft
    for (int b = 0; b < 4; b++){ const float a = b * 1.5707963f + 0.4f; const uint16_t p0 = push(0.f, H * 0.93f, 0.f, 0.f, 1.f, 0.f, 0.9f), p1 = push(0.18f*std::cos(a), H * 0.95f, 0.18f*std::sin(a), 0.f, 1.f, 0.f, 1.1f), p2 = push(0.f, H * 1.02f, 0.f, 0.f, 1.f, 0.f, 1.2f);
        m.idx.push_back(p0); m.idx.push_back(p1); m.idx.push_back(p2); }
}

// ---------------- LOW-QUALITY pine / spruce: a hand-designed low-poly model (the way big games make their "LOD / mobile" trees) ----------------
// Chunky, readable silhouette: short brown trunk + 4 (spruce) / 3 (pine) overlapping hexagonal tiers, each tier rotated against the one below so the
// outline zig-zags like real branch whorls. Flat-shaded facets (one normal per face) and a baked-in gradient (dark under-skirt = ambient occlusion,
// bright tip) give depth and shape without any needle texture. ~50 triangles per tree. Same size (H = 16 m) as the real model, so it swaps in 1:1.
inline void buildConiferLow(ConiferMesh& m, int species){
    const float H = 16.f, R = H * (species == 0 ? 0.17f : 0.22f);
    const float base[3] = {species == 0 ? 0.105f : 0.150f, species == 0 ? 0.225f : 0.255f, species == 0 ? 0.135f : 0.095f};
    auto push = [&](float x, float y, float z, float nx, float ny, float nz, const float* col, float c, float fl){
        const float l = std::sqrt(nx*nx + ny*ny + nz*nz); const float a[12] = {x, y, z, nx/l, ny/l, nz/l, col[0]*c, col[1]*c, col[2]*c, 0.f, 0.f, fl};
        m.v.insert(m.v.end(), a, a + 12); return (uint16_t)(m.v.size() / 12 - 1); };
    // trunk: 5-sided tapered prism, buried 3 m below the foot (never floats on a slope), shows between ground and the lowest tier
    { const float bk[3] = {0.22f, 0.15f, 0.09f}, tr = 0.50f, top = H * 0.30f, tt = 0.55f;
      for (int j = 0; j < 5; j++){
          const float a0 = j * 6.2831853f / 5, a1 = (j + 1) * 6.2831853f / 5, am = (a0 + a1) * 0.5f, nx = std::cos(am), nz = std::sin(am);
          const uint16_t p0 = push(tr*std::cos(a0), -3.f, tr*std::sin(a0), nx, 0.f, nz, bk, 1.f, 2.f), p1 = push(tr*std::cos(a1), -3.f, tr*std::sin(a1), nx, 0.f, nz, bk, 1.f, 2.f),
                         p2 = push(tr*tt*std::cos(a0), top, tr*tt*std::sin(a0), nx, 0.f, nz, bk, 0.9f, 2.f), p3 = push(tr*tt*std::cos(a1), top, tr*tt*std::sin(a1), nx, 0.f, nz, bk, 0.9f, 2.f);
          const uint16_t t[6] = {p0, p1, p2, p1, p3, p2}; m.idx.insert(m.idx.end(), t, t + 6); } }
    const int tiers = species == 0 ? 4 : 3, seg = 6;
    for (int i = 0; i < tiers; i++){
        const float f = tiers > 1 ? (float)i / (tiers - 1) : 0.f;
        const float y0 = H * (0.14f + 0.62f * f * (species == 0 ? 1.0f : 0.92f)), ht = H * (species == 0 ? 0.38f : 0.44f) * (1.f - 0.18f * f), y1 = y0 + ht;
        const float r = R * (1.12f - 0.62f * f), rot = (i & 1) ? 0.5236f : 0.f;                       // every second tier is turned by 30 deg
        const float skirt = (species == 0 ? 0.045f : 0.02f) * H;                                       // lower rim droops a little below the cone base
        const float cb = 0.50f + 0.12f * f, ct = 1.12f + 0.12f * f;                                  // dark under-skirt -> lit tip
        for (int j = 0; j < seg; j++){
            const float a0 = rot + j * 6.2831853f / seg, a1 = rot + (j + 1) * 6.2831853f / seg, am = (a0 + a1) * 0.5f;
            const float nx = std::cos(am) * ht, nz = std::sin(am) * ht, ny = r * 0.85f;                   // one normal per facet = flat shading
            const uint16_t a = push(r*std::cos(a0), y0 - skirt, r*std::sin(a0), nx, ny, nz, base, cb, 0.f);
            const uint16_t b = push(r*std::cos(a1), y0 - skirt, r*std::sin(a1), nx, ny, nz, base, cb, 0.f);
            const uint16_t c = push(0.f, y1, 0.f, nx, ny, nz, base, ct, 0.f);
            m.idx.push_back(a); m.idx.push_back(b); m.idx.push_back(c);
            const uint16_t d = push(0.f, y0 + 0.10f * ht, 0.f, 0.f, -1.f, 0.f, base, cb * 0.7f, 0.f);        // underside of the tier (dark, closes the gap)
            const uint16_t e = push(r*std::cos(a0), y0 - skirt, r*std::sin(a0), 0.f, -1.f, 0.f, base, cb * 0.7f, 0.f);
            const uint16_t g = push(r*std::cos(a1), y0 - skirt, r*std::sin(a1), 0.f, -1.f, 0.f, base, cb * 0.7f, 0.f);
            m.idx.push_back(d); m.idx.push_back(e); m.idx.push_back(g);
        }
    }
}

} // namespace TreeModel
