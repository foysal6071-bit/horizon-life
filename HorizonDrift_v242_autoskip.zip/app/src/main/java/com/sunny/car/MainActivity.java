package com.sunny.car;

import android.app.Activity;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.os.Handler;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import java.nio.ByteBuffer;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MainActivity extends Activity {
    static { System.loadLibrary("car"); }
    static native void nInit(AssetManager am);
    static native void nSkip(int mask);          // auto-recovery: 1 = skip houses, 2 = skip waterfall / clouds (steps that closed the game last time)
    static native int nLoadProgress();           // loading screen: 0..100, 100 = world ready, -1 = failed
    static native void nResize(int w, int h);
    static native void nDraw();
    static native void nInput(int mask);
    static native void nPedals(float thr, float brk);                       // analog pedals 0..1 (< 0 = plain on/off)
    static native void nAssists(int abs, int tcs, int esc, float thrCurve, float brkCurve);   // driver aids + pedal response
    static native void nDriveCfg(int driftAssist, int steerAssist, int manual, int roadCond, int brakeFade, float handbrake, float counterSteer);   // drive options: assists, gearbox, road condition
    static native void nShift(int dir);                                     // manual gearbox: +1 up, -1 down (one pulse)
    static native void nTelemetry(float[] out);                             // development telemetry (18 values, see telemetryText)
    static float pedT = -1, pedB = -1;
    static native void nTimeOfDay(int idx);   // time of day: 0 morning, 1 noon, 2 afternoon, 3 sunset, 4 dusk, 5 night
    static native float nSpeed();
    static native void nDrift(float[] out);     // drift score inputs: drift 0..1, km/h (signed), rear slip angle in degrees (signed), handbrake 0..1
    static native void nSkyImg(int id, int w, int h, ByteBuffer rgba);   // sky pictures: 0..4 cube faces, 5 mountain colour, 6 mountain data
    static native void nSens(float v);          // steering sensitivity (HTML steerSens, 0.6 ... 3, default 1.8)
    static native void nReset();                // HTML resetCar()
    static native void nWheelMode(int on);      // HTML Settings > Controls: buttons / wheel
    static native void nWheelDown(float deg);
    static native void nWheelMove(float deg);
    static native void nWheelUp();
    static native float nWheelRot();            // wheel angle in degrees (+ = clockwise)
    static native float[] nMapData();           // minimap: roads, river, track, lake, village  [kind, n, payload...]
    static native void nCamDrag(float dx, float dy);   // free camera: finger drag in pixels
    static native void nCamRelease();
    static native void nCamMode(int mode);      // camera: 0 chase, 1 close chase, 2 bonnet, 3 cockpit, 4 dashboard
    static native int nCamGetMode();
    static native void nCamSet(float smooth, float dist, float height, float look, int shake);   // camera settings (see applyCam)
    static native void nShadows(int on);                                                          // settings: shadows on / off
    static native void nBloom(int on);                                                            // settings: bloom (glow) fully on / off
    static native void nSpeedFx(int on);                                                          // settings: motion blur, speed lines, speed FOV, drift shake
    static native void nGfx(float fovRad, int tyreFx, int natureFx);        // settings: field of view + effects on/off
    static native void nSuperSmooth(int on);                               // settings: Super smooth mode (trees only as 2D pictures, no grass / flowers, little tyre smoke)
    static native void nViewDist(float scale);                              // settings: world draw distance 0.4 .. 2 (houses, fences, boulders, tree detail)
    static native void nGrassOff(int off);                                 // settings: 1 = all grass, flowers and tall grass switched off
    static native void nGrassMode(int mode);                                // settings: 0 mixed, 1 all grass 3D, 2 all grass 2D
    static native void nGrassDist(float scale);                             // settings: grass / flower range, 0.1 .. 1
    static native void nQuality(int level);                                // settings: graphics quality 0 low / 1 normal / 2 high (draw distance)
    static native void nTreeDist(float farMetres, float nearMetres);                            // settings: how far trees are drawn (far ones as 2D pictures)
    static native void nPause(int on);                                     // settings open = game paused
    static native void nCamCfg(float sens, int autoReturn, int invertY);   // settings: free-camera options
    static native void nSound(float[] out);                                // sound inputs (9): rpm, throttle, skid, km/h, brake, gear-change flash, gear, rev limiter, water spray
    static native void nCarPose(float[] out);   // minimap: car x, z, heading (rad)

    static boolean glBuilt = false; static int prevLoad = 100, skipMask = 0;
    int mask = 0, kmask = 0;   // 1=left 2=right 4=gas 8=brake 16=handbrake 32=key left 64=key right   (mask = touch, kmask = keyboard)
    final float[] tele = new float[18]; TextView teleTv; View shiftUp, shiftDn;
    GLSurfaceView gl; SpeedView speed; MiniMapView miniMap; DriftView driftView; View wheelView, bl, br;
    SharedPreferences sp; FrameLayout rootView; View settingsLayer; IconBtn wheelBtn; TextView fpsTv; EngineSound engine = new EngineSound();
    final java.util.ArrayList<View> ctlViews = new java.util.ArrayList<>(), topList = new java.util.ArrayList<>();
    boolean haptic = true, mapShown = true; int mapDp = 128; volatile int frames;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        android.view.Window win = getWindow();
        win.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        win.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.BLACK));
        if (android.os.Build.VERSION.SDK_INT >= 28) {            // draw into the camera notch area as well (no black bar beside the notch)
            android.view.WindowManager.LayoutParams wl = win.getAttributes();
            wl.layoutInDisplayCutoutMode = android.os.Build.VERSION.SDK_INT >= 30
                ? android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                : android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            win.setAttributes(wl);
        }
        sp = getSharedPreferences("sunny_settings", MODE_PRIVATE);
        prevLoad = sp.getInt("last_load", 100);   // where the last start stopped; a stop at 87 / 88 switches that step off for the next start
        { int stuck = sp.getInt("stuck", 0); if (stuck == 0 && (prevLoad == 87 || prevLoad == 88)) stuck = prevLoad;
          int m = sp.getInt("skip_mask", 0); if (stuck == 87) m |= 1; else if (stuck == 88) m |= 2;
          sp.edit().putInt("skip_mask", m).putInt("stuck", 0).commit(); skipMask = m; }
        gl = new GLSurfaceView(this);
        gl.setEGLContextClientVersion(3);
        gl.setEGLConfigChooser(8, 8, 8, 8, 24, 0);
        gl.setPreserveEGLContextOnPause(true);
        gl.getHolder().addCallback(new android.view.SurfaceHolder.Callback() {   // 60 fps cap on 90/120 Hz phones: far less heat / throttling, same look
            public void surfaceCreated(android.view.SurfaceHolder h) { if (android.os.Build.VERSION.SDK_INT >= 30) { try { h.getSurface().setFrameRate(60f, android.view.Surface.FRAME_RATE_COMPATIBILITY_FIXED_SOURCE); } catch (Throwable t) {} } }
            public void surfaceChanged(android.view.SurfaceHolder h, int f, int w, int hh) {}
            public void surfaceDestroyed(android.view.SurfaceHolder h) {}
        });
        if (android.os.Build.VERSION.SDK_INT >= 24) { try { win.setSustainedPerformanceMode(true); } catch (Throwable t) {} }          // keep the GL context when the app goes to the background (a lost context = the world would have to be rebuilt)
        gl.setRenderer(new GLSurfaceView.Renderer() {
            public void onSurfaceCreated(GL10 g, EGLConfig c) {
                if (glBuilt) { restartApp(); return; }      // the GL context was lost and re-created: every GPU buffer of the world is gone -> clean restart instead of a crash / frozen screen
                glBuilt = true; loadSky(); nSkip(skipMask); nInit(getAssets());
            }
            public void onSurfaceChanged(GL10 g, int w, int h) { nResize(w, h); }
            public void onDrawFrame(GL10 g) { frames++; nDraw(); }
        });
        final FrameLayout outer = new FrameLayout(this); outer.setBackgroundColor(Color.BLACK); rootView = outer;
        outer.addView(gl);                                    // the 3D view fills the WHOLE screen (under the camera notch too)
        final FrameLayout root = new FrameLayout(this);       // HUD layer: pushed in only as far as the notch / rounded corners need, so no button is hidden
        gl.setOnTouchListener(new View.OnTouchListener() {   // drag on the free part of the screen = orbit the camera round the car
            int pid = -1; float lx, ly;
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: case MotionEvent.ACTION_POINTER_DOWN:
                        if (pid < 0) { int i = e.getActionIndex(); pid = e.getPointerId(i); lx = e.getX(i); ly = e.getY(i); }
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        int i = e.findPointerIndex(pid); if (i < 0) return true;
                        float x = e.getX(i), y = e.getY(i); nCamDrag(x - lx, y - ly); lx = x; ly = y; return true;
                    }
                    case MotionEvent.ACTION_UP: case MotionEvent.ACTION_CANCEL: pid = -1; nCamRelease(); return true;
                    case MotionEvent.ACTION_POINTER_UP:
                        if (e.getPointerId(e.getActionIndex()) == pid) { pid = -1; nCamRelease(); }
                        return true;
                }
                return true;
            }
        });
        final float dn = getResources().getDisplayMetrics().density;

        // ---- driving controls: steering arrows (left), brake + gas pedals and handbrake (right) ----
        bl  = addCtl(root, Ctl.LEFT,  1, 0, 28, 28, 112, 104);
        br  = addCtl(root, Ctl.RIGHT, 2, 0, 28 + 112, 28, 112, 104);   // the two halves touch: together they form one hexagon pad
        addCtl(root, Ctl.GAS,   4,  Gravity.END, 28, 28, 92, 168);
        addCtl(root, Ctl.BRAKE, 8,  Gravity.END, 28 + 92 + 14, 28, 92, 118);
        addCtl(root, Ctl.HAND, 16,  Gravity.END, 28 + 92 + 14 + 14, 28 + 118 + 14, 70, 70);
        // manual gearbox buttons (only visible with Settings > Controls > Gearbox = Manual): shift up above the gas pedal, shift down above the handbrake
        shiftUp = addShift(root, 1, 28, 28 + 168 + 14);
        shiftDn = addShift(root, -1, 28 + 92 + 14, 28 + 118 + 14 + 70 + 12);

        // ---- top-left round icon buttons: time of day / wheel / reset ----
        final IconBtn nb = new IconBtn(this, IconBtn.NIGHT); todBtn = nb;
        nb.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {                                   // tap = next time of day: morning > noon > afternoon > sunset > dusk > night > morning
                int i = (gi("tod_idx", 1) + 1) % TOD_EN.length; pi("tod_idx", i); applyTod();
                android.widget.Toast.makeText(MainActivity.this, TOD_EN[i], android.widget.Toast.LENGTH_SHORT).show();
            }
        });
        addTop(root, nb, 0);
        final IconBtn wb = new IconBtn(this, IconBtn.WHEEL); wheelBtn = wb;
        addTop(root, wb, 1);
        final IconBtn rb = new IconBtn(this, IconBtn.RESET);
        rb.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { nReset(); driftView.reset(); } });
        addTop(root, rb, 2);
        final IconBtn sb = new IconBtn(this, IconBtn.SETTINGS);
        sb.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { openSettings(); } });
        addTop(root, sb, 3);

        wheelView = new View(this) {      // drag-to-turn steering wheel (HTML #tWheel): rotation comes from the C++ Ctrl::Wheel
            final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG); final RectF mark = new RectF();
            @Override protected void onDraw(Canvas c) {
                float w = getWidth(), h = getHeight(), cx = w / 2, cy = h / 2, r = Math.min(w, h) / 2 - dp(8);
                // soft base disc (does not rotate)
                p.setStyle(Paint.Style.FILL); p.setColor(0x33000000); c.drawCircle(cx, cy, r + dp(6), p);
                c.save(); c.rotate(nWheelRot(), cx, cy);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(r * 0.20f); p.setColor(0xEE16191E); c.drawCircle(cx, cy, r, p);
                p.setStrokeWidth(dp(2)); p.setColor(0x66FFFFFF); c.drawCircle(cx, cy, r + r * 0.10f, p); c.drawCircle(cx, cy, r - r * 0.10f, p);
                p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeWidth(r * 0.13f); p.setColor(0xEE2A2F38);
                c.drawLine(cx - r, cy, cx + r, cy, p); c.drawLine(cx, cy, cx, cy + r, p);
                p.setStyle(Paint.Style.FILL); p.setColor(0xFF1B1F26); c.drawCircle(cx, cy, r * 0.26f, p);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); p.setColor(0xFF29B6F6); c.drawCircle(cx, cy, r * 0.26f, p);
                p.setStyle(Paint.Style.FILL); p.setColor(0xFFFF3B3B);   // 12 o'clock mark
                mark.set(cx - r * 0.05f, cy - r - r * 0.10f, cx + r * 0.05f, cy - r + r * 0.10f); c.drawRoundRect(mark, dp(2), dp(2), p);
                c.restore();
            }
            @Override public boolean onTouchEvent(MotionEvent e) {
                float deg = (float) Math.toDegrees(Math.atan2(e.getY() - getHeight() / 2f, e.getX() - getWidth() / 2f));
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: nWheelDown(deg); break;
                    case MotionEvent.ACTION_MOVE: nWheelMove(deg); break;
                    case MotionEvent.ACTION_UP: case MotionEvent.ACTION_CANCEL: nWheelUp(); break;
                }
                return true;
            }
        };
        FrameLayout.LayoutParams wlp = new FrameLayout.LayoutParams((int) dp(210), (int) dp(210), Gravity.BOTTOM | Gravity.START);
        wlp.leftMargin = (int) dp(28); wlp.bottomMargin = (int) dp(20);
        wheelView.setLayoutParams(wlp); wheelView.setVisibility(View.GONE); root.addView(wheelView);
        wb.setOnClickListener(new View.OnClickListener() {      // controls switch: buttons <-> steering wheel (HTML Settings > Controls)
            public void onClick(View v) { setWheelMode(!wb.on); pi("ctl_mode", wb.on ? 1 : 0); }
        });
        final Handler wh = new Handler();
        wh.post(new Runnable() { float last = Float.NaN; public void run() { if (wheelView.getVisibility() == View.VISIBLE) { float r = nWheelRot(); if (Float.isNaN(last) || Math.abs(r - last) > 0.05f) { last = r; wheelView.invalidate(); } } else last = Float.NaN; wh.postDelayed(this, 16); } });

        speed = new SpeedView(this);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int) dp(200), (int) dp(92), Gravity.TOP | Gravity.END);
        lp.setMargins(0, (int) dp(14), (int) dp(20), 0);
        root.addView(speed, lp);
        // ---- camera button (top right, left of the speedometer, clear of gas / brake / steering): tap = next camera ----
        final IconBtn cb = new IconBtn(this, IconBtn.CAMERA);
        FrameLayout.LayoutParams cblp = new FrameLayout.LayoutParams((int) dp(52), (int) dp(52), Gravity.TOP | Gravity.END);
        cblp.rightMargin = (int) dp(230); cblp.topMargin = (int) dp(20);
        cb.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { int m = (nCamGetMode() + 1) % CAM_NAMES.length; nCamMode(m); pi("cam_mode", m); showCamLabel(m); } });
        root.addView(cb, cblp);
        camTv = new TextView(this); camTv.setTextColor(0xFFFFFFFF); camTv.setTextSize(15); camTv.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        camTv.setShadowLayer(4, 0, 0, 0xFF000000); camTv.setPadding((int) dp(14), (int) dp(6), (int) dp(14), (int) dp(6)); camTv.setBackground(pill(0x55000000, 0x66FFFFFF, 16)); camTv.setAlpha(0f);
        FrameLayout.LayoutParams ctlp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        ctlp.topMargin = (int) dp(62); root.addView(camTv, ctlp);
        // ---- drift score + combo: top centre, only shown while a drift chain is alive ----
        driftView = new DriftView(this);
        FrameLayout.LayoutParams dlp = new FrameLayout.LayoutParams((int) dp(224), (int) dp(92), Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        dlp.topMargin = (int) dp(70);
        // drift score + combo HUD removed (the view is not added to the screen any more)
        // ---- minimap, top-left corner (tap it to switch between the zoomed follow view and the whole map) ----
        miniMap = new MiniMapView(this);
        FrameLayout.LayoutParams mlp = new FrameLayout.LayoutParams((int) dp(mapDp), (int) dp(mapDp), Gravity.TOP | Gravity.START);
        mlp.setMargins((int) dp(14), (int) dp(12), 0, 0);
        root.addView(miniMap, mlp);
        fpsTv = new TextView(this); fpsTv.setTextColor(0xFFA3E635); fpsTv.setTextSize(12); fpsTv.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        fpsTv.setShadowLayer(3, 0, 0, 0xFF000000); fpsTv.setVisibility(View.VISIBLE);
        FrameLayout.LayoutParams flp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        flp.bottomMargin = (int) dp(8);
        root.addView(fpsTv, flp);
        teleTv = new TextView(this); teleTv.setTextColor(0xFFE2F3FF); teleTv.setTextSize(11); teleTv.setTypeface(Typeface.MONOSPACE); teleTv.setShadowLayer(3, 0, 0, 0xFF000000);
        teleTv.setBackgroundColor(0x66000000); teleTv.setPadding((int) dp(6), (int) dp(3), (int) dp(6), (int) dp(3)); teleTv.setVisibility(View.GONE);   // development telemetry: hidden unless switched on in Settings
        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        tlp.topMargin = (int) dp(8); root.addView(teleTv, tlp);
        outer.addView(root, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        outer.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            public android.view.WindowInsets onApplyWindowInsets(View v, android.view.WindowInsets ins) {
                int l = 0, t = 0, r = 0, bt = 0;
                if (android.os.Build.VERSION.SDK_INT >= 28 && ins.getDisplayCutout() != null) {
                    android.view.DisplayCutout dc = ins.getDisplayCutout();
                    l = dc.getSafeInsetLeft(); t = dc.getSafeInsetTop(); r = dc.getSafeInsetRight(); bt = dc.getSafeInsetBottom();
                }
                cutPad[0] = l; cutPad[1] = t; cutPad[2] = r; cutPad[3] = bt;
                root.setPadding(l, t, r, bt);
                if (settingsLayer != null) settingsLayer.setPadding(l, t, r, bt);
                return ins;
            }
        });
        hudRoot = root;
        buildLoading(outer);
        setContentView(outer); if (android.os.Build.VERSION.SDK_INT >= 24) { try { getWindow().setSustainedPerformanceMode(true); } catch (Throwable t) {} }
        goFullscreen();
        applyAll();
        final Handler h = new Handler();
        h.post(new Runnable() { int n = 0; public void run() { speed.set(nSpeed()); miniMap.tick(); if ((++n & 1) == 0 && teleTv.getVisibility() == View.VISIBLE) { nTelemetry(tele); teleTv.setText(telemetryText()); } h.postDelayed(this, 50); } });
        final Handler dh = new Handler();
        final Handler fh = new Handler();
        fh.post(new Runnable() { int last = 0; public void run() { int f = frames; if (fpsTv.getVisibility() == View.VISIBLE) { final int fp = (f - last) * 2; fpsTv.setText(fp + " FPS"); fpsTv.setTextColor(fp >= 50 ? 0xFFA3E635 : fp >= 30 ? 0xFFFACC15 : 0xFFF87171); } last = f; fh.postDelayed(this, 500); } });
    }

    final int[] cutPad = new int[4];

    // true full screen: no status bar, no navigation bar (a swipe from the edge shows them for a moment, then they hide again)
    void goFullscreen() {
        final android.view.Window w = getWindow();
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false);
            android.view.WindowInsetsController c = w.getInsetsController();
            if (c != null) {
                c.hide(android.view.WindowInsets.Type.systemBars());
                c.setSystemBarsBehavior(android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            final View d = w.getDecorView();
            d.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            d.setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener() {
                public void onSystemUiVisibilityChange(int v) { if ((v & View.SYSTEM_UI_FLAG_FULLSCREEN) == 0) d.postDelayed(new Runnable() { public void run() { goFullscreen(); } }, 1500); }
            });
        }
    }
    @Override public void onWindowFocusChanged(boolean hasFocus) { super.onWindowFocusChanged(hasFocus); if (hasFocus) goFullscreen(); }

    float dp(float v) { return v * getResources().getDisplayMetrics().density; }

    View addCtl(FrameLayout root, int kind, final int bit, int grav, int mx, int my, int w, int hh) {
        Ctl c = new Ctl(this, kind, bit);
        int g = Gravity.BOTTOM | (grav == Gravity.END ? Gravity.END : Gravity.START);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int) dp(w), (int) dp(hh), g);
        if (g == (Gravity.BOTTOM | Gravity.END)) lp.rightMargin = (int) dp(mx); else lp.leftMargin = (int) dp(mx);
        lp.bottomMargin = (int) dp(my);
        root.addView(c, lp); ctlViews.add(c);
        return c;
    }

    View addShift(FrameLayout root, int dir, int mx, int my) {
        ShiftBtn b = new ShiftBtn(this, dir);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int) dp(92), (int) dp(52), Gravity.BOTTOM | Gravity.END);
        lp.rightMargin = (int) dp(mx); lp.bottomMargin = (int) dp(my);
        b.setVisibility(View.GONE); root.addView(b, lp); ctlViews.add(b);
        return b;
    }

    // manual gearbox button: one tap = one shift (the pulse is consumed by the physics on the next step)
    class ShiftBtn extends View {
        final int dir; boolean down; final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        ShiftBtn(android.content.Context ctx, int dir) { super(ctx); this.dir = dir; setClickable(true); }
        @Override public boolean onTouchEvent(MotionEvent e) {
            final int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) { down = true; nShift(dir); if (haptic) performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY); invalidate(); }
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) { down = false; invalidate(); }
            return true;
        }
        @Override protected void onDraw(Canvas c) {
            final float w = getWidth(), h = getHeight(), pad = dp(4);
            p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(down ? 0x28FFFFFF : 0x06FFFFFF); c.drawRoundRect(new RectF(pad, pad, w - pad, h - pad), dp(16), dp(16), p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.4f)); p.setColor(down ? 0xCCFFFFFF : 0x66FFFFFF); c.drawRoundRect(new RectF(pad, pad, w - pad, h - pad), dp(16), dp(16), p);
            p.setStyle(Paint.Style.FILL); p.setColor(down ? 0xFFFFFFFF : 0xE6FFFFFF); p.setTextSize(dp(15)); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
            c.drawText(dir > 0 ? "SHIFT +" : "SHIFT -", w / 2, h / 2 - (p.ascent() + p.descent()) / 2f, p);
        }
    }

    // development telemetry text (nTelemetry): speed, rpm, gear, pedals, steering, slip, g-forces, grip and assist activity
    String telemetryText() {
        final float[] t = tele; final java.util.Locale L = java.util.Locale.US;
        return String.format(L, "%3.0f km/h  %4.0f rpm  gear %s\nthr %3.0f%%  brk %3.0f%%  steer %+5.1f deg\ndrift %+5.1f deg  slip F %+5.1f  R %+5.1f deg\nlat %+5.2f g  lon %+5.2f g  grip mu %.2f\nTCS %3.0f%%  ABS %3.0f%%  ESC %3.0f%%  brakeT %3.0f%%  HB %3.0f%%  rear %3.0f%%",
            t[0], t[1], t[2] < 0.5f ? "R" : Integer.toString(Math.round(t[2])), t[3], t[4], t[5], t[6], t[7], t[8], t[9], t[10], t[11], t[12] * 100, t[13] * 100, t[14] * 100, t[15] * 100, t[16] * 100, t[17] * 100);
    }

    void addTop(FrameLayout root, View v, int slot) {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int) dp(48), (int) dp(48), Gravity.TOP | Gravity.START);
        root.addView(v, lp); topList.add(v); layoutTop();
    }

    void layoutTop() {   // the round buttons sit right of the minimap (or at the corner when the minimap is hidden)
        final float x0 = mapShown ? 14 + mapDp + 14 : 20;
        for (int i = 0; i < topList.size(); i++) {
            View v = topList.get(i); FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) v.getLayoutParams();
            lp.setMargins((int) dp(x0 + i * 60), (int) dp(16), 0, 0); v.setLayoutParams(lp);
        }
    }

    // =====================================================================================
    //  Racing-style touch controls (custom drawn, translucent dark glass + accent colour)
    // =====================================================================================
    class Ctl extends View {
        static final int LEFT = 0, RIGHT = 1, GAS = 2, BRAKE = 3, HAND = 4;
        final int kind, bit, accent; boolean down;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Ctl(android.content.Context ctx, int kind, int bit) {
            super(ctx); this.kind = kind; this.bit = bit;
            accent = 0xFFFFFFFF;
            setClickable(true);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            final boolean pedal = kind == GAS || kind == BRAKE;
            if (a == MotionEvent.ACTION_DOWN) { down = true; mask |= bit; if (haptic) performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY); }
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) { down = false; mask &= ~bit; if (pedal) { if (kind == GAS) pedT = -1; else pedB = -1; nPedals(pedT, pedB); } }
            else if (a != MotionEvent.ACTION_MOVE) return true;
            if (down && pedal) {   // analog pedal: touch near the top of the pedal = full, near the bottom = light (about 30 %)
                final float v = Math.max(0.45f, Math.min(1f, 1f - 0.55f * Math.max(0f, Math.min(1f, e.getY() / Math.max(1f, getHeight())))));
                if (kind == GAS) pedT = v; else pedB = v;
                nPedals(pedT, pedB);
            }
            nInput(mask | kmask); invalidate(); return true;
        }
        void text(Canvas c, String s, float cx, float cy, float size, int col) {
            p.setStyle(Paint.Style.FILL); p.setColor(col); p.setTextSize(size); p.setTextAlign(Paint.Align.CENTER);
            p.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
            c.drawText(s, cx, cy - (p.ascent() + p.descent()) / 2f, p);
        }
        // steering pad: one half of a transparent hexagon (pointed outer end, flat inner edge) with double white chevrons
        void drawSteerHalf(Canvas c, float w, float h) {
            final boolean L = kind == LEFT; final float pad = dp(4), cy = h / 2, pt = w * 0.34f;
            final float in = L ? w : 0, out = L ? pad : w - pad, mid = L ? out + pt : out - pt;   // inner edge x, outer tip x, shoulder x
            Path hex = new Path(); hex.moveTo(in, pad); hex.lineTo(mid, pad); hex.lineTo(out, cy); hex.lineTo(mid, h - pad); hex.lineTo(in, h - pad); hex.close();
            p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(down ? 0x28FFFFFF : 0x06FFFFFF); c.drawPath(hex, p);       // see-through glass
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.4f)); p.setStrokeJoin(Paint.Join.ROUND);
            p.setColor(down ? 0xCCFFFFFF : 0x55FFFFFF); c.drawPath(hex, p);
            // two chevrons, the first one bright and the second one dim (like the pad in a racing game)
            final float ch = h * 0.20f, cw = ch * 0.62f, dir = L ? -1 : 1, base = w / 2 + (L ? dp(6) : -dp(6)) - dir * cw * 0.2f;
            p.setStyle(Paint.Style.FILL_AND_STROKE); p.setStrokeWidth(dp(2.2f)); p.setStrokeJoin(Paint.Join.ROUND); p.setStrokeCap(Paint.Cap.ROUND);
            for (int i = 0; i < 2; i++) {
                final float x = base + dir * (i == 0 ? -cw * 0.55f : cw * 0.75f);
                Path ch2 = new Path(); ch2.moveTo(x - dir * cw * 0.5f, cy - ch); ch2.lineTo(x + dir * cw * 0.5f, cy); ch2.lineTo(x - dir * cw * 0.5f, cy + ch); ch2.close();   // solid arrow head
                p.setColor(down ? 0xFFFFFFFF : (i == 0 ? 0xE6FFFFFF : 0x66FFFFFF)); c.drawPath(ch2, p);
            }
            p.setStrokeCap(Paint.Cap.BUTT);
        }
        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), cx = w / 2, cy = h / 2, pad = dp(5);
            if (kind == LEFT || kind == RIGHT) { drawSteerHalf(c, w, h); return; }
            c.save(); if (down) c.scale(0.95f, 0.95f, cx, cy);
            RectF r = new RectF(pad, pad, w - pad, h - pad);
            float rad = kind == HAND ? Math.min(w, h) / 2 : dp(24);
            // transparent glass like the steering pad: faint white fill, thin white border, white icon (brighter while pressed)
            p.setShader(null); p.setStyle(Paint.Style.FILL);
            p.setColor(down ? 0x28FFFFFF : 0x06FFFFFF); c.drawRoundRect(r, rad, rad, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.4f));
            p.setColor(down ? 0xCCFFFFFF : 0x66FFFFFF); c.drawRoundRect(r, rad, rad, p);
            int ic = down ? 0xFFFFFFFF : 0xE6FFFFFF;
            if (kind == LEFT || kind == RIGHT) {
                SvgIcon.draw(c, p, kind == LEFT ? SvgIcon.STEER_L : SvgIcon.STEER_R, cx, cy, Math.min(w, h) * 0.50f, ic, 2.6f, true);
            } else if (kind == GAS || kind == BRAKE) {
                SvgIcon.draw(c, p, kind == GAS ? SvgIcon.PEDAL_GAS : SvgIcon.PEDAL_BRAKE, cx, cy - dp(8), w * (kind == GAS ? 0.50f : 0.56f), ic, 2.0f, true);
                text(c, kind == GAS ? "GAS" : "BRAKE", cx, r.bottom - dp(18), dp(14), ic);
            } else {
                SvgIcon.draw(c, p, SvgIcon.HANDBRAKE, cx, cy, Math.min(w, h) * 0.66f, ic, 2.0f, true);
            }
            c.restore();
        }
    }

    // round glass icon button (night / wheel / reset)
    class IconBtn extends View {
        static final int NIGHT = 0, WHEEL = 1, RESET = 2, SETTINGS = 3, CAMERA = 4;
        final int kind; boolean on;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        IconBtn(android.content.Context ctx, int kind) { super(ctx); this.kind = kind; setClickable(true); }
        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) { setAlpha(0.6f); performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY); }
            else if (e.getActionMasked() == MotionEvent.ACTION_UP || e.getActionMasked() == MotionEvent.ACTION_CANCEL) setAlpha(1f);
            return super.onTouchEvent(e);
        }
        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), cx = w / 2, cy = getHeight() / 2, r = w / 2 - dp(2);
            // buttons are colourless (white)
            final int col = 0xFFFFFFFF, rgb = 0x00FFFFFF;   // no colours: plain white glass buttons
            p.setStyle(Paint.Style.FILL); p.setColor(0x08101820); c.drawCircle(cx, cy, r, p);                     // transparent glass base
            p.setColor(rgb | (on ? 0x30000000 : 0x10000000)); c.drawCircle(cx, cy, r, p);                         // colour tint
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.8f)); p.setColor(rgb | (on ? 0xCC000000 : 0x88000000)); c.drawCircle(cx, cy, r, p);
            String[] icon = kind == NIGHT ? (on ? SvgIcon.SUN : SvgIcon.MOON) : kind == WHEEL ? SvgIcon.WHEEL : kind == SETTINGS ? SvgIcon.SLIDERS : kind == CAMERA ? SvgIcon.CAMERA : SvgIcon.RESET;
            SvgIcon.draw(c, p, icon, cx, cy, r * 1.12f, col, 2.1f, true);
        }
    }

    // =====================================================================================
    //  Drift score HUD: points grow with speed x slip angle, the combo multiplier climbs the longer the chain lasts
    //  and with every direction switch. Let go of the drift for ~1.6 s and the score is banked; a hard hit loses it.
    // =====================================================================================
    class DriftView extends View {
        static final int IDLE = 0, DRIFT = 1, GRACE = 2, BANK = 3, CRASH = 4;
        static final float GRACE_T = 1.6f, STEP_T = 2.5f, MIN_ANGLE = 11f, MIN_KMH = 30f;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final RectF rf = new RectF();
        final float[] in = new float[4];
        final java.text.NumberFormat nf = java.text.NumberFormat.getIntegerInstance(java.util.Locale.US);
        boolean enabled = true, newBest;
        int state = IDLE, mult = 1, trans, side, best;
        float score, shown, chain, graceT, msgT, popT, showA, angle, lastKmh, flashT;
        long lastNs;

        DriftView(android.content.Context ctx) { super(ctx); best = sp.getInt("drift_best", 0); }

        void setEnabled2(boolean on) { enabled = on; if (!on) reset(); }
        void reset() { state = IDLE; score = shown = 0; chain = 0; mult = 1; trans = 0; lastKmh = 0; lastNs = 0; msgT = 0; showA = 0; invalidate(); }

        void start(int sg) { state = DRIFT; score = shown = 0; chain = 0; mult = 1; trans = 0; side = sg; graceT = GRACE_T; newBest = false; popT = 1; }

        void tick() {
            final long now = System.nanoTime();
            float dt = lastNs == 0 ? 0f : (now - lastNs) / 1e9f; lastNs = now;
            if (dt > 0.1f) dt = 0.1f;
            if (settingsLayer != null || !enabled) return;                      // settings open = game paused
            nDrift(in);
            final float kmh = in[1], ang = in[2], absA = Math.abs(ang);
            angle = absA;
            final boolean drifting = kmh > MIN_KMH && absA > MIN_ANGLE && in[0] > 0.3f;
            final int sg = ang >= 0 ? 1 : -1;
            // a sudden big loss of speed (wall, house, tree, fence) while a chain is alive = crash, the chain is lost
            if ((state == DRIFT || state == GRACE) && dt > 0 && dt < 0.1f && lastKmh - kmh > Math.max(10f, lastKmh * 0.25f)) {
                state = CRASH; msgT = 1.5f; flashT = 0.35f; mult = 1;
            }
            lastKmh = kmh;
            switch (state) {
                case IDLE: case BANK: case CRASH:
                    if (state != IDLE) { msgT -= dt; if (msgT <= 0) state = IDLE; }
                    if (drifting && (state == IDLE || msgT < 1.2f || state == BANK)) start(sg);
                    break;
                case DRIFT: case GRACE:
                    if (drifting) {
                        state = DRIFT; graceT = GRACE_T; chain += dt;
                        if (sg != side) { side = sg; trans++; flashT = 0.3f; }              // direction switch = combo up
                        final int nm = Math.min(10, 1 + (int) (chain / STEP_T) + trans);
                        if (nm > mult) { mult = nm; popT = 1f; }
                        score += kmh * absA * 0.12f * mult * dt;
                    } else {
                        state = GRACE; graceT -= dt;
                        if (graceT <= 0) {
                            if (score < 100f) { state = IDLE; }
                            else {
                                final int v = (int) score; newBest = v > best;
                                if (newBest) { best = v; pi("drift_best", best); }
                                state = BANK; msgT = 2.0f; popT = 1f;
                            }
                        }
                    }
                    break;
            }
            shown += (score - shown) * Math.min(1f, dt * 12f);
            if (popT > 0) popT = Math.max(0, popT - dt * 3.5f);
            if (flashT > 0) flashT = Math.max(0, flashT - dt);
            final float tgt = state == IDLE ? 0f : 1f;
            showA += (tgt - showA) * Math.min(1f, dt * (tgt > showA ? 14f : 6f));
            if (showA < 0.01f && tgt == 0f) showA = 0f;
            if (showA > 0f || state != IDLE) invalidate();
        }

        int tier(int m) { return m <= 1 ? 0xFF38BDF8 : m <= 3 ? 0xFF2EE59D : m <= 5 ? 0xFFFFD600 : m <= 7 ? 0xFFFF9F1C : 0xFFFF3D6E; }
        int al(int col) { return ((int) ((col >>> 24) * showA) << 24) | (col & 0xFFFFFF); }
        String fmt(float v) { return nf.format((long) v); }

        @Override protected void onDraw(Canvas c) {
            if (showA <= 0.01f) return;
            final float w = getWidth(), h = getHeight();
            final int acc = state == BANK ? 0xFF2EE59D : state == CRASH ? 0xFFFF3D3D : tier(mult);
            c.save();
            final float sc = 0.9f + 0.1f * showA; c.scale(sc, sc, w / 2, h / 2);
            if (state == CRASH) c.translate((float) Math.sin(msgT * 60) * dp(5) * Math.min(1f, (msgT - 1.1f) * 3f + 0.2f), 0);
            // glass panel
            p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(al(0x99101318)); rf.set(0, 0, w, h); c.drawRoundRect(rf, dp(18), dp(18), p);
            if (flashT > 0) { p.setColor(al((acc & 0xFFFFFF) | ((int) (70 * flashT / 0.35f) << 24))); c.drawRoundRect(rf, dp(18), dp(18), p); }
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.5f)); p.setColor(al((acc & 0xFFFFFF) | 0x66000000)); rf.set(1, 1, w - 1, h - 1); c.drawRoundRect(rf, dp(18), dp(18), p);
            // label row
            p.setStyle(Paint.Style.FILL); p.setTextAlign(Paint.Align.LEFT);
            p.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD)); p.setTextSize(dp(12)); p.setLetterSpacing(0.18f);
            p.setColor(al(acc)); final String lab = state == BANK ? "BANKED" : state == CRASH ? "CRASHED" : "DRIFT";
            c.drawText(lab, dp(16), dp(24), p);
            p.setLetterSpacing(0f);
            if (state == DRIFT || state == GRACE) {
                p.setColor(al(state == DRIFT ? 0xCCFFFFFF : 0x66FFFFFF)); p.setTextSize(dp(12));
                c.drawText(Math.round(angle) + "\u00B0", dp(16) + p.measureText("DRIFT") + dp(22), dp(24), p);
            }
            // score
            p.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC)); p.setTextSize(dp(38));
            p.setColor(al(state == BANK ? 0xFF2EE59D : state == CRASH ? 0xFFFF6B6B : 0xFFFFFFFF));
            p.setStrikeThruText(state == CRASH);
            final float shownV = state == BANK ? score : shown;
            c.drawText(fmt(shownV), dp(16), dp(61), p);
            p.setStrikeThruText(false);
            // multiplier badge
            final float bw = dp(62), bh = dp(38), bx = w - dp(14) - bw, by = dp(14);
            if (state == DRIFT || state == GRACE) {
                c.save(); final float k = 1f + 0.35f * popT; c.scale(k, k, bx + bw / 2, by + bh / 2);
                p.setStyle(Paint.Style.FILL); p.setColor(al((acc & 0xFFFFFF) | 0x38000000)); rf.set(bx, by, bx + bw, by + bh); c.drawRoundRect(rf, dp(12), dp(12), p);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.6f)); p.setColor(al(acc)); c.drawRoundRect(rf, dp(12), dp(12), p);
                p.setStyle(Paint.Style.FILL); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(dp(26)); p.setColor(al(0xFFFFFFFF));
                c.drawText("x" + mult, bx + bw / 2, by + bh / 2 + dp(9), p);
                c.restore();
            } else if (state == BANK && newBest) {
                p.setStyle(Paint.Style.FILL); p.setTextAlign(Paint.Align.RIGHT); p.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD)); p.setTextSize(dp(12)); p.setLetterSpacing(0.1f);
                p.setColor(al(0xFFFFD600)); c.drawText("NEW BEST!", w - dp(16), dp(24), p); p.setLetterSpacing(0f);
            }
            // bar: progress to the next multiplier, drains while the chain is about to be banked / lost
            final float bx0 = dp(16), bx1 = w - dp(16), by0 = dp(72), bh2 = dp(5);
            p.setStyle(Paint.Style.FILL); p.setColor(al(0x33FFFFFF)); rf.set(bx0, by0, bx1, by0 + bh2); c.drawRoundRect(rf, bh2, bh2, p);
            float f; int bc = acc;
            if (state == DRIFT) f = mult >= 10 ? 1f : (chain % STEP_T) / STEP_T;
            else if (state == GRACE) { f = Math.max(0f, graceT / GRACE_T); bc = 0xFFFF9F1C; }
            else f = Math.max(0f, msgT / (state == BANK ? 2.0f : 1.5f));
            if (f > 0.01f) { p.setColor(al(bc)); rf.set(bx0, by0, bx0 + (bx1 - bx0) * f, by0 + bh2); c.drawRoundRect(rf, bh2, bh2, p); }
            // best
            p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD)); p.setTextSize(dp(10)); p.setLetterSpacing(0.12f);
            p.setColor(al(0x88FFFFFF)); c.drawText("BEST  " + fmt(best), w / 2, dp(88), p); p.setLetterSpacing(0f);
            c.restore();
        }
    }

    // digital speedometer with a segmented rev-style bar
    class SpeedView extends View {
        float kmh;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        SpeedView(android.content.Context ctx) { super(ctx); }
        boolean mph;
        float disp(float v) { return mph ? v * 0.621371f : v; }
        void set(float v) { if ((int) disp(v) != (int) disp(kmh)) { kmh = v; invalidate(); } else kmh = v; }
        int lerp(int a, int b, float t) {
            int ar = a >> 16 & 255, ag = a >> 8 & 255, ab = a & 255, br2 = b >> 16 & 255, bg = b >> 8 & 255, bb = b & 255;
            return 0xFF000000 | ((int) (ar + (br2 - ar) * t) << 16) | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
        }
        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            p.setStyle(Paint.Style.FILL); p.setColor(0x80101318); c.drawRoundRect(new RectF(0, 0, w, h), dp(18), dp(18), p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.5f)); p.setColor(0x33FFFFFF); c.drawRoundRect(new RectF(1, 1, w - 1, h - 1), dp(18), dp(18), p);
            p.setStyle(Paint.Style.FILL); p.setTextAlign(Paint.Align.CENTER); p.setColor(0xFFFFFFFF);
            p.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC)); p.setTextSize(dp(46));
            c.drawText(String.valueOf((int) disp(kmh)), w * 0.42f, dp(48), p);
            p.setTextSize(dp(13)); p.setColor(0xAAFFFFFF); p.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
            p.setTextAlign(Paint.Align.LEFT); c.drawText(mph ? "MPH" : "KM/H", w * 0.42f + dp(52), dp(48), p);
            int n = 24, lit = Math.min(n, Math.round(kmh / 160f * n));
            float x0 = dp(14), gap = dp(3), sw = (w - 2 * x0 - gap * (n - 1)) / n, y0 = h - dp(24), hh = dp(10);
            for (int i = 0; i < n; i++) {
                float t = i / (n - 1f);
                p.setColor(i < lit ? (t < 0.6f ? lerp(0xFF2EE59D, 0xFFFFD600, t / 0.6f) : lerp(0xFFFFD600, 0xFFFF3D3D, (t - 0.6f) / 0.4f)) : 0x33FFFFFF);
                float x = x0 + i * (sw + gap);
                Path sp = new Path(); sp.moveTo(x + dp(3), y0); sp.lineTo(x + sw + dp(3), y0); sp.lineTo(x + sw, y0 + hh); sp.lineTo(x, y0 + hh); sp.close();   // slanted segments
                c.drawPath(sp, p);
            }
        }
    }



    // =====================================================================================
    //  Modern line icons: real SVG path data (24 x 24 viewBox, 2 px round-cap strokes, Lucide style) parsed at runtime.
    // =====================================================================================
    static class SvgIcon {
        static final String[] STEER_L = { "FM14.5 5.5v13L4.5 12z", "FM21 5.5v13l-8.5-6.5z" };
        static final String[] STEER_R = { "FM9.5 5.5v13L19.5 12z", "FM3 5.5v13l8.5-6.5z" };
        static final String[] PEDAL_GAS = { "M8.2 2.8h7.6a1.6 1.6 0 0 1 1.6 1.4l1.4 15.2a2 2 0 0 1-2 2.2H7.2a2 2 0 0 1-2-2.2L6.6 4.2a1.6 1.6 0 0 1 1.6-1.4z", "FM8.4 7h7.2v1.9H8.4z", "FM8.2 11h7.6v1.9H8.2z", "FM8 15h8v1.9H8z" };
        static final String[] PEDAL_BRAKE = { "M5.5 5.5h13a3 3 0 0 1 3 3v7a3 3 0 0 1-3 3h-13a3 3 0 0 1-3-3v-7a3 3 0 0 1 3-3z", "FM6.8 9h1.9v6H6.8z", "FM11 9h1.9v6H11z", "FM15.3 9h1.9v6h-1.9z" };
        static final String[] HANDBRAKE = { "M12 2.8a9.2 9.2 0 1 0 0 18.4 9.2 9.2 0 1 0 0-18.4z", "FM9.3 7.2h3.6a2.9 2.9 0 0 1 0 5.8h-1.7v3.8H9.3z" };
        static final String[] MOON = { "FM12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9z" };
        static final String[] SUN = { "FM12 7.5a4.5 4.5 0 1 0 0 9 4.5 4.5 0 1 0 0-9z", "M12 2v2.2", "M12 19.8V22", "M4.93 4.93l1.55 1.55", "M17.52 17.52l1.55 1.55", "M2 12h2.2", "M19.8 12H22", "M6.48 17.52l-1.55 1.55", "M19.07 4.93l-1.55 1.55" };
        static final String[] WHEEL = { "M12 3a9 9 0 1 0 0 18 9 9 0 1 0 0-18z", "FM12 9.3a2.7 2.7 0 1 0 0 5.4 2.7 2.7 0 1 0 0-5.4z", "M3.3 11.2h5.9", "M14.8 11.2h5.9", "M12 14.7V20.7" };
        static final String[] SLIDERS = { "M21 4h-7", "M10 4H3", "M21 12h-9", "M8 12H3", "M21 20h-5", "M12 20H3", "M14 2v4", "M8 10v4", "M16 18v4" };
        static final String[] CAMERA = { "M3 8a2 2 0 0 1 2-2h2l1.6-2h6.8l1.6 2h2a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z", "FM12 9.4a3.6 3.6 0 1 0 0 7.2 3.6 3.6 0 1 0 0-7.2z" };
        static final String[] CLOSE = { "M18 6L6 18", "M6 6l12 12" };
        static final String[] RESET = { "M3.5 12a8.5 8.5 0 1 0 2.7-6.2", "FM2.6 2.8v6.6h6.6z" };
        static final java.util.HashMap<String, Path> cache = new java.util.HashMap<>();

        // draws the icon centred at (cx, cy), `size` px wide, in colour `col`, with a soft glow underneath; later paths of a chevron pair are dimmer
        static void draw(Canvas c, Paint p, String[] paths, float cx, float cy, float size, int col, float stroke, boolean glow) {
            c.save(); c.translate(cx - size / 2, cy - size / 2); final float k = size / 24f; c.scale(k, k);
            p.setStyle(Paint.Style.STROKE); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND); p.setShader(null);
            for (int i = 0; i < paths.length; i++) {
                final boolean fillP = paths[i].charAt(0) == 'F'; Path path = parse(fillP ? paths[i].substring(1) : paths[i]);
                final boolean dim = paths == STEER_L || paths == STEER_R ? i == 1 : false;
                final int cc = dim ? (col & 0x00FFFFFF) | 0x70000000 : col;
                if (fillP) { p.setStyle(Paint.Style.FILL); p.setColor(cc); c.drawPath(path, p); p.setStyle(Paint.Style.STROKE); continue; }
                if (glow) { p.setStrokeWidth(stroke * 2.3f); p.setColor((cc & 0x00FFFFFF) | ((cc >>> 24) / 4 << 24)); c.drawPath(path, p); }
                p.setStrokeWidth(stroke); p.setColor(cc); c.drawPath(path, p);
            }
            c.restore();
        }

        static Path parse(String d) {
            Path cached = cache.get(d); if (cached != null) return cached;
            java.util.ArrayList<String> t = new java.util.ArrayList<>();
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("[MmLlHhVvCcQqAaZz]|-?(?:\\d+\\.?\\d*|\\.\\d+)(?:[eE][-+]?\\d+)?").matcher(d);
            while (m.find()) t.add(m.group());
            Path path = new Path(); int i = 0; char cmd = 'M'; float x = 0, y = 0, sx = 0, sy = 0;
            while (i < t.size()) {
                String tok = t.get(i);
                if (Character.isLetter(tok.charAt(0))) { cmd = tok.charAt(0); i++; if (cmd == 'Z' || cmd == 'z') { path.close(); x = sx; y = sy; continue; } }
                final boolean rel = Character.isLowerCase(cmd);
                switch (Character.toUpperCase(cmd)) {
                    case 'M': { float nx = f(t, i++) + (rel ? x : 0), ny = f(t, i++) + (rel ? y : 0); path.moveTo(nx, ny); x = sx = nx; y = sy = ny; cmd = rel ? 'l' : 'L'; break; }
                    case 'L': { float nx = f(t, i++) + (rel ? x : 0), ny = f(t, i++) + (rel ? y : 0); path.lineTo(nx, ny); x = nx; y = ny; break; }
                    case 'H': { float nx = f(t, i++) + (rel ? x : 0); path.lineTo(nx, y); x = nx; break; }
                    case 'V': { float ny = f(t, i++) + (rel ? y : 0); path.lineTo(x, ny); y = ny; break; }
                    case 'C': { float x1 = f(t, i++) + (rel ? x : 0), y1 = f(t, i++) + (rel ? y : 0), x2 = f(t, i++) + (rel ? x : 0), y2 = f(t, i++) + (rel ? y : 0), nx = f(t, i++) + (rel ? x : 0), ny = f(t, i++) + (rel ? y : 0);
                        path.cubicTo(x1, y1, x2, y2, nx, ny); x = nx; y = ny; break; }
                    case 'Q': { float x1 = f(t, i++) + (rel ? x : 0), y1 = f(t, i++) + (rel ? y : 0), nx = f(t, i++) + (rel ? x : 0), ny = f(t, i++) + (rel ? y : 0);
                        path.quadTo(x1, y1, nx, ny); x = nx; y = ny; break; }
                    case 'A': { float rx = f(t, i++), ry = f(t, i++); i++; boolean large = f(t, i++) != 0, sweep = f(t, i++) != 0;
                        float nx = f(t, i++) + (rel ? x : 0), ny = f(t, i++) + (rel ? y : 0); arc(path, x, y, rx, ry, large, sweep, nx, ny); x = nx; y = ny; break; }
                    default: i++;
                }
            }
            cache.put(d, path); return path;
        }
        static float f(java.util.ArrayList<String> t, int i) { return i < t.size() ? Float.parseFloat(t.get(i)) : 0f; }

        // SVG elliptical arc (axis-aligned) -> Path.arcTo (endpoint to centre parameterisation, SVG spec F.6.5)
        static void arc(Path path, float x0, float y0, float rx, float ry, boolean large, boolean sweep, float x, float y) {
            rx = Math.abs(rx); ry = Math.abs(ry);
            if (rx == 0 || ry == 0 || (x0 == x && y0 == y)) { path.lineTo(x, y); return; }
            double dx = (x0 - x) / 2.0, dy = (y0 - y) / 2.0, lam = dx * dx / (rx * (double) rx) + dy * dy / (ry * (double) ry);
            if (lam > 1) { double sq = Math.sqrt(lam); rx *= sq; ry *= sq; }
            double num = rx * rx * ry * ry - rx * rx * dy * dy - ry * ry * dx * dx, den = rx * rx * dy * dy + ry * ry * dx * dx;
            double co = (large == sweep ? -1 : 1) * Math.sqrt(Math.max(0, num / den));
            double cxp = co * (rx * dy / ry), cyp = co * -(ry * dx / rx), cx = cxp + (x0 + x) / 2.0, cy = cyp + (y0 + y) / 2.0;
            double th1 = Math.atan2((dy - cyp) / ry, (dx - cxp) / rx), th2 = Math.atan2((-dy - cyp) / ry, (-dx - cxp) / rx), dth = th2 - th1;
            if (!sweep && dth > 0) dth -= 2 * Math.PI; else if (sweep && dth < 0) dth += 2 * Math.PI;
            path.arcTo(new RectF((float) (cx - rx), (float) (cy - ry), (float) (cx + rx), (float) (cy + ry)), (float) Math.toDegrees(th1), (float) Math.toDegrees(dth));
        }
    }


    // =====================================================================================
    //  Settings: Graphics / Sound / HUD / Control tabs. Custom-drawn controls, values kept in SharedPreferences.
    // =====================================================================================
    interface BoolCb { void on(boolean v); }
    interface IntCb { void on(int v); }
    interface FloatCb { void on(float v); }
    interface Fmt { String f(float v); }

    // ---- time of day ----
    static final String[] TOD_EN = {"Morning", "Noon", "Afternoon", "Sunset", "Dusk", "Night"};
    IconBtn todBtn;
    void applyTod() {
        final int i = Math.max(0, Math.min(5, gi("tod_idx", 1)));
        nTimeOfDay(i);
        if (todBtn != null) { todBtn.on = i <= 3; todBtn.invalidate(); }      // sun icon by day, moon icon at dusk / night
    }

    // ---- cameras ----
    static final String[] CAM_NAMES = {"Third Person", "Close Chase", "Bonnet", "Cockpit", "Dashboard"};
    TextView camTv;
    void showCamLabel(int m) { if (camTv == null) return; camTv.setText(CAM_NAMES[m]);
        if (camTv.getCompoundDrawables()[0] == null) {      // svg camera icon (no emoji) in front of the label
            final int isz = (int) dp(18);
            android.graphics.drawable.Drawable ic = new android.graphics.drawable.Drawable() {
                final Paint ip = new Paint(Paint.ANTI_ALIAS_FLAG);
                @Override public void draw(Canvas c) { SvgIcon.draw(c, ip, SvgIcon.CAMERA, isz / 2f, isz / 2f, isz, 0xFFFFFFFF, 2.2f, false); }
                @Override public void setAlpha(int a) {} @Override public void setColorFilter(android.graphics.ColorFilter cf) {}
                @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
                @Override public int getIntrinsicWidth() { return isz; } @Override public int getIntrinsicHeight() { return isz; }
            };
            ic.setBounds(0, 0, isz, isz); camTv.setCompoundDrawables(ic, null, null, null); camTv.setCompoundDrawablePadding((int) dp(8));
        }
        camTv.animate().cancel(); camTv.setAlpha(1f); camTv.animate().alpha(0f).setStartDelay(1300).setDuration(500).start(); }
    void applyCam() {
        nCamSet(gf("cam_smooth", 1f), gf("cam_dist", 1f), gf("cam_height", 1f), gf("cam_look", 1f), gb("cam_shake", true) ? 1 : 0);
        nCamMode(Math.max(0, Math.min(4, gi("cam_mode", 0))));
    }

    float gf(String k, float d) { return sp.getFloat(k, d); }
    int gi(String k, int d) { return sp.getInt(k, d); }
    boolean gb(String k, boolean d) { return sp.getBoolean(k, d); }
    void pf(String k, float v) { sp.edit().putFloat(k, v).apply(); }
    void pi(String k, int v) { sp.edit().putInt(k, v).apply(); }
    void pb(String k, boolean v) { sp.edit().putBoolean(k, v).apply(); }

    // ---- apply (called at start, and by every control when it changes) ----
    void applyAll() { applyRes(); applyGfx(); applyTod(); applySound(); applyHud(); applyControl(); applyDrive(); applyCam(); }

    void applyRes() {   // render the 3D scene at a lower resolution and let the GPU scale it up: big FPS win on high-res phones
        android.util.DisplayMetrics dm = new android.util.DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(dm);
        final int sw = Math.max(dm.widthPixels, dm.heightPixels), sh = Math.min(dm.widthPixels, dm.heightPixels);
        final int th = new int[]{480, 720, 1080, 0}[Math.max(0, Math.min(3, gi("gfx_res", 0)))];
        if (th == 0 || th >= sh) gl.getHolder().setSizeFromLayout();
        else { float sc = th / (float) sh; gl.getHolder().setFixedSize(Math.round(sw * sc), Math.round(sh * sc)); }
    }
    void applyGfx() { if (!sp.contains("gfx_quality2") && sp.contains("gfx_quality")) pi("gfx_quality2", gi("gfx_quality", 1) + 1);   // older saves: Low/Normal/High moved one place right
        final int q2 = gi("gfx_quality2", 1); nSuperSmooth(q2 == 0 ? 1 : 0); nSpeedFx(gb("gfx_speedfx", false) ? 1 : 0); nBloom(gb("gfx_bloom", true) ? 1 : 0); nShadows(gb("gfx_shadows", true) ? 1 : 0); nQuality(Math.max(0, q2 - 1)); nViewDist(gf("gfx_viewdist", 100f) / 100f); nTreeDist(gf("gfx_treedist", 2000f), gf("gfx_tree3d2", 180f)); nAssists(gb("drv_abs", true) ? 1 : 0, gb("drv_tcs", true) ? 1 : 0, gb("drv_esc", true) ? 1 : 0, gf("drv_thrcurve", 1.35f), gf("drv_brkcurve", 1.25f)); nGrassDist(gf("gfx_grassdist", 100f) / 100f); nGrassOff(gb("gfx_grass_on", true) ? 0 : 1); nGrassMode(gb("gfx_grass2d", false) ? 2 : (gb("gfx_grass3d", false) ? 1 : 0)); nGfx(gf("gfx_fov", 57f) * (float) Math.PI / 180f, gb("gfx_tyre", true) ? 1 : 0, gb("gfx_nature", false) ? 1 : 0); }
    void applySound() { engine.master = gf("snd_master", 0.8f); engine.eng = gf("snd_engine", 1f); engine.skid = gf("snd_skid", 0.8f); }
    void applyHud() {
        speed.setVisibility(gb("hud_speed", true) ? View.VISIBLE : View.GONE);
        speed.mph = gi("hud_unit", 0) == 1; speed.invalidate();
        mapShown = gb("hud_map", true); mapDp = new int[]{100, 128, 160}[Math.max(0, Math.min(2, gi("hud_mapsize", 1)))];
        miniMap.setVisibility(mapShown ? View.VISIBLE : View.GONE);
        miniMap.applySize();
        layoutTop();
        fpsTv.setVisibility(gb("hud_fps2", true) ? View.VISIBLE : View.GONE);
        driftView.setEnabled2(false);
        final float a = gf("hud_alpha", 1f);
        for (View v : ctlViews) v.setAlpha(a);
        wheelView.setAlpha(a);
    }
    // driving options: assists, gearbox, road condition, brake fade, handbrake + counter-steer strength, telemetry overlay
    void applyDrive() {
        final boolean manual = gi("drv_gearbox", 0) == 1;
        nDriveCfg(gb("drv_drift", true) ? 1 : 0, gb("drv_steerassist", true) ? 1 : 0, manual ? 1 : 0, gi("drv_road", 0), gb("drv_fade", false) ? 1 : 0, gf("drv_hbstr", 0.55f), gf("drv_counter", 0.5f));
        final int vis = manual ? View.VISIBLE : View.GONE; if (shiftUp != null) shiftUp.setVisibility(vis); if (shiftDn != null) shiftDn.setVisibility(vis);
        if (teleTv != null) teleTv.setVisibility(gb("dbg_tele", false) ? View.VISIBLE : View.GONE);
    }
    void applyControl() {
        nSens(gf("ctl_steer", 1.8f));
        nCamCfg(gf("ctl_cam", 1f), gb("ctl_cam_auto", true) ? 1 : 0, gb("ctl_cam_inv", false) ? 1 : 0);
        haptic = gb("ctl_haptic", true);
        setWheelMode(gi("ctl_mode", 0) == 1);
    }
    void setWheelMode(boolean on) {   // controls switch: buttons <-> steering wheel
        wheelBtn.on = on; wheelBtn.invalidate(); nWheelMode(on ? 1 : 0);
        wheelView.setVisibility(on ? View.VISIBLE : View.GONE);
        bl.setVisibility(on ? View.GONE : View.VISIBLE); br.setVisibility(on ? View.GONE : View.VISIBLE);
    }

    // ---- small custom widgets ----
    class Toggle extends View {
        boolean on; final int accent; final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Toggle(Context ctx, boolean on, int accent, final BoolCb cb) {
            super(ctx); this.on = on; this.accent = accent; setClickable(true);
            setOnClickListener(new View.OnClickListener() { public void onClick(View v) { Toggle.this.on = !Toggle.this.on; invalidate(); cb.on(Toggle.this.on); } });
        }
        @Override protected void onMeasure(int w, int h) { setMeasuredDimension((int) dp(48), (int) dp(28)); }
        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), r = h / 2;
            p.setStyle(Paint.Style.FILL); p.setColor(on ? 0x55FFFFFF : 0x14FFFFFF); c.drawRoundRect(new RectF(0, 0, w, h), r, r, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.2f)); p.setColor(on ? 0xCCFFFFFF : 0x66FFFFFF); c.drawRoundRect(new RectF(dp(0.6f), dp(0.6f), w - dp(0.6f), h - dp(0.6f)), r, r, p); p.setStyle(Paint.Style.FILL);
            p.setColor(on ? 0xFFFFFFFF : 0xFFAEB6C2); c.drawCircle(on ? w - r : r, r, r - dp(3.5f), p);
        }
    }

    class Slider extends View {
        final float min, max, step; float val; final int accent; final FloatCb cb; final TextView label; final Fmt fmt;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Slider(Context ctx, float min, float max, float step, float val, int accent, Fmt fmt, TextView label, FloatCb cb) {
            super(ctx); this.min = min; this.max = max; this.step = step; this.val = val; this.accent = accent; this.fmt = fmt; this.label = label; this.cb = cb;
            label.setText(fmt.f(val));
        }
        @Override protected void onMeasure(int w, int h) { setMeasuredDimension((int) dp(150), (int) dp(34)); }
        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), cy = getHeight() / 2f, pad = dp(11), tw = w - 2 * pad, f = (val - min) / (max - min);
            p.setStyle(Paint.Style.STROKE); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeWidth(dp(5));
            p.setColor(0x33FFFFFF); c.drawLine(pad, cy, w - pad, cy, p);
            p.setColor(accent | 0xFF000000); c.drawLine(pad, cy, pad + tw * f, cy, p);
            p.setStyle(Paint.Style.FILL); p.setColor(0xFFFFFFFF); c.drawCircle(pad + tw * f, cy, dp(9), p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2.5f)); p.setColor(accent | 0xFF000000); c.drawCircle(pad + tw * f, cy, dp(9), p);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
            float pad = dp(11), f = Math.max(0f, Math.min(1f, (e.getX() - pad) / (getWidth() - 2 * pad)));
            float v = min + f * (max - min); if (step > 0) v = Math.round(v / step) * step; v = Math.max(min, Math.min(max, v));
            if (v != val) { val = v; label.setText(fmt.f(v)); invalidate(); if (e.getActionMasked() != MotionEvent.ACTION_CANCEL) cb.on(v); }
            return true;
        }
    }

    class SvgView extends View {
        final String[] ic; final int col; final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        SvgView(Context ctx, String[] ic, int col) { super(ctx); this.ic = ic; this.col = col; setClickable(true); }
        @Override protected void onDraw(Canvas c) { SvgIcon.draw(c, p, ic, getWidth() / 2f, getHeight() / 2f, Math.min(getWidth(), getHeight()) * 0.6f, col, 2.2f, false); }
    }

    TextView tv(String text, float sizeSp, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(text); t.setTextSize(sizeSp); t.setTextColor(color);
        t.setTypeface(Typeface.create(bold ? "sans-serif-medium" : "sans-serif", Typeface.NORMAL)); return t;
    }
    GradientDrawable pill(int fill, int stroke, float radiusDp) {
        GradientDrawable g = new GradientDrawable(); g.setColor(fill); g.setCornerRadius(dp(radiusDp)); if (stroke != 0) g.setStroke((int) dp(1.2f), stroke); return g;
    }
    View divider() { View v = new View(this); v.setBackgroundColor(0x16FFFFFF); v.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)); return v; }

    void addRow(LinearLayout ll, String title, String desc, View widget) {
        LinearLayout r = new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL); r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, (int) dp(9), 0, (int) dp(9));
        LinearLayout left = new LinearLayout(this); left.setOrientation(LinearLayout.VERTICAL);
        left.addView(tv(title, 14.5f, 0xFFFFFFFF, true));
        if (desc != null) left.addView(tv(desc, 11f, 0x88FFFFFF, false));
        r.addView(left, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)); r.addView(widget);
        ll.addView(r); ll.addView(divider());
    }
    void toggle(LinearLayout ll, int acc, String title, String desc, final String key, boolean def, final BoolCb cb) {
        addRow(ll, title, desc, new Toggle(this, gb(key, def), acc, new BoolCb() { public void on(boolean v) { pb(key, v); cb.on(v); } }));
    }
    void slider(LinearLayout ll, int acc, String title, String desc, final String key, float def, float min, float max, float step, Fmt fmt, final FloatCb cb) {
        LinearLayout w = new LinearLayout(this); w.setOrientation(LinearLayout.HORIZONTAL); w.setGravity(Gravity.CENTER_VERTICAL);
        TextView lab = tv("", 13f, acc | 0xFF000000, true); lab.setGravity(Gravity.END); lab.setMinWidth((int) dp(52));
        w.addView(new Slider(this, min, max, step, gf(key, def), acc, fmt, lab, new FloatCb() { public void on(float v) { pf(key, v); cb.on(v); } }));
        w.addView(lab); addRow(ll, title, desc, w);
    }
    void seg(LinearLayout ll, final int acc, String title, String desc, final String key, int def, String[] opts, final IntCb cb) {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setBackground(pill(0x22FFFFFF, 0, 14)); row.setPadding((int) dp(3), (int) dp(3), (int) dp(3), (int) dp(3));
        final TextView[] t = new TextView[opts.length];
        for (int i = 0; i < opts.length; i++) {
            t[i] = tv(opts[i], 12f, 0xCCFFFFFF, true); t[i].setGravity(Gravity.CENTER); final int hp = opts.length > 4 ? 5 : 11; t[i].setPadding((int) dp(hp), (int) dp(6), (int) dp(hp), (int) dp(6)); row.addView(t[i]);
            final int idx = i;
            t[i].setOnClickListener(new View.OnClickListener() { public void onClick(View v) { styleSeg(t, idx, acc); pi(key, idx); cb.on(idx); } });
        }
        styleSeg(t, Math.max(0, Math.min(opts.length - 1, gi(key, def))), acc); addRow(ll, title, desc, row);
    }
    void styleSeg(TextView[] t, int sel, int acc) {
        for (int i = 0; i < t.length; i++) {
            if (i == sel) { t[i].setBackground(pill(0x33FFFFFF, 0xCCFFFFFF, 11)); t[i].setTextColor(0xFFFFFFFF); } else { t[i].setBackground(null); t[i].setTextColor(0xCCFFFFFF); }
        }
    }

    // ---- the four tabs ----
    static final int ACC_GFX = 0xFFFFFF, ACC_SND = 0xFFFFFF, ACC_HUD = 0xFFFFFF, ACC_CTL = 0xFFFFFF, ACC_CAM = 0xFFFFFF;
    void buildTab(LinearLayout ll, int tab) {
        if (tab == 0) {
            seg(ll, ACC_GFX, "Time of day", "Morning, noon, afternoon, sunset, dusk or night (also the sun / moon button, top left)", "tod_idx", 1, TOD_EN, new IntCb() { public void on(int v) { applyTod(); } });
            seg(ll, ACC_GFX, "Graphics quality", "Super smooth = fastest of all (480p, every tree is a flat 2D picture, no grass / flowers, little tyre smoke), Low = fast (480p, no grass blades / god rays / speed effects), Normal = balanced (720p, full bloom + god rays), High = best looking (1080p, smoothest bloom, longer view distance)", "gfx_quality2", 1, new String[]{"Super smooth", "Low", "Normal", "High"}, new IntCb() { public void on(int v) {
                final int lv = Math.max(0, v - 1);       // 0 super smooth / 1 low -> low settings, 2 normal, 3 high
                pi("gfx_res", lv);                       // Super smooth + Low 480p / Normal 720p / High 1080p
                pb("gfx_nature", lv != 0);               // Super smooth + Low: no waterfall & valley cloud
                pb("gfx_tyre", true);
                pb("gfx_speedfx", lv != 0);              // Super smooth + Low: no motion blur / speed lines / camera shake (saves GPU)
                pf("gfx_treedist", v == 0 ? 1500f : (lv == 0 ? 2000f : (lv == 2 ? 6000f : 4000f))); pf("gfx_tree3d2", lv == 0 ? 180f : (lv == 2 ? 250f : 180f));   // preset sets a matching tree distance (still adjustable below)
                applyRes(); applyGfx();
                if (refreshTab != null) refreshTab.run();   // other controls follow the preset
            } });
            seg(ll, ACC_GFX, "Resolution", "Lower = smoother on slow phones", "gfx_res", 0, new String[]{"480p", "720p", "1080p", "Native"}, new IntCb() { public void on(int v) { applyRes(); } });
            slider(ll, ACC_GFX, "Field of view", "Wider = more speed feeling", "gfx_fov", 57f, 45f, 80f, 1f, new Fmt() { public String f(float v) { return (int) v + "\u00B0"; } }, new FloatCb() { public void on(float v) { applyGfx(); } });
            slider(ll, ACC_GFX, "World draw distance", "How far houses, fences, lamps and boulders are drawn. Lower = faster, higher = see farther", "gfx_viewdist", 100f, 40f, 200f, 10f, new Fmt() { public String f(float v) { return (int) v + " %"; } }, new FloatCb() { public void on(float v) { applyGfx(); } });
            slider(ll, ACC_GFX, "Tree distance", "How far trees are seen (far ones = 2D picture facing you)", "gfx_treedist", 2000f, 500f, 6500f, 250f, new Fmt() { public String f(float v) { return (int) v + " m"; } }, new FloatCb() { public void on(float v) { applyGfx(); } });
            toggle(ll, ACC_GFX, "Grass", "Switch ALL grass, tall grass and flowers on or off. Off = fastest, bushes stay", "gfx_grass_on", true, new BoolCb() { public void on(boolean v) { applyGfx(); } });
            slider(ll, ACC_GFX, "Grass distance", "How far grass, flowers and tall grass are drawn. Lower = faster", "gfx_grassdist", 100f, 10f, 100f, 5f, new Fmt() { public String f(float v) { return (int) v + " %"; } }, new FloatCb() { public void on(float v) { applyGfx(); } });
            toggle(ll, ACC_GFX, "All grass 3D", "Every grass tuft is real 3D (best look, slower). Ignored if 'All grass 2D' is on", "gfx_grass3d", false, new BoolCb() { public void on(boolean v) { applyGfx(); } });
            toggle(ll, ACC_GFX, "All grass 2D", "Every grass tuft is a flat picture (fastest)", "gfx_grass2d", false, new BoolCb() { public void on(boolean v) { applyGfx(); } });
            slider(ll, ACC_GFX, "3D tree distance", "Closer than this = real 3D tree, farther = 2D picture. Lower = faster", "gfx_tree3d2", 180f, 60f, 600f, 10f, new Fmt() { public String f(float v) { return (int) v + " m"; } }, new FloatCb() { public void on(float v) { applyGfx(); } });
            toggle(ll, ACC_GFX, "Tyre smoke & skid marks", null, "gfx_tyre", true, new BoolCb() { public void on(boolean v) { applyGfx(); } });
            toggle(ll, ACC_GFX, "Speed effects", "Motion blur, speed lines, wider view at speed, camera shake in drifts", "gfx_speedfx", false, new BoolCb() { public void on(boolean v) { applyGfx(); } });
            toggle(ll, ACC_GFX, "Bloom", "Soft glow around the sun, bright sky and lights. Off = no glow at all (also saves GPU)", "gfx_bloom", true, new BoolCb() { public void on(boolean v) { applyGfx(); } });
            toggle(ll, ACC_GFX, "Shadows", "Soft shadow under the car. Off = no shadows at all", "gfx_shadows", true, new BoolCb() { public void on(boolean v) { applyGfx(); } });
            toggle(ll, ACC_GFX, "Waterfall & valley cloud", null, "gfx_nature", false, new BoolCb() { public void on(boolean v) { applyGfx(); } });
        } else if (tab == 1) {
            Fmt pct = new Fmt() { public String f(float v) { return Math.round(v * 100) + "%"; } };
            slider(ll, ACC_SND, "Master volume", null, "snd_master", 0.8f, 0f, 1f, 0.05f, pct, new FloatCb() { public void on(float v) { applySound(); } });
            slider(ll, ACC_SND, "Engine", "Pitch follows rpm and throttle", "snd_engine", 1f, 0f, 1f, 0.05f, pct, new FloatCb() { public void on(float v) { applySound(); } });
            slider(ll, ACC_SND, "Tyre screech", "When the car drifts or the handbrake locks", "snd_skid", 0.8f, 0f, 1f, 0.05f, pct, new FloatCb() { public void on(float v) { applySound(); } });
        } else if (tab == 2) {
            toggle(ll, ACC_HUD, "Speedometer", null, "hud_speed", true, new BoolCb() { public void on(boolean v) { applyHud(); } });
            seg(ll, ACC_HUD, "Speed unit", null, "hud_unit", 0, new String[]{"km/h", "mph"}, new IntCb() { public void on(int v) { applyHud(); } });
            toggle(ll, ACC_HUD, "Minimap", "Tap the minimap to open it large / close it", "hud_map", true, new BoolCb() { public void on(boolean v) { applyHud(); } });
            seg(ll, ACC_HUD, "Minimap size", null, "hud_mapsize", 1, new String[]{"Small", "Medium", "Large"}, new IntCb() { public void on(int v) { applyHud(); } });
            toggle(ll, ACC_HUD, "FPS counter", "Shown at the bottom of the screen", "hud_fps2", true, new BoolCb() { public void on(boolean v) { applyHud(); } });
            slider(ll, ACC_HUD, "Button opacity", "Driving buttons and steering wheel", "hud_alpha", 1f, 0.3f, 1f, 0.05f, new Fmt() { public String f(float v) { return Math.round(v * 100) + "%"; } }, new FloatCb() { public void on(float v) { applyHud(); } });
        } else if (tab == 3) {
            seg(ll, ACC_CTL, "Steering", null, "ctl_mode", 0, new String[]{"Buttons", "Wheel"}, new IntCb() { public void on(int v) { applyControl(); } });
            slider(ll, ACC_CTL, "Steering sensitivity", "How fast the wheels turn", "ctl_steer", 1.8f, 0.6f, 3f, 0.1f, new Fmt() { public String f(float v) { return String.format(java.util.Locale.US, "%.1f", v); } }, new FloatCb() { public void on(float v) { applyControl(); } });
            slider(ll, ACC_CTL, "Camera sensitivity", "Drag on the screen to look around", "ctl_cam", 1f, 0.3f, 2f, 0.1f, new Fmt() { public String f(float v) { return String.format(java.util.Locale.US, "%.1fx", v); } }, new FloatCb() { public void on(float v) { applyControl(); } });
            toggle(ll, ACC_CTL, "Camera returns behind the car", "A moment after you let go", "ctl_cam_auto", true, new BoolCb() { public void on(boolean v) { applyControl(); } });
            toggle(ll, ACC_CTL, "Invert camera up / down", null, "ctl_cam_inv", false, new BoolCb() { public void on(boolean v) { applyControl(); } });
            toggle(ll, ACC_CTL, "Vibration on buttons", null, "ctl_haptic", true, new BoolCb() { public void on(boolean v) { applyControl(); } });
            toggle(ll, ACC_CTL, "ABS", "Brakes never lock up, braking stays strong", "drv_abs", true, new BoolCb() { public void on(boolean v) { applyGfx(); } });
            toggle(ll, ACC_CTL, "Traction control", "Cuts power when the rear wheels spin too much", "drv_tcs", true, new BoolCb() { public void on(boolean v) { applyGfx(); } });
            toggle(ll, ACC_CTL, "Stability control", "Calms a spin that runs away; normal drift angles are left alone", "drv_esc", true, new BoolCb() { public void on(boolean v) { applyGfx(); } });
            slider(ll, ACC_CTL, "Throttle response", "Lower = sharper pedal, higher = gentler at the start", "drv_thrcurve", 1.35f, 0.8f, 2.2f, 0.05f, new Fmt() { public String f(float v) { return String.format(java.util.Locale.US, "%.2f", v); } }, new FloatCb() { public void on(float v) { applyGfx(); } });
            slider(ll, ACC_CTL, "Brake sensitivity", "Lower = stronger bite at light pressure", "drv_brkcurve", 1.25f, 0.8f, 2.2f, 0.05f, new Fmt() { public String f(float v) { return String.format(java.util.Locale.US, "%.2f", v); } }, new FloatCb() { public void on(float v) { applyGfx(); } });
            toggle(ll, ACC_CTL, "Drift assist", "Lets you hold a long drift on a touch screen; rescues a slide that runs too wide", "drv_drift", true, new BoolCb() { public void on(boolean v) { applyDrive(); } });
            toggle(ll, ACC_CTL, "Steering assist", "Takes some lock off when the front tyres start to plough", "drv_steerassist", true, new BoolCb() { public void on(boolean v) { applyDrive(); } });
            slider(ll, ACC_CTL, "Counter-steer assist", "How much the car steers into a slide by itself", "drv_counter", 0.5f, 0f, 1f, 0.05f, new Fmt() { public String f(float v) { return Math.round(v * 100) + "%"; } }, new FloatCb() { public void on(float v) { applyDrive(); } });
            slider(ll, ACC_CTL, "Handbrake strength", "How hard the locked rear wheels brake the car", "drv_hbstr", 0.55f, 0.2f, 1f, 0.05f, new Fmt() { public String f(float v) { return Math.round(v * 100) + "%"; } }, new FloatCb() { public void on(float v) { applyDrive(); } });
            seg(ll, ACC_CTL, "Gearbox", "Manual shows two shift buttons (keys: E up, Q down)", "drv_gearbox", 0, new String[]{"Automatic", "Manual"}, new IntCb() { public void on(int v) { applyDrive(); } });
            seg(ll, ACC_CTL, "Road condition", "Changes the grip of every surface", "drv_road", 0, new String[]{"Dry", "Wet", "Snow", "Ice"}, new IntCb() { public void on(int v) { applyDrive(); } });
            toggle(ll, ACC_CTL, "Brake fade", "Brakes lose bite after repeated hard stops from high speed", "drv_fade", false, new BoolCb() { public void on(boolean v) { applyDrive(); } });
            toggle(ll, ACC_CTL, "Telemetry overlay (development)", "Speed, rpm, gear, slip, g-force, assists", "dbg_tele", false, new BoolCb() { public void on(boolean v) { applyDrive(); } });
        }
        else {
            seg(ll, ACC_CAM, "Camera", "Also the camera button at the top of the screen: Third Person > Close Chase > Bonnet > Cockpit > Dashboard", "cam_mode", 0, CAM_NAMES, new IntCb() { public void on(int v) { applyCam(); } });
            slider(ll, ACC_CAM, "Field of view", "Wider = more speed feeling (cockpit cameras add a little more)", "gfx_fov", 57f, 45f, 80f, 1f, new Fmt() { public String f(float v) { return (int) v + "\u00B0"; } }, new FloatCb() { public void on(float v) { applyGfx(); } });
            slider(ll, ACC_CAM, "Camera sensitivity", "Drag on the screen to orbit (chase) or look around (cockpit)", "ctl_cam", 1f, 0.3f, 2f, 0.1f, new Fmt() { public String f(float v) { return String.format(java.util.Locale.US, "%.1fx", v); } }, new FloatCb() { public void on(float v) { applyControl(); } });
            slider(ll, ACC_CAM, "Cockpit look sensitivity", "Extra sensitivity for looking around inside the car", "cam_look", 1f, 0.3f, 2f, 0.1f, new Fmt() { public String f(float v) { return String.format(java.util.Locale.US, "%.1fx", v); } }, new FloatCb() { public void on(float v) { applyCam(); } });
            slider(ll, ACC_CAM, "Camera smoothing", "Higher = the chase camera lags more behind the car", "cam_smooth", 1f, 0.3f, 2f, 0.1f, new Fmt() { public String f(float v) { return String.format(java.util.Locale.US, "%.1fx", v); } }, new FloatCb() { public void on(float v) { applyCam(); } });
            slider(ll, ACC_CAM, "Chase camera distance", "Third Person / Close Chase", "cam_dist", 1f, 0.6f, 1.6f, 0.05f, new Fmt() { public String f(float v) { return Math.round(v * 100) + "%"; } }, new FloatCb() { public void on(float v) { applyCam(); } });
            slider(ll, ACC_CAM, "Chase camera height", "Third Person / Close Chase", "cam_height", 1f, 0.6f, 1.6f, 0.05f, new Fmt() { public String f(float v) { return Math.round(v * 100) + "%"; } }, new FloatCb() { public void on(float v) { applyCam(); } });
            toggle(ll, ACC_CAM, "Camera shake / body movement", "Cornering lean, acceleration and braking head movement, drift shake. Off = steady camera", "cam_shake", true, new BoolCb() { public void on(boolean v) { applyCam(); } });
            toggle(ll, ACC_CAM, "Speed effects", "Motion blur, speed lines, wider view at speed", "gfx_speedfx", false, new BoolCb() { public void on(boolean v) { applyGfx(); } });
        }
    }

    // ---- the panel (game is paused while it is open) ----
    int curTab = 0; Runnable refreshTab;
    void openSettings() {
        if (settingsLayer != null) return;
        mask = 0; pedT = pedB = -1; nPedals(-1, -1); nInput(kmask); nWheelUp(); nCamRelease(); nPause(1);
        final FrameLayout layer = new FrameLayout(this); layer.setBackgroundColor(0x88000000); layer.setClickable(true);
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        final int pw = Math.min((int) dp(620), dm.widthPixels - (int) dp(32)), ph = Math.min((int) dp(340), dm.heightPixels - (int) dp(24));
        LinearLayout panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(pill(0xEE111720, 0x33FFFFFF, 22)); panel.setPadding((int) dp(18), (int) dp(12), (int) dp(18), (int) dp(10));
        // header: title, reset, close
        LinearLayout head = new LinearLayout(this); head.setOrientation(LinearLayout.HORIZONTAL); head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = tv("Settings", 19f, 0xFFFFFFFF, true); head.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        final TextView reset = tv("Reset", 12.5f, 0xFFFFFFFF, true); reset.setPadding((int) dp(12), (int) dp(6), (int) dp(12), (int) dp(6)); reset.setBackground(pill(0x14FFFFFF, 0x99FFFFFF, 14));
        head.addView(reset);
        SvgView close = new SvgView(this, SvgIcon.CLOSE, 0xFFEAF0F6); LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams((int) dp(38), (int) dp(38)); clp.leftMargin = (int) dp(8);
        close.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { closeSettings(); } }); head.addView(close, clp);
        panel.addView(head);
        // tabs
        LinearLayout tabs = new LinearLayout(this); tabs.setOrientation(LinearLayout.HORIZONTAL);
        final String[] names = {"Graphics", "Sound", "HUD", "Control", "Camera"}; final int[] accs = {ACC_GFX, ACC_SND, ACC_HUD, ACC_CTL, ACC_CAM};
        final TextView[] tabViews = new TextView[5];
        final LinearLayout content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        final Runnable[] show = new Runnable[1];
        for (int i = 0; i < 5; i++) {
            final int idx = i; tabViews[i] = tv(names[i], 13.5f, 0xAAFFFFFF, true); tabViews[i].setGravity(Gravity.CENTER); tabViews[i].setPadding(0, (int) dp(8), 0, (int) dp(8));
            LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f); tlp.setMargins((int) dp(3), (int) dp(8), (int) dp(3), (int) dp(4));
            tabViews[i].setOnClickListener(new View.OnClickListener() { public void onClick(View v) { curTab = idx; show[0].run(); } });
            tabs.addView(tabViews[i], tlp);
        }
        panel.addView(tabs);
        show[0] = new Runnable() { public void run() {
            for (int i = 0; i < 5; i++) {
                if (i == curTab) { tabViews[i].setBackground(pill((accs[i] | 0x33000000), accs[i] | 0xFF000000, 14)); tabViews[i].setTextColor(accs[i] | 0xFF000000); }
                else { tabViews[i].setBackground(null); tabViews[i].setTextColor(0xAAFFFFFF); }
            }
            content.removeAllViews(); buildTab(content, curTab);
        } };
        reset.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { sp.edit().clear().apply(); applyAll(); show[0].run(); } });
        ScrollView sv = new ScrollView(this); sv.setFillViewport(true); sv.setVerticalScrollBarEnabled(false); sv.addView(content);
        panel.addView(sv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        refreshTab = show[0]; show[0].run();
        layer.addView(panel, new FrameLayout.LayoutParams(pw, ph, Gravity.CENTER));
        rootView.addView(layer, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        layer.setPadding(cutPad[0], cutPad[1], cutPad[2], cutPad[3]);
        settingsLayer = layer;
    }
    void closeSettings() {
        if (settingsLayer == null) return;
        rootView.removeView(settingsLayer); settingsLayer = null; refreshTab = null; nPause(0);
    }

    // =====================================================================================
    //  Engine sound: the real Audi R8 V10 recording from the HTML game (two seamless 22.05 kHz loops, eng_idle.pcm + eng_main.pcm).
    //  Both loops are re-pitched by the car's rpm and cross-faded (equal power, log rpm) like the HTML; wind + tyre squeal are added on top.
    // =====================================================================================
    static class EngineSound implements Runnable {
        volatile float master = 0.8f, eng = 1f, skid = 0.8f; volatile boolean run; volatile int gen; Thread th; android.content.res.AssetManager am;
        static final float MAIN_REF = 3500f, IDLE_REF = 1300f;
        void start() { if (run) return; run = true; final int my = ++gen; th = new Thread(new Runnable() { public void run() { EngineSound.this.run(my); } }, "engine-sound"); th.setDaemon(true); th.start(); }
        volatile AudioTrack cur;
        void stop() { run = false; gen++; th = null; final AudioTrack t = cur; if (t != null) { try { t.setVolume(0f); t.pause(); t.flush(); } catch (Throwable e) { } } }   // silence at once: the queued audio is dropped now, not after the thread notices
        static float[] load(android.content.res.AssetManager am, String name) {
            try {
                java.io.InputStream in = am.open(name); java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream(); byte[] b = new byte[16384]; int n;
                while ((n = in.read(b)) > 0) o.write(b, 0, n); in.close();
                final byte[] d = o.toByteArray(); final float[] f = new float[d.length / 2];
                for (int i = 0; i < f.length; i++) f[i] = (short) ((d[2 * i] & 255) | (d[2 * i + 1] << 8)) / 32768f;
                return f;
            } catch (Throwable t) { return null; }
        }
        public void run() { }
        void run(final int my) {
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_AUDIO);
            final int sr = 22050; AudioTrack at;
            final float[] mainL = load(am, "eng_main.pcm"), idleL = load(am, "eng_idle.pcm");
            if (mainL == null || idleL == null) { if (my == gen) run = false; return; }
            if (!run || my != gen) return;
            try {
                final int minB = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
                at = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    .setAudioFormat(new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(Math.max(minB, 4096)).setTransferMode(AudioTrack.MODE_STREAM).build();
                at.play(); cur = at;
            } catch (Throwable t) { if (my == gen) run = false; return; }
            final short[] buf = new short[512]; final float[] st = new float[9];
            double pm = 0, pi = 0; float cI = 1, cM = 0, rpm = 900, thr = 0, sk = 0, wind = 0, wt = 0, lp = 0, l1 = 0, l2 = 0, w1 = 0, w2 = 0, gx = 0, gy = 0, chop = 1, eg = 0; int seed = 12345, tick = 0;
            final double LN1 = Math.log(1400), LN2 = Math.log(2800);
            while (run && my == gen) {
                MainActivity.nSound(st); final float rT = st[0], tT = st[1], sT = st[2], kmh = st[3], limT = st[7], wtT = st[8];
                final float windT = Math.min(kmh / 115f, 1f) * 0.10f;
                final float egT = (Math.abs(kmh) > 1.5f || tT > 0.05f) ? 1f : 0f;   // car stopped and no throttle: the engine goes completely silent
                {   // the idle / main cross-fade only needs updating once per buffer (23 ms), not per sample: no log / sin / cos in the inner loop
                    final double x = Math.min(Math.max((Math.log(Math.max(rpm, 1f)) - LN1) / (LN2 - LN1), 0), 1);
                    cI = (float) Math.cos(x * Math.PI / 2); cM = (float) Math.sin(x * Math.PI / 2);
                }
                for (int i = 0; i < buf.length; i++) {
                    rpm += (rT - rpm) * 0.0016f; thr += (tT - thr) * 0.0016f; sk += (sT - sk) * 0.0016f; wind += (windT - wind) * 0.0004f; wt += (wtT - wt) * 0.0025f; eg += (egT - eg) * 0.0006f;
                    // re-pitched loops (linear interpolation) cross-faded by log rpm
                    pm += Math.min(Math.max(rpm / MAIN_REF, 0.3f), 2.6f); if (pm >= mainL.length) pm -= mainL.length;
                    pi += Math.min(Math.max(rpm / IDLE_REF, 0.5f), 2.2f); if (pi >= idleL.length) pi -= idleL.length;
                    final int m0 = (int) pm, m1 = m0 + 1 < mainL.length ? m0 + 1 : 0, i0 = (int) pi, i1 = i0 + 1 < idleL.length ? i0 + 1 : 0;
                    final float sm = mainL[m0] + (mainL[m1] - mainL[m0]) * (float) (pm - m0), si = idleL[i0] + (idleL[i1] - idleL[i0]) * (float) (pi - i0);
                    float s = si * cI + sm * cM;
                    lp += (s - lp) * Math.min(1f, (3000f + rpm * 0.6f + thr * 7000f) * (5.5f / 22050f));           // brighter on throttle, duller off throttle
                    if ((++tick & 511) == 0) chop = ((limT > 0.5f || rpm > 6850) && thr > 0.5f && ((System.nanoTime() / 55000000L) & 1) == 1) ? 0.3f : 1f;   // rev limiter chop
                    final float gain = (0.34f + thr * 0.66f) * (0.75f + 0.25f * rpm / 7000f) * 1.25f * 0.45f;
                    seed = seed * 1664525 + 1013904223; final float n = ((seed >>> 8) / 8388608f) - 1f;
                    l1 += (n - l1) * 0.35f; l2 += (l1 - l2) * 0.35f;                                             // band-passed noise = tyre squeal
                    w1 += (n - w1) * 0.12f; w2 += (w1 - w2) * 0.12f;                                              // low rumble = wind
                    float out = (lp * gain * chop * eng * eg + (l1 - l2) * sk * 1.6f * skid + w2 * wind * 2.2f + ((n - w1) * 0.30f + (l1 - l2) * 0.9f + w2 * 0.6f) * wt * 0.55f) * master;   // + the hiss / rush of water thrown by the tyres in a puddle
                    out = out / (1f + Math.abs(out) * 0.6f);                                                      // soft clip
                    buf[i] = (short) (out * 30000f);
                }
                if (at.write(buf, 0, buf.length) < 0) break;
            }
            if (cur == at) cur = null;
            try { at.pause(); at.flush(); at.stop(); } catch (Throwable t) { }
            try { at.release(); } catch (Throwable t) { }
        }
    }

    // =====================================================================================
    //  Minimap (round, top-left): roads, river, dirt track, lake, village, cable car + the car.
    //  Default = zoomed, heading-up (the car always points up). Tap = whole map, north-up.
    // =====================================================================================
    class MiniMapView extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Path roads = new Path(), conn = new Path(), river = new Path(), track = new Path(), bound = new Path(), cable = new Path();
        final java.util.ArrayList<float[]> huts = new java.util.ArrayList<>(), churches = new java.util.ArrayList<>(), pylons = new java.util.ArrayList<>(), cabSt = new java.util.ArrayList<>();
        float[] pois = new float[0], mts = new float[0];   // pois: [x, z, type]...   mts: [x, z, rx, rz]...
        float lakeX, lakeZ, lakeR; boolean haveLake, loaded;
        final float[] pose = new float[3]; boolean full;
        final Matrix m = new Matrix(); final float[] mv = new float[9];
        final Path clip = new Path(), arrow = new Path();
        static final float ZOOM_R = 230f, FULL_R = 1480f;      // metres shown from the centre to the edge

        boolean big;      // tap: opens the whole map in a large view in the middle of the screen; tap again to close
        void applySize() {
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) getLayoutParams(); if (lp == null) return;
            if (big) {
                android.util.DisplayMetrics dmx = getResources().getDisplayMetrics();
                lp.width = lp.height = Math.min(dmx.widthPixels, dmx.heightPixels) - (int) dp(16);
                lp.gravity = Gravity.CENTER; lp.setMargins(0, 0, 0, 0);
                setElevation(dp(8)); setAlpha(0.65f);
            } else {
                lp.width = lp.height = (int) dp(mapDp);
                lp.gravity = Gravity.TOP | Gravity.START; lp.setMargins((int) dp(14), (int) dp(12), 0, 0);
                setElevation(0); setAlpha(0.8f);
            }
            setLayoutParams(lp); bringToFront();
        }
        MiniMapView(android.content.Context ctx) {
            super(ctx); setClickable(true);
            setOnClickListener(new View.OnClickListener() { public void onClick(View v) { big = !big; full = big; applySize(); invalidate(); } });
            p.setStrokeJoin(Paint.Join.ROUND); p.setStrokeCap(Paint.Cap.ROUND);
        }
        void load() {
            float[] d = nMapData(); if (d == null) return;
            int i = 0;
            while (i + 1 < d.length) {
                int kind = (int) d[i], n = (int) d[i + 1]; i += 2;
                if (kind == 20) { pois = java.util.Arrays.copyOfRange(d, i, i + n * 3); i += n * 3; continue; }
                if (kind == 21) { mts = java.util.Arrays.copyOfRange(d, i, i + n * 4); i += n * 4; continue; }
                if (kind == 4) { lakeX = d[i]; lakeZ = d[i + 1]; lakeR = d[i + 2]; haveLake = true; i += 3; continue; }
                Path t = kind == 0 ? roads : kind == 1 ? conn : kind == 2 ? river : kind == 3 ? track : kind == 7 ? bound : kind == 12 ? cable : null;
                float[] pts = (t == null) ? new float[n * 2] : null;
                for (int k = 0; k < n; k++) {
                    float x = d[i + k * 2], z = d[i + k * 2 + 1];
                    if (t != null) { if (k == 0) t.moveTo(x, z); else t.lineTo(x, z); } else { pts[k * 2] = x; pts[k * 2 + 1] = z; }
                }
                if (kind == 7) bound.close();
                if (kind == 5) huts.add(pts); else if (kind == 6) churches.add(pts); else if (kind == 13) pylons.add(pts); else if (kind == 14) cabSt.add(pts);
                i += n * 2;
            }
            loaded = true;
        }
        void tick() {
            if (!loaded) load();
            nCarPose(pose); invalidate();
        }
        @Override public boolean performClick() { return super.performClick(); }

        void line(Canvas c, Path path, float wMetres, float minPx, float s, int col) {
            p.setStyle(Paint.Style.STROKE); p.setColor(col); p.setStrokeWidth(Math.max(wMetres, dp(minPx) / s)); c.drawPath(path, p);
        }
        void dots(Canvas c, java.util.ArrayList<float[]> list, float rPx, float s, int col) {
            p.setStyle(Paint.Style.FILL); p.setColor(col);
            for (float[] a : list) for (int k = 0; k + 1 < a.length; k += 2) c.drawCircle(a[k], a[k + 1], rPx / s, p);
        }
        // a text label beside a map point; dir -1 = above, +1 = below; skipped outside the disc, flipped to the left side when it would run off the edge
        void label(Canvas c, String t, float sx, float sy, float cx, float cy, float r, int dir, int col) {
            float dx = sx - cx, dy = sy - cy; if (dx * dx + dy * dy > (r - dp(10)) * (r - dp(10))) return;
            float tw = p.measureText(t), ox = dp(8), oy = dir < 0 ? -dp(7) : dp(14);
            boolean left = Math.hypot(dx + ox + tw, dy + oy) > r - dp(3);
            float tx = left ? sx - ox - tw : sx + ox, ty = sy + oy; if (Math.hypot(tx - cx + (left ? 0 : tw), ty - cy) > r) return;
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2.6f)); p.setStrokeJoin(Paint.Join.ROUND); p.setColor(0xDD0E141A); c.drawText(t, tx, ty, p);
            p.setStyle(Paint.Style.FILL); p.setColor(col); c.drawText(t, tx, ty, p);
        }
        // legend (large map only): what each line means
        void legend(Canvas c, float cx, float cy, float r) {
            final String[] names = {"Road", "Cable car", "River", "Hill road", "Village", "Church", "Mountain", "Lake / pond", "Bridge", "Summit: food + fuel"};
            final int[] cols = {0xFFC9CED6, 0xFFFF4D9A, 0xFF3D9BE0, 0xFFB08A5A, 0xFFFFB866, 0xFFFFFFFF, 0xFFC9A15A, 0xFF2F8FD0, 0xFFE6E9EE, 0xFFE85D3A};
            float rowH = dp(14), y0 = cy + r * 0.40f, yb = y0 + rowH * 5 + dp(2);
            float half = (float) Math.sqrt(Math.max(r * r - (yb - cy) * (yb - cy), 0)), tot = Math.max(half * 2 - dp(10), dp(150)), colW = tot / 2f, x0 = cx - tot / 2f;
            p.setStyle(Paint.Style.FILL); p.setColor(0xB30E141A); c.drawRoundRect(new RectF(x0 - dp(5), y0 - dp(4), x0 + tot + dp(5), yb), dp(7), dp(7), p);
            p.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD)); p.setTextSize(dp(9)); p.setTextAlign(Paint.Align.LEFT); p.setStrokeCap(Paint.Cap.BUTT);
            for (int k = 0; k < 10; k++) {
                float lx = x0 + (k % 2) * colW, ly = y0 + (k / 2) * rowH + dp(6);
                p.setPathEffect(null);
                if (k <= 3) {
                    p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(k == 0 ? 3f : 2.6f)); p.setColor(cols[k]);
                    if (k == 1) p.setPathEffect(new android.graphics.DashPathEffect(new float[]{dp(5), dp(3)}, 0));
                    c.drawLine(lx, ly, lx + dp(16), ly, p); p.setPathEffect(null);
                } else {
                    p.setStyle(Paint.Style.FILL); float mx = lx + dp(8);
                    if (k == 8) { p.setColor(0xFF0E1216); c.drawRect(mx - dp(4), ly - dp(4), mx + dp(4), ly + dp(4), p); p.setColor(cols[k]); c.drawRect(mx - dp(2.4f), ly - dp(2.4f), mx + dp(2.4f), ly + dp(2.4f), p); }
                    else if (k == 6) { p.setColor(0xFF1B1409); c.drawCircle(mx, ly, dp(5.5f), p); p.setColor(cols[k]); arrow.reset(); arrow.moveTo(mx, ly - dp(4)); arrow.lineTo(mx + dp(4.4f), ly + dp(3)); arrow.lineTo(mx - dp(4.4f), ly + dp(3)); arrow.close(); c.drawPath(arrow, p); }
                    else if (k == 9) { p.setColor(0xFFFFFFFF); c.drawCircle(mx, ly, dp(5), p); p.setColor(0xFFE85D3A); c.drawCircle(mx, ly, dp(3.4f), p); }
                    else { p.setColor(0xFFFFFFFF); c.drawCircle(mx, ly, dp(k == 5 ? 4.6f : 5f), p); p.setColor(cols[k]); c.drawCircle(mx, ly, dp(3.4f), p); }
                }
                p.setStyle(Paint.Style.FILL); p.setColor(0xFFFFFFFF); c.drawText(names[k], lx + dp(21), ly + dp(3.3f), p);
            }
            p.setStrokeCap(Paint.Cap.ROUND);
        }
        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), cx = w / 2, cy = h / 2, r = Math.min(w, h) / 2 - dp(2);
            // background disc
            p.setStyle(Paint.Style.FILL); p.setColor(0x401E3324); c.drawCircle(cx, cy, r, p);   // transparent background
            if (!loaded) return;
            final float R = full ? FULL_R : ZOOM_R, s = r / R;
            final float hd = pose[2], sH = (float) Math.sin(hd), cH = (float) Math.cos(hd);
            float a, b, cc, d;                 // screen = M * (x, z)
            if (full) { a = -s; b = 0; cc = 0; d = -s; } else { a = -cH * s; b = sH * s; cc = -sH * s; d = -cH * s; }
            float cxW = full ? 0 : pose[0], czW = full ? 0 : pose[1];
            mv[0] = a; mv[1] = b; mv[2] = cx - (a * cxW + b * czW);
            mv[3] = cc; mv[4] = d; mv[5] = cy - (cc * cxW + d * czW);
            mv[6] = 0; mv[7] = 0; mv[8] = 1; m.setValues(mv);
            c.save(); clip.reset(); clip.addCircle(cx, cy, r, Path.Direction.CW); c.clipPath(clip);
            c.concat(m);
            // lake, river, dirt track, roads (dark casing first, light surface on top)
            if (haveLake) { p.setStyle(Paint.Style.FILL); p.setColor(0xFF2F8FD0); c.drawCircle(lakeX, lakeZ, lakeR, p); }
            for (int k = 0; k + 3 < mts.length; k += 4) {                                // mountains: shaded footprint + contour rings
                for (int q = 0; q < 3; q++) { float f = 1f - q * 0.30f; p.setStyle(Paint.Style.FILL); p.setColor(q == 0 ? 0x405B4A2A : 0x305B4A2A); c.save(); c.translate(mts[k], mts[k + 1]); c.scale(1f, mts[k + 3] / mts[k + 2]); c.drawCircle(0, 0, mts[k + 2] * f, p); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1f) / s); p.setColor(0x88C9A15A); c.drawCircle(0, 0, mts[k + 2] * f, p); c.restore(); } }
            line(c, bound, 6f, 2.2f, s, 0xFFFF4D4D);                      // world boundary: the car cannot go beyond this red line
            line(c, river, 20f, 3f, s, 0xFF3D9BE0);
            line(c, track, 8f, 1.6f, s, 0xFFB08A5A);
            line(c, roads, 22f, 4.2f, s, 0xFF0E1216); line(c, conn, 18f, 3.6f, s, 0xFF0E1216);
            line(c, roads, 14f, 2.6f, s, 0xFFC9CED6); line(c, conn, 12f, 2.2f, s, 0xFFC9CED6);
            // ---- cable car (pink rope, pylons, stations) ----
            p.setStrokeCap(Paint.Cap.BUTT);
            p.setPathEffect(new android.graphics.DashPathEffect(new float[]{dp(7f) / s, dp(4f) / s}, 0)); line(c, cable, 3f, 1.9f, s, 0xFFFF4D9A); p.setPathEffect(null);
            p.setStrokeCap(Paint.Cap.ROUND);
            dots(c, pylons, 3.0f, s, 0xFFFFFFFF); dots(c, pylons, 1.8f, s, 0xFFFF4D9A);
            for (float[] a2 : cabSt) for (int k = 0; k + 1 < a2.length; k += 2) {            // cable car stations: pink squares with a white rim
                float q = dp(4.2f) / s; p.setStyle(Paint.Style.FILL); p.setColor(0xFFFF4D9A); c.drawRect(a2[k] - q, a2[k + 1] - q, a2[k] + q, a2[k + 1] + q, p);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.4f) / s); p.setColor(0xFFFFFFFF); c.drawRect(a2[k] - q, a2[k + 1] - q, a2[k] + q, a2[k + 1] + q, p); }
            dots(c, huts, 2.6f, s, 0xFFFFB866);
            dots(c, churches, 4.2f, s, 0xFFFFFFFF);
            for (int k = 0; k + 2 < pois.length; k += 3) {                               // points of interest: icons (names are drawn below, in screen space)
                int t = (int) pois[k + 2]; float x = pois[k], z = pois[k + 1];
                p.setStyle(Paint.Style.FILL);
                if (t == 10) { p.setColor(0xFF2F8FD0); c.drawCircle(x, z, dp(3f) / s, p); }                                        // pond
                else if (t == 11) { p.setColor(0xFF0E1216); float q = dp(3.6f) / s; c.drawRect(x - q, z - q, x + q, z + q, p); p.setColor(0xFFE6E9EE); q = dp(2.2f) / s; c.drawRect(x - q, z - q, x + q, z + q, p); }   // bridge
                else if (t == 12) { p.setColor(0xFFC98B4A); c.drawCircle(x, z, dp(2.6f) / s, p); }                                // log cabin
                else if (t == 3 || t == 4) { p.setColor(0xFFFFFFFF); c.drawCircle(x, z, dp(5.2f) / s, p); p.setColor(t == 3 ? 0xFFE85D3A : 0xFFF2B01E); c.drawCircle(x, z, dp(3.6f) / s, p); }   // restaurant / petrol
                else if (t == 5) { p.setColor(0xFFFFFFFF); c.drawCircle(x, z, dp(5.2f) / s, p); p.setColor(0xFF2563C9); c.drawCircle(x, z, dp(3.6f) / s, p); }                   // car park
                else if (t == 7 || t == 8 || t == 6) { p.setColor(0xFF1B1409); float q = dp(6.2f) / s; c.drawCircle(x, z, q, p); p.setColor(0xFFC9A15A); arrow.reset(); arrow.moveTo(x, z - q * 0.75f); arrow.lineTo(x + q * 0.8f, z + q * 0.55f); arrow.lineTo(x - q * 0.8f, z + q * 0.55f); arrow.close(); c.drawPath(arrow, p); }   // mountain triangle
                else if (t == 13) { p.setColor(0xFF1B1409); c.drawCircle(x, z, dp(4.2f) / s, p); p.setColor(0xFFFFFFFF); c.drawCircle(x, z, dp(2f) / s, p); }
                else if (t == 1) { p.setColor(0xFFFFFFFF); c.drawCircle(x, z, dp(6f) / s, p); p.setColor(0xFFFFB866); c.drawCircle(x, z, dp(4.4f) / s, p); }
            }
            c.restore();
            // frame + north mark
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); p.setColor(0xCCFFFFFF); c.drawCircle(cx, cy, r, p);
            float nx = full ? 0 : sH, ny = full ? -1 : -cH;               // screen direction of "north" (+Z)
            float nr = r - dp(9);
            p.setStyle(Paint.Style.FILL); p.setColor(0xFFFF4D5A); c.drawCircle(cx + nx * nr, cy + ny * nr, dp(7), p);
            p.setColor(0xFFFFFFFF); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(dp(9));
            p.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
            c.drawText("N", cx + nx * nr, cy + ny * nr - (p.ascent() + p.descent()) / 2f, p);
            // station names (screen space, with a dark halo so they read on any background)
            p.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD)); p.setTextSize(dp(full ? 9.5f : 8.5f)); p.setTextAlign(Paint.Align.LEFT);
            for (int k = 0; k < cabSt.size() && k < 1; k++) { float[] a2 = cabSt.get(k); if (a2.length >= 4) {
                label(c, "Cable car South", mv[0] * a2[0] + mv[1] * a2[1] + mv[2], mv[3] * a2[0] + mv[4] * a2[1] + mv[5], cx, cy, r, 1, 0xFFFF9CC4);
                label(c, "Cable car North", mv[0] * a2[2] + mv[1] * a2[3] + mv[2], mv[3] * a2[2] + mv[4] * a2[3] + mv[5], cx, cy, r, 1, 0xFFFF9CC4); } }
            {   // names of everything (screen space); small things only on the large map
                final String[] PN = {"", "Village", "Church", "Restaurant", "Petrol station", "Car park", "Alpine peak", "North mountain", "South mountain", "Lake", "Pond", "Bridge", "Log cabin", "Tunnel", "", "River", "Hill road"};
                final int[] PC = {0, 0xFFFFD9A8, 0xFFFFFFFF, 0xFFFF9F8A, 0xFFFFD36B, 0xFF9CC0FF, 0xFFE6C98A, 0xFFE6C98A, 0xFFE6C98A, 0xFF8FD0FF, 0xFF8FD0FF, 0xFFE6E9EE, 0xFFE0B080, 0xFFFFFFFF, 0, 0xFF8FD0FF, 0xFFD9B98A};
                p.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD)); p.setTextSize(dp(full ? 9.5f : 8.5f)); p.setTextAlign(Paint.Align.LEFT);
                for (int k = 0; k + 2 < pois.length; k += 3) {
                    int t = (int) pois[k + 2]; if (t < 1 || t >= PN.length || PN[t].isEmpty()) continue;
                    if ((t == 10 || t == 11 || t == 12 || t == 13) && !big) continue;
                    label(c, PN[t], mv[0] * pois[k] + mv[1] * pois[k + 1] + mv[2], mv[3] * pois[k] + mv[4] * pois[k + 1] + mv[5], cx, cy, r, (t == 3 || t == 5 || t == 9 || t == 16) ? 1 : -1, PC[t]); }
            }
            if (big) legend(c, cx, cy, r);
            // the car: arrow (always up when zoomed; rotated by -heading on the whole map)
            float carX = cx, carY = cy;
            if (full) { carX = mv[0] * pose[0] + mv[1] * pose[1] + mv[2]; carY = mv[3] * pose[0] + mv[4] * pose[1] + mv[5]; }
            c.save(); c.translate(carX, carY); if (full) c.rotate((float) -Math.toDegrees(hd));
            float q = dp(big ? 10 : 7);
            arrow.reset(); arrow.moveTo(0, -q * 1.4f); arrow.lineTo(q, q); arrow.lineTo(0, q * 0.4f); arrow.lineTo(-q, q); arrow.close();
            p.setStyle(Paint.Style.FILL); p.setColor(0xFF29B6F6); c.drawPath(arrow, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.5f)); p.setColor(0xFFFFFFFF); c.drawPath(arrow, p);
            c.restore();
        }
    }

    // the HTML sky pictures (embedded JPEG / PNG): decode here, hand the RGBA pixels to the C++ sky
    void loadSky() {
        String[] names = {"sky_0.jpg", "sky_1.jpg", "sky_2.jpg", "sky_3.jpg", "sky_4.jpg", "mtn_col.jpg", "mtn_data.png"};
        for (int i = 0; i < names.length; i++) {
            try {
                BitmapFactory.Options o = new BitmapFactory.Options(); o.inPreferredConfig = Bitmap.Config.ARGB_8888; o.inScaled = false;
                Bitmap b = BitmapFactory.decodeStream(getAssets().open(names[i]), null, o);
                if (b == null) continue;
                ByteBuffer bb = ByteBuffer.allocateDirect(b.getWidth() * b.getHeight() * 4);
                b.copyPixelsToBuffer(bb); bb.rewind();
                nSkyImg(i, b.getWidth(), b.getHeight(), bb); b.recycle();
            } catch (Exception e) { /* missing picture: that part of the sky stays plain */ }
        }
    }

    // ---------------- loading screen ----------------
    static final String[] TIPS = {
        "Tip: using the handbrake spins the rear wheels loose and the car slides around",
        "Tip: tap the camera button to switch to the cockpit view",
        "Tip: ease off the gas mid-corner to keep a long, smooth drift",
        "Tip: Settings > Graphics lowers the quality if the game feels slow",
        "Tip: the clock button changes the time of day, from sunrise to night"};
    View loadingView, garageView, hudRoot; Handler loadH = new Handler();
    void buildLoading(final FrameLayout outer) {
        final float dn = getResources().getDisplayMetrics().density;
        final FrameLayout ov = new FrameLayout(this); ov.setBackgroundColor(Color.BLACK); ov.setClickable(true); loadingView = ov;
        android.widget.ImageView bg = new android.widget.ImageView(this);
        bg.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP); bg.setImageResource(R.drawable.loading_bg);
        ov.addView(bg, new FrameLayout.LayoutParams(-1, -1));
        View scrim = new View(this);
        scrim.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0x66000000, 0x33000000, 0xE6000000}));
        ov.addView(scrim, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL); col.setGravity(Gravity.CENTER_HORIZONTAL);
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM); clp.setMargins((int) (48 * dn), 0, (int) (48 * dn), (int) (26 * dn));
        final TextView title = new TextView(this); title.setText("HORIZON DRIFT"); title.setTextColor(Color.WHITE); title.setTextSize(30); title.setLetterSpacing(0.18f);
        title.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD)); title.setShadowLayer(8, 0, 2, 0xFF000000); col.addView(title);
        final TextView tip = new TextView(this); tip.setTextColor(0xFFE5E7EB); tip.setTextSize(13); tip.setGravity(Gravity.CENTER); tip.setShadowLayer(4, 0, 1, 0xFF000000);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(-2, -2); tlp.topMargin = (int) (6 * dn); col.addView(tip, tlp);
        final float[] shown = {0f};
        final View bar = new View(this) {
            final Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG);
            @Override protected void onDraw(Canvas c) {
                float w = getWidth(), h = getHeight(), r = h / 2;
                bp.setColor(0x44FFFFFF); c.drawRoundRect(new RectF(0, 0, w, h), r, r, bp);
                float fw = Math.max(h, w * shown[0] / 100f);
                bp.setShader(new LinearGradient(0, 0, w, 0, 0xFFFFB03A, 0xFFFF3D5A, Shader.TileMode.CLAMP));
                c.drawRoundRect(new RectF(0, 0, fw, h), r, r, bp); bp.setShader(null);
            }
        };
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, (int) (7 * dn)); blp.topMargin = (int) (14 * dn); col.addView(bar, blp);
        final TextView pct = new TextView(this); pct.setTextColor(0xFFFFFFFF); pct.setTextSize(12); pct.setTypeface(Typeface.DEFAULT_BOLD); pct.setShadowLayer(4, 0, 1, 0xFF000000);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(-2, -2); plp.topMargin = (int) (6 * dn); col.addView(pct, plp);
        ov.addView(col, clp);
        outer.addView(ov, new FrameLayout.LayoutParams(-1, -1));
        final long t0 = System.currentTimeMillis();
        final int prevStop = prevLoad;   // where the LAST start stopped (100 = it finished): shown on screen, no computer needed
        loadH.post(new Runnable() {
            int lastTip = -1, savedPct = -2;
            public void run() {
                int target = nLoadProgress(); long el = System.currentTimeMillis() - t0;
                if (target != savedPct) { savedPct = target; try { SharedPreferences.Editor ed = sp.edit().putInt("last_load", target); if (target >= 87 && target < 100) ed.putInt("stuck", target); else if (target >= 100) ed.putInt("stuck", 0); ed.commit(); } catch (Throwable t) { } }
                if (target < 0) {      // the world could not be built (usually: not enough memory)
                    pct.setText("Could not load the game \u2013 tap to restart"); ov.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { restartApp(); } }); return;
                }
                shown[0] += (target - shown[0]) * 0.12f + 0.15f; if (shown[0] > target) shown[0] = target;     // the bar always creeps forward, never freezes
                bar.invalidate(); pct.setText(target >= 100 ? "100%" : ((int) shown[0] + "%  \u00B7  Loading the valley..." + (prevStop >= 0 && prevStop < 100 ? "\nLast time it closed at " + prevStop + "%" : "") + (skipMask != 0 ? "\nSafe mode: " + ((skipMask & 1) != 0 ? "houses off " : "") + ((skipMask & 2) != 0 ? "waterfall off" : "") : "")));
                int ti = (int) (el / 3500) % TIPS.length; if (ti != lastTip) { lastTip = ti; tip.setText(TIPS[ti]); }
                if (target >= 100 && shown[0] >= 100f && el > 1500) {   // ready: fade out, then remove the overlay
                    ov.animate().alpha(0f).setDuration(450).withEndAction(new Runnable() { public void run() { outer.removeView(ov); loadingView = null; showGarage(outer); } }).start(); return;
                }
                loadH.postDelayed(this, 50);
            }
        });
    }
    // ---- simple garage / home lobby: shown once the world is ready (the car stands in the 3D view behind it), big PLAY button at the bottom ----
    void showGarage(final FrameLayout outer) {
        final float dn = getResources().getDisplayMetrics().density;
        if (hudRoot != null) hudRoot.setVisibility(View.GONE);      // no driving controls in the lobby
        nPause(1);                                                    // the world stands still while you are in the garage
        final FrameLayout g = new FrameLayout(this); g.setClickable(true); garageView = g;
        g.setPadding(cutPad[0], cutPad[1], cutPad[2], cutPad[3]);
        View scrim = new View(this);
        scrim.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xAA000000, 0x00000000, 0x00000000, 0xDD000000}));
        g.addView(scrim, new FrameLayout.LayoutParams(-1, -1));
        // top-left: title
        LinearLayout top = new LinearLayout(this); top.setOrientation(LinearLayout.VERTICAL);
        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START); tlp.setMargins((int) (28 * dn), (int) (20 * dn), 0, 0);
        TextView t1 = new TextView(this); t1.setText("HORIZON DRIFT"); t1.setTextColor(Color.WHITE); t1.setTextSize(24); t1.setLetterSpacing(0.16f);
        t1.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD)); t1.setShadowLayer(8, 0, 2, 0xFF000000); top.addView(t1);
        TextView t2 = new TextView(this); t2.setText("GARAGE"); t2.setTextColor(0xFFFFB03A); t2.setTextSize(13); t2.setLetterSpacing(0.3f);
        t2.setTypeface(Typeface.DEFAULT_BOLD); t2.setShadowLayer(4, 0, 1, 0xFF000000); top.addView(t2);
        g.addView(top, tlp);
        // left: the car and two facts
        LinearLayout info = new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL);
        FrameLayout.LayoutParams ilp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.START); ilp.setMargins((int) (28 * dn), 0, 0, (int) (96 * dn));
        TextView cn = new TextView(this); cn.setText("SPORTS COUPE"); cn.setTextColor(Color.WHITE); cn.setTextSize(20); cn.setLetterSpacing(0.1f);
        cn.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD)); cn.setShadowLayer(6, 0, 2, 0xFF000000); info.addView(cn);
        TextView cs = new TextView(this); cs.setText("1650 kg   \u00B7   Wheelbase 2.8 m   \u00B7   Colour: Black"); cs.setTextColor(0xFFE5E7EB); cs.setTextSize(12); cs.setShadowLayer(4, 0, 1, 0xFF000000);
        LinearLayout.LayoutParams cslp = new LinearLayout.LayoutParams(-2, -2); cslp.topMargin = (int) (4 * dn); info.addView(cs, cslp);
        g.addView(info, ilp);
        // bottom centre: PLAY
        final TextView play = new TextView(this); play.setText("PLAY"); play.setTextColor(Color.WHITE); play.setTextSize(22); play.setLetterSpacing(0.25f);
        play.setTypeface(Typeface.DEFAULT_BOLD); play.setGravity(Gravity.CENTER); play.setShadowLayer(4, 0, 1, 0x66000000);
        GradientDrawable pg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0xFFFFB03A, 0xFFFF3D5A}); pg.setCornerRadius(30 * dn);
        play.setBackground(pg);
        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams((int) (240 * dn), (int) (56 * dn), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL); plp.bottomMargin = (int) (24 * dn);
        g.addView(play, plp);
        play.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
            play.setClickable(false);
            g.animate().alpha(0f).setDuration(300).withEndAction(new Runnable() { public void run() {
                outer.removeView(g); garageView = null;
                if (hudRoot != null) hudRoot.setVisibility(View.VISIBLE);
                nPause(0);
            } }).start();
        } });
        g.setAlpha(0f); outer.addView(g, new FrameLayout.LayoutParams(-1, -1)); g.animate().alpha(1f).setDuration(350).start();
    }
    // after a lost GL context: start the game again in a fresh process
    void restartApp() {
        runOnUiThread(new Runnable() { public void run() {
            try { android.content.Intent i = getPackageManager().getLaunchIntentForPackage(getPackageName()); i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK | android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK); startActivity(i); } catch (Exception e) { }
            finish(); Runtime.getRuntime().exit(0);
        } });
    }

    // keyboard (HTML: W / S / A / D, arrows, Space = handbrake, R = reset)
    int keyBit(int k) {
        switch (k) {
            case KeyEvent.KEYCODE_W: case KeyEvent.KEYCODE_DPAD_UP: return 4;
            case KeyEvent.KEYCODE_S: case KeyEvent.KEYCODE_DPAD_DOWN: return 8;
            case KeyEvent.KEYCODE_A: case KeyEvent.KEYCODE_DPAD_LEFT: return 32;
            case KeyEvent.KEYCODE_D: case KeyEvent.KEYCODE_DPAD_RIGHT: return 64;
            case KeyEvent.KEYCODE_SPACE: return 16;
        }
        return 0;
    }
    @Override public boolean onKeyDown(int k, KeyEvent e) {
        if (k == KeyEvent.KEYCODE_R) { if (e.getRepeatCount() == 0) nReset(); return true; }
        if (k == KeyEvent.KEYCODE_E || k == KeyEvent.KEYCODE_PAGE_UP) { if (e.getRepeatCount() == 0) nShift(1); return true; }       // manual gearbox: E / Page up = shift up
        if (k == KeyEvent.KEYCODE_Q || k == KeyEvent.KEYCODE_PAGE_DOWN) { if (e.getRepeatCount() == 0) nShift(-1); return true; }   // Q / Page down = shift down
        int b = keyBit(k); if (b == 0) return super.onKeyDown(k, e);
        kmask |= b; nInput(mask | kmask); return true;
    }
    @Override public boolean onKeyUp(int k, KeyEvent e) {
        int b = keyBit(k); if (b == 0) return super.onKeyUp(k, e);
        kmask &= ~b; nInput(mask | kmask); return true;
    }

    @Override protected void onPause() { engine.stop(); super.onPause(); gl.onPause(); }
    @Override protected void onStop() { engine.stop(); super.onStop(); }
    @Override protected void onDestroy() { engine.stop(); loadH.removeCallbacksAndMessages(null); super.onDestroy(); if (isFinishing()) android.os.Process.killProcess(android.os.Process.myPid()); }
    @Override protected void onResume() { super.onResume(); gl.onResume(); engine.am = getAssets(); engine.start(); }
    @Override public void onBackPressed() { if (settingsLayer != null) closeSettings(); else super.onBackPressed(); }
}
