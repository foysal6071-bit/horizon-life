// URP skybox: port of the HTML sky fragment shader (SkyGL::FS in sky.h): gradient + sun/twilight glow + 5-photo cube atlas + clouds + night (moon, stars, milky way).
Shader "SunnyDrift/Sky" {
    Properties { _CubeTex("Sky atlas", 2D) = "gray" {} }
    SubShader {
        Tags { "RenderPipeline"="UniversalPipeline" "Queue"="Background" "RenderType"="Background" "PreviewType"="Skybox" }
        ZWrite Off Cull Off
        Pass {
            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
            TEXTURE2D(_CubeTex); SAMPLER(sampler_CubeTex);
            CBUFFER_START(UnityPerMaterial)
                float4 _CubeTex_ST;
                float _T, _Night, _Tw, _Rain, _CubeAmt, _Inset, _Q, _Lin;
                float4 _Sun, _Moon, _Hor, _Mid, _Zen, _Cl, _Cs, _Tint;
            CBUFFER_END
            struct A { float4 p : POSITION; };
            struct V { float4 pos : SV_POSITION; float3 d : TEXCOORD0; };
            V vert(A i) { V o; o.pos = TransformObjectToHClip(i.p.xyz); o.d = i.p.xyz; return o; }

            float hash(float2 p){ p=frac(p*float2(123.34,456.21)); p+=dot(p,p+45.32); return frac(p.x*p.y); }
            float noise(float2 p){ float2 i=floor(p), f=frac(p); f=f*f*(3.-2.*f);
                return lerp(lerp(hash(i),hash(i+float2(1.,0.)),f.x), lerp(hash(i+float2(0.,1.)),hash(i+float2(1.,1.)),f.x), f.y); }
            float fbm(float2 p){ float a=.5, s=0.; [unroll] for(int i=0;i<4;i++){ s+=a*noise(p); p=p*2.03+float2(17.1,9.7); a*=.5; } return s; }
            float h31(float3 p){ p=frac(p*.1031); p+=dot(p,p.yzx+33.33); return frac((p.x+p.y)*p.z); }
            float3 skyTex(float3 d){
                float3 a = abs(d); float2 uv; float f;
                if (a.y > a.x && a.y > a.z){ uv = float2(d.x, d.z)/a.y; f = 4.; }
                else if (a.z >= a.x){ if (d.z < 0.){ uv = float2(d.x, d.y)/a.z; f = 0.; } else { uv = float2(-d.x, d.y)/a.z; f = 2.; } }
                else { if (d.x > 0.){ uv = float2(d.z, d.y)/a.x; f = 1.; } else { uv = float2(-d.z, d.y)/a.x; f = 3.; } }
                uv = clamp(uv*.5+.5, _Inset.xx, 1.-_Inset.xx);
                float c = fmod(f,3.), r = floor(f/3.);
                return SAMPLE_TEXTURE2D_LOD(_CubeTex, sampler_CubeTex, float2((c+uv.x)/3., (1.-r+uv.y)/2.), 0).rgb;
            }
            float3 star(float3 d,float S,float dens,float r){
                float3 g=d*S, id=floor(g), f=frac(g);
                float e=h31(id+3.3); if(e>dens) return 0;
                float3 rp=.2+.6*float3(h31(id),h31(id+19.19),h31(id+47.7));
                float dd=length(f-rp), b=exp(-dd*dd/(r*r));
                float tw=.78+.22*sin(_T*(1.5+e*20./dens)+e*90.);
                return b*tw*(.3+.7*h31(id+8.1))*lerp(float3(.7,.82,1.),float3(1.,.86,.68),h31(id+5.5));
            }
            half4 frag(V i) : SV_Target {
                float3 d = normalize(float3(-i.d.x, i.d.y, i.d.z));      // game axes (Unity x is mirrored)
                float h = d.y; float3 sun=_Sun.xyz, moon=_Moon.xyz;
                float3 col = lerp(_Hor.xyz, _Mid.xyz, smoothstep(0.,.28,h));
                col = lerp(col, _Zen.xyz, smoothstep(.25,.95,h));
                if (h < 0.) col = lerp(_Hor.xyz, _Hor.xyz*.7, pow(-h,.5));
                if (_CubeAmt > .001){
                    float cr = _T*.0025, cs = sin(cr), cc = cos(cr);
                    float3 dr = normalize(float3(cc*d.x - cs*d.z, max(d.y,0.), cs*d.x + cc*d.z));
                    float3 sc = skyTex(dr);
                    float lm = dot(sc, float3(.299,.587,.114));
                    sc = pow(max(sc,0.), .72); sc = lerp(lm.xxx, sc, 1.0-.5*_Rain) * _Tint.xyz;
                    sc = lerp(sc, _Hor.xyz, (1.-smoothstep(0.,.14,h))*.35);
                    col = lerp(col, sc, _CubeAmt*lerp(.55,1.,_Night)*smoothstep(-.03,.0,h));
                }
                float sd = max(dot(d,sun),0.); float sv = smoothstep(-.12,.04,sun.y);
                col += (float3(1.,.80,.50)*pow(sd,5.)*.22 + float3(1.,.90,.70)*pow(sd,40.)*.45)*sv;
                col += float3(1.,.4,.12)*pow(sd,3.)*_Tw*.55*(1.-smoothstep(0.,.5,h));
                col += lerp(float3(1.,.97,.88),float3(1.,.55,.28),_Tw)*smoothstep(.9993,.9997,sd)*2.*sv;
                if (_Night > .01 && h > -.02){
                    float vis = _Night*smoothstep(-.02,.18,h);
                    float md = dot(d,moon);
                    float3 mwN = normalize(float3(.35,.75,-.55)), mA = normalize(cross(mwN,float3(0.,1.,0.))), mB = cross(mwN,mA);
                    float dn = dot(d,mwN), band = exp(-dn*dn/.03), mw = 0.;
                    if (band > .02 && _Q > .5){ float2 mp = float2(dot(d,mA),dot(d,mB))*4.;
                        mw = band*(.4+.9*fbm(mp))*(.6+.6*fbm(mp*3.1+7.))*(1.-.5*smoothstep(.5,.8,fbm(mp*2.+3.))); }
                    float3 st = star(d,26.,.09,.2)*1.7 + star(d,55.,.35,.16) + (_Q > .5 ? star(d,115.,.4+.35*band,.2)*.7 : 0);
                    float wash = 1.-clamp(pow(max(md,0.),6.)*1.4,0.,1.);
                    col += (st + float3(.5,.58,.85)*mw*.2)*wash*vis;
                    col += float3(.5,.62,.95)*(pow(max(md,0.),70.)*.4 + pow(max(md,0.),7.)*.08)*_Night;
                    float MR = .034;
                    if (md > cos(MR)){
                        float3 r = normalize(cross(float3(0.,1.,0.),moon)); float3 u = cross(moon,r);
                        float2 q = float2(dot(d,r),dot(d,u))/sin(MR); float q2 = dot(q,q);
                        if (q2 < 1.){
                            float3 n = float3(q,sqrt(1.-q2)); float3 L = normalize(float3(.75,.25,.6));
                            float lit = smoothstep(-.05,.12,dot(n,L));
                            float3 alb = float3(.88,.86,.80)*(.62+.5*fbm(q*2.6+5.))*(.85+.3*fbm(q*9.+1.));
                            alb *= lerp(1.,.55,smoothstep(.55,.7,fbm(q*2.+11.)));
                            col = lerp(col, alb*(lit+.05)*1.5, smoothstep(1.,.95,sqrt(q2)));
                        }
                    }
                }
                if (h > 0.01){
                    float2 uv = d.xz/(h+.12)*1.4 + float2(_T*.012, _T*.004);
                    float n = fbm(uv*.9);
                    float c = smoothstep(.60-.35*_Rain,.86-.3*_Rain,n) * smoothstep(.0,.16,h);
                    if (c > .004){
                        float lit = fbm(uv*.9 + sun.xz*.35);
                        float3 cc = lerp(_Cs.xyz, _Cl.xyz, clamp(1.-(lit-n)*2.4,0.,1.));
                        cc += float3(1.,.85,.6)*pow(sd,8.)*.25*(1.-_Night)*sv;
                        cc += float3(.25,.3,.45)*pow(max(dot(d,moon),0.),12.)*_Night*.5;
                        col = lerp(col, cc, c*.92*(1.-.88*_CubeAmt));
                    }
                }
                if (_Lin > .5) col = pow(max(col, 0.), 2.2);
                return half4(col, 1);
            }
            ENDHLSL
        }
    }
}
