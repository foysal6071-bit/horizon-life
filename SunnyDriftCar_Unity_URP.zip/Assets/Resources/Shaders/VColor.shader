// URP vertex-colour lit shader (ground, verges, hills): vertex colour x main light (+cascade shadows) + ambient SH + fog.
// v3: full URP pass set (ForwardLit + ShadowCaster + DepthOnly), SRP-Batcher compatible, no _MAIN_LIGHT_SHADOWS_SCREEN (shadow coord is computed per pixel).
Shader "SunnyDrift/VColor" {
    Properties { [MainColor] _Color("Tint", Color) = (1,1,1,1) }
    SubShader {
        Tags { "RenderPipeline"="UniversalPipeline" "RenderType"="Opaque" "Queue"="Geometry" }

        Pass {
            Name "ForwardLit" Tags { "LightMode"="UniversalForward" }
            Cull Off
            HLSLPROGRAM
            #pragma target 3.5
            #pragma vertex vert
            #pragma fragment frag
            #pragma multi_compile _ _MAIN_LIGHT_SHADOWS _MAIN_LIGHT_SHADOWS_CASCADE
            #pragma multi_compile_fragment _ _SHADOWS_SOFT
            #pragma multi_compile_fog
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Lighting.hlsl"
            CBUFFER_START(UnityPerMaterial)
                half4 _Color;
            CBUFFER_END
            struct A { float4 p : POSITION; float3 n : NORMAL; half4 c : COLOR; };
            struct V { float4 pos : SV_POSITION; float3 nw : TEXCOORD0; float3 pw : TEXCOORD1; half4 c : COLOR; half fog : TEXCOORD2; };
            V vert(A i) {
                V o; VertexPositionInputs vp = GetVertexPositionInputs(i.p.xyz);
                o.pos = vp.positionCS; o.pw = vp.positionWS; o.nw = TransformObjectToWorldNormal(i.n); o.c = i.c;
                o.fog = ComputeFogFactor(vp.positionCS.z); return o;
            }
            half4 frag(V i) : SV_Target {
                float3 n = normalize(i.nw); if (n.y < 0) n = -n;                   // two-sided
                Light l = GetMainLight(TransformWorldToShadowCoord(i.pw));
                half nl = saturate(dot(n, l.direction));
                half3 col = i.c.rgb * _Color.rgb * (l.color * (nl * l.shadowAttenuation) + SampleSH(n));
                col = MixFog(col, i.fog);
                return half4(col, 1);
            }
            ENDHLSL
        }

        Pass {
            Name "ShadowCaster" Tags { "LightMode"="ShadowCaster" }
            ZWrite On ZTest LEqual ColorMask 0 Cull Off
            HLSLPROGRAM
            #pragma target 3.5
            #pragma vertex ShadowVert
            #pragma fragment ShadowFrag
            #pragma multi_compile_vertex _ _CASTING_PUNCTUAL_LIGHT_SHADOW
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Shadows.hlsl"
            CBUFFER_START(UnityPerMaterial)
                half4 _Color;
            CBUFFER_END
            float3 _LightDirection;
            float3 _LightPosition;
            struct SA { float4 p : POSITION; float3 n : NORMAL; };
            struct SV { float4 pos : SV_POSITION; };
            SV ShadowVert(SA i) {
                SV o; float3 pw = TransformObjectToWorld(i.p.xyz); float3 nw = TransformObjectToWorldNormal(i.n);
                #if defined(_CASTING_PUNCTUAL_LIGHT_SHADOW)
                    float3 ld = normalize(_LightPosition - pw);
                #else
                    float3 ld = _LightDirection;
                #endif
                float4 cs = TransformWorldToHClip(ApplyShadowBias(pw, nw, ld));
                #if UNITY_REVERSED_Z
                    cs.z = min(cs.z, UNITY_NEAR_CLIP_VALUE);
                #else
                    cs.z = max(cs.z, UNITY_NEAR_CLIP_VALUE);
                #endif
                o.pos = cs; return o;
            }
            half4 ShadowFrag(SV i) : SV_Target { return 0; }
            ENDHLSL
        }

        Pass {
            Name "DepthOnly" Tags { "LightMode"="DepthOnly" }
            ZWrite On ColorMask R Cull Off
            HLSLPROGRAM
            #pragma target 3.5
            #pragma vertex DepthVert
            #pragma fragment DepthFrag
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
            CBUFFER_START(UnityPerMaterial)
                half4 _Color;
            CBUFFER_END
            struct DA { float4 p : POSITION; };
            struct DV { float4 pos : SV_POSITION; };
            DV DepthVert(DA i) { DV o; o.pos = TransformObjectToHClip(i.p.xyz); return o; }
            half4 DepthFrag(DV i) : SV_Target { return 0; }
            ENDHLSL
        }
    }
}
