// Sunny Drift (Unity port) - bootstrap, controls (touch + keyboard), chase camera, HUD. Runs from an EMPTY scene: no setup needed.
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

public class Game : MonoBehaviour {
    CarState S = new CarState(); CarModel car; Transform carRoot, cam; Camera camC; SkyEnv sky; float nightK, nightTgt; double tPitch, tRoll, carGy;
    double sens = 1.8, spinF, spinR, camYaw, rollS, pitchS;
    float ui; int mask; const int LEFT = 1, RIGHT = 2, GAS = 4, BRAKE = 8, HAND = 16;
    Rect rL, rR, rGas, rBrk, rHand, rReset, rDay; GUIStyle big, small, btn;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void Boot() { new GameObject("Game").AddComponent<Game>(); }

    static Material Flat(Color c, float gloss = 0.05f) { return CarModel.Lit(c, 0f, gloss, c.a < 0.99f); }
    static Texture2D AsphaltTex() {
        const int W = 128, H = 128; var t = new Texture2D(W, H, TextureFormat.RGB24, true); var rnd = new System.Random(7);
        for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) {
            float u = (x + 0.5f) / W, v = (y + 0.5f) / H, g = 0.20f + (float)rnd.NextDouble() * 0.07f; Color c = new Color(g, g, g * 1.03f);
            if (u < 0.05f && u > 0.03f || u > 0.95f && u < 0.97f) c = new Color(0.85f, 0.85f, 0.82f);            // edge lines
            if (u > 0.485f && u < 0.515f && v < 0.5f) c = new Color(0.9f, 0.88f, 0.75f);                        // dashed centre line
            t.SetPixel(x, y, c);
        }
        t.wrapModeU = TextureWrapMode.Clamp; t.wrapModeV = TextureWrapMode.Repeat; t.anisoLevel = 8; t.Apply(true); return t;
    }

    void Start() {
        Application.targetFrameRate = 60; QualitySettings.vSyncCount = 0;
        // light, fog, sky colour
        if (GraphicsSettings.currentRenderPipeline == null) Debug.LogError("No URP asset is active: Project Settings > Graphics > Scriptable Render Pipeline Settings is empty. Use a '3D (URP)' project or run  Sunny Drift > Apply URP Settings.");
        var sun = new GameObject("Sun").AddComponent<Light>(); sun.type = LightType.Directional; sun.intensity = 1.15f; sun.color = new Color(1f, 0.96f, 0.88f); sun.transform.rotation = Quaternion.Euler(48, -35, 0);
        sun.shadows = LightShadows.Soft; sun.shadowStrength = 1f; sun.shadowBias = 0.05f; sun.shadowNormalBias = 0.4f; sun.renderMode = LightRenderMode.ForcePixel; RenderSettings.sun = sun;   // URP main light + cascaded shadow map
        RenderSettings.fog = true; RenderSettings.fogMode = FogMode.Linear; RenderSettings.fogStartDistance = 300; RenderSettings.fogEndDistance = 2200;
        var camGo = new GameObject("Camera"); camC = camGo.AddComponent<Camera>(); camGo.tag = "MainCamera"; camGo.AddComponent<AudioListener>(); cam = camGo.transform;
        camC.clearFlags = CameraClearFlags.Skybox; camC.farClipPlane = 4000; camC.fieldOfView = 62; camC.allowHDR = true; camC.allowMSAA = true;
        var camData = camGo.AddComponent<UniversalAdditionalCameraData>(); camData.renderShadows = true; camData.renderPostProcessing = false; camData.antialiasing = AntialiasingMode.None;   // MSAA comes from the URP asset
        sky = new SkyEnv(); sky.Init(sun); sky.Apply(0, 0, camC);
        var vcol = new Material(Shader.Find("SunnyDrift/VColor"));
        // outer ground (flat, under the hills) + roads + hills
        var ground = GameObject.CreatePrimitive(PrimitiveType.Plane); Destroy(ground.GetComponent<Collider>()); ground.transform.localScale = new Vector3(1000, 1, 1000); ground.transform.position = new Vector3(0, -0.06f, 0);
        var gm = new Material(vcol); { var gc = new Color(0.441f, 0.539f, 0.269f); gm.color = QualitySettings.activeColorSpace == ColorSpace.Linear ? gc.linear : gc; } ground.GetComponent<Renderer>().sharedMaterial = gm;
        var roadMat = Flat(Color.white, 0.2f); roadMat.mainTexture = AsphaltTex();
        var root = new GameObject("World").transform;
        RoadNet.Init(root, roadMat, Flat(new Color(0.72f, 0.65f, 0.48f)));
        Terrain2.Init(root, vcol);
        // car
        carRoot = new GameObject("Car").transform; car = carRoot.gameObject.AddComponent<CarModel>(); car.Load();
        var shadow = GameObject.CreatePrimitive(PrimitiveType.Quad); Destroy(shadow.GetComponent<Collider>()); shadow.transform.SetParent(carRoot, false);
        shadow.transform.localRotation = Quaternion.Euler(90, 0, 0); shadow.transform.localPosition = new Vector3(0, 0.03f, 0); shadow.transform.localScale = new Vector3(2.7f, 5.6f, 1);
        var sm = Flat(new Color(0, 0, 0, 0.22f));
        var sr = shadow.GetComponent<Renderer>(); sr.sharedMaterial = sm; sr.shadowCastingMode = ShadowCastingMode.Off; sr.receiveShadows = false;   // contact blob only; the real car shadow comes from the URP shadow map
        double x, z, h; RoadNet.StartPose(out x, out z, out h); S.x = x; S.z = z; S.heading = h; camYaw = h; Place(true);
    }

    // ---------------- input ----------------
    void Layout() {
        ui = Screen.height / 720f; float m = 30 * ui, s = 150 * ui, W = Screen.width, H = Screen.height;
        rL = new Rect(m, H - m - s, s, s); rR = new Rect(m + s + 20 * ui, H - m - s, s, s);
        rGas = new Rect(W - m - 190 * ui, H - m - 260 * ui, 190 * ui, 260 * ui); rBrk = new Rect(W - m - 190 * ui - 20 * ui - 170 * ui, H - m - 190 * ui, 170 * ui, 190 * ui);
        rDay = new Rect(m, m, 150 * ui, 70 * ui); rHand = new Rect(rBrk.x, rBrk.y - 20 * ui - 100 * ui, 170 * ui, 100 * ui); rReset = new Rect(W - m - 110 * ui, m, 110 * ui, 70 * ui);
    }
    bool Hit(Rect r, Vector2 p) { return r.Contains(new Vector2(p.x, Screen.height - p.y)); }
    bool resetTap;
    void ReadInput() {
        Layout(); mask = 0; var pts = new System.Collections.Generic.List<Vector2>();
        foreach (var t in Input.touches) if (t.phase != TouchPhase.Ended && t.phase != TouchPhase.Canceled) { pts.Add(t.position); if (t.phase == TouchPhase.Began && Hit(rReset, t.position)) resetTap = true; }
        if (Input.touchCount == 0 && Input.GetMouseButton(0)) pts.Add(Input.mousePosition);
        if (Input.touchCount == 0 && Input.GetMouseButtonDown(0) && Hit(rReset, Input.mousePosition)) resetTap = true;
        foreach (var t in Input.touches) if (t.phase == TouchPhase.Began && Hit(rDay, t.position)) nightTgt = 1 - nightTgt;
        if (Input.touchCount == 0 && Input.GetMouseButtonDown(0) && Hit(rDay, Input.mousePosition)) nightTgt = 1 - nightTgt;
        if (Input.GetKeyDown(KeyCode.N)) nightTgt = 1 - nightTgt;
        foreach (var p in pts) { if (Hit(rL, p)) mask |= LEFT; if (Hit(rR, p)) mask |= RIGHT; if (Hit(rGas, p)) mask |= GAS; if (Hit(rBrk, p)) mask |= BRAKE; if (Hit(rHand, p)) mask |= HAND; }
        if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A)) mask |= LEFT;
        if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D)) mask |= RIGHT;
        if (Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.W)) mask |= GAS;
        if (Input.GetKey(KeyCode.DownArrow) || Input.GetKey(KeyCode.S)) mask |= BRAKE;
        if (Input.GetKey(KeyCode.Space)) mask |= HAND;
        if (Input.GetKeyDown(KeyCode.R)) resetTap = true;
    }

    // ---------------- loop ----------------
    void Update() {
        ReadInput();
        if (resetTap) { resetTap = false; RoadNet.Reset(S); camYaw = S.heading; }
        var inp = new CarInput { left = (mask & LEFT) != 0, right = (mask & RIGHT) != 0, gas = (mask & GAS) != 0, brake = (mask & BRAKE) != 0, hand = (mask & HAND) != 0, sens = sens };
        double dt = System.Math.Min(Time.deltaTime, 0.05);
        Surface sf = RoadNet.SurfaceAt((float)S.x, (float)S.z);
        {   // follow the hills (carGroundH): slope along / across the car, ride height
            double sH = System.Math.Sin(S.heading), cH = System.Math.Cos(S.heading), A = 1.4, B = 0.8;
            System.Func<double, double, double> gh = (f, l) => Terrain2.GroundH(S.x + sH * f + cH * l, S.z + cH * f - sH * l);
            double hF = gh(A, 0), hR = gh(-A, 0), hL = gh(0, B), hRt = gh(0, -B), g = (hF - hR) / (2 * A), sl = (hL - hRt) / (2 * B);
            double sn = g / System.Math.Sqrt(1 + g * g); S.slope += (sn - S.slope) * (1 - System.Math.Exp(-10 * dt));
            tPitch += (System.Math.Atan(g) - tPitch) * (1 - System.Math.Exp(-12 * dt)); tRoll += (System.Math.Atan(sl) - tRoll) * (1 - System.Math.Exp(-12 * dt));
            carGy = (hF + hR + hL + hRt) / 4;
        }
        Veh.Step(S, inp, sf, dt);
        nightK = Mathf.MoveTowards(nightK, nightTgt, Time.deltaTime / 4f); sky.Apply(nightK, Time.time, camC);
        Place(false);
    }

    void Place(bool snap) {
        float dt = Time.deltaTime; double u = Mathf.Clamp01((RoadNet.Clearance((float)S.x, (float)S.z) - 0.3f) / 2.4f); float ride = RoadNet.SURF * (1 - (float)(u * u * (3 - 2 * u)));
        carRoot.position = new Vector3(-(float)S.x, ride + (float)carGy, (float)S.z); carRoot.rotation = Quaternion.Euler(-(float)(tPitch * Mathf.Rad2Deg), -(float)(S.heading * Mathf.Rad2Deg), (float)(tRoll * Mathf.Rad2Deg));
        // body roll (leans outward) / pitch (dive under braking, squat under power)
        double rT = -S.ay * 0.35, pT = -S.axS * 0.30; rollS += (rT - rollS) * (1 - System.Math.Exp(-dt * 8)); pitchS += (pT - pitchS) * (1 - System.Math.Exp(-dt * 8));
        car.body.localRotation = Quaternion.Euler((float)pitchS, 0, (float)rollS);
        // wheels: front = 0, 1 ; rear = 2, 3 (game order). steer the front pair, spin all
        float vF = (float)S.speed, spin = vF * dt / CarModel.WHEEL_R * Mathf.Rad2Deg; spinF += spin; spinR += spin;
        for (int i = 0; i < 4; i++) {
            if (car.wheelPivot[i] == null) continue;
            car.wheelPivot[i].localRotation = Quaternion.Euler(0, i < 2 ? -(float)(S.steerAngle * Mathf.Rad2Deg) : 0, 0);
            car.wheelSpin[i].localRotation = Quaternion.Euler((float)spinF, 0, 0);
        }
        // chase camera: follows the heading with a lag, a bit more FOV at speed
        double dy = S.heading - camYaw; while (dy > System.Math.PI) dy -= 2 * System.Math.PI; while (dy < -System.Math.PI) dy += 2 * System.Math.PI;
        camYaw = snap ? S.heading : camYaw + dy * (1 - System.Math.Exp(-dt * 4.0));
        Vector3 f = new Vector3(-(float)System.Math.Sin(camYaw), 0, (float)System.Math.Cos(camYaw));
        Vector3 target = carRoot.position - f * 6.8f + Vector3.up * 2.5f;
        cam.position = snap ? target : Vector3.Lerp(cam.position, target, 1 - Mathf.Exp(-dt * 12)); cam.LookAt(carRoot.position + f * 3f + Vector3.up * 1.1f);
        camC.fieldOfView = Mathf.Lerp(camC.fieldOfView, 60 + (float)System.Math.Abs(S.speed) * 0.25f, 1 - Mathf.Exp(-dt * 3));
    }

    // ---------------- HUD + touch buttons ----------------
    void OnGUI() {
        if (big == null) { big = new GUIStyle(GUI.skin.label) { fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter, normal = { textColor = Color.white } }; small = new GUIStyle(big); btn = new GUIStyle(GUI.skin.box) { fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter, normal = { textColor = Color.white } }; }
        Layout(); big.fontSize = (int)(64 * ui); small.fontSize = (int)(26 * ui); btn.fontSize = (int)(34 * ui);
        GUI.color = new Color(1, 1, 1, 0.55f);
        Pad(rL, "◀", LEFT); Pad(rR, "▶", RIGHT); Pad(rGas, "GAS", GAS); Pad(rBrk, "BRAKE", BRAKE); Pad(rHand, "HAND", HAND); GUI.Box(rReset, "R", btn); GUI.Box(rDay, nightTgt > 0.5f ? "NIGHT" : "DAY", btn);
        GUI.color = Color.white; float W = Screen.width;
        GUI.Label(new Rect(W / 2 - 150 * ui, 20 * ui, 300 * ui, 80 * ui), Mathf.RoundToInt((float)System.Math.Abs(S.speed) * 3.6f).ToString(), big);
        GUI.Label(new Rect(W / 2 - 150 * ui, 90 * ui, 300 * ui, 34 * ui), "km/h   •   " + (S.gear == 0 ? "R" : S.gear.ToString()), small);
        float rp = Mathf.Clamp01((float)(S.rpm / (Veh.REDLINE_RPM + 300))); var bar = new Rect(W / 2 - 150 * ui, 130 * ui, 300 * ui * rp, 10 * ui);
        GUI.color = rp > 0.9f ? Color.red : new Color(0.3f, 0.85f, 1f); GUI.DrawTexture(bar, Texture2D.whiteTexture); GUI.color = Color.white;
    }
    void Pad(Rect r, string t, int bit) { GUI.color = new Color(1, 1, 1, (mask & bit) != 0 ? 0.9f : 0.45f); GUI.Box(r, t, btn); }
}
