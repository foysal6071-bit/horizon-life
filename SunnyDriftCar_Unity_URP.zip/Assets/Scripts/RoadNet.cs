// Sunny Drift - road network, C# port of road.h (rings 220/420/640 m + 2 connector roads, centripetal Catmull-Rom like three.js)
using System;
using System.Collections.Generic;
using UnityEngine;

public class Curve {
    public List<Vector3> pts = new List<Vector3>(); public bool closed = true, open; public double hw;
    List<double> lens = new List<double>();

    static double Cr(double x0, double x1, double x2, double x3, double dt0, double dt1, double dt2, double t) {
        double t1 = (x1 - x0) / dt0 - (x2 - x0) / (dt0 + dt1) + (x2 - x1) / dt1;
        double t2 = (x2 - x1) / dt1 - (x3 - x1) / (dt1 + dt2) + (x3 - x2) / dt2;
        t1 *= dt1; t2 *= dt1;
        return x1 + t1 * t + (-3 * x1 + 3 * x2 - 2 * t1 - t2) * t * t + (2 * x1 - 2 * x2 + t1 + t2) * t * t * t;
    }
    static double D2(Vector3 a, Vector3 b) { return (a - b).sqrMagnitude; }
    public Vector3 GetPoint(double t) {
        long l = pts.Count; double p = (l - (closed ? 0 : 1)) * t;
        long ip = (long)Math.Floor(p); double w = p - ip;
        if (closed) { if (!(ip > 0)) ip += (long)(Math.Floor(Math.Abs((double)ip) / l) + 1) * l; }
        else if (w == 0 && ip == l - 1) { ip = l - 2; w = 1; }
        Vector3 p0, p3;
        if (closed || ip > 0) p0 = pts[(int)((ip - 1) % l)]; else p0 = 2 * pts[0] - pts[1];
        Vector3 p1 = pts[(int)(ip % l)], p2 = pts[(int)((ip + 1) % l)];
        if (closed || ip + 2 < l) p3 = pts[(int)((ip + 2) % l)]; else p3 = 2 * pts[(int)l - 1] - pts[(int)l - 2];
        double dt0 = Math.Pow(D2(p0, p1), 0.25), dt1 = Math.Pow(D2(p1, p2), 0.25), dt2 = Math.Pow(D2(p2, p3), 0.25);
        if (dt1 < 1e-4) dt1 = 1; if (dt0 < 1e-4) dt0 = dt1; if (dt2 < 1e-4) dt2 = dt1;
        return new Vector3((float)Cr(p0.x, p1.x, p2.x, p3.x, dt0, dt1, dt2, w), (float)Cr(p0.y, p1.y, p2.y, p3.y, dt0, dt1, dt2, w), (float)Cr(p0.z, p1.z, p2.z, p3.z, dt0, dt1, dt2, w));
    }
    public void Build() {
        const int DIV = 200; lens.Clear(); lens.Add(0); Vector3 last = GetPoint(0); double sum = 0;
        for (int p = 1; p <= DIV; p++) { Vector3 c = GetPoint((double)p / DIV); sum += (c - last).magnitude; lens.Add(sum); last = c; }
    }
    public double Length { get { return lens[lens.Count - 1]; } }
    double UtoT(double u) {
        int il = lens.Count; double target = u * lens[il - 1]; int low = 0, high = il - 1, i = 0;
        while (low <= high) { i = low + (high - low) / 2; double cmp = lens[i] - target; if (cmp < 0) low = i + 1; else if (cmp > 0) high = i - 1; else { high = i; break; } }
        i = high < 0 ? 0 : high;
        if (lens[i] == target) return (double)i / (il - 1);
        return (i + (target - lens[i]) / (lens[i + 1] - lens[i])) / (il - 1);
    }
    public Vector3 GetPointAt(double u) { return GetPoint(UtoT(u)); }
    public Vector3 GetTangentAt(double u) {
        double t = UtoT(u), d = 0.0001, t1 = Math.Max(t - d, 0), t2 = Math.Min(t + d, 1);
        Vector3 v = GetPoint(t2) - GetPoint(t1); return v.sqrMagnitude == 0 ? Vector3.forward : v.normalized;
    }
}

public static class RoadNet {
    public const float SURF = 0.08f; const double PI = Math.PI;
    public static Curve A, B, C, D, E;
    const int RG = 24; static Dictionary<long, List<Vector3>> grid = new Dictionary<long, List<Vector3>>();
    static long Key(long cx, long cz) { return (cx + 100000) * 200003L + (cz + 100000); }

    static readonly double[] A220 = { 22, 15, 10, 5 }, K220 = { 2, 3, 5, 7 }, A420 = { 28, 20, 12, 8 }, K420 = { 3, 4, 7, 11 }, A640 = { 30, 22, 14, 9 }, K640 = { 3, 5, 8, 13 };
    static void RingPt(double R, double a, out double x, out double z) {
        int kind = R < 300 ? 0 : (R < 550 ? 1 : 2);
        double[] Am = kind == 0 ? A220 : kind == 1 ? A420 : A640, Km = kind == 0 ? K220 : kind == 1 ? K420 : K640;
        double SX = kind == 0 ? 1.40 : 1.30, SZ = kind == 0 ? 0.66 : kind == 1 ? 0.80 : 0.78, p = R * 0.013, r = R;
        for (int i = 0; i < 4; i++) r += Am[i] * ((i % 2) != 0 ? Math.Cos(Km[i] * a - p * i) : Math.Sin(Km[i] * a + p * (i + 1)));
        x = Math.Cos(a) * r * SX; z = Math.Sin(a) * r * SZ;
    }
    static Curve MakeRing(double radius, double width) {
        var c = new Curve(); int seg = (int)Math.Floor(radius * 2.3 + 0.5);
        for (int i = 0; i < seg; i++) { double a = (double)i / seg * PI * 2 + PI / 2, px, pz; RingPt(radius, a, out px, out pz); c.pts.Add(new Vector3((float)px, SURF, (float)pz)); }
        c.closed = true; c.hw = width / 2; c.Build(); return c;
    }
    static Curve MakeConn(double R0, double R1, double a, double amp) {
        double ax, az, bx, bz; RingPt(R0, a, out ax, out az); RingPt(R1, a, out bx, out bz); const int K = 14;
        double dx = bx - ax, dz = bz - az, dl = Math.Sqrt(dx * dx + dz * dz), px = -dz / dl, pz = dx / dl;
        var c = new Curve { closed = false, open = true, hw = 6.0 };
        for (int i = 0; i <= K; i++) { double t = (double)i / K, off = amp * Math.Sin(2 * PI * t) * Math.Sin(PI * t); c.pts.Add(new Vector3((float)(ax + dx * t + px * off), SURF, (float)(az + dz * t + pz * off))); }
        c.Build(); return c;
    }

    // ---- strip mesh: profile = list of (offset, height, u 0..1) ----
    class MB { public List<Vector3> v = new List<Vector3>(); public List<Vector2> uv = new List<Vector2>(); public List<int> idx = new List<int>(); }
    static void Strip(MB m, Curve cv, int N, float[][] prof, int vRep, double t0, double t1) {
        int P = prof.Length, b = m.v.Count;
        for (int i = 0; i <= N; i++) {
            double t = ((t0 + (t1 - t0) * i / N) % 1.0 + 1.0) % 1.0;
            Vector3 p = cv.GetPointAt(t), tg = cv.GetTangentAt(t);
            double nl = Math.Sqrt(tg.x * tg.x + tg.z * tg.z); if (nl == 0) nl = 1;
            float ux = (float)(-tg.z / nl), uz = (float)(tg.x / nl);
            for (int j = 0; j < P; j++) { m.v.Add(new Vector3(p.x + ux * prof[j][0], prof[j][1], p.z + uz * prof[j][0])); m.uv.Add(new Vector2(prof[j][2], (float)i / N * vRep)); }
        }
        for (int i = 0; i < N; i++) for (int j = 0; j < P - 1; j++) {
            int a = b + i * P + j, c = b + (i + 1) * P + j;
            m.idx.Add(a); m.idx.Add(c); m.idx.Add(a + 1); m.idx.Add(a + 1); m.idx.Add(c); m.idx.Add(c + 1);
        }
    }
    static Mesh ToMesh(MB m) {
        // game x axis is mirrored in Unity (left-handed), then make faces point up
        for (int i = 0; i < m.v.Count; i++) { var q = m.v[i]; q.x = -q.x; m.v[i] = q; }
        if (m.idx.Count >= 3) { Vector3 n = Vector3.Cross(m.v[m.idx[1]] - m.v[m.idx[0]], m.v[m.idx[2]] - m.v[m.idx[0]]); if (n.y < 0) for (int i = 0; i < m.idx.Count; i += 3) { int t = m.idx[i + 1]; m.idx[i + 1] = m.idx[i + 2]; m.idx[i + 2] = t; } }
        var me = new Mesh { indexFormat = UnityEngine.Rendering.IndexFormat.UInt32 };
        me.SetVertices(m.v); me.SetUVs(0, m.uv); me.SetTriangles(m.idx, 0); me.RecalculateNormals(); me.RecalculateBounds(); return me;
    }
    static readonly float[][] VP = { new float[] { -1.5f, 0.075f, 0 }, new float[] { 0, 0.08f, 0.15f }, new float[] { 3.5f, 0.06f, 0.55f }, new float[] { 8, 0.045f, 1 } };
    static void AddRoad(MB road, MB verge, Curve cv, double t0, double t1, bool trimVerge) {
        double len = cv.Length; float hw = (float)cv.hw; int N = (int)Math.Ceiling(len / 1.5), rep = Math.Max(1, (int)Math.Floor(len / 8 + 0.5));
        Strip(road, cv, N, new[] { new float[] { hw, SURF, 0 }, new float[] { -hw, SURF, 1 } }, rep, t0, t1);
        double s0 = t0, s1 = t1;
        if (trimVerge) { s0 = Math.Min(0.35, hw * 1.5 / len); s1 = 1 - s0; }
        foreach (int s in new[] { 1, -1 }) {
            var sh = new List<float[]>(); foreach (var q in VP) sh.Add(new[] { s * (hw + q[0]), q[1], q[2] });
            if (s > 0) sh.Reverse();
            Strip(verge, cv, Math.Max(2, (int)Math.Ceiling(N * (s1 - s0))), sh.ToArray(), Math.Max(1, (int)Math.Floor(len / 2.5 * (s1 - s0) + 0.5)), s0, s1);
        }
    }

    public static void Init(Transform parent, Material roadMat, Material vergeMat) {
        A = MakeRing(220, 14); B = MakeRing(420, 15); D = MakeRing(640, 15);
        C = MakeConn(220, 420, -PI / 2 + 0.10, 18); E = MakeConn(420, 640, 0.72, 22);
        var road = new MB(); var verge = new MB();
        foreach (var r in new[] { A, B, D }) AddRoad(road, verge, r, 0, 1, false);
        foreach (var r in new[] { C, E }) AddRoad(road, verge, r, 0, 0.99999, true);
        Make("Road", ToMesh(road), roadMat, parent); Make("Verge", ToMesh(verge), vergeMat, parent);
        foreach (var cv in new[] { A, B, C, D, E }) {
            int cnt = (int)Math.Ceiling(cv.Length / 2);
            for (int i = 0; i <= cnt; i++) {
                Vector3 p = cv.GetPointAt(cv.open ? Math.Min((double)i / cnt, 0.99999) : (double)(i % cnt) / cnt);
                long k = Key((long)Math.Floor(p.x / RG), (long)Math.Floor(p.z / RG));
                List<Vector3> l; if (!grid.TryGetValue(k, out l)) grid[k] = l = new List<Vector3>();
                l.Add(new Vector3(p.x, p.z, (float)cv.hw));
            }
        }
    }
    static void Make(string n, Mesh m, Material mat, Transform parent) {
        var g = new GameObject(n); g.transform.SetParent(parent, false);
        g.AddComponent<MeshFilter>().sharedMesh = m; g.AddComponent<MeshRenderer>().sharedMaterial = mat;
    }

    // distance from nearest road EDGE (negative = on the road)
    public static float Clearance(float x, float z) {
        long cx = (long)Math.Floor(x / RG), cz = (long)Math.Floor(z / RG); float best = 1e9f;
        for (int i = -1; i <= 1; i++) for (int j = -1; j <= 1; j++) {
            List<Vector3> l; if (!grid.TryGetValue(Key(cx + i, cz + j), out l)) continue;
            foreach (var s in l) { float dx = x - s.x, dz = z - s.y, d = Mathf.Sqrt(dx * dx + dz * dz) - s.z; if (d < best) best = d; }
        }
        return best;
    }
    // distances to the nearest road edge of every road sample within `cells` grid cells (used by the terrain fade)
    public static IEnumerable<double> NearEdges(double x, double z, int cells) {
        long cx = (long)Math.Floor(x / RG), cz = (long)Math.Floor(z / RG);
        for (int i = -cells; i <= cells; i++) for (int j = -cells; j <= cells; j++) {
            List<Vector3> l; if (!grid.TryGetValue(Key(cx + i, cz + j), out l)) continue;
            foreach (var s in l) { double dx = x - s.x, dz = z - s.y; yield return Math.Sqrt(dx * dx + dz * dz) - s.z; }
        }
    }
    public static Surface SurfaceAt(float x, float z) {
        double c = Clearance(x, z), t = Math.Min(Math.Max((c - 0.8) / 2.2, 0), 1), g = t * t * (3 - 2 * t);
        return new Surface { mu = 1.15 - 0.3 * g, rr = 0.028 + 0.06 * g, muF = -1, muR = -1 };
    }
    public static void StartPose(out double x, out double z, out double heading) {
        Vector3 p = A.GetPointAt(0), t = A.GetTangentAt(0); x = p.x; z = p.z; heading = Math.Atan2(t.x, t.z);
    }
    // put the car on the nearest road point, facing the way it was going
    public static void Reset(CarState S) {
        double bd = 1e18, bt = 0; Curve bc = A;
        foreach (var cv in new[] { A, B, C, D, E }) for (int i = 0; i < 360; i++) {
            double t = i / 360.0; Vector3 p = cv.GetPointAt(t); double dx = p.x - S.x, dz = p.z - S.z, d = dx * dx + dz * dz;
            if (d < bd) { bd = d; bc = cv; bt = t; }
        }
        Vector3 q = bc.GetPointAt(bt), tn = bc.GetTangentAt(bt); double hd = Math.Atan2(tn.x, tn.z);
        if (Math.Cos(hd - S.heading) < 0) hd += PI;
        S.x = q.x; S.z = q.z; S.heading = hd; S.speed = S.vy = S.yaw = S.steer = S.steerAngle = 0;
        S.throttle = S.brake = S.hb = S.drift = 0; S.gear = 1; S.rpm = 900; S.shiftT = 0; S.slope = 0; S.fd = S.ax = S.ay = S.axS = S.revTimer = S.aFr = S.aRr = 0;
    }
}
