// Sunny Drift - rolling Swiss hills (port of terrain.h: fieldNoise / fieldMask / fieldH / grassColor / ground lattice).
// Not ported yet: river, dirt track, lake (they are separate features in the C++ game). Heights near roads are exactly 0, like the C++ game.
using System;
using System.Collections.Generic;
using UnityEngine;

public static class Terrain2 {
    const double FIELD_MAX = 52, FIELD_AMP = 31, HF0 = 1350, HF1 = 1575;
    const double GX0 = -1350, GX1 = 1350, GZ0 = -960, GZ1 = 960;
    public const double CELL = 10; static int NX, NZ; static float[] H, F;
    static double[] FS = { 0.5, 100, 200, 300 };
    static double Cl01(double v) { return v < 0 ? 0 : v > 1 ? 1 : v; }
    static double Ss(double a, double b, double x) { double t = Math.Min(Math.Max((x - a) / (b - a), 0.0), 1.0); return t * t * (3 - 2 * t); }
    static double FHash(double x, double y) { double h = Math.Sin(x * 127.1 + y * 311.7 + FS[0] * 0.37) * 43758.5453; return h - Math.Floor(h); }
    static double FNoise(double x, double y) {
        double ix = Math.Floor(x), iy = Math.Floor(y), fx = x - ix, fy = y - iy, u = fx * fx * (3 - 2 * fx), v = fy * fy * (3 - 2 * fy);
        return (FHash(ix, iy) * (1 - u) + FHash(ix + 1, iy) * u) * (1 - v) + (FHash(ix, iy + 1) * (1 - u) + FHash(ix + 1, iy + 1) * u) * v;
    }
    static double FFbm(double x, double y, int o) { double a = 0.5, s = 0, f = 1, n = 0; for (int i = 0; i < o; i++) { s += a * FNoise(x * f + i * 17.3, y * f - i * 9.1); n += a; f *= 2.03; a *= 0.5; } return s / n; }

    static double FieldClear(double x, double z) {   // distance to the nearest road edge, looks 96 m around
        double best = 1e9; foreach (double d in RoadNet.NearEdges(x, z, 4)) if (d < best) best = d; return best;
    }
    static double FieldNoise(double x, double z) {
        double wx = x + 38 * (FFbm(x / 190 + FS[2], z / 190 + 7.3, 2) - 0.5), wz = z + 38 * (FFbm(x / 190 - 5.1, z / 190 + FS[1], 2) - 0.5);
        double big = FFbm(wx / 420 + FS[1], wz / 420 + FS[2], 3), vd = Math.Abs(z - 40 * Math.Sin(x / 300 + 0.5));
        double mass = Cl01(0.35 * Ss(0.37, 0.61, big) + Ss(200, 500, vd));
        double det = FFbm(wx / 150 + FS[3], wz / 150 - FS[1], 3), roll = FFbm(wx / 160 - FS[2], wz / 160 + FS[3], 2);
        double rg = 0, a = 0.5, f = 1.0 / 110, w = 1;
        for (int i = 0; i < 4; i++) { double n = 1 - Math.Abs(FNoise(wx * f + FS[3] + i * 3.1, wz * f - FS[2] + i * 5.7) * 2 - 1); n *= n; n *= w; w = Cl01(n * 1.6); rg += n * a; f *= 2.1; a *= 0.5; }
        double crest = Ss(0.45, 0.9, mass);
        double h = FIELD_AMP * mass * (0.35 + 0.45 * det + 0.55 * rg * crest) + 3.0 * roll;
        h += 0.9 * (FFbm(x / 14 + 31.7, z / 14 - 12.9, 2) - 0.5) * (0.4 + mass);
        { double st = h / 3.2, fl = Math.Floor(st), fr = st - fl; h = (fl + Ss(0.35, 0.65, fr) * 0.35 + fr * 0.65) * 3.2 * mass + h * (1 - mass); }
        return Math.Max(0.0, Math.Min(FIELD_MAX, h));
    }
    static double FieldMask(double x, double z) {
        double edge = Math.Min(Math.Min(x - GX0, GX1 - x), Math.Min(z - GZ0, GZ1 - z)); if (edge <= 0) return 0;
        double m = 1 - Ss(HF0, HF1, Math.Sqrt(x * x + z * z)); if (m <= 0) return 0;
        return m * Ss(10, 80, FieldClear(x, z));
    }
    static double FieldH(double x, double z) {
        double m = FieldMask(x, z), h = 0; if (m > 0) h = FieldNoise(x, z) * m;
        double W = h > 3 ? Math.Min(85.0, Math.Max(10.0, h / 0.30)) : 10.0;
        double rc = W > 10.0 ? FieldClear(x, z) : RoadNet.Clearance((float)x, (float)z); if (rc < 4 + W) h *= Ss(4, 4 + W, rc);
        return h;
    }

    // ground height under a point (what the tyres touch): bilinear on the lattice
    public static double GroundH(double x, double z) {
        if (H == null) return 0; double fx = (x - GX0) / CELL, fz = (z - GZ0) / CELL; if (fx < 0 || fz < 0 || fx >= NX || fz >= NZ) return 0;
        int i = (int)fx, k = (int)fz; double u = fx - i, v = fz - k, W = NX + 1;
        double a = H[k * (NX + 1) + i], b = H[k * (NX + 1) + i + 1], c = H[(k + 1) * (NX + 1) + i], d = H[(k + 1) * (NX + 1) + i + 1];
        return (u + v <= 1) ? a + u * (b - a) + v * (c - a) : b * (1 - v) + c * (1 - u) + d * (u + v - 1);
    }
    static double Slope(int i, int k) {
        int W = NX + 1; int i0 = Math.Max(i - 1, 0), i1 = Math.Min(i + 1, NX), k0 = Math.Max(k - 1, 0), k1 = Math.Min(k + 1, NZ);
        double dx = (F[k * W + i1] - F[k * W + i0]) / ((i1 - i0) * CELL), dz = (F[k1 * W + i] - F[k0 * W + i]) / ((k1 - k0) * CELL); return Math.Sqrt(dx * dx + dz * dz);
    }
    static readonly Vector3 C1 = new Vector3(0x5b, 0x7a, 0x3b) / 255f, C2 = new Vector3(0x86, 0x99, 0x4e) / 255f, DRY = new Vector3(0xa0, 0x9a, 0x5c) / 255f, DARK = new Vector3(0x44, 0x59, 0x2f) / 255f, SAND = new Vector3(0x9c, 0x84, 0x5f) / 255f;
    static Color Grass(double x, double z, double f, double sl) {
        double y = -z, t = (Math.Sin(x * 0.05) + Math.Cos(y * 0.07)) * 0.25 + Math.Sin(x * 0.17 + y * 0.11) * 0.15 + Math.Sin(x * 0.011 - y * 0.013) * 0.25 + 0.5 + (FHash(Math.Floor(x * 0.7), Math.Floor(y * 0.7)) - 0.5) * 0.06, tt = Cl01(t);
        Vector3 c = C1 + (C2 - C1) * (float)tt;
        double dn = Math.Sin(x * 0.007 + 1.3) * Math.Cos(y * 0.006 - 0.7) + Math.Sin(x * 0.021 + y * 0.017) * 0.4;
        if (dn > 0.35) c = Vector3.Lerp(c, DRY, (float)Math.Min((dn - 0.35) * 0.5, 0.14)); else if (dn < -0.5) c = Vector3.Lerp(c, DARK, (float)Math.Min((-0.5 - dn) * 0.7, 0.5));
        double bare = 0, rc = RoadNet.Clearance((float)x, (float)z);
        if (rc < 22) { double n = 0.9 + 0.2 * FNoise(x / 80, z / 80), kr = Math.Min(1.0, (1 - Ss(4, 22, Math.Max(rc, 0.0))) * 0.8 * n); c = Vector3.Lerp(c, SAND, (float)kr); bare = Math.Max(bare, kr); }
        double k = 1 + 0.10 * (f / FIELD_AMP); Vector3 m = (C1 + C2) / 2; c = Div(c, m) * (float)k;
        double w = 1 - bare; c.x *= (float)(1 + 0.30 * w); c.y *= (float)(1 + 0.24 * w); c.z *= (float)(1 - 0.50 * w);
        // rock on steep faces, dry alpine grass high up (targets are in the same normalised space as c: colour / mid-grass * 0.5)
        double n1 = FNoise(x / 9 + 4.4, z / 9 - 2.2), n2 = FNoise(x / 2.5, z / 2.5), rockA = Ss(0.55, 0.95, sl + (n1 - 0.5) * 0.3), high = Ss(14, 30, f + (n1 - 0.5) * 5);
        Vector3 alp = Div(new Vector3(0.40f, 0.55f, 0.20f), m) * 0.5f; c = Vector3.Lerp(c, alp, (float)(high * 0.30 * (1 - rockA)));
        Vector3 rock = Div(new Vector3((float)(0.46 + 0.12 * n2), (float)(0.42 + 0.10 * n2), (float)(0.37 + 0.09 * n2)), m) * 0.5f; c = Vector3.Lerp(c, rock, (float)Math.Min(1.0, rockA * 0.8));
        return new Color(Mathf.Min(1.4f, 0.441f * c.x), Mathf.Min(1.4f, 0.539f * c.y), Mathf.Min(1.4f, 0.269f * c.z));
    }
    static Vector3 Div(Vector3 a, Vector3 b) { return new Vector3(a.x / b.x, a.y / b.y, a.z / b.z); }

    public static void Init(Transform parent, Material mat) {
        var rng = new System.Random(); for (int i = 0; i < 4; i++) FS[i] = rng.NextDouble() * 500;     // different hills on every launch
        NX = (int)((GX1 - GX0) / CELL); NZ = (int)((GZ1 - GZ0) / CELL); int W = NX + 1;
        H = new float[W * (NZ + 1)]; F = new float[W * (NZ + 1)];
        for (int k = 0; k <= NZ; k++) for (int i = 0; i <= NX; i++) { double x = GX0 + i * CELL, z = GZ0 + k * CELL; F[k * W + i] = H[k * W + i] = (float)FieldH(x, z); }
        bool lin = QualitySettings.activeColorSpace == ColorSpace.Linear;
        var v = new Vector3[W * (NZ + 1)]; var n = new Vector3[v.Length]; var col = new Color[v.Length];
        for (int k = 0; k <= NZ; k++) for (int i = 0; i <= NX; i++) {
            int q = k * W + i; double x = GX0 + i * CELL, z = GZ0 + k * CELL;
            double hxm = H[k * W + Math.Max(i - 1, 0)], hxp = H[k * W + Math.Min(i + 1, NX)], hzm = H[Math.Max(k - 1, 0) * W + i], hzp = H[Math.Min(k + 1, NZ) * W + i];
            double nx = (hxm - hxp) / (2 * CELL), nz = (hzm - hzp) / (2 * CELL), l = Math.Sqrt(nx * nx + nz * nz + 1);
            v[q] = new Vector3(-(float)x, H[q], (float)z); n[q] = new Vector3(-(float)(nx / l), (float)(1 / l), (float)(nz / l));
            Color c = Grass(x, z, F[q], Slope(i, k)); col[q] = lin ? c.linear : c;
        }
        var tri = new List<int>(NX * NZ * 6);
        for (int k = 0; k < NZ; k++) for (int i = 0; i < NX; i++) { int a = k * W + i, b = a + 1, c = a + W, d = c + 1; tri.Add(a); tri.Add(b); tri.Add(c); tri.Add(b); tri.Add(d); tri.Add(c); }   // x mirrored: winding chosen so faces point up (shader is two-sided anyway)
        var m = new Mesh { indexFormat = UnityEngine.Rendering.IndexFormat.UInt32 }; m.vertices = v; m.normals = n; m.colors = col; m.SetTriangles(tri, 0); m.RecalculateBounds();
        var g = new GameObject("Hills"); g.transform.SetParent(parent, false); g.AddComponent<MeshFilter>().sharedMesh = m; g.AddComponent<MeshRenderer>().sharedMaterial = mat;
    }
}
