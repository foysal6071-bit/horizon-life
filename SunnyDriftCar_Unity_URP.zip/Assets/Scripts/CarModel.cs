// Sunny Drift - loads the Audi R8 (r8.bytes + r8_meta.txt + r8_groups.txt) into Unity meshes. Port of CarGL::init in car_render.h
using System;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;

public class CarModel : MonoBehaviour {
    const int WH0 = 54432, WHN = 24570, NEON0 = 152712;
    const double S = 2.8 / 2643.1, ZC = -104.45;
    public const float WHEEL_R = 0.3318f;
    public Transform body;                       // roll / pitch applied here
    public Transform[] wheelPivot = new Transform[4];   // 0 FL, 1 FR?, see ORDER (game order 0,2,1,3 of raw wheels)
    public Transform[] wheelSpin = new Transform[4];
    public Renderer[] brakeLights = new Renderer[0];

    class Item { public int s, c; Material mat; public int tgt; public Material M { get { return mat; } set { mat = value; } } }

    // URP/Lit material (falls back to Standard on Built-in RP)
    static Shader litShader;
    public static Material Lit(Color col, float metal, float smooth, bool transparent = false, Color? emis = null) {
        if (litShader == null) litShader = Shader.Find("Universal Render Pipeline/Lit");
        if (litShader == null) { Debug.LogError("URP/Lit shader not found. Install the Universal RP package and run  Sunny Drift > Apply URP Settings."); litShader = Shader.Find("Hidden/InternalErrorShader"); }
        var m = new Material(litShader); m.SetColor("_BaseColor", col);
        m.SetFloat("_Metallic", metal); m.SetFloat("_Smoothness", smooth);
        if (emis.HasValue) { m.EnableKeyword("_EMISSION"); m.SetColor("_EmissionColor", emis.Value); m.globalIlluminationFlags = MaterialGlobalIlluminationFlags.RealtimeEmissive; }
        if (transparent) {   // URP/Lit "Surface Type = Transparent, Blend = Alpha"
            m.SetFloat("_Surface", 1); m.SetFloat("_Blend", 0); m.SetFloat("_ZWrite", 0);
            m.SetFloat("_SrcBlend", (float)UnityEngine.Rendering.BlendMode.SrcAlpha); m.SetFloat("_DstBlend", (float)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
            if (m.HasProperty("_SrcBlendAlpha")) { m.SetFloat("_SrcBlendAlpha", (float)UnityEngine.Rendering.BlendMode.One); m.SetFloat("_DstBlendAlpha", (float)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha); }
            m.EnableKeyword("_SURFACE_TYPE_TRANSPARENT"); m.SetOverrideTag("RenderType", "Transparent");
            m.SetShaderPassEnabled("DepthOnly", false); m.SetShaderPassEnabled("ShadowCaster", false);   // glass / blob must not write depth or cast shadows
            m.renderQueue = (int)UnityEngine.Rendering.RenderQueue.Transparent;
        }
        return m;
    }
    // many R8 groups share one look -> share the Material (fewer SRP-Batcher state changes)
    static readonly Dictionary<string, Material> matCache = new Dictionary<string, Material>();
    public static Material MakeMat(string name, Color col, int em, double al) {
        string n = name.ToLower(); bool metal = n.Contains("metal") || n.Contains("chrome") || n.Contains("alu");
        bool tr = al < 0.99; if (tr) col.a = (float)al;
        string key = n + "|" + ColorUtility.ToHtmlStringRGBA(col) + "|" + em + "|" + tr; Material cached;
        if (matCache.TryGetValue(key, out cached) && cached != null) return cached;
        var m = Lit(col, metal ? 0.85f : 0.2f, n.Contains("gloss") || n.Contains("paint") || n.Contains("glass") ? 0.85f : 0.45f, tr, em == 1 ? (Color?)(col * 1.5f) : null);
        m.name = "R8_" + name; matCache[key] = m; return m;
    }

    public void Load() {
        var meta = Resources.Load<TextAsset>("r8_meta").text.Split(new[] { ' ', '\n', '\r', '\t' }, StringSplitOptions.RemoveEmptyEntries);
        int n = int.Parse(meta[0]), ni = int.Parse(meta[1]);
        double[] mn = { D(meta[2]), D(meta[3]), D(meta[4]) }, sz = { D(meta[5]), D(meta[6]), D(meta[7]) };
        byte[] raw = Resources.Load<TextAsset>("r8").bytes;
        var vb = new Vector3[n]; var nb = new Vector3[n];
        for (int i = 0; i < n; i++) {
            double rx = mn[0] + BitConverter.ToUInt16(raw, i * 6) / 65535.0 * sz[0], ry = mn[1] + BitConverter.ToUInt16(raw, i * 6 + 2) / 65535.0 * sz[1], rz = mn[2] + BitConverter.ToUInt16(raw, i * 6 + 4) / 65535.0 * sz[2];
            // GL model: x = forward, y = up, z = right  ->  Unity: x = right, y = up, z = forward
            vb[i] = new Vector3((float)(-rx * S), (float)(ry * S), (float)((rz - ZC) * S));
            double nx = (sbyte)raw[n * 6 + i * 4] / 127.0, ny = (sbyte)raw[n * 6 + i * 4 + 1] / 127.0, nz = (sbyte)raw[n * 6 + i * 4 + 2] / 127.0, l = Math.Sqrt(nx * nx + ny * ny + nz * nz); if (l == 0) l = 1;
            nb[i] = new Vector3((float)(-nx / l), (float)(ny / l), (float)(nz / l));
        }
        var idx = new int[ni]; for (int i = 0; i < ni; i++) idx[i] = BitConverter.ToUInt16(raw, n * 10 + i * 2);

        // wheel centres (bounding box middle). raw wheel 0/2 = front, 1/3 = rear -> game order 0,2,1,3
        int[] ORDER = { 0, 2, 1, 3 }; var wc = new Vector3[4];
        for (int gi = 0; gi < 4; gi++) {
            int wi = ORDER[gi]; Vector3 lo = Vector3.one * 1e9f, hi = -Vector3.one * 1e9f;
            for (int i = WH0 + wi * WHN; i < WH0 + (wi + 1) * WHN; i++) { lo = Vector3.Min(lo, vb[idx[i]]); hi = Vector3.Max(hi, vb[idx[i]]); }
            wc[gi] = (lo + hi) / 2;
        }

        // material groups -> targets: 0 body, 1..4 tyres, 5..8 rims
        var items = new List<KeyValuePair<int, int[]>>(); var mats = new List<Material>(); var tg = new List<int>();
        foreach (var line in Resources.Load<TextAsset>("r8_groups").text.Split('\n')) {
            var f = line.Split(new[] { ' ', '\r' }, StringSplitOptions.RemoveEmptyEntries); if (f.Length < 6) continue;
            int s = int.Parse(f[1]), c = int.Parse(f[2]), em = int.Parse(f[4]); double al = D(f[5]);
            if (c == 0 || s >= NEON0 || em == 2) continue;
            Color col; if (!ColorUtility.TryParseHtmlString(f[3], out col)) col = Color.gray;
            int t = 0;
            if (s >= WH0) { int wi = (s - WH0) / WHN, off = s - WH0 - wi * WHN, gi = 0; for (int k = 0; k < 4; k++) if (ORDER[k] == wi) gi = k; t = (off >= 666 && off < 1944 ? 5 : 1) + gi; }
            items.Add(new KeyValuePair<int, int[]>(t, new[] { s, c })); mats.Add(MakeMat(f[0], col, em, al));
        }

        body = new GameObject("Body").transform; body.SetParent(transform, false);
        BuildPart(body, 0, items, mats, vb, nb, idx, Vector3.zero);
        for (int gi = 0; gi < 4; gi++) {
            var piv = new GameObject("WheelPivot" + gi).transform; piv.SetParent(body, false); piv.localPosition = wc[gi];
            var spin = new GameObject("WheelSpin" + gi).transform; spin.SetParent(piv, false);
            BuildPart(spin, 1 + gi, items, mats, vb, nb, idx, wc[gi]); BuildPart(spin, 5 + gi, items, mats, vb, nb, idx, wc[gi]);
            wheelPivot[gi] = piv; wheelSpin[gi] = spin;
        }
    }
    static double D(string s) { return double.Parse(s, CultureInfo.InvariantCulture); }

    static void BuildPart(Transform parent, int target, List<KeyValuePair<int, int[]>> items, List<Material> mats, Vector3[] vb, Vector3[] nb, int[] idx, Vector3 offset) {
        var map = new Dictionary<int, int>(); var v = new List<Vector3>(); var nn = new List<Vector3>(); var subs = new List<List<int>>(); var sm = new List<Material>();
        for (int k = 0; k < items.Count; k++) {
            if (items[k].Key != target) continue; var tri = new List<int>(); int s = items[k].Value[0], c = items[k].Value[1];
            for (int i = s; i < s + c; i++) {
                int o = idx[i], r; if (!map.TryGetValue(o, out r)) { r = v.Count; map[o] = r; v.Add(vb[o] - offset); nn.Add(nb[o]); } tri.Add(r);
            }
            for (int i = 0; i + 2 < tri.Count; i += 3) { int t = tri[i + 1]; tri[i + 1] = tri[i + 2]; tri[i + 2] = t; }   // axis swap flips winding
            subs.Add(tri); sm.Add(mats[k]);
        }
        if (v.Count == 0) return;
        var m = new Mesh { indexFormat = UnityEngine.Rendering.IndexFormat.UInt32 }; m.SetVertices(v); m.SetNormals(nn); m.subMeshCount = subs.Count;
        for (int i = 0; i < subs.Count; i++) m.SetTriangles(subs[i], i);
        m.RecalculateBounds();
        var g = new GameObject("Mesh" + target); g.transform.SetParent(parent, false);
        g.AddComponent<MeshFilter>().sharedMesh = m; g.AddComponent<MeshRenderer>().sharedMaterials = sm.ToArray();
    }
}
