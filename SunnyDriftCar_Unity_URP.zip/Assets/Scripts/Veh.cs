// Sunny Drift - car physics, 1:1 C# port of car_core.h (Veh::step, v19 realistic model)
using System;

public class CarState {
    public double x, z, heading, speed, vy, yaw, steer, steerAngle, throttle, brake, ax, ay, axS, revTimer;
    public int gear = 1; public double rpm = 900, shiftT, ayLim = 9, hb, drift, fd, slope;
    public bool reverse, braking, handOn; public double aFr, aRr;
}
public struct CarInput { public bool gas, brake, left, right, hand; public double sens; public bool useAnalog; public double analog; }
public struct Surface {
    public double mu, rr, muF, muR, pull, muSide;
    public static Surface Tarmac { get { return new Surface { mu = 1.15, rr = 0.028, muF = -1, muR = -1 }; } }
}

public static class Veh {
    const double G = 9.81, MASS = 1650, WHEELBASE = 2.8, WR = 0.40;
    const double RPM_K = 1.0 / (0.10472 * WR);
    public const double VMAX = 220.0 / 3.6;
    const double IDLE = 900, REDLINE = 7000, EFF = 0.92, ENGINE_BRAKE = 30;
    static readonly double R6 = REDLINE / (VMAX * RPM_K);
    static readonly double[] RATIOS = { 0, R6 * 3.297, R6 * 2.286, R6 * 1.670, R6 * 1.319, R6 * 1.121, R6 };
    const double REV_MAX = 20.0 / 3.6, REV_FORCE = 3600;
    const double BRAKE_DECEL = 13.0, K_AERO = 0.40, K_DOWN = 0.45, RR_OFFSET = 0.015;
    const double TYRE_K = 0.97, TYRE_KL = 1.06, TYRE_B = 13, TYRE_C = 1.4;
    const double LOAD_SENS = 0.13, FZ_REF = MASS * G / 4, RELAX = 0.45, DRIVE_REAR = 0.60;
    const double LA = 1.55, LB = 1.25, IZ = 2700, HCG = 0.46, TRACK = 1.64, LT_FRONT = 0.54;
    const double STEER_LOCK = 0.55, STEER_RATE = 3.6, STEER_RETURN = 6.0;
    public const double REDLINE_RPM = REDLINE;

    static double C(double v, double a, double b) { return Math.Min(Math.Max(v, a), b); }
    static double Sgn(double v) { return v > 0 ? 1 : (v < 0 ? -1 : 0); }

    static readonly double[] TR = { 900, 1500, 2500, 3500, 4500, 5500, 6500, 7300 };
    static readonly double[] TT = { 230, 330, 430, 500, 545, 565, 560, 500 };
    static double Torque(double rpm) {
        double v;
        if (rpm <= TR[0]) v = TT[0]; else if (rpm >= TR[7]) v = TT[7];
        else { int i = 0; while (rpm > TR[i + 1]) i++; v = TT[i] + (TT[i + 1] - TT[i]) * (rpm - TR[i]) / (TR[i + 1] - TR[i]); }
        return v * C((REDLINE + 300 - rpm) / 300, 0, 1);
    }
    static double AxleGrip(double Fa, double dF) {
        double fz0 = Fa * 0.5, k0 = 1 - LOAD_SENS * (fz0 / FZ_REF - 1), r = Math.Min(dF / Math.Max(fz0, 1.0), 1.0);
        return Math.Max(k0, 0.4) * (1 - LOAD_SENS * 1.6 * r * r);
    }

    public static void Step(CarState S, CarInput inp, Surface surf, double dt) {
        double vx0 = S.speed, thrT = 0, brkT = 0; bool rev = false;
        if (inp.gas && inp.brake) brkT = 1;
        else if (inp.gas) { if (vx0 < -0.8) brkT = 1; else thrT = 1; }
        else if (inp.brake) {
            if (vx0 > 0.8) brkT = 1;
            else { S.revTimer += dt; if (S.revTimer > 0.3 || vx0 < -0.8) { rev = true; thrT = 1; } else brkT = 1; }
        }
        if (!inp.brake || inp.gas) S.revTimer = 0;
        if (inp.hand) {
            if (S.speed > 6) brkT = inp.brake ? 1 : (inp.gas ? 0 : ((inp.left || inp.right) ? 0.18 : 0.45));
            else { brkT = 1; thrT = 0; rev = false; }
        }
        S.reverse = rev;
        S.throttle += (thrT - S.throttle) * (1 - Math.Exp(-dt * (thrT > S.throttle ? 7 : 14)));
        S.brake += (brkT - S.brake) * (1 - Math.Exp(-dt * (brkT > S.brake ? 18 : 20)));
        S.braking = S.brake > 0.25; S.handOn = inp.hand;
        S.hb += (((inp.hand && S.speed > 5) ? 1 : 0) - S.hb) * (1 - Math.Exp(-dt * 6));
        double av = Math.Abs(S.speed);

        double steerIn = inp.useAnalog ? inp.analog : (inp.left ? 1 : 0) - (inp.right ? 1 : 0);
        double rate = ((steerIn == 0 || Sgn(steerIn) != Sgn(S.steer)) ? STEER_RETURN : STEER_RATE) * inp.sens / (1 + av / 120);
        double dS = steerIn - S.steer;
        S.steer += Sgn(dS) * Math.Min(Math.Abs(dS), rate * dt);

        S.shiftT = Math.Max(0.0, S.shiftT - dt);
        if (S.reverse || S.speed < -0.5) S.gear = 0;
        else {
            if (S.gear == 0) S.gear = 1;
            double sp = Math.Max(S.speed, 0.0), rpmG = sp * RATIOS[S.gear] * RPM_K;
            if (S.shiftT <= 0) {
                if (S.gear < 6 && (rpmG > 6700 || (rpmG > 5200 && S.throttle < 0.15))) { S.gear++; S.shiftT = 0.12; }
                else if (S.gear > 1 && (rpmG < 2300 || (S.throttle > 0.9 && rpmG < 3600)) && sp * RATIOS[S.gear - 1] * RPM_K < 6400) { S.gear--; S.shiftT = 0.10; }
            }
        }
        double gearR = S.gear == 0 ? 14 : RATIOS[S.gear];
        double rpmW = av * gearR * RPM_K, clutch = 1 - C(av / 6, 0, 1);
        double rpmTgt = Math.Max(rpmW, IDLE + S.throttle * 3600 * clutch);
        S.rpm += (rpmTgt - S.rpm) * (1 - Math.Exp(-dt * (rpmTgt > S.rpm ? 12 : 7)));
        S.rpm = Math.Min(S.rpm, REDLINE + 300);

        double Fdrive = 0;
        if (S.throttle > 0.001) {
            if (S.reverse) Fdrive = -S.throttle * REV_FORCE * C((REV_MAX + S.speed) / 3, 0, 1);
            else Fdrive = S.throttle * Torque(Math.Max(S.rpm, 3300.0)) * RATIOS[S.gear] * EFF / WR *
                    (S.shiftT > 0 ? 1 - 0.5 * Math.Sin(Math.PI * (1 - Math.Min(S.shiftT / 0.12, 1.0))) : 1);
        }
        if (!S.reverse) Fdrive *= C((VMAX - S.speed) / 1.2, 0, 1);
        S.fd += (Fdrive - S.fd) * (1 - Math.Exp(-dt * 16)); Fdrive = S.fd;

        double rrS = Math.Max(surf.rr - RR_OFFSET, 0.008);
        double gripN0 = surf.mu * TYRE_K * (MASS * G + K_DOWN * S.speed * S.speed), gripL0 = surf.mu * TYRE_KL * (MASS * G + K_DOWN * S.speed * S.speed);
        double Flong = Math.Max(Math.Min(Math.Abs(Fdrive), 0.8 * gripL0), S.brake * Math.Min(BRAKE_DECEL * MASS, 0.97 * gripL0));
        S.ayLim = Math.Sqrt(Math.Max(gripN0 * gripN0 - Flong * Flong, 0.04 * gripN0 * gripN0)) / MASS * 0.97;
        double sensK = C(0.7 + 0.3 * inp.sens, 0.85, 1.6);
        double lockSpeed = sensK * STEER_LOCK / (1 + Math.Pow(av / 46, 2));
        double lockGrip = 0.06 * sensK + Math.Atan(WHEELBASE * S.ayLim * 1.1 / Math.Max(S.speed * S.speed, 1.0));
        double dDrv = S.steer * Math.Min(lockSpeed, lockGrip);
        double delta = dDrv;

        int N = Math.Max(1, (int)Math.Ceiling(dt / 0.005)); double h = dt / N, axAcc = 0;
        for (int it = 0; it < N; it++) {
            double vx = S.speed, sp = Math.Abs(vx), sg = C(vx / 0.4, -1, 1);
            double wDyn = C((vx - 3) / 4, 0, 1);
            double down = K_DOWN * vx * vx;
            double muFl = surf.muF > 0 ? surf.muF : surf.mu, muRl = surf.muR > 0 ? surf.muR : surf.mu;
            double gripN = surf.mu * TYRE_KL * (MASS * G + down);
            bool wasDrift = S.drift > 0.3;
            double lim = (wasDrift ? 1.0 : 0.80) * gripN;
            double Fd = C(Fdrive, -lim, lim);
            double Fb = S.brake * Math.Min(BRAKE_DECEL * MASS, 0.97 * gripN);
            double Fres = -sg * (rrS * MASS * G + K_AERO * vx * vx + MASS * Math.Abs(S.ay) * 0.04);
            if (S.gear > 0) {
                double eb = C(1 - S.throttle / 0.15, 0, 1) * C(1 - S.brake / 0.15, 0, 1);
                Fres -= sg * C(sp / 2, 0, 1) * ENGINE_BRAKE * RATIOS[S.gear] * (S.rpm / REDLINE) / WR * eb;
            }
            double Fg = -MASS * G * S.slope;
            double Fx = Fd - sg * Fb + Fres + Fg;

            double dFz = C(MASS * S.axS * HCG / WHEELBASE, -0.22 * MASS * G, 0.22 * MASS * G);
            double FzF = Math.Max(MASS * G * LB / WHEELBASE - dFz + down * 0.40, 800.0);
            double FzR = Math.Max(MASS * G * LA / WHEELBASE + dFz + down * 0.60, 800.0);
            double latT = MASS * Math.Abs(S.ay) * HCG / TRACK;
            double gF = AxleGrip(FzF, latT * LT_FRONT), gR = AxleGrip(FzR, latT * (1 - LT_FRONT));
            double muF = muFl * TYRE_K * gF, muR = muRl * TYRE_K * gR;
            double muFL = muFl * TYRE_KL * gF, muRL = muRl * TYRE_KL * gR;

            double uA = Math.Max(vx, 2.5), beta = Math.Atan2(S.vy, uA);
            double usF = C((Fb * 0.68 + Math.Abs(Fd) * (1 - DRIVE_REAR) * 0.8) / (muFL * FzF), 0, 0.95);
            double usR = C(0.8 * Math.Abs(Fd * DRIVE_REAR - sg * Fb * 0.32) / (muRL * FzR), 0, 0.9);
            double capF = Math.Sqrt(1 - usF * usF);
            double capR = Math.Sqrt(1 - usR * usR) * (1 - 0.55 * S.hb) * (1 + 1.3 * C((Math.Abs(beta) - 0.55) / 0.4, 0, 1));
            double wAs = C((Math.Abs(beta) - 0.08) / 0.15, 0, 1) * 0.7 * wDyn;
            delta = C(dDrv + wAs * C(beta, -0.7, 0.7), -0.65, 0.65);

            double aFk = Math.Atan2(S.vy + LA * S.yaw, uA) - delta;
            double aRk = Math.Atan2(S.vy - LB * S.yaw, uA);
            double kr = 1 - Math.Exp(-Math.Max(sp, 4.0) * h / RELAX);
            S.aFr += (aFk - S.aFr) * kr; S.aRr += (aRk - S.aRr) * kr;
            double FyF = -muF * FzF * capF * Math.Sin(TYRE_C * Math.Atan(TYRE_B * S.aFr));
            double FyR = -muR * FzR * capR * Math.Sin(TYRE_C * Math.Atan(TYRE_B * S.aRr));
            double cd = Math.Cos(delta), sd = Math.Sin(delta);

            S.speed += (Fx - FyF * sd * wDyn) / MASS * h;
            S.speed = C(S.speed, -REV_MAX, VMAX * (1 + 0.03 * C(-S.slope * 8, 0, 1)));
            axAcc += Fx / MASS;
            S.vy += (FyF * cd + FyR) / MASS * h * wDyn;
            double yawAsym = (0.5 * MASS * G * surf.pull * C(sp / 2, 0, 1) + 0.5 * Fb * surf.muSide) * 0.85 / IZ;
            S.yaw += ((LA * FyF * cd - LB * FyR) / IZ - 0.55 * S.yaw + yawAsym) * h * wDyn;
            if (wDyn < 1) {
                double rK = S.speed * Math.Tan(delta) / WHEELBASE;
                S.yaw += (rK - S.yaw) * (1 - Math.Exp(-h / 0.05)) * (1 - wDyn);
                S.vy *= Math.Exp(-8 * (1 - wDyn) * h);
                S.aFr *= Math.Exp(-8 * (1 - wDyn) * h); S.aRr *= Math.Exp(-8 * (1 - wDyn) * h);
            }
            S.yaw = C(S.yaw, -2.6, 2.6);
            if (Math.Abs(S.speed) < 0.08 && S.throttle < 0.02 && (Math.Abs(S.slope) < 0.3 || S.brake > 0.3 || S.handOn)) { S.speed = 0; S.vy = 0; S.yaw = 0; S.aFr = S.aRr = 0; }
            double dH = S.yaw * h; S.heading += dH;
            double a = dH * wDyn, c = Math.Cos(a), sn = Math.Sin(a), sp0 = S.speed;
            S.speed = sp0 * c + S.vy * sn; S.vy = -sp0 * sn + S.vy * c;
            double sH = Math.Sin(S.heading), cH = Math.Cos(S.heading);
            S.x += (S.speed * sH + S.vy * cH) * h;
            S.z += (S.speed * cH - S.vy * sH) * h;
        }
        S.steerAngle = C(delta, -0.6, 0.6);
        double bR = Math.Abs(Math.Atan2(S.vy - LB * S.yaw, Math.Max(S.speed, 2.5)));
        double tgt = S.speed > 5 ? C((bR - 0.12) / 0.2, 0, 1) : 0;
        S.drift += (tgt - S.drift) * (1 - Math.Exp(-dt * (tgt > S.drift ? 10 : 3)));
        S.ax = axAcc / N;
        S.axS += (S.ax - S.axS) * (1 - Math.Exp(-dt * 5));
        S.ay = S.speed * S.yaw;
    }
}
