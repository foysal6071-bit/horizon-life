// Sunny Drift - sky + time of day (port of SkyGL::envAt / init in sky.h). Drives the URP skybox, sun light, ambient and fog.
using UnityEngine;

public class SkyEnv {
    public Material mat; public Light sun; public float night, tw, day; public Vector3 sunDir, moonDir, hor, mid, zen, cl, cs, tint, fog;
    static float Ss(float a, float b, float x) { x = Mathf.Clamp01((x - a) / (b - a)); return x * x * (3 - 2 * x); }
    static Vector3 Mix(Vector3 a, Vector3 b, float t) { return a + (b - a) * t; }
    static Vector3 V(float a, float b, float c) { return new Vector3(a, b, c); }

    public void Init(Light sunLight) {
        sun = sunLight; mat = new Material(Shader.Find("SunnyDrift/Sky"));
        // 5 photo faces -> 3x2 atlas (same layout as the HTML canvas, filled #5b7a96)
        Texture2D[] f = new Texture2D[5]; int S = 0;
        for (int i = 0; i < 5; i++) { var t = new Texture2D(2, 2, TextureFormat.RGB24, false); t.LoadImage(Resources.Load<TextAsset>("Sky/sky_" + i).bytes); f[i] = t; S = t.width; }
        var atlas = new Texture2D(S * 3, S * 2, TextureFormat.RGB24, false); var fill = new Color32[S * 3 * S * 2]; for (int i = 0; i < fill.Length; i++) fill[i] = new Color32(0x5b, 0x7a, 0x96, 255);
        atlas.SetPixels32(fill);
        for (int i = 0; i < 5; i++) { if (f[i].width != S || f[i].height != S) continue; int r = i / 3, c = i % 3; atlas.SetPixels(c * S, (1 - r) * S, S, S, f[i].GetPixels()); }
        atlas.wrapMode = TextureWrapMode.Clamp; atlas.filterMode = FilterMode.Bilinear; atlas.Apply(false);
        mat.SetTexture("_CubeTex", atlas); mat.SetFloat("_CubeAmt", 1); mat.SetFloat("_Inset", 1.5f / S); mat.SetFloat("_Q", 1); mat.SetFloat("_Rain", 0);
        mat.SetFloat("_Lin", QualitySettings.activeColorSpace == ColorSpace.Linear ? 1 : 0);
        RenderSettings.skybox = mat;
    }

    // tod: 175 = 1 PM (default), up to 420 = deep night
    public void EnvAt(float tod) {
        const float DAY_S = 300, NIGHT_S = 180, PI = Mathf.PI;
        Vector3[] DAY = { V(.74f, .88f, .98f), V(.34f, .65f, .98f), V(.09f, .34f, .88f) }, DUSK = { V(1, .52f, .26f), V(.62f, .38f, .56f), V(.17f, .21f, .47f) }, NIGHT = { V(.035f, .05f, .10f), V(.012f, .02f, .055f), V(.004f, .008f, .025f) };
        float th = tod < DAY_S ? PI * tod / DAY_S : PI + PI * (tod - DAY_S) / NIGHT_S;
        sunDir = V(-Mathf.Cos(th) * .85f, Mathf.Sin(th) * .95f, .45f).normalized;
        if (tod >= DAY_S) { float m = PI * (tod - DAY_S) / NIGHT_S; moonDir = V(-Mathf.Cos(m) * .8f, Mathf.Sin(m) * .62f, -.55f).normalized; } else moonDir = V(0, -1, 0);
        float e = sunDir.y; day = Ss(-.10f, .32f, e); tw = Mathf.Exp(-Mathf.Pow((e - .03f) / .15f, 2)) * .9f; night = 1 - Ss(-.22f, -.02f, e);
        Vector3[] o = new Vector3[3]; for (int i = 0; i < 3; i++) o[i] = Mix(Mix(NIGHT[i], DAY[i], day), DUSK[i], tw);
        hor = o[0]; mid = o[1]; zen = o[2];
        cl = Mix(Mix(V(.07f, .09f, .16f), V(1, 1, 1), day), V(1, .62f, .45f), tw); cs = Mix(Mix(V(.025f, .035f, .07f), V(.86f, .91f, .97f), day), V(.45f, .32f, .42f), tw);
        tint = Mix(Mix(V(.05f, .065f, .13f), V(1.40f, 1.50f, 1.68f), day), V(1.38f, .86f, .62f), tw * .8f); fog = Mix(hor, V(.70f, .88f, .97f), day * (1 - tw));
    }
    static Vector4 U(Vector3 v) { return new Vector4(-v.x, v.y, v.z, 0); }   // game axes -> Unity (x mirrored); shader mirrors again, so pass GAME axes
    static Vector4 G(Vector3 v) { return new Vector4(v.x, v.y, v.z, 0); }

    public void Apply(float nightK, float time, Camera cam) {
        EnvAt(175f + (420f - 175f) * nightK);
        mat.SetFloat("_T", time); mat.SetFloat("_Night", night); mat.SetFloat("_Tw", tw);
        mat.SetVector("_Sun", G(sunDir)); mat.SetVector("_Moon", G(moonDir)); mat.SetVector("_Hor", G(hor)); mat.SetVector("_Mid", G(mid)); mat.SetVector("_Zen", G(zen));
        mat.SetVector("_Cl", G(cl)); mat.SetVector("_Cs", G(cs)); mat.SetVector("_Tint", G(tint));
        // sun light (Unity world: x mirrored)
        Vector3 toSun = new Vector3(-sunDir.x, sunDir.y, sunDir.z); if (night > 0.6f) toSun = new Vector3(-moonDir.x, Mathf.Max(moonDir.y, 0.2f), moonDir.z);
        sun.transform.rotation = Quaternion.LookRotation(-toSun.normalized);
        float lin = QualitySettings.activeColorSpace == ColorSpace.Linear ? 2.2f : 1f;
        Color dayC = Color.Lerp(new Color(1f, .62f, .38f), new Color(1f, .96f, .88f), 1 - tw);
        sun.color = night > 0.6f ? new Color(.45f, .55f, .9f) : dayC; sun.intensity = night > 0.6f ? 0.25f : Mathf.Lerp(0.05f, 1.15f, day);
        Color amb = Color.Lerp(new Color(.04f, .05f, .10f), new Color(.55f, .62f, .72f), day); if (tw > .1f) amb = Color.Lerp(amb, new Color(.55f, .42f, .45f), tw * .5f);
        RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat; RenderSettings.ambientLight = lin > 1 ? amb.linear : amb;
        Color fc = new Color(fog.x, fog.y, fog.z); RenderSettings.fogColor = lin > 1 ? fc.linear : fc; if (cam) cam.backgroundColor = fc;
    }
}
