Sunny Drift Car - Unity port (v1)

কীভাবে চালাবেন:
1. Unity Hub -> New project -> "3D (URP)" (Unity 2021.3 বা নতুন)।
2. এই zip এর "Assets" ফোল্ডারটি আপনার প্রজেক্টের Assets এ কপি/মার্জ করুন।
3. SampleScene খোলা রেখে Play চাপুন। (সিন খালি থাকলেও চলবে, সব কিছু কোড থেকে তৈরি হয়)
4. কন্ট্রোল: W/A/S/D বা তীর, Space = হ্যান্ডব্রেক, R = রিসেট। মোবাইলে স্ক্রিনের বাটন।

Android বিল্ডের আগে:
- Player Settings > Resolution > Default Orientation = Landscape Left/Auto Rotation (Landscape)
- (v3 থেকে স্বয়ংক্রিয়: Assets/Editor/URPSetup.cs মেনু "Sunny Drift > Apply URP Settings" দিয়ে URP/Lit Always Included Shaders এ যোগ হয়ে যায়)

ফাইল:
- Veh.cs      : গাড়ির ফিজিক্স (car_core.h এর হুবহু C# পোর্ট)
- RoadNet.cs  : ৩টি রিং রোড + ২টি কানেক্টর, রাস্তার মেশ, গ্রিপ (road.h)
- CarModel.cs : Audi R8 মডেল লোড (r8.bin), আলাদা চাকা
- Game.cs     : ক্যামেরা, কন্ট্রোল (টাচ+কীবোর্ড), HUD

v2 (URP রেন্ডারিং):
- Assets/Resources/Shaders/SunnySky.shader : আকাশ shader (sky.h এর GLSL → URP HLSL): মেঘ, সূর্য, চাঁদ, তারা, দিন-রাত
- Assets/Resources/Shaders/VColor.shader   : টেরেইন shader (vertex color + সূর্যের আলো + ছায়া + কুয়াশা)
- SkyEnv.cs   : আকাশের রং, দিন-রাত (DAY/NIGHT বাটন বা N চাপুন)
- Terrain.cs  : পাহাড়/টিলা (terrain.h), গাড়ি ঢালে উঠে-নামে
URP Asset এ Depth/Shadows চালু থাকলে ছায়া দেখাবে।

v3 (সম্পূর্ণ URP রূপান্তর):
- VColor.shader : ForwardLit + ShadowCaster + DepthOnly পাস (টেরেইন/রাস্তার ধার ছায়া ফেলে ও গ্রহণ করে, Depth Texture কাজ করে), SRP Batcher সামঞ্জস্যপূর্ণ
- CarModel.cs   : শুধু URP/Lit (Standard/Sprites ফলব্যাক বাদ), স্বচ্ছ মেটেরিয়াল সঠিক URP কীওয়ার্ড/পাস সহ, একই মেটেরিয়াল শেয়ার (cache)
- Game.cs       : UniversalAdditionalCameraData, RenderSettings.sun, সূর্যের শ্যাডো বায়াস, গাড়ির আসল ছায়া (ব্লব ছায়া হালকা), URP না থাকলে ত্রুটি বার্তা
- Assets/Editor/URPSetup.cs : URP Asset টিউন (ক্যাসকেড সফট শ্যাডো 2048, MSAA 2x, HDR) + Always Included Shaders
