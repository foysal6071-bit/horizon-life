#pragma once
// Sunny Drift - the HTML "makeGrassTexture()" (256 px tile: pale base, soft patches, 5200 blades, specks) painted on the CPU.
// The ground / hills multiply their vertex colour by it (HTML: MeshLambertMaterial map x vertexColors, repeat 500 over 2000 m = one tile per 4 m).
#include "bridge.h"
namespace Bridge {
static void hsl2rgb(double h, double s, double l, double& r, double& g, double& b){      // h in degrees, s / l 0..1 -> 0..255
    auto f = [&](double n){ const double k = std::fmod(n + h / 30.0, 12.0), a = s * std::min(l, 1 - l); return 255.0 * (l - a * std::max(-1.0, std::min(std::min(k - 3, 9 - k), 1.0))); };
    r = f(0); g = f(8); b = f(4);
}
static void strokeLine(Img& im, double x0, double y0, double x1, double y1, double w, double r, double g, double b, double a){   // anti-aliased thick segment, wraps around the tile
    const double dx = x1 - x0, dy = y1 - y0, L2 = std::max(dx*dx + dy*dy, 1e-9), hw = w / 2 + 0.5;
    for (int yy = (int)std::floor(std::min(y0, y1) - hw); yy <= (int)std::ceil(std::max(y0, y1) + hw); yy++)
        for (int xx = (int)std::floor(std::min(x0, x1) - hw); xx <= (int)std::ceil(std::max(x0, x1) + hw); xx++){
            const double px = xx + .5, py = yy + .5, t = std::min(1.0, std::max(0.0, ((px - x0)*dx + (py - y0)*dy) / L2));
            const double d = std::hypot(px - (x0 + dx*t), py - (y0 + dy*t)), cov = std::min(1.0, std::max(0.0, w / 2 + 0.5 - d));
            if (cov > 0) blendPx(im, xx, yy, r, g, b, a * cov);
        }
}
static Img makeGrassTex(){
    const int W = 256; Img im(W, W);
    fillRect(im, 0, 0, W, W, 0xd4, 0xda, 0xbd, 1);                               // #d4dabd
    for (int i = 0; i < 70; i++){                                                // soft patches
        const bool dark = rnd01() < 0.5; const double a = 0.05 + rnd01() * 0.06, x = rnd01() * W, y = rnd01() * W, r = 10 + rnd01() * 34;
        disc(im, x, y, r, dark ? 60 : 255, dark ? 90 : 255, dark ? 30 : 220, a);
    }
    for (int i = 0; i < 5200; i++){                                              // blades
        const double x = rnd01() * W, y = rnd01() * W, h = 3 + rnd01() * 9, lean = (rnd01() - 0.5) * 4;
        double r, g, b; hsl2rgb(66 + rnd01() * 34, (14 + rnd01() * 22) / 100, (46 + rnd01() * 40) / 100, r, g, b);
        const double a = 0.45 + rnd01() * 0.4, lw = 0.8 + rnd01() * 0.8;
        strokeLine(im, x, y, x + lean, y - h, lw, r, g, b, a);
    }
    for (int i = 0; i < 500; i++){ const double x = rnd01() * W, y = rnd01() * W; fillRect(im, x, y, 1 + rnd01() * 2, 1 + rnd01() * 2, 50, 70, 25, 0.22); }
    return im;
}
}
