// Sunny Drift - tunnel portals at the two dead ends of the dirt track (pure C++, no OpenGL).
//  * a concrete arch + an earth mound with a dark tunnel mouth, so the track seems to disappear underground
//  * an invisible wall (oriented box in front of the arch and around the mound): the car cannot get in
//  * blocked() keeps the pine forest from growing through the mound
#pragma once
#include <algorithm>
#include <cmath>
#include <vector>
#include "terrain.h"
#include "village.h"
#include "fence.h"          // bounceOff

namespace Tunnel {

struct Portal { double x, z, bx, bz, y0; };         // (x, z) = centre of the arch front; (bx, bz) = unit vector pointing INTO the tunnel; y0 = ground height there
static std::vector<Portal> gP;

static const double ARCH_R = 4.2, SIDE_H = 2.6, WALL_T = 3.0, DEPTH = 16.0, MOUND_L = 26.0, MOUND_SPREAD = 1.7;
static const double HALF_U = 13.0, W_FRONT = -1.0, W_BACK = 27.0;      // the invisible wall: lateral half width, in front of the arch, behind the mound

static void toLocal(const Portal& P, double x, double z, double& u, double& w){
    const double dx = x - P.x, dz = z - P.z; u = dx * (-P.bz) + dz * P.bx; w = dx * P.bx + dz * P.bz;
}

// call after Terrain::init(): one portal at each end of the dirt track
static void plan(){
    gP.clear(); if (!Terrain::TRK.on || Terrain::TRK.n < 6 || Terrain::PEAK.on) return;   // no tunnel mouths on the hill road
    const std::vector<float>& p = Terrain::TRK.pts; const int n = Terrain::TRK.n;
    auto add = [&](int e, int nb){
        double x = p[e*2], z = p[e*2+1], dx = x - p[nb*2], dz = z - p[nb*2+1]; const double l = std::hypot(dx, dz); if (l < 1e-6) return;
        Portal P; P.x = x; P.z = z; P.bx = dx / l; P.bz = dz / l; P.y0 = Terrain::meshH(x, z); gP.push_back(P);     // away from the track = into the tunnel
    };
    add(0, 3); add(n - 1, n - 4);
}

static bool blocked(double x, double z, double margin){
    for (const Portal& P : gP){ double u, w; toLocal(P, x, z, u, w); if (std::fabs(u) < HALF_U + margin && w > W_FRONT - margin && w < W_BACK + margin) return true; }
    return false;
}

// the invisible wall: three circles along the car, each pushed out of the box (same scheme as the houses)
static void collide(CarState& S){
    if (gP.empty()) return;
    const double sH = std::sin(S.heading), cH = std::cos(S.heading), R = 1.05; static const double OFS[3] = {-1.5, 0.0, 1.5};
    for (const Portal& P : gP){
        const double dx = P.x - S.x, dz = P.z - S.z; if (dx*dx + dz*dz > 70.0 * 70.0) continue;
        for (double o : OFS){
            double u, w; toLocal(P, S.x + sH * o, S.z + cH * o, u, w);
            const double cu = std::max(-HALF_U, std::min(HALF_U, u)), cw = std::max(W_FRONT, std::min(W_BACK, w)), vu = u - cu, vw = w - cw, d = std::sqrt(vu*vu + vw*vw);
            double nu, nw, pen;
            if (d > 1e-6){ if (d >= R) continue; nu = vu / d; nw = vw / d; pen = R - d; }
            else {                                                                                  // centre inside the box: leave through the nearest side
                const double e[4] = {HALF_U - u, u + HALF_U, W_BACK - w, w - W_FRONT}; int k = 0; for (int j = 1; j < 4; j++) if (e[j] < e[k]) k = j;
                nu = (k == 0) ? 1.0 : (k == 1 ? -1.0 : 0.0); nw = (k == 2) ? 1.0 : (k == 3 ? -1.0 : 0.0); pen = e[k] + R;
            }
            const double wx = -P.bz * nu + P.bx * nw, wz = P.bx * nu + P.bz * nw;                   // local -> world direction
            S.x += wx * pen; S.z += wz * pen;
            Fence::bounceOff(S, wx, wz, 0.22, 0.30);
        }
    }
}


// ---------- ROAD TUNNELS (v207): where the player's new road (Road::NEW_EDGE) runs into the mountains, the ground above it is a mountain, so the road becomes a tunnel through it ----------
//  planRoad() finds the buried stretches; the car drives on the road level inside them (groundOverride), the tube (lining + portal rings) is built by build().
struct RSeg { std::vector<float> p; };            // x, z, tx, tz every 2 m
static std::vector<RSeg> gSeg;
static const double TUN_R = 5.4, TUN_SIDE = 3.2, TUN_EXT = 14.0;
static void planRoad(){
    gSeg.clear(); const Road::Curve& cv = Road::gNet.roads[Road::NEW_EDGE]; const double len = cv.length(); const int N = (int)(len / 2.0);
    std::vector<char> bur(N + 1, 0);
    for (int i = 0; i <= N; i++){ const Road::V3 q = cv.getPointAt(std::min((double)i / N, 0.99999)); bur[i] = (!Terrain::inLattice(q.x, q.z) && Terrain::meshH(q.x, q.z) > 2.0) ? 1 : 0; }
    const int ext = (int)(TUN_EXT / 2.0); std::vector<char> m(N + 1, 0);
    for (int i = 0; i <= N; i++) if (bur[i]) for (int j = std::max(0, i - ext); j <= std::min(N, i + ext); j++) m[j] = 1;
    for (int i = 0; i <= N; ){ if (!m[i]){ i++; continue; } int j = i; while (j <= N && m[j]) j++;
        if (j - i > 8){ RSeg s; for (int k = i; k < j; k++){ const double u = std::min((double)k / N, 0.99999); const Road::V3 q = cv.getPointAt(u), tg = cv.getTangentAt(u); double l = std::hypot(tg.x, tg.z); if (l == 0) l = 1;
                s.p.push_back((float)q.x); s.p.push_back((float)q.z); s.p.push_back((float)(tg.x / l)); s.p.push_back((float)(tg.z / l)); } gSeg.push_back(s); }
        i = j; }
}
// true (and y = road level) when (x, z) is inside a tunnel: the car must not climb the mountain above it
static bool inRoadTunnel(double x, double z){
    for (const RSeg& s : gSeg){ if (s.p.size() < 8) continue;
        const double dx0 = x - s.p[0], dz0 = z - s.p[1]; if (dx0*dx0 + dz0*dz0 > 1.0e8 && false) continue;
        for (size_t k = 0; k + 3 < s.p.size(); k += 4){ const double dx = x - s.p[k], dz = z - s.p[k+1]; if (dx*dx + dz*dz < TUN_R * TUN_R) return true; } }
    return false;
}

// ---------- geometry (world space; vertex = pos(3) + normal(3)) ----------
enum { PART_FRAME = 0, PART_MOUND = 1, PART_DARK = 2, PART_FLOOR = 3, PART_LINING = 4, PART_LIGHT = 5, PART_LEAF0 = 6, PART_LEAF1 = 7, PART_LEAF2 = 8, PARTS = 9 };
static const float PART_COL[PARTS][3] = {{0.55f, 0.54f, 0.51f}, {0.28f, 0.40f, 0.22f}, {0.045f, 0.045f, 0.05f}, {0.34f, 0.33f, 0.31f}, {0.36f, 0.36f, 0.37f}, {1.0f, 0.93f, 0.62f}, {0.96f, 0.72f, 0.10f}, {0.84f, 0.52f, 0.07f}, {0.93f, 0.83f, 0.32f}};

static void build(std::vector<float> out[PARTS]){
    for (int i = 0; i < PARTS; i++) out[i].clear();
    typedef std::pair<double, double> UV;
    for (const Portal& P : gP){
        auto W = [&](double u, double v, double w, double* o){ o[0] = P.x - P.bz * u + P.bx * w; o[1] = P.y0 + v; o[2] = P.z + P.bx * u + P.bz * w; };
        auto groundV = [&](double u, double w){ double q[3]; W(u, 0, w, q); return Terrain::meshH(q[0], q[2]) - P.y0; };
        // triangle with a flat normal turned away from (away = true) or towards (false) the reference point (ru, rv, rw)
        auto tri = [&](int part, const double* a, const double* b, const double* c, const double* ref, bool away){
            double e1[3] = {b[0]-a[0], b[1]-a[1], b[2]-a[2]}, e2[3] = {c[0]-a[0], c[1]-a[1], c[2]-a[2]};
            double nx = e1[1]*e2[2] - e1[2]*e2[1], ny = e1[2]*e2[0] - e1[0]*e2[2], nz = e1[0]*e2[1] - e1[1]*e2[0];
            const double l = std::sqrt(nx*nx + ny*ny + nz*nz); if (l < 1e-9) return; nx /= l; ny /= l; nz /= l;
            const double d = nx*(a[0]-ref[0]) + ny*(a[1]-ref[1]) + nz*(a[2]-ref[2]); if ((d < 0) == away){ nx = -nx; ny = -ny; nz = -nz; }
            for (const double* q : {a, b, c}){ out[part].push_back((float)q[0]); out[part].push_back((float)q[1]); out[part].push_back((float)q[2]); out[part].push_back((float)nx); out[part].push_back((float)ny); out[part].push_back((float)nz); }
        };
        auto quad = [&](int part, const double* a, const double* b, const double* c, const double* d, const double* ref, bool away){ tri(part, a, b, c, ref, away); tri(part, a, c, d, ref, away); };
        // arch outline: left wall up, half circle over the top, right wall down (same point count for every radius -> matching rings)
        auto outline = [&](double r, double vbL, double vbR){
            std::vector<UV> o; const int ns = 3, na = 14;
            for (int i = 0; i < ns; i++) o.push_back({-r, vbL + (SIDE_H - vbL) * i / ns});
            for (int k = 0; k <= na; k++){ const double th = M_PI * (1.0 - (double)k / na); o.push_back({r * std::cos(th), SIDE_H + r * std::sin(th)}); }
            for (int i = 1; i <= ns; i++) o.push_back({r, SIDE_H + (vbR - SIDE_H) * i / ns});
            return o;
        };
        const double RO = ARCH_R + WALL_T, FLOOR = 0.14;
        const std::vector<UV> in = outline(ARCH_R, FLOOR - 0.02, FLOOR - 0.02);
        const std::vector<UV> outr = outline(RO, groundV(-RO, 0) - 0.4, groundV(RO, 0) - 0.4);
        const size_t N = in.size();
        const double inside[3] = {0, 3, 14}, axisFront[3] = {0, SIDE_H, 0}, axisTube[3] = {0, SIDE_H, DEPTH * 0.5};
        double a[3], b[3], c[3], d[3];
        // 1) concrete frame: front ring (0.5 m proud of the mound), rim between ring and mound, reveal inside the opening
        for (size_t i = 0; i + 1 < N; i++){
            W(in[i].first, in[i].second, -0.5, a);   W(in[i+1].first, in[i+1].second, -0.5, b);
            W(outr[i+1].first, outr[i+1].second, -0.5, c); W(outr[i].first, outr[i].second, -0.5, d);
            quad(PART_FRAME, a, b, c, d, inside, true);
            W(outr[i].first, outr[i].second, 0, a); W(outr[i+1].first, outr[i+1].second, 0, b);
            quad(PART_FRAME, d, c, b, a, inside, true);
            double e[3], f[3]; W(in[i].first, in[i].second, 0, e); W(in[i+1].first, in[i+1].second, 0, f);
            double g[3], h[3]; W(in[i].first, in[i].second, -0.5, g); W(in[i+1].first, in[i+1].second, -0.5, h);
            quad(PART_FRAME, g, h, f, e, axisFront, false);
        }
        // 2) earth mound: from the outer ring back to the ground, spreading sideways like a hillside
        std::vector<std::vector<double>> back(N, std::vector<double>(3));
        for (size_t i = 0; i < N; i++){ const double ub = outr[i].first * MOUND_SPREAD; double q[3]; W(ub, groundV(ub, MOUND_L) - 0.5, MOUND_L, q); back[i] = {q[0], q[1], q[2]}; }
        for (size_t i = 0; i + 1 < N; i++){
            W(outr[i].first, outr[i].second, 0, a); W(outr[i+1].first, outr[i+1].second, 0, b);
            quad(PART_MOUND, a, b, back[i+1].data(), back[i].data(), inside, true);
        }
        // 3) dark tunnel: inner walls + black back wall
        for (size_t i = 0; i + 1 < N; i++){
            W(in[i].first, in[i].second, 0, a); W(in[i+1].first, in[i+1].second, 0, b); W(in[i+1].first, in[i+1].second, DEPTH, c); W(in[i].first, in[i].second, DEPTH, d);
            quad(PART_DARK, a, b, c, d, axisTube, false);
            double ctr[3]; W(0, SIDE_H, DEPTH, ctr); tri(PART_DARK, ctr, c, d, axisFront, false);
        }
        { double ctr[3], l0[3], l1[3]; W(0, SIDE_H, DEPTH, ctr); W(in[N-1].first, in[N-1].second, DEPTH, l0); W(in[0].first, in[0].second, DEPTH, l1); tri(PART_DARK, ctr, l0, l1, axisFront, false); }
        // 4) the track carries on into the tunnel: dirt floor
        W(-ARCH_R, FLOOR + 0.01, -3.0, a); W(ARCH_R, FLOOR + 0.01, -3.0, b); W(ARCH_R, FLOOR + 0.01, DEPTH, c); W(-ARCH_R, FLOOR + 0.01, DEPTH, d);
        { const double up[3] = {0, 50, 0}; quad(PART_FLOOR, a, b, c, d, up, false); }
    }

    // ROAD TUNNEL tubes: lining + a concrete ring at both portals
    for (const RSeg& s : gSeg){
        const int n = (int)(s.p.size() / 4); if (n < 2) continue; const int na = 12;
        std::vector<std::pair<double,double>> prof;                     // (lateral, height): left wall, half circle roof, right wall
        prof.push_back({-TUN_R, 0.0}); prof.push_back({-TUN_R, TUN_SIDE * 0.5});
        for (int k = 0; k <= na; k++){ const double th = M_PI * (1.0 - (double)k / na); prof.push_back({TUN_R * std::cos(th), TUN_SIDE + TUN_R * std::sin(th)}); }
        prof.push_back({TUN_R, TUN_SIDE * 0.5}); prof.push_back({TUN_R, 0.0});
        auto P3 = [&](int i, double lat, double h, double* o, double grow){ const float x = s.p[i*4], z = s.p[i*4+1], tx = s.p[i*4+2], tz = s.p[i*4+3]; o[0] = x - tz * lat; o[1] = 0.06 + h; o[2] = z + tx * lat; (void)grow; };
        auto push = [&](int part, const double* a, const double* b, const double* c, double nx, double ny, double nz){ for (const double* q : {a, b, c}){ out[part].push_back((float)q[0]); out[part].push_back((float)q[1]); out[part].push_back((float)q[2]); out[part].push_back((float)nx); out[part].push_back((float)ny); out[part].push_back((float)nz); } };
        for (int i = 0; i + 1 < n; i++) for (size_t j = 0; j + 1 < prof.size(); j++){
            double a[3], b[3], c[3], d[3]; P3(i, prof[j].first, prof[j].second, a, 0); P3(i, prof[j+1].first, prof[j+1].second, b, 0); P3(i+1, prof[j+1].first, prof[j+1].second, c, 0); P3(i+1, prof[j].first, prof[j].second, d, 0);
            const double mx = (prof[j].first + prof[j+1].first) * 0.5, my = (prof[j].second + prof[j+1].second) * 0.5 - TUN_SIDE; double nl = std::hypot(mx, my); if (nl < 1e-6) nl = 1;
            const double lx = -mx / nl, ly = -my / nl; const double tx = s.p[i*4+2], tz = s.p[i*4+3];                 // normal points to the tunnel axis
            const double nx = -tz * lx, nz = tx * lx;
            push(PART_LINING, a, b, c, nx, ly, nz); push(PART_LINING, a, c, d, nx, ly, nz);
        }

        // lamps: a ceiling light every 10 m + a continuous warm light strip along both walls
        for (int i = 0; i + 1 < n; i++){
            const bool lamp = (i % 5) < 2;
            auto quadL = [&](double l0, double h0, double l1, double h1, int i0, int i1){ double a[3], b[3], c[3], d[3]; P3(i0, l0, h0, a, 0); P3(i0, l1, h1, b, 0); P3(i1, l1, h1, c, 0); P3(i1, l0, h0, d, 0);
                push(PART_LIGHT, a, b, c, 0, -1, 0); push(PART_LIGHT, a, c, d, 0, -1, 0); };
            if (lamp) quadL(-0.9, TUN_SIDE + TUN_R - 0.12, 0.9, TUN_SIDE + TUN_R - 0.12, i, i + 1);
            for (int sd = -1; sd <= 1; sd += 2) quadL(sd * (TUN_R - 0.06), 2.0, sd * (TUN_R - 0.06), 2.3, i, i + 1);
        }
        for (int e = 0; e < 2; e++){                                       // portal rings (concrete): a band round the opening, 1.2 m proud
            const int i = e ? n - 1 : 0; const double dirx = (e ? 1 : -1) * s.p[i*4+2], dirz = (e ? 1 : -1) * s.p[i*4+3];
            for (size_t j = 0; j + 1 < prof.size(); j++){
                double a[3], b[3], c[3], d[3]; P3(i, prof[j].first, prof[j].second, a, 0); P3(i, prof[j+1].first, prof[j+1].second, b, 0);
                const double k1 = 1.9; const double r0 = std::hypot(prof[j].first, prof[j].second - TUN_SIDE), r1 = std::hypot(prof[j+1].first, prof[j+1].second - TUN_SIDE);
                P3(i, prof[j+1].first * (1 + k1 / std::max(r1, 1.0)), TUN_SIDE + (prof[j+1].second - TUN_SIDE) * (1 + k1 / std::max(r1, 1.0)), c, 0); P3(i, prof[j].first * (1 + k1 / std::max(r0, 1.0)), TUN_SIDE + (prof[j].second - TUN_SIDE) * (1 + k1 / std::max(r0, 1.0)), d, 0);
                for (double* q : {a, b, c, d}){ q[0] += dirx * 0.6; q[2] += dirz * 0.6; }
                push(PART_FRAME, a, b, c, dirx, 0, dirz); push(PART_FRAME, a, c, d, dirx, 0, dirz);
            }
        }
    }

    // FALLEN GINKGO LEAVES along the whole new road: golden leaves on the tarmac and drifts on the verges (small flat quads, 3 shades)
    {
        const Road::Curve& cv = Road::gNet.roads[Road::NEW_EDGE]; const double len = cv.length(), hw = cv.hw; uint32_t rs = 0x9e3779b9u;
        auto R = [&]{ rs = rs * 1664525u + 1013904223u; return (rs >> 8) / 16777216.0; };
        for (double s = 8.0; s < len - 8.0; s += 1.0){
            const Road::V3 p = cv.getPointAt(s / len), tg = cv.getTangentAt(s / len); double nl = std::hypot(tg.x, tg.z); if (nl == 0) continue;
            if (inRoadTunnel(p.x, p.z) || std::fabs(River::riverSd(p.x, p.z)) < River::RIVER_WALL + 8.0) continue;
            const double nx = -tg.z / nl, nz = tg.x / nl, tx = tg.x / nl, tz = tg.z / nl;
            const int cnt = 6;
            for (int k = 0; k < cnt; k++){
                const double side = R() < 0.5 ? -1.0 : 1.0; const bool onRoad = R() < 0.30; const double r = R();
                const double u = onRoad ? r * (hw - 0.2) : hw + 0.1 + 9.0 * r * r;                 // thick near the road edge, thinning out into the grass
                const double along = (R() - 0.5) * 1.0, x = p.x + nx * u * side + tx * along, z = p.z + nz * u * side + tz * along;
                if (!onRoad && (std::fabs(River::riverSd(x, z)) < River::RIVER_WALL + 4.0 || Village::blocked(x, z, 1.0))) continue;
                const double y = onRoad ? 0.115 : Terrain::meshH(x, z) + 0.05, sz = 0.20 + 0.20 * R(), ang = R() * 6.2831853, ca = std::cos(ang), sa = std::sin(ang);
                const int part = PART_LEAF0 + (int)(R() * 2.999);
                // real ginkgo leaf: a fan (wedge) on a short stalk, wavy outer edge, a notch in the middle of the top
                double fx[8], fz[8];
                fx[0] = x; fz[0] = z;
                for (int v = 0; v <= 6; v++){
                    const double a = (-68.0 + v * 136.0 / 6.0) * M_PI / 180.0, rr = sz * (v == 3 ? 0.50 : ((v == 0 || v == 6) ? 0.88 : 1.0 - 0.08 * (v & 1)));
                    const double lx = rr * std::sin(a), lz = rr * std::cos(a);
                    fx[v + 1] = x + ca * lz - sa * lx; fz[v + 1] = z + sa * lz + ca * lx;
                }
                for (int v = 1; v <= 6; v++){
                    const double px[3] = {fx[0], fx[v], fx[v + 1]}, pz[3] = {fz[0], fz[v], fz[v + 1]};
                    for (int w = 0; w < 3; w++){ out[part].push_back((float)px[w]); out[part].push_back((float)y); out[part].push_back((float)pz[w]); out[part].push_back(0.f); out[part].push_back(1.f); out[part].push_back(0.f); }
                }
            }
        }
    }
}

} // namespace Tunnel
