// Sunny Drift - butterflies on the wildflowers.
// A small pool of butterflies lives round the camera. Each one is bound to a real flower of the meadow (MeadowGL::gFl): it hovers and rests on it with slow wing beats,
// then flits to another flower nearby (wobbling path, fast wing beats). A car that comes close startles them: they flutter up and away.
// All geometry is made in the vertex shader (5 quads per butterfly: 2 fore wings, 2 hind wings, body); the wing shape, veins and colours are drawn in the fragment shader.
#pragma once
#include <GLES3/gl3.h>
#include <cmath>
#include <algorithm>
#include <vector>
#include "sun_light.h"
#include "meadow_render.h"
#include "quality.h"

namespace ButterflyGL {

static const char* BF_VS = R"GLSL(#version 300 es
layout(location=0) in vec4 iA;   // x, y, z, heading
layout(location=1) in vec4 iB;   // wing angle, type, size, seed
uniform mat4 uVP;
out vec2 vq; flat out vec4 vInfo; out vec3 vNt; out vec3 wp;
const vec2 C[6] = vec2[6](vec2(0.,0.), vec2(1.,0.), vec2(0.,1.), vec2(1.,0.), vec2(1.,1.), vec2(0.,1.));
void main(){
  int quad = gl_VertexID / 6; vec2 c = C[gl_VertexID % 6];
  float h = iA.w; vec3 F = vec3(cos(h), 0., sin(h)); vec3 U = vec3(0., 1., 0.); vec3 S = cross(F, U);
  float a = iB.x, size = iB.z; vec3 pos; vec3 Nt = U;
  if (quad == 4){                                                // body: a thin strip along the flight direction
    float s = mix(-0.40, 0.30, c.y) * size, w = (c.x - 0.5) * 0.075 * size;
    pos = iA.xyz + F * s + S * w;
  } else {
    float sg = (quad == 0 || quad == 1) ? 1.0 : -1.0; bool fore = (quad == 0 || quad == 2);
    vec3 Wd = S * sg * cos(a) + U * sin(a);                      // the wing hinges on the body and swings up / down by angle a
    float w = c.x * (fore ? 0.50 : 0.40) * size;
    float s0 = fore ? -0.02 : -0.46, s1 = fore ? 0.46 : -0.02;
    float s = mix(s0, s1, c.y) * size;
    pos = iA.xyz + F * s + Wd * w;
    Nt = sg * normalize(cross(Wd, F));                           // normal of the upper side of this wing
  }
  vq = c; vInfo = vec4(float(quad), iB.y, iB.w, size); vNt = Nt; wp = pos;
  gl_Position = uVP * vec4(pos, 1.0);
}
)GLSL";

static const char* BF_FS = R"GLSL(#version 300 es
precision highp float;
in vec2 vq; flat in vec4 vInfo; in vec3 vNt; in vec3 wp; uniform vec3 uCam; out vec4 o;
void main(){
  float quad = vInfo.x, type = vInfo.y, seed = vInfo.z;
  vec3 V = uCam - wp; float dist = length(V); V /= dist;
  vec3 N = normalize(vNt); bool top = dot(N, V) > 0.0; if (!top) N = -N;
  float u = vq.x, v = vq.y; vec3 col;
  if (quad > 3.5){                                               // body: dark, thicker at the thorax
    float e = abs(u - 0.5) * 2.0; float prof = v < 0.30 ? 0.55 : (v < 0.62 ? 0.95 : 0.50);
    if (e > prof) discard;
    col = vec3(0.07, 0.05, 0.04) * (0.8 + 0.5 * v);
  } else {
    bool fore = quad < 0.5 || (quad > 1.5 && quad < 2.5); float edge, vein;
    if (fore){
      float vt = 1.0 - 0.16 * u * u, vl = 0.06 + 0.74 * pow(u, 2.2) + 0.015 * sin(u * 28.0);
      if (v > vt || v < vl) discard;
      edge = 1.0 - smoothstep(0.0, 0.09, min(vt - v, v - vl));
    } else {
      vec2 p = vec2(u, (v - 0.55) / 0.55); float r = length(p), an = atan(p.y, p.x); float R = 1.0 + 0.05 * sin(an * 8.0 + seed * 6.0);
      if (r > R) discard;
      edge = 1.0 - smoothstep(0.0, 0.14, R - r);
    }
    float va = atan(v - 0.5, u + 0.06) * 2.2282; vein = 1.0 - smoothstep(0.0, 0.09, abs(fract(va) - 0.5));
    vec3 base; vec3 rim = vec3(0.07, 0.06, 0.06); float rimK = edge * 0.9;
    if (type < 0.5){                                             // cabbage white: white, grey-black wing tips and a dark spot
      base = vec3(0.96, 0.96, 0.92); if (fore){ float tip = smoothstep(0.62, 0.95, u) * smoothstep(0.50, 0.85, v); base = mix(base, vec3(0.12), tip); base = mix(base, vec3(0.15), smoothstep(0.10, 0.0, length(vec2(u - 0.55, v - 0.55)))*0.8); }
      rimK = edge * 0.25;
    } else if (type < 1.5){                                      // brimstone: lemon yellow, small orange dot
      base = vec3(0.96, 0.88, 0.20); base = mix(base, vec3(0.95, 0.50, 0.10), smoothstep(0.07, 0.0, length(vec2(u - 0.50, v - 0.55))));
      rim = vec3(0.55, 0.45, 0.10); rimK = edge * 0.4;
    } else if (type < 2.5){                                      // common blue: blue upper side, white fringe
      base = vec3(0.30, 0.46, 0.93); base = mix(base, vec3(0.62, 0.74, 1.0), 0.35 * (1.0 - u)); rim = vec3(0.10, 0.10, 0.20); rimK = edge * 0.55;
      if (edge > 0.85) base = mix(base, vec3(0.95), 0.6);
    } else if (type < 3.5){                                      // orange (monarch-like): orange, thick black veins and border with white dots
      base = vec3(0.98, 0.52, 0.10); base = mix(base, vec3(0.05), vein * 0.85); rimK = edge;
      float dots = step(0.82, fract(u * 9.0 + v * 4.0)) * step(0.35, edge) * step(edge, 0.8); base = mix(base, vec3(0.97), dots);
    } else if (type < 4.5){                                      // swallowtail: pale yellow with black bands
      base = vec3(0.97, 0.88, 0.38); float band = step(0.74, fract(u * 3.0 + v * 0.6)) * 0.85;
      base = mix(base, vec3(0.06), band); rimK = edge;
    } else {                                                     // peacock: rust red with an eyespot at the tip
      base = vec3(0.62, 0.13, 0.07); float d = length(vec2((u - 0.72) * 1.0, (v - 0.66) * 1.2));
      base = mix(base, vec3(0.95, 0.80, 0.30), smoothstep(0.17, 0.15, d)); base = mix(base, vec3(0.12, 0.20, 0.65), smoothstep(0.12, 0.10, d)); base = mix(base, vec3(0.03), smoothstep(0.06, 0.04, d));
      rim = vec3(0.08, 0.06, 0.07); rimK = edge * 0.8;
    }
    col = mix(base, rim, clamp(rimK, 0.0, 1.0)); col *= 1.0 - 0.16 * vein;
    if (!top){                                                   // underside seen from below: duller, brownish
      float duller = (type > 1.5 && type < 2.5) || type > 4.5 ? 0.55 : 0.12; col = mix(col, vec3(0.52, 0.45, 0.32) * dot(col, vec3(0.5)) * 1.4, duller);
    }
  }
  vec3 L = SUNL;
  float d = max(dot(N, L), 0.0); float trans = pow(max(dot(-V, L), 0.0), 2.0) * 0.30;                 // thin wings glow when the sun is behind them
  col *= 0.62 + 0.45 * d + trans;
  col = mix(col, vec3(0.72, 0.87, 0.98), clamp(dist / 2850.0, 0.0, 1.0));
  o = vec4(col, 1.0);
}
)GLSL";

struct Bf {
    float x = 0, y = 0, z = 0, bx = 0, bz = 0;            // drawn position; bx/bz = path position without the wobble
    float tx = 0, ty = 0, tz = 0;                         // flower being visited (ty = hover height above it)
    float heading = 0, phase = 0, t = 0, age = 0, size = 0.25f, seed = 0, speed = 2.f, fvx = 0, fvz = 0;
    int state = -1, type = 0;                             // -1 = free slot, 0 = flying to a flower, 1 = resting on a flower, 2 = startled
    bool alive = false;
};

static GLuint gProg = 0, gVAO = 0, gVBO = 0; static GLint uVP = -1, uCam = -1; static bool gOk = false;
static std::vector<Bf> gB; static std::vector<float> gInst; static double gLast = 0; static unsigned gRs = 0x9e3779b9u;
static inline float rnd(){ gRs ^= gRs << 13; gRs ^= gRs >> 17; gRs ^= gRs << 5; return (gRs >> 8) / 16777216.f; }
static inline float sstep(float a, float b, float x){ x = std::min(1.f, std::max(0.f, (x - a) / (b - a))); return x * x * (3.f - 2.f * x); }

static void init(){
    GLuint v = glCreateShader(GL_VERTEX_SHADER), f = glCreateShader(GL_FRAGMENT_SHADER);
    SunLight::shaderSource(v, BF_VS); glCompileShader(v); SunLight::shaderSource(f, BF_FS); glCompileShader(f);
    gProg = glCreateProgram(); glAttachShader(gProg, v); glAttachShader(gProg, f); glLinkProgram(gProg);
    GLint ok = 0; glGetProgramiv(gProg, GL_LINK_STATUS, &ok); if (!ok) return;
    SunLight::attach(gProg);
    uVP = glGetUniformLocation(gProg, "uVP"); uCam = glGetUniformLocation(gProg, "uCam");
    glGenVertexArrays(1, &gVAO); glBindVertexArray(gVAO); glGenBuffers(1, &gVBO); glBindBuffer(GL_ARRAY_BUFFER, gVBO);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 32, (void*)0); glVertexAttribDivisor(0, 1);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 32, (void*)16); glVertexAttribDivisor(1, 1);
    glBindVertexArray(0); gOk = true;
}

// a random flower near (x, z), between minD and maxD metres away. The flower layer is a ring buffer: the cell (cx, cz) lives in slot (cz mod N) * N + (cx mod N).
static bool flowerNear(float x, float z, float rangeM, float minD, float maxD, float& fx, float& fy, float& fz){
    const MeadowGL::Layer& L = MeadowGL::gFl; if (!L.ok) return false;
    const long ccx = (long)std::floor(x / L.S), ccz = (long)std::floor(z / L.S); const int rc = (int)(rangeM / L.S);
    for (int k = 0; k < 18; k++){
        const long cx = ccx + (long)(rnd() * (2 * rc + 1)) - rc, cz = ccz + (long)(rnd() * (2 * rc + 1)) - rc;
        const size_t s = (size_t)((((cz % L.N) + L.N) % L.N) * L.N + (((cx % L.N) + L.N) % L.N));
        if (L.kx[s] != cx || L.kz[s] != cz) continue;
        const float* d = &L.data[s * 8]; if (d[3] < 0.3f) continue;
        const float dx = d[0] - x, dz = d[2] - z, q = dx * dx + dz * dz; if (q < minD * minD || q > maxD * maxD) continue;
        fx = d[0]; fy = d[1] + 0.40f; fz = d[2]; return true;
    }
    return false;
}

static void pickNext(Bf& b){                                        // fly to another flower close by, or stay where we are
    float fx, fy, fz;
    if (flowerNear(b.tx, b.tz, 12.f, 2.5f, 12.f, fx, fy, fz)){ b.tx = fx; b.ty = fy; b.tz = fz; b.state = 0; b.speed = 1.3f + 1.4f * rnd(); b.t = 0; }
    else b.t = 2.f + 3.f * rnd();
}

static void spawn(Bf& b, const float* eye){
    for (int k = 0; k < 4; k++){
        const float a = rnd() * 6.2831853f, r = 7.f + 48.f * rnd(), px = eye[0] + std::cos(a) * r, pz = eye[2] + std::sin(a) * r; float fx, fy, fz;
        if (!flowerNear(px, pz, 6.f, 0.f, 9.f, fx, fy, fz)) continue;
        b = Bf(); b.alive = true; b.state = 1; b.tx = b.x = b.bx = fx; b.ty = b.y = fy; b.tz = b.z = b.bz = fz; b.heading = rnd() * 6.2831853f; b.phase = rnd() * 6.28f;
        b.t = 0.5f + 5.f * rnd(); b.size = 0.22f + 0.14f * rnd(); b.seed = rnd(); b.type = (int)(rnd() * 5.99f); b.age = 0.f; return;
    }
}

static void step(Bf& b, float dt, const float* eye, const float* car){
    b.age += dt; b.t -= dt;
    const float cdx = b.x - car[0], cdz = b.z - car[2], cd = std::sqrt(cdx * cdx + cdz * cdz);
    if (b.state != 2 && cd < 6.5f){                                  // the car comes close: flutter up and away
        b.state = 2; b.t = 1.4f + 0.6f * rnd(); const float l = std::max(cd, 0.3f); b.fvx = cdx / l * (3.0f + 1.5f * rnd()) + (rnd() - 0.5f) * 2.f; b.fvz = cdz / l * (3.0f + 1.5f * rnd()) + (rnd() - 0.5f) * 2.f;
    }
    if (b.state == 1){                                               // resting on / hovering at a flower: slow wing beats, small drift
        b.phase += dt * (3.2f + 1.5f * std::sin(b.seed * 40.f + b.age * 0.7f));
        b.bx += (b.tx - b.bx) * std::min(1.f, dt * 3.f); b.bz += (b.tz - b.bz) * std::min(1.f, dt * 3.f);
        b.x = b.bx + 0.03f * std::sin(b.age * 1.3f + b.seed * 9.f); b.z = b.bz + 0.03f * std::cos(b.age * 1.1f + b.seed * 5.f);
        b.y += (b.ty + 0.03f * std::sin(b.age * 2.0f) - b.y) * std::min(1.f, dt * 5.f);
        b.heading += 0.25f * std::sin(b.age * 0.6f + b.seed * 20.f) * dt;
        if (b.t <= 0.f) pickNext(b);
    } else if (b.state == 0){                                        // flitting to the next flower: quick wing beats, wobbling path
        b.phase += dt * (13.f + 3.f * std::sin(b.age * 3.f + b.seed * 10.f));
        const float dx = b.tx - b.bx, dz = b.tz - b.bz, dist = std::sqrt(dx * dx + dz * dz);
        const float sp = b.speed * (0.65f + 0.35f * sstep(0.f, 1.5f, dist)) * (1.f + 0.35f * std::sin(b.age * 5.f + b.seed * 12.f));   // flaps in bursts
        if (dist > 0.12f){ b.bx += dx / dist * sp * dt; b.bz += dz / dist * sp * dt; const float want = std::atan2(dz, dx); float dh = want - b.heading; while (dh > 3.14159f) dh -= 6.2831853f; while (dh < -3.14159f) dh += 6.2831853f; b.heading += dh * std::min(1.f, dt * 5.f); }
        else { b.state = 1; b.t = 3.f + 5.f * rnd(); }
        const float wob = std::min(1.f, dist / 2.5f), px = -dz / std::max(dist, 0.01f), pz = dx / std::max(dist, 0.01f), side = std::sin(b.age * 2.3f + b.seed * 17.f) * 0.45f * wob;
        b.x = b.bx + px * side; b.z = b.bz + pz * side;
        const float ty = b.ty + 0.25f + 0.55f * wob + 0.18f * std::sin(b.age * 8.f + b.seed * 3.f);   // rise on the way, bob with the wing beats, settle down on arrival
        b.y += (ty - b.y) * std::min(1.f, dt * 3.f);
    } else {                                                         // startled by the car
        b.phase += dt * 17.f;
        b.bx += b.fvx * dt; b.bz += b.fvz * dt; b.x = b.bx; b.z = b.bz; b.y += (1.8f + 0.9f * std::sin(b.age * 6.f) - 0.f) * dt * 1.2f;
        b.heading = std::atan2(b.fvz, b.fvx);
        if (b.t <= 0.f){ b.tx = b.bx; b.tz = b.bz; float fx, fy, fz; if (flowerNear(b.bx, b.bz, 12.f, 3.f, 14.f, fx, fy, fz)){ b.tx = fx; b.ty = fy; b.tz = fz; b.state = 0; b.speed = 2.2f; } else b.alive = false; }
    }
    const float ex = b.x - eye[0], ez = b.z - eye[2];
    if (ex * ex + ez * ez > 90.f * 90.f) b.alive = false;           // too far: this slot respawns near the camera
}

// call once per frame after MeadowGL::draw (opaque, depth-tested). night = NightGL::night (0..1), level = Quality::level
static void draw(const float* VP, const float* eye, const float* car, double tSec, float night, int level){
    if (!gOk || Quality::flat || Quality::grassOff) return;
    const int want = night > 0.35f ? 0 : (level >= 2 ? 44 : (level == 1 ? 28 : 12));              // none at night, fewer on Low graphics
    if ((int)gB.size() != want) gB.resize(want);
    float dt = (float)(tSec - gLast); gLast = tSec; if (dt <= 0.f || dt > 0.25f) dt = 0.016f;
    int spawnBudget = 2;
    for (Bf& b : gB){
        if (!b.alive){ if (spawnBudget > 0){ spawn(b, eye); spawnBudget--; } if (!b.alive) continue; }
        step(b, dt, eye, car);
    }
    gInst.clear();
    for (const Bf& b : gB){
        if (!b.alive) continue;
        const float grow = sstep(0.f, 1.2f, b.age);                                                  // fade in by growing: no popping
        const float rest = b.state == 1 ? 1.f : 0.f;
        const float ang = rest > 0.5f ? 0.85f + 0.55f * std::sin(b.phase) : 0.40f + 0.95f * std::sin(b.phase);   // resting: wings open and close slowly; flying: big quick beats
        const float row[8] = {b.x, b.y, b.z, b.heading, ang, (float)b.type, b.size * grow, b.seed}; gInst.insert(gInst.end(), row, row + 8);
    }
    const int cnt = (int)(gInst.size() / 8); if (!cnt) return;
    glEnable(GL_DEPTH_TEST); glDepthMask(GL_TRUE); glDisable(GL_BLEND); glDisable(GL_CULL_FACE);
    glUseProgram(gProg); glUniformMatrix4fv(uVP, 1, GL_FALSE, VP); glUniform3fv(uCam, 1, eye);
    glBindVertexArray(gVAO); glBindBuffer(GL_ARRAY_BUFFER, gVBO); glBufferData(GL_ARRAY_BUFFER, gInst.size() * 4, gInst.data(), GL_STREAM_DRAW);
    glDrawArraysInstanced(GL_TRIANGLES, 0, 30, cnt);
    glBindVertexArray(0);
}

} // namespace ButterflyGL
