// CI entry point (GitHub Actions / game-ci):  buildMethod = CiBuild.Build
// Works on a bare project that only has Assets/: creates the URP asset + a scene if missing, applies settings, builds an Android APK.
using System;
using System.IO;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

public static class CiBuild {
    public static void Build() {
        EnsureUrpAsset();
        string scene = EnsureScene();
        URPSetup.Apply(true);

        PlayerSettings.productName = "Sunny Drift Car"; PlayerSettings.companyName = "SunnyDrift";
        PlayerSettings.SetApplicationIdentifier(NamedBuildTarget.Android, "com.sunnydrift.car");
        PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel24;
        PlayerSettings.Android.bundleVersionCode = Mathf.Max(1, GetInt("-versionCode", 1));
        PlayerSettings.bundleVersion = GetArg("-versionName", "1.0");
        EditorUserBuildSettings.buildAppBundle = false;
        EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android);

        string path = GetArg("-customBuildPath", "build/Android/SunnyDriftCar.apk");
        if (!path.EndsWith(".apk", StringComparison.OrdinalIgnoreCase)) path += ".apk";
        Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path)));

        var rep = BuildPipeline.BuildPlayer(new BuildPlayerOptions { scenes = new[] { scene }, locationPathName = path, target = BuildTarget.Android, options = BuildOptions.None });
        Debug.Log("[CiBuild] result: " + rep.summary.result + "  size: " + rep.summary.totalSize + "  -> " + path);
        EditorApplication.Exit(rep.summary.result == BuildResult.Succeeded ? 0 : 1);
    }

    static void EnsureUrpAsset() {
        if (GraphicsSettings.defaultRenderPipeline == null) {
            if (!AssetDatabase.IsValidFolder("Assets/Settings")) AssetDatabase.CreateFolder("Assets", "Settings");
            var rd = ScriptableObject.CreateInstance<UniversalRendererData>();
            AssetDatabase.CreateAsset(rd, "Assets/Settings/URP_Renderer.asset");
            var asset = UniversalRenderPipelineAsset.Create(rd);
            AssetDatabase.CreateAsset(asset, "Assets/Settings/URP_Asset.asset");
            AssetDatabase.SaveAssets();
            GraphicsSettings.defaultRenderPipeline = asset;
            for (int i = 0; i < QualitySettings.names.Length; i++) { QualitySettings.SetQualityLevel(i, false); QualitySettings.renderPipeline = asset; }
            AssetDatabase.SaveAssets();
            Debug.Log("[CiBuild] created URP asset");
        }
    }

    static string EnsureScene() {   // the game builds itself at runtime (RuntimeInitializeOnLoadMethod), so an empty scene is enough
        const string p = "Assets/Scenes/Main.unity";
        if (!AssetDatabase.IsValidFolder("Assets/Scenes")) AssetDatabase.CreateFolder("Assets", "Scenes");
        if (!File.Exists(p)) EditorSceneManager.SaveScene(EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single), p);
        return p;
    }

    static string GetArg(string name, string def) { var a = Environment.GetCommandLineArgs(); for (int i = 0; i < a.Length - 1; i++) if (a[i] == name) return a[i + 1]; return def; }
    static int GetInt(string name, int def) { int v; return int.TryParse(GetArg(name, ""), out v) ? v : def; }
}
