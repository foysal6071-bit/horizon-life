// Sunny Drift - one-click URP setup (Editor only). Runs automatically once after import, or via menu: Sunny Drift > Apply URP Settings.
// - checks that a URP asset is active
// - tunes the active URP asset (cascaded soft shadows, MSAA, HDR) through SerializedObject (properties that do not exist in your URP version are skipped)
// - adds "Universal Render Pipeline/Lit" to Always Included Shaders so Android/iOS/desktop builds don't lose the car materials
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

public static class URPSetup {
    const string DoneKey = "SunnyDrift.URPSetup.v3";

    [InitializeOnLoadMethod]
    static void Auto() { if (SessionState.GetBool(DoneKey, false)) return; SessionState.SetBool(DoneKey, true); EditorApplication.delayCall += () => Apply(false); }

    [MenuItem("Sunny Drift/Apply URP Settings")]
    static void Menu() { Apply(true); }

    public static void Apply(bool verbose) {
        var rp = QualitySettings.renderPipeline != null ? QualitySettings.renderPipeline : GraphicsSettings.defaultRenderPipeline;
        if (rp == null) {
            Debug.LogWarning("[SunnyDrift] No URP asset is assigned. Create one: Assets > Create > Rendering > URP Asset (with Universal Renderer), " +
                             "then assign it in Project Settings > Graphics (and Quality). Easiest: start from the '3D (URP)' template.");
            return;
        }
        var so = new SerializedObject(rp); bool changed = false;
        changed |= Set(so, "m_MainLightShadowsSupported", true);
        changed |= Set(so, "m_MainLightShadowmapResolution", 2048);
        changed |= Set(so, "m_ShadowDistance", 150f);
        changed |= Set(so, "m_ShadowCascadeCount", 3);
        changed |= Set(so, "m_Cascade3Split", 0.25f);
        changed |= Set(so, "m_SoftShadowsSupported", true);
        changed |= Set(so, "m_SupportsHDR", true);
        changed |= Set(so, "m_MSAA", 2);
        if (changed) { so.ApplyModifiedProperties(); EditorUtility.SetDirty(rp); AssetDatabase.SaveAssets(); }

        bool added = IncludeShader("Universal Render Pipeline/Lit");
        if (verbose || changed || added) Debug.Log("[SunnyDrift] URP settings applied to '" + rp.name + "' (shadows 2048 / 3 cascades / soft, MSAA 2x, HDR). Lit shader always-included: " + (added ? "added" : "already present") + ".");
    }

    static bool Set(SerializedObject so, string name, object v) {
        var p = so.FindProperty(name); if (p == null) return false;
        switch (p.propertyType) {
            case SerializedPropertyType.Boolean: if (p.boolValue == (bool)v) return false; p.boolValue = (bool)v; return true;
            case SerializedPropertyType.Integer: if (p.intValue == (int)v) return false; p.intValue = (int)v; return true;
            case SerializedPropertyType.Float: if (Mathf.Approximately(p.floatValue, (float)v)) return false; p.floatValue = (float)v; return true;
            case SerializedPropertyType.Enum: if (p.enumValueIndex == (int)v) return false; p.enumValueIndex = (int)v; return true;
        }
        return false;
    }

    static bool IncludeShader(string shaderName) {
        var sh = Shader.Find(shaderName); if (sh == null) return false;
        var gs = AssetDatabase.LoadAssetAtPath<Object>("ProjectSettings/GraphicsSettings.asset"); if (gs == null) return false;
        var so = new SerializedObject(gs); var arr = so.FindProperty("m_AlwaysIncludedShaders"); if (arr == null) return false;
        for (int i = 0; i < arr.arraySize; i++) if (arr.GetArrayElementAtIndex(i).objectReferenceValue == sh) return false;
        arr.InsertArrayElementAtIndex(arr.arraySize); arr.GetArrayElementAtIndex(arr.arraySize - 1).objectReferenceValue = sh;
        so.ApplyModifiedProperties(); AssetDatabase.SaveAssets(); return true;
    }
}
