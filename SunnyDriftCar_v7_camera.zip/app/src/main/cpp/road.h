// Sunny Drift - road network: C++ port of the HTML "Road network" block (pure C++, no OpenGL).
//  * two winding ring roads (radius 220 m / 420 m, sum-of-harmonics wobble = ringRad) + a connector road between them
//  * centre lines are three.js CatmullRomCurve3 (centripetal) with the SAME arc-length parametrisation as three.js
//    (200 divisions, getPointAt / getTangentAt), so every point lies exactly where it does in the HTML game
//  * road ribbons / sand verges are lofted along the centre line exactly like buildStrip() in the HTML
//  * roadClearance() / surfaceAt() are used by the trees and by the car's grip
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <unordered_map>
#include <vector>
#include "river.h"

namespace Road {

const double ROAD_SURF = 0.08;                        // height of the road surface
const double PI = 3.14159265358979323846;

struct V3 { double x = 0, y = 0, z = 0; };
static inline V3 vsub(const V3& a, const V3& b){ return {a.x - b.x, a.y - b.y, a.z - b.z}; }
static inline double dist2(const V3& a, const V3& b){ V3 d = vsub(a, b); return d.x*d.x + d.y*d.y + d.z*d.z; }
static inline double jsRound(double v){ return std::floor(v + 0.5); }          // JS Math.round

// ---------- three.js CatmullRomCurve3 (centripetal) ----------
struct Curve {
    std::vector<V3> pts; bool closed = true, open = false; double hw = 0;
    std::vector<double> lens;                          // cumulative arc lengths, 200 divisions (Curve.getLengths)

    static double cr(double x0, double x1, double x2, double x3, double dt0, double dt1, double dt2, double t){
        double t1 = (x1 - x0) / dt0 - (x2 - x0) / (dt0 + dt1) + (x2 - x1) / dt1;
        double t2 = (x2 - x1) / dt1 - (x3 - x1) / (dt1 + dt2) + (x3 - x2) / dt2;
        t1 *= dt1; t2 *= dt1;
        double c0 = x1, c1 = t1, c2 = -3*x1 + 3*x2 - 2*t1 - t2, c3 = 2*x1 - 2*x2 + t1 + t2;
        return c0 + c1*t + c2*t*t + c3*t*t*t;
    }
    V3 getPoint(double t) const {
        const long l = (long)pts.size();
        double p = (double)(l - (closed ? 0 : 1)) * t;
        long ip = (long)std::floor(p); double w = p - (double)ip;
        if (closed){ if (!(ip > 0)) ip += (long)(std::floor(std::fabs((double)ip) / (double)l) + 1) * l; }
        else if (w == 0 && ip == l - 1){ ip = l - 2; w = 1; }
        V3 p0, p3;
        if (closed || ip > 0) p0 = pts[(ip - 1) % l];
        else { const V3 &a = pts[0], &b = pts[1]; p0 = {2*a.x - b.x, 2*a.y - b.y, 2*a.z - b.z}; }
        const V3 p1 = pts[ip % l], p2 = pts[(ip + 1) % l];
        if (closed || ip + 2 < l) p3 = pts[(ip + 2) % l];
        else { const V3 &a = pts[l-1], &b = pts[l-2]; p3 = {2*a.x - b.x, 2*a.y - b.y, 2*a.z - b.z}; }
        double dt0 = std::pow(dist2(p0, p1), 0.25), dt1 = std::pow(dist2(p1, p2), 0.25), dt2 = std::pow(dist2(p2, p3), 0.25);
        if (dt1 < 1e-4) dt1 = 1.0;
        if (dt0 < 1e-4) dt0 = dt1;
        if (dt2 < 1e-4) dt2 = dt1;
        return { cr(p0.x, p1.x, p2.x, p3.x, dt0, dt1, dt2, w), cr(p0.y, p1.y, p2.y, p3.y, dt0, dt1, dt2, w), cr(p0.z, p1.z, p2.z, p3.z, dt0, dt1, dt2, w) };
    }
    void build(){
        const int DIV = 200; lens.assign(1, 0.0); V3 last = getPoint(0); double sum = 0;
        for (int p = 1; p <= DIV; p++){ V3 c = getPoint((double)p / DIV); sum += std::sqrt(dist2(c, last)); lens.push_back(sum); last = c; }
    }
    double length() const { return lens.back(); }
    double utoT(double u) const {                      // Curve.getUtoTmapping
        const long il = (long)lens.size(); double target = u * lens[il - 1];
        long low = 0, high = il - 1, i = 0;
        while (low <= high){
            i = low + (high - low) / 2; double cmp = lens[i] - target;
            if (cmp < 0) low = i + 1; else if (cmp > 0) high = i - 1; else { high = i; break; }
        }
        i = high < 0 ? 0 : high;
        if (lens[i] == target) return (double)i / (double)(il - 1);
        double before = lens[i], after = lens[i + 1];
        return ((double)i + (target - before) / (after - before)) / (double)(il - 1);
    }
    V3 getPointAt(double u) const { return getPoint(utoT(u)); }
    V3 getTangent(double t) const {
        const double d = 0.0001; double t1 = t - d, t2 = t + d; if (t1 < 0) t1 = 0; if (t2 > 1) t2 = 1;
        V3 a = getPoint(t1), b = getPoint(t2), v = vsub(b, a); double l = std::sqrt(v.x*v.x + v.y*v.y + v.z*v.z); if (l == 0) l = 1;
        return {v.x / l, v.y / l, v.z / l};
    }
    V3 getTangentAt(double u) const { return getTangent(utoT(u)); }
};

// ---------- winding ring radius (ringRad / RING_H in the HTML) ----------
static double ringRad(double R, double a){
    static const double A220[4] = {36, 22, 14, 6},  K220[4] = {2, 3, 5, 7};
    static const double A420[4] = {34, 24, 12, 10}, K420[4] = {3, 4, 7, 11};
    const bool inner = R < 300; const double* A = inner ? A220 : A420; const double* K = inner ? K220 : K420;
    const double S = inner ? 0.8 : 1.0, p = R * 0.013; double r = R;
    for (int i = 0; i < 4; i++) r += S * A[i] * ((i % 2) ? std::cos(K[i]*a - p*i) : std::sin(K[i]*a + p*(i + 1)));
    return r;
}
// the river angle only decides where the connector road runs (pickRiverAngle in the HTML)
static double pickRiverAngle(){
    double best = 0.4, bestScore = 1e18; const double e = 0.002;
    for (double A = 0; A < PI; A += 0.01){
        double a0 = std::atan2(std::cos(A), std::sin(A));
        double sc = std::fabs(std::sin(a0)) < 0.45 ? 1e3 : 0;
        for (double R : {220.0, 420.0}) for (double base : {a0, a0 + PI}) for (int k = -4; k <= 4; k++){
            double a = base + k * (60 / R / 4);
            double r0 = ringRad(R, a), r1 = ringRad(R, a + e), rm = ringRad(R, a - e);
            double dr = (r1 - rm) / (2*e), ddr = (r1 - 2*r0 + rm) / (e*e);
            double kappa = (r0*r0 + 2*dr*dr - r0*ddr) / std::pow(r0*r0 + dr*dr, 1.5);
            sc += 6 * (dr/R) * (dr/R) + 0.5 * (kappa*R) * (kappa*R);
        }
        if (sc < bestScore){ bestScore = sc; best = A; }
    }
    return best;
}

// ---------- strip meshes (buildStrip in the HTML). vertex = pos(3) uv(2) normal(3) ----------
struct Mesh { std::vector<float> v; std::vector<uint32_t> idx; };
struct Prof { double o, y, u; };

static void buildStrip(Mesh& m, const Curve& curve, int N, const std::vector<Prof>& prof, int vRepeat, double t0, double t1, bool closed, double vConst = -1){
    const int P = (int)prof.size(); const uint32_t base = (uint32_t)(m.v.size() / 8);
    const int nv = (N + 1) * P; std::vector<double> pos(nv * 3), nor(nv * 3, 0.0); std::vector<float> uv(nv * 2);
    for (int i = 0; i <= N; i++){
        double t = std::fmod(std::fmod(t0 + (t1 - t0) * i / N, 1.0) + 1.0, 1.0);
        V3 p = curve.getPointAt(t), tan = curve.getTangentAt(t);
        double nl = std::hypot(tan.x, tan.z); if (nl == 0) nl = 1; double ux = -tan.z / nl, uz = tan.x / nl;
        for (int j = 0; j < P; j++){
            int k = i * P + j;
            pos[k*3] = p.x + ux * prof[j].o; pos[k*3+1] = prof[j].y; pos[k*3+2] = p.z + uz * prof[j].o;
            uv[k*2] = (float)prof[j].u; uv[k*2+1] = (float)(vConst >= 0 ? vConst : (double)i / N * vRepeat);
        }
    }
    std::vector<uint32_t> idx;
    for (int i = 0; i < N; i++) for (int j = 0; j < P - 1; j++){
        uint32_t a = i*P + j, b = (i+1)*P + j; uint32_t t[6] = {a, b, a+1, a+1, b, b+1};
        idx.insert(idx.end(), t, t + 6);
    }
    for (size_t f = 0; f < idx.size(); f += 3){                                    // computeVertexNormals
        const double *A = &pos[idx[f]*3], *B = &pos[idx[f+1]*3], *C = &pos[idx[f+2]*3];
        double cb[3] = {C[0]-B[0], C[1]-B[1], C[2]-B[2]}, ab[3] = {A[0]-B[0], A[1]-B[1], A[2]-B[2]};
        double n[3] = {cb[1]*ab[2] - cb[2]*ab[1], cb[2]*ab[0] - cb[0]*ab[2], cb[0]*ab[1] - cb[1]*ab[0]};
        for (int q = 0; q < 3; q++) for (int c = 0; c < 3; c++) nor[idx[f+q]*3 + c] += n[c];
    }
    for (int j = 0; closed && j < P; j++){                                          // seamless shading where the loop closes
        int a = j, b = N*P + j;
        for (int c = 0; c < 3; c++){ double s = nor[a*3+c] + nor[b*3+c]; nor[a*3+c] = nor[b*3+c] = s; }
    }
    for (int k = 0; k < nv; k++){
        double l = std::sqrt(nor[k*3]*nor[k*3] + nor[k*3+1]*nor[k*3+1] + nor[k*3+2]*nor[k*3+2]); if (l == 0) l = 1;
        double s = nor[k*3+1] < 0 ? -1.0 : 1.0;                                     // always face up
        for (int c = 0; c < 3; c++) nor[k*3+c] = nor[k*3+c] / l * s;
        float row[8] = {(float)pos[k*3], (float)pos[k*3+1], (float)pos[k*3+2], uv[k*2], uv[k*2+1], (float)nor[k*3], (float)nor[k*3+1], (float)nor[k*3+2]};
        m.v.insert(m.v.end(), row, row + 8);
    }
    for (uint32_t i : idx) m.idx.push_back(base + i);
}

// ---------- the network ----------
struct Net {
    Curve A, B, C; double riverAng = 0;
    Mesh road, roadC, verge, vergeC, trk, trkV;                         // ring roads / connector road / ring verges / connector verges; trk / trkV = dirt track + its verges (filled by Terrain)
    std::unordered_map<long long, std::vector<float>> grid;  // road centre samples (x, z, halfwidth) per 24 m cell
    bool ready = false;
};
static Net gNet;
static const int RG = 24;
static inline long long cellKey(long cx, long cz){ return (long long)(cx + 100000) * 200003LL + (cz + 100000); }

static Curve makeRing(double radius, double width){
    Curve c; const int seg = (int)jsRound(radius * 1.6);
    for (int i = 0; i < seg; i++){ double a = (double)i / seg * PI * 2, rr = ringRad(radius, a); c.pts.push_back({std::cos(a) * rr, ROAD_SURF, std::sin(a) * rr}); }
    c.closed = true; c.hw = width / 2; c.build(); return c;
}
static void addRing(Mesh& road, Mesh& verge, const Curve& cv){
    const double len = cv.length(), hw = cv.hw; const int N = (int)std::ceil(len / 1.5);
    const int roadRep = std::max(1, (int)jsRound(len / 8)), shRep = std::max(1, (int)jsRound(len / 2.5));
    // no road / sand across the river: the bridge deck is the roadway there (same sampling as buildRoadRing() in the HTML)
    const int SS = (int)std::ceil(len / 1.2); std::vector<char> inRv;
    for (int i = 0; i < SS; i++){ V3 q = cv.getPointAt((double)i / SS); inRv.push_back(std::fabs(River::riverSd(q.x, q.z)) < River::RIVER_WALL + 5); }
    int r0 = -1; for (int i = 0; i < SS; i++) if (!inRv[i]){ r0 = i; break; }
    struct Run { double a, b; bool full; }; std::vector<Run> runs;
    if (r0 >= 0){ int i = 0; while (i < SS){ if (inRv[(r0 + i) % SS]){ i++; continue; } int j = i; while (j < SS && !inRv[(r0 + j) % SS]) j++; runs.push_back({(double)(r0 + i) / SS, (double)(r0 + j) / SS, j - i == SS}); i = j; } }
    const std::vector<Prof> ASPH = {{hw, ROAD_SURF, hw}, {-hw, ROAD_SURF, -hw}};   // asphalt: u = metres from the centre line, v = half width (lane marking shader)
    if (r0 < 0) buildStrip(road, cv, N, ASPH, roadRep, 0, 1, true, hw);
    for (const Run& r : runs){
        if (r.full) buildStrip(road, cv, N, ASPH, roadRep, 0, 1, true, hw);
        else { const double L = (r.b - r.a) * len; buildStrip(road, cv, std::max(2, (int)std::ceil(L / 1.5)), ASPH, std::max(1, (int)jsRound(L / 8)), r.a, r.b, false, hw); }
    }
    static const double SP[4][2] = {{-1.5, 0.075}, {0, 0.08}, {3.5, 0.06}, {8, 0.045}};
    for (int s : {1, -1}){
        std::vector<Prof> sh; for (auto& q : SP) sh.push_back({s * (hw + q[0]), q[1], (q[0] + 1.5) / (8 + 1.5)});
        if (s > 0) std::reverse(sh.begin(), sh.end());
        for (const Run& r : runs){
            const double L = (r.b - r.a) * len;
            if (r.full) buildStrip(verge, cv, N, sh, shRep, 0, 1, true);
            else buildStrip(verge, cv, std::max(2, (int)std::ceil(L / 1.5)), sh, std::max(1, (int)jsRound(L / 2.5)), r.a, r.b, false);
        }
    }
}

static void init(){
    Net& n = gNet; if (n.ready) return;
    River::init();
    n.A = makeRing(220, 14); n.B = makeRing(420, 15);
    n.riverAng = pickRiverAngle();
    // connector road: radial, away from the start line, gentle S-bend, T-junctions on both ring roads
    {
        auto wrap = [](double a){ return std::atan2(std::sin(a), std::cos(a)); };
        double a0 = std::atan2(std::cos(n.riverAng), std::sin(n.riverAng));
        double a = wrap(a0 + PI / 2); if (std::fabs(a) < 0.7) a = wrap(a0 - PI / 2);
        double rA = ringRad(220, a), rB = ringRad(420, a); const int K = 14;
        Curve c; c.closed = false; c.open = true; c.hw = 12.0 / 2;
        for (int i = 0; i <= K; i++){ double t = (double)i / K, r = rA + (rB - rA) * t, ang = a + 0.11 * std::sin(2*PI*t) * std::sin(PI*t); c.pts.push_back({std::cos(ang) * r, ROAD_SURF, std::sin(ang) * r}); }
        c.build(); n.C = c;
    }
    addRing(n.road, n.verge, n.A); addRing(n.road, n.verge, n.B);
    {   // connector ribbon + its verges (trimmed so the sand does not run over the ring road)
        const Curve& c = n.C; const double len = c.length(), hw = c.hw, t1 = 0.99999; const int N = (int)std::ceil(len / 1.5);
        buildStrip(n.roadC, c, N, {{hw, ROAD_SURF, hw}, {-hw, ROAD_SURF, -hw}}, std::max(1, (int)jsRound(len / 8)), 0, t1, false, hw);
        static const double SP[4][2] = {{-1.5, 0.075}, {0, 0.08}, {3.5, 0.06}, {8, 0.045}};
        const int shRep = std::max(1, (int)jsRound(len / 2.5));
        const double sT0 = std::min(0.35, n.A.hw * 1.5 / len), sT1 = 1 - std::min(0.35, n.B.hw * 1.5 / len), fS = sT1 - sT0;
        for (int sd : {1, -1}){
            std::vector<Prof> sh; for (auto& q : SP) sh.push_back({sd * (hw + q[0]), q[1], (q[0] + 1.5) / (8 + 1.5)});
            if (sd > 0) std::reverse(sh.begin(), sh.end());
            buildStrip(n.vergeC, c, std::max(2, (int)std::ceil(N * fS)), sh, std::max(1, (int)jsRound(shRep * fS)), sT0, sT1, false);
        }
    }
    // grid of centre-line samples -> distance from the nearest road EDGE
    for (const Curve* cv : {&n.A, &n.B, &n.C}){
        const int cnt = (int)std::ceil(cv->length() / 2);
        for (int i = 0; i <= cnt; i++){
            V3 p = cv->getPointAt(cv->open ? std::min((double)i / cnt, 0.99999) : (double)(i % cnt) / cnt);
            auto& l = n.grid[cellKey((long)std::floor(p.x / RG), (long)std::floor(p.z / RG))];
            l.push_back((float)p.x); l.push_back((float)p.z); l.push_back((float)cv->hw);
        }
    }
    n.ready = true;
}

// distance from the nearest road EDGE (negative = on the road)
static float clearance(float x, float z){
    long cx = (long)std::floor(x / RG), cz = (long)std::floor(z / RG); float best = 1e9f;
    for (int i = -1; i <= 1; i++) for (int j = -1; j <= 1; j++){
        auto it = gNet.grid.find(cellKey(cx + i, cz + j)); if (it == gNet.grid.end()) continue;
        const std::vector<float>& l = it->second;
        for (size_t k = 0; k < l.size(); k += 3){ float dx = x - l[k], dz = z - l[k+1], d = std::sqrt(dx*dx + dz*dz) - l[k+2]; if (d < best) best = d; }
    }
    return best;
}

// grip / drag / ride height under the tyres (surfaceAt in the HTML): tarmac-like road, softer verge, grass
struct SurfaceInfo { double mu, rr, rideY; };
static SurfaceInfo surfaceAt(float x, float z){
    double c = clearance(x, z), t = std::min(std::max((c - 0.8) / 2.2, 0.0), 1.0), g = t*t*(3 - 2*t);
    double u = std::min(std::max((c - 0.3) / 2.4, 0.0), 1.0);
    return {1.15 - 0.3 * g, 0.028 + 0.06 * g, ROAD_SURF * (1 - u*u*(3 - 2*u))};
}
// where the HTML puts the car: on roadA at the start line, facing along the road
static void startPose(double& x, double& z, double& heading){
    V3 p = gNet.A.getPointAt(0), t = gNet.A.getTangentAt(0); x = p.x; z = p.z; heading = std::atan2(t.x, t.z);
}

} // namespace Road
