// Sunny Drift - very light nature effects: a waterfall down a mountain flank (one small animated ribbon + a soft spray puff)
// and a thin, patchy layer of low cloud drifting over the valley (one flat disc, 2 texture lookups per pixel).
// Both are alpha-blended, write no depth and are drawn before the night overlay, so they darken with the rest of the picture.
#pragma once
#include "nature_plan.h"
#include "terrain_render.h"

namespace NatureFxGL {

static const char* FALL_VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in vec2 uv;
uniform mat4 uVP; uniform int uMode; uniform vec3 uBase, uRight; uniform float uSize; out vec2 vuv; out vec3 wp;
void main(){
  vec3 w = p;
  if (uMode == 1) w = uBase + uRight * (uv.x * uSize) + vec3(0.0, (uv.y * 0.5 + 0.5) * uSize * 0.55, 0.0);
  vuv = uv; wp = w; gl_Position = uVP * vec4(w, 1.0);
}
)GLSL";
static const char* FALL_FS = R"GLSL(#version 300 es
precision mediump float;
in vec2 vuv; in vec3 wp; uniform int uMode; uniform float uT; uniform vec3 uCam; out vec4 o;
float h21(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float vn(vec2 p){ vec2 i = floor(p), f = fract(p); f = f*f*(3.0 - 2.0*f); return mix(mix(h21(i), h21(i + vec2(1,0)), f.x), mix(h21(i + vec2(0,1)), h21(i + vec2(1,1)), f.x), f.y); }
void main(){
  vec3 hz = vec3(0.72, 0.87, 0.98);
  float fog = clamp(length(uCam - wp) / 2500.0, 0.0, 1.0);
  if (uMode == 1){                                            // spray at the foot: a soft, slowly breathing puff
    float r = length(vuv); float a = (1.0 - smoothstep(0.15, 1.0, r)) * (0.26 + 0.07 * sin(uT * 0.8 + vuv.x * 2.0));
    o = vec4(mix(vec3(0.96, 0.98, 1.0), hz, fog), a * (1.0 - 0.6 * fog)); return;
  }
  float c = abs(vuv.x * 2.0 - 1.0);
  float edge = 1.0 - smoothstep(0.50, 1.0, c);
  float s = 0.55 * vn(vec2(vuv.x * 7.0, vuv.y * 0.12 + uT * 2.2)) + 0.45 * vn(vec2(vuv.x * 17.0 + 3.0, vuv.y * 0.25 + uT * 3.6));   // streaks running down
  vec3 col = mix(vec3(0.62, 0.80, 0.92), vec3(1.0), smoothstep(0.30, 0.80, s));
  float a = edge * (0.40 + 0.50 * s) * smoothstep(0.0, 14.0, vuv.y) * 0.85;
  o = vec4(mix(col, hz, fog), a * (1.0 - 0.5 * fog));
}
)GLSL";
static const char* CLOUD_VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; uniform mat4 uVP; out vec3 wp;
void main(){ wp = p; gl_Position = uVP * vec4(p, 1.0); }
)GLSL";
static const char* CLOUD_FS = R"GLSL(#version 300 es
precision mediump float;
in vec3 wp; uniform vec3 uCam; uniform float uT; uniform sampler2D uFbm; out vec4 o;
void main(){
  vec2 q = wp.xz;
  float n = 0.62 * texture(uFbm, q * 0.0021 + vec2(uT * 0.0030, uT * 0.0012)).r + 0.38 * texture(uFbm, q * 0.0062 - vec2(uT * 0.0045, -uT * 0.0020)).g;
  float m = smoothstep(0.48, 0.74, n);                                   // patchy: only part of the valley is covered
  float d = length(q - uCam.xz);
  float f = smoothstep(140.0, 450.0, d) * (1.0 - smoothstep(1050.0, 1650.0, d));   // clear around the car, melts away far off
  vec3 col = vec3(0.96, 0.98, 1.0) * (0.90 + 0.10 * n);
  col = mix(col, vec3(0.72, 0.87, 0.98), clamp(d / 3000.0, 0.0, 0.5));
  o = vec4(col, m * f * 0.30);                                           // at most 30 % opaque: a light veil
}
)GLSL";

static GLuint gFallProg = 0, gCloudProg = 0, gCloudTex = 0;
static GLint uF_VP, uF_Mode, uF_Base, uF_Right, uF_Size, uF_T, uF_Cam, uC_VP, uC_Cam, uC_T, uC_Fbm;
static BridgeGL::Gpu gFall, gMist, gCloud; static float gBase[3] = {0, 0, 0}; static bool gOk = false;

// Call once with a GL context, after Terrain::init(), NatureFx::plan(), RoadGL::init() and BridgeGL::init().
static void init(){
    gFallProg = RoadGL::makeProg(FALL_VS, FALL_FS); gCloudProg = RoadGL::makeProg(CLOUD_VS, CLOUD_FS);
    uF_VP = glGetUniformLocation(gFallProg, "uVP"); uF_Mode = glGetUniformLocation(gFallProg, "uMode"); uF_Base = glGetUniformLocation(gFallProg, "uBase");
    uF_Right = glGetUniformLocation(gFallProg, "uRight"); uF_Size = glGetUniformLocation(gFallProg, "uSize"); uF_T = glGetUniformLocation(gFallProg, "uT"); uF_Cam = glGetUniformLocation(gFallProg, "uCam");
    uC_VP = glGetUniformLocation(gCloudProg, "uVP"); uC_Cam = glGetUniformLocation(gCloudProg, "uCam"); uC_T = glGetUniformLocation(gCloudProg, "uT"); uC_Fbm = glGetUniformLocation(gCloudProg, "uFbm");
    // low cloud: one flat disc 55 m above the zero level (rings 1 / 400 / 900 / 1700 m)
    {   const float R[4] = {1.f, 400.f, 900.f, 1700.f}; const int NS = 48; std::vector<float> v; std::vector<uint32_t> idx;
        for (int i = 0; i < 4; i++) for (int j = 0; j < NS; j++){ const float a = (float)j / NS * 6.2831853f; v.push_back(std::cos(a) * R[i]); v.push_back(55.f); v.push_back(std::sin(a) * R[i]); }
        for (int i = 0; i < 3; i++) for (int j = 0; j < NS; j++){ const uint32_t a = i*NS + j, b = i*NS + (j+1) % NS, c = (i+1)*NS + j, d = (i+1)*NS + (j+1) % NS; const uint32_t t[6] = {a, c, b, b, c, d}; idx.insert(idx.end(), t, t + 6); }
        const int n[1] = {3}, o[1] = {0}; gCloud = BridgeGL::upload(v.data(), v.size() * 4, idx, 12, n, o, 1); gCloudTex = RoadGL::gFbmTex; }
    // waterfall ribbon: 5 columns across, every column sits 0.9 m above the real mountain surface
    if (NatureFx::gFallOn){
        const int N = (int)NatureFx::PX.size(), C = 5; std::vector<float> v; std::vector<uint32_t> idx; float lastY = 0;
        for (int i = 0; i < N; i++){
            const int a = std::max(0, i - 1), b = std::min(N - 1, i + 1);
            float tx = NatureFx::PX[b] - NatureFx::PX[a], tz = NatureFx::PZ[b] - NatureFx::PZ[a]; const float tl = std::sqrt(tx*tx + tz*tz); if (tl < 1e-4f){ tx = 1; tz = 0; } else { tx /= tl; tz /= tl; }
            const float sx = -tz, sz = tx, t = (float)i / (N - 1), hw = 0.5f * (3.0f + 5.0f * t * t * (3 - 2 * t));
            for (int c = 0; c < C; c++){
                const float u = (float)c / (C - 1), off = (u * 2 - 1) * hw, x = NatureFx::PX[i] + sx * off, z = NatureFx::PZ[i] + sz * off;
                double h = Terrain::mtnH(x, z); const float y = (h >= 0 ? (float)h : lastY) + 0.9f; lastY = y;
                const float row[5] = {x, y, z, u, 5.f * i}; v.insert(v.end(), row, row + 5);
            }
        }
        for (int i = 0; i + 1 < N; i++) for (int c = 0; c + 1 < C; c++){ const uint32_t a = i*C + c, b = i*C + c + 1, d = (i+1)*C + c, e = (i+1)*C + c + 1; const uint32_t t[6] = {a, b, d, b, e, d}; idx.insert(idx.end(), t, t + 6); }
        const int n[2] = {3, 2}, o[2] = {0, 12}; gFall = BridgeGL::upload(v.data(), v.size() * 4, idx, 20, n, o, 2);
        const float q[4][5] = {{0,0,0,-1,-1}, {0,0,0,1,-1}, {0,0,0,-1,1}, {0,0,0,1,1}}; std::vector<float> mv(&q[0][0], &q[0][0] + 20); std::vector<uint32_t> mi = {0, 1, 2, 1, 3, 2};
        gMist = BridgeGL::upload(mv.data(), mv.size() * 4, mi, 20, n, o, 2);
        gBase[0] = NatureFx::PX[N - 1]; gBase[2] = NatureFx::PZ[N - 1]; const double hb = Terrain::mtnH(gBase[0], gBase[2]); gBase[1] = (hb >= 0 ? (float)hb : 0.f) + 1.0f;
    }
    gOk = true;
}

// transparent: call after the opaque scene (and the lake), before the night overlay
static void draw(const float* VP, const float* eye, float t){
    if (!gOk) return;
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glDepthMask(GL_FALSE); glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    if (gFall.count){
        glUseProgram(gFallProg); glUniformMatrix4fv(uF_VP, 1, GL_FALSE, VP); glUniform3fv(uF_Cam, 1, eye); glUniform1f(uF_T, t);
        glEnable(GL_POLYGON_OFFSET_FILL); glPolygonOffset(-3.f, -3.f);
        glUniform1i(uF_Mode, 0); BridgeGL::drawGpu(gFall);
        glDisable(GL_POLYGON_OFFSET_FILL);
        float rx = eye[2] - gBase[2], rz = -(eye[0] - gBase[0]), l = std::sqrt(rx*rx + rz*rz); if (l < 1e-4f) l = 1;      // spray puff faces the camera (horizontal right vector)
        glUniform1i(uF_Mode, 1); glUniform3f(uF_Base, gBase[0], gBase[1], gBase[2]); glUniform3f(uF_Right, rx / l, 0.f, rz / l); glUniform1f(uF_Size, 22.f); BridgeGL::drawGpu(gMist);
    }
    glUseProgram(gCloudProg); glUniformMatrix4fv(uC_VP, 1, GL_FALSE, VP); glUniform3fv(uC_Cam, 1, eye); glUniform1f(uC_T, t);
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, gCloudTex); glUniform1i(uC_Fbm, 0);
    BridgeGL::drawGpu(gCloud);
    glDepthMask(GL_TRUE); glDisable(GL_BLEND);
}

} // namespace NatureFxGL
