// Sunny Drift - OpenGL ES 3 rendering of the roadside fence (posts, mounds, ropes, flying dirt) and the wooden lamp poles (see fence.h).
//  every part is one instanced draw (model matrix + tint per instance); the instance lists are rebuilt each frame by Fence::build()
#pragma once
#include <GLES3/gl3.h>
#include "fence.h"
#include "sun_light.h"
#include <algorithm>
#include <cmath>
#include "quality.h"

namespace FenceGL {

static const char* FVS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in vec3 n; layout(location=2) in vec2 t; layout(location=3) in vec3 c;
layout(location=4) in vec4 m0; layout(location=5) in vec4 m1; layout(location=6) in vec4 m2; layout(location=7) in vec4 m3; layout(location=8) in vec3 tint;
uniform mat4 uVP; out vec3 vn; out vec3 wp; out vec3 vc; out vec2 vt;
void main(){
  mat4 M = mat4(m0, m1, m2, m3); vec4 w = M * vec4(p, 1.0);
  wp = w.xyz; vn = mat3(M) * n; vt = t; vc = c * tint; gl_Position = uVP * w;
}
)GLSL";
static const char* FFS = R"GLSL(#version 300 es
precision highp float;
in vec3 vn; in vec3 wp; in vec3 vc; in vec2 vt;
uniform sampler2D uTex; uniform vec3 uCam, uBase; uniform float uUseTex, uSrgb, uUnlit, uBump, uMetal, uQ;
out vec4 o;
void main(){
  vec3 base = vc * uBase;
  vec3 N = normalize(vn); if (!gl_FrontFacing) N = -N;
  float cav = 1.0;
  if (uUseTex > 0.5){
    vec3 tx = texture(uTex, vt).rgb; float hgt = tx.g;
    if (uSrgb > 0.5) tx = pow(tx, vec3(2.2));
    base *= tx;
    if (uBump > 0.0 && length(uCam - wp) < 30.0){                                   // screen-space bump map: the bark / grain luminance becomes real relief (cracks, ridges, strands)
      vec3 dpx = dFdx(wp), dpy = dFdy(wp); float hx = dFdx(hgt) * uBump, hy = dFdy(hgt) * uBump;
      vec3 r1 = cross(dpy, N), r2 = cross(N, dpx); float det = dot(dpx, r1);
      vec3 grad = sign(det) * (hx * r1 + hy * r2);
      N = normalize(abs(det) * N - grad);
    }
    cav = mix(0.70, 1.0, smoothstep(0.10, 0.65, hgt));  // deep cracks sit in shadow
  }
  vec3 L = SUNL, V = normalize(uCam - wp), H = normalize(L + V);
  float d = max(dot(N, L), 0.0), wrap = max(dot(N, L) * 0.5 + 0.5, 0.0);
  vec3 amb = mix(vec3(0.20, 0.18, 0.13), vec3(0.32, 0.39, 0.50), N.y * 0.5 + 0.5);      // warm ground bounce below, cool sky above
  vec3 sun = vec3(1.0, 0.93, 0.78);
  vec3 lit = (uUnlit > 0.5) ? base : base * (amb * cav + sun * (0.78 * d + 0.12 * wrap) * mix(0.6, 1.0, cav));
  if (uUnlit < 0.5 && uUseTex > 0.5){                   // faint dry-wood sheen + bleached silvery fresnel edge
    lit += sun * pow(max(dot(N, H), 0.0), 22.0) * 0.035 * cav;
    lit += vec3(0.30, 0.34, 0.38) * pow(1.0 - max(dot(N, V), 0.0), 4.0) * 0.05 * base;
  }
  if (uMetal > 0.5){                                     // galvanised steel: brushed-metal look, soft broad highlight + tight sun glint, sky reflection (Low: cheap version, no weathering noise)
    float h1 = 0.5, streak = 0.94;
    if (uQ > 0.5){ h1 = fract(sin(dot(vec2(floor((wp.x + wp.z) * 3.0), floor(wp.y * 30.0)), vec2(12.9898, 78.233))) * 43758.5453); streak = 0.90 + 0.10 * h1 + 0.05 * sin(wp.x * 0.7 + wp.z * 0.9); }
    vec3 Rf = reflect(-V, N);
    float NoV = max(dot(N, V), 0.0);
    // environment the steel mirrors: dark verge below, pale hazy horizon band, deeper blue overhead (+ a warm tint when the sun is low)
    float ry = Rf.y;
    vec3 skyHi = mix(vec3(0.80, 0.88, 0.97), vec3(0.22, 0.42, 0.85), clamp(ry * 1.7, 0.0, 1.0));
    vec3 env = mix(vec3(0.07, 0.08, 0.06), skyHi, smoothstep(-0.25, 0.06, ry));
    env += vec3(1.0, 0.85, 0.6) * pow(max(dot(Rf, L), 0.0), 6.0) * 0.35;                 // broad sun sheen in the sky
    vec3 F0 = vec3(0.56, 0.58, 0.61);                                                    // galvanised zinc: cool silver-grey
    vec3 F = F0 + (vec3(1.0) - F0) * pow(1.0 - NoV, 5.0);
    float nh = max(dot(N, H), 0.0);
    float sp = pow(nh, 140.0) * 2.4 + pow(nh, 28.0) * 0.55 + pow(nh, 7.0) * 0.12 * (uQ > 1.5 ? 1.0 : 0.6);   // tight glint + glossy lobe + soft sheen
    lit = base * vec3(0.95, 0.98, 1.04) * streak * (amb * 0.75 + sun * 0.30 * d)         // metals have almost no diffuse light
        + env * F * streak * 0.95
        + sun * vec3(0.95, 0.97, 1.0) * sp * (0.7 + 0.3 * h1) * step(0.001, d + 0.01);
    lit *= mix(0.80, 1.0, smoothstep(0.35, 0.75, N.x * N.x + N.z * N.z + abs(N.y) * 0.6));
  }
  vec3 c = pow(lit, vec3(1.0 / 2.2));                                   // linear -> display, like three.js
  c = mix(c, vec3(0.62, 0.80, 0.95), clamp(length(uCam - wp) / 3750.0, 0.0, 1.0));
  o = vec4(c, 1.0);
}
)GLSL";

struct GeoGL { GLuint vao = 0, vbo = 0, ibo = 0; GLsizei count = 0; };
static GeoGL gPost, gMound, gRope, gSeg, gPart, gPole, gShade, gHead, gGrail, gGPost, gSWall;
static GLuint gProg = 0, gInst = 0, gBark = 0, gRopeT = 0, gWood = 0;
static GLint uVP, uCam, uBase, uUseTex, uSrgb, uUnlit, uTex, uBump, uMetal, uQ;
static bool gOk = false;

static GLuint sh(GLenum t, const char* s){ GLuint x = glCreateShader(t); SunLight::shaderSource(x, s); glCompileShader(x); return x; }
static GeoGL upload(const Fence::Mesh& m){
    GeoGL g; g.count = (GLsizei)m.idx.size(); if (!g.count) return g;
    std::vector<float> vb((size_t)m.vc() * 11);
    for (int i = 0; i < m.vc(); i++){
        for (int k = 0; k < 3; k++){ vb[i*11+k] = m.p[i*3+k]; vb[i*11+3+k] = m.n[i*3+k]; vb[i*11+8+k] = m.c[i*3+k]; }
        vb[i*11+6] = m.uv[i*2]; vb[i*11+7] = m.uv[i*2+1];
    }
    glGenVertexArrays(1, &g.vao); glBindVertexArray(g.vao);
    glGenBuffers(1, &g.vbo); glBindBuffer(GL_ARRAY_BUFFER, g.vbo); glBufferData(GL_ARRAY_BUFFER, vb.size() * 4, vb.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 44, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 44, (void*)12);
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 44, (void*)24);
    glEnableVertexAttribArray(3); glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 44, (void*)32);
    glGenBuffers(1, &g.ibo); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, g.ibo); glBufferData(GL_ELEMENT_ARRAY_BUFFER, m.idx.size() * 2, m.idx.data(), GL_STATIC_DRAW);
    glBindVertexArray(0); return g;
}
static GLuint tex(const std::vector<uint8_t>& px, int w, int h){
    GLuint t; glGenTextures(1, &t); glBindTexture(GL_TEXTURE_2D, t);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, px.data()); glGenerateMipmap(GL_TEXTURE_2D);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    return t;
}

// Call once with a current GL context, after Terrain::init() and Bridge/BridgeGL::init().
static void init(){
    Fence::init();
    gProg = glCreateProgram(); glAttachShader(gProg, sh(GL_VERTEX_SHADER, FVS)); glAttachShader(gProg, sh(GL_FRAGMENT_SHADER, FFS)); glLinkProgram(gProg); SunLight::attach(gProg);
    uVP = glGetUniformLocation(gProg, "uVP"); uCam = glGetUniformLocation(gProg, "uCam"); uBase = glGetUniformLocation(gProg, "uBase");
    uUseTex = glGetUniformLocation(gProg, "uUseTex"); uSrgb = glGetUniformLocation(gProg, "uSrgb"); uUnlit = glGetUniformLocation(gProg, "uUnlit"); uTex = glGetUniformLocation(gProg, "uTex"); uBump = glGetUniformLocation(gProg, "uBump"); uMetal = glGetUniformLocation(gProg, "uMetal"); uQ = glGetUniformLocation(gProg, "uQ");
    gPost = upload(Fence::G.post); gMound = upload(Fence::G.mound); gRope = upload(Fence::G.rope); gSeg = upload(Fence::G.seg); gPart = upload(Fence::G.part);
    gPole = upload(Fence::G.pole); gShade = upload(Fence::G.shade); gHead = upload(Fence::G.head); gGrail = upload(Fence::G.grail); gGPost = upload(Fence::G.gpost); gSWall = upload(Fence::G.swall);
    gBark = tex(Fence::G.barkTex, Fence::G.barkW, Fence::G.barkH); gRopeT = tex(Fence::G.ropeTex, Fence::G.ropeS, Fence::G.ropeS); gWood = tex(Fence::G.woodTex, Fence::G.woodW, Fence::G.woodH);
    glGenBuffers(1, &gInst); gOk = true;
}

static void drawInst(const GeoGL& g, const std::vector<float>& inst){
    const GLsizei n = (GLsizei)(inst.size() / 19); if (!n || !g.count) return;
    glBindVertexArray(g.vao); glBindBuffer(GL_ARRAY_BUFFER, gInst); glBufferData(GL_ARRAY_BUFFER, inst.size() * 4, inst.data(), GL_STREAM_DRAW);
    for (int i = 0; i < 4; i++){ glEnableVertexAttribArray(4 + i); glVertexAttribPointer(4 + i, 4, GL_FLOAT, GL_FALSE, 76, (void*)(intptr_t)(16 * i)); glVertexAttribDivisor(4 + i, 1); }
    glEnableVertexAttribArray(8); glVertexAttribPointer(8, 3, GL_FLOAT, GL_FALSE, 76, (void*)(intptr_t)64); glVertexAttribDivisor(8, 1);
    glDrawElementsInstanced(GL_TRIANGLES, g.count, GL_UNSIGNED_SHORT, (void*)0, n);
    glBindVertexArray(0);
}
static void material(GLuint t, bool srgb, float r, float g, float b, bool unlit, float bump = 0.f){
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, t ? t : 0); glUniform1i(uTex, 0);
    glUniform1f(uUseTex, t ? 1.f : 0.f); glUniform1f(uSrgb, srgb ? 1.f : 0.f); glUniform3f(uBase, r, g, b); glUniform1f(uUnlit, unlit ? 1.f : 0.f); glUniform1f(uBump, bump); glUniform1f(uMetal, 0.f);
}

// VP = projection*view (column-major), V = view matrix (for the camera forward), eye = camera position
static void draw(const float* VP, const float* V, const float* eye){
    if (!gOk) return;
    const float fwd[3] = {-V[2], -V[6], -V[10]}; const float l = std::sqrt(fwd[0]*fwd[0] + fwd[2]*fwd[2]); const float f2[3] = {l > 1e-5f ? fwd[0] / l : 0.f, 0.f, l > 1e-5f ? fwd[2] / l : 1.f};
    Fence::build(eye, f2);
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glDisable(GL_BLEND);
    glUseProgram(gProg); glUniformMatrix4fv(uVP, 1, GL_FALSE, VP); glUniform3fv(uCam, 1, eye); glUniform1f(uQ, Quality::flat ? 0.f : (float)Quality::level);   // metal shading detail follows Settings > Graphics
    material(0, false, 1, 1, 1, false, 0.f);                         // white plastic guide posts: vertex colours only
    drawInst(gPost, Fence::gI.posts);
    material(gRopeT, true, 1, 1, 1, false, 0.006f);                  // twisted rope
    drawInst(gRope, Fence::gI.ropes); drawInst(gSeg, Fence::gI.segs);
    material(0, false, 1, 1, 1, false, 0.f);                         // steel guardrails + posts
    glUniform1f(uMetal, 1.f); drawInst(gGrail, Fence::gI.beams); drawInst(gGPost, Fence::gI.gposts); glUniform1f(uMetal, 0.f);
    drawInst(gSWall, Fence::gI.swalls);                              // stone retaining walls (hill road hairpins)
    material(0, false, 1, 1, 1, false);                      // dirt / splinter chunks (vertex colour only; tint = colour)
    drawInst(gPart, Fence::gI.parts);
    material(0, false, 1, 1, 1, false, 0.f);                         // galvanised steel lamp poles (vertex colours)
    glUniform1f(uMetal, 1.f); drawInst(gPole, Fence::gI.lamps); glUniform1f(uMetal, 0.f);
    drawInst(gShade, Fence::gI.lamps);                               // luminaire housing
    material(0, false, 0.55f, 0.60f, 0.64f, true);           // LED lens (unlit, day colour: pale)
    drawInst(gHead, Fence::gI.lamps);
    glActiveTexture(GL_TEXTURE0);
}

// =====================================================================================================================================
// NIGHT: the street lamps really light up.  After NightGL::overlay() has darkened the picture, each lamp (nearby ones, from Fence::gI.lamps) adds
//   1. the lantern lens glows warm (unlit, so bloom picks it up),
//   2. a pool of warm light on the ground under the lamp: the road / grass colour is MULTIPLIED by (1 + light), so it lights the real surface instead of
//      painting a flat disc; the light follows the true point-light law (height h above the ground: E = h^3 / (r^2 + h^2)^1.5), soft edge,
//   3. a faint cone of lit dust / haze under the lantern (additive, soft edges, Normal + High quality only),
//   4. a camera-facing halo + white-hot core that grows with distance, so far lamps still read as glowing points (like real sodium / LED lamps),
// A lamp that has been knocked over by the car dims (its bulb is no longer high above the ground) and goes out when it lies flat.
// =====================================================================================================================================
static const char* LH_VS = R"GLSL(#version 300 es
layout(location=0) in vec2 q; layout(location=1) in vec4 a;       // a = bulb position, brightness (0..1)
uniform mat4 uVP; uniform vec3 uRt, uUp, uCam; out vec2 vQ; out float vK;
void main(){
  vec3 d = uCam - a.xyz; float dist = length(d);
  vec3 c = a.xyz + d / max(dist, 0.1) * 0.6;                     // a little towards the eye, so the glow is not cut by the lantern itself
  float s = 0.60 + dist * 0.0105;                                  // far lamps get a bigger halo: they stay visible as glowing points
  vQ = q; vK = a.w * smoothstep(1.5, 8.0, dist);
  gl_Position = uVP * vec4(c + (uRt * q.x + uUp * q.y) * s, 1.0);
}
)GLSL";
static const char* LH_FS = R"GLSL(#version 300 es
precision mediump float;
in vec2 vQ; in float vK; uniform float uN; out vec4 o;
void main(){
  float r2 = dot(vQ, vQ);
  float core = exp(-r2 * 70.0), halo = 0.30 / (1.0 + r2 * 30.0), wide = 0.10 * exp(-r2 * 4.5);
  float edge = smoothstep(1.0, 0.55, sqrt(r2));
  vec3 col = mix(vec3(1.0, 0.72, 0.38), vec3(1.0, 0.94, 0.82), clamp(core * 1.5, 0.0, 1.0));   // warm sodium halo, white-hot core
  o = vec4(col * (core * 1.9 + halo + wide) * edge * vK * uN, 1.0);
}
)GLSL";
static const char* LP_VS = R"GLSL(#version 300 es
layout(location=0) in vec2 q; layout(location=1) in vec4 a; layout(location=2) in vec2 g;   // a = bulb xyz + brightness, g.x = ground height
uniform mat4 uVP; out vec2 vP; out float vH; out float vK;
const float R = 11.0;
void main(){
  vP = q * R; vH = a.y - g.x; vK = a.w;
  gl_Position = uVP * vec4(a.x + vP.x, g.x + 0.14, a.z + vP.y, 1.0);
}
)GLSL";
static const char* LP_FS = R"GLSL(#version 300 es
precision highp float;
in vec2 vP; in float vH; in float vK; uniform float uN; uniform int uMode; out vec4 o;
void main(){
  float r2 = dot(vP, vP), h = max(vH, 1.0), d2 = r2 + h * h;
  float e = (h * h * h) / (d2 * sqrt(d2)) * (1.0 - smoothstep(55.0, 121.0, r2));     // point light above the ground, soft edge at 11 m
  float E = e * vK * uN;
  vec3 warm = vec3(1.0, 0.80, 0.50);
  o = (uMode == 0) ? vec4(warm * E * 4.0, 1.0) : vec4(warm * E * 0.10, 1.0);          // multiply pass (x up to 5) + faint additive veil
}
)GLSL";
static const char* LC_VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in vec3 n; layout(location=2) in float t; layout(location=3) in vec4 a; layout(location=4) in vec2 g;
uniform mat4 uVP; uniform vec3 uEye; out vec3 vN; out vec3 vV; out float vT; out float vK;
void main(){
  float len = min(a.y - g.x, 6.0), rad = len * 0.62;
  vec3 w = a.xyz + vec3(p.x * rad, p.y * len, p.z * rad);
  vN = n; vV = uEye - w; vT = t; vK = a.w * (1.0 - smoothstep(40.0, 110.0, length(uEye - a.xyz)));
  gl_Position = uVP * vec4(w, 1.0);
}
)GLSL";
static const char* LC_FS = R"GLSL(#version 300 es
precision highp float;
in vec3 vN; in vec3 vV; in float vT; in float vK; uniform float uN; out vec4 o;
void main(){
  float nd = abs(dot(normalize(vN), normalize(vV)));
  float a = pow(nd, 1.6) * pow(1.0 - vT, 1.6) * smoothstep(0.0, 0.08, vT) * 0.13 * vK * uN;
  o = vec4(vec3(1.0, 0.78, 0.46) * a, 1.0);
}
)GLSL";

static GLuint gLHalo = 0, gLPool = 0, gLCone = 0, gLvaoH = 0, gLvaoP = 0, gLvaoC = 0, gLquad = 0, gLconeV = 0, gLinst = 0; static bool gLOk = false;
static GLint uH_VP, uH_Rt, uH_Up, uH_Cam, uH_N, uP_VP, uP_N, uP_Mode, uC_VP, uC_Eye, uC_N;
static const int CONE_N = 16;
static GLuint mkLP(const char* vs, const char* fs){
    GLuint p = glCreateProgram(); GLuint a = glCreateShader(GL_VERTEX_SHADER); glShaderSource(a, 1, &vs, nullptr); glCompileShader(a);
    GLuint b = glCreateShader(GL_FRAGMENT_SHADER); glShaderSource(b, 1, &fs, nullptr); glCompileShader(b);
    glAttachShader(p, a); glAttachShader(p, b); glLinkProgram(p); return p;
}
static void initLights(){
    gLHalo = mkLP(LH_VS, LH_FS); gLPool = mkLP(LP_VS, LP_FS); gLCone = mkLP(LC_VS, LC_FS);
    uH_VP = glGetUniformLocation(gLHalo, "uVP"); uH_Rt = glGetUniformLocation(gLHalo, "uRt"); uH_Up = glGetUniformLocation(gLHalo, "uUp"); uH_Cam = glGetUniformLocation(gLHalo, "uCam"); uH_N = glGetUniformLocation(gLHalo, "uN");
    uP_VP = glGetUniformLocation(gLPool, "uVP"); uP_N = glGetUniformLocation(gLPool, "uN"); uP_Mode = glGetUniformLocation(gLPool, "uMode");
    uC_VP = glGetUniformLocation(gLCone, "uVP"); uC_Eye = glGetUniformLocation(gLCone, "uEye"); uC_N = glGetUniformLocation(gLCone, "uN");
    const float qd[12] = {-1,-1, 1,-1, -1,1, -1,1, 1,-1, 1,1};
    glGenBuffers(1, &gLquad); glBindBuffer(GL_ARRAY_BUFFER, gLquad); glBufferData(GL_ARRAY_BUFFER, sizeof(qd), qd, GL_STATIC_DRAW);
    std::vector<float> cv;                                        // unit cone: apex at the bulb, opens downwards (y = -1, radius 1)
    for (int i = 0; i < CONE_N; i++){
        const float a0 = i * 6.2831853f / CONE_N, a1 = (i + 1) * 6.2831853f / CONE_N, am = (a0 + a1) * 0.5f;
        const float nx = std::cos(am), nz = std::sin(am);
        const float v[3][7] = {{0, 0, 0, nx, 0.4f, nz, 0.f}, {std::cos(a0), -1, std::sin(a0), nx, 0.4f, nz, 1.f}, {std::cos(a1), -1, std::sin(a1), nx, 0.4f, nz, 1.f}};
        for (int k = 0; k < 3; k++) cv.insert(cv.end(), v[k], v[k] + 7);
    }
    glGenBuffers(1, &gLconeV); glBindBuffer(GL_ARRAY_BUFFER, gLconeV); glBufferData(GL_ARRAY_BUFFER, cv.size() * 4, cv.data(), GL_STATIC_DRAW);
    glGenBuffers(1, &gLinst); glBindBuffer(GL_ARRAY_BUFFER, gLinst); glBufferData(GL_ARRAY_BUFFER, 4096 * 24, nullptr, GL_STREAM_DRAW);
    // halo VAO: quad + (bulb, k)
    glGenVertexArrays(1, &gLvaoH); glBindVertexArray(gLvaoH);
    glBindBuffer(GL_ARRAY_BUFFER, gLquad); glEnableVertexAttribArray(0); glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 8, (void*)0);
    glBindBuffer(GL_ARRAY_BUFFER, gLinst); glEnableVertexAttribArray(1); glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 24, (void*)0); glVertexAttribDivisor(1, 1);
    // pool VAO: quad + (bulb, k) + (ground y)
    glGenVertexArrays(1, &gLvaoP); glBindVertexArray(gLvaoP);
    glBindBuffer(GL_ARRAY_BUFFER, gLquad); glEnableVertexAttribArray(0); glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 8, (void*)0);
    glBindBuffer(GL_ARRAY_BUFFER, gLinst); glEnableVertexAttribArray(1); glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 24, (void*)0); glVertexAttribDivisor(1, 1);
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 24, (void*)16); glVertexAttribDivisor(2, 1);
    // cone VAO
    glGenVertexArrays(1, &gLvaoC); glBindVertexArray(gLvaoC);
    glBindBuffer(GL_ARRAY_BUFFER, gLconeV);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 28, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 28, (void*)12);
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 1, GL_FLOAT, GL_FALSE, 28, (void*)24);
    glBindBuffer(GL_ARRAY_BUFFER, gLinst);
    glEnableVertexAttribArray(3); glVertexAttribPointer(3, 4, GL_FLOAT, GL_FALSE, 24, (void*)0); glVertexAttribDivisor(3, 1);
    glEnableVertexAttribArray(4); glVertexAttribPointer(4, 2, GL_FLOAT, GL_FALSE, 24, (void*)16); glVertexAttribDivisor(4, 1);
    glBindVertexArray(0); gLOk = true;
}

// call AFTER NightGL::overlay() (and the sky), so the lights are not darkened by the night multiply. V = view matrix, night = NightGL::night (0..1)
static void drawLights(const float* VP, const float* V, const float* eye, float night){
    if (!gOk) return;
    if (!gLOk) initLights();
    float t = (night - 0.08f) / 0.47f; t = t < 0.f ? 0.f : (t > 1.f ? 1.f : t); const float N = t * t * (3.f - 2.f * t);       // lamps switch on while the sky goes dark
    if (N < 0.01f) return;
    const std::vector<float>& L = Fence::gI.lamps; const int n = (int)(L.size() / 19); if (!n) return;
    struct Lt { float d2, x, y, z, k, gy; }; static std::vector<Lt> lt; lt.clear();
    const float Hb = (float)Fence::LAMP_H + 0.07f;                                                 // just under the lens
    for (int i = 0; i < n; i++){
        const float* m = &L[(size_t)i * 19];
        const float bx = m[0] * -(float)Fence::LAMP_ARM + m[4] * Hb + m[12], by = m[1] * -(float)Fence::LAMP_ARM + m[5] * Hb + m[13], bz = m[2] * -(float)Fence::LAMP_ARM + m[6] * Hb + m[14];
        float k = (by - m[13] - 1.0f) / 4.0f; k = k < 0.f ? 0.f : (k > 1.f ? 1.f : k);            // a knocked-over lamp dims, lying flat it is dark
        if (k <= 0.f) continue;
        const float dx = bx - eye[0], dz = bz - eye[2], d2 = dx*dx + dz*dz + (by - eye[1]) * (by - eye[1]); if (d2 > 450.f * 450.f) continue;
        lt.push_back({d2, bx, by, bz, k, m[13]});
    }
    if (lt.empty()) return;
    std::sort(lt.begin(), lt.end(), [](const Lt& a, const Lt& b){ return a.d2 < b.d2; });
    if (lt.size() > 160) lt.resize(160);
    static std::vector<float> D; D.clear(); int pC = 0, cC = 0;
    for (const Lt& l : lt){ const float a[6] = {l.x, l.y, l.z, l.k, l.gy, 0.f}; D.insert(D.end(), a, a + 6); if (l.d2 < 230.f * 230.f) pC++; if (l.d2 < 110.f * 110.f) cC++; }
    const int cnt = (int)lt.size();
    glBindBuffer(GL_ARRAY_BUFFER, gLinst); glBufferData(GL_ARRAY_BUFFER, D.size() * 4, D.data(), GL_STREAM_DRAW);

    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glDepthMask(GL_FALSE);
    // 1. the lens itself: warm, unlit, drawn over the darkened picture (same depth as the day lens -> LEQUAL)
    glDepthFunc(GL_LEQUAL); glDisable(GL_BLEND);
    glUseProgram(gProg); glUniformMatrix4fv(uVP, 1, GL_FALSE, VP); glUniform3fv(uCam, 1, eye);
    material(0, false, 1.00f * N, 0.84f * N, 0.55f * N, true);
    drawInst(gHead, L);
    glDepthFunc(GL_LESS);
    glEnable(GL_BLEND);
    // 2. pools of light on the road / grass (the surface colour x (1 + light))
    glUseProgram(gLPool); glUniformMatrix4fv(uP_VP, 1, GL_FALSE, VP); glUniform1f(uP_N, N); glBindVertexArray(gLvaoP);
    glEnable(GL_POLYGON_OFFSET_FILL); glPolygonOffset(-5.f, -5.f);
    glUniform1i(uP_Mode, 0); glBlendFunc(GL_DST_COLOR, GL_ONE); glDrawArraysInstanced(GL_TRIANGLES, 0, 6, pC);
    glUniform1i(uP_Mode, 1); glBlendFunc(GL_ONE, GL_ONE);       glDrawArraysInstanced(GL_TRIANGLES, 0, 6, pC);
    glDisable(GL_POLYGON_OFFSET_FILL);
    // 3. faint cone of lit haze under each lantern (not on Low)
    if (Quality::level > 0 && cC > 0){
        glUseProgram(gLCone); glUniformMatrix4fv(uC_VP, 1, GL_FALSE, VP); glUniform3fv(uC_Eye, 1, eye); glUniform1f(uC_N, N); glBindVertexArray(gLvaoC);
        glBlendFunc(GL_ONE, GL_ONE); glDrawArraysInstanced(GL_TRIANGLES, 0, CONE_N * 3, cC);
    }
    // 4. halo + white-hot core, always facing the camera
    glUseProgram(gLHalo); glUniformMatrix4fv(uH_VP, 1, GL_FALSE, VP); glUniform1f(uH_N, N); glUniform3fv(uH_Cam, 1, eye);
    glUniform3f(uH_Rt, V[0], V[4], V[8]); glUniform3f(uH_Up, V[1], V[5], V[9]);
    glBindVertexArray(gLvaoH); glBlendFunc(GL_ONE, GL_ONE); glDrawArraysInstanced(GL_TRIANGLES, 0, 6, cnt);
    glBindVertexArray(0); glDisable(GL_BLEND); glDepthMask(GL_TRUE);
    glActiveTexture(GL_TEXTURE0);
}

} // namespace FenceGL
