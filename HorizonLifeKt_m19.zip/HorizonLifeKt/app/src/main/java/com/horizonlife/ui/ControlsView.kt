package com.horizonlife.ui

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import com.horizonlife.game.Collision
import com.horizonlife.game.EngineSound
import com.horizonlife.game.Game
import com.horizonlife.game.Settings
import kotlin.math.*

/**
 * Transparent overlay on top of the GLSurfaceView: multi-touch driving buttons (L / R / GAS / BRAKE / HANDBRAKE),
 * a speed/gear HUD, one-finger drag = orbit camera, two-finger pinch = zoom (same as the JS version).
 */
class ControlsView(ctx: Context, private val game: Game, private val onResolution: () -> Unit, private val fpsProvider: () -> Float) : View(ctx) {
    private enum class Btn { LEFT, RIGHT, GAS, BRAKE, HAND, RESET, TIME, MUTE, PAUSE, SETTINGS, WHEEL }
    private val rects = HashMap<Btn, RectF>()
    private val held = HashMap<Int, Btn>()                 // pointerId -> button
    private val camPtr = HashMap<Int, PointF>()            // pointers dragging the camera
    private var pinchD = 0f
    private var mapOpen = false                           // full-screen map (tap the minimap)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG); private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f; color = 0x59FFFFFF }
    init { Minimap.buildAsync() }
    private val panel = SettingsPanel(game, onResolution) { relayout(); }
    private var lastHudScale = Settings.hudScale
    private fun isDrive(b: Btn) = b == Btn.LEFT || b == Btn.RIGHT || b == Btn.GAS || b == Btn.BRAKE || b == Btn.HAND || b == Btn.WHEEL
    /** wheel mode swaps the L/R buttons for the drag-to-turn wheel */
    private fun shown(b: Btn) = (!isDrive(b) || Settings.hudShow[3]) &&
        !(Settings.ctrlWheel && (b == Btn.LEFT || b == Btn.RIGHT)) && !(!Settings.ctrlWheel && b == Btn.WHEEL)
    private var rot = 0f; private var wheelPtr = -1; private var lastAng = 0f      // wheel angle in degrees (+ = clockwise = right), JS wheelRange 135
    private fun wheelAng(x: Float, y: Float): Float { val r = rects[Btn.WHEEL] ?: return 0f; return Math.toDegrees(atan2((y - r.centerY()).toDouble(), (x - r.centerX()).toDouble())).toFloat() }
    private val mmPath = Path(); private val mmM = Matrix(); private val mmPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) = relayout()

    private fun relayout() {
        val w = width; val h = height; if (w == 0 || h == 0) return
        val hs = Settings.hudScale.toFloat(); lastHudScale = Settings.hudScale
        val d = resources.displayMetrics.density
        val s = 84f * d * hs; val g = 14f * d * hs; val m = 20f * d
        rects[Btn.LEFT] = RectF(m, h - m - s, m + s, h - m)
        rects[Btn.RIGHT] = RectF(m + s + g, h - m - s, m + 2 * s + g, h - m)
        rects[Btn.WHEEL] = RectF(m, h - m - s * 1.9f, m + s * 1.9f, h - m)
        rects[Btn.GAS] = RectF(w - m - s * 1.2f, h - m - s * 1.5f, w - m, h - m)
        rects[Btn.BRAKE] = RectF(w - m - s * 2.2f - g, h - m - s, w - m - s * 1.2f - g, h - m)
        rects[Btn.HAND] = RectF(w - m - s * 2.2f - g, h - m - s * 2f - g, w - m - s * 1.2f - g, h - m - s - g)
        val b = 48f * d; val st = 56f * d; val m0 = 20f * d      // top-right row: settings, pause, reset, day/night, sound
        for ((i, k) in listOf(Btn.SETTINGS, Btn.PAUSE, Btn.RESET, Btn.TIME, Btn.MUTE).withIndex())
            rects[k] = RectF(w - m0 - b - i * st, m0, w - m0 - i * st, m0 + b)
    }

    private fun hit(x: Float, y: Float): Btn? = rects.entries.firstOrNull { shown(it.key) && it.value.contains(x, y) }?.key

    private fun sync() {
        val i = game.input; val on = held.values.toSet()
        i.sens = Settings.steerSens; i.analog = if (Settings.ctrlWheel) -(rot / 135f).coerceIn(-1f, 1f).toDouble() else null
        i.left = Btn.LEFT in on; i.right = Btn.RIGHT in on; i.gas = Btn.GAS in on; i.brake = Btn.BRAKE in on; i.hand = Btn.HAND in on
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val a = e.actionMasked; val idx = e.actionIndex; val id = e.getPointerId(idx)
        if (panel.open) { held.clear(); camPtr.clear(); sync(); panel.touch(e); postInvalidateOnAnimation(); return true }
        if (mapOpen) { if (a == MotionEvent.ACTION_DOWN) { mapOpen = false; postInvalidateOnAnimation() }; return true }      // any tap closes the map
        if (a == MotionEvent.ACTION_DOWN && Settings.hudShow[0]) {
            val d = resources.displayMetrics.density; val r = 62f * d
            if (hypot(e.x - (16f * d + r), e.y - (52f * d + r)) < r) { mapOpen = true; held.clear(); camPtr.clear(); sync(); return true }
        }
        when (a) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val b = hit(e.getX(idx), e.getY(idx))
                if (b == Btn.RESET) game.reset()
                else if (b == Btn.TIME) game.env.toggle()
                else if (b == Btn.MUTE) { EngineSound.muted = !EngineSound.muted; Settings.save() }
                else if (b == Btn.PAUSE) Settings.paused = !Settings.paused
                else if (b == Btn.SETTINGS) { panel.open = true; held.clear(); camPtr.clear(); sync() }
                else if (b == Btn.WHEEL) { wheelPtr = id; lastAng = wheelAng(e.getX(idx), e.getY(idx)) }
                else if (b != null) held[id] = b
                else { camPtr[id] = PointF(e.getX(idx), e.getY(idx)); game.cam.dragging = true; game.cam.idle = 0.0
                    if (camPtr.size == 2) pinchD = pinchDist() }
                sync()
            }
            MotionEvent.ACTION_MOVE -> {
                for (k in 0 until e.pointerCount) {
                    val pid = e.getPointerId(k)
                    if (pid == wheelPtr) { val a2 = wheelAng(e.getX(k), e.getY(k)); var dd = a2 - lastAng; if (dd > 180) dd -= 360; if (dd < -180) dd += 360; lastAng = a2; rot = (rot + dd).coerceIn(-135f, 135f); continue }
                    val p = camPtr[pid]
                    if (p != null) {
                        val x = e.getX(k); val y = e.getY(k)
                        if (camPtr.size == 1) game.cam.onDrag(x - p.x, y - p.y)
                        p.x = x; p.y = y
                    } else {   // finger slid from one button to another
                        val b = hit(e.getX(k), e.getY(k)); if (b != null && isDrive(b) && b != Btn.WHEEL) held[pid] = b else held.remove(pid)
                    }
                }
                if (camPtr.size == 2) { val d = pinchDist(); if (pinchD > 0 && d > 0) game.cam.onPinch((pinchD / d).toDouble()); pinchD = d }
                sync()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                held.remove(id); camPtr.remove(id); if (id == wheelPtr) wheelPtr = -1
                if (a == MotionEvent.ACTION_CANCEL) { held.clear(); camPtr.clear(); wheelPtr = -1 }
                game.cam.dragging = camPtr.isNotEmpty(); game.cam.idle = 0.0; sync()
            }
        }
        return true
    }

    private fun pinchDist(): Float {
        val l = camPtr.values.toList(); return if (l.size < 2) 0f else hypot(l[0].x - l[1].x, l[0].y - l[1].y)
    }

    override fun onDraw(c: Canvas) {
        val d = resources.displayMetrics.density
        if (lastHudScale != Settings.hudScale) relayout()
        if (wheelPtr < 0 && rot != 0f) { rot *= 0.78f; if (abs(rot) < 0.5f) rot = 0f }       // wheel self-centres on release
        sync()
        val on = held.values.toSet()
        val layer = c.saveLayerAlpha(0f, 0f, width.toFloat(), height.toFloat(), (Settings.hudAlpha * 255).roundToInt())
        for ((b, r) in rects) {
            if (!shown(b)) continue
            if (b == Btn.WHEEL) { drawWheel(c, r, d); continue }
            fill.color = if (b in on) 0x99FFFFFF.toInt() else 0x66141928
            c.drawRoundRect(r, 14f * d, 14f * d, fill); c.drawRoundRect(r, 14f * d, 14f * d, stroke)
            text.textSize = 20f * d * min(1f, Settings.hudScale.toFloat() + 0.2f)
            val t = when (b) {
                Btn.LEFT -> "◀"; Btn.RIGHT -> "▶"; Btn.GAS -> "GAS"; Btn.BRAKE -> "BRK"; Btn.HAND -> "HB"; Btn.RESET -> "↺"
                Btn.TIME -> if (game.env.running) "☾" else "☀"; Btn.MUTE -> if (EngineSound.muted) "✕" else "♪"
                Btn.PAUSE -> if (Settings.paused) "▶" else "❚❚"; Btn.SETTINGS -> "⚙"; Btn.WHEEL -> ""
            }
            c.drawText(t, r.centerX(), r.centerY() + 7f * d, text)
        }
        // speed HUD (top-centre)
        if (Settings.hudShow[1]) {
            c.save(); c.scale(Settings.hudScale.toFloat(), Settings.hudScale.toFloat(), width / 2f, 0f)
            val kmh = (abs(game.car.speed) * 3.6).roundToInt()
            text.textSize = 34f * d; c.drawText(kmh.toString(), width / 2f, 44f * d, text)
            text.textSize = 11f * d; c.drawText("KM/H", width / 2f, 60f * d, text)
            text.textSize = 20f * d; c.drawText(if (game.car.gear == 0) "R" else game.car.gear.toString(), width / 2f - 70f * d, 40f * d, text)
            c.restore()
        }
        text.textSize = 11f * d; text.textAlign = Paint.Align.LEFT
        if (Settings.hudShow[2]) c.drawText("%.0f fps  %.0f rpm".format(fpsProvider(), game.car.rpm), 16f * d, 22f * d, text)
        c.drawText("bumps %d".format(Collision.hits), 16f * d, 38f * d, text)
        text.textAlign = Paint.Align.CENTER
        if (Settings.hudShow[0]) drawMinimap(c, d)
        c.restoreToCount(layer)
        if (Settings.paused) { text.textSize = 22f * d; c.drawText("PAUSED", width / 2f, height / 2f, text) }
        game.toast?.let { t -> text.textSize = 16f * d; text.color = Color.WHITE; fill.color = 0x99141928.toInt(); val w = text.measureText(t) + 28f * d
            c.drawRoundRect(width / 2f - w / 2, 72f * d, width / 2f + w / 2, 104f * d, 12f * d, 12f * d, fill); c.drawText(t, width / 2f, 94f * d, text) }
        if (mapOpen) drawFullMap(c, d)
        if (panel.open) panel.draw(c, width, height, d)
        postInvalidateOnAnimation()
    }

    private fun drawWheel(c: Canvas, r: RectF, d: Float) {
        val cx = r.centerX(); val cy = r.centerY(); val rad = min(r.width(), r.height()) / 2
        c.save(); c.rotate(rot, cx, cy)
        fill.color = 0x40141928; c.drawCircle(cx, cy, rad, fill)
        stroke.strokeWidth = 9f * d; stroke.color = 0xCCFFFFFF.toInt(); c.drawCircle(cx, cy, rad - 6f * d, stroke)
        stroke.strokeWidth = 5f * d; c.drawLine(cx - rad + 8f * d, cy, cx + rad - 8f * d, cy, stroke); c.drawLine(cx, cy, cx, cy + rad - 8f * d, stroke)
        fill.color = 0xFFE53935.toInt(); c.drawRect(cx - 3f * d, cy - rad, cx + 3f * d, cy - rad + 18f * d, fill)     // top marker
        c.restore(); stroke.strokeWidth = 3f; stroke.color = 0x59FFFFFF
    }

    /** full-screen map (JS full map): whole island, north up, you + the pier; tap to close */
    private fun drawFullMap(c: Canvas, d: Float) {
        val bmp = Minimap.bitmap
        fill.color = 0xE60F1620.toInt(); c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), fill)
        val size = min(width, height) * 0.94f; val s = size / (Minimap.RANGE * 2f); val ox = (width - size) / 2; val oy = (height - size) / 2
        if (bmp != null) { mmM.reset(); mmM.postScale(s, s); mmM.postTranslate(ox, oy); c.drawBitmap(bmp, mmM, mmPaint) }
        fun px(x: Double) = ox + (x + Minimap.RANGE).toFloat() * s; fun pz(z: Double) = oy + (z + Minimap.RANGE).toFloat() * s
        text.textAlign = Paint.Align.CENTER; text.textSize = 12f * d
        val lx = px(com.horizonlife.game.Harbor.worldX(-34.0, 0.0)); val lz = pz(com.horizonlife.game.Harbor.worldZ(-34.0, 0.0))
        fill.color = 0xFFFFFFFF.toInt(); val tw = text.measureText("PIER") + 12f * d
        c.drawRoundRect(lx - tw / 2, lz - 9f * d, lx + tw / 2, lz + 9f * d, 8f * d, 8f * d, fill)
        text.color = 0xFF0B4F7A.toInt(); c.drawText("PIER", lx, lz + 4f * d, text); text.color = Color.WHITE
        val cx = px(game.car.x); val cz = pz(game.car.z)
        c.save(); c.translate(cx, cz); c.rotate((180.0 + Math.toDegrees(game.car.heading)).toFloat())
        fill.color = 0xFFE53935.toInt()
        c.drawPath(Path().apply { moveTo(0f, -11f * d); lineTo(7f * d, 9f * d); lineTo(0f, 5f * d); lineTo(-7f * d, 9f * d); close() }, fill)
        c.restore()
        text.textSize = 12f * d; c.drawText("tap to close", width / 2f, height - 10f * d, text)
    }

    /** rotating minimap (forward = up), ~1 px/m * density like the JS one */
    private fun drawMinimap(c: Canvas, d: Float) {
        val bmp = Minimap.bitmap ?: return
        val r = 62f * d; val cx = 16f * d + r; val cy = 52f * d + r
        mmPath.reset(); mmPath.addCircle(cx, cy, r, Path.Direction.CW)
        c.save(); c.clipPath(mmPath)
        mmM.reset()
        mmM.postTranslate(-(game.car.x + Minimap.RANGE).toFloat(), -(game.car.z + Minimap.RANGE).toFloat())
        mmM.postScale(1.1f * d, 1.1f * d)
        mmM.postRotate((180.0 + Math.toDegrees(game.car.heading)).toFloat())
        mmM.postTranslate(cx, cy)
        c.drawBitmap(bmp, mmM, mmPaint)
        c.restore()
        stroke.color = 0xCCFFFFFF.toInt(); c.drawCircle(cx, cy, r, stroke); stroke.color = 0x59FFFFFF
        fill.color = 0xFFE53935.toInt()                                 // the car: arrow pointing up
        val a = Path().apply { moveTo(cx, cy - 8f * d); lineTo(cx + 5f * d, cy + 6f * d); lineTo(cx, cy + 3f * d); lineTo(cx - 5f * d, cy + 6f * d); close() }
        c.drawPath(a, fill)
    }
}
