// Sunny Drift - green trees: OpenGL ES 3 rendering + planting (C++ port of the HTML "Trees" + "Tree LOD" blocks).
//  * leaves: alpha-tested cards with the leaf texture, gentle wind sway (trSway in the HTML)
//  * bark: 6-sided tubes with the bark texture
//  * every tree is one instance (x, z, scale, rotation); trees within NEAR metres are drawn as the full model,
//    farther ones as a camera-facing billboard baked once from the model (same idea as bakeProto / updateTreeLOD)
#pragma once
#include <GLES3/gl3.h>
#include "sun_light.h"
#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <random>
#include <unordered_set>
#include <unordered_map>
#include "tree_model.h"
#include "road.h"
#include "terrain.h"
#include "village.h"        // houses: no trees on or next to them
#include "nature_plan.h"
#include "quality.h"
#include "tunnel.h"    // waterfall: no trees in the stream
#include "railway.h"   // no trees on the railway line

namespace TreeGL {

// ---------- tunables (same numbers as the HTML) ----------
const float NEAR_DIST = 38.f, HYST = 8.f;            // low-poly LOD: full model only very close (was 70 / 14)
const float MAX_DIST = 600.f;                         // distance culling: nothing farther than this is drawn at all
const float CULL_R = 7.f;                             // bounding radius (m, before tree scale) used for frustum culling
const int   GREEN_TREES = 240, GROVE_TREES = 170;    // 400 total in the HTML = 330 green + 70 maple; maple is not part of this port

const int N_SP = 7;                                   // tree species: 0 = spruce, 1 = pine, 2 = Norway spruce, 3 = silver fir, 4 = European larch, 5 = sycamore maple, 6 = rowan (broadleaf)
const float NORWAY_SHARE = 0.35f, FIR_SHARE = 0.20f, LARCH_SHARE = 0.15f, MAPLE_SHARE = 0.12f, ROWAN_SHARE = 0.08f;  // 35 % Norway spruce + 20 % silver fir + 15 % European larch + 12 % sycamore maple + 8 % rowan; the other 10 % keep the old spruce : pine = 55 : 45 split

struct Tree { float x, z, s, r, y; };                 // y = ground height (the hills)

static std::vector<Tree> gTrees;
static std::vector<uint8_t> gIsNear;
static GLuint gMeshProg = 0, gBillProg = 0, gNearVBO = 0, gFarVBO = 0;
static GLuint gLeafVAO = 0, gBarkVAO = 0, gBillVAO = 0, gLeafTex = 0, gBarkTex = 0, gBillTex = 0;
static GLuint gLeafVBO = 0, gLeafIBO = 0, gBarkVBO = 0, gBarkIBO = 0, gQuadVBO = 0;
static int gLeafIdx = 0, gBarkIdx = 0;
static float gBbHalfW = 1, gBbY0 = 0, gBbH = 1;
static GLint uM_VP, uM_Wind, uM_Sway, uM_Tex, uM_Cam, uM_Tint, uM_Emis, uM_Alpha, uM_Leaf;
static GLint uB_VP, uB_Right, uB_Size, uB_Tex, uB_Cam;

static const char* MESH_VS =
    "#version 300 es\n"
    "layout(location=0) in vec3 p; layout(location=1) in vec3 n; layout(location=2) in vec2 t; layout(location=3) in vec4 inst; layout(location=4) in float instY;\n"
    "uniform mat4 uVP; uniform float uWind; uniform float uSway;\n"
    "out vec2 vt; out vec3 vn; out vec3 wp;\n"
    "void main(){\n"
    " vec3 q = p;\n"
    " if (uSway > 0.5){\n"                                   // trSway(): wind moves the upper part of the crown
    "  float wv = sin(uWind*1.5 + inst.x*.11 + inst.y*.09)*.6 + sin(uWind*2.9 + q.x*1.3 + q.z*1.1 + inst.x*.2)*.4;\n"
    "  float hh = max(q.y - 1.5, 0.);\n"
    "  q.x += wv*.03*hh; q.z += wv*.02*hh;\n"
    " }\n"
    " q *= inst.z;\n"
    " float c = cos(inst.w), s = sin(inst.w);\n"
    " mat3 Ry = mat3(c,0.,-s, 0.,1.,0., s,0.,c);\n"
    " wp = Ry*q + vec3(inst.x, instY, inst.y); vn = Ry*n; vt = t;\n"
    " gl_Position = uVP*vec4(wp,1.);\n"
    "}";
static const char* MESH_FS =
    "#version 300 es\n"
    "precision highp float;\n"
    "in vec2 vt; in vec3 vn; in vec3 wp;\n"
    "uniform sampler2D uTex; uniform vec3 uCam, uTint, uEmis; uniform float uAlpha, uLeaf;\n"
    "out vec4 o;\n"
    "float h3(vec3 p){ p = fract(p*0.1031); p += dot(p, p.yzx + 33.33); return fract((p.x + p.y)*p.z); }\n"
    "void main(){\n"
    " vec4 tx = texture(uTex, vt);\n"
    " if (uAlpha > 0. && tx.a < uAlpha) discard;\n"
    " vec3 V = uCam - wp; float dist = length(V); V /= dist;\n"
    " vec3 L = SUNL;\n"
    " vec3 N = normalize(vn); vec3 c;\n"
    " if (uLeaf < .5){\n"
    "  if (!gl_FrontFacing) N = -N;\n"
    "  float d = max(dot(N, L), 0.0);\n"
    "  c = tx.rgb*uTint*(0.35 + 0.75*d) + uEmis;\n"
    " } else {\n"
    "  float v = h3(floor(wp*1.6));\n"
    "  vec3 alb = tx.rgb*uTint*mix(vec3(0.80,0.90,0.68), vec3(1.10,1.05,0.78), v);\n"
    "  alb *= 0.86 + 0.14*smoothstep(0.0, 0.5, vt.y);\n"
    "  N = normalize(N + vec3(0.0, 0.55, 0.0));\n"
    "  float nd = dot(N, L); float d = max(nd, 0.0), wrap = max(nd*0.5 + 0.5, 0.0);\n"
    "  vec3 amb = mix(vec3(0.24,0.29,0.16), vec3(0.50,0.66,0.95), N.y*0.5 + 0.5)*0.85;\n"
    "  c = alb*(amb + vec3(1.08,1.0,0.82)*(0.55*d + 0.35*wrap));\n"
    "  c += alb*vec3(0.75,0.95,0.25)*pow(max(dot(-V, L), 0.0), 3.0)*0.45;\n"
    "  c += uEmis;\n"
    " }\n"
    " c = mix(c, vec3(0.62,0.80,0.95), clamp(dist/3750.0, 0.0, 1.0));\n"
    " o = vec4(c,1.);\n"
    "}\n";
static const char* BILL_VS =
    "#version 300 es\n"
    "layout(location=0) in vec2 q; layout(location=3) in vec4 inst; layout(location=4) in float instY;\n"
    "uniform mat4 uVP; uniform vec3 uRight; uniform vec3 uSize;\n"   // uSize = (half width, y0, height) of the baked model
    "out vec2 vt; out vec3 wp;\n"
    "void main(){\n"
    " wp = vec3(inst.x, instY, inst.y) + uRight*(q.x*uSize.x*inst.z) + vec3(0., (uSize.y + q.y*uSize.z)*inst.z, 0.);\n"
    " vt = vec2(q.x*.5 + .5, q.y); gl_Position = uVP*vec4(wp,1.);\n"
    "}";
static const char* BILL_FS =
    "#version 300 es\nprecision mediump float;\n"
    "in vec2 vt; in vec3 wp; uniform sampler2D uTex; uniform vec3 uCam; out vec4 o;\n"
    "void main(){\n"
    " vec4 tx = texture(uTex, vt); if (tx.a < 0.4) discard;\n"
    " vec3 c = tx.rgb / max(tx.a, 0.001);\n"                                                                          // un-darken: the baked picture is black where empty, mip levels / filtering blend that black into the edge colour
    " c = mix(c, vec3(0.62,0.80,0.95), clamp(length(uCam-wp)/3750.0, 0.0, 1.0));\n"
    " o = vec4(c,1.);\n"
    "}";

static GLuint compileSh(GLenum t, const char* s){ GLuint sh = glCreateShader(t); SunLight::shaderSource(sh, s); glCompileShader(sh); return sh; }
static GLuint makeProg(const char* vs, const char* fs){
    GLuint p = glCreateProgram(); glAttachShader(p, compileSh(GL_VERTEX_SHADER, vs)); glAttachShader(p, compileSh(GL_FRAGMENT_SHADER, fs));
    glLinkProgram(p); SunLight::attach(p); return p;
}

// raw RGBA file: int32 width, int32 height, then w*h*4 bytes
static GLuint makeTexture(const std::vector<char>& f){
    if (f.size() < 8) return 0;
    int w, h; memcpy(&w, f.data(), 4); memcpy(&h, f.data() + 4, 4);
    GLuint t; glGenTextures(1, &t); glBindTexture(GL_TEXTURE_2D, t);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, f.data() + 8);   // row 0 = v 0 (three.js flipY = false)
    glGenerateMipmap(GL_TEXTURE_2D);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_BASE_LEVEL, 1);                 // low texture quality: start at mip 1 (half resolution, a quarter of the bandwidth)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    return t;
}

static void makePart(const TreeModel::Mesh& m, GLuint tex, GLuint& vao, GLuint& vbo, GLuint& ibo, int& idxCount){
    (void)tex;
    const int n = m.vertexCount();
    std::vector<float> vb((size_t)n * 8);
    for (int i = 0; i < n; i++){
        for (int k = 0; k < 3; k++){ vb[i*8+k] = m.pos[i*3+k]; vb[i*8+3+k] = m.nrm[i*3+k]; }
        vb[i*8+6] = m.uv[i*2]; vb[i*8+7] = m.uv[i*2+1];
    }
    glGenVertexArrays(1, &vao); glBindVertexArray(vao);
    glGenBuffers(1, &vbo); glBindBuffer(GL_ARRAY_BUFFER, vbo); glBufferData(GL_ARRAY_BUFFER, vb.size() * 4, vb.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 32, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 32, (void*)12);
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 32, (void*)24);
    glGenBuffers(1, &ibo); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, m.idx.size() * 2, m.idx.data(), GL_STATIC_DRAW);
    idxCount = (int)m.idx.size();
    glBindBuffer(GL_ARRAY_BUFFER, gNearVBO);                                   // per-instance (x, z, scale, rotation, y)
    glEnableVertexAttribArray(3); glVertexAttribPointer(3, 4, GL_FLOAT, GL_FALSE, 20, (void*)0); glVertexAttribDivisor(3, 1);
    glEnableVertexAttribArray(4); glVertexAttribPointer(4, 1, GL_FLOAT, GL_FALSE, 20, (void*)16); glVertexAttribDivisor(4, 1);
    glBindVertexArray(0);
}

static void setMeshUniforms(const float* VP, const float* eye, float t){
    glUseProgram(gMeshProg);
    glUniformMatrix4fv(uM_VP, 1, GL_FALSE, VP); glUniform1f(uM_Wind, t); glUniform3fv(uM_Cam, 1, eye); glUniform1i(uM_Tex, 0);
}
static void drawModel(int instances){
    glActiveTexture(GL_TEXTURE0);
    // bark
    glBindTexture(GL_TEXTURE_2D, gBarkTex); glUniform1f(uM_Sway, 0); glUniform1f(uM_Alpha, 0); glUniform1f(uM_Leaf, 0);
    glUniform3f(uM_Tint, 1.f, 1.f, 1.f); glUniform3f(uM_Emis, 0.04f, 0.04f, 0.035f);
    glBindVertexArray(gBarkVAO); glDrawElementsInstanced(GL_TRIANGLES, gBarkIdx, GL_UNSIGNED_SHORT, (void*)0, instances);
    // leaves (alpha-tested, swaying, slightly warm green tint + soft green glow like the HTML material)
    glBindTexture(GL_TEXTURE_2D, gLeafTex); glUniform1f(uM_Sway, 1); glUniform1f(uM_Alpha, 0.5f); glUniform1f(uM_Leaf, 1);
    glUniform3f(uM_Tint, 1.0f, 1.05f, 0.88f); glUniform3f(uM_Emis, 0.012f, 0.03f, 0.008f);
    glBindVertexArray(gLeafVAO); glDrawElementsInstanced(GL_TRIANGLES, gLeafIdx, GL_UNSIGNED_SHORT, (void*)0, instances);
    glBindVertexArray(0);
}

// ---------- planting (plantTree / plantGrove / randClear from the HTML) ----------
// Trees stand on the rolling ground (Terrain::fieldH). "Clear" = at least ~16 m from the edge of every road (like farFromRoad(16) in the HTML).
static std::mt19937 gRng(20260101);
static float rnd(){ return std::uniform_real_distribution<float>(0.f, 1.f)(gRng); }
static float gauss(){ return (rnd() + rnd() + rnd() - 1.5f) / 0.75f; }          // ~N(0,1)-ish, in [-2,2]
static bool treeOk(float x, float z, float roadHalfWidth){ (void)roadHalfWidth; return Road::clearance(x, z) > 16.5f && std::fabs(River::riverSd(x, z)) > 34.0 && Terrain::trackDist(x, z) > 12.0 && !Village::blocked(x, z, 5.f) && !Railway::blocked(x, z, 7.0); }   // also off the dirt track (HTML isClear: trackDist > 12)   // also keep the river clear (HTML: |riverSd| < r+32)
static void plant(float x, float z){ const float s = 0.8f + rnd() * 0.9f, r = rnd() * 6.2831853f; gTrees.push_back({x, z, s, r, (float)Terrain::fieldH(x, z)}); }   // stands on the hill
static bool randClear(float rw, float& x, float& z){
    for (int t = 0; t < 60; t++){
        float a = rnd() * 6.2831853f, d = 30.f + rnd() * 640.f; x = std::cos(a) * d; z = std::sin(a) * d;
        if (treeOk(x, z, rw)) return true;
    }
    return false;
}
static int plantGrove(int n, float rad, float rw){
    float cx, cz; if (!randClear(rw, cx, cz)) return 0;
    int done = 0;
    for (int k = 0; k < n * 8 && done < n; k++){
        float x = cx + gauss() * rad * 0.5f, z = cz + gauss() * rad * 0.5f;
        if (!treeOk(x, z, rw)) continue;
        bool tooClose = false;
        for (const Tree& t : gTrees){ float dx = t.x - x, dz = t.z - z; if (dx*dx + dz*dz < 9.f){ tooClose = true; break; } }
        if (tooClose) continue;
        plant(x, z); done++;
    }
    return done;
}
static void plantAll(float roadHalfWidth){
    gTrees.clear(); int guard = 0;
    while ((int)gTrees.size() < GROVE_TREES && guard++ < 400) plantGrove(8 + (int)(rnd() * 11), 14.f + rnd() * 10.f, roadHalfWidth);   // groves of 8-18
    while ((int)gTrees.size() < GREEN_TREES && guard++ < 2000){ float x, z; if (randClear(roadHalfWidth, x, z)) plant(x, z); }          // lone trees
    gIsNear.assign(gTrees.size(), 0);
}

// ---------- billboard bake: render the tree once from the side into a texture ----------
static void bakeBillboard(const TreeModel::Model& M){
    gBbHalfW = M.halfWidth * 1.02f; gBbY0 = M.minY; float y1 = M.maxY * 1.01f; gBbH = y1 - gBbY0;
    const int W = 256; int H = std::max(64, (int)std::lround(W * gBbH / (2 * gBbHalfW) / 8.0) * 8); if (H > 512) H = 512;   // 256 px wide: a sharp picture of the real tree
    GLint oldFbo = 0, vp[4]; glGetIntegerv(GL_FRAMEBUFFER_BINDING, &oldFbo); glGetIntegerv(GL_VIEWPORT, vp);
    glGenTextures(1, &gBillTex); glBindTexture(GL_TEXTURE_2D, gBillTex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, W, H, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    GLuint fbo, depth; glGenFramebuffers(1, &fbo); glBindFramebuffer(GL_FRAMEBUFFER, fbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, gBillTex, 0);
    glGenRenderbuffers(1, &depth); glBindRenderbuffer(GL_RENDERBUFFER, depth);
    glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT16, W, H);
    glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, depth);
    if (glCheckFramebufferStatus(GL_FRAMEBUFFER) == GL_FRAMEBUFFER_COMPLETE){
        glViewport(0, 0, W, H); glClearColor(0, 0, 0, 0); glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        glEnable(GL_DEPTH_TEST);
        float P[16] = {0}; P[0] = 1.f / gBbHalfW; P[5] = 2.f / gBbH; P[10] = -0.01f; P[13] = -(y1 + gBbY0) / gBbH; P[15] = 1;   // side-on orthographic
        const float one[5] = {0, 0, 1, 0, 0}, eye[3] = {0, 0, 0};
        glBindBuffer(GL_ARRAY_BUFFER, gNearVBO); glBufferData(GL_ARRAY_BUFFER, sizeof(one), one, GL_STREAM_DRAW);
        setMeshUniforms(P, eye, 0.f); drawModel(1);
    }
    glBindFramebuffer(GL_FRAMEBUFFER, oldFbo); glDeleteRenderbuffers(1, &depth); glDeleteFramebuffers(1, &fbo);
    glViewport(vp[0], vp[1], vp[2], vp[3]);
    glBindTexture(GL_TEXTURE_2D, gBillTex); glGenerateMipmap(GL_TEXTURE_2D);
}

// ---------- public API ----------
static bool gReady = false;

// Call once with a current GL context. rawBlob = tree_raw.bin, meta = tree_meta.txt, leafTex/barkTex = *.rgba assets.
static bool init(const std::vector<char>& rawBlob, const std::vector<char>& meta, const std::vector<char>& leafTex,
                 const std::vector<char>& barkTex, float roadHalfWidth){
    TreeModel::Meta M; if (!TreeModel::parseMeta(std::string(meta.begin(), meta.end()), M)) return false;
    if (rawBlob.size() < (size_t)(M.t0 + M.t1)) return false;
    TreeModel::Model model;
    if (!TreeModel::parse((const uint8_t*)rawBlob.data(), rawBlob.size() - M.t0 - M.t1, M, model)) return false;

    gMeshProg = makeProg(MESH_VS, MESH_FS); gBillProg = makeProg(BILL_VS, BILL_FS);
    uM_VP = glGetUniformLocation(gMeshProg, "uVP"); uM_Wind = glGetUniformLocation(gMeshProg, "uWind"); uM_Sway = glGetUniformLocation(gMeshProg, "uSway");
    uM_Tex = glGetUniformLocation(gMeshProg, "uTex"); uM_Cam = glGetUniformLocation(gMeshProg, "uCam"); uM_Tint = glGetUniformLocation(gMeshProg, "uTint");
    uM_Emis = glGetUniformLocation(gMeshProg, "uEmis"); uM_Alpha = glGetUniformLocation(gMeshProg, "uAlpha"); uM_Leaf = glGetUniformLocation(gMeshProg, "uLeaf");
    uB_VP = glGetUniformLocation(gBillProg, "uVP"); uB_Right = glGetUniformLocation(gBillProg, "uRight"); uB_Size = glGetUniformLocation(gBillProg, "uSize");
    uB_Tex = glGetUniformLocation(gBillProg, "uTex"); uB_Cam = glGetUniformLocation(gBillProg, "uCam");

    glGenBuffers(1, &gNearVBO); glGenBuffers(1, &gFarVBO);
    gLeafTex = makeTexture(leafTex); gBarkTex = makeTexture(barkTex);
    makePart(model.leaf, gLeafTex, gLeafVAO, gLeafVBO, gLeafIBO, gLeafIdx);
    makePart(model.bark, gBarkTex, gBarkVAO, gBarkVBO, gBarkIBO, gBarkIdx);

    const float quad[8] = {-1, 0,  1, 0,  -1, 1,  1, 1};                       // billboard quad: x -1..1, y 0..1
    glGenVertexArrays(1, &gBillVAO); glBindVertexArray(gBillVAO);
    glGenBuffers(1, &gQuadVBO); glBindBuffer(GL_ARRAY_BUFFER, gQuadVBO); glBufferData(GL_ARRAY_BUFFER, sizeof(quad), quad, GL_STATIC_DRAW);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 8, (void*)0);
    glBindBuffer(GL_ARRAY_BUFFER, gFarVBO);
    glEnableVertexAttribArray(3); glVertexAttribPointer(3, 4, GL_FLOAT, GL_FALSE, 20, (void*)0); glVertexAttribDivisor(3, 1);
    glEnableVertexAttribArray(4); glVertexAttribPointer(4, 1, GL_FLOAT, GL_FALSE, 20, (void*)16); glVertexAttribDivisor(4, 1);
    glBindVertexArray(0);

    bakeBillboard(model);
    plantAll(roadHalfWidth);
    gReady = true; return true;
}

// VP = projection*view (column-major), V = view matrix (for the billboard's right vector), eye = camera position
static void draw(const float* VP, const float* V, const float* eye, float timeSec){
    if (!gReady) return;
    static std::vector<float> nearB, farB; nearB.clear(); farB.clear();
    const float n2 = NEAR_DIST * NEAR_DIST, h2 = (NEAR_DIST + HYST) * (NEAR_DIST + HYST), m2 = MAX_DIST * MAX_DIST;
    float pl[6][4];                                                                   // frustum planes from the column-major view-projection matrix
    for (int i = 0; i < 6; i++){ const int a = i >> 1; const float sg = (i & 1) ? 1.f : -1.f;
        for (int j = 0; j < 4; j++) pl[i][j] = VP[j*4 + 3] + sg * VP[j*4 + a];
        const float l = std::sqrt(pl[i][0]*pl[i][0] + pl[i][1]*pl[i][1] + pl[i][2]*pl[i][2]); if (l > 1e-6f) for (int j = 0; j < 4; j++) pl[i][j] /= l; }
    for (size_t k = 0; k < gTrees.size(); k++){
        const Tree& t = gTrees[k]; float dx = t.x - eye[0], dz = t.z - eye[2], d2 = dx*dx + dz*dz;
        if (d2 > m2) { gIsNear[k] = 0; continue; }                                      // too far: culled
        { const float cy = t.y + 3.f * t.s, rad = CULL_R * t.s; bool out = false;      // outside the view: culled (no draw, no GPU upload)
          for (int i = 0; i < 6 && !out; i++) if (pl[i][0]*t.x + pl[i][1]*cy + pl[i][2]*t.z + pl[i][3] < -rad) out = true;
          if (out) continue; }
        bool near = gIsNear[k] ? d2 < h2 : d2 < n2; gIsNear[k] = near;               // hysteresis so trees do not flicker between LODs
        std::vector<float>& B = near ? nearB : farB; B.push_back(t.x); B.push_back(t.z); B.push_back(t.s); B.push_back(t.r); B.push_back(t.y);
    }
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glActiveTexture(GL_TEXTURE0);
    int nn = (int)(nearB.size() / 5), nf = (int)(farB.size() / 5);
    if (nn){
        glBindBuffer(GL_ARRAY_BUFFER, gNearVBO); glBufferData(GL_ARRAY_BUFFER, nearB.size() * 4, nearB.data(), GL_STREAM_DRAW);
        setMeshUniforms(VP, eye, timeSec); drawModel(nn);
    }
    if (nf){
        glBindBuffer(GL_ARRAY_BUFFER, gFarVBO); glBufferData(GL_ARRAY_BUFFER, farB.size() * 4, farB.data(), GL_STREAM_DRAW);
        glUseProgram(gBillProg); glUniformMatrix4fv(uB_VP, 1, GL_FALSE, VP); glUniform3fv(uB_Cam, 1, eye); glUniform1i(uB_Tex, 0);
        float rx = V[0], rz = V[8], l = std::sqrt(rx*rx + rz*rz); if (l < 1e-6f) l = 1;                  // camera-right, kept horizontal
        glUniform3f(uB_Right, rx / l, 0.f, rz / l); glUniform3f(uB_Size, gBbHalfW, gBbY0, gBbH);
        glBindTexture(GL_TEXTURE_2D, gBillTex);
        glBindVertexArray(gBillVAO); glDrawArraysInstanced(GL_TRIANGLE_STRIP, 0, 4, nf); glBindVertexArray(0);
    }
}

// =====================================================================================================================
// Pine & spruce forest: dark green cones planted densely on the mountain slopes, along the roads and on the foothills.
// Three levels of detail (full cones close, simple cones in the middle, 2-cone "needle" far away), all instanced:
// one draw call per species and level (6 in total), distance + frustum culled on the CPU.
// =====================================================================================================================
static const char* CO_VS =
    "#version 300 es\n"
    "layout(location=0) in vec3 p; layout(location=1) in vec3 n; layout(location=2) in vec3 c; layout(location=3) in vec4 inst; layout(location=4) in float instY; layout(location=5) in vec2 uv; layout(location=6) in float fl; layout(location=7) in vec2 sway;\n"
    "uniform mat4 uVP; uniform float uTime; out vec3 vc; out vec3 vn; out vec3 wp; out vec2 vuv; out vec2 vsh; flat out float vfl;\n"
    "void main(){\n"
    " float cs = cos(inst.w), sn = sin(inst.w); mat3 Ry = mat3(cs,0.,-sn, 0.,1.,0., sn,0.,cs);\n"
    " vec3 q = p; float hh = max(q.y, 0.0)/16.0;\n"                                            // wind: the whole tree leans a little, branches also flutter
    " float ph = uTime*1.4 + inst.x*0.11 + inst.y*0.07;\n"
    " q.x += sin(ph)*0.35*hh*hh; q.z += cos(ph*0.8)*0.22*hh*hh;\n"
    " if (fl > 2.5){ float fw = uTime*3.1 + p.x*1.9 + p.z*1.5 + inst.x*0.3; q.y += sin(fw)*0.07; q.x += cos(fw*0.9)*0.05; }\n"
     " if (fl > 0.5 && fl < 1.5) q.y += sin(uTime*2.6 + p.x*2.1 + p.z*1.7 + inst.x*0.3)*0.10*uv.x*uv.x;\n"
    " vsh = vec2(length(p.xz)/4.0, clamp(p.y/16.0, 0.0, 1.0));\n"
    " wp = Ry*(q*inst.z) + vec3(inst.x, instY, inst.y); vn = Ry*n; vuv = uv; vfl = fl;\n"
    " wp.xz += sway * (hh*hh);\n"                                                            // a tree hit by the car swings: the foot stays, the crown moves most
    " float v = fract(sin(dot(inst.xy, vec2(12.9898, 78.233))) * 43758.5453);\n"      // each tree a slightly different green
    " vc = c * (0.85 + 0.32*v) * mix(vec3(1.0), vec3(1.08, 1.0, 0.86), fract(v*7.3));\n"
    " gl_Position = uVP*vec4(wp,1.);\n"
    "}";
static const char* CO_FS =
    "#version 300 es\nprecision highp float;\n"
    "in vec3 vc; in vec3 vn; in vec3 wp; in vec2 vuv; in vec2 vsh; flat in float vfl; uniform vec3 uCam; uniform float uBake; uniform float uLow; out vec4 o;\n"
    "float h3(vec3 p){ p = fract(p*0.1031); p += dot(p, p.yzx + 33.33); return fract((p.x + p.y)*p.z); }\n"
    "void main(){\n"
    " vec3 V = uCam - wp; float dist = length(V); V /= dist;\n"
    " vec3 N = normalize(vn); if (!gl_FrontFacing) N = -N;\n"
    " vec3 L = (uBake > 0.5) ? normalize(vec3(0.4, 0.8, 0.3)) : SUNL;\n"
    " float nd = dot(N, L); float d = max(nd, 0.0), wrap = max(nd*0.5 + 0.5, 0.0);\n"
    " vec3 alb = vc; float nor = step(1.15, vfl)*step(vfl, 1.35); float fir = step(1.35, vfl)*step(vfl, 1.5); float lar = step(1.05, vfl)*step(vfl, 1.15);\n"
    " if (vfl > 3.1){\n"
     " float sv = vuv.y, su = vuv.x; vec2 q = vec2(su*0.52, sv) - vec2(0.0, 0.30); float r = length(q), an = atan(q.x, q.y); float R = 0.0, vd = 9.0;\n"
     " for (int k = 0; k < 5; k++){ float a0 = (float(k) - 2.0)*0.78; float w = k == 2 ? 1.0 : ((k == 1 || k == 3) ? 0.84 : 0.56); float da = an - a0; R = max(R, w*pow(max(cos(min(abs(da), 1.43)*2.2), 0.0), 1.4)); vd = min(vd, abs(sin(da))*r); }\n"
     " R = (0.14 + 0.52*R) * (1.0 + 0.06*sin(an*34.0 + sv*3.0)); bool pet = abs(su*0.52) < 0.018 && sv < 0.30;\n"
     " if (r > R && !pet) discard;\n"
     " float vein = (1.0 - smoothstep(0.0, 0.014, vd)) * step(r, R*0.97) * step(0.0, q.y + 0.25);\n"
     " alb *= (0.88 + 0.20*sv) * (1.0 - 0.16*smoothstep(0.80, 1.0, r/max(R, 0.01)));\n"
     " alb = mix(alb, alb*vec3(1.40, 1.28, 0.90) + vec3(0.02, 0.03, 0.0), vein*0.55);\n"
     " if (pet && r > R) alb = vec3(0.34, 0.40, 0.16);\n"
     " } else if (vfl > 2.5){\n"                                                                          // broadleaf leaf card: lobed leaf outline, midrib, side veins
     "   float sv = vuv.y, su = vuv.x; float wd = sin(3.14159*pow(clamp(sv, 0.0, 1.0), 0.75)) * (0.80 + 0.20*cos(sv*13.0 + 1.0)) * (1.0 - 0.12*abs(sin(sv*40.0)));\n"
     "   if (abs(su) > wd) discard;\n"
     "   float rib = 1.0 - smoothstep(0.0, 0.10, abs(su)); float vein = 1.0 - smoothstep(0.0, 0.10, abs(fract(sv*7.0 - abs(su)*1.6) - 0.5)*2.0 - 0.80);\n"
     "   alb *= (0.90 + 0.22*sv) * (1.0 + 0.30*rib) * (1.0 + 0.08*vein);\n"
     "   alb = mix(alb, alb*vec3(0.80, 0.95, 0.75), smoothstep(0.55, 1.0, abs(su)/max(wd, 0.05))*0.5);\n"
     " } else if (vfl > 1.5){\n"                                                                          // trunk: vertical bark furrows
    "  float br = h3(floor(vec3(wp.x*7.0, wp.y*0.7, wp.z*7.0))); float pl = h3(floor(vec3(wp.x*3.0, wp.y*2.2, wp.z*3.0))); alb *= (0.65 + 0.7*br) * (0.80 + 0.40*pl);"
    " } else if (vfl > 0.5){\n"                                                                  // a branch: needles combed along both sides of a brown stem
    "   float sd = abs(vuv.y); float stem = 1.0 - smoothstep(0.02, 0.05, sd);\n"
    "   float pos = vuv.x*(uLow > 0.5 ? 13.0 : 30.0)*(1.0 + 0.45*nor + 0.35*fir - 0.30*lar) - sd*3.6 + step(0.0, vuv.y)*0.5; float id = floor(pos); float s = fract(pos);\n"
    "   float rn = (dist < 70.0 && uLow < 0.5) ? h3(vec3(id, step(0.0, vuv.y), floor(wp.x*0.5 + wp.z*0.5))) : fract(id*0.618 + step(0.0, vuv.y)*0.37);\n"                  // every needle: its own length, tone
    "   float nd = smoothstep(0.0, 0.12, s) * (1.0 - smoothstep(0.50, 0.72, s));\n"
    "   float tuft = 1.0 - abs(fract(vuv.x*8.0 + rn*0.2) - 0.5)*2.0; float reach = (0.55 + 0.45*rn + 0.20*nor + 0.20*fir + lar*(0.25 + 0.30*tuft)) * (1.0 - (0.45 - 0.20*lar)*vuv.x) * mix(1.0, 0.35 + 0.65*smoothstep(0.1, 0.6, tuft), lar);\n"
    "   if (max(nd*step(sd, reach), stem) < 0.42) discard;\n"
    "   alb *= (0.85 + 0.35*rn) * (0.93 + 0.17*sd) * (0.50 + 0.50*smoothstep(0.0, 0.55, vuv.x));\n"                                            // paler needle tips, darker near the stem (self-shadow)
    "   alb = mix(alb, vec3(0.24, 0.16, 0.09), stem*0.35);\n"
    "   alb *= mix(0.55, 1.0, smoothstep(0.0, 0.9, vsh.x)) * (0.80 + 0.28*vsh.y);\n"
    "   alb = mix(alb, vec3(0.17, 0.30, 0.08), nor*smoothstep(0.62, 1.0, vuv.x)*0.45*rn);\n"
    "   alb = mix(alb, vec3(0.42, 0.56, 0.15), lar*(0.35 + 0.35*rn));\n"
    "   alb *= 1.0 + fir*0.20*(h3(vec3(floor(vuv.x*11.0), step(0.0, vuv.y), id*0.09)) - 0.5);\n"
    "   alb = mix(alb, vec3(0.50, 0.58, 0.50)*dot(alb, vec3(0.6)) *2.6, fir*smoothstep(0.05, -0.30, V.y)*0.60);\n"
    "   alb *= 1.0 + nor*0.25*(h3(vec3(floor(vuv.x*9.0), step(0.0, vuv.y), id*0.07)) - 0.5);\n"
    " } else if (dist < 160.0 && uLow < 0.5){ float nz = h3(floor(wp*vec3(2.2, 3.4, 2.2))) * 0.6 + h3(floor(wp*vec3(5.5, 8.0, 5.5))) * 0.4;\n"   // needle clumps / branch lumps
    "   alb *= mix(1.0, 0.80 + 0.45*nz, 1.0 - smoothstep(60.0, 160.0, dist)); }\n"
    " vec3 sky = vec3(0.50, 0.66, 0.95), gnd = vec3(0.26, 0.30, 0.18);\n"
    " vec3 amb = mix(gnd, sky, N.y*0.5 + 0.5) * 0.95 + vec3(0.06, 0.09, 0.05);\n"
    " vec3 col = alb * (amb + vec3(1.10, 1.00, 0.82)*(0.62*d + 0.32*wrap));\n"
    " col += alb * vec3(0.70, 0.85, 0.20) * lar * pow(max(dot(-V, L), 0.0), 2.0) * 0.18;\n"
    " if (vfl > 1.15 && vfl < 1.35) col += vec3(0.55, 0.62, 0.45) * pow(max(dot(reflect(-L, N), V), 0.0), 14.0) * 0.07 * max(nd, 0.0);\n"
    " if (vfl > 2.9 && vfl < 3.3) col += vec3(0.60, 0.70, 0.50) * pow(max(dot(reflect(-L, N), V), 0.0), 22.0) * 0.14 * max(nd, 0.0);\n"                // glossy ivy leaves
    " col += alb * vec3(0.78, 0.92, 0.32) * pow(max(dot(-V, L), 0.0), 2.5) * 0.20;\n"                  // sun shining through the needles
    " col += vec3(0.34, 0.44, 0.32) * pow(1.0 - max(dot(N, V), 0.0), 3.0) * 0.06;\n"                     // soft sky rim
    " float lum = dot(col, vec3(0.299, 0.587, 0.114)); col = mix(vec3(lum), col, 0.90);\n col = pow(col, vec3(0.97));\n"
    " float fog = 1.0 - exp(-pow(dist/2850.0, 1.35));\n"
    " col = mix(col, vec3(0.72, 0.87, 0.98), clamp(fog, 0.0, 1.0));\n"
    " o = vec4(col, 1.0);\n"
    "}";

// ---- far trees as camera-facing billboards (Normal quality): the tree is baked once from the side into a texture and drawn as one quad that always turns to the camera ----
static const char* CB_VS =
    "#version 300 es\n"
    "layout(location=0) in vec2 q; layout(location=3) in vec4 inst; layout(location=4) in float instY;\n"
    "uniform mat4 uVP; uniform vec3 uCam; uniform vec3 uSize; uniform float uTime; out vec2 vuv; out vec3 vtint; out float vdist; flat out vec2 vlay; flat out float vmix;\n"      // uSize = half width, bottom y, height (tree scale 1)
    "void main(){\n"
    " vec2 d = uCam.xz - inst.xy; float l = max(length(d), 1e-3); vec2 f = d / l;\n"
    " vec3 right = vec3(f.y, 0., -f.x);\n"                                                                      // upright, turns round the vertical axis to face the camera
    " vec3 base = vec3(inst.x, instY, inst.y);\n"
    " vec3 wp = base + right * (q.x * uSize.x * inst.z) + vec3(0., uSize.y + q.y * uSize.z, 0.) * inst.z;\n"
    " { float hh = max(uSize.y + q.y * uSize.z, 0.0) / 16.0; float ph = uTime*1.4 + inst.x*0.11 + inst.y*0.07;\n"          // same wind lean as the 3D tree
    "   vec2 sw = vec2(sin(ph)*0.35, cos(ph*0.8)*0.22) * hh*hh * inst.z; float cs = cos(inst.w), sn = sin(inst.w);\n"
    "   wp.x += cs*sw.x + sn*sw.y; wp.z += -sn*sw.x + cs*sw.y; }\n"
    " vuv = vec2(q.x * 0.5 + 0.5, q.y);\n"
    // which of the 8 baked views (taken from 8 directions round the tree) looks like the real tree from here: the two nearest are cross-faded
    " float ang = atan(f.x, f.y); if (ang < 0.) ang += 6.2831853;\n"
    " float u = ang * (8.0 / 6.2831853); float l0 = floor(u); vmix = u - l0; if (l0 >= 8.) l0 -= 8.;\n"
    " vlay = vec2(l0, (l0 >= 7.) ? 0. : l0 + 1.);\n"
    " float v = fract(sin(dot(inst.xy, vec2(12.9898, 78.233))) * 43758.5453);\n"                                  // same per-tree green variation as the 3D trees
    " vtint = (0.85 + 0.32 * v) / 0.85 * mix(vec3(1.0), vec3(1.08, 1.0, 0.86), fract(v * 7.3));\n"
    " vdist = length(uCam - base);\n"
    " gl_Position = uVP * vec4(wp, 1.);\n"
    "}";
static const char* CB_FS =
    "#version 300 es\nprecision mediump float; precision mediump sampler2DArray;\n"
    "in vec2 vuv; in vec3 vtint; in float vdist; flat in vec2 vlay; flat in float vmix; uniform sampler2DArray uTex; out vec4 o;\n"
    "void main(){\n"
    " vec4 t = mix(texture(uTex, vec3(vuv, vlay.x)), texture(uTex, vec3(vuv, vlay.y)), vmix);\n"
    " float nz = fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453);\n"      // dither: soft, leafy edge instead of a hard cut-out
    " if (t.a < 0.25 + 0.3 * nz) discard;\n"
    " vec3 c = t.rgb / max(t.a, 0.001) * vtint;\n"
    " float lum = dot(c, vec3(0.33));\n"
    " c *= mix(0.72, 1.12, smoothstep(0.0, 0.9, vuv.y));\n"                                          // darker low inside the crown, lighter at the top = depth like a 3D tree
    " c = mix(c, c * (0.82 + 0.5 * lum) * vec3(1.02, 1.0, 0.94), 0.5);\n"                           // extra leaf-contrast so it is not a flat colour
    " c *= 0.9 + 0.2 * fract(sin(dot(floor(vuv * vec2(46., 92.)), vec2(12.9898, 78.233))) * 43758.5453);\n"
    " vec2 cl = floor(vuv * vec2(9., 18.)); float cn = fract(sin(dot(cl, vec2(41.3, 17.7))) * 9341.7);\n"   // big leaf clumps: some lit, some in shade
    " c *= 0.8 + 0.4 * cn;\n"
    " c = mix(vec3(dot(c, vec3(0.33))), c, 1.15);\n"                                                  // slightly richer colour
    " c += vec3(0.05, 0.045, 0.02) * smoothstep(0.55, 1.0, vuv.y) * (1.0 - t.a * 0.3);\n"              // sunlit top edge   // fine leaf/needle speckle
    " float fg = 1.0 - exp(-pow(vdist / 2000.0, 1.25));\n"
    " o = vec4(mix(c, vec3(0.72, 0.87, 0.98), clamp(fg, 0.0, 1.0)), 1.0);\n"
    "}";
const int CB_VIEWS = 8, CB_W = 384, CB_H = 768;   // 8 views round the tree, each a lit 384x768 picture (keep CB_VIEWS = 8 in sync with the shader)
static GLuint gCbProg = 0, gCbTex[N_SP] = {0, 0, 0, 0, 0, 0, 0}, gCbVAO[N_SP] = {0, 0, 0, 0, 0, 0, 0}, gCbInst[N_SP] = {0, 0, 0, 0, 0, 0, 0}, gCbQuad = 0;
static float gCbHW[N_SP] = {1, 1, 1, 1, 1, 1, 1}, gCbY0[N_SP] = {0, 0, 0, 0, 0, 0, 0}, gCbH[N_SP] = {1, 1, 1, 1, 1, 1, 1};
static GLint uCb_VP = -1, uCb_Cam = -1, uCb_Size = -1, uCb_Tex = -1, uCb_Time = -1;
static bool gCbReady = false;
const float CO_BB_DIST = 330.f;   // billboards start where the 3D tree has already faded to its flat far colour, so there is no visible switch

struct CoTree { float x, z, s, r, y; uint8_t sp; };
static inline float coCrown(uint8_t sp){ return sp == 0 ? 2.7f : (sp == 2 ? 2.5f : (sp == 3 ? 3.2f : (sp == 4 ? 2.3f : (sp == 5 ? 4.2f : (sp == 6 ? 2.8f : 3.5f))))); }   // crown radius (m, scale 1) for the trunk / crown collision
static std::vector<CoTree> gCo;
static GLuint gCoProg = 0, gCoVAO[N_SP][5], gCoVBO[N_SP][5], gCoIBO[N_SP][5], gCoInst[N_SP][5]; static int gCoIdx[N_SP][5]; static GLint uCo_VP = -1, uCo_Cam = -1, uCo_Time = -1, uCo_Bake = -1, uCo_Low = -1;
static bool gCoReady = false;
// climbing vines: some conifers (about VINE_SHARE of species 0-4) carry two spiralling ivy-like vines on the trunk; one shared mesh, drawn instanced for the nearby vine trees
static GLuint gVineVAO = 0, gVineVBO = 0, gVineIBO = 0, gVineInst = 0; static int gVineIdx = 0;
const float VINE_SHARE = 0.25f, VINE_DIST = 90.f; const size_t VINE_MAX = 48;   // at most 48 vine trees per frame (the vine mesh is detailed)
static inline bool coHasVine(float x, float z, uint8_t sp){
    if (sp > 4) return false;
    float h = std::sin(x * 12.9898f + z * 78.233f) * 43758.5453f; h -= std::floor(h);
    return h < VINE_SHARE;
}
const float CO_MAX_DIST = 2300.f, CO_LOD0 = 80.f, CO_LOD1 = 260.f;

// Planting is spread over many frames (time-sliced) so the game starts at once instead of freezing while ~28000 trees are placed.
// Trees that are planted but not "loaded" yet (planting still running) are drawn as 2D pictures (billboards) only; the 3D models switch on when loading is done.
static bool gCoDone = false;                       // true once every tree is planted (3D models + collision are enabled then)
struct CoPlanter { std::mt19937 rng{0x5eed1234u}; std::unordered_set<long long> used; int phase = 0, t = 0, n = 0; };
static CoPlanter gPl;

// plant for at most budgetSec seconds; returns true when ALL trees are planted
static bool coPlantStep(double budgetSec){
    using Clk = std::chrono::steady_clock; const Clk::time_point t0 = Clk::now();
    auto over = [&]{ return std::chrono::duration<double>(Clk::now() - t0).count() > budgetSec; };
    CoPlanter& P = gPl; auto U = [&]{ return std::uniform_real_distribution<float>(0.f, 1.f)(P.rng); };
    auto freeCell = [&](float x, float z, float cell){ const long long k = ((long long)std::floor(x / cell) << 32) ^ (long long)(std::floor(z / cell) + 100000); return P.used.insert(k).second; };
    auto hs = [](float x, float y){ const float h = std::sin(x*127.1f + y*311.7f) * 43758.5453f; return h - std::floor(h); };
    auto vn = [&](float x, float y){ const float ix = std::floor(x), iy = std::floor(y), fx = x - ix, fy = y - iy, u = fx*fx*(3 - 2*fx), v = fy*fy*(3 - 2*fy);
        return (hs(ix, iy)*(1-u) + hs(ix+1, iy)*u)*(1-v) + (hs(ix, iy+1)*(1-u) + hs(ix+1, iy+1)*u)*v; };
    auto clump = [&](float x, float z){ return 0.65f*vn(x*0.012f + 9.f, z*0.012f + 4.f) + 0.35f*vn(x*0.05f, z*0.05f); };   // forest patches with glades
    auto sstep = [](float a, float b, float x){ x = std::min(1.f, std::max(0.f, (x - a) / (b - a))); return x*x*(3 - 2*x); };
    auto ground = [&](float x, float z){ return Terrain::inLattice(x, z) ? (float)Terrain::fieldH(x, z) : (float)Terrain::outerH(x, z); };
    auto add = [&](float x, float z, float y, float s){ // species by place (altitude + distance to the river), like a real Swiss valley: broadleaf maple / rowan on the valley floor and by the water,
        //   spruce + silver fir on the lower slopes, spruce + larch higher up, larch + pine (+ a few spruce) at the tree line
        //   species: 0 spruce, 1 pine, 2 Norway spruce, 3 silver fir, 4 larch, 5 sycamore maple, 6 rowan
        static const float W[4][7] = { {0.03f,0.02f,0.25f,0.15f,0.10f,0.30f,0.15f},     // valley floor / river bank (< 35 m)
                                       {0.04f,0.04f,0.38f,0.28f,0.08f,0.12f,0.06f},     // lower slopes (35 - 110 m)
                                       {0.06f,0.10f,0.38f,0.04f,0.32f,0.00f,0.10f},     // upper slopes (110 - 190 m)
                                       {0.08f,0.22f,0.15f,0.00f,0.50f,0.00f,0.05f} };   // tree line (> 190 m)
        const float rdw = (float)std::fabs(River::riverSd(x, z));
        const int band = (y < 35.f || rdw < 60.f) ? 0 : (y < 110.f ? 1 : (y < 190.f ? 2 : 3));
        const float q = U(); float acc = 0.f; uint8_t sp = 2;
        for (int k = 0; k < 7; k++){ acc += W[band][k]; if (q < acc){ sp = (uint8_t)k; break; } }
        if (band >= 2) s *= 1.f - 0.25f * sstep(110.f, 230.f, y);                         // smaller trees higher up
        if (sp == 2) s *= 1.12f; else if (sp == 3) s *= 1.15f; else if (sp == 4) s *= 1.08f; else if (sp == 5) s *= 0.95f; else if (sp == 6) s *= 0.78f;   // Norway spruce / silver fir / larch grow a little taller
        gCo.push_back({x, z, s, U() * 6.2831853f, y, sp}); };
    int& t = P.t; int& n = P.n;

    // 1) along the roads: only a few scattered groves now (was dense bands of forest) - the roadsides are open alpine meadow
    //    with grass, wildflowers and shrubs (meadow_render.h). Trees stay >= 22 m off the road edge and only grow in the thickest forest patches.
    if (P.phase == 0){
        for (; t < 400000 && n < 1300; t++){
            if ((t & 63) == 0 && over()) return false;
            const float x = (U() * 2 - 1) * 1350.f, z = (U() * 2 - 1) * 960.f;
            const float c = Road::clearance(x, z); if (c < 11.f || c > 75.f) continue;
            if (c < 22.f){                                                                                  // a lone big larch / maple now and then close to the road: an eye-catcher
                if (U() > 0.010f) continue;
                if (Village::blocked(x, z, 8.f) || Tunnel::blocked(x, z, 8.0) || Railway::blocked(x, z, 7.0) || !freeCell(x, z, 40.f)) continue;
                if (std::fabs(River::riverSd(x, z)) < 36.0 || Terrain::trackDist(x, z) < 14.0) continue;
                gCo.push_back({x, z, 1.25f + U() * 0.30f, U() * 6.2831853f, ground(x, z), (uint8_t)(U() < 0.5f ? 4 : 5)}); n++; continue;
            }
            const float p = (0.03f + 0.55f * sstep(0.50f, 0.68f, clump(x, z))) * (1.f - 0.5f * sstep(40.f, 75.f, c)) * 0.45f; if (U() > p) continue;   // seeds of little groves
            if (Village::blocked(x, z, 6.f) || Tunnel::blocked(x, z, 8.0) || Railway::blocked(x, z, 7.0) || !freeCell(x, z, 5.f)) continue;
            if (std::fabs(River::riverSd(x, z)) < 36.0 || Terrain::trackDist(x, z) < 9.0) continue;
            const float gs = 0.75f + U() * 0.65f; const int before = (int)gCo.size(); add(x, z, ground(x, z), gs); n++;
            const uint8_t gsp = gCo.back().sp; const int extra = 2 + (int)(U() * 4.f);                       // 3-6 trees of ONE species per grove, then open meadow
            for (int e = 0; e < extra; e++){
                const float ang = U() * 6.2831853f, rr = 6.f + U() * 4.f, ex = x + std::cos(ang) * rr, ez = z + std::sin(ang) * rr;
                if (Road::clearance(ex, ez) < 22.f || Village::blocked(ex, ez, 6.f) || Tunnel::blocked(ex, ez, 8.0) || Railway::blocked(ex, ez, 7.0) || !freeCell(ex, ez, 5.f)) continue;
                if (std::fabs(River::riverSd(ex, ez)) < 36.0 || Terrain::trackDist(ex, ez) < 9.0) continue;
                gCo.push_back({ex, ez, gs * (0.7f + U() * 0.8f), U() * 6.2831853f, ground(ex, ez), gsp}); n++;
            }
            (void)before;
        }
        P.phase = 1; t = 0; n = 0;
    }
    // 2) foothills between the playable ground and the mountain ring
    if (P.phase == 1){
        for (; t < 90000 && n < 3600; t++){
            if ((t & 63) == 0 && over()) return false;
            const float a = U() * 6.2831853f, r = 960.f + U() * 360.f, x = std::cos(a) * r, z = std::sin(a) * r;
            if (clump(x, z) < 0.40f && U() > 0.25f) continue;
            if (Terrain::lakeDn(x, z) < 1.95) continue;                                                    // no trees in the lake
            if (Road::clearance(x, z) < 12.f || Village::blocked(x, z, 6.f) || Tunnel::blocked(x, z, 8.0) || Railway::blocked(x, z, 7.0) || !freeCell(x, z, 6.f)) continue;
            if (std::fabs(River::riverSd(x, z)) < 40.0 || Terrain::trackDist(x, z) < 9.0) continue;
            add(x, z, ground(x, z), 0.9f + U() * 0.8f); n++;
        }
        P.phase = 2; t = 0; n = 0;
    }
    // 3) mountain slopes: forest up to the tree line (~230 m), thinning out; none on cliffs
    if (P.phase == 2){
        for (; t < 240000 && n < 19000; t++){
            if ((t & 63) == 0 && over()) return false;
            const float a = U() * 6.2831853f, r = (float)Terrain::MTN_R0 + 15.f + U() * (float)(Terrain::MTN_R1 - Terrain::MTN_R0 - 30.f), x = std::cos(a) * r, z = std::sin(a) * r;
            const float h = (float)Terrain::mtnH(x, z); if (h < 0.f) continue;
            const float tl = 1.f - sstep(150.f, 250.f, h + (vn(x*0.02f, z*0.02f) - 0.5f) * 90.f); if (U() > tl) continue;              // tree line
            const float cl = clump(x, z); if (U() > 0.35f + 0.65f * sstep(0.30f, 0.55f, cl)) continue;                                   // glades
            const float sx = (float)(Terrain::mtnH(x + 10, z) - Terrain::mtnH(x - 10, z)) / 20.f, sz = (float)(Terrain::mtnH(x, z + 10) - Terrain::mtnH(x, z - 10)) / 20.f;
            if (std::sqrt(sx*sx + sz*sz) > 0.85f) continue;                                                                               // too steep for trees
            if (Terrain::lakeDn(x, z) < 1.95) continue;
            if (NatureFx::nearFall(x, z, 9.f)) continue;                                                                                  // keep the waterfall clear
            if (!freeCell(x, z, 7.f)) continue;
            if (std::fabs(River::riverSd(x, z)) < 40.0) continue;
            add(x, z, h - 0.5f, 1.2f + U() * 1.0f); n++;                                                                                  // bigger trees: still readable from 1 km
        }
        P.phase = 3; t = 0; n = 0;
    }
    // 4) PINE FOREST on the foot of the big (drivable) mountain: dense at the bottom, thinning out as the slope climbs, none on the upper meadow / summit.
    //    Mostly pine (species 1) with some spruce / fir; kept clear of the road, the summit pad, the river, the lake, the village, the tunnel and the dirt track.
    if (P.phase == 3){
        if (!Terrain::PEAK.on){ P.phase = 4; return true; }
        const float pr = (float)Terrain::PEAK.R * 1.30f;
        for (; t < 400000 && n < 4200; t++){
            if ((t & 63) == 0 && over()) return false;
            const float x = (float)Terrain::PEAK.x + (U() * 2 - 1) * pr, z = (float)Terrain::PEAK.z + (U() * 2 - 1) * pr;
            const float hp = (float)Terrain::peakH(x, z); if (hp <= 0.5f) continue;
            const float f = hp / (float)Terrain::PEAK.H;                                                   // 0 = foot .. 1 = summit
            const float dens = 1.f - sstep(0.10f, 0.52f, f + (vn(x*0.03f, z*0.03f) - 0.5f) * 0.14f);       // dense below ~10 % of the height, fading out by ~half way up
            if (U() > dens) continue;
            const float cl = clump(x, z); if (U() > 0.55f + 0.45f * sstep(0.25f, 0.50f, cl)) continue;     // a few glades, mostly solid forest
            if (Terrain::summitCleared(x, z, 10.0)) continue;
            const float c = Road::clearance(x, z); if (c < 14.f) continue;                                // stay off the tarmac and its verge
            if (Terrain::fieldClear(x, z) < 16.0) continue;                                                // the raised road mound / run-out
            const float sx = (float)(Terrain::peakH(x + 8, z) - Terrain::peakH(x - 8, z)) / 16.f, sz = (float)(Terrain::peakH(x, z + 8) - Terrain::peakH(x, z - 8)) / 16.f;
            if (std::sqrt(sx*sx + sz*sz) > 0.85f) continue;                                                // too steep
            if (Terrain::lakeDn(x, z) < 1.95) continue;
            if (Village::blocked(x, z, 6.f) || Tunnel::blocked(x, z, 8.0) || Railway::blocked(x, z, 7.0) || !freeCell(x, z, 5.f)) continue;
            if (std::fabs(River::riverSd(x, z)) < 36.0 || Terrain::trackDist(x, z) < 13.0 || Railway::blocked(x, z, 7.0)) continue;   // the hill road itself is Terrain::TRK (not in Road::clearance)
            if (NatureFx::nearFall(x, z, 9.f)) continue;
            // species by height on the mountain (f = 0 foot .. 1 summit): mixed spruce / fir / maple forest at the foot, spruce + larch in the middle, larch + pine near the top
            static const float WM[3][7] = { {0.04f,0.14f,0.30f,0.30f,0.06f,0.10f,0.06f}, {0.06f,0.18f,0.34f,0.14f,0.22f,0.00f,0.06f}, {0.06f,0.30f,0.12f,0.00f,0.46f,0.00f,0.06f} };
            const int mb = f < 0.25f ? 0 : (f < 0.50f ? 1 : 2);
            const float q = U(); float ac = 0.f; uint8_t sp = 2;
            for (int k = 0; k < 7; k++){ ac += WM[mb][k]; if (q < ac){ sp = (uint8_t)k; break; } }         // 62 % pine, 16 % spruce, 12 % Norway spruce, 10 % silver fir
            float sc = (0.95f + U() * 0.85f) * (1.f - 0.25f * sstep(0.15f, 0.50f, f)); if (sp == 2) sc *= 1.12f; else if (sp == 3) sc *= 1.15f;   // smaller trees higher up
            gCo.push_back({x, z, sc, U() * 6.2831853f, ground(x, z), sp}); n++;
        }
        P.phase = 4; t = 0; n = 0;
    }
    // 5) ROADSIDE TREES where a real road would have them (placed in two passes, spaced so they read as planted / natural rather than a wall):
    //    a) village roads: broad-leaved avenue trees (sycamore maple, rowan, larch) 8-12 m from the tarmac edge in stretches, never closer than 22 m to the next one
    //    b) hill road: a forest edge of pine / spruce / fir 9-15 m from the edge on both sides, thinning out higher up; clear of the guardrail, verge, summit and car park
    if (P.phase == 4){
        for (; t < 520000 && n < 1000; t++){
            if ((t & 63) == 0 && over()) return false;
            if (t < 300000){                                                                                // a) avenue / roadside trees along the village roads
                if (n >= 560) { t = 299999; continue; }
                const float x = (U() * 2 - 1) * 1350.f, z = (U() * 2 - 1) * 960.f;
                const float c = Road::clearance(x, z); if (c < 8.f || c > 12.f) continue;
                if (clump(x * 0.6f + 31.f, z * 0.6f - 17.f) < 0.42f) continue;                              // stretches with trees, stretches without
                if (Village::blocked(x, z, 7.f) || Tunnel::blocked(x, z, 8.0) || Railway::blocked(x, z, 7.0) || !freeCell(x, z, 22.f)) continue;
                if (std::fabs(River::riverSd(x, z)) < 40.0 || Terrain::trackDist(x, z) < 14.0 || NatureFx::nearFall(x, z, 9.f)) continue;
                if (Terrain::PEAK.on && Terrain::summitCleared(x, z, 10.0)) continue;
                const float q = U(); const uint8_t sp = q < 0.40f ? 5 : (q < 0.65f ? 6 : (q < 0.85f ? 4 : 2));
                gCo.push_back({x, z, (sp == 2 ? 0.95f : 1.05f) + U() * 0.35f, U() * 6.2831853f, ground(x, z), sp}); n++;
            } else {                                                                                        // b) forest edge along the hill road
                if (!Terrain::PEAK.on || !Terrain::TRK.on) break;
                const float pr = (float)Terrain::PEAK.R * 1.30f;
                const float x = (float)Terrain::PEAK.x + (U() * 2 - 1) * pr, z = (float)Terrain::PEAK.z + (U() * 2 - 1) * pr;
                const double td = Terrain::trackDist(x, z), hwT = Terrain::TRK_W * 0.5; if (td < hwT + 9.0 || td > hwT + 15.0) continue;
                const float hp = (float)Terrain::peakH(x, z); if (hp <= 0.5f) continue;
                const float f = hp / (float)Terrain::PEAK.H; if (U() > 1.f - sstep(0.30f, 0.62f, f)) continue;   // thins out towards the summit (none on the upper meadow)
                if (clump(x * 0.8f + 5.f, z * 0.8f + 9.f) < 0.38f) continue;
                if (Terrain::summitCleared(x, z, 12.0) || Terrain::fieldClear(x, z) < 16.0) continue;
                if (Road::clearance(x, z) < 14.f || Terrain::lakeDn(x, z) < 1.95) continue;
                const float sx = (float)(Terrain::peakH(x + 8, z) - Terrain::peakH(x - 8, z)) / 16.f, sz = (float)(Terrain::peakH(x, z + 8) - Terrain::peakH(x, z - 8)) / 16.f;
                if (std::sqrt(sx*sx + sz*sz) > 0.85f) continue;
                if (Village::blocked(x, z, 6.f) || Tunnel::blocked(x, z, 8.0) || Railway::blocked(x, z, 7.0) || !freeCell(x, z, 9.f)) continue;
                if (std::fabs(River::riverSd(x, z)) < 36.0 || NatureFx::nearFall(x, z, 9.f)) continue;
                const float q = U(); const uint8_t sp = q < 0.55f ? 1 : (q < 0.72f ? 0 : (q < 0.88f ? 2 : 3));
                const float sc = (0.90f + U() * 0.70f) * (1.f - 0.25f * sstep(0.15f, 0.50f, f));
                gCo.push_back({x, z, sc, U() * 6.2831853f, ground(x, z), sp}); n++;
            }
        }
        P.phase = 5;
    }
    return true;
}

// =====================================================================================================================
// Trunk collision + sway + falling needles
//  * every pine / spruce trunk is solid (3 circles along the car vs a circle for the trunk, found through a 16 m grid)
//  * a hit makes that tree swing (damped oscillation, the crown moves most) and shakes needles loose, which flutter down to the ground
// =====================================================================================================================
static std::unordered_map<long long, std::vector<int>> gCoGrid; static const float CO_CELL = 16.f;
static inline long long coCell(long cx, long cz){ return ((long long)(cx + 100000) << 32) ^ (long long)(cz + 100000); }
struct CoChunk { std::vector<int> idx; float x0, x1, z0, z1, y0, y1; };
static std::vector<CoChunk> gChunks; static bool gChunkBuilt = false;
static void coBuildGrid(){ gCoGrid.clear(); for (size_t k = 0; k < gCo.size(); k++) gCoGrid[coCell((long)std::floor(gCo[k].x / CO_CELL), (long)std::floor(gCo[k].z / CO_CELL))].push_back((int)k); }

struct Sway { int idx = -1; float t = 0, A = 0, dx = 0, dz = 0; };
static Sway gSw[16]; static std::vector<uint8_t> gSwSlot; static int gSwN = 0; static float gSwOff[16][2];
static inline void pushInst(std::vector<float>& v, const CoTree& t, bool withSway){
    v.push_back(t.x); v.push_back(t.z); v.push_back(t.s); v.push_back(t.r); v.push_back(t.y);
    if (!withSway) return;
    float sx = 0, sz = 0;
    if (gSwN){ const size_t k = (size_t)(&t - gCo.data()); if (k < gSwSlot.size() && gSwSlot[k]){ sx = gSwOff[gSwSlot[k] - 1][0]; sz = gSwOff[gSwSlot[k] - 1][1]; } }
    v.push_back(sx); v.push_back(sz);
}
static void swayOffsets(){                       // crown displacement now (metres): damped swing along the push direction
    for (int i = 0; i < 16; i++){ const Sway& w = gSw[i]; if (w.idx < 0) continue;
        const float a = w.A * std::exp(-0.9f * w.t) * std::sin(3.4f * w.t) + 0.12f * w.A * std::exp(-1.6f * w.t) * std::sin(8.5f * w.t);
        gSwOff[i][0] = w.dx * a; gSwOff[i][1] = w.dz * a; }
}

// ---- falling needles / leaves: a small pool of point sprites ----
struct Leaf { float x, y, z, vx, vy, vz, age, life, size, ph, spin; uint8_t kind; bool landed; };
static const int LEAF_MAX = 700; static Leaf gLeaf[LEAF_MAX]; static int gLeafHead = 0, gLeafAlive = 0;
static GLuint gLfProg = 0, gLfVAO = 0, gLfVBO = 0; static GLint uLf_VP = -1, uLf_Scale = -1;
static uint32_t gLfRng = 0x9e3779b9u;
static inline float frnd(){ gLfRng ^= gLfRng << 13; gLfRng ^= gLfRng >> 17; gLfRng ^= gLfRng << 5; return (gLfRng >> 8) / 16777216.f; }
static const char* LF_VS =
    "#version 300 es\n"
    "layout(location=0) in vec4 pa; layout(location=1) in vec4 pc; uniform mat4 uVP; uniform float uScale; out vec3 vcol; out float vrot;\n"
    "void main(){ gl_Position = uVP * vec4(pa.xyz, 1.0); float d = max(gl_Position.w, 0.5);\n"
    " gl_PointSize = (pa.w > 0.001) ? clamp(pa.w * uScale / d, 1.5, 26.0) : 0.0; vcol = pc.rgb; vrot = pc.a; }";
static const char* LF_FS =
    "#version 300 es\nprecision mediump float;\n"
    "in vec3 vcol; in float vrot; out vec4 o;\n"
    "void main(){ vec2 c = gl_PointCoord * 2.0 - 1.0; float cs = cos(vrot), sn = sin(vrot); vec2 r = vec2(cs*c.x - sn*c.y, sn*c.x + cs*c.y);\n"
    " float e = (r.x*r.x) / 0.30 + r.y*r.y * 3.2; if (e > 1.0) discard;\n"                          // a thin leaf / needle tuft
    " o = vec4(vcol * (0.72 + 0.38 * (r.x * 0.5 + 0.5)), 1.0); }";
static void leafInit(){
    gLfProg = makeProg(LF_VS, LF_FS); uLf_VP = glGetUniformLocation(gLfProg, "uVP"); uLf_Scale = glGetUniformLocation(gLfProg, "uScale");
    glGenVertexArrays(1, &gLfVAO); glBindVertexArray(gLfVAO); glGenBuffers(1, &gLfVBO); glBindBuffer(GL_ARRAY_BUFFER, gLfVBO);
    glBufferData(GL_ARRAY_BUFFER, LEAF_MAX * 8 * 4, nullptr, GL_STREAM_DRAW);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 32, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 32, (void*)16);
    glBindVertexArray(0);
    for (Leaf& l : gLeaf) l.life = 0;
    gSwSlot.assign(gCo.size(), 0); for (Sway& w : gSw) w.idx = -1; gSwN = 0;
}
static void spawnLeaves(const CoTree& t, float vx, float vz, int n){
    const float s = t.s, crownR = coCrown(t.sp) * s;
    for (int i = 0; i < n; i++){
        Leaf& l = gLeaf[gLeafHead]; gLeafHead = (gLeafHead + 1) % LEAF_MAX;
        const float h = (2.0f + frnd() * 11.5f) * s, rho = crownR * (1.f - h / (16.f * s)) * (0.2f + 0.9f * frnd()), th = frnd() * 6.2831853f;
        l.x = t.x + std::cos(th) * rho; l.z = t.z + std::sin(th) * rho; l.y = t.y + h;
        l.vx = (frnd() - 0.5f) * 1.2f + vx * 0.10f; l.vz = (frnd() - 0.5f) * 1.2f + vz * 0.10f; l.vy = (frnd() - 0.3f) * 1.0f;
        l.age = 0; l.life = 4.0f + frnd() * 3.5f; l.size = 0.11f + frnd() * 0.10f; l.ph = frnd() * 6.2831853f; l.spin = (frnd() - 0.5f) * 8.f; l.landed = false;
        const float k = frnd(); l.kind = k < 0.45f ? 0 : (k < 0.80f ? 1 : 2);
    }
}
static void hitTree(int k, float nx, float nz, float vx, float vz, float vn){
    const CoTree& t = gCo[k]; if (gSwSlot.size() != gCo.size()) return;
    int slot = gSwSlot[k] ? gSwSlot[k] - 1 : -1;
    if (slot >= 0 && gSw[slot].t < 0.35f) return;                         // still shaking from the last hit: no new burst every frame
    float dl = std::sqrt(vx*vx + vz*vz); float dx = dl > 0.05f ? vx / dl : -nx, dz = dl > 0.05f ? vz / dl : -nz;
    const float A = std::min(1.8f, 0.25f + vn * 0.09f) / (0.6f + 0.4f * t.s);
    if (slot < 0){ int best = 0; slot = -1; for (int i = 0; i < 16; i++){ if (gSw[i].idx < 0){ slot = i; break; } if (gSw[i].t > gSw[best].t) best = i; }
        if (slot < 0){ slot = best; gSwSlot[gSw[slot].idx] = 0; gSwN--; } gSw[slot].idx = k; gSwSlot[k] = (uint8_t)(slot + 1); gSwN++; gSwOff[slot][0] = gSwOff[slot][1] = 0; }
    Sway& w = gSw[slot]; w.t = 0; w.A = A; w.dx = dx; w.dz = dz;
    spawnLeaves(t, vx, vz, (int)std::min(70.f, 8.f + vn * 2.4f));
}

// the trunks are solid
static void collide(CarState& S){
    if (!gCoReady || !gCoDone) return;
    const double sH = std::sin(S.heading), cH = std::cos(S.heading), R = 1.05; static const double OFS[3] = {-1.5, 0.0, 1.5};
    for (double o : OFS){
        const double px = S.x + sH * o, pz = S.z + cH * o; const long cx = (long)std::floor(px / CO_CELL), cz = (long)std::floor(pz / CO_CELL);
        for (long i = cx - 1; i <= cx + 1; i++) for (long j = cz - 1; j <= cz + 1; j++){
            auto it = gCoGrid.find(coCell(i, j)); if (it == gCoGrid.end()) continue;
            for (int k : it->second){
                const CoTree& t = gCo[k]; const double qx = S.x + sH * o - t.x, qz = S.z + cH * o - t.z, r = R + 0.43 * t.s, d2 = qx*qx + qz*qz;
                if (d2 >= r * r) continue;
                const double d = std::sqrt(d2); const double nx = d > 1e-4 ? qx / d : -sH, nz = d > 1e-4 ? qz / d : -cH, pen = r - d;
                S.x += nx * pen; S.z += nz * pen;
                const double vx = S.speed * sH + S.vy * cH, vz = S.speed * cH - S.vy * sH, vn = -(vx * nx + vz * nz);
                if (vn > 0){ Fence::bounceOff(S, nx, nz, 0.12, 0.35); if (vn > 1.2) hitTree(k, (float)nx, (float)nz, (float)vx, (float)vz, (float)vn); }
            }
        }
    }
}

// camera line of sight: walking from a (the look-at point) towards b (the eye), the distance to the first pine / spruce (trunk or cone-shaped crown)
// that stands in the way, or -1 when the view is clear.  The first 2.5 m are skipped (trees right next to the car are not "in front of" it).
static float camBlock(const float* a, const float* b){
    if (!gCoReady || !gCoDone) return -1.f;
    const float dx = b[0] - a[0], dy = b[1] - a[1], dz = b[2] - a[2], L = std::sqrt(dx*dx + dy*dy + dz*dz); if (L < 1e-3f) return -1.f;
    for (float s = 2.5f; s <= L; s += 0.6f){
        const float k = s / L, x = a[0] + dx * k, y = a[1] + dy * k, z = a[2] + dz * k;
        const long cx = (long)std::floor(x / CO_CELL), cz = (long)std::floor(z / CO_CELL);
        for (long i = cx - 1; i <= cx + 1; i++) for (long j = cz - 1; j <= cz + 1; j++){
            auto it = gCoGrid.find(coCell(i, j)); if (it == gCoGrid.end()) continue;
            for (int q : it->second){
                const CoTree& t = gCo[q]; const float h = y - t.y; if (h < 0.f || h > 15.5f * t.s) continue;
                const float ex = x - t.x, ez = z - t.z, d2 = ex*ex + ez*ez;
                const float crownR = coCrown(t.sp) * t.s * 0.85f;
                float r = 0.45f * t.s;                                                      // trunk
                if (t.sp >= 5){ const bool rw = t.sp == 6; const float u = (h / t.s - (rw ? 9.0f : 10.2f)) / (rw ? 4.4f : 5.4f); if (std::fabs(u) < 1.f) r = std::max(r, (rw ? 4.0f : 6.2f) * t.s * std::sqrt(1.f - u*u)); }   // maple / rowan: ROUND crown
                else if (h > 2.0f * t.s) r = std::max(r, crownR * (1.f - h / (16.f * t.s)));     // cone-shaped crown
                if (d2 < r * r) return s;
            }
        }
    }
    return -1.f;
}
static void updateFx(double dt){
    const float d = (float)dt;
    for (int i = 0; i < 16; i++){ Sway& w = gSw[i]; if (w.idx < 0) continue; w.t += d;
        if (w.A * std::exp(-0.9f * w.t) < 0.012f){ if (w.idx < (int)gSwSlot.size()) gSwSlot[w.idx] = 0; w.idx = -1; gSwN--; } }
    gLeafAlive = 0;
    for (Leaf& l : gLeaf){
        if (l.life <= 0) continue; l.age += d; if (l.age >= l.life){ l.life = 0; continue; } gLeafAlive++;
        if (l.landed) continue;
        const float k = 1.f - std::exp(-2.2f * d);
        l.vy += ((-1.5f - 0.5f * std::sin(l.age * 4.f + l.ph)) - l.vy) * k;                                  // drifts down at ~1.5 m/s, bobbing
        l.vx += ((0.35f + 0.5f * std::sin(l.age * 5.3f + l.ph)) - l.vx) * (1.f - std::exp(-1.1f * d));        // slow sideways flutter + a little wind
        l.vz += ((0.15f + 0.5f * std::cos(l.age * 4.7f + l.ph)) - l.vz) * (1.f - std::exp(-1.1f * d));
        l.x += l.vx * d; l.y += l.vy * d; l.z += l.vz * d;
        const float gy = (float)Terrain::meshH(l.x, l.z) + 0.03f; if (l.y <= gy){ l.y = gy; l.landed = true; }
    }
}

// pixelScale = viewport height / (2 tan(fov/2)): converts a world size at distance d into pixels
static void drawLeaves(const float* VP, float pixelScale){
    if (!gLfProg || gLeafAlive <= 0) return;
    static float buf[LEAF_MAX * 8]; int n = 0;
    static const float COL[3][3] = {{0.14f, 0.33f, 0.15f}, {0.22f, 0.42f, 0.16f}, {0.36f, 0.25f, 0.12f}};
    for (const Leaf& l : gLeaf){
        if (l.life <= 0) continue; float* o = buf + n * 8; const float fade = std::min(1.f, (l.life - l.age) / 0.8f);
        o[0] = l.x; o[1] = l.y; o[2] = l.z; o[3] = l.size * fade; o[4] = COL[l.kind][0]; o[5] = COL[l.kind][1]; o[6] = COL[l.kind][2]; o[7] = l.ph + (l.landed ? 0.f : l.age * l.spin); n++;
    }
    if (!n) return;
    glUseProgram(gLfProg); glUniformMatrix4fv(uLf_VP, 1, GL_FALSE, VP); glUniform1f(uLf_Scale, pixelScale);
    glEnable(GL_DEPTH_TEST); glDepthMask(GL_TRUE); glDisable(GL_BLEND); glDisable(GL_CULL_FACE);
    glBindVertexArray(gLfVAO); glBindBuffer(GL_ARRAY_BUFFER, gLfVBO); glBufferData(GL_ARRAY_BUFFER, n * 32, buf, GL_STREAM_DRAW);
    glDrawArrays(GL_POINTS, 0, n); glBindVertexArray(0);
}


// render each species once from the side into a texture (flat far-distance colour, like the 3D tree has beyond 330 m), then build the billboard quad buffers
static void coBakeBillboards(){
    gCbProg = makeProg(CB_VS, CB_FS);
    uCb_VP = glGetUniformLocation(gCbProg, "uVP"); uCb_Cam = glGetUniformLocation(gCbProg, "uCam"); uCb_Size = glGetUniformLocation(gCbProg, "uSize"); uCb_Tex = glGetUniformLocation(gCbProg, "uTex"); uCb_Time = glGetUniformLocation(gCbProg, "uTime");
    const float quad[8] = {-1, 0,  1, 0,  -1, 1,  1, 1};
    glGenBuffers(1, &gCbQuad); glBindBuffer(GL_ARRAY_BUFFER, gCbQuad); glBufferData(GL_ARRAY_BUFFER, sizeof(quad), quad, GL_STATIC_DRAW);
    GLint oldFbo = 0, vp[4]; glGetIntegerv(GL_FRAMEBUFFER_BINDING, &oldFbo); glGetIntegerv(GL_VIEWPORT, vp);
    bool ok = true;
    for (int sp = 0; sp < N_SP; sp++){
        int levels = 1; for (int m = std::max(CB_W, CB_H); m > 1; m >>= 1) levels++;
        glGenTextures(1, &gCbTex[sp]); glBindTexture(GL_TEXTURE_2D_ARRAY, gCbTex[sp]);
        glTexStorage3D(GL_TEXTURE_2D_ARRAY, levels, GL_RGBA8, CB_W, CB_H, CB_VIEWS);
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR); glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        GLuint fbo, depth; glGenFramebuffers(1, &fbo); glBindFramebuffer(GL_FRAMEBUFFER, fbo);
        glGenRenderbuffers(1, &depth); glBindRenderbuffer(GL_RENDERBUFFER, depth); glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT16, CB_W, CB_H);
        glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, depth);
        for (int k = 0; k < CB_VIEWS; k++){
            glFramebufferTextureLayer(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, gCbTex[sp], 0, k);
            if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE){ ok = false; continue; }
            glViewport(0, 0, CB_W, CB_H); glClearColor(0, 0, 0, 0); glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
            glEnable(GL_DEPTH_TEST); glDepthMask(GL_TRUE); glDisable(GL_BLEND); glDisable(GL_CULL_FACE);
            const float hw = gCbHW[sp], y0 = gCbY0[sp], hh = gCbH[sp];
            // the camera orbits the tree (the sun stays where it is in the world, so every view is lit exactly like the real 3D tree):
            // view k looks from direction (sin a, cos a); screen-x = (cos a, -sin a) . p, as the billboard quad's "right" vector at run time
            const float ang = 6.2831853f * (float)k / (float)CB_VIEWS, sa = std::sin(ang), ca = std::cos(ang);
            float P[16] = {0}; P[0] = ca / hw; P[8] = -sa / hw; P[2] = -0.01f * sa; P[10] = -0.01f * ca; P[5] = 2.f / hh; P[13] = -(2.f * y0 + hh) / hh; P[15] = 1;
            const float one[7] = {0, 0, 1, 0, 0, 0, 0}, eye[3] = {sa * 110.f, 8.f, ca * 110.f};      // viewer in the right direction (specular / needle glow use it)
            glUseProgram(gCoProg); glUniformMatrix4fv(uCo_VP, 1, GL_FALSE, P); glUniform3fv(uCo_Cam, 1, eye); glUniform1f(uCo_Time, 0.f); glUniform1f(uCo_Bake, 1.f); glUniform1f(uCo_Low, 0.f);
            glBindVertexArray(gCoVAO[sp][1]); glBindBuffer(GL_ARRAY_BUFFER, gCoInst[sp][1]); glBufferData(GL_ARRAY_BUFFER, sizeof(one), one, GL_STREAM_DRAW);
            glDrawElementsInstanced(GL_TRIANGLES, gCoIdx[sp][1], GL_UNSIGNED_SHORT, (void*)0, 1);
            glUniform1f(uCo_Bake, 0.f); glBindVertexArray(0);
        }
        glBindTexture(GL_TEXTURE_2D_ARRAY, gCbTex[sp]); glGenerateMipmap(GL_TEXTURE_2D_ARRAY);
        glBindFramebuffer(GL_FRAMEBUFFER, oldFbo); glDeleteRenderbuffers(1, &depth); glDeleteFramebuffers(1, &fbo);
        glGenVertexArrays(1, &gCbVAO[sp]); glBindVertexArray(gCbVAO[sp]);
        glBindBuffer(GL_ARRAY_BUFFER, gCbQuad); glEnableVertexAttribArray(0); glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 8, (void*)0);
        glGenBuffers(1, &gCbInst[sp]); glBindBuffer(GL_ARRAY_BUFFER, gCbInst[sp]);
        glEnableVertexAttribArray(3); glVertexAttribPointer(3, 4, GL_FLOAT, GL_FALSE, 20, (void*)0); glVertexAttribDivisor(3, 1);
        glEnableVertexAttribArray(4); glVertexAttribPointer(4, 1, GL_FLOAT, GL_FALSE, 20, (void*)16); glVertexAttribDivisor(4, 1);
        glBindVertexArray(0);
    }
    glViewport(vp[0], vp[1], vp[2], vp[3]);
    gCbReady = ok;
}

static void coInit(){
    gCoProg = makeProg(CO_VS, CO_FS); uCo_VP = glGetUniformLocation(gCoProg, "uVP"); uCo_Cam = glGetUniformLocation(gCoProg, "uCam"); uCo_Time = glGetUniformLocation(gCoProg, "uTime"); uCo_Bake = glGetUniformLocation(gCoProg, "uBake"); uCo_Low = glGetUniformLocation(gCoProg, "uLow");
    struct LodDef { int tiers, seg; bool jag; }; const LodDef L[3] = {{6, 10, true}, {6, 9, true}, {2, 5, false}};
    for (int sp = 0; sp < N_SP; sp++) for (int l = 0; l < 5; l++){      // l = 4: hand-made star-tier tree (Normal graphics); l = 3 unused
        if (l == 3) continue;      // slot 3 is unused (the low-poly tree was removed: Low keeps the same tree)
        TreeModel::ConiferMesh m; if (l == 4) TreeModel::buildConiferMid(m, sp); else TreeModel::buildConifer(m, sp, L[l].tiers, L[l].seg, L[l].jag); gCoIdx[sp][l] = m.count();
        if (l == 1){ float mx = 0.f, y0 = 1e9f, y1 = -1e9f;   // size of the detailed model (scale 1): used to bake the far 2D picture
            for (size_t i = 0; i + 2 < m.v.size(); i += 12){ mx = std::max(mx, std::max(std::fabs(m.v[i]), std::fabs(m.v[i + 2]))); y0 = std::min(y0, m.v[i + 1]); y1 = std::max(y1, m.v[i + 1]); }
            gCbHW[sp] = mx * 1.03f; gCbY0[sp] = y0; gCbH[sp] = (y1 - y0) * 1.01f; }
        glGenVertexArrays(1, &gCoVAO[sp][l]); glBindVertexArray(gCoVAO[sp][l]);
        glGenBuffers(1, &gCoVBO[sp][l]); glBindBuffer(GL_ARRAY_BUFFER, gCoVBO[sp][l]); glBufferData(GL_ARRAY_BUFFER, m.v.size() * 4, m.v.data(), GL_STATIC_DRAW);
        for (int a = 0; a < 3; a++){ glEnableVertexAttribArray(a); glVertexAttribPointer(a, 3, GL_FLOAT, GL_FALSE, 48, (void*)(size_t)(a * 12)); }
        glEnableVertexAttribArray(5); glVertexAttribPointer(5, 2, GL_FLOAT, GL_FALSE, 48, (void*)36);
        glEnableVertexAttribArray(6); glVertexAttribPointer(6, 1, GL_FLOAT, GL_FALSE, 48, (void*)44);
        glGenBuffers(1, &gCoIBO[sp][l]); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gCoIBO[sp][l]); glBufferData(GL_ELEMENT_ARRAY_BUFFER, m.idx.size() * 2, m.idx.data(), GL_STATIC_DRAW);
        glGenBuffers(1, &gCoInst[sp][l]); glBindBuffer(GL_ARRAY_BUFFER, gCoInst[sp][l]);
        glEnableVertexAttribArray(3); glVertexAttribPointer(3, 4, GL_FLOAT, GL_FALSE, 28, (void*)0); glVertexAttribDivisor(3, 1);
        glEnableVertexAttribArray(4); glVertexAttribPointer(4, 1, GL_FLOAT, GL_FALSE, 28, (void*)16); glVertexAttribDivisor(4, 1);
        glEnableVertexAttribArray(7); glVertexAttribPointer(7, 2, GL_FLOAT, GL_FALSE, 28, (void*)20); glVertexAttribDivisor(7, 1);   // sway offset x, z
        glBindVertexArray(0);
    }
    {   // vine mesh (same vertex layout + shader as the conifers)
        TreeModel::ConiferMesh m; TreeModel::buildVine(m); gVineIdx = m.count();
        glGenVertexArrays(1, &gVineVAO); glBindVertexArray(gVineVAO);
        glGenBuffers(1, &gVineVBO); glBindBuffer(GL_ARRAY_BUFFER, gVineVBO); glBufferData(GL_ARRAY_BUFFER, m.v.size() * 4, m.v.data(), GL_STATIC_DRAW);
        for (int a = 0; a < 3; a++){ glEnableVertexAttribArray(a); glVertexAttribPointer(a, 3, GL_FLOAT, GL_FALSE, 48, (void*)(size_t)(a * 12)); }
        glEnableVertexAttribArray(5); glVertexAttribPointer(5, 2, GL_FLOAT, GL_FALSE, 48, (void*)36);
        glEnableVertexAttribArray(6); glVertexAttribPointer(6, 1, GL_FLOAT, GL_FALSE, 48, (void*)44);
        glGenBuffers(1, &gVineIBO); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gVineIBO); glBufferData(GL_ELEMENT_ARRAY_BUFFER, m.idx.size() * 2, m.idx.data(), GL_STATIC_DRAW);
        glGenBuffers(1, &gVineInst); glBindBuffer(GL_ARRAY_BUFFER, gVineInst);
        glEnableVertexAttribArray(3); glVertexAttribPointer(3, 4, GL_FLOAT, GL_FALSE, 28, (void*)0); glVertexAttribDivisor(3, 1);
        glEnableVertexAttribArray(4); glVertexAttribPointer(4, 1, GL_FLOAT, GL_FALSE, 28, (void*)16); glVertexAttribDivisor(4, 1);
        glEnableVertexAttribArray(7); glVertexAttribPointer(7, 2, GL_FLOAT, GL_FALSE, 28, (void*)20); glVertexAttribDivisor(7, 1);
        glBindVertexArray(0);
    }
    gCo.clear(); gCo.reserve(34000); gCoReady = true; coBakeBillboards(); leafInit();   // trees are planted a little each frame (coLoadStep), see drawConifers
}

// call after Terrain::init() (needs the mountain heights) with a current GL context
static void initConifers(){ coInit(); }

// plant a few ms of trees per frame; when everything is planted: build the collision grid and allow the 3D models
static void coLoadStep(double budgetSec){
    if (gCoDone) return;
    if (coPlantStep(budgetSec)){ coBuildGrid(); gSwSlot.assign(gCo.size(), 0); gCoDone = true; }
}

static void drawConifers(const float* VP, const float* eye, float timeSec = 0.f){
    if (!gCoReady) return;
    {   // the forest is planted a little each frame. A fixed 4 ms per frame made the far forest take very long to appear on a slow phone (low fps = few planting
        // steps per second), so the not-yet-planted far trees were missing for many seconds. Now the planting budget grows with the frame time (about 40 % of it,
        // 4..20 ms): planted trees are shown at once as 2D pictures (all2D below), and the whole forest is there much sooner. Nothing changes once loading is done.
        static std::chrono::steady_clock::time_point lastT = std::chrono::steady_clock::now();
        const std::chrono::steady_clock::time_point nowT = std::chrono::steady_clock::now();
        const double fdt = std::chrono::duration<double>(nowT - lastT).count(); lastT = nowT;
        if (!gCoDone) coLoadStep(std::min(0.020, std::max(0.004, fdt * 0.40)));
    }
    static std::vector<float> B[N_SP][5], BB[N_SP]; for (auto& a : B) for (auto& b : a) b.clear(); for (auto& a : BB) a.clear();
    static std::vector<float> VB; VB.clear();                    // instances of trees that carry vines (close ones only)
    const bool useBb = gCbReady && Quality::billboards();     // Normal quality: far trees are camera-facing pictures
    const bool all2D = useBb && (!gCoDone || Quality::flat);    // still loading (or Super smooth mode): EVERY tree is only a 2D picture
    float pl[6][4];
    for (int i = 0; i < 6; i++){ const int a = i >> 1; const float sg = (i & 1) ? 1.f : -1.f;
        for (int j = 0; j < 4; j++) pl[i][j] = VP[j*4 + 3] + sg * VP[j*4 + a];
        const float l = std::sqrt(pl[i][0]*pl[i][0] + pl[i][1]*pl[i][1] + pl[i][2]*pl[i][2]); if (l > 1e-6f) for (int j = 0; j < 4; j++) pl[i][j] /= l; }
    const float qs = Quality::distScale(), m2 = Quality::treeDist * Quality::treeDist, a2 = CO_LOD0 * qs * CO_LOD0 * qs, b2 = CO_LOD1 * qs * CO_LOD1 * qs, bb2 = Quality::bbDist * Quality::bbDist;
    const float vd2 = (VINE_DIST * qs) * (VINE_DIST * qs);
    const bool low = Quality::level == 0;                                                      // Low graphics: the SAME trees, only the needles are simpler (see uLow in CO_FS)
    const bool mid = Quality::level == 1;                                                      // Normal graphics: the star-tier tree between 30 m and the 2D-picture distance
    static std::vector<std::pair<float, const CoTree*>> nearL; nearL.clear();
    // coarse 128 m chunks: whole chunks outside the view / tree distance are skipped (same trees are drawn as before, only the per-tree tests are saved)
    static std::vector<int> cand; cand.clear();
    if (gCoDone){
        if (!gChunkBuilt){ gChunks.clear(); std::unordered_map<long long, int> id;
            for (size_t k = 0; k < gCo.size(); k++){ const CoTree& t = gCo[k]; const long long key = coCell((long)std::floor(t.x / 128.f), (long)std::floor(t.z / 128.f));
                auto it = id.find(key); if (it == id.end()){ it = id.emplace(key, (int)gChunks.size()).first; CoChunk c; c.x0 = c.x1 = t.x; c.z0 = c.z1 = t.z; c.y0 = t.y; c.y1 = t.y + 17.f * t.s; gChunks.push_back(c); }
                CoChunk& c = gChunks[it->second]; c.idx.push_back((int)k); c.x0 = std::min(c.x0, t.x - 9.f * t.s); c.x1 = std::max(c.x1, t.x + 9.f * t.s); c.z0 = std::min(c.z0, t.z - 9.f * t.s); c.z1 = std::max(c.z1, t.z + 9.f * t.s); c.y0 = std::min(c.y0, t.y); c.y1 = std::max(c.y1, t.y + 17.f * t.s); }
            gChunkBuilt = true; }
        for (const CoChunk& c : gChunks){
            const float cx = (c.x0 + c.x1) * 0.5f, cy = (c.y0 + c.y1) * 0.5f, cz = (c.z0 + c.z1) * 0.5f, hx = (c.x1 - c.x0) * 0.5f, hy = (c.y1 - c.y0) * 0.5f, hz = (c.z1 - c.z0) * 0.5f, r = std::sqrt(hx*hx + hy*hy + hz*hz);
            const float ddx = cx - eye[0], ddz = cz - eye[2], dd = std::sqrt(ddx*ddx + ddz*ddz); if (dd - r > Quality::treeDist) continue;
            bool out = false; for (int i = 0; i < 6 && !out; i++) if (pl[i][0]*cx + pl[i][1]*cy + pl[i][2]*cz + pl[i][3] < -r) out = true;
            if (out) continue; cand.insert(cand.end(), c.idx.begin(), c.idx.end()); }
    } else { cand.resize(gCo.size()); for (size_t k = 0; k < cand.size(); k++) cand[k] = (int)k; }
    for (const int ti : cand){ const CoTree& t = gCo[ti];
        const float dx = t.x - eye[0], dz = t.z - eye[2], d2 = dx*dx + dz*dz; if (d2 > m2) continue;
        const float cy = t.y + 8.f * t.s, rad = 9.f * t.s; bool out = false;
        for (int i = 0; i < 6 && !out; i++) if (pl[i][0]*t.x + pl[i][1]*cy + pl[i][2]*t.z + pl[i][3] < -rad) out = true;
        if (out) continue;
        if (!all2D && gCoDone && d2 < vd2 && VB.size() < VINE_MAX * 7 && coHasVine(t.x, t.z, t.sp)) pushInst(VB, t, true);   // vines follow the trunk's wind lean and the crash sway
        if (mid && !all2D){ if (d2 < 30.f * 30.f){ nearL.push_back({d2, &t}); continue; } if (d2 < bb2){ pushInst(B[t.sp][4], t, true); continue; } }   // only the closest trees keep the full needle-branch model
        if (!all2D && !mid && d2 < a2){ nearL.push_back({d2, &t}); continue; }                                   // close: full branch model (capped below)
        const bool toBb = useBb && (all2D || low || d2 >= bb2);          // Low: everything outside the nearest full trees is the baked picture of the real tree, always facing the camera
        std::vector<float>& v = toBb ? BB[t.sp] : B[t.sp][(d2 < b2 || useBb) ? 1 : 2];
        pushInst(v, t, !toBb);
    }
    // the detailed branch model is the costly one: only the nearest MAX_DETAIL trees get it, the rest use the cheaper mid-distance model
    const size_t MAX_DETAIL = low ? 10 : (mid ? 16 : 36);        // Low: only the nearest few trees get the full needle-branch model
    if (nearL.size() > MAX_DETAIL) std::nth_element(nearL.begin(), nearL.begin() + MAX_DETAIL, nearL.end(), [](const std::pair<float, const CoTree*>& a, const std::pair<float, const CoTree*>& b){ return a.first < b.first; });
    for (size_t k = 0; k < nearL.size(); k++){ const CoTree& t = *nearL[k].second;
        if (low && useBb && k >= MAX_DETAIL){ pushInst(BB[t.sp], t, false); continue; }               // Low: no simple cone model, the picture of the real tree instead
        std::vector<float>& v = B[t.sp][k < MAX_DETAIL ? 0 : 1];
        pushInst(v, t, true); }
    swayOffsets();
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE);
    glUseProgram(gCoProg); glUniformMatrix4fv(uCo_VP, 1, GL_FALSE, VP); glUniform3fv(uCo_Cam, 1, eye); glUniform1f(uCo_Time, timeSec); glUniform1f(uCo_Bake, 0.f); glUniform1f(uCo_Low, low ? 1.f : 0.f);
    for (int sp = 0; sp < N_SP; sp++) for (int l = 0; l < 5; l++){
        const int cnt = (int)(B[sp][l].size() / 7); if (!cnt) continue;
        glBindVertexArray(gCoVAO[sp][l]);
        glBindBuffer(GL_ARRAY_BUFFER, gCoInst[sp][l]); glBufferData(GL_ARRAY_BUFFER, B[sp][l].size() * 4, B[sp][l].data(), GL_STREAM_DRAW);
        glDrawElementsInstanced(GL_TRIANGLES, gCoIdx[sp][l], GL_UNSIGNED_SHORT, (void*)0, cnt);
    }
    if (!VB.empty()){
        glBindVertexArray(gVineVAO); glBindBuffer(GL_ARRAY_BUFFER, gVineInst); glBufferData(GL_ARRAY_BUFFER, VB.size() * 4, VB.data(), GL_STREAM_DRAW);
        glDrawElementsInstanced(GL_TRIANGLES, gVineIdx, GL_UNSIGNED_SHORT, (void*)0, (int)(VB.size() / 7));
    }
    if (useBb){
        glUseProgram(gCbProg); glUniformMatrix4fv(uCb_VP, 1, GL_FALSE, VP); glUniform3fv(uCb_Cam, 1, eye); glUniform1i(uCb_Tex, 0); glUniform1f(uCb_Time, timeSec); glActiveTexture(GL_TEXTURE0);
        for (int sp = 0; sp < N_SP; sp++){
            const int cnt = (int)(BB[sp].size() / 5); if (!cnt) continue;
            glUniform3f(uCb_Size, gCbHW[sp], gCbY0[sp], gCbH[sp]); glBindTexture(GL_TEXTURE_2D_ARRAY, gCbTex[sp]);
            glBindVertexArray(gCbVAO[sp]);
            glBindBuffer(GL_ARRAY_BUFFER, gCbInst[sp]); glBufferData(GL_ARRAY_BUFFER, BB[sp].size() * 4, BB[sp].data(), GL_STREAM_DRAW);
            glDrawArraysInstanced(GL_TRIANGLE_STRIP, 0, 4, cnt);
        }
    }
    glBindVertexArray(0);
}

} // namespace TreeGL
