// Horizon Drift - CABLE CAR: valley station (mountain foot) -> 3 steel pylons -> summit station, with two sagging steel ropes. Static decoration (cabins: later).
#pragma once
#include <GLES3/gl3.h>
#include <cmath>
#include <vector>
#include <algorithm>
#include "wetland.h"
#include "terrain.h"
#include "village.h"
#include "road.h"
#include "river.h"

namespace CableCar {
struct V3 { double x, y, z; };
static std::vector<float> gV; static std::vector<uint32_t> gI; static GLuint gProg = 0, gVao = 0, gVbo = 0, gIbo = 0; static GLint uVP = -1, uCam = -1, uT = -1; static bool gOk = false;
static GLsizei gCount = 0; static V3 gA, gB; static double gDx = 0, gDz = 1;                                   // station centres (ground y), unit direction valley -> summit

static uint32_t vt(double x, double y, double z, double nx, double ny, double nz, float r, float g, float b){
    const uint32_t i = (uint32_t)(gV.size() / 10); const float a[10] = {(float)x, (float)y, (float)z, (float)nx, (float)ny, (float)nz, r, g, b, 0.f}; gV.insert(gV.end(), a, a + 10); return i; }
static void quad(V3 a, V3 b, V3 c, V3 d, float r, float g, float bl){                 // a,b,c,d counter-clockwise; flat normal
    const double ux = b.x - a.x, uy = b.y - a.y, uz = b.z - a.z, wx = d.x - a.x, wy = d.y - a.y, wz = d.z - a.z; double nx = uy * wz - uz * wy, ny = uz * wx - ux * wz, nz = ux * wy - uy * wx; const double l = std::sqrt(nx*nx + ny*ny + nz*nz) + 1e-12; nx /= l; ny /= l; nz /= l;
    const uint32_t A = vt(a.x, a.y, a.z, nx, ny, nz, r, g, bl), B = vt(b.x, b.y, b.z, nx, ny, nz, r, g, bl), C = vt(c.x, c.y, c.z, nx, ny, nz, r, g, bl), D = vt(d.x, d.y, d.z, nx, ny, nz, r, g, bl); gI.insert(gI.end(), {A, B, C, A, C, D}); }
// local frame of a station: u along the line (towards the summit), v across, y up
struct Fr { double ox, oz; };
static V3 W(const Fr& f, double u, double v, double y){ return {f.ox + gDx * u - gDz * v, y, f.oz + gDz * u + gDx * v}; }
static void box(const Fr& f, double u0, double u1, double v0, double v1, double y0, double y1, float r, float g, float b){
    V3 p[8] = {W(f,u0,v0,y0), W(f,u1,v0,y0), W(f,u1,v1,y0), W(f,u0,v1,y0), W(f,u0,v0,y1), W(f,u1,v0,y1), W(f,u1,v1,y1), W(f,u0,v1,y1)};
    quad(p[4], p[5], p[6], p[7], r, g, b); quad(p[0], p[3], p[2], p[1], r*0.5f, g*0.5f, b*0.5f);
    quad(p[0], p[1], p[5], p[4], r*0.9f, g*0.9f, b*0.9f); quad(p[1], p[2], p[6], p[5], r*0.8f, g*0.8f, b*0.8f); quad(p[2], p[3], p[7], p[6], r*0.9f, g*0.9f, b*0.9f); quad(p[3], p[0], p[4], p[7], r*0.8f, g*0.8f, b*0.8f);
}
static void tube(V3 a, V3 b, double rad, int n, float r, float g, float bl){                 // thin prism between two points (ropes, legs, wheel axles)
    double dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z; const double L = std::sqrt(dx*dx + dy*dy + dz*dz); if (L < 1e-6) return; dx /= L; dy /= L; dz /= L;
    double px = -dz, py = 0, pz = dx; double pl = std::sqrt(px*px + pz*pz); if (pl < 1e-6){ px = 1; pz = 0; pl = 1; } px /= pl; pz /= pl; const double qx = dy * pz - dz * py, qy = dz * px - dx * pz, qz = dx * py - dy * px;
    std::vector<uint32_t> ia, ib;
    for (int i = 0; i < n; i++){ const double t = i * 6.2831853 / n, c = std::cos(t), s = std::sin(t), nx = px * c + qx * s, ny = py * c + qy * s, nz = pz * c + qz * s; const float k = 0.75f + 0.25f * (float)ny;
        ia.push_back(vt(a.x + nx * rad, a.y + ny * rad, a.z + nz * rad, nx, ny, nz, r * k, g * k, bl * k)); ib.push_back(vt(b.x + nx * rad, b.y + ny * rad, b.z + nz * rad, nx, ny, nz, r * k, g * k, bl * k)); }
    for (int i = 0; i < n; i++){ const int j = (i + 1) % n; gI.insert(gI.end(), {ia[i], ib[i], ia[j], ia[j], ib[i], ib[j]}); }
}
static void station(const V3& c, bool summit){
    const Fr f = {c.x, c.z}; const double HL = 7.5, HW = 4.4;
    double lo = 1e9, hi = -1e9; for (double u : {-HL, HL}) for (double v : {-HW, HW}){ const V3 p = W(f, u, v, 0); const double y = Terrain::fieldH(p.x, p.z); lo = std::min(lo, y); hi = std::max(hi, y); }
    const double F = summit ? c.y : hi + 0.15, base = std::min(lo, F) - 1.2;
    box(f, -HL, HL, -HW, HW, base, F + 3.2, 0.62f, 0.60f, 0.57f);                                                    // concrete plinth
    box(f, -HL + 0.4, HL - 0.4, -HW + 0.25, HW - 0.25, F + 3.2, F + 7.2, 0.40f, 0.26f, 0.14f);                       // timber upper storey
    for (int sgn : {-1, 1}) box(f, -HL + 2.2, HL - 2.2, sgn * (HW - 0.22) - 0.04, sgn * (HW - 0.22) + 0.04, F + 4.3, F + 6.2, 0.10f, 0.15f, 0.20f);   // glazing band
    box(f, HL - 0.45, HL - 0.30, -1.2, 1.2, F + 4.4, F + 6.6, 0.03f, 0.03f, 0.04f); box(f, -HL + 0.30, -HL + 0.45, -1.2, 1.2, F + 4.4, F + 6.6, 0.03f, 0.03f, 0.04f);   // rope gates
    const double ry = F + 7.2, ov = 1.3, rh = 2.3;                                                                   // low gable roof, ridge along the line
    V3 e0 = W(f, -HL - ov, -HW - ov, ry), e1 = W(f, -HL - ov, HW + ov, ry), e2 = W(f, HL + ov, HW + ov, ry), e3 = W(f, HL + ov, -HW - ov, ry), r0 = W(f, -HL - ov, 0, ry + rh), r1 = W(f, HL + ov, 0, ry + rh);
    quad(e3, e0, r0, r1, 0.20f, 0.19f, 0.20f); quad(e1, e2, r1, r0, 0.24f, 0.23f, 0.24f);
    { const uint32_t A = vt(e0.x, e0.y, e0.z, -gDx, 0, -gDz, 0.3f, 0.2f, 0.12f), B = vt(e1.x, e1.y, e1.z, -gDx, 0, -gDz, 0.3f, 0.2f, 0.12f), C = vt(r0.x, r0.y, r0.z, -gDx, 0, -gDz, 0.3f, 0.2f, 0.12f), D = vt(e2.x, e2.y, e2.z, gDx, 0, gDz, 0.3f, 0.2f, 0.12f), E = vt(e3.x, e3.y, e3.z, gDx, 0, gDz, 0.3f, 0.2f, 0.12f), G = vt(r1.x, r1.y, r1.z, gDx, 0, gDz, 0.3f, 0.2f, 0.12f); gI.insert(gI.end(), {A, B, C, E, D, G}); }
    const double wu = summit ? HL + 1.8 : -HL - 1.8;                                                                 // bull-wheel on a short mast outside the gate end
    for (int s : {-1, 1}) tube(W(f, wu, s * 1.8, ry - 0.5 + 0.0), W(f, wu, s * 1.8, ry - 0.5 + 0.2), 1.4, 14, 0.22f, 0.23f, 0.25f);
    box(f, -HL - 1.0, -HL, -1.3, 1.3, F, F + 0.25, 0.5f, 0.5f, 0.5f);                                                // entrance step
}
static void rope(const std::vector<V3>& pts){ for (size_t i = 0; i + 1 < pts.size(); i++) tube(pts[i], pts[i + 1], 0.045, 5, 0.18f, 0.18f, 0.19f); }
static void pylon(const V3& g, double H){
    const Fr f = {g.x, g.z}; const double b = 2.0, t = 0.55; const double y0 = g.y - 0.8, y1 = g.y + H;
    for (int sx : {-1, 1}) for (int sz : {-1, 1}) tube(W(f, sx * b, sz * b, y0), W(f, sx * t, sz * t, y1), 0.13, 5, 0.62f, 0.64f, 0.66f);
    for (int k = 1; k <= 4; k++){ const double y = g.y + H * k / 5.0, w = b + (t - b) * (y - y0) / (y1 - y0); for (int s : {-1, 1}){ tube(W(f, -w, s * w, y), W(f, w, s * w, y), 0.05, 4, 0.58f, 0.60f, 0.62f); tube(W(f, s * w, -w, y), W(f, s * w, w, y), 0.05, 4, 0.58f, 0.60f, 0.62f); } }
    box(f, -0.7, 0.7, -3.2, 3.2, y1, y1 + 0.35, 0.9f, 0.35f, 0.08f);                                                  // cross-arm, safety orange
    for (int s : {-1, 1}) box(f, -0.45, 0.45, s * 1.8 - 0.3, s * 1.8 + 0.3, y1 - 0.4, y1, 0.25f, 0.26f, 0.28f);     // sheave housings
    box(f, -2.6, 2.6, -2.6, 2.6, g.y - 1.0, g.y + 0.4, 0.55f, 0.54f, 0.52f);                                         // concrete footing
}
static bool free_(double x, double z){ if (Road::clearance((float)x, (float)z) < 14.f) return false; if (std::fabs(River::riverSd(x, z)) < 30) return false; for (const Village::Building& b : Village::gB){ const double dx = x - b.x, dz = z - b.z; if (dx*dx + dz*dz < 16.0*16.0) return false; } return true; }
static void plan(){
    const double ax0 = 640, az0 = 415; double ax = ax0, az = az0; bool ok = false;                                     // valley station: nearest free spot to the mountain foot
    for (int r = 0; r < 120 && !ok; r += 6) for (int k = 0; k < 16 && !ok; k++){ const double a = k * 0.3927 + r, x = ax0 + std::cos(a) * r, z = az0 + std::sin(a) * r; if (free_(x, z)){ ax = x; az = z; ok = true; } }
    double sx = 870, sz = -122, sy = 160;
    if (Terrain::PEAK.on){ sx = Terrain::PEAK.x; sz = Terrain::PEAK.z; sy = Terrain::PEAK.padY; }
    const double R = Road::gPark[2] > 45.f ? Road::gPark[2] : 60.0; double dx = ax - sx, dz = az - sz; double dl = std::hypot(dx, dz); dx /= dl; dz /= dl;
    double bx = sx + dx * (R - 12.0), bz = sz + dz * (R - 12.0);                                                       // summit station on the pad edge facing the valley (the restaurant is 24 m from the centre on the other side)
    for (int k = 0; k < 12; k++){ bool hit = false; for (const Village::Building& b : Village::gB){ const double ex = bx - b.x, ez = bz - b.z; if (ex*ex + ez*ez < 18.0*18.0) hit = true; } if (!hit) break; const double a = std::atan2(dz, dx) + 0.2 * (k + 1) * (k % 2 ? 1 : -1); bx = sx + std::cos(a) * (R - 12.0); bz = sz + std::sin(a) * (R - 12.0); }
    gA = {ax, Terrain::fieldH(ax, az), az}; gB = {bx, sy, bz};
    gDx = gB.x - gA.x; gDz = gB.z - gA.z; const double L = std::hypot(gDx, gDz); gDx /= L; gDz /= L;
}
static void build(){
    plan(); const double hA = 6.6 + 3.3, hB = 6.6 + 3.3;                                                                // rope height above each station floor (wheel centre)
    const double lo = 0; (void)lo;
    station(gA, false); station(gB, true);
    const double L = std::hypot(gB.x - gA.x, gB.z - gA.z), ya = gA.y + hA, yb = gB.y + hB;
    std::vector<V3> top; top.push_back({gA.x, ya, gA.z});
    const double ts[3] = {0.28, 0.52, 0.76};
    for (int i = 0; i < 3; i++){ const double x = gA.x + (gB.x - gA.x) * ts[i], z = gA.z + (gB.z - gA.z) * ts[i], g = Terrain::fieldH(x, z), line = ya + (yb - ya) * ts[i], H = std::max(line - g + 0.0, 12.0) + 1.0; pylon({x, g, z}, H); top.push_back({x, g + H - 0.1, z}); }
    top.push_back({gB.x, yb, gB.z});
    for (int s : {-1, 1}){ std::vector<V3> pts;                                                                         // two parallel ropes, each span hangs in a catenary sag
        for (size_t i = 0; i + 1 < top.size(); i++){ const V3 a = top[i], b = top[i + 1]; const double span = std::hypot(b.x - a.x, b.z - a.z), sag = span * 0.014; const int n = std::max(6, (int)(span / 8));
            for (int k = (i ? 1 : 0); k <= n; k++){ const double t = (double)k / n; pts.push_back({a.x + (b.x - a.x) * t - gDz * s * 1.8, a.y + (b.y - a.y) * t - 4.0 * sag * t * (1 - t), a.z + (b.z - a.z) * t + gDx * s * 1.8}); } }
        rope(pts); }
    (void)L;
}
static void init(){
    if (gOk) return; build(); if (gI.empty()) return;
    gProg = glCreateProgram(); glAttachShader(gProg, Wetland::sh(GL_VERTEX_SHADER, Wetland::VS)); glAttachShader(gProg, Wetland::sh(GL_FRAGMENT_SHADER, Wetland::FS)); glLinkProgram(gProg); SunLight::attach(gProg);
    uVP = glGetUniformLocation(gProg, "uVP"); uCam = glGetUniformLocation(gProg, "uCam"); uT = glGetUniformLocation(gProg, "uT");
    glGenVertexArrays(1, &gVao); glBindVertexArray(gVao); glGenBuffers(1, &gVbo); glBindBuffer(GL_ARRAY_BUFFER, gVbo); glBufferData(GL_ARRAY_BUFFER, gV.size() * 4, gV.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 40, (void*)0); glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 40, (void*)12);
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 40, (void*)24); glEnableVertexAttribArray(3); glVertexAttribPointer(3, 1, GL_FLOAT, GL_FALSE, 40, (void*)36);
    glGenBuffers(1, &gIbo); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gIbo); glBufferData(GL_ELEMENT_ARRAY_BUFFER, gI.size() * 4, gI.data(), GL_STATIC_DRAW); glBindVertexArray(0);
    gCount = (GLsizei)gI.size(); std::vector<float>().swap(gV); std::vector<uint32_t>().swap(gI); gOk = true;
}
static void draw(const float* VP, const float* eye, float time){
    if (!gOk) return; const double mx = (gA.x + gB.x) * 0.5 - eye[0], mz = (gA.z + gB.z) * 0.5 - eye[2]; if (mx*mx + mz*mz > 1800.0*1800.0) return;
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glDisable(GL_BLEND); glUseProgram(gProg); glUniformMatrix4fv(uVP, 1, GL_FALSE, VP); glUniform3fv(uCam, 1, eye); glUniform1f(uT, time);
    glBindVertexArray(gVao); glDrawElements(GL_TRIANGLES, gCount, GL_UNSIGNED_INT, (void*)0); glBindVertexArray(0);
}
}
