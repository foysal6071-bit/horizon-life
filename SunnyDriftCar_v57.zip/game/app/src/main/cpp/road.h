// Sunny Drift - road network: C++ port of the HTML "Road network" block (pure C++, no OpenGL).
//  * three Swiss-valley ring roads (stretched ovals, nominal radius 220 m / 420 m / 640 m, soft sum-of-harmonics wobble = ringPt) + two connector roads (A-B in the north, B-D in the south-east)
//  * centre lines are three.js CatmullRomCurve3 (centripetal) with the SAME arc-length parametrisation as three.js
//    (200 divisions, getPointAt / getTangentAt), so every point lies exactly where it does in the HTML game
//  * road ribbons / sand verges are lofted along the centre line exactly like buildStrip() in the HTML
//  * roadClearance() / surfaceAt() are used by the trees and by the car's grip
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <unordered_map>
#include <vector>
#include "river.h"

namespace Road {

const double ROAD_SURF = 0.08;                        // height of the road surface
const double PI = 3.14159265358979323846;

struct V3 { double x = 0, y = 0, z = 0; };
static inline V3 vsub(const V3& a, const V3& b){ return {a.x - b.x, a.y - b.y, a.z - b.z}; }
static inline double dist2(const V3& a, const V3& b){ V3 d = vsub(a, b); return d.x*d.x + d.y*d.y + d.z*d.z; }
static inline double jsRound(double v){ return std::floor(v + 0.5); }          // JS Math.round

// ---------- three.js CatmullRomCurve3 (centripetal) ----------
struct Curve {
    std::vector<V3> pts; bool closed = true, open = false; double hw = 0;
    double rA = 0, rB = 0;                             // connector only: half-width of the ring road it joins at its start / end (T-junction flare), 0 = none
    std::vector<double> lens;                          // cumulative arc lengths, 200 divisions (Curve.getLengths)

    static double cr(double x0, double x1, double x2, double x3, double dt0, double dt1, double dt2, double t){
        double t1 = (x1 - x0) / dt0 - (x2 - x0) / (dt0 + dt1) + (x2 - x1) / dt1;
        double t2 = (x2 - x1) / dt1 - (x3 - x1) / (dt1 + dt2) + (x3 - x2) / dt2;
        t1 *= dt1; t2 *= dt1;
        double c0 = x1, c1 = t1, c2 = -3*x1 + 3*x2 - 2*t1 - t2, c3 = 2*x1 - 2*x2 + t1 + t2;
        return c0 + c1*t + c2*t*t + c3*t*t*t;
    }
    V3 getPoint(double t) const {
        const long l = (long)pts.size();
        double p = (double)(l - (closed ? 0 : 1)) * t;
        long ip = (long)std::floor(p); double w = p - (double)ip;
        if (closed){ if (!(ip > 0)) ip += (long)(std::floor(std::fabs((double)ip) / (double)l) + 1) * l; }
        else if (w == 0 && ip == l - 1){ ip = l - 2; w = 1; }
        V3 p0, p3;
        if (closed || ip > 0) p0 = pts[(ip - 1) % l];
        else { const V3 &a = pts[0], &b = pts[1]; p0 = {2*a.x - b.x, 2*a.y - b.y, 2*a.z - b.z}; }
        const V3 p1 = pts[ip % l], p2 = pts[(ip + 1) % l];
        if (closed || ip + 2 < l) p3 = pts[(ip + 2) % l];
        else { const V3 &a = pts[l-1], &b = pts[l-2]; p3 = {2*a.x - b.x, 2*a.y - b.y, 2*a.z - b.z}; }
        double dt0 = std::pow(dist2(p0, p1), 0.25), dt1 = std::pow(dist2(p1, p2), 0.25), dt2 = std::pow(dist2(p2, p3), 0.25);
        if (dt1 < 1e-4) dt1 = 1.0;
        if (dt0 < 1e-4) dt0 = dt1;
        if (dt2 < 1e-4) dt2 = dt1;
        return { cr(p0.x, p1.x, p2.x, p3.x, dt0, dt1, dt2, w), cr(p0.y, p1.y, p2.y, p3.y, dt0, dt1, dt2, w), cr(p0.z, p1.z, p2.z, p3.z, dt0, dt1, dt2, w) };
    }
    void build(){
        const int DIV = 200; lens.assign(1, 0.0); V3 last = getPoint(0); double sum = 0;
        for (int p = 1; p <= DIV; p++){ V3 c = getPoint((double)p / DIV); sum += std::sqrt(dist2(c, last)); lens.push_back(sum); last = c; }
    }
    double length() const { return lens.back(); }
    double utoT(double u) const {                      // Curve.getUtoTmapping
        const long il = (long)lens.size(); double target = u * lens[il - 1];
        long low = 0, high = il - 1, i = 0;
        while (low <= high){
            i = low + (high - low) / 2; double cmp = lens[i] - target;
            if (cmp < 0) low = i + 1; else if (cmp > 0) high = i - 1; else { high = i; break; }
        }
        i = high < 0 ? 0 : high;
        if (lens[i] == target) return (double)i / (double)(il - 1);
        double before = lens[i], after = lens[i + 1];
        return ((double)i + (target - before) / (after - before)) / (double)(il - 1);
    }
    V3 getPointAt(double u) const { return getPoint(utoT(u)); }
    V3 getTangent(double t) const {
        const double d = 0.0001; double t1 = t - d, t2 = t + d; if (t1 < 0) t1 = 0; if (t2 > 1) t2 = 1;
        V3 a = getPoint(t1), b = getPoint(t2), v = vsub(b, a); double l = std::sqrt(v.x*v.x + v.y*v.y + v.z*v.z); if (l == 0) l = 1;
        return {v.x / l, v.y / l, v.z / l};
    }
    V3 getTangentAt(double u) const { return getTangent(utoT(u)); }
};

// ---------- Swiss valley rings ----------
//  Both loops are stretched ovals that follow the valley (long axis = west-east, the direction the river flows), with a soft sum-of-harmonics
//  wobble so the road flows like a real mountain road.  ringPt(R, a) gives the centre-line point of the ring with nominal radius R (220 / 420)
//  at parameter angle a.  The start line (u = 0) sits at a = RING_PHASE = the middle of the southern straight, well away from the river bridges.
static const double RING_PHASE = PI / 2;
static void ringPt(double R, double a, double& x, double& z){
    static const double A220[4] = {22, 15, 10, 5},  K220[4] = {2, 3, 5, 7};
    static const double A420[4] = {28, 20, 12, 8}, K420[4] = {3, 4, 7, 11};
    static const double A640[4] = {30, 22, 14, 9}, K640[4] = {3, 5, 8, 13};     // outer ring (R = 640): long, lazy bends
    const int kind = R < 300 ? 0 : (R < 550 ? 1 : 2);
    const double* A = kind == 0 ? A220 : kind == 1 ? A420 : A640; const double* K = kind == 0 ? K220 : kind == 1 ? K420 : K640;
    const double SX = kind == 0 ? 1.40 : 1.30, SZ = kind == 0 ? 0.66 : kind == 1 ? 0.80 : 0.78, p = R * 0.013; double r = R;
    for (int i = 0; i < 4; i++) r += A[i] * ((i % 2) ? std::cos(K[i]*a - p*i) : std::sin(K[i]*a + p*(i + 1)));
    x = std::cos(a) * r * SX; z = std::sin(a) * r * SZ;
}
// direction the valley / river runs in (angle used by the dirt track and the connector road): fixed, the river is hand-placed in river.h
static double pickRiverAngle(){ return PI / 2; }

// ---------- strip meshes (buildStrip in the HTML). vertex = pos(3) uv(2) normal(3) along(1) curv(1) = 10 floats ----------
//  along = metres travelled along the road (lets the shader paint dashed centre lines), curv = 1 / bend radius (solid line in tight bends).
struct Mesh { std::vector<float> v; std::vector<uint32_t> idx; };
static const int VSTRIDE = 10;
struct Prof { double o, y, u; };

// Sample positions (curve parameter t0..t1, equal in arc length) that keep the polyline within `tol` metres of the true curve:
// long steps on straights, short steps in bends.  The old fixed 1.5 m grid spent 3-4x more vertices for no visible gain on a flat ribbon.
static std::vector<double> adaptiveT(const Curve& cv, double t0, double t1, double tol, double minStep, double maxStep){
    const double len = cv.length(), L = (t1 - t0) * len; std::vector<double> ts{t0};
    if (L <= minStep){ ts.push_back(t1); return ts; }
    auto wrap = [](double t){ return std::fmod(std::fmod(t, 1.0) + 1.0, 1.0); };
    const int n = std::max(2, (int)std::ceil(L)); std::vector<double> k(n + 1);                // curvature probe every ~1 m
    for (int i = 0; i <= n; i++){
        const double t = t0 + (t1 - t0) * i / n, d = 1.5 / len; V3 a = cv.getTangentAt(wrap(t - d)), b = cv.getTangentAt(wrap(t + d));
        k[i] = std::fabs(std::atan2(a.x*b.z - a.z*b.x, a.x*b.x + a.z*b.z)) / 3.0;
    }
    const double pr = L / n; double s = 0;
    while (s < L - 1e-6){
        const int i0 = (int)std::floor(s / pr), i1 = std::min(n, (int)std::ceil((s + maxStep) / pr)); double km = 1e-6;
        for (int i = i0; i <= i1; i++) km = std::max(km, k[i]);
        double st = std::sqrt(8.0 * tol / km); st = std::min(maxStep, std::max(minStep, st));
        s += st; if (L - s < 0.5 * minStep) s = L;
        ts.push_back(s >= L ? t1 : t0 + (t1 - t0) * s / L);
    }
    return ts;
}

// ts = sample positions along the curve; widen(t) = extra half width at t (junction flare; shifts every profile point outwards, asphalt uv with it)
static void buildStrip(Mesh& m, const Curve& curve, const std::vector<double>& ts, const std::vector<Prof>& prof, int vRepeat, double t0, double t1, bool closed, double vConst = -1,
                       double (*widen)(const Curve&, double) = nullptr){
    const int N = (int)ts.size() - 1, P = (int)prof.size(); const uint32_t base = (uint32_t)(m.v.size() / VSTRIDE); const double len = curve.length();
    const int nv = (N + 1) * P; std::vector<double> pos(nv * 3), nor(nv * 3, 0.0), aux(nv * 2); std::vector<float> uv(nv * 2);
    for (int i = 0; i <= N; i++){
        double t = std::fmod(std::fmod(ts[i], 1.0) + 1.0, 1.0);
        V3 p = curve.getPointAt(t), tan = curve.getTangentAt(t);
        double nl = std::hypot(tan.x, tan.z); if (nl == 0) nl = 1; double ux = -tan.z / nl, uz = tan.x / nl;
        const double d = 1.5 / len; V3 ta = curve.getTangentAt(std::fmod(std::fmod(t - d, 1.0) + 1.0, 1.0)), tb = curve.getTangentAt(std::fmod(t + d, 1.0));
        const double kap = std::fabs(std::atan2(ta.x*tb.z - ta.z*tb.x, ta.x*tb.x + ta.z*tb.z)) / 3.0;
        const double ex = widen ? widen(curve, t) : 0.0, vr = (ts[i] - t0) / (t1 - t0) * vRepeat;
        for (int j = 0; j < P; j++){
            int k = i * P + j; const double o = prof[j].o + (prof[j].o < 0 ? -ex : ex);
            pos[k*3] = p.x + ux * o; pos[k*3+1] = prof[j].y; pos[k*3+2] = p.z + uz * o;
            uv[k*2] = (float)(vConst >= 0 ? prof[j].u + (prof[j].u < 0 ? -ex : ex) : prof[j].u); uv[k*2+1] = (float)(vConst >= 0 ? vConst + ex : vr);
            aux[k*2] = (double)(ts[i]) * len; aux[k*2+1] = kap;
        }
    }
    std::vector<uint32_t> idx;
    for (int i = 0; i < N; i++) for (int j = 0; j < P - 1; j++){
        uint32_t a = i*P + j, b = (i+1)*P + j; uint32_t t[6] = {a, b, a+1, a+1, b, b+1};
        idx.insert(idx.end(), t, t + 6);
    }
    for (size_t f = 0; f < idx.size(); f += 3){                                    // computeVertexNormals
        const double *A = &pos[idx[f]*3], *B = &pos[idx[f+1]*3], *C = &pos[idx[f+2]*3];
        double cb[3] = {C[0]-B[0], C[1]-B[1], C[2]-B[2]}, ab[3] = {A[0]-B[0], A[1]-B[1], A[2]-B[2]};
        double n[3] = {cb[1]*ab[2] - cb[2]*ab[1], cb[2]*ab[0] - cb[0]*ab[2], cb[0]*ab[1] - cb[1]*ab[0]};
        for (int q = 0; q < 3; q++) for (int c = 0; c < 3; c++) nor[idx[f+q]*3 + c] += n[c];
    }
    for (int j = 0; closed && j < P; j++){                                          // seamless shading where the loop closes
        int a = j, b = N*P + j;
        for (int c = 0; c < 3; c++){ double s = nor[a*3+c] + nor[b*3+c]; nor[a*3+c] = nor[b*3+c] = s; }
    }
    for (int k = 0; k < nv; k++){
        double l = std::sqrt(nor[k*3]*nor[k*3] + nor[k*3+1]*nor[k*3+1] + nor[k*3+2]*nor[k*3+2]); if (l == 0) l = 1;
        double s = nor[k*3+1] < 0 ? -1.0 : 1.0;                                     // always face up
        for (int c = 0; c < 3; c++) nor[k*3+c] = nor[k*3+c] / l * s;
        float row[VSTRIDE] = {(float)pos[k*3], (float)pos[k*3+1], (float)pos[k*3+2], uv[k*2], uv[k*2+1], (float)nor[k*3], (float)nor[k*3+1], (float)nor[k*3+2], (float)aux[k*2], (float)aux[k*2+1]};
        m.v.insert(m.v.end(), row, row + VSTRIDE);
    }
    for (uint32_t i : idx) m.idx.push_back(base + i);
}

// ---------- the network ----------
struct Net {
    Curve A, B, C, D, E; double riverAng = 0;                            // A / B / D = ring roads (inner, middle, outer), C = connector A-B, E = connector B-D
    Mesh road, roadC, roadE, verge, vergeC, vergeE, trk, trkV;                         // ring roads / connector road / ring verges / connector verges; trk / trkV = dirt track + its verges (filled by Terrain)
    std::unordered_map<long long, std::vector<float>> grid;  // road centre samples (x, z, halfwidth) per 24 m cell
    bool ready = false;
};
static Net gNet;
static const int RG = 24;
static inline long long cellKey(long cx, long cz){ return (long long)(cx + 100000) * 200003LL + (cz + 100000); }

static Curve makeRing(double radius, double width){
    Curve c; const int seg = (int)jsRound(radius * 2.3);
    for (int i = 0; i < seg; i++){ double a = (double)i / seg * PI * 2 + RING_PHASE, px, pz; ringPt(radius, a, px, pz); c.pts.push_back({px, ROAD_SURF, pz}); }
    c.closed = true; c.hw = width / 2; c.build(); return c;
}
// mesh quality: polyline stays within ROAD_TOL metres of the true centre line; step 1.5 m in tight bends up to 6 m on straights
static const double ROAD_TOL = 0.03, STEP_MIN = 1.5, STEP_MAX = 6.0;

static void addRing(Mesh& road, Mesh& verge, const Curve& cv){
    const double len = cv.length(), hw = cv.hw;
    const int roadRep = std::max(1, (int)jsRound(len / 8)), shRep = std::max(1, (int)jsRound(len / 2.5));
    // no road / sand across the river: the bridge deck is the roadway there (same sampling as buildRoadRing() in the HTML)
    const int SS = (int)std::ceil(len / 1.2); std::vector<char> inRv;
    for (int i = 0; i < SS; i++){ V3 q = cv.getPointAt((double)i / SS); inRv.push_back(std::fabs(River::riverSd(q.x, q.z)) < River::RIVER_WALL + 5); }
    int r0 = -1; for (int i = 0; i < SS; i++) if (!inRv[i]){ r0 = i; break; }
    struct Run { double a, b; bool full; std::vector<double> ts; }; std::vector<Run> runs;
    if (r0 >= 0){ int i = 0; while (i < SS){ if (inRv[(r0 + i) % SS]){ i++; continue; } int j = i; while (j < SS && !inRv[(r0 + j) % SS]) j++; runs.push_back({(double)(r0 + i) / SS, (double)(r0 + j) / SS, j - i == SS, {}}); i = j; } }
    for (Run& r : runs){ const double a = r.full ? 0.0 : r.a, b = r.full ? 1.0 : r.b; r.ts = adaptiveT(cv, a, b, ROAD_TOL, STEP_MIN, STEP_MAX); }
    const std::vector<Prof> ASPH = {{hw, ROAD_SURF, hw}, {-hw, ROAD_SURF, -hw}};   // asphalt: u = metres from the centre line, v = half width (lane marking shader)
    if (r0 < 0) buildStrip(road, cv, adaptiveT(cv, 0, 1, ROAD_TOL, STEP_MIN, STEP_MAX), ASPH, roadRep, 0, 1, true, hw);
    for (const Run& r : runs){
        if (r.full) buildStrip(road, cv, r.ts, ASPH, roadRep, 0, 1, true, hw);
        else { const double L = (r.b - r.a) * len; buildStrip(road, cv, r.ts, ASPH, std::max(1, (int)jsRound(L / 8)), r.a, r.b, false, hw); }
    }
    static const double SP[4][2] = {{-1.5, 0.075}, {0, 0.08}, {3.5, 0.06}, {8, 0.045}};
    for (int s : {1, -1}){
        std::vector<Prof> sh; for (auto& q : SP) sh.push_back({s * (hw + q[0]), q[1], (q[0] + 1.5) / (8 + 1.5)});
        if (s > 0) std::reverse(sh.begin(), sh.end());
        for (const Run& r : runs){
            const double L = (r.b - r.a) * len;
            if (r.full) buildStrip(verge, cv, r.ts, sh, shRep, 0, 1, true);
            else buildStrip(verge, cv, r.ts, sh, std::max(1, (int)jsRound(L / 2.5)), r.a, r.b, false);
        }
    }
}

// connector road between ring radius R0 (inner) and R1 (outer) at ring angle a, S-bend of amplitude amp metres; T-junctions on both ring roads
static Curve makeConn(double R0, double R1, double a, double amp){
    double ax, az, bx, bz; ringPt(R0, a, ax, az); ringPt(R1, a, bx, bz); const int K = 14;
    const double dx = bx - ax, dz = bz - az, dl = std::hypot(dx, dz), px = -dz / dl, pz = dx / dl;
    Curve c; c.closed = false; c.open = true; c.hw = 12.0 / 2;
    for (int i = 0; i <= K; i++){ double t = (double)i / K, off = amp * std::sin(2*PI*t) * std::sin(PI*t); c.pts.push_back({ax + dx*t + px*off, ROAD_SURF, az + dz*t + pz*off}); }
    c.build(); return c;
}
// T-junction fillet: the connector widens towards each ring road along a circular arc of radius FLARE (a real kerb return), tangent to the connector edge on
// one end and to the ring road's edge on the other. Extra half width at arc length d from the start of the connector (full FLARE under the ring road itself).
static const double FLARE = 7.0;
static double connExtra(const Curve& c, double d){
    auto f = [](double dd, double rh){
        if (rh <= 0) return 0.0; const double x = rh + FLARE - dd;            // distance from the arc's centre, along the connector
        if (x >= FLARE) return FLARE; if (x <= 0) return 0.0;
        return FLARE - std::sqrt(FLARE * FLARE - x * x);
    };
    return std::max(f(d, c.rA), f(c.length() - d, c.rB));
}
static double connWiden(const Curve& c, double t){ return connExtra(c, t * c.length()); }
// samples along the connector (curve parameter t0..t1): 1.5 m, but every 0.3 m inside the fillets where the edge sweeps out quickly
static std::vector<double> connT(const Curve& c, double t0, double t1){
    const double len = c.length(); std::vector<double> ts; double s = t0 * len; const double e = t1 * len;
    while (s < e - 1e-6){ ts.push_back(s / len); const bool fine = s < c.rA + FLARE + 1.0 || s > len - c.rB - FLARE - 1.0; s += fine ? 0.3 : 1.5; }
    ts.push_back(t1); return ts;
}

// connector ribbon + its verges (trimmed so the sand does not run over the ring roads)
static void addConn(Mesh& road, Mesh& vergeM, const Curve& c, const Curve& inner, const Curve& outer){
    const double len = c.length(), hw = c.hw, t1 = 0.99999;
    buildStrip(road, c, connT(c, 0, t1), {{hw, ROAD_SURF, hw}, {-hw, ROAD_SURF, -hw}}, std::max(1, (int)jsRound(len / 8)), 0, t1, false, hw, connWiden);
    static const double SP[4][2] = {{-1.5, 0.075}, {0, 0.08}, {3.5, 0.06}, {8, 0.045}};
    const int shRep = std::max(1, (int)jsRound(len / 2.5));
    const double sT0 = std::min(0.35, inner.hw * 1.5 / len), sT1 = 1 - std::min(0.35, outer.hw * 1.5 / len), fS = sT1 - sT0;
    for (int sd : {1, -1}){
        std::vector<Prof> sh; for (auto& q : SP) sh.push_back({sd * (hw + q[0]), q[1], (q[0] + 1.5) / (8 + 1.5)});
        if (sd > 0) std::reverse(sh.begin(), sh.end());
        buildStrip(vergeM, c, connT(c, sT0, sT1), sh, std::max(1, (int)jsRound(shRep * fS)), sT0, sT1, false, -1, connWiden);
    }
}

static void init(){
    Net& n = gNet; if (n.ready) return;
    River::init();
    n.A = makeRing(220, 14); n.B = makeRing(420, 15); n.D = makeRing(640, 15);
    n.riverAng = pickRiverAngle();
    // connector roads: a gentle S-bend between two ring roads with a T-junction on each. C (A-B) crosses the north slope, E (B-D) the south-east one:
    // both stay clear of the start line, the river and the tributaries
    n.C = makeConn(220, 420, -PI / 2 + 0.10, 18.0);
    n.E = makeConn(420, 640, 0.72, 22.0);
    n.C.rA = n.A.hw; n.C.rB = n.B.hw; n.E.rA = n.B.hw; n.E.rB = n.D.hw;                 // T-junction flares
    addRing(n.road, n.verge, n.A); addRing(n.road, n.verge, n.B); addRing(n.road, n.verge, n.D);
    addConn(n.roadC, n.vergeC, n.C, n.A, n.B);
    addConn(n.roadE, n.vergeE, n.E, n.B, n.D);
    // grid of centre-line samples -> distance from the nearest road EDGE
    for (const Curve* cv : {&n.A, &n.B, &n.C, &n.D, &n.E}){
        const int cnt = (int)std::ceil(cv->length() / 2);
        for (int i = 0; i <= cnt; i++){
            V3 p = cv->getPointAt(cv->open ? std::min((double)i / cnt, 0.99999) : (double)(i % cnt) / cnt);
            auto& l = n.grid[cellKey((long)std::floor(p.x / RG), (long)std::floor(p.z / RG))];
            l.push_back((float)p.x); l.push_back((float)p.z);
            l.push_back((float)(cv->hw + (cv->open ? connExtra(*cv, std::min((double)i / cnt, 0.99999) * cv->length()) : 0.0)));   // flared junction mouths count as road
        }
    }
    n.ready = true;
}

// distance from the nearest road EDGE (negative = on the road)
static float clearance(float x, float z){
    long cx = (long)std::floor(x / RG), cz = (long)std::floor(z / RG); float best = 1e9f;
    for (int i = -1; i <= 1; i++) for (int j = -1; j <= 1; j++){
        auto it = gNet.grid.find(cellKey(cx + i, cz + j)); if (it == gNet.grid.end()) continue;
        const std::vector<float>& l = it->second;
        for (size_t k = 0; k < l.size(); k += 3){ float dx = x - l[k], dz = z - l[k+1], d = std::sqrt(dx*dx + dz*dz) - l[k+2]; if (d < best) best = d; }
    }
    return best;
}

// grip / drag / ride height under the tyres (surfaceAt in the HTML): tarmac-like road, softer verge, grass
struct SurfaceInfo { double mu, rr, rideY; };
static SurfaceInfo surfaceAt(float x, float z){
    double c = clearance(x, z), t = std::min(std::max((c - 0.8) / 2.2, 0.0), 1.0), g = t*t*(3 - 2*t);
    double u = std::min(std::max((c - 0.3) / 2.4, 0.0), 1.0);
    return {1.15 - 0.3 * g, 0.028 + 0.06 * g, ROAD_SURF * (1 - u*u*(3 - 2*u))};
}
// where the HTML puts the car: on roadA at the start line, facing along the road
static void startPose(double& x, double& z, double& heading){
    V3 p = gNet.A.getPointAt(0), t = gNet.A.getTangentAt(0); x = p.x; z = p.z; heading = std::atan2(t.x, t.z);
}

} // namespace Road
