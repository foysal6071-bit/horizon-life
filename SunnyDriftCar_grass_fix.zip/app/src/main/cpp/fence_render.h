// Sunny Drift - OpenGL ES 3 rendering of the roadside fence (posts, mounds, ropes, flying dirt) and the wooden lamp poles (see fence.h).
//  every part is one instanced draw (model matrix + tint per instance); the instance lists are rebuilt each frame by Fence::build()
#pragma once
#include <GLES3/gl3.h>
#include "fence.h"

namespace FenceGL {

static const char* FVS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in vec3 n; layout(location=2) in vec2 t; layout(location=3) in vec3 c;
layout(location=4) in vec4 m0; layout(location=5) in vec4 m1; layout(location=6) in vec4 m2; layout(location=7) in vec4 m3; layout(location=8) in vec3 tint;
uniform mat4 uVP; out vec3 vn; out vec3 wp; out vec3 vc; out vec2 vt;
void main(){
  mat4 M = mat4(m0, m1, m2, m3); vec4 w = M * vec4(p, 1.0);
  wp = w.xyz; vn = mat3(M) * n; vt = t; vc = c * tint; gl_Position = uVP * w;
}
)GLSL";
static const char* FFS = R"GLSL(#version 300 es
precision highp float;
in vec3 vn; in vec3 wp; in vec3 vc; in vec2 vt;
uniform sampler2D uTex; uniform vec3 uCam, uBase; uniform float uUseTex, uSrgb, uUnlit, uBump;
out vec4 o;
void main(){
  vec3 base = vc * uBase;
  vec3 N = normalize(vn); if (!gl_FrontFacing) N = -N;
  float cav = 1.0;
  if (uUseTex > 0.5){
    vec3 tx = texture(uTex, vt).rgb; float hgt = tx.g;
    if (uSrgb > 0.5) tx = pow(tx, vec3(2.2));
    base *= tx;
    if (uBump > 0.0){                                   // screen-space bump map: the bark / grain luminance becomes real relief (cracks, ridges, strands)
      vec3 dpx = dFdx(wp), dpy = dFdy(wp); float hx = dFdx(hgt) * uBump, hy = dFdy(hgt) * uBump;
      vec3 r1 = cross(dpy, N), r2 = cross(N, dpx); float det = dot(dpx, r1);
      vec3 grad = sign(det) * (hx * r1 + hy * r2);
      N = normalize(abs(det) * N - grad);
    }
    cav = mix(0.70, 1.0, smoothstep(0.10, 0.65, hgt));  // deep cracks sit in shadow
  }
  vec3 L = normalize(vec3(0.4, 0.8, 0.3)), V = normalize(uCam - wp), H = normalize(L + V);
  float d = max(dot(N, L), 0.0), wrap = max(dot(N, L) * 0.5 + 0.5, 0.0);
  vec3 amb = mix(vec3(0.20, 0.18, 0.13), vec3(0.32, 0.39, 0.50), N.y * 0.5 + 0.5);      // warm ground bounce below, cool sky above
  vec3 sun = vec3(1.0, 0.93, 0.78);
  vec3 lit = (uUnlit > 0.5) ? base : base * (amb * cav + sun * (0.78 * d + 0.12 * wrap) * mix(0.6, 1.0, cav));
  if (uUnlit < 0.5 && uUseTex > 0.5){                   // faint dry-wood sheen + bleached silvery fresnel edge
    lit += sun * pow(max(dot(N, H), 0.0), 22.0) * 0.035 * cav;
    lit += vec3(0.30, 0.34, 0.38) * pow(1.0 - max(dot(N, V), 0.0), 4.0) * 0.05 * base;
  }
  vec3 c = pow(lit, vec3(1.0 / 2.2));                                   // linear -> display, like three.js
  c = mix(c, vec3(0.62, 0.80, 0.95), clamp(length(uCam - wp) / 2500.0, 0.0, 1.0));
  o = vec4(c, 1.0);
}
)GLSL";

struct GeoGL { GLuint vao = 0, vbo = 0, ibo = 0; GLsizei count = 0; };
static GeoGL gPost, gMound, gRope, gSeg, gPart, gPole, gShade, gHead;
static GLuint gProg = 0, gInst = 0, gBark = 0, gRopeT = 0, gWood = 0;
static GLint uVP, uCam, uBase, uUseTex, uSrgb, uUnlit, uTex, uBump;
static bool gOk = false;

static GLuint sh(GLenum t, const char* s){ GLuint x = glCreateShader(t); glShaderSource(x, 1, &s, nullptr); glCompileShader(x); return x; }
static GeoGL upload(const Fence::Mesh& m){
    GeoGL g; g.count = (GLsizei)m.idx.size(); if (!g.count) return g;
    std::vector<float> vb((size_t)m.vc() * 11);
    for (int i = 0; i < m.vc(); i++){
        for (int k = 0; k < 3; k++){ vb[i*11+k] = m.p[i*3+k]; vb[i*11+3+k] = m.n[i*3+k]; vb[i*11+8+k] = m.c[i*3+k]; }
        vb[i*11+6] = m.uv[i*2]; vb[i*11+7] = m.uv[i*2+1];
    }
    glGenVertexArrays(1, &g.vao); glBindVertexArray(g.vao);
    glGenBuffers(1, &g.vbo); glBindBuffer(GL_ARRAY_BUFFER, g.vbo); glBufferData(GL_ARRAY_BUFFER, vb.size() * 4, vb.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 44, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 44, (void*)12);
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 44, (void*)24);
    glEnableVertexAttribArray(3); glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 44, (void*)32);
    glGenBuffers(1, &g.ibo); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, g.ibo); glBufferData(GL_ELEMENT_ARRAY_BUFFER, m.idx.size() * 2, m.idx.data(), GL_STATIC_DRAW);
    glBindVertexArray(0); return g;
}
static GLuint tex(const std::vector<uint8_t>& px, int w, int h){
    GLuint t; glGenTextures(1, &t); glBindTexture(GL_TEXTURE_2D, t);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, px.data()); glGenerateMipmap(GL_TEXTURE_2D);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    return t;
}

// Call once with a current GL context, after Terrain::init() and Bridge/BridgeGL::init().
static void init(){
    Fence::init();
    gProg = glCreateProgram(); glAttachShader(gProg, sh(GL_VERTEX_SHADER, FVS)); glAttachShader(gProg, sh(GL_FRAGMENT_SHADER, FFS)); glLinkProgram(gProg);
    uVP = glGetUniformLocation(gProg, "uVP"); uCam = glGetUniformLocation(gProg, "uCam"); uBase = glGetUniformLocation(gProg, "uBase");
    uUseTex = glGetUniformLocation(gProg, "uUseTex"); uSrgb = glGetUniformLocation(gProg, "uSrgb"); uUnlit = glGetUniformLocation(gProg, "uUnlit"); uTex = glGetUniformLocation(gProg, "uTex"); uBump = glGetUniformLocation(gProg, "uBump");
    gPost = upload(Fence::G.post); gMound = upload(Fence::G.mound); gRope = upload(Fence::G.rope); gSeg = upload(Fence::G.seg); gPart = upload(Fence::G.part);
    gPole = upload(Fence::G.pole); gShade = upload(Fence::G.shade); gHead = upload(Fence::G.head);
    gBark = tex(Fence::G.barkTex, Fence::G.barkW, Fence::G.barkH); gRopeT = tex(Fence::G.ropeTex, Fence::G.ropeS, Fence::G.ropeS); gWood = tex(Fence::G.woodTex, Fence::G.woodW, Fence::G.woodH);
    glGenBuffers(1, &gInst); gOk = true;
}

static void drawInst(const GeoGL& g, const std::vector<float>& inst){
    const GLsizei n = (GLsizei)(inst.size() / 19); if (!n || !g.count) return;
    glBindVertexArray(g.vao); glBindBuffer(GL_ARRAY_BUFFER, gInst); glBufferData(GL_ARRAY_BUFFER, inst.size() * 4, inst.data(), GL_STREAM_DRAW);
    for (int i = 0; i < 4; i++){ glEnableVertexAttribArray(4 + i); glVertexAttribPointer(4 + i, 4, GL_FLOAT, GL_FALSE, 76, (void*)(intptr_t)(16 * i)); glVertexAttribDivisor(4 + i, 1); }
    glEnableVertexAttribArray(8); glVertexAttribPointer(8, 3, GL_FLOAT, GL_FALSE, 76, (void*)(intptr_t)64); glVertexAttribDivisor(8, 1);
    glDrawElementsInstanced(GL_TRIANGLES, g.count, GL_UNSIGNED_SHORT, (void*)0, n);
    glBindVertexArray(0);
}
static void material(GLuint t, bool srgb, float r, float g, float b, bool unlit, float bump = 0.f){
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, t ? t : 0); glUniform1i(uTex, 0);
    glUniform1f(uUseTex, t ? 1.f : 0.f); glUniform1f(uSrgb, srgb ? 1.f : 0.f); glUniform3f(uBase, r, g, b); glUniform1f(uUnlit, unlit ? 1.f : 0.f); glUniform1f(uBump, bump);
}

// VP = projection*view (column-major), V = view matrix (for the camera forward), eye = camera position
static void draw(const float* VP, const float* V, const float* eye){
    if (!gOk) return;
    const float fwd[3] = {-V[2], -V[6], -V[10]}; const float l = std::sqrt(fwd[0]*fwd[0] + fwd[2]*fwd[2]); const float f2[3] = {l > 1e-5f ? fwd[0] / l : 0.f, 0.f, l > 1e-5f ? fwd[2] / l : 1.f};
    Fence::build(eye, f2);
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glDisable(GL_BLEND);
    glUseProgram(gProg); glUniformMatrix4fv(uVP, 1, GL_FALSE, VP); glUniform3fv(uCam, 1, eye);
    material(gBark, false, 1, 1, 1, false, 0.020f);                  // bark: luminance map (linear) x vertex colours
    drawInst(gPost, Fence::gI.posts); drawInst(gMound, Fence::gI.mounds);
    material(gRopeT, true, 1, 1, 1, false, 0.006f);                  // twisted rope
    drawInst(gRope, Fence::gI.ropes); drawInst(gSeg, Fence::gI.segs);
    material(0, false, 1, 1, 1, false);                      // dirt / splinter chunks (vertex colour only; tint = colour)
    drawInst(gPart, Fence::gI.parts);
    material(gWood, true, 1, 1, 1, false, 0.018f);                   // lamp poles: weathered bark
    drawInst(gPole, Fence::gI.lamps);
    material(0, false, 0.019f, 0.022f, 0.026f, false);       // dark enamel lantern shade (0x26292d)
    drawInst(gShade, Fence::gI.lamps);
    material(0, false, 0.25f, 0.25f, 0.25f, true);           // lens (0x888888, unlit, day colour)
    drawInst(gHead, Fence::gI.lamps);
    glActiveTexture(GL_TEXTURE0);
}

} // namespace FenceGL
