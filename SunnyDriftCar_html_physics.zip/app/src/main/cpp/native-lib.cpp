#include <jni.h>
#include <GLES3/gl3.h>
#include <android/asset_manager.h>
#include <android/asset_manager_jni.h>
#include <chrono>
#include <sstream>
#include "car_core.h"
#include "night.h"           // night mode + headlight light pool (ported from the HTML game)
#include "car_render.h"      // Audi R8 look (materials, glass, lights), rolling / steering wheels, body roll + pitch (ported from the HTML game)
#include "road.h"             // winding mud roads: geometry (ported from the HTML game)
#include "road_render.h"      // winding mud roads: textures + shaders
#include "bridge_render.h"    // river bed + water + wooden bridges (ported from the HTML game)
#include "terrain.h"          // rolling hills, distant mountains, dirt track (ported from the HTML game)
#include "terrain_render.h"
#include "tree_render.h"      // green trees (ported from the HTML game)
#include "fence_render.h"     // roadside post-and-rope fence (breakable) + wooden lamp poles (ported from the HTML game)

// ---------- model ----------
struct Group { int start, count; float r, g, b; };
static vector<Group> gGroups;
static GLuint gVBO = 0, gIBO = 0, gGroundVBO = 0, gProg = 0;
static GLint uMVP, uModel, uColor, uCam;
static int gW = 1, gH = 1, gInputMask = 0, gN = 0, gGroundN = 0;
static CarState gCar; static Surface gSurf; static Input gIn;
static chrono::steady_clock::time_point gLast;
static bool gReady = false;

static vector<char> readAsset(AAssetManager* am, const char* name){
    AAsset* a = AAssetManager_open(am, name, AASSET_MODE_BUFFER);
    vector<char> d; if (!a) return d;
    d.resize(AAsset_getLength(a)); AAsset_read(a, d.data(), d.size()); AAsset_close(a); return d;
}

static GLuint compile(GLenum t, const char* s){
    GLuint sh = glCreateShader(t); glShaderSource(sh, 1, &s, nullptr); glCompileShader(sh); return sh;
}

static void loadModel(AAssetManager* am){
    vector<char> meta = readAsset(am, "r8_meta.txt"), raw = readAsset(am, "r8.bin");
    istringstream mf(string(meta.begin(), meta.end()));
    int n, ni, ng; double mn[3], sz[3];
    mf >> n >> ni >> mn[0] >> mn[1] >> mn[2] >> sz[0] >> sz[1] >> sz[2] >> ng;
    gGroups.clear();
    for (int i = 0; i < ng; i++){
        string name, col; int s, c, em; mf >> name >> s >> c >> col >> em;
        unsigned r = 128, g = 128, b = 128; sscanf(col.c_str(), "#%02x%02x%02x", &r, &g, &b);
        if (c == 0 || s >= 152712) continue;                // skip empty + under-car neon
        gGroups.push_back({s, c, r / 255.f, g / 255.f, b / 255.f});
    }
    const uint16_t* pos = (const uint16_t*)raw.data();
    const int8_t* nor = (const int8_t*)(raw.data() + n * 6);
    const double S = 2.8 / 2643.1, ZC = -104.45;
    vector<float> vb(n * 6);
    for (int i = 0; i < n; i++){
        double rx = mn[0] + pos[i*3]   / 65535.0 * sz[0];
        double ry = mn[1] + pos[i*3+1] / 65535.0 * sz[1];
        double rz = mn[2] + pos[i*3+2] / 65535.0 * sz[2];
        vb[i*6] = (float)((rz - ZC) * S); vb[i*6+1] = (float)(ry * S); vb[i*6+2] = (float)(-rx * S);
        double nx = nor[i*4] / 127.0, ny = nor[i*4+1] / 127.0, nz = nor[i*4+2] / 127.0;
        double l = sqrt(nx*nx + ny*ny + nz*nz); if (l == 0) l = 1;
        vb[i*6+3] = (float)(nz / l); vb[i*6+4] = (float)(ny / l); vb[i*6+5] = (float)(-nx / l);
    }
    glGenBuffers(1, &gVBO); glBindBuffer(GL_ARRAY_BUFFER, gVBO);
    glBufferData(GL_ARRAY_BUFFER, vb.size() * 4, vb.data(), GL_STATIC_DRAW);
    glGenBuffers(1, &gIBO); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gIBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, ni * 2, raw.data() + n * 10, GL_STATIC_DRAW);
    gN = n;
    // ground: flat quads around the hilly area (normal up). Inside it the ground is the river patch (BridgeGL) + two hill strips (TerrainGL).
    {
        const float G = 3000, X0 = (float)River::GX0, X1 = (float)River::GX1, Z0 = (float)River::GZ0, Z1 = (float)River::PZ1;
        const float HX0 = (float)Terrain::LX0, HX1 = (float)(Terrain::LX0 + Terrain::LNX * Terrain::LC), HZ0 = (float)Terrain::LZ0, HZ1 = (float)(Terrain::LZ0 + Terrain::LNZ * Terrain::LC);
        const float R[8][4] = {{-G, -G, X0, G}, {X1, -G, G, G}, {X0, -G, X1, HZ0}, {X0, HZ1, X1, G},                 // x0 z0 x1 z1
                               {X0, HZ0, HX0, Z0}, {HX1, HZ0, X1, Z0}, {X0, Z1, HX0, HZ1}, {HX1, Z1, X1, HZ1}};
        vector<float> gv;
        for (auto& r : R){
            const float q[6][2] = {{r[0], r[1]}, {r[2], r[1]}, {r[0], r[3]}, {r[2], r[1]}, {r[2], r[3]}, {r[0], r[3]}};
            for (auto& p : q){ const float v[6] = {p[0], -0.06f, p[1], 0, 1, 0}; gv.insert(gv.end(), v, v + 6); }
        }
        gGroundN = (int)(gv.size() / 6);
        glGenBuffers(1, &gGroundVBO); glBindBuffer(GL_ARRAY_BUFFER, gGroundVBO);
        glBufferData(GL_ARRAY_BUFFER, gv.size() * 4, gv.data(), GL_STATIC_DRAW);
    }
}

// ---------- tiny matrix helpers (column-major) ----------
typedef float M4[16];
static void ident(M4 m){ memset(m, 0, 64); m[0] = m[5] = m[10] = m[15] = 1; }
static void mul(M4 o, const M4 a, const M4 b){
    M4 t; for (int c = 0; c < 4; c++) for (int r = 0; r < 4; r++){
        float s = 0; for (int k = 0; k < 4; k++) s += a[k*4+r] * b[c*4+k]; t[c*4+r] = s; }
    memcpy(o, t, 64);
}
static void persp(M4 m, float fov, float asp, float n, float f){
    float t = 1.f / tanf(fov / 2); memset(m, 0, 64);
    m[0] = t / asp; m[5] = t; m[10] = (f + n) / (n - f); m[11] = -1; m[14] = 2 * f * n / (n - f);
}
static void lookAt(M4 m, const float* e, const float* c){
    float f[3] = {c[0]-e[0], c[1]-e[1], c[2]-e[2]}; float l = sqrtf(f[0]*f[0]+f[1]*f[1]+f[2]*f[2]);
    for (float& v : f) v /= l;
    float s[3] = {f[1]*0 - f[2]*1, f[2]*0 - f[0]*0, f[0]*1 - f[1]*0};           // f x up(0,1,0)
    l = sqrtf(s[0]*s[0]+s[1]*s[1]+s[2]*s[2]); for (float& v : s) v /= l;
    float u[3] = {s[1]*f[2]-s[2]*f[1], s[2]*f[0]-s[0]*f[2], s[0]*f[1]-s[1]*f[0]};
    ident(m);
    m[0]=s[0]; m[4]=s[1]; m[8]=s[2];  m[1]=u[0]; m[5]=u[1]; m[9]=u[2];  m[2]=-f[0]; m[6]=-f[1]; m[10]=-f[2];
    m[12] = -(s[0]*e[0]+s[1]*e[1]+s[2]*e[2]); m[13] = -(u[0]*e[0]+u[1]*e[1]+u[2]*e[2]); m[14] = f[0]*e[0]+f[1]*e[1]+f[2]*e[2];
}
static void rotY(M4 m, float a, float tx, float tz){
    ident(m); float c = cosf(a), s = sinf(a); m[0] = c; m[2] = -s; m[8] = s; m[10] = c; m[12] = tx; m[14] = tz;
}

static void drawMesh(GLuint vbo){
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 24, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 24, (void*)12);
}

extern "C" {
JNIEXPORT void JNICALL Java_com_sunny_car_MainActivity_nInit(JNIEnv* env, jclass, jobject amgr){
    AAssetManager* am = AAssetManager_fromJava(env, amgr);
    const char* vs = "#version 300 es\nlayout(location=0) in vec3 p; layout(location=1) in vec3 n;\n"
        "uniform mat4 uMVP, uModel; out vec3 vn; out vec3 wp;\n"
        "void main(){ vn = mat3(uModel)*n; wp = (uModel*vec4(p,1)).xyz; gl_Position = uMVP*vec4(p,1); }";
    const char* fs = "#version 300 es\nprecision mediump float; in vec3 vn; in vec3 wp;\n"
        "uniform vec3 uColor, uCam; out vec4 o;\n"
        "void main(){ vec3 N = normalize(vn), L = normalize(vec3(0.4,0.8,0.3)), V = normalize(uCam-wp);\n"
        " float d = max(dot(N,L),0.0); float s = pow(max(dot(N,normalize(L+V)),0.0), 48.0);\n"
        " vec3 c = uColor*(0.35 + 0.75*d) + vec3(0.35)*s;\n"
        " c = mix(c, vec3(0.62,0.80,0.95), clamp(length(uCam-wp)/2500.0, 0.0, 1.0));\n"
        " o = vec4(c,1); }";
    gProg = glCreateProgram();
    glAttachShader(gProg, compile(GL_VERTEX_SHADER, vs)); glAttachShader(gProg, compile(GL_FRAGMENT_SHADER, fs));
    glLinkProgram(gProg);
    uMVP = glGetUniformLocation(gProg, "uMVP"); uModel = glGetUniformLocation(gProg, "uModel");
    uColor = glGetUniformLocation(gProg, "uColor"); uCam = glGetUniformLocation(gProg, "uCam");
    loadModel(am);
    NightGL::init();
    CarGL::init(readAsset(am, "r8.bin"), readAsset(am, "r8_meta.txt"), readAsset(am, "r8_groups.txt"));   // HTML car materials + separate wheels
    Road::init();                                            // ring roads + connector (centre lines, meshes, clearance grid)
    Terrain::init((uint32_t)chrono::steady_clock::now().time_since_epoch().count());   // hills + dirt track + mountains (different on every launch, like the HTML)
    RoadGL::init(readAsset(am, "road_a.rgba"), readAsset(am, "road_a_h.bin"), readAsset(am, "road_b.rgba"),
                 readAsset(am, "road_b_h.bin"), readAsset(am, "road_verge.rgba"));
    TreeGL::init(readAsset(am, "tree_raw.bin"), readAsset(am, "tree_meta.txt"),
                 readAsset(am, "tree_leaf.rgba"), readAsset(am, "tree_bark.rgba"), 6.0f);   // trees keep clear of every road (Road::clearance)
    BridgeGL::init();                                        // river bed (with the hills) + water + bridges (needs the road textures)
    TerrainGL::init();                                       // hill strips + distant mountains
    FenceGL::init();                                         // fence posts + ropes + lamp poles (needs the hills, river and bridges)
    gCar = CarState(); Road::startPose(gCar.x, gCar.z, gCar.heading);   // start line on the inner road, facing along it
    gLast = chrono::steady_clock::now(); gReady = true;
}
JNIEXPORT void JNICALL Java_com_sunny_car_MainActivity_nResize(JNIEnv*, jclass, jint w, jint h){ gW = w; gH = h; glViewport(0, 0, w, h); }
JNIEXPORT void JNICALL Java_com_sunny_car_MainActivity_nInput(JNIEnv*, jclass, jint m){ gInputMask = m; }
JNIEXPORT void JNICALL Java_com_sunny_car_MainActivity_nNight(JNIEnv*, jclass, jint on){ NightGL::target = on ? 1.f : 0.f; }
JNIEXPORT jfloat JNICALL Java_com_sunny_car_MainActivity_nSpeed(JNIEnv*, jclass){ return (jfloat)fabs(gCar.speed * 3.6); }

JNIEXPORT void JNICALL Java_com_sunny_car_MainActivity_nDraw(JNIEnv*, jclass){
    if (!gReady) return;
    auto now = chrono::steady_clock::now();
    double dt = chrono::duration<double>(now - gLast).count(); gLast = now; dt = min(dt, 0.05);
    { static double dtS = 0.016; dtS += (dt - dtS) * 0.2; dt = dtS; }       // HTML: smoothed step, so uneven frame times no longer jerk the car
    gIn.left = gInputMask & 1; gIn.right = gInputMask & 2; gIn.gas = gInputMask & 4; gIn.brake = gInputMask & 8; gIn.hand = gInputMask & 16;
    Road::SurfaceInfo si = Road::surfaceAt((float)gCar.x, (float)gCar.z);   // road / verge / grass grip
    gSurf.mu = si.mu; gSurf.rr = si.rr;
    if (Road::clearance((float)gCar.x, (float)gCar.z) > 1.5f){            // packed dirt track: more grip than grass, less than tarmac
        Terrain::trackQ(gCar.x, gCar.z);
        if (Terrain::tkD < 3.4){ const double k = 1 - River::sstep(2.1, 3.4, Terrain::tkD); gSurf.mu = gSurf.mu * (1 - k) + 1.05 * k; gSurf.rr = gSurf.rr * (1 - k) + 0.032 * k; }
    }
    // 4 wheels sample the hills: ride height, pitch, roll and the pull of gravity come from where the tyres really are (HTML "vehicle dynamics")
    static double carGy = 0, gyV = 0, tRoll = 0, ptT = 0; static bool gyAir = false;
    double terrG = 0, tRollT = 0, gRide = 0;
    {
        const double sH = sin(gCar.heading), cH = cos(gCar.heading), A = 1.4, B = 0.85;
        auto hw = [&](double f, double l){ return Terrain::carGroundH(gCar.x + sH * f + cH * l, gCar.z + cH * f - sH * l); };      // f = metres forward, l = metres to the LEFT
        const double hFL = hw(A, B), hFR = hw(A, -B), hRL = hw(-A, B), hRR = hw(-A, -B);
        const double hF = (hFL + hFR) / 2, hR = (hRL + hRR) / 2, hLf = (hFL + hRL) / 2, hRt = (hFR + hRR) / 2, avg = (hF + hR) / 2;
        const double g = (hF - hR) / (2 * A), sl = (hLf - hRt) / (2 * B);                  // slope along the car (+ = uphill) and across it (+ = left side higher)
        const double lift = max(0.0, max(max(hFL - (avg + A*g + B*sl), hFR - (avg + A*g - B*sl)), max(hRL - (avg - A*g + B*sl), hRR - (avg - A*g - B*sl))));   // no tyre may sink into the ground
        gRide = avg + lift; terrG = g; tRollT = atan(sl);
    }
    // bridge deck under the tyres: height + slope along the car (HTML carGroundH / bridgeLift); gravity pulls on the slope
    static double bridgeY = 0, pitchS = 0; double bhAvg = 0, bridgeG = 0;
    {
        const double sH0 = sin(gCar.heading), cH0 = cos(gCar.heading), A = 1.4;
        const double hF = Bridge::lift(gCar.x + sH0 * A, gCar.z + cH0 * A), hR = Bridge::lift(gCar.x - sH0 * A, gCar.z - cH0 * A);
        bridgeG = (hF - hR) / (2 * A); bhAvg = (hF + hR) / 2;
        const double gT = (gyAir ? 0 : terrG) + bridgeG, sn = gT / sqrt(1 + gT * gT); gCar.slope += (sn - gCar.slope) * (1 - exp(-10 * dt));
        bridgeY += (bhAvg - bridgeY) * (1 - exp(-(bhAvg > 0.002 || bridgeY > 0.002 ? 45 : 10) * dt));
        const double pt = gyAir ? clampd(atan2(gyV, max(fabs(gCar.speed), 4.0)), -0.55, 0.55) : atan(bridgeG + terrG);
        ptT = pt; pitchS += (pt - pitchS) * (1 - exp(-12 * dt));
    }
    {   // follow the hills: stuck to the ground on slopes, but flies off steep drops and crests and lands again
        const double idt = max(dt, 0.001);
        if (!gyAir){
            const double vg = (gRide - carGy) / idt;
            if (gCar.speed > 4 && vg < gyV - 18 * dt - 1.5) gyAir = true;
            else { gyV += (vg - gyV) * (1 - exp(-25 * dt)); carGy = gRide; }
        }
        if (gyAir){
            gyV -= 18 * dt; carGy += gyV * dt;
            if (carGy <= gRide){ carGy = gRide; gyAir = false; if (gyV < -9) gCar.speed *= 0.96; gyV = 0; }
        }
        tRoll += ((gyAir ? 0 : tRollT) - tRoll) * (1 - exp(-16 * dt));
    }
    if (dt > 0){ Veh::step(gCar, gIn, gSurf, dt); CarGL::update(gCar, dt, gyAir, pitchS, ptT, tRoll, tRollT); }
    NightGL::update(dt);   // + suspension springs, wheel roll / steer, brake light
    Fence::update(gCar, dt);                                     // posts / ropes are knocked over, lamp poles are solid (HTML fencePosts + lampCollide)
    Bridge::collide(gCar);                                       // rails, bridge mouth, river walls
    {   // HTML checkCollisions: invisible wall at the edge of the world (radius 960 m), the car loses half its speed against it
        const double r = hypot(gCar.x, gCar.z), LIM = 960;
        if (r > LIM){ gCar.x *= LIM / r; gCar.z *= LIM / r; gCar.speed *= 0.5; gCar.vy *= 0.5; gCar.yaw *= sqrt(0.5); }
    }

    glClearColor(0.62f, 0.80f, 0.95f, 1); glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE);
    glUseProgram(gProg);

    float h = (float)gCar.heading, fx = sinf(h), fz = cosf(h);
    const float baseY = (float)(carGy + bridgeY);                // the camera rides on the hills with the car
    float eye[3] = { (float)gCar.x - fx * 7.5f, baseY + 2.6f, (float)gCar.z - fz * 7.5f };
    eye[1] = max(eye[1], (float)Terrain::meshH(eye[0], eye[2]) + 1.0f);          // never inside a hill behind the car
    float ctr[3] = { (float)gCar.x + fx * 2.0f, baseY + 0.9f, (float)gCar.z + fz * 2.0f };
    M4 P, V, VP, I, MVP, Mdl; persp(P, 1.0f, (float)gW / gH, 0.2f, 4000); lookAt(V, eye, ctr); mul(VP, P, V);
    glUniform3fv(uCam, 1, eye);

    // ground
    ident(I); mul(MVP, VP, I);
    glUniformMatrix4fv(uMVP, 1, GL_FALSE, MVP); glUniformMatrix4fv(uModel, 1, GL_FALSE, I);
    drawMesh(gGroundVBO); glUniform3f(uColor, 0.30f, 0.58f, 0.25f); glDrawArrays(GL_TRIANGLES, 0, gGroundN);
    BridgeGL::drawTerrain(VP, eye);                              // carved river bed (grass -> wet mud -> gravel) + hills inside the patch
    TerrainGL::draw(VP, eye);                                    // hill strips north / south of the patch + the distant mountain ring
    // winding mud roads + sand verges (own shaders / VAOs), then back to the car program
    RoadGL::draw(VP, eye);
    static const auto t0 = chrono::steady_clock::now();
    const float tSec = (float)chrono::duration<double>(now - t0).count();
    BridgeGL::draw(VP, eye, tSec);                               // bridges (timber, dirt, road blend) + river water
    FenceGL::draw(VP, V, eye);                                   // fence posts + ropes + flying dirt + lamp poles
    glUseProgram(gProg);

    // car: model nose is +X, game heading 0 = +Z  ->  rotation (heading - 90 deg)
    rotY(Mdl, h - 1.5707963f, (float)gCar.x, (float)gCar.z);
    {   // pitch along the bridge arch / hill (about the model Z axis) and roll with the cross slope (about the nose axis): M = Ry * Rz(pitch) * Rx(roll)
        const float cp = (float)cos(pitchS - CarGL::suspPitch), sp = (float)sin(pitchS - CarGL::suspPitch), cr = (float)cos(tRoll + CarGL::suspRoll), sr = (float)sin(tRoll + CarGL::suspRoll);   // slope + suspension (HTML car.rotation.x / .z)
        const float c = Mdl[0], s_ = -Mdl[2];                    // cos / sin of the heading rotation (Mdl[0] = c, Mdl[2] = -s)
        Mdl[0] = c * cp;                 Mdl[1] = sp;       Mdl[2] = -s_ * cp;
        Mdl[4] = -c * cr * sp + s_ * sr; Mdl[5] = cr * cp;  Mdl[6] = s_ * cr * sp + c * sr;
        Mdl[8] = c * sr * sp + s_ * cr;  Mdl[9] = -sr * cp; Mdl[10] = -s_ * sr * sp + c * cr;
    }
    Mdl[13] = (float)(si.rideY + bridgeY + carGy);               // tyres rest on the road / bridge deck / hill (sink to the grass off-road)
    CarGL::draw(VP, Mdl, eye, gCar, NightGL::night);                             // body, glass, lights, 4 wheels, contact shadow (own shader)
    glUseProgram(gProg);

    // green trees (full model nearby, baked billboard far away); wind time in seconds
    TreeGL::draw(VP, V, eye, tSec);

    // night: darken the picture, then the headlight pool and the car lights glow on top of it
    NightGL::overlay();
    NightGL::pool(VP, gCar.x, gCar.z, gCar.heading, carGy + bridgeY);
    CarGL::drawGlow(NightGL::night);
}
}
