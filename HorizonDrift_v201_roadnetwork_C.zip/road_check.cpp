#include <iostream>
#include <cmath>
#include "app/src/main/cpp/road.h"
int main(){ Road::init();
 std::cout<<"nodes="<<Road::NODE_N<<" defs="<<Road::edgeDefs().size()<<" roads="<<Road::gNet.roads.size()<<"\n";
 for(int e=43;e<48;e++){ const auto& c=Road::gNet.roads[e]; double mr=1e9; int n=500; for(int i=0;i<=n;i++){auto p=c.getPointAt((double)i/n);mr=std::min(mr,std::fabs(River::riverSd(p.x,p.z)));} std::cout<<e<<" len="<<c.length()<<" minRiver="<<mr<<"\n"; }
 return Road::gNet.roads.size()==48?0:1; }
