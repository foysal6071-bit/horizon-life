#include <iostream>
#include <cmath>
#include "app/src/main/cpp/road.h"
int main(){Road::init();auto &c=Road::gNet.roads[44]; double best=1e9,bu=0;for(int i=0;i<=10000;i++){double u=(double)i/10000;auto p=c.getPointAt(u);double d=std::fabs(River::riverSd(p.x,p.z));if(d<best){best=d;bu=u;}}auto p=c.getPointAt(bu);auto t=c.getTangentAt(bu);double rx=River::gGx,rz=River::gGz;std::cout<<"u="<<bu<<" d="<<best<<" p="<<p.x<<","<<p.z<<" tangent="<<t.x<<","<<t.z<<" riverNormal="<<rx<<","<<rz<<" dot="<<std::fabs(t.x*rx+t.z*rz)<<" distToEnd="<<std::min(bu,1-bu)*c.length()<<"\n";}
