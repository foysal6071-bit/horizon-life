# HorizonDrift – Road Network C upgrade

## Scope
- Preserves the existing terrain, river, lake, mountains, village locations, world boundary, hill road, and forest gravel road.
- Extends the existing junction-to-junction network from 43 to 48 road edges.
- Adds two new junction nodes while keeping the existing node coordinates unchanged.

## New connections
- **Northern Ridge Bypass (edges 43–44):** creates a second route between the upper village node and the east-side village node, bypassing the existing route through the mountain-side junction.
- **Western Ridge Bypass (edges 45–46):** creates an alternate route between the far-west bridge and the south-west village loop.
- **Southern Connector (edge 47):** joins the former southern dead-end nodes, creating a new southern loop and another way around the lower valley.

## Integration
- `native-lib.cpp` already exports every curve in `Road::gNet.roads` to the minimap, so the added roads appear automatically.
- `Bridge::init()` already checks every road curve and generates bridge geometry for river crossings; the northern bypass river crossing is therefore included automatically.
- Road meshes, road clearance/grip sampling, verge generation, and puddle planning already iterate over the road vector, so no fixed-size arrays needed changing.
- The forest gravel road remains at index 42; its special gravel rendering and grip treatment are preserved.

## Validation
- C++17 standalone road-network check: passed.
- Node count: 36.
- Edge definitions / runtime road curves: 48 / 48.
- New roads checked against the river centreline; the northern bypass includes one river crossing (handled by automatic bridge generation), while the other new routes stay clear of the river.
- Android APK build and on-device visual/gameplay testing were not available in this environment.
