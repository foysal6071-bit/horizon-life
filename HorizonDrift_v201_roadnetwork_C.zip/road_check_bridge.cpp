#include <iostream>
#include "app/src/main/cpp/bridge.h"
int main(){
  Road::init();
  if (Road::NODE_N != 36 || Road::edgeDefs().size() != 48 || Road::gNet.roads.size() != 48) return 2;
  Road::finish();
  Bridge::init();
  std::cout << "nodes=" << Road::NODE_N << " roads=" << Road::gNet.roads.size()
            << " bridges=" << Bridge::gBridges.size()
            << " roadMeshes=" << Road::gNet.roadM.size() << "\n";
  for (int e=43; e<48; ++e) std::cout << "edge "<<e<<" meshVertices="<<Road::gNet.roadM[e].v.size()/Road::VSTRIDE<<"\n";
  return Bridge::gBridges.empty() ? 3 : 0;
}
