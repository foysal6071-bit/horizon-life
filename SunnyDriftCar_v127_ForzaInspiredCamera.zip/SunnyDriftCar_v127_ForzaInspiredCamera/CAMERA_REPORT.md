# SunnyDriftCar_v127_ForzaInspiredCamera - camera upgrade (built on the uploaded v140 source)

## Honest status
| Item | State |
|---|---|
| native-lib.cpp (+ car_render.h, sky.h) | syntax / type checked with g++ against stub GLES / JNI / Android headers. NOT built with the NDK |
| New cockpit + car shaders | compiled and linked-checked on Mesa llvmpipe (GLES 3.0): no shader errors |
| MainActivity.java | javac: no syntax errors (only missing android.jar symbols). NOT compiled against android.jar |
| APK | NOT built (no Android SDK / NDK / network here). Build with `gradle assembleDebug` (CI workflow already in the project) |
| Gameplay tests 1-13 | NOT performed. No on-device or in-game run, no screenshots of the 5 modes. Nothing below is a measured result |
| Cockpit geometry placement | checked only with an offline Python software preview from the driver's eye position (windshield, A-pillar, wheel, mirrors and gauge panel all in view) |

## What changed
* `native-lib.cpp`: new camera system (5 modes), cockpit pass, new JNI `nCamMode / nCamGetMode / nCamSet`.
* `car_render.h`: `drawCabin()` (cockpit / bonnet / dashboard pass), animated steering wheel, procedural instrument cluster + mirror glass, per-item bounding boxes for culling, night multiplier uniform.
* `sky.h`: `draw()` accepts a camera up vector (cockpit camera rolls with the body).
* `MainActivity.java`: camera button (top right, left of the speedometer, clear of pedals / steering / shift buttons), mode label that fades, new **Camera** settings tab, persistence (`cam_*` keys in SharedPreferences).

## Findings about the original code
* Camera = orbit around a point ahead of the car in `nDraw`; world up only; near plane 2.5 m. Car model frame: x forward, y up, z to the RIGHT (R8 steering wheel is at z = +0.375); game heading 0 = +Z; positive steer angle = left.
* The R8 model already has a cabin (dashboard tub, seats, wheel = index range 4959 / 657, mirror, glass). It is reused, not replaced. Added procedurally: gauges, mirror glass, dark trim override for roof / pillars seen from inside.

## Modes
0 Third Person (9.5 m / 1.7 m, speed-dependent distance + height, yaw lag, accel / brake distance, cornering lean, drift shake), 1 Close Chase (6.0 m / 1.05 m), 2 Bonnet (on the bonnet, 1.62 / 0.99), 3 Cockpit (driver's eye 0.13 / 1.03 / 0.375, behind the wheel), 4 Dashboard (0.40 / 1.00, wider FOV). Order of the button: 0 > 1 > 2 > 3 > 4 > 0.
* Cockpit modes: camera rigidly attached to the chassis matrix (so pitch, roll, heave, jumps and landing follow the car); small head movement under acceleration / braking / cornering (switchable). Touch drag = look (yaw +-109 deg, pitch -26..+31 deg), returns to forward after 1.2 s.
* Rendering: world pass with near 1.6 m (no car body), then the cabin pass last with near 3 cm and a squeezed depth range (no depth clear, so god rays / haze keep their depth). Cabin culls everything behind x < -0.7 m, wheels, calipers, lamps.
* Steering wheel: rotates about its real column axis by `steerAngle x 9` (full lock about 283 deg, hard limit 5.2 rad), smoothed at 32 /s.
* Gauges (real data): rpm, km/h (needle + digital), gear (R shown as r), ABS / TCS / ESC / handbrake lights, shift light. No fuel (the game has no fuel simulation).
* Mirrors: cheap sky / road gradient on the three mirror glasses (no render-to-texture, no cost).
* Collision (chase modes): existing tree query + terrain / bridge-deck march along the camera line + chalet footprints; fast pull-in, slow restore. Cockpit modes never collide. Vehicle physics untouched.

## Known limits / to check on a device
* Cluster panel position / size and the 9:1 wheel ratio were chosen from model measurements, not by eye on a phone.
* Glass alpha inside the cabin is 0.12; windshield may need a tweak on device.
* Mirrors do not show a real rear view (by design, for performance).
* Body-roll of the world horizon in the cockpit follows the existing suspension roll; check it feels right.
* Project name requested was v127 although the uploaded source was v140.
