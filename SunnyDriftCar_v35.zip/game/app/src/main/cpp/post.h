// Sunny Drift - post-processing: the whole scene is drawn into an off-screen texture, then one full-screen pass adds
//   * bloom (soft glow round the sun, bright sky and the car's lights; taken from the blurry high mip levels of the scene, so it is cheap)
//   * cinematic colour grading (gentle S-curve contrast, a little more saturation, cool shadows / warm highlights)
//   * a soft vignette
// Off on the Low quality level, and if the off-screen buffer can not be created the game simply draws straight to the screen as before.
#pragma once
#include <GLES3/gl3.h>

namespace Post {

static GLuint gFbo = 0, gTex = 0, gDepth = 0, gProg = 0, gVao = 0; static int gW = 0, gH = 0; static bool gFailed = false;
static GLint uS, uRes;
static float bloom = 1.0f;                    // 0 = off, 1 = default

static const char* VS = R"GLSL(#version 300 es
void main(){ vec2 p = vec2((gl_VertexID == 1) ? 3.0 : -1.0, (gl_VertexID == 2) ? 3.0 : -1.0); gl_Position = vec4(p, 0.0, 1.0); }
)GLSL";
static const char* FS = R"GLSL(#version 300 es
precision highp float;
uniform sampler2D uS; uniform vec2 uRes; uniform float uBloom; out vec4 o;
void main(){
  vec2 uv = gl_FragCoord.xy / uRes;
  vec3 c = texture(uS, uv).rgb;
  // bloom: three blurry mip levels, only what is clearly brighter than the sky / road leaks into a glow
  vec3 b = textureLod(uS, uv, 3.0).rgb*0.30 + textureLod(uS, uv, 4.5).rgb*0.40 + textureLod(uS, uv, 6.0).rgb*0.30;
  float bl = dot(b, vec3(0.299, 0.587, 0.114));
  c += b * (max(bl - 0.80, 0.0) / max(bl, 1e-3)) * 1.7 * uBloom;
  // colour grade
  c = mix(c, c*c*(3.0 - 2.0*c), 0.26);                                         // S-curve: deeper shadows, brighter highlights
  float l = dot(c, vec3(0.299, 0.587, 0.114));
  c = mix(vec3(l), c, 1.10);                                                   // a bit more colour
  c *= mix(vec3(0.96, 1.00, 1.05), vec3(1.04, 1.00, 0.94), smoothstep(0.20, 0.80, l));   // cool shadows, warm highlights
  float r = length((uv - 0.5)*vec2(1.0, 0.9));
  c *= 1.0 - 0.26*smoothstep(0.40, 0.88, r);                                   // vignette
  o = vec4(clamp(c, 0.0, 1.0), 1.0);
}
)GLSL";

static GLuint comp(GLenum t, const char* s){ GLuint sh = glCreateShader(t); glShaderSource(sh, 1, &s, nullptr); glCompileShader(sh); return sh; }
static void freeFbo(){ if (gFbo) glDeleteFramebuffers(1, &gFbo); if (gTex) glDeleteTextures(1, &gTex); if (gDepth) glDeleteRenderbuffers(1, &gDepth); gFbo = gTex = gDepth = 0; }

static bool ensure(int W, int H){
    if (gFailed) return false;
    if (gFbo && gW == W && gH == H) return true;
    if (!gProg){
        gProg = glCreateProgram(); glAttachShader(gProg, comp(GL_VERTEX_SHADER, VS)); glAttachShader(gProg, comp(GL_FRAGMENT_SHADER, FS)); glLinkProgram(gProg);
        GLint ok = 0; glGetProgramiv(gProg, GL_LINK_STATUS, &ok); if (!ok){ gFailed = true; return false; }
        uS = glGetUniformLocation(gProg, "uS"); uRes = glGetUniformLocation(gProg, "uRes"); glGenVertexArrays(1, &gVao);
    }
    freeFbo(); gW = W; gH = H;
    glGenTextures(1, &gTex); glBindTexture(GL_TEXTURE_2D, gTex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, W, H, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glGenRenderbuffers(1, &gDepth); glBindRenderbuffer(GL_RENDERBUFFER, gDepth); glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT24, W, H);
    glGenFramebuffers(1, &gFbo); glBindFramebuffer(GL_FRAMEBUFFER, gFbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, gTex, 0);
    glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, gDepth);
    const bool ok = glCheckFramebufferStatus(GL_FRAMEBUFFER) == GL_FRAMEBUFFER_COMPLETE;
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    if (!ok){ freeFbo(); gFailed = true; return false; }
    return true;
}

// start of the frame: redirect drawing into the off-screen buffer. Returns false when post-processing is off (then draw to the screen as usual).
static bool begin(int W, int H, bool wanted){
    if (!wanted || W < 16 || H < 16 || !ensure(W, H)) return false;
    glBindFramebuffer(GL_FRAMEBUFFER, gFbo); glViewport(0, 0, W, H); return true;
}
// end of the frame: bloom + grade + vignette onto the screen
static void end(int W, int H){
    glBindFramebuffer(GL_FRAMEBUFFER, 0); glViewport(0, 0, W, H);
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, gTex); glGenerateMipmap(GL_TEXTURE_2D);
    glDisable(GL_DEPTH_TEST); glDisable(GL_BLEND); glDisable(GL_CULL_FACE); glDepthMask(GL_FALSE);
    glUseProgram(gProg); glUniform1i(uS, 0); glUniform2f(uRes, (float)W, (float)H); glUniform1f(glGetUniformLocation(gProg, "uBloom"), bloom);
    glBindVertexArray(gVao); glDrawArrays(GL_TRIANGLES, 0, 3); glBindVertexArray(0);
    glDepthMask(GL_TRUE); glEnable(GL_DEPTH_TEST);
}

}   // namespace Post
