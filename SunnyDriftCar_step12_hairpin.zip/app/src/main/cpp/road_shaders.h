// Sunny Drift - GLSL ES 3.00 shaders for the asphalt road (procedural tarmac + lane paint) and its gravel shoulder.
// Port of the HTML roadMat.onBeforeCompile (world-space "no puddle" mask, colour grading, wet roughness, bump map)
// and of the sand-verge material. Lighting uses the same sun / ambient / fog as the rest of this project.
#pragma once
#include "env_glsl.h"

static const char* ROAD_VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in vec2 uv; layout(location=2) in vec3 n;
uniform mat4 uVP;
out vec2 vUv; out vec3 vN; out vec3 wp;
void main(){ vUv = uv; vN = n; wp = p; gl_Position = uVP * vec4(p, 1.0); }
)GLSL";

static const char* ROAD_FS = R"GLSL(#version 300 es
precision highp float;
in vec2 vUv; in vec3 vN; in vec3 wp;       // vUv.x = metres from the centre line, vUv.y = road half width
uniform vec3 uCam;
uniform vec2 uEndA, uEndB; uniform float uEndR;   // connector road: no lane paint inside the junction mouths (uEndR = 0 elsewhere)
out vec4 o;

float aH(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float aN(vec2 p){ vec2 i = floor(p), f = fract(p); f = f*f*(3.0 - 2.0*f);
  return mix(mix(aH(i), aH(i + vec2(1, 0)), f.x), mix(aH(i + vec2(0, 1)), aH(i + vec2(1, 1)), f.x), f.y); }
float aF(vec2 p){ float a = 0.5, s = 0.0; for (int i = 0; i < 4; i++){ s += a * aN(p); p = p * 2.03 + 17.1; a *= 0.5; } return s / 0.9375; }
)GLSL" ENV_GLSL R"GLSL(
// anti-aliased painted stripe: coverage of a line of half width hwl centred on c (metres across the road)
float stripe(float x, float c, float hwl, float aa){ return clamp((hwl - abs(x - c)) / aa + 0.5, 0.0, 1.0); }

void main(){
  vec2 rw = wp.xz;
  float dist = length(uCam - wp);
  float u = vUv.x, hw = vUv.y, edgeD = hw - abs(u);                                   // edgeD = metres to the nearest road edge
  float w3 = 1.0 - smoothstep(8.0, 40.0, dist), w2 = 1.0 - smoothstep(25.0, 90.0, dist);   // fine detail fades out: no shimmer far away

  // ---- asphalt: stone chips (3 scales), large patches, repair tone ----
  float g1 = aN(rw * 9.0), g2 = aN(rw * 37.0), g3 = aN(rw * 140.0);
  float grain = 0.5 + (g1 - 0.5) * 0.5 + (g2 - 0.5) * 0.45 * w2 + (g3 - 0.5) * 0.5 * w3;
  float pat = aF(rw / 7.0), big = aF(rw / 45.0 + 4.3);
  float repair = smoothstep(0.58, 0.64, aF(rw / 19.0 + 9.7));                         // a few darker, fresher patches
  vec3 alb = L2(vec3(0.405, 0.41, 0.415));                                            // ash grey
  alb *= (0.80 + 0.40 * grain) * (0.90 + 0.20 * pat) * (0.94 + 0.12 * big);
  alb *= mix(1.0, 0.78, repair);

  // ---- wear: polished wheel paths, dust on the edges, hairline cracks ----
  float lane = abs(abs(u) - hw * 0.5);                                                // distance from a lane centre
  float wheel = exp(-pow((lane - 0.85) / 0.42, 2.0)) * (0.55 + 0.45 * aN(rw / 2.5));
  float wheel2 = exp(-pow(lane / 0.30, 2.0)) * 0.5 * aN(rw / 1.6 + 7.0);            // oil drip between the wheels
  alb *= 1.0 - 0.14 * wheel - 0.10 * wheel2;
  float dust = (1.0 - smoothstep(0.0, 1.6, edgeD)) * (0.35 + 0.65 * aN(rw * 1.7));
  alb = mix(alb, L2(vec3(0.50, 0.475, 0.425)), 0.42 * dust);                          // sand / earth washed onto the tarmac
  alb = mix(alb, L2(vec3(0.34, 0.31, 0.27)), (1.0 - smoothstep(0.0, 0.35, edgeD)) * 0.55);   // ragged earthy rim
  vec2 wq = rw * 0.8 + 3.0 * vec2(aN(rw * 2.3), aN(rw * 2.3 + 9.0));
  float crack = (1.0 - smoothstep(0.0, 0.030, abs(aN(wq) - 0.5))) * smoothstep(0.52, 0.72, aF(rw / 28.0 + 1.9)) * (1.0 - smoothstep(25.0, 80.0, dist));
  alb *= 1.0 - 0.55 * crack;

  // ---- lane paint: white edge lines + double yellow centre line ----
  float aa = max(fwidth(u) * 0.75, 0.0007);
  float yel = max(stripe(u, 0.17, 0.09, aa), stripe(u, -0.17, 0.09, aa));
  float whi = max(stripe(u, hw - 0.60, 0.11, aa), stripe(u, -(hw - 0.60), 0.11, aa));
  float mask = uEndR > 0.0 ? smoothstep(uEndR, uEndR + 1.5, min(length(rw - uEndA), length(rw - uEndB))) : 1.0;
  float worn = 1.0 - 0.45 * smoothstep(0.50, 0.78, aF(rw / 2.6 + 2.2)) - 0.20 * wheel;     // paint scuffed off, chips showing through
  float chip = 0.80 + 0.20 * smoothstep(0.25, 0.60, mix(0.5, grain, w2));
  float py = yel * mask * worn * chip, pw = whi * mask * worn * chip;
  alb = mix(alb, L2(vec3(0.93, 0.70, 0.08)) * (0.92 + 0.08 * pat), py);             // traffic yellow
  alb = mix(alb, L2(vec3(0.86, 0.87, 0.86)) * (0.92 + 0.08 * pat), pw);             // traffic white
  float paint = max(py, pw);
  float rough = clamp(0.90 - 0.12 * wheel - 0.10 * paint, 0.5, 1.0);

  // ---- micro relief -> bump (three.js perturbNormalArb, surface derivatives of a procedural height in metres) ----
  float H = (g1 - 0.5) * 0.010 + (g2 - 0.5) * 0.006 * w2 + (g3 - 0.5) * 0.004 * w3 - crack * 0.012 + paint * 0.0015;
  H *= 1.0 - smoothstep(60.0, 200.0, dist);
  vec3 N0 = normalize(vN);
  vec3 sX = dFdx(wp), sY = dFdy(wp), R1 = cross(sY, N0), R2 = cross(N0, sX);
  float fDet = dot(sX, R1);
  vec3 N = normalize(abs(fDet) * N0 - sign(fDet) * (dFdx(H) * R1 + dFdy(H) * R2) * 9.0);

  vec3 L = normalize(vec3(0.4, 0.8, 0.3)), V = normalize(uCam - wp), Hh = normalize(L + V);
  float d = max(dot(N, L), 0.0), smo = 1.0 - rough;
  float spec = pow(max(dot(N, Hh), 0.0), mix(6.0, 120.0, smo * smo * 4.0)) * (0.02 + 0.5 * smo * smo * smo);   // dry tarmac: faint sheen
  vec3 Rf = reflect(-V, N); vec2 ab = envBRDF(rough, max(dot(N, V), 1e-3));
  vec3 lin = alb * (0.35 + 0.75 * d) + vec3(spec) + envC(Rf, rough) * 0.32 * (0.04 * ab.x + ab.y);
  vec3 c = pow(lin, vec3(1.0 / 2.2));
  c = mix(c, vec3(0.62, 0.80, 0.95), clamp(dist / 2500.0, 0.0, 1.0));
  o = vec4(c, 1.0);
}
)GLSL";

static const char* VERGE_FS = R"GLSL(#version 300 es
precision highp float;
in vec2 vUv; in vec3 vN; in vec3 wp;
uniform sampler2D uTex; uniform vec3 uCam;
out vec4 o;
float vH(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float vNz(vec2 p){ vec2 i = floor(p), f = fract(p); f = f*f*(3.0 - 2.0*f);
  return mix(mix(vH(i), vH(i + vec2(1, 0)), f.x), mix(vH(i + vec2(0, 1)), vH(i + vec2(1, 1)), f.x), f.y); }
void main(){
  vec4 tx = texture(uTex, vUv);
  float dist = length(uCam - wp);
  vec3 soil = pow(tx.rgb, vec3(2.2));
  // asphalt shoulder: grey-tan gravel and dust instead of wet mud (the old mud texture only shapes the alpha / soil under it)
  float gr = 0.75 + 0.5 * vNz(wp.xz * 5.0) * 0.6 + 0.5 * vNz(wp.xz * 31.0) * 0.4 * (1.0 - smoothstep(10.0, 50.0, dist));
  vec3 gravel = pow(vec3(0.47, 0.45, 0.41), vec3(2.2)) * gr * (0.85 + 0.3 * vNz(wp.xz / 6.0));
  vec3 alb = mix(soil, gravel, 0.6);
  vec3 N = normalize(vN);
  float d = max(dot(N, normalize(vec3(0.4, 0.8, 0.3))), 0.0);
  vec3 c = pow(alb * (0.35 + 0.75 * d), vec3(1.0 / 2.2));
  c = mix(c, vec3(0.62, 0.80, 0.95), clamp(dist / 2500.0, 0.0, 1.0));
  o = vec4(c, tx.a);
}
)GLSL";
