#include <jni.h>
#include <GLES3/gl3.h>
#include <android/asset_manager.h>
#include <android/asset_manager_jni.h>
#include <chrono>
#include <atomic>
#include <sstream>
#include "car_core.h"
#include "night.h"           // night mode + headlight light pool (ported from the HTML game)
#include "car_render.h"      // Audi R8 look (materials, glass, lights), rolling / steering wheels, body roll + pitch (ported from the HTML game)
#include "road.h"             // winding mud roads: geometry (ported from the HTML game)
#include "sky.h"              // HTML sky: gradient, sun glow, drifting clouds, dramatic cube-map, photo mountains, night stars + moon
#include "control.h"          // car controls: keys / pedals / steering wheel / sensitivity / reset (ported from the HTML game)
#include "road_render.h"      // winding mud roads: textures + shaders
#include "bridge_render.h"    // river bed + water + wooden bridges (ported from the HTML game)
#include "terrain.h"          // rolling hills, distant mountains, dirt track (ported from the HTML game)
#include "terrain_render.h"
#include "tree_render.h"      // green trees (ported from the HTML game)
#include "village_render.h"   // Swiss village: wooden chalets + church (instanced)
#include "nature_fx.h"        // light extras: mountain waterfall + low valley cloud
#include "tyre_fx.h"          // skid marks, tyre smoke, dust behind the wheels
#include "tunnel.h"           // tunnel portals at the dead ends of the dirt track + invisible wall
#include "fence_render.h"     // roadside post-and-rope fence (breakable) + wooden lamp poles (ported from the HTML game)

// ---------- model ----------
struct Group { int start, count; float r, g, b; };
static vector<Group> gGroups;
static GLuint gVBO = 0, gIBO = 0, gProg = 0; static BridgeGL::Gpu gGroundG;
static GLint uMVP, uModel, uColor, uCam;
static int gW = 1, gH = 1, gInputMask = 0, gN = 0;
static CarState gCar; static Surface gSurf; static Input gIn;
static chrono::steady_clock::time_point gLast;
static bool gReady = false, gResetReq = false;
// free camera: finger drag orbits the camera around the car; after a short idle it eases back behind the car
static std::atomic<int> gDragDX{0}, gDragDY{0}; static std::atomic<bool> gDragging{false};
static float gCamYaw = 0, gCamPitch = 0, gCamIdle = 0;
// settings (Java side: Settings > Graphics / Control)
static float gFov = 1.0f, gCamSens = 1.f; static bool gTyreFxOn = true, gNatureFxOn = true, gCamAuto = true, gCamInv = false; static std::atomic<bool> gPaused{false};

static vector<char> readAsset(AAssetManager* am, const char* name){
    AAsset* a = AAssetManager_open(am, name, AASSET_MODE_BUFFER);
    vector<char> d; if (!a) return d;
    d.resize(AAsset_getLength(a)); AAsset_read(a, d.data(), d.size()); AAsset_close(a); return d;
}

static GLuint compile(GLenum t, const char* s){
    GLuint sh = glCreateShader(t); glShaderSource(sh, 1, &s, nullptr); glCompileShader(sh); return sh;
}

static void loadModel(AAssetManager* am){
    vector<char> meta = readAsset(am, "r8_meta.txt"), raw = readAsset(am, "r8.bin");
    istringstream mf(string(meta.begin(), meta.end()));
    int n, ni, ng; double mn[3], sz[3];
    mf >> n >> ni >> mn[0] >> mn[1] >> mn[2] >> sz[0] >> sz[1] >> sz[2] >> ng;
    gGroups.clear();
    for (int i = 0; i < ng; i++){
        string name, col; int s, c, em; mf >> name >> s >> c >> col >> em;
        unsigned r = 128, g = 128, b = 128; sscanf(col.c_str(), "#%02x%02x%02x", &r, &g, &b);
        if (c == 0 || s >= 152712) continue;                // skip empty + under-car neon
        gGroups.push_back({s, c, r / 255.f, g / 255.f, b / 255.f});
    }
    const uint16_t* pos = (const uint16_t*)raw.data();
    const int8_t* nor = (const int8_t*)(raw.data() + n * 6);
    const double S = 2.8 / 2643.1, ZC = -104.45;
    vector<float> vb(n * 6);
    for (int i = 0; i < n; i++){
        double rx = mn[0] + pos[i*3]   / 65535.0 * sz[0];
        double ry = mn[1] + pos[i*3+1] / 65535.0 * sz[1];
        double rz = mn[2] + pos[i*3+2] / 65535.0 * sz[2];
        vb[i*6] = (float)((rz - ZC) * S); vb[i*6+1] = (float)(ry * S); vb[i*6+2] = (float)(-rx * S);
        double nx = nor[i*4] / 127.0, ny = nor[i*4+1] / 127.0, nz = nor[i*4+2] / 127.0;
        double l = sqrt(nx*nx + ny*ny + nz*nz); if (l == 0) l = 1;
        vb[i*6+3] = (float)(nz / l); vb[i*6+4] = (float)(ny / l); vb[i*6+5] = (float)(-nx / l);
    }
    glGenBuffers(1, &gVBO); glBindBuffer(GL_ARRAY_BUFFER, gVBO);
    glBufferData(GL_ARRAY_BUFFER, vb.size() * 4, vb.data(), GL_STATIC_DRAW);
    glGenBuffers(1, &gIBO); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gIBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, ni * 2, raw.data() + n * 10, GL_STATIC_DRAW);
    gN = n;
    // ground: flat quads around the hilly area (normal up). Inside it the ground is the river patch (BridgeGL) + two hill strips (TerrainGL).
    {
        const float G = 4500, X0 = (float)River::GX0, X1 = (float)River::GX1, Z0 = (float)River::GZ0, Z1 = (float)River::PZ1;
        const float HX0 = (float)Terrain::LX0, HX1 = (float)(Terrain::LX0 + Terrain::LNX * Terrain::LC), HZ0 = (float)Terrain::LZ0, HZ1 = (float)(Terrain::LZ0 + Terrain::LNZ * Terrain::LC);
        const float R[8][4] = {{-G, -G, X0, G}, {X1, -G, G, G}, {X0, -G, X1, HZ0}, {X0, HZ1, X1, G},                 // x0 z0 x1 z1
                               {X0, HZ0, HX0, Z0}, {HX1, HZ0, X1, Z0}, {X0, Z1, HX0, HZ1}, {HX1, Z1, X1, HZ1}};
        vector<float> gv; vector<uint32_t> gi;                       // vertex = pos(3) colour(3) normal(3): the same layout / grass shader as the hills
        for (auto& r : R){
            const float q[6][2] = {{r[0], r[1]}, {r[2], r[1]}, {r[0], r[3]}, {r[2], r[1]}, {r[2], r[3]}, {r[0], r[3]}};
            for (auto& p : q){ const float v[9] = {p[0], -0.06f, p[1], 0.57f, 0.67f, 0.13f, 0, 1, 0}; gv.insert(gv.end(), v, v + 9); gi.push_back((uint32_t)gi.size()); }
        }
        { const int an[3] = {3, 3, 3}, ao[3] = {0, 12, 24}; gGroundG = BridgeGL::upload(gv.data(), gv.size() * 4, gi, 36, an, ao, 3); }
    }
}

// ---------- tiny matrix helpers (column-major) ----------
typedef float M4[16];
static void ident(M4 m){ memset(m, 0, 64); m[0] = m[5] = m[10] = m[15] = 1; }
static void mul(M4 o, const M4 a, const M4 b){
    M4 t; for (int c = 0; c < 4; c++) for (int r = 0; r < 4; r++){
        float s = 0; for (int k = 0; k < 4; k++) s += a[k*4+r] * b[c*4+k]; t[c*4+r] = s; }
    memcpy(o, t, 64);
}
static void persp(M4 m, float fov, float asp, float n, float f){
    float t = 1.f / tanf(fov / 2); memset(m, 0, 64);
    m[0] = t / asp; m[5] = t; m[10] = (f + n) / (n - f); m[11] = -1; m[14] = 2 * f * n / (n - f);
}
static void lookAt(M4 m, const float* e, const float* c){
    float f[3] = {c[0]-e[0], c[1]-e[1], c[2]-e[2]}; float l = sqrtf(f[0]*f[0]+f[1]*f[1]+f[2]*f[2]);
    for (float& v : f) v /= l;
    float s[3] = {f[1]*0 - f[2]*1, f[2]*0 - f[0]*0, f[0]*1 - f[1]*0};           // f x up(0,1,0)
    l = sqrtf(s[0]*s[0]+s[1]*s[1]+s[2]*s[2]); for (float& v : s) v /= l;
    float u[3] = {s[1]*f[2]-s[2]*f[1], s[2]*f[0]-s[0]*f[2], s[0]*f[1]-s[1]*f[0]};
    ident(m);
    m[0]=s[0]; m[4]=s[1]; m[8]=s[2];  m[1]=u[0]; m[5]=u[1]; m[9]=u[2];  m[2]=-f[0]; m[6]=-f[1]; m[10]=-f[2];
    m[12] = -(s[0]*e[0]+s[1]*e[1]+s[2]*e[2]); m[13] = -(u[0]*e[0]+u[1]*e[1]+u[2]*e[2]); m[14] = f[0]*e[0]+f[1]*e[1]+f[2]*e[2];
}
static void rotY(M4 m, float a, float tx, float tz){
    ident(m); float c = cosf(a), s = sinf(a); m[0] = c; m[2] = -s; m[8] = s; m[10] = c; m[12] = tx; m[14] = tz;
}

static void drawMesh(GLuint vbo){
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 24, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 24, (void*)12);
}

// ---------- tunnel portals (geometry from tunnel.h): one VBO per material, drawn with the plain lit program ----------
static GLuint gTunVBO[Tunnel::PARTS] = {0}; static int gTunN[Tunnel::PARTS] = {0};
static void tunnelInit(){
    std::vector<float> parts[Tunnel::PARTS]; Tunnel::build(parts);
    for (int i = 0; i < Tunnel::PARTS; i++){
        gTunN[i] = (int)(parts[i].size() / 6); if (!gTunN[i]) continue;
        glGenBuffers(1, &gTunVBO[i]); glBindBuffer(GL_ARRAY_BUFFER, gTunVBO[i]); glBufferData(GL_ARRAY_BUFFER, parts[i].size() * 4, parts[i].data(), GL_STATIC_DRAW);
    }
}
static void tunnelDraw(const float* VP, const float* eye){
    if (Tunnel::gP.empty()) return;
    bool near = false; for (const Tunnel::Portal& P : Tunnel::gP){ const float dx = (float)P.x - eye[0], dz = (float)P.z - eye[2]; if (dx*dx + dz*dz < 1500.f * 1500.f) near = true; }
    if (!near) return;
    float I[16] = {1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1};
    glUseProgram(gProg); glBindVertexArray(0);
    glUniformMatrix4fv(uMVP, 1, GL_FALSE, VP); glUniformMatrix4fv(uModel, 1, GL_FALSE, I); glUniform3fv(uCam, 1, eye);
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glDisable(GL_BLEND); glDepthMask(GL_TRUE);
    for (int i = 0; i < Tunnel::PARTS; i++){
        if (!gTunN[i]) continue;
        glUniform3f(uColor, Tunnel::PART_COL[i][0], Tunnel::PART_COL[i][1], Tunnel::PART_COL[i][2]);
        drawMesh(gTunVBO[i]); glDrawArrays(GL_TRIANGLES, 0, gTunN[i]);
    }
}

extern "C" {
JNIEXPORT void JNICALL Java_com_sunny_car_MainActivity_nInit(JNIEnv* env, jclass, jobject amgr){
    AAssetManager* am = AAssetManager_fromJava(env, amgr);
    const char* vs = "#version 300 es\nlayout(location=0) in vec3 p; layout(location=1) in vec3 n;\n"
        "uniform mat4 uMVP, uModel; out vec3 vn; out vec3 wp;\n"
        "void main(){ vn = mat3(uModel)*n; wp = (uModel*vec4(p,1)).xyz; gl_Position = uMVP*vec4(p,1); }";
    const char* fs = "#version 300 es\nprecision mediump float; in vec3 vn; in vec3 wp;\n"
        "uniform vec3 uColor, uCam; out vec4 o;\n"
        "void main(){ vec3 N = normalize(vn), L = normalize(vec3(0.4,0.8,0.3)), V = normalize(uCam-wp);\n"
        " float d = max(dot(N,L),0.0); float s = pow(max(dot(N,normalize(L+V)),0.0), 48.0);\n"
        " vec3 c = uColor*(0.35 + 0.75*d) + vec3(0.35)*s;\n"
        " c = mix(c, vec3(0.70,0.88,0.97), clamp(length(uCam-wp)/3750.0, 0.0, 1.0));\n"
        " o = vec4(c,1); }";
    gProg = glCreateProgram();
    glAttachShader(gProg, compile(GL_VERTEX_SHADER, vs)); glAttachShader(gProg, compile(GL_FRAGMENT_SHADER, fs));
    glLinkProgram(gProg);
    uMVP = glGetUniformLocation(gProg, "uMVP"); uModel = glGetUniformLocation(gProg, "uModel");
    uColor = glGetUniformLocation(gProg, "uColor"); uCam = glGetUniformLocation(gProg, "uCam");
    loadModel(am);
    SkyGL::init();                                           // sky pictures were handed over by Java (nSkyImg) before this call
    NightGL::init();
    CarGL::init(readAsset(am, "r8.bin"), readAsset(am, "r8_meta.txt"), readAsset(am, "r8_groups.txt"));   // HTML car materials + separate wheels
    Road::init();                                            // ring roads + connector (centre lines, meshes, clearance grid)
    Terrain::init(2026u); Tunnel::plan();   // hills + dirt track + mountains: FIXED seed = the same Swiss valley on every launch
    NatureFx::plan();                                        // waterfall site on a mountain flank (before the trees, so none stands in the stream)
    Village::plan();                                         // where the chalets + church stand (before the trees, so they keep clear of the houses)
    RoadGL::init(readAsset(am, "road_a.rgba"), readAsset(am, "road_a_h.bin"), readAsset(am, "road_b.rgba"),
                 readAsset(am, "road_b_h.bin"), readAsset(am, "road_verge.rgba"));
    // (broadleaf trees removed - only the pine / spruce forest remains)
    /* TreeGL::init(readAsset(am, "tree_raw.bin"), readAsset(am, "tree_meta.txt"),
                 readAsset(am, "tree_leaf.rgba"), readAsset(am, "tree_bark.rgba"), 6.0f); */   // trees keep clear of every road (Road::clearance)
    TreeGL::initConifers();                                  // pine + spruce forest: mountain slopes, roadsides, foothills (needs Terrain::init)
    BridgeGL::init();                                        // river bed (with the hills) + water + bridges (needs the road textures)
    TerrainGL::init();                                       // hill strips + distant mountains
    VillageGL::init();                                       // chalet + church models (2 instanced draw calls)
    NatureFxGL::init();                                      // waterfall ribbon + spray + low cloud disc
    TyreFx::init();                                          // skid-mark ring buffer + smoke / dust sprites
    tunnelInit();                                            // tunnel portal meshes
    FenceGL::init();                                         // fence posts + ropes + lamp poles (needs the hills, river and bridges)
    gCar = CarState(); Road::startPose(gCar.x, gCar.z, gCar.heading);   // start line on the inner road, facing along it
    gLast = chrono::steady_clock::now(); gReady = true;
}
JNIEXPORT void JNICALL Java_com_sunny_car_MainActivity_nResize(JNIEnv*, jclass, jint w, jint h){ gW = w; gH = h; glViewport(0, 0, w, h); }
JNIEXPORT void JNICALL Java_com_sunny_car_MainActivity_nInput(JNIEnv*, jclass, jint m){ gInputMask = m; }
JNIEXPORT void JNICALL Java_com_sunny_car_MainActivity_nNight(JNIEnv*, jclass, jint on){ NightGL::target = on ? 1.f : 0.f; }
JNIEXPORT void JNICALL Java_com_sunny_car_MainActivity_nSkyImg(JNIEnv* env, jclass, jint id, jint w, jint h, jobject buf){
    const uint8_t* p = (const uint8_t*)env->GetDirectBufferAddress(buf); if (p) SkyGL::setImage(id, w, h, p);
}
JNIEXPORT void JNICALL Java_com_sunny_car_MainActivity_nSens(JNIEnv*, jclass, jfloat v){ Ctrl::setSens(v); }
JNIEXPORT void JNICALL Java_com_sunny_car_MainActivity_nReset(JNIEnv*, jclass){ gResetReq = true; }
JNIEXPORT void JNICALL Java_com_sunny_car_MainActivity_nWheelMode(JNIEnv*, jclass, jint on){ Ctrl::wheel.setMode(on != 0); }
JNIEXPORT void JNICALL Java_com_sunny_car_MainActivity_nWheelDown(JNIEnv*, jclass, jfloat a){ Ctrl::wheel.down(a); }
JNIEXPORT void JNICALL Java_com_sunny_car_MainActivity_nWheelMove(JNIEnv*, jclass, jfloat a){ Ctrl::wheel.move(a); }
JNIEXPORT void JNICALL Java_com_sunny_car_MainActivity_nWheelUp(JNIEnv*, jclass){ Ctrl::wheel.release(); }
JNIEXPORT jfloat JNICALL Java_com_sunny_car_MainActivity_nWheelRot(JNIEnv*, jclass){ return (jfloat)Ctrl::wheel.rot; }
JNIEXPORT void JNICALL Java_com_sunny_car_MainActivity_nCamDrag(JNIEnv*, jclass, jfloat dx, jfloat dy){ gDragging = true; gDragDX += (int)(dx * 16.f); gDragDY += (int)(dy * 16.f); }
JNIEXPORT void JNICALL Java_com_sunny_car_MainActivity_nCamRelease(JNIEnv*, jclass){ gDragging = false; }
JNIEXPORT void JNICALL Java_com_sunny_car_MainActivity_nGfx(JNIEnv*, jclass, jfloat fov, jint tyre, jint nature){ gFov = fov < 0.6f ? 0.6f : (fov > 1.6f ? 1.6f : fov); gTyreFxOn = tyre != 0; gNatureFxOn = nature != 0; }
JNIEXPORT void JNICALL Java_com_sunny_car_MainActivity_nQuality(JNIEnv*, jclass, jint q){ Quality::level = q < 0 ? 0 : (q > 2 ? 2 : q); }
JNIEXPORT void JNICALL Java_com_sunny_car_MainActivity_nTreeDist(JNIEnv*, jclass, jfloat d){ Quality::treeDist = d < 200.f ? 200.f : (d > 4000.f ? 4000.f : d); }   // settings: how far trees are drawn (m)
JNIEXPORT void JNICALL Java_com_sunny_car_MainActivity_nPause(JNIEnv*, jclass, jint on){ gPaused = on != 0; }
JNIEXPORT void JNICALL Java_com_sunny_car_MainActivity_nCamCfg(JNIEnv*, jclass, jfloat sens, jint autoReturn, jint invertY){ gCamSens = sens; gCamAuto = autoReturn != 0; gCamInv = invertY != 0; }
// engine sound inputs: out[0] = rpm, out[1] = throttle 0..1, out[2] = tyre skid 0..1, out[3] = speed km/h
JNIEXPORT void JNICALL Java_com_sunny_car_MainActivity_nSound(JNIEnv* env, jclass, jfloatArray out){
    jfloat v[4] = {900.f, 0.f, 0.f, 0.f};
    if (gReady){ v[0] = (jfloat)gCar.rpm; v[1] = (jfloat)gCar.throttle; v[3] = (jfloat)fabs(gCar.speed * 3.6);
        v[2] = (jfloat)(clampd((max(gCar.drift, gCar.hb) - 0.2) * 1.5, 0.0, 1.0) * clampd(fabs(gCar.speed) / 8.0, 0.0, 1.0)); }
    env->SetFloatArrayRegion(out, 0, 4, v);
}
JNIEXPORT jfloat JNICALL Java_com_sunny_car_MainActivity_nSpeed(JNIEnv*, jclass){ return (jfloat)fabs(gCar.speed * 3.6); }

// ---------- minimap data (read by the Java MiniMapView) ----------
// layout: repeated [kind, n, payload...]  kind 0 = ring road (closed), 1 = connector road, 2 = river, 3 = dirt track, 4 = lake (x, z, r),
//         5 = chalets (n x,z pairs), 6 = church (n x,z pairs).  Rings: A, B, D; connectors: C, E; rivers: main + 2 tributaries (one block each)
JNIEXPORT jfloatArray JNICALL Java_com_sunny_car_MainActivity_nMapData(JNIEnv* env, jclass){
    if (!gReady) return nullptr;                             // world not built yet (the GL thread is still in nInit)
    vector<float> o;
    auto curve = [&](const Road::Curve& c, int kind){
        const int cnt = max(8, (int)ceil(c.length() / 8.0)); o.push_back((float)kind); o.push_back((float)(cnt + 1));
        for (int i = 0; i <= cnt; i++){
            const double u = c.open ? min((double)i / cnt, 0.99999) : (double)(i % cnt) / cnt;
            const Road::V3 p = c.getPointAt(u); o.push_back((float)p.x); o.push_back((float)p.z);
        }
    };
    curve(Road::gNet.A, 0); curve(Road::gNet.B, 0); curve(Road::gNet.D, 0); curve(Road::gNet.C, 1); curve(Road::gNet.E, 1);
    for (const std::vector<float>& L : River::RV_LINES){ const int n = (int)(L.size() / 2); if (n > 1){ o.push_back(2.f); o.push_back((float)n); o.insert(o.end(), L.begin(), L.end()); } }      // main river + the two tributaries
    if (Terrain::TRK.n > 1){ o.push_back(3.f); o.push_back((float)Terrain::TRK.n); for (int i = 0; i < Terrain::TRK.n * 2; i++) o.push_back(Terrain::TRK.pts[i]); }
    if (Terrain::gLake.on){ o.push_back(4.f); o.push_back(1.f); o.push_back((float)Terrain::gLake.x); o.push_back((float)Terrain::gLake.z); o.push_back((float)Terrain::gLake.r); }
    for (int kind = 0; kind < 2; kind++){
        vector<float> q; for (const Village::Building& b : Village::gB) if (b.type == kind){ q.push_back(b.x); q.push_back(b.z); }
        if (!q.empty()){ o.push_back(kind == 0 ? 5.f : 6.f); o.push_back((float)(q.size() / 2)); o.insert(o.end(), q.begin(), q.end()); }
    }
    jfloatArray a = env->NewFloatArray((jsize)o.size()); env->SetFloatArrayRegion(a, 0, (jsize)o.size(), o.data()); return a;
}
// car pose for the minimap: out[0] = x, out[1] = z, out[2] = heading (rad, 0 = +Z)
JNIEXPORT void JNICALL Java_com_sunny_car_MainActivity_nCarPose(JNIEnv* env, jclass, jfloatArray out){
    if (!gReady) return;
    const jfloat v[3] = {(jfloat)gCar.x, (jfloat)gCar.z, (jfloat)gCar.heading}; env->SetFloatArrayRegion(out, 0, 3, v);
}

JNIEXPORT void JNICALL Java_com_sunny_car_MainActivity_nDraw(JNIEnv*, jclass){
    if (!gReady) return;
    auto now = chrono::steady_clock::now();
    // The game runs on REAL time: however slow the phone draws (even 5 fps) the car moves exactly as far as it would at 60 fps. A long frame is simulated
    // as several equal steps of at most 1/60 s (physics stays stable and accurate); only a stall longer than 0.5 s (app in the background...) is not caught up.
    const double dtReal = min(max(chrono::duration<double>(now - gLast).count(), 0.0), 0.5); gLast = now;
    Ctrl::wheel.frame(dtReal);                                             // HTML spring(): the steering wheel self-centres
    Ctrl::build(gIn, gInputMask);                                          // HTML input: pedals, keys, wheel (analog), steerSens 1.8
    static double carGy = 0, gyV = 0, tRoll = 0, ptT = 0, bridgeY = 0, pitchS = 0; static bool gyAir = false;   // follow-the-hills state (kept between steps and frames)
    Road::SurfaceInfo si = {1.15, 0.028, Road::ROAD_SURF};                  // surface under the car (average of the four tyres), used by the renderer below
    const int nSub = gPaused ? 0 : max(1, (int)ceil(dtReal / (1.0 / 60.0) - 1e-9)); const double dt = nSub > 0 ? dtReal / nSub : 0.0;   // settings open = game paused
    for (int sub = 0; sub < nSub; sub++){
    // every tyre reads the surface under ITS OWN contact patch (the model's real wheel positions): tarmac / verge / grass / dirt track.
    // Grip, rolling resistance and ride height are the average of the four; each axle and each side keeps its own grip (partly on the grass = partly less grip, the car is pulled).
    static TyreFx::Contact wc[4]; static double wf[4], wl[4]; si = {1.15, 0.028, Road::ROAD_SURF};
    {
        const double sHw = sin(gCar.heading), cHw = cos(gCar.heading);
        double mu = 0, rr = 0, ry = 0, muFa = 0, muRa = 0, muL = 0, muRt = 0, rrL = 0, rrRt = 0; int nF = 0, nR = 0, nL = 0, nRt = 0;
        for (int i = 0; i < 4; i++){
            const double f = CarGL::wC[i][0], l = -CarGL::wC[i][2]; wf[i] = f; wl[i] = l;
            const float wx = (float)(gCar.x + sHw * f + cHw * l), wz = (float)(gCar.z + cHw * f - sHw * l);
            const Road::SurfaceInfo q = Road::surfaceAt(wx, wz); double m = q.mu, r = q.rr; const float cl = Road::clearance(wx, wz); bool trk = false;
            if (cl > 1.5f){                                             // packed dirt track: more grip than grass, less than tarmac
                Terrain::trackQ(wx, wz);
                if (Terrain::tkD < 3.4){ const double k = 1 - River::sstep(2.1, 3.4, Terrain::tkD); m = m * (1 - k) + 1.05 * k; r = r * (1 - k) + 0.032 * k; trk = k > 0.5; }
            }
            mu += m; rr += r; ry += q.rideY;
            if (f > 0){ muFa += m; nF++; } else { muRa += m; nR++; }
            if (l > 0){ muL += m; rrL += r; nL++; } else { muRt += m; rrRt += r; nRt++; }
            wc[i] = {(double)wx, (double)wz, Terrain::carGroundH(wx, wz) + Road::ROAD_SURF, (double)cl, m, r, cl < -0.15f, trk, false};
        }
        si.mu = mu / 4; si.rr = rr / 4; si.rideY = ry / 4;
        gSurf.mu = si.mu; gSurf.rr = si.rr; gSurf.muF = nF ? muFa / nF : -1; gSurf.muR = nR ? muRa / nR : -1;
        if (nL && nRt){ const double a = muL / nL, b = muRt / nRt; gSurf.muSide = (a - b) / (a + b); gSurf.pull = rrL / nL - rrRt / nRt; } else { gSurf.muSide = 0; gSurf.pull = 0; }
    }
    // 4 wheels sample the hills: ride height, pitch, roll and the pull of gravity come from where the tyres really are (HTML "vehicle dynamics")
    double terrG = 0, tRollT = 0, gRide = 0;
    {
        const double sH = sin(gCar.heading), cH = cos(gCar.heading), A = 1.4, B = 0.85;
        auto hw = [&](double f, double l){ return Terrain::carGroundH(gCar.x + sH * f + cH * l, gCar.z + cH * f - sH * l); };      // f = metres forward, l = metres to the LEFT
        const double hFL = hw(A, B), hFR = hw(A, -B), hRL = hw(-A, B), hRR = hw(-A, -B);
        const double hF = (hFL + hFR) / 2, hR = (hRL + hRR) / 2, hLf = (hFL + hRL) / 2, hRt = (hFR + hRR) / 2, avg = (hF + hR) / 2;
        const double g = (hF - hR) / (2 * A), sl = (hLf - hRt) / (2 * B);                  // slope along the car (+ = uphill) and across it (+ = left side higher)
        const double lift = max(0.0, max(max(hFL - (avg + A*g + B*sl), hFR - (avg + A*g - B*sl)), max(hRL - (avg - A*g + B*sl), hRR - (avg - A*g - B*sl))));   // no tyre may sink into the ground
        gRide = avg + lift; terrG = g; tRollT = atan(sl);
    }
    // bridge deck under the tyres: height + slope along the car (HTML carGroundH / bridgeLift); gravity pulls on the slope
    double bhAvg = 0, bridgeG = 0;
    {
        const double sH0 = sin(gCar.heading), cH0 = cos(gCar.heading), A = 1.4;
        const double hF = Bridge::lift(gCar.x + sH0 * A, gCar.z + cH0 * A), hR = Bridge::lift(gCar.x - sH0 * A, gCar.z - cH0 * A);
        bridgeG = (hF - hR) / (2 * A); bhAvg = (hF + hR) / 2;
        const double gT = (gyAir ? 0 : terrG) + bridgeG, sn = gT / sqrt(1 + gT * gT); gCar.slope += (sn - gCar.slope) * (1 - exp(-10 * dt));
        bridgeY += (bhAvg - bridgeY) * (1 - exp(-(bhAvg > 0.002 || bridgeY > 0.002 ? 45 : 10) * dt));
        const double pt = gyAir ? clampd(atan2(gyV, max(fabs(gCar.speed), 4.0)), -0.55, 0.55) : atan(bridgeG + terrG);
        ptT = pt; pitchS += (pt - pitchS) * (1 - exp(-12 * dt));
    }
    {   // follow the hills: stuck to the ground on slopes, but flies off steep drops and crests and lands again
        const double idt = max(dt, 0.001);
        if (!gyAir){
            const double vg = (gRide - carGy) / idt;
            if (gCar.speed > 4 && vg < gyV - 18 * dt - 1.5) gyAir = true;
            else { gyV += (vg - gyV) * (1 - exp(-25 * dt)); carGy = gRide; }
        }
        if (gyAir){
            gyV -= 18 * dt; carGy += gyV * dt;
            if (carGy <= gRide){ carGy = gRide; gyAir = false; if (gyV < -9) gCar.speed *= 0.96; gyV = 0; }
        }
        tRoll += ((gyAir ? 0 : tRollT) - tRoll) * (1 - exp(-16 * dt));
    }
    if (gResetReq){   // HTML resetCar(): nearest road point, everything at rest
        gResetReq = false; Ctrl::reset(gCar);
        carGy = 0; gyV = 0; gyAir = false; bridgeY = 0; pitchS = 0; ptT = 0; tRoll = 0;
        CarGL::suspRoll = CarGL::suspRollV = CarGL::suspPitch = CarGL::suspPitchV = 0; TyreFx::reset();
    }
    if (dt > 0) TreeGL::updateFx(dt);                            // swinging trees + falling needles
    if (dt > 0){ Veh::step(gCar, gIn, gSurf, dt); CarGL::update(gCar, dt, gyAir, pitchS, ptT, tRoll, tRollT); }
    { for (int i = 0; i < 4; i++) wc[i].onDeck = bridgeY > 0.002; TyreFx::update(gCar, dt, wc, wf, wl, gyAir); }   // skid marks / smoke / dust from the real slip + surface of every tyre
    NightGL::update(dt);   // + suspension springs, wheel roll / steer, brake light
    Fence::update(gCar, dt);                                     // posts / ropes are knocked over, lamp poles are solid (HTML fencePosts + lampCollide)
    Village::collide(gCar);                                      // the houses are solid
    TreeGL::collide(gCar);                                       // pine / spruce trunks are solid; a hit makes the tree swing and shakes needles loose
    Tunnel::collide(gCar);                                       // invisible wall in front of the tunnel mouths at the ends of the dirt track
    Bridge::collide(gCar);                                       // rails, bridge mouth, river walls
    {   // HTML checkCollisions: invisible wall at the edge of the world (radius 1440 m), the car loses half its speed against it
        const double r = hypot(gCar.x, gCar.z), LIM = 1440;
        if (r > LIM){ gCar.x *= LIM / r; gCar.z *= LIM / r; gCar.speed *= 0.5; gCar.vy *= 0.5; gCar.yaw *= sqrt(0.5); }
    }

    }   // end of the simulation steps

    glClearColor(0.70f, 0.88f, 0.97f, 1); glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE);
    glUseProgram(gProg);

    {   // free camera: drag = orbit (yaw / pitch offset); when the finger is up for 2 s it glides back behind the car
        const int ddx = gDragDX.exchange(0), ddy = gDragDY.exchange(0);
        if (ddx || ddy){ gCamYaw -= ddx / 16.f * 0.0065f * gCamSens; gCamPitch += ddy / 16.f * 0.0045f * gCamSens * (gCamInv ? -1.f : 1.f); gCamIdle = 0; }
        gCamPitch = min(max(gCamPitch, -0.20f), 1.20f);
        if (gDragging) gCamIdle = 0; else gCamIdle += (float)dtReal;
        while (gCamYaw >  3.14159265f) gCamYaw -= 6.2831853f;
        while (gCamYaw < -3.14159265f) gCamYaw += 6.2831853f;
        if (gCamAuto && gCamIdle > 2.0f){ const float k = 1.f - expf(-3.0f * (float)dtReal); gCamYaw -= gCamYaw * k; gCamPitch -= gCamPitch * k; }
    }
    float h = (float)gCar.heading, fx = sinf(h), fz = cosf(h);
    const float baseY = (float)(carGy + bridgeY);                // the camera rides on the hills with the car
    // orbit round a point just ahead of the car (default offsets = the old fixed chase camera: 9.5 m back, 1.7 m up from that point)
    const float kAhead = 0.5f * (1.f + cosf(gCamYaw));           // 1 behind the car ... 0 in front of it: the look-at point slides back onto the car
    float ctr[3] = { (float)gCar.x + fx * 2.0f * kAhead, baseY + 0.9f, (float)gCar.z + fz * 2.0f * kAhead };
    const float e0 = atan2f(1.7f, 9.5f), el = e0 + gCamPitch, dist = sqrtf(9.5f * 9.5f + 1.7f * 1.7f), ya = h + gCamYaw;
    float eye[3] = { ctr[0] - sinf(ya) * cosf(el) * dist, ctr[1] + sinf(el) * dist, ctr[2] - cosf(ya) * cosf(el) * dist };
    eye[1] = max(eye[1], (float)Terrain::meshH(eye[0], eye[2]) + 1.0f);          // never inside a hill behind the car
    M4 P, V, VP, I, MVP, Mdl; persp(P, gFov, (float)gW / gH, 0.2f, 7000); lookAt(V, eye, ctr); mul(VP, P, V);
    glUniform3fv(uCam, 1, eye);

    // ground
    ident(I); mul(MVP, VP, I);
    glUniformMatrix4fv(uMVP, 1, GL_FALSE, MVP); glUniformMatrix4fv(uModel, 1, GL_FALSE, I);
    glUseProgram(BridgeGL::gProgT); glUniformMatrix4fv(BridgeGL::uT_VP, 1, GL_FALSE, VP); glUniform3fv(BridgeGL::uT_Cam, 1, eye);          // far ground: same grass shader as the hills
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, BridgeGL::gGrass); glUniform1i(BridgeGL::uT_Grass, 0); BridgeGL::drawGpu(gGroundG);
    BridgeGL::drawTerrain(VP, eye);                              // carved river bed (grass -> wet mud -> gravel) + hills inside the patch
    TerrainGL::draw(VP, eye);                                    // hill strips north / south of the patch + the distant mountain ring
    // winding mud roads + sand verges (own shaders / VAOs), then back to the car program
    RoadGL::draw(VP, eye);
    static const auto t0 = chrono::steady_clock::now();
    const float tSec = (float)chrono::duration<double>(now - t0).count();
    BridgeGL::draw(VP, eye, tSec);                               // bridges (timber, dirt, road blend) + river water
    FenceGL::draw(VP, V, eye);
    tunnelDraw(VP, eye);                                         // tunnel mouths (arch + earth mound + dark tube)                                   // fence posts + ropes + flying dirt + lamp poles
    glUseProgram(gProg);

    // car: model nose is +X, game heading 0 = +Z  ->  rotation (heading - 90 deg)
    rotY(Mdl, h - 1.5707963f, (float)gCar.x, (float)gCar.z);
    {   // pitch along the bridge arch / hill (about the model Z axis) and roll with the cross slope (about the nose axis): M = Ry * Rz(pitch) * Rx(roll)
        const float cp = (float)cos(pitchS - CarGL::suspPitch), sp = (float)sin(pitchS - CarGL::suspPitch), cr = (float)cos(tRoll + CarGL::suspRoll), sr = (float)sin(tRoll + CarGL::suspRoll);   // slope + suspension (HTML car.rotation.x / .z)
        const float c = Mdl[0], s_ = -Mdl[2];                    // cos / sin of the heading rotation (Mdl[0] = c, Mdl[2] = -s)
        Mdl[0] = c * cp;                 Mdl[1] = sp;       Mdl[2] = -s_ * cp;
        Mdl[4] = -c * cr * sp + s_ * sr; Mdl[5] = cr * cp;  Mdl[6] = s_ * cr * sp + c * sr;
        Mdl[8] = c * sr * sp + s_ * cr;  Mdl[9] = -sr * cp; Mdl[10] = -s_ * sr * sp + c * cr;
    }
    Mdl[13] = (float)(si.rideY + bridgeY + carGy);               // tyres rest on the road / bridge deck / hill (sink to the grass off-road)
    CarGL::draw(VP, Mdl, eye, gCar, NightGL::night);                             // body, glass, lights, 4 wheels, contact shadow (own shader)
    glUseProgram(gProg);

    // green trees (full model nearby, baked billboard far away); wind time in seconds
    // TreeGL::draw(VP, V, eye, tSec);                          // broadleaf trees removed
    TreeGL::drawConifers(VP, eye, tSec);                               // pine / spruce forest (3 levels of detail, instanced)
    TreeGL::drawLeaves(VP, gH / (2.f * tanf(gFov * 0.5f)));          // needles shaken loose by the car
    VillageGL::draw(VP, eye, NightGL::night);                    // chalets + church (instanced, culled)
    TerrainGL::drawLake(VP, eye, tSec);                          // mountain lake (transparent: after the trees)
    if (gNatureFxOn) NatureFxGL::draw(VP, eye, tSec);                             // waterfall + low valley cloud (transparent)
    if (gTyreFxOn) TyreFx::draw(VP, gH);                                        // skid marks + tyre smoke + dust (transparent)

    // night: darken the picture, then the headlight pool and the car lights glow on top of it
    NightGL::overlay();
    SkyGL::update(NightGL::night);                               // HTML sky (drawn last, only where nothing else covers the screen)
    SkyGL::draw(eye, ctr, 1.0f, (float)gW / gH, tSec);
    NightGL::pool(VP, gCar.x, gCar.z, gCar.heading, carGy + bridgeY);
    CarGL::drawGlow(NightGL::night);
}
}
