// Sunny Drift - graphics quality preset (0 = Low, 1 = Normal, 2 = High). Scales how far trees / fences / houses are drawn.
#pragma once
namespace Quality {
  static int level = 1;
  static float treeDist = 2300.f;                  // Settings > "Tree distance": how far away trees are still drawn (far ones as 2D pictures of the real tree)
  static bool billboards(){ return true; }         // far trees are always baked camera-facing pictures (never a dark flat shape)
  static float distScale(){ return level == 0 ? 0.5f : (level == 2 ? 1.3f : 1.0f); }   // Normal = the original look
}
