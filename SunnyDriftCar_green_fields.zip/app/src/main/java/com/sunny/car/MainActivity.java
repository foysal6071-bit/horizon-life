package com.sunny.car;

import android.app.Activity;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.os.Handler;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.LinearGradient;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import java.nio.ByteBuffer;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MainActivity extends Activity {
    static { System.loadLibrary("car"); }
    static native void nInit(AssetManager am);
    static native void nResize(int w, int h);
    static native void nDraw();
    static native void nInput(int mask);
    static native void nNight(int on);
    static native float nSpeed();
    static native void nSkyImg(int id, int w, int h, ByteBuffer rgba);   // sky pictures: 0..4 cube faces, 5 mountain colour, 6 mountain data
    static native void nSens(float v);          // steering sensitivity (HTML steerSens, 0.6 ... 3, default 1.8)
    static native void nReset();                // HTML resetCar()
    static native void nWheelMode(int on);      // HTML Settings > Controls: buttons / wheel
    static native void nWheelDown(float deg);
    static native void nWheelMove(float deg);
    static native void nWheelUp();
    static native float nWheelRot();            // wheel angle in degrees (+ = clockwise)

    int mask = 0, kmask = 0;   // 1=left 2=right 4=gas 8=brake 16=handbrake 32=key left 64=key right   (mask = touch, kmask = keyboard)
    GLSurfaceView gl; SpeedView speed; View wheelView, bl, br;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        gl = new GLSurfaceView(this);
        gl.setEGLContextClientVersion(3);
        gl.setEGLConfigChooser(8, 8, 8, 8, 24, 0);
        gl.setRenderer(new GLSurfaceView.Renderer() {
            public void onSurfaceCreated(GL10 g, EGLConfig c) { loadSky(); nInit(getAssets()); }
            public void onSurfaceChanged(GL10 g, int w, int h) { nResize(w, h); }
            public void onDrawFrame(GL10 g) { nDraw(); }
        });
        FrameLayout root = new FrameLayout(this);
        root.addView(gl);
        final float dn = getResources().getDisplayMetrics().density;

        // ---- driving controls: steering arrows (left), brake + gas pedals and handbrake (right) ----
        bl  = addCtl(root, Ctl.LEFT,  2, 0, 28, 28, 104, 104);
        br  = addCtl(root, Ctl.RIGHT, 1, 0, 28 + 104 + 16, 28, 104, 104);
        addCtl(root, Ctl.GAS,   4,  Gravity.END, 28, 28, 92, 168);
        addCtl(root, Ctl.BRAKE, 8,  Gravity.END, 28 + 92 + 14, 28, 92, 118);
        addCtl(root, Ctl.HAND, 16,  Gravity.END, 28 + 92 + 14 + 14, 28 + 118 + 14, 70, 70);

        // ---- top-left round icon buttons: night / wheel / reset ----
        final IconBtn nb = new IconBtn(this, IconBtn.NIGHT);
        nb.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { nb.on = !nb.on; nb.invalidate(); nNight(nb.on ? 1 : 0); }
        });
        addTop(root, nb, 0);
        final IconBtn wb = new IconBtn(this, IconBtn.WHEEL);
        addTop(root, wb, 1);
        final IconBtn rb = new IconBtn(this, IconBtn.RESET);
        rb.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { nReset(); } });
        addTop(root, rb, 2);

        wheelView = new View(this) {      // drag-to-turn steering wheel (HTML #tWheel): rotation comes from the C++ Ctrl::Wheel
            final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            @Override protected void onDraw(Canvas c) {
                float w = getWidth(), h = getHeight(), cx = w / 2, cy = h / 2, r = Math.min(w, h) / 2 - dp(8);
                // soft base disc (does not rotate)
                p.setStyle(Paint.Style.FILL); p.setColor(0x33000000); c.drawCircle(cx, cy, r + dp(6), p);
                c.save(); c.rotate(nWheelRot(), cx, cy);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(r * 0.20f); p.setColor(0xEE16191E); c.drawCircle(cx, cy, r, p);
                p.setStrokeWidth(dp(2)); p.setColor(0x66FFFFFF); c.drawCircle(cx, cy, r + r * 0.10f, p); c.drawCircle(cx, cy, r - r * 0.10f, p);
                p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeWidth(r * 0.13f); p.setColor(0xEE2A2F38);
                c.drawLine(cx - r, cy, cx + r, cy, p); c.drawLine(cx, cy, cx, cy + r, p);
                p.setStyle(Paint.Style.FILL); p.setColor(0xFF1B1F26); c.drawCircle(cx, cy, r * 0.26f, p);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); p.setColor(0xFF29B6F6); c.drawCircle(cx, cy, r * 0.26f, p);
                p.setStyle(Paint.Style.FILL); p.setColor(0xFFFF3B3B);   // 12 o'clock mark
                c.drawRoundRect(new RectF(cx - r * 0.05f, cy - r - r * 0.10f, cx + r * 0.05f, cy - r + r * 0.10f), dp(2), dp(2), p);
                c.restore();
            }
            @Override public boolean onTouchEvent(MotionEvent e) {
                float deg = (float) Math.toDegrees(Math.atan2(e.getY() - getHeight() / 2f, e.getX() - getWidth() / 2f));
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: nWheelDown(deg); break;
                    case MotionEvent.ACTION_MOVE: nWheelMove(deg); break;
                    case MotionEvent.ACTION_UP: case MotionEvent.ACTION_CANCEL: nWheelUp(); break;
                }
                return true;
            }
        };
        FrameLayout.LayoutParams wlp = new FrameLayout.LayoutParams((int) dp(210), (int) dp(210), Gravity.BOTTOM | Gravity.START);
        wlp.leftMargin = (int) dp(28); wlp.bottomMargin = (int) dp(20);
        wheelView.setLayoutParams(wlp); wheelView.setVisibility(View.GONE); root.addView(wheelView);
        wb.setOnClickListener(new View.OnClickListener() {      // controls switch: buttons <-> steering wheel (HTML Settings > Controls)
            public void onClick(View v) {
                wb.on = !wb.on; wb.invalidate(); nWheelMode(wb.on ? 1 : 0);
                wheelView.setVisibility(wb.on ? View.VISIBLE : View.GONE);
                bl.setVisibility(wb.on ? View.GONE : View.VISIBLE); br.setVisibility(wb.on ? View.GONE : View.VISIBLE);
            }
        });
        final Handler wh = new Handler();
        wh.post(new Runnable() { public void run() { if (wheelView.getVisibility() == View.VISIBLE) wheelView.invalidate(); wh.postDelayed(this, 16); } });
        nSens(1.8f);

        speed = new SpeedView(this);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int) dp(200), (int) dp(92), Gravity.TOP | Gravity.END);
        lp.setMargins(0, (int) dp(14), (int) dp(20), 0);
        root.addView(speed, lp);
        setContentView(root);
        final Handler h = new Handler();
        h.post(new Runnable() { public void run() { speed.set(nSpeed()); h.postDelayed(this, 50); } });
    }

    float dp(float v) { return v * getResources().getDisplayMetrics().density; }

    View addCtl(FrameLayout root, int kind, final int bit, int grav, int mx, int my, int w, int hh) {
        Ctl c = new Ctl(this, kind, bit);
        int g = Gravity.BOTTOM | (grav == Gravity.END ? Gravity.END : Gravity.START);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int) dp(w), (int) dp(hh), g);
        if (g == (Gravity.BOTTOM | Gravity.END)) lp.rightMargin = (int) dp(mx); else lp.leftMargin = (int) dp(mx);
        lp.bottomMargin = (int) dp(my);
        root.addView(c, lp);
        return c;
    }

    void addTop(FrameLayout root, View v, int slot) {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int) dp(48), (int) dp(48), Gravity.TOP | Gravity.START);
        lp.setMargins((int) dp(20 + slot * 60), (int) dp(16), 0, 0);
        root.addView(v, lp);
    }

    // =====================================================================================
    //  Racing-style touch controls (custom drawn, translucent dark glass + accent colour)
    // =====================================================================================
    class Ctl extends View {
        static final int LEFT = 0, RIGHT = 1, GAS = 2, BRAKE = 3, HAND = 4;
        final int kind, bit, accent; boolean down;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Ctl(android.content.Context ctx, int kind, int bit) {
            super(ctx); this.kind = kind; this.bit = bit;
            accent = kind == GAS ? 0xFF2EE59D : kind == BRAKE ? 0xFFFF4D5A : kind == HAND ? 0xFFFFB020 : 0xFF29B6F6;
            setClickable(true);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) { down = true; mask |= bit; performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY); }
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) { down = false; mask &= ~bit; }
            else return true;
            nInput(mask | kmask); invalidate(); return true;
        }
        void text(Canvas c, String s, float cx, float cy, float size, int col) {
            p.setStyle(Paint.Style.FILL); p.setColor(col); p.setTextSize(size); p.setTextAlign(Paint.Align.CENTER);
            p.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
            c.drawText(s, cx, cy - (p.ascent() + p.descent()) / 2f, p);
        }
        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), cx = w / 2, cy = h / 2, pad = dp(5);
            c.save(); if (down) c.scale(0.95f, 0.95f, cx, cy);
            RectF r = new RectF(pad, pad, w - pad, h - pad);
            float rad = kind == HAND ? Math.min(w, h) / 2 : dp(24);
            p.setShader(null); p.setStyle(Paint.Style.FILL);
            if (down) { p.setColor((accent & 0x00FFFFFF) | 0x44000000); c.drawRoundRect(new RectF(r.left - dp(3), r.top - dp(3), r.right + dp(3), r.bottom + dp(3)), rad + dp(3), rad + dp(3), p); }
            int top = down ? ((accent & 0x00FFFFFF) | 0xF0000000) : 0xCC323843;
            int bot = down ? (0xF0000000 | ((accent >> 1) & 0x7F7F7F)) : 0xCC12151A;
            p.setShader(new LinearGradient(0, r.top, 0, r.bottom, top, bot, Shader.TileMode.CLAMP));
            c.drawRoundRect(r, rad, rad, p); p.setShader(null);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2));
            p.setColor(down ? 0xFFFFFFFF : ((accent & 0x00FFFFFF) | 0x99000000)); c.drawRoundRect(r, rad, rad, p);
            // glossy top highlight
            if (!down) { p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1)); p.setColor(0x22FFFFFF);
                c.drawRoundRect(new RectF(r.left + dp(5), r.top + dp(5), r.right - dp(5), r.bottom - dp(5)), rad - dp(4), rad - dp(4), p); }
            int ic = down ? 0xFFFFFFFF : 0xFFEAF0F6;
            p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND);
            if (kind == LEFT || kind == RIGHT) {
                float s = Math.min(w, h) * 0.20f, dir = kind == LEFT ? 1 : -1;
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(7));
                for (int i = 0; i < 2; i++) {
                    float ox = (i == 0 ? -1 : 1) * s * 0.55f * -dir;            // leading chevron brighter
                    boolean lead = i == 1;
                    p.setColor(lead ? ic : ((ic & 0x00FFFFFF) | 0x55000000));
                    Path pt = new Path();
                    pt.moveTo(cx + ox + dir * s * 0.5f, cy - s); pt.lineTo(cx + ox - dir * s * 0.5f, cy); pt.lineTo(cx + ox + dir * s * 0.5f, cy + s);
                    c.drawPath(pt, p);
                }
            } else if (kind == GAS || kind == BRAKE) {
                text(c, kind == GAS ? "GAS" : "BRAKE", cx, r.top + dp(22), dp(15), ic);
                int n = kind == GAS ? 6 : 4; float y0 = r.top + dp(46), y1 = r.bottom - dp(18);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(6));
                p.setColor(down ? 0xFFFFFFFF : ((accent & 0x00FFFFFF) | 0xCC000000));
                for (int i = 0; i < n; i++) { float y = y0 + (y1 - y0) * i / (n - 1f); c.drawLine(cx - w * 0.26f, y, cx + w * 0.26f, y, p); }
            } else {                                                              // handbrake: ( P )
                float rr = Math.min(w, h) / 2;
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(3)); p.setColor(ic);
                c.drawArc(new RectF(cx - rr * 0.72f, cy - rr * 0.72f, cx + rr * 0.72f, cy + rr * 0.72f), 150, 60, false, p);
                c.drawArc(new RectF(cx - rr * 0.72f, cy - rr * 0.72f, cx + rr * 0.72f, cy + rr * 0.72f), -30, 60, false, p);
                c.drawCircle(cx, cy, rr * 0.44f, p);
                text(c, "P", cx, cy, rr * 0.62f, ic);
            }
            c.restore();
        }
    }

    // round glass icon button (night / wheel / reset)
    class IconBtn extends View {
        static final int NIGHT = 0, WHEEL = 1, RESET = 2;
        final int kind; boolean on;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        IconBtn(android.content.Context ctx, int kind) { super(ctx); this.kind = kind; setClickable(true); }
        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) { setAlpha(0.6f); performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY); }
            else if (e.getActionMasked() == MotionEvent.ACTION_UP || e.getActionMasked() == MotionEvent.ACTION_CANCEL) setAlpha(1f);
            return super.onTouchEvent(e);
        }
        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), cx = w / 2, cy = getHeight() / 2, r = w / 2 - dp(2), k = r * 0.46f;
            int col = on ? 0xFF29B6F6 : 0xFFEAF0F6;
            p.setStyle(Paint.Style.FILL); p.setColor(0xB0141820); c.drawCircle(cx, cy, r, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.5f)); p.setColor(on ? 0xFF29B6F6 : 0x55FFFFFF); c.drawCircle(cx, cy, r, p);
            p.setColor(col); p.setStrokeWidth(dp(2.2f)); p.setStrokeCap(Paint.Cap.ROUND);
            if (kind == NIGHT) {
                if (on) {                                                         // sun (tap = back to day)
                    p.setStyle(Paint.Style.FILL); c.drawCircle(cx, cy, k * 0.52f, p); p.setStyle(Paint.Style.STROKE);
                    for (int i = 0; i < 8; i++) { double a = i * Math.PI / 4;
                        c.drawLine(cx + (float) Math.cos(a) * k * 0.82f, cy + (float) Math.sin(a) * k * 0.82f, cx + (float) Math.cos(a) * k * 1.12f, cy + (float) Math.sin(a) * k * 1.12f, p); }
                } else {                                                          // moon
                    Path m = new Path(), cut = new Path();
                    m.addCircle(cx, cy, k, Path.Direction.CW); cut.addCircle(cx + k * 0.55f, cy - k * 0.35f, k * 0.85f, Path.Direction.CW);
                    m.op(cut, Path.Op.DIFFERENCE); p.setStyle(Paint.Style.FILL); c.drawPath(m, p);
                }
            } else if (kind == WHEEL) {
                p.setStyle(Paint.Style.STROKE); c.drawCircle(cx, cy, k, p);
                c.drawLine(cx - k, cy, cx - k * 0.25f, cy, p); c.drawLine(cx + k * 0.25f, cy, cx + k, cy, p); c.drawLine(cx, cy + k * 0.25f, cx, cy + k, p);
                p.setStyle(Paint.Style.FILL); c.drawCircle(cx, cy, k * 0.22f, p);
            } else {                                                              // reset: circular arrow
                p.setStyle(Paint.Style.STROKE);
                c.drawArc(new RectF(cx - k, cy - k, cx + k, cy + k), -50, 280, false, p);
                double a = Math.toRadians(230); float px = cx + (float) Math.cos(a) * k, py = cy + (float) Math.sin(a) * k;
                float tx = (float) -Math.sin(a), ty = (float) Math.cos(a), nx = (float) Math.cos(a), ny = (float) Math.sin(a), q = k * 0.55f;
                Path ah = new Path(); ah.moveTo(px + tx * q, py + ty * q); ah.lineTo(px + nx * q * 0.8f, py + ny * q * 0.8f); ah.lineTo(px - nx * q * 0.8f, py - ny * q * 0.8f); ah.close();
                p.setStyle(Paint.Style.FILL); c.drawPath(ah, p);
            }
        }
    }

    // digital speedometer with a segmented rev-style bar
    class SpeedView extends View {
        float kmh;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        SpeedView(android.content.Context ctx) { super(ctx); }
        void set(float v) { if ((int) v != (int) kmh) { kmh = v; invalidate(); } else kmh = v; }
        int lerp(int a, int b, float t) {
            int ar = a >> 16 & 255, ag = a >> 8 & 255, ab = a & 255, br2 = b >> 16 & 255, bg = b >> 8 & 255, bb = b & 255;
            return 0xFF000000 | ((int) (ar + (br2 - ar) * t) << 16) | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
        }
        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            p.setStyle(Paint.Style.FILL); p.setColor(0x80101318); c.drawRoundRect(new RectF(0, 0, w, h), dp(18), dp(18), p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.5f)); p.setColor(0x33FFFFFF); c.drawRoundRect(new RectF(1, 1, w - 1, h - 1), dp(18), dp(18), p);
            p.setStyle(Paint.Style.FILL); p.setTextAlign(Paint.Align.CENTER); p.setColor(0xFFFFFFFF);
            p.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC)); p.setTextSize(dp(46));
            c.drawText(String.valueOf((int) kmh), w * 0.42f, dp(48), p);
            p.setTextSize(dp(13)); p.setColor(0xAAFFFFFF); p.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
            p.setTextAlign(Paint.Align.LEFT); c.drawText("KM/H", w * 0.42f + dp(52), dp(48), p);
            int n = 24, lit = Math.min(n, Math.round(kmh / 160f * n));
            float x0 = dp(14), gap = dp(3), sw = (w - 2 * x0 - gap * (n - 1)) / n, y0 = h - dp(24), hh = dp(10);
            for (int i = 0; i < n; i++) {
                float t = i / (n - 1f);
                p.setColor(i < lit ? (t < 0.6f ? lerp(0xFF2EE59D, 0xFFFFD600, t / 0.6f) : lerp(0xFFFFD600, 0xFFFF3D3D, (t - 0.6f) / 0.4f)) : 0x33FFFFFF);
                float x = x0 + i * (sw + gap);
                Path sp = new Path(); sp.moveTo(x + dp(3), y0); sp.lineTo(x + sw + dp(3), y0); sp.lineTo(x + sw, y0 + hh); sp.lineTo(x, y0 + hh); sp.close();   // slanted segments
                c.drawPath(sp, p);
            }
        }
    }

    // the HTML sky pictures (embedded JPEG / PNG): decode here, hand the RGBA pixels to the C++ sky
    void loadSky() {
        String[] names = {"sky_0.jpg", "sky_1.jpg", "sky_2.jpg", "sky_3.jpg", "sky_4.jpg", "mtn_col.jpg", "mtn_data.png"};
        for (int i = 0; i < names.length; i++) {
            try {
                BitmapFactory.Options o = new BitmapFactory.Options(); o.inPreferredConfig = Bitmap.Config.ARGB_8888; o.inScaled = false;
                Bitmap b = BitmapFactory.decodeStream(getAssets().open(names[i]), null, o);
                if (b == null) continue;
                ByteBuffer bb = ByteBuffer.allocateDirect(b.getWidth() * b.getHeight() * 4);
                b.copyPixelsToBuffer(bb); bb.rewind();
                nSkyImg(i, b.getWidth(), b.getHeight(), bb); b.recycle();
            } catch (Exception e) { /* missing picture: that part of the sky stays plain */ }
        }
    }

    // keyboard (HTML: W / S / A / D, arrows, Space = handbrake, R = reset)
    int keyBit(int k) {
        switch (k) {
            case KeyEvent.KEYCODE_W: case KeyEvent.KEYCODE_DPAD_UP: return 4;
            case KeyEvent.KEYCODE_S: case KeyEvent.KEYCODE_DPAD_DOWN: return 8;
            case KeyEvent.KEYCODE_A: case KeyEvent.KEYCODE_DPAD_LEFT: return 32;
            case KeyEvent.KEYCODE_D: case KeyEvent.KEYCODE_DPAD_RIGHT: return 64;
            case KeyEvent.KEYCODE_SPACE: return 16;
        }
        return 0;
    }
    @Override public boolean onKeyDown(int k, KeyEvent e) {
        if (k == KeyEvent.KEYCODE_R) { if (e.getRepeatCount() == 0) nReset(); return true; }
        int b = keyBit(k); if (b == 0) return super.onKeyDown(k, e);
        kmask |= b; nInput(mask | kmask); return true;
    }
    @Override public boolean onKeyUp(int k, KeyEvent e) {
        int b = keyBit(k); if (b == 0) return super.onKeyUp(k, e);
        kmask &= ~b; nInput(mask | kmask); return true;
    }

    @Override protected void onPause() { super.onPause(); gl.onPause(); }
    @Override protected void onResume() { super.onResume(); gl.onResume(); }
}
