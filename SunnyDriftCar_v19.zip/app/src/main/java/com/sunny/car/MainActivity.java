package com.sunny.car;

import android.app.Activity;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.os.Handler;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import java.nio.ByteBuffer;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MainActivity extends Activity {
    static { System.loadLibrary("car"); }
    static native void nInit(AssetManager am);
    static native void nResize(int w, int h);
    static native void nDraw();
    static native void nInput(int mask);
    static native void nNight(int on);
    static native float nSpeed();
    static native void nSkyImg(int id, int w, int h, ByteBuffer rgba);   // sky pictures: 0..4 cube faces, 5 mountain colour, 6 mountain data
    static native void nSens(float v);          // steering sensitivity (HTML steerSens, 0.6 ... 3, default 1.8)
    static native void nReset();                // HTML resetCar()
    static native void nWheelMode(int on);      // HTML Settings > Controls: buttons / wheel
    static native void nWheelDown(float deg);
    static native void nWheelMove(float deg);
    static native void nWheelUp();
    static native float nWheelRot();            // wheel angle in degrees (+ = clockwise)
    static native float[] nMapData();           // minimap: roads, river, track, lake, village  [kind, n, payload...]
    static native void nCamDrag(float dx, float dy);   // free camera: finger drag in pixels
    static native void nCamRelease();
    static native void nGfx(float fovRad, int tyreFx, int natureFx);        // settings: field of view + effects on/off
    static native void nQuality(int level);                                // settings: graphics quality 0 low / 1 normal / 2 high (draw distance)
    static native void nTreeDist(float farMetres, float nearMetres);                            // settings: how far trees are drawn (far ones as 2D pictures)
    static native void nPause(int on);                                     // settings open = game paused
    static native void nCamCfg(float sens, int autoReturn, int invertY);   // settings: free-camera options
    static native void nSound(float[] out);                                // engine sound inputs: rpm, throttle, skid, km/h
    static native void nCarPose(float[] out);   // minimap: car x, z, heading (rad)

    int mask = 0, kmask = 0;   // 1=left 2=right 4=gas 8=brake 16=handbrake 32=key left 64=key right   (mask = touch, kmask = keyboard)
    GLSurfaceView gl; SpeedView speed; MiniMapView miniMap; View wheelView, bl, br;
    SharedPreferences sp; FrameLayout rootView; View settingsLayer; IconBtn wheelBtn; TextView fpsTv; EngineSound engine = new EngineSound();
    final java.util.ArrayList<View> ctlViews = new java.util.ArrayList<>(), topList = new java.util.ArrayList<>();
    boolean haptic = true, mapShown = true; int mapDp = 128; volatile int frames;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("sunny_settings", MODE_PRIVATE);
        gl = new GLSurfaceView(this);
        gl.setEGLContextClientVersion(3);
        gl.setEGLConfigChooser(8, 8, 8, 8, 24, 0);
        gl.setRenderer(new GLSurfaceView.Renderer() {
            public void onSurfaceCreated(GL10 g, EGLConfig c) { loadSky(); nInit(getAssets()); }
            public void onSurfaceChanged(GL10 g, int w, int h) { nResize(w, h); }
            public void onDrawFrame(GL10 g) { frames++; nDraw(); }
        });
        FrameLayout root = new FrameLayout(this); rootView = root;
        root.addView(gl);
        gl.setOnTouchListener(new View.OnTouchListener() {   // drag on the free part of the screen = orbit the camera round the car
            int pid = -1; float lx, ly;
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: case MotionEvent.ACTION_POINTER_DOWN:
                        if (pid < 0) { int i = e.getActionIndex(); pid = e.getPointerId(i); lx = e.getX(i); ly = e.getY(i); }
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        int i = e.findPointerIndex(pid); if (i < 0) return true;
                        float x = e.getX(i), y = e.getY(i); nCamDrag(x - lx, y - ly); lx = x; ly = y; return true;
                    }
                    case MotionEvent.ACTION_UP: case MotionEvent.ACTION_CANCEL: pid = -1; nCamRelease(); return true;
                    case MotionEvent.ACTION_POINTER_UP:
                        if (e.getPointerId(e.getActionIndex()) == pid) { pid = -1; nCamRelease(); }
                        return true;
                }
                return true;
            }
        });
        final float dn = getResources().getDisplayMetrics().density;

        // ---- driving controls: steering arrows (left), brake + gas pedals and handbrake (right) ----
        bl  = addCtl(root, Ctl.LEFT,  2, 0, 28, 28, 104, 104);
        br  = addCtl(root, Ctl.RIGHT, 1, 0, 28 + 104 + 16, 28, 104, 104);
        addCtl(root, Ctl.GAS,   4,  Gravity.END, 28, 28, 92, 168);
        addCtl(root, Ctl.BRAKE, 8,  Gravity.END, 28 + 92 + 14, 28, 92, 118);
        addCtl(root, Ctl.HAND, 16,  Gravity.END, 28 + 92 + 14 + 14, 28 + 118 + 14, 70, 70);

        // ---- top-left round icon buttons: night / wheel / reset ----
        final IconBtn nb = new IconBtn(this, IconBtn.NIGHT);
        nb.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { nb.on = !nb.on; nb.invalidate(); nNight(nb.on ? 1 : 0); }
        });
        addTop(root, nb, 0);
        final IconBtn wb = new IconBtn(this, IconBtn.WHEEL); wheelBtn = wb;
        addTop(root, wb, 1);
        final IconBtn rb = new IconBtn(this, IconBtn.RESET);
        rb.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { nReset(); } });
        addTop(root, rb, 2);
        final IconBtn sb = new IconBtn(this, IconBtn.SETTINGS);
        sb.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { openSettings(); } });
        addTop(root, sb, 3);

        wheelView = new View(this) {      // drag-to-turn steering wheel (HTML #tWheel): rotation comes from the C++ Ctrl::Wheel
            final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            @Override protected void onDraw(Canvas c) {
                float w = getWidth(), h = getHeight(), cx = w / 2, cy = h / 2, r = Math.min(w, h) / 2 - dp(8);
                // soft base disc (does not rotate)
                p.setStyle(Paint.Style.FILL); p.setColor(0x33000000); c.drawCircle(cx, cy, r + dp(6), p);
                c.save(); c.rotate(nWheelRot(), cx, cy);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(r * 0.20f); p.setColor(0xEE16191E); c.drawCircle(cx, cy, r, p);
                p.setStrokeWidth(dp(2)); p.setColor(0x66FFFFFF); c.drawCircle(cx, cy, r + r * 0.10f, p); c.drawCircle(cx, cy, r - r * 0.10f, p);
                p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeWidth(r * 0.13f); p.setColor(0xEE2A2F38);
                c.drawLine(cx - r, cy, cx + r, cy, p); c.drawLine(cx, cy, cx, cy + r, p);
                p.setStyle(Paint.Style.FILL); p.setColor(0xFF1B1F26); c.drawCircle(cx, cy, r * 0.26f, p);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); p.setColor(0xFF29B6F6); c.drawCircle(cx, cy, r * 0.26f, p);
                p.setStyle(Paint.Style.FILL); p.setColor(0xFFFF3B3B);   // 12 o'clock mark
                c.drawRoundRect(new RectF(cx - r * 0.05f, cy - r - r * 0.10f, cx + r * 0.05f, cy - r + r * 0.10f), dp(2), dp(2), p);
                c.restore();
            }
            @Override public boolean onTouchEvent(MotionEvent e) {
                float deg = (float) Math.toDegrees(Math.atan2(e.getY() - getHeight() / 2f, e.getX() - getWidth() / 2f));
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: nWheelDown(deg); break;
                    case MotionEvent.ACTION_MOVE: nWheelMove(deg); break;
                    case MotionEvent.ACTION_UP: case MotionEvent.ACTION_CANCEL: nWheelUp(); break;
                }
                return true;
            }
        };
        FrameLayout.LayoutParams wlp = new FrameLayout.LayoutParams((int) dp(210), (int) dp(210), Gravity.BOTTOM | Gravity.START);
        wlp.leftMargin = (int) dp(28); wlp.bottomMargin = (int) dp(20);
        wheelView.setLayoutParams(wlp); wheelView.setVisibility(View.GONE); root.addView(wheelView);
        wb.setOnClickListener(new View.OnClickListener() {      // controls switch: buttons <-> steering wheel (HTML Settings > Controls)
            public void onClick(View v) { setWheelMode(!wb.on); pi("ctl_mode", wb.on ? 1 : 0); }
        });
        final Handler wh = new Handler();
        wh.post(new Runnable() { public void run() { if (wheelView.getVisibility() == View.VISIBLE) wheelView.invalidate(); wh.postDelayed(this, 16); } });

        speed = new SpeedView(this);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int) dp(200), (int) dp(92), Gravity.TOP | Gravity.END);
        lp.setMargins(0, (int) dp(14), (int) dp(20), 0);
        root.addView(speed, lp);
        // ---- minimap, top-left corner (tap it to switch between the zoomed follow view and the whole map) ----
        miniMap = new MiniMapView(this);
        FrameLayout.LayoutParams mlp = new FrameLayout.LayoutParams((int) dp(mapDp), (int) dp(mapDp), Gravity.TOP | Gravity.START);
        mlp.setMargins((int) dp(14), (int) dp(12), 0, 0);
        root.addView(miniMap, mlp);
        fpsTv = new TextView(this); fpsTv.setTextColor(0xFFA3E635); fpsTv.setTextSize(12); fpsTv.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        fpsTv.setShadowLayer(3, 0, 0, 0xFF000000); fpsTv.setVisibility(View.GONE);
        root.addView(fpsTv, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.CENTER_HORIZONTAL));
        setContentView(root);
        applyAll();
        final Handler h = new Handler();
        h.post(new Runnable() { public void run() { speed.set(nSpeed()); miniMap.tick(); h.postDelayed(this, 50); } });
        final Handler fh = new Handler();
        fh.post(new Runnable() { int last = 0; public void run() { int f = frames; if (fpsTv.getVisibility() == View.VISIBLE) fpsTv.setText((f - last) * 2 + " FPS"); last = f; fh.postDelayed(this, 500); } });
    }

    float dp(float v) { return v * getResources().getDisplayMetrics().density; }

    View addCtl(FrameLayout root, int kind, final int bit, int grav, int mx, int my, int w, int hh) {
        Ctl c = new Ctl(this, kind, bit);
        int g = Gravity.BOTTOM | (grav == Gravity.END ? Gravity.END : Gravity.START);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int) dp(w), (int) dp(hh), g);
        if (g == (Gravity.BOTTOM | Gravity.END)) lp.rightMargin = (int) dp(mx); else lp.leftMargin = (int) dp(mx);
        lp.bottomMargin = (int) dp(my);
        root.addView(c, lp); ctlViews.add(c);
        return c;
    }

    void addTop(FrameLayout root, View v, int slot) {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int) dp(48), (int) dp(48), Gravity.TOP | Gravity.START);
        root.addView(v, lp); topList.add(v); layoutTop();
    }

    void layoutTop() {   // the round buttons sit right of the minimap (or at the corner when the minimap is hidden)
        final float x0 = mapShown ? 14 + mapDp + 14 : 20;
        for (int i = 0; i < topList.size(); i++) {
            View v = topList.get(i); FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) v.getLayoutParams();
            lp.setMargins((int) dp(x0 + i * 60), (int) dp(16), 0, 0); v.setLayoutParams(lp);
        }
    }

    // =====================================================================================
    //  Racing-style touch controls (custom drawn, translucent dark glass + accent colour)
    // =====================================================================================
    class Ctl extends View {
        static final int LEFT = 0, RIGHT = 1, GAS = 2, BRAKE = 3, HAND = 4;
        final int kind, bit, accent; boolean down;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Ctl(android.content.Context ctx, int kind, int bit) {
            super(ctx); this.kind = kind; this.bit = bit;
            accent = kind == GAS ? 0xFF2EE59D : kind == BRAKE ? 0xFFFF4D5A : kind == HAND ? 0xFFFFB020 : 0xFF29B6F6;
            setClickable(true);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) { down = true; mask |= bit; if (haptic) performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY); }
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) { down = false; mask &= ~bit; }
            else return true;
            nInput(mask | kmask); invalidate(); return true;
        }
        void text(Canvas c, String s, float cx, float cy, float size, int col) {
            p.setStyle(Paint.Style.FILL); p.setColor(col); p.setTextSize(size); p.setTextAlign(Paint.Align.CENTER);
            p.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
            c.drawText(s, cx, cy - (p.ascent() + p.descent()) / 2f, p);
        }
        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), cx = w / 2, cy = h / 2, pad = dp(5);
            c.save(); if (down) c.scale(0.95f, 0.95f, cx, cy);
            RectF r = new RectF(pad, pad, w - pad, h - pad);
            float rad = kind == HAND ? Math.min(w, h) / 2 : dp(24);
            final int rgb = accent & 0x00FFFFFF;
            p.setShader(null); p.setStyle(Paint.Style.FILL);
            if (down) { p.setColor(rgb | 0x55000000); c.drawRoundRect(new RectF(r.left - dp(4), r.top - dp(4), r.right + dp(4), r.bottom + dp(4)), rad + dp(4), rad + dp(4), p); }
            // transparent glass: a faint dark base, then a soft tint of the button's own colour (stronger while pressed)
            p.setColor(0x38101820); c.drawRoundRect(r, rad, rad, p);
            p.setShader(new LinearGradient(0, r.top, 0, r.bottom, rgb | (down ? 0x99000000 : 0x40000000), rgb | (down ? 0x55000000 : 0x14000000), Shader.TileMode.CLAMP));
            c.drawRoundRect(r, rad, rad, p); p.setShader(null);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2));
            p.setColor(down ? 0xFFFFFFFF : (rgb | 0xCC000000)); c.drawRoundRect(r, rad, rad, p);
            if (!down) { p.setStrokeWidth(dp(1)); p.setColor(0x26FFFFFF);                               // thin inner highlight
                c.drawRoundRect(new RectF(r.left + dp(5), r.top + dp(5), r.right - dp(5), r.bottom - dp(5)), rad - dp(4), rad - dp(4), p); }
            int ic = down ? 0xFFFFFFFF : accent;
            if (kind == LEFT || kind == RIGHT) {
                SvgIcon.draw(c, p, kind == LEFT ? SvgIcon.STEER_L : SvgIcon.STEER_R, cx, cy, Math.min(w, h) * 0.50f, ic, 2.6f, true);
            } else if (kind == GAS || kind == BRAKE) {
                SvgIcon.draw(c, p, kind == GAS ? SvgIcon.PEDAL_GAS : SvgIcon.PEDAL_BRAKE, cx, cy - dp(8), w * (kind == GAS ? 0.50f : 0.56f), ic, 2.0f, true);
                text(c, kind == GAS ? "GAS" : "BRAKE", cx, r.bottom - dp(18), dp(14), ic);
            } else {
                SvgIcon.draw(c, p, SvgIcon.HANDBRAKE, cx, cy, Math.min(w, h) * 0.66f, ic, 2.0f, true);
            }
            c.restore();
        }
    }

    // round glass icon button (night / wheel / reset)
    class IconBtn extends View {
        static final int NIGHT = 0, WHEEL = 1, RESET = 2, SETTINGS = 3;
        final int kind; boolean on;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        IconBtn(android.content.Context ctx, int kind) { super(ctx); this.kind = kind; setClickable(true); }
        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) { setAlpha(0.6f); performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY); }
            else if (e.getActionMasked() == MotionEvent.ACTION_UP || e.getActionMasked() == MotionEvent.ACTION_CANCEL) setAlpha(1f);
            return super.onTouchEvent(e);
        }
        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), cx = w / 2, cy = getHeight() / 2, r = w / 2 - dp(2);
            // every button has its own colour: night = violet (amber sun when on), wheel = teal, reset = orange
            final int col = kind == NIGHT ? (on ? 0xFFFBBF24 : 0xFFA78BFA) : kind == WHEEL ? 0xFF2DD4BF : kind == SETTINGS ? 0xFFA3E635 : 0xFFFB923C, rgb = col & 0x00FFFFFF;
            p.setStyle(Paint.Style.FILL); p.setColor(0x38101820); c.drawCircle(cx, cy, r, p);                     // transparent glass base
            p.setColor(rgb | (on ? 0x59000000 : 0x26000000)); c.drawCircle(cx, cy, r, p);                         // colour tint
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.8f)); p.setColor(rgb | (on ? 0xFF000000 : 0xB0000000)); c.drawCircle(cx, cy, r, p);
            String[] icon = kind == NIGHT ? (on ? SvgIcon.SUN : SvgIcon.MOON) : kind == WHEEL ? SvgIcon.WHEEL : kind == SETTINGS ? SvgIcon.SLIDERS : SvgIcon.RESET;
            SvgIcon.draw(c, p, icon, cx, cy, r * 1.12f, col, 2.1f, true);
        }
    }

    // digital speedometer with a segmented rev-style bar
    class SpeedView extends View {
        float kmh;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        SpeedView(android.content.Context ctx) { super(ctx); }
        boolean mph;
        float disp(float v) { return mph ? v * 0.621371f : v; }
        void set(float v) { if ((int) disp(v) != (int) disp(kmh)) { kmh = v; invalidate(); } else kmh = v; }
        int lerp(int a, int b, float t) {
            int ar = a >> 16 & 255, ag = a >> 8 & 255, ab = a & 255, br2 = b >> 16 & 255, bg = b >> 8 & 255, bb = b & 255;
            return 0xFF000000 | ((int) (ar + (br2 - ar) * t) << 16) | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
        }
        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            p.setStyle(Paint.Style.FILL); p.setColor(0x80101318); c.drawRoundRect(new RectF(0, 0, w, h), dp(18), dp(18), p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.5f)); p.setColor(0x33FFFFFF); c.drawRoundRect(new RectF(1, 1, w - 1, h - 1), dp(18), dp(18), p);
            p.setStyle(Paint.Style.FILL); p.setTextAlign(Paint.Align.CENTER); p.setColor(0xFFFFFFFF);
            p.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC)); p.setTextSize(dp(46));
            c.drawText(String.valueOf((int) disp(kmh)), w * 0.42f, dp(48), p);
            p.setTextSize(dp(13)); p.setColor(0xAAFFFFFF); p.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
            p.setTextAlign(Paint.Align.LEFT); c.drawText(mph ? "MPH" : "KM/H", w * 0.42f + dp(52), dp(48), p);
            int n = 24, lit = Math.min(n, Math.round(kmh / 160f * n));
            float x0 = dp(14), gap = dp(3), sw = (w - 2 * x0 - gap * (n - 1)) / n, y0 = h - dp(24), hh = dp(10);
            for (int i = 0; i < n; i++) {
                float t = i / (n - 1f);
                p.setColor(i < lit ? (t < 0.6f ? lerp(0xFF2EE59D, 0xFFFFD600, t / 0.6f) : lerp(0xFFFFD600, 0xFFFF3D3D, (t - 0.6f) / 0.4f)) : 0x33FFFFFF);
                float x = x0 + i * (sw + gap);
                Path sp = new Path(); sp.moveTo(x + dp(3), y0); sp.lineTo(x + sw + dp(3), y0); sp.lineTo(x + sw, y0 + hh); sp.lineTo(x, y0 + hh); sp.close();   // slanted segments
                c.drawPath(sp, p);
            }
        }
    }



    // =====================================================================================
    //  Modern line icons: real SVG path data (24 x 24 viewBox, 2 px round-cap strokes, Lucide style) parsed at runtime.
    // =====================================================================================
    static class SvgIcon {
        static final String[] STEER_L = { "M14 5l-7 7 7 7", "M20 5l-7 7 7 7" };                 // double chevron (first = leading)
        static final String[] STEER_R = { "M10 5l7 7-7 7", "M4 5l7 7-7 7" };
        static final String[] PEDAL_GAS = { "M8 3h8a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z", "M9.5 8h5", "M9.5 12h5", "M9.5 16h5" };
        static final String[] PEDAL_BRAKE = { "M6 6h12a3 3 0 0 1 3 3v6a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V9a3 3 0 0 1 3-3z", "M8 10v4", "M12 10v4", "M16 10v4" };
        static final String[] HANDBRAKE = { "M12 3a9 9 0 1 0 0 18 9 9 0 1 0 0-18z", "M10 16V8h3a2.2 2.2 0 0 1 0 4.4h-3" };
        static final String[] MOON = { "M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9z" };
        static final String[] SUN = { "M12 8a4 4 0 1 0 0 8 4 4 0 1 0 0-8z", "M12 2v2", "M12 20v2", "M4.93 4.93l1.41 1.41", "M17.66 17.66l1.41 1.41", "M2 12h2", "M20 12h2", "M6.34 17.66l-1.41 1.41", "M19.07 4.93l-1.41 1.41" };
        static final String[] WHEEL = { "M12 3a9 9 0 1 0 0 18 9 9 0 1 0 0-18z", "M12 10a2 2 0 1 0 0 4 2 2 0 1 0 0-4z", "M3 12h7", "M14 12h7", "M12 14v7" };
        static final String[] SLIDERS = { "M21 4h-7", "M10 4H3", "M21 12h-9", "M8 12H3", "M21 20h-5", "M12 20H3", "M14 2v4", "M8 10v4", "M16 18v4" };
        static final String[] CLOSE = { "M18 6L6 18", "M6 6l12 12" };
        static final String[] RESET = { "M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8", "M3 3v5h5" };
        static final java.util.HashMap<String, Path> cache = new java.util.HashMap<>();

        // draws the icon centred at (cx, cy), `size` px wide, in colour `col`, with a soft glow underneath; later paths of a chevron pair are dimmer
        static void draw(Canvas c, Paint p, String[] paths, float cx, float cy, float size, int col, float stroke, boolean glow) {
            c.save(); c.translate(cx - size / 2, cy - size / 2); final float k = size / 24f; c.scale(k, k);
            p.setStyle(Paint.Style.STROKE); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND); p.setShader(null);
            for (int i = 0; i < paths.length; i++) {
                Path path = parse(paths[i]);
                final boolean dim = paths == STEER_L || paths == STEER_R ? i == 1 : false;
                final int cc = dim ? (col & 0x00FFFFFF) | 0x70000000 : col;
                if (glow) { p.setStrokeWidth(stroke * 2.3f); p.setColor((cc & 0x00FFFFFF) | ((cc >>> 24) / 4 << 24)); c.drawPath(path, p); }
                p.setStrokeWidth(stroke); p.setColor(cc); c.drawPath(path, p);
            }
            c.restore();
        }

        static Path parse(String d) {
            Path cached = cache.get(d); if (cached != null) return cached;
            java.util.ArrayList<String> t = new java.util.ArrayList<>();
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("[MmLlHhVvCcQqAaZz]|-?(?:\\d+\\.?\\d*|\\.\\d+)(?:[eE][-+]?\\d+)?").matcher(d);
            while (m.find()) t.add(m.group());
            Path path = new Path(); int i = 0; char cmd = 'M'; float x = 0, y = 0, sx = 0, sy = 0;
            while (i < t.size()) {
                String tok = t.get(i);
                if (Character.isLetter(tok.charAt(0))) { cmd = tok.charAt(0); i++; if (cmd == 'Z' || cmd == 'z') { path.close(); x = sx; y = sy; continue; } }
                final boolean rel = Character.isLowerCase(cmd);
                switch (Character.toUpperCase(cmd)) {
                    case 'M': { float nx = f(t, i++) + (rel ? x : 0), ny = f(t, i++) + (rel ? y : 0); path.moveTo(nx, ny); x = sx = nx; y = sy = ny; cmd = rel ? 'l' : 'L'; break; }
                    case 'L': { float nx = f(t, i++) + (rel ? x : 0), ny = f(t, i++) + (rel ? y : 0); path.lineTo(nx, ny); x = nx; y = ny; break; }
                    case 'H': { float nx = f(t, i++) + (rel ? x : 0); path.lineTo(nx, y); x = nx; break; }
                    case 'V': { float ny = f(t, i++) + (rel ? y : 0); path.lineTo(x, ny); y = ny; break; }
                    case 'C': { float x1 = f(t, i++) + (rel ? x : 0), y1 = f(t, i++) + (rel ? y : 0), x2 = f(t, i++) + (rel ? x : 0), y2 = f(t, i++) + (rel ? y : 0), nx = f(t, i++) + (rel ? x : 0), ny = f(t, i++) + (rel ? y : 0);
                        path.cubicTo(x1, y1, x2, y2, nx, ny); x = nx; y = ny; break; }
                    case 'Q': { float x1 = f(t, i++) + (rel ? x : 0), y1 = f(t, i++) + (rel ? y : 0), nx = f(t, i++) + (rel ? x : 0), ny = f(t, i++) + (rel ? y : 0);
                        path.quadTo(x1, y1, nx, ny); x = nx; y = ny; break; }
                    case 'A': { float rx = f(t, i++), ry = f(t, i++); i++; boolean large = f(t, i++) != 0, sweep = f(t, i++) != 0;
                        float nx = f(t, i++) + (rel ? x : 0), ny = f(t, i++) + (rel ? y : 0); arc(path, x, y, rx, ry, large, sweep, nx, ny); x = nx; y = ny; break; }
                    default: i++;
                }
            }
            cache.put(d, path); return path;
        }
        static float f(java.util.ArrayList<String> t, int i) { return i < t.size() ? Float.parseFloat(t.get(i)) : 0f; }

        // SVG elliptical arc (axis-aligned) -> Path.arcTo (endpoint to centre parameterisation, SVG spec F.6.5)
        static void arc(Path path, float x0, float y0, float rx, float ry, boolean large, boolean sweep, float x, float y) {
            rx = Math.abs(rx); ry = Math.abs(ry);
            if (rx == 0 || ry == 0 || (x0 == x && y0 == y)) { path.lineTo(x, y); return; }
            double dx = (x0 - x) / 2.0, dy = (y0 - y) / 2.0, lam = dx * dx / (rx * (double) rx) + dy * dy / (ry * (double) ry);
            if (lam > 1) { double sq = Math.sqrt(lam); rx *= sq; ry *= sq; }
            double num = rx * rx * ry * ry - rx * rx * dy * dy - ry * ry * dx * dx, den = rx * rx * dy * dy + ry * ry * dx * dx;
            double co = (large == sweep ? -1 : 1) * Math.sqrt(Math.max(0, num / den));
            double cxp = co * (rx * dy / ry), cyp = co * -(ry * dx / rx), cx = cxp + (x0 + x) / 2.0, cy = cyp + (y0 + y) / 2.0;
            double th1 = Math.atan2((dy - cyp) / ry, (dx - cxp) / rx), th2 = Math.atan2((-dy - cyp) / ry, (-dx - cxp) / rx), dth = th2 - th1;
            if (!sweep && dth > 0) dth -= 2 * Math.PI; else if (sweep && dth < 0) dth += 2 * Math.PI;
            path.arcTo(new RectF((float) (cx - rx), (float) (cy - ry), (float) (cx + rx), (float) (cy + ry)), (float) Math.toDegrees(th1), (float) Math.toDegrees(dth));
        }
    }


    // =====================================================================================
    //  Settings: Graphics / Sound / HUD / Control tabs. Custom-drawn controls, values kept in SharedPreferences.
    // =====================================================================================
    interface BoolCb { void on(boolean v); }
    interface IntCb { void on(int v); }
    interface FloatCb { void on(float v); }
    interface Fmt { String f(float v); }

    float gf(String k, float d) { return sp.getFloat(k, d); }
    int gi(String k, int d) { return sp.getInt(k, d); }
    boolean gb(String k, boolean d) { return sp.getBoolean(k, d); }
    void pf(String k, float v) { sp.edit().putFloat(k, v).apply(); }
    void pi(String k, int v) { sp.edit().putInt(k, v).apply(); }
    void pb(String k, boolean v) { sp.edit().putBoolean(k, v).apply(); }

    // ---- apply (called at start, and by every control when it changes) ----
    void applyAll() { applyRes(); applyGfx(); applySound(); applyHud(); applyControl(); }

    void applyRes() {   // render the 3D scene at a lower resolution and let the GPU scale it up: big FPS win on high-res phones
        android.util.DisplayMetrics dm = new android.util.DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(dm);
        final int sw = Math.max(dm.widthPixels, dm.heightPixels), sh = Math.min(dm.widthPixels, dm.heightPixels);
        final int th = new int[]{480, 720, 1080, 0}[Math.max(0, Math.min(3, gi("gfx_res", 1)))];
        if (th == 0 || th >= sh) gl.getHolder().setSizeFromLayout();
        else { float sc = th / (float) sh; gl.getHolder().setFixedSize(Math.round(sw * sc), Math.round(sh * sc)); }
    }
    void applyGfx() { nQuality(gi("gfx_quality", 1)); nTreeDist(gf("gfx_treedist", 4000f), gf("gfx_tree3d", 330f)); nGfx(gf("gfx_fov", 57f) * (float) Math.PI / 180f, gb("gfx_tyre", true) ? 1 : 0, gb("gfx_nature", true) ? 1 : 0); }
    void applySound() { engine.master = gf("snd_master", 0.8f); engine.eng = gf("snd_engine", 1f); engine.skid = gf("snd_skid", 0.8f); }
    void applyHud() {
        speed.setVisibility(gb("hud_speed", true) ? View.VISIBLE : View.GONE);
        speed.mph = gi("hud_unit", 0) == 1; speed.invalidate();
        mapShown = gb("hud_map", true); mapDp = new int[]{100, 128, 160}[Math.max(0, Math.min(2, gi("hud_mapsize", 1)))];
        miniMap.setVisibility(mapShown ? View.VISIBLE : View.GONE);
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) miniMap.getLayoutParams(); lp.width = lp.height = (int) dp(mapDp); miniMap.setLayoutParams(lp);
        layoutTop();
        fpsTv.setVisibility(gb("hud_fps", false) ? View.VISIBLE : View.GONE);
        final float a = gf("hud_alpha", 1f);
        for (View v : ctlViews) v.setAlpha(a);
        wheelView.setAlpha(a);
    }
    void applyControl() {
        nSens(gf("ctl_steer", 1.8f));
        nCamCfg(gf("ctl_cam", 1f), gb("ctl_cam_auto", true) ? 1 : 0, gb("ctl_cam_inv", false) ? 1 : 0);
        haptic = gb("ctl_haptic", true);
        setWheelMode(gi("ctl_mode", 0) == 1);
    }
    void setWheelMode(boolean on) {   // controls switch: buttons <-> steering wheel
        wheelBtn.on = on; wheelBtn.invalidate(); nWheelMode(on ? 1 : 0);
        wheelView.setVisibility(on ? View.VISIBLE : View.GONE);
        bl.setVisibility(on ? View.GONE : View.VISIBLE); br.setVisibility(on ? View.GONE : View.VISIBLE);
    }

    // ---- small custom widgets ----
    class Toggle extends View {
        boolean on; final int accent; final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Toggle(Context ctx, boolean on, int accent, final BoolCb cb) {
            super(ctx); this.on = on; this.accent = accent; setClickable(true);
            setOnClickListener(new View.OnClickListener() { public void onClick(View v) { Toggle.this.on = !Toggle.this.on; invalidate(); cb.on(Toggle.this.on); } });
        }
        @Override protected void onMeasure(int w, int h) { setMeasuredDimension((int) dp(48), (int) dp(28)); }
        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), r = h / 2;
            p.setStyle(Paint.Style.FILL); p.setColor(on ? (accent | 0xFF000000) : 0x33FFFFFF); c.drawRoundRect(new RectF(0, 0, w, h), r, r, p);
            p.setColor(on ? 0xFFFFFFFF : 0xFFAEB6C2); c.drawCircle(on ? w - r : r, r, r - dp(3.5f), p);
        }
    }

    class Slider extends View {
        final float min, max, step; float val; final int accent; final FloatCb cb; final TextView label; final Fmt fmt;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Slider(Context ctx, float min, float max, float step, float val, int accent, Fmt fmt, TextView label, FloatCb cb) {
            super(ctx); this.min = min; this.max = max; this.step = step; this.val = val; this.accent = accent; this.fmt = fmt; this.label = label; this.cb = cb;
            label.setText(fmt.f(val));
        }
        @Override protected void onMeasure(int w, int h) { setMeasuredDimension((int) dp(150), (int) dp(34)); }
        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), cy = getHeight() / 2f, pad = dp(11), tw = w - 2 * pad, f = (val - min) / (max - min);
            p.setStyle(Paint.Style.STROKE); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeWidth(dp(5));
            p.setColor(0x33FFFFFF); c.drawLine(pad, cy, w - pad, cy, p);
            p.setColor(accent | 0xFF000000); c.drawLine(pad, cy, pad + tw * f, cy, p);
            p.setStyle(Paint.Style.FILL); p.setColor(0xFFFFFFFF); c.drawCircle(pad + tw * f, cy, dp(9), p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2.5f)); p.setColor(accent | 0xFF000000); c.drawCircle(pad + tw * f, cy, dp(9), p);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
            float pad = dp(11), f = Math.max(0f, Math.min(1f, (e.getX() - pad) / (getWidth() - 2 * pad)));
            float v = min + f * (max - min); if (step > 0) v = Math.round(v / step) * step; v = Math.max(min, Math.min(max, v));
            if (v != val) { val = v; label.setText(fmt.f(v)); invalidate(); if (e.getActionMasked() != MotionEvent.ACTION_CANCEL) cb.on(v); }
            return true;
        }
    }

    class SvgView extends View {
        final String[] ic; final int col; final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        SvgView(Context ctx, String[] ic, int col) { super(ctx); this.ic = ic; this.col = col; setClickable(true); }
        @Override protected void onDraw(Canvas c) { SvgIcon.draw(c, p, ic, getWidth() / 2f, getHeight() / 2f, Math.min(getWidth(), getHeight()) * 0.6f, col, 2.2f, false); }
    }

    TextView tv(String text, float sizeSp, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(text); t.setTextSize(sizeSp); t.setTextColor(color);
        t.setTypeface(Typeface.create(bold ? "sans-serif-medium" : "sans-serif", Typeface.NORMAL)); return t;
    }
    GradientDrawable pill(int fill, int stroke, float radiusDp) {
        GradientDrawable g = new GradientDrawable(); g.setColor(fill); g.setCornerRadius(dp(radiusDp)); if (stroke != 0) g.setStroke((int) dp(1.2f), stroke); return g;
    }
    View divider() { View v = new View(this); v.setBackgroundColor(0x16FFFFFF); v.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)); return v; }

    void addRow(LinearLayout ll, String title, String desc, View widget) {
        LinearLayout r = new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL); r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, (int) dp(9), 0, (int) dp(9));
        LinearLayout left = new LinearLayout(this); left.setOrientation(LinearLayout.VERTICAL);
        left.addView(tv(title, 14.5f, 0xFFFFFFFF, true));
        if (desc != null) left.addView(tv(desc, 11f, 0x88FFFFFF, false));
        r.addView(left, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)); r.addView(widget);
        ll.addView(r); ll.addView(divider());
    }
    void toggle(LinearLayout ll, int acc, String title, String desc, final String key, boolean def, final BoolCb cb) {
        addRow(ll, title, desc, new Toggle(this, gb(key, def), acc, new BoolCb() { public void on(boolean v) { pb(key, v); cb.on(v); } }));
    }
    void slider(LinearLayout ll, int acc, String title, String desc, final String key, float def, float min, float max, float step, Fmt fmt, final FloatCb cb) {
        LinearLayout w = new LinearLayout(this); w.setOrientation(LinearLayout.HORIZONTAL); w.setGravity(Gravity.CENTER_VERTICAL);
        TextView lab = tv("", 13f, acc | 0xFF000000, true); lab.setGravity(Gravity.END); lab.setMinWidth((int) dp(52));
        w.addView(new Slider(this, min, max, step, gf(key, def), acc, fmt, lab, new FloatCb() { public void on(float v) { pf(key, v); cb.on(v); } }));
        w.addView(lab); addRow(ll, title, desc, w);
    }
    void seg(LinearLayout ll, final int acc, String title, String desc, final String key, int def, String[] opts, final IntCb cb) {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setBackground(pill(0x22FFFFFF, 0, 14)); row.setPadding((int) dp(3), (int) dp(3), (int) dp(3), (int) dp(3));
        final TextView[] t = new TextView[opts.length];
        for (int i = 0; i < opts.length; i++) {
            t[i] = tv(opts[i], 12f, 0xCCFFFFFF, true); t[i].setGravity(Gravity.CENTER); t[i].setPadding((int) dp(11), (int) dp(6), (int) dp(11), (int) dp(6)); row.addView(t[i]);
            final int idx = i;
            t[i].setOnClickListener(new View.OnClickListener() { public void onClick(View v) { styleSeg(t, idx, acc); pi(key, idx); cb.on(idx); } });
        }
        styleSeg(t, Math.max(0, Math.min(opts.length - 1, gi(key, def))), acc); addRow(ll, title, desc, row);
    }
    void styleSeg(TextView[] t, int sel, int acc) {
        for (int i = 0; i < t.length; i++) {
            if (i == sel) { t[i].setBackground(pill(acc | 0xFF000000, 0, 11)); t[i].setTextColor(0xFF10151C); } else { t[i].setBackground(null); t[i].setTextColor(0xCCFFFFFF); }
        }
    }

    // ---- the four tabs ----
    static final int ACC_GFX = 0x38BDF8, ACC_SND = 0xA78BFA, ACC_HUD = 0xFBBF24, ACC_CTL = 0x34D399;
    void buildTab(LinearLayout ll, int tab) {
        if (tab == 0) {
            seg(ll, ACC_GFX, "Graphics quality", "Low = fastest, High = best looking", "gfx_quality", 1, new String[]{"Low", "Normal", "High"}, new IntCb() { public void on(int v) {
                pi("gfx_res", v);                       // Low 480p / Normal 720p / High 1080p
                pb("gfx_nature", v != 0);               // Low: no waterfall & valley cloud
                pb("gfx_tyre", true);
                pf("gfx_treedist", v == 0 ? 2500f : (v == 2 ? 6000f : 4000f)); pf("gfx_tree3d", v == 0 ? 200f : (v == 2 ? 450f : 330f));   // preset sets a matching tree distance (still adjustable below)
                applyRes(); applyGfx();
                if (refreshTab != null) refreshTab.run();   // other controls follow the preset
            } });
            seg(ll, ACC_GFX, "Resolution", "Lower = smoother on slow phones", "gfx_res", 1, new String[]{"480p", "720p", "1080p", "Native"}, new IntCb() { public void on(int v) { applyRes(); } });
            slider(ll, ACC_GFX, "Field of view", "Wider = more speed feeling", "gfx_fov", 57f, 45f, 80f, 1f, new Fmt() { public String f(float v) { return (int) v + "\u00B0"; } }, new FloatCb() { public void on(float v) { applyGfx(); } });
            slider(ll, ACC_GFX, "Tree distance", "How far trees are seen (far ones = 2D picture facing you)", "gfx_treedist", 4000f, 500f, 6500f, 250f, new Fmt() { public String f(float v) { return (int) v + " m"; } }, new FloatCb() { public void on(float v) { applyGfx(); } });
            slider(ll, ACC_GFX, "3D tree distance", "Closer than this = real 3D tree, farther = 2D picture. Lower = faster", "gfx_tree3d", 330f, 60f, 600f, 10f, new Fmt() { public String f(float v) { return (int) v + " m"; } }, new FloatCb() { public void on(float v) { applyGfx(); } });
            toggle(ll, ACC_GFX, "Tyre smoke & skid marks", null, "gfx_tyre", true, new BoolCb() { public void on(boolean v) { applyGfx(); } });
            toggle(ll, ACC_GFX, "Waterfall & valley cloud", null, "gfx_nature", true, new BoolCb() { public void on(boolean v) { applyGfx(); } });
        } else if (tab == 1) {
            Fmt pct = new Fmt() { public String f(float v) { return Math.round(v * 100) + "%"; } };
            slider(ll, ACC_SND, "Master volume", null, "snd_master", 0.8f, 0f, 1f, 0.05f, pct, new FloatCb() { public void on(float v) { applySound(); } });
            slider(ll, ACC_SND, "Engine", "Pitch follows rpm and throttle", "snd_engine", 1f, 0f, 1f, 0.05f, pct, new FloatCb() { public void on(float v) { applySound(); } });
            slider(ll, ACC_SND, "Tyre screech", "When the car drifts or the handbrake locks", "snd_skid", 0.8f, 0f, 1f, 0.05f, pct, new FloatCb() { public void on(float v) { applySound(); } });
        } else if (tab == 2) {
            toggle(ll, ACC_HUD, "Speedometer", null, "hud_speed", true, new BoolCb() { public void on(boolean v) { applyHud(); } });
            seg(ll, ACC_HUD, "Speed unit", null, "hud_unit", 0, new String[]{"km/h", "mph"}, new IntCb() { public void on(int v) { applyHud(); } });
            toggle(ll, ACC_HUD, "Minimap", "Tap the minimap to zoom out / in", "hud_map", true, new BoolCb() { public void on(boolean v) { applyHud(); } });
            seg(ll, ACC_HUD, "Minimap size", null, "hud_mapsize", 1, new String[]{"Small", "Medium", "Large"}, new IntCb() { public void on(int v) { applyHud(); } });
            toggle(ll, ACC_HUD, "FPS counter", null, "hud_fps", false, new BoolCb() { public void on(boolean v) { applyHud(); } });
            slider(ll, ACC_HUD, "Button opacity", "Driving buttons and steering wheel", "hud_alpha", 1f, 0.3f, 1f, 0.05f, new Fmt() { public String f(float v) { return Math.round(v * 100) + "%"; } }, new FloatCb() { public void on(float v) { applyHud(); } });
        } else {
            seg(ll, ACC_CTL, "Steering", null, "ctl_mode", 0, new String[]{"Buttons", "Wheel"}, new IntCb() { public void on(int v) { applyControl(); } });
            slider(ll, ACC_CTL, "Steering sensitivity", "How fast the wheels turn", "ctl_steer", 1.8f, 0.6f, 3f, 0.1f, new Fmt() { public String f(float v) { return String.format(java.util.Locale.US, "%.1f", v); } }, new FloatCb() { public void on(float v) { applyControl(); } });
            slider(ll, ACC_CTL, "Camera sensitivity", "Drag on the screen to look around", "ctl_cam", 1f, 0.3f, 2f, 0.1f, new Fmt() { public String f(float v) { return String.format(java.util.Locale.US, "%.1fx", v); } }, new FloatCb() { public void on(float v) { applyControl(); } });
            toggle(ll, ACC_CTL, "Camera returns behind the car", "A moment after you let go", "ctl_cam_auto", true, new BoolCb() { public void on(boolean v) { applyControl(); } });
            toggle(ll, ACC_CTL, "Invert camera up / down", null, "ctl_cam_inv", false, new BoolCb() { public void on(boolean v) { applyControl(); } });
            toggle(ll, ACC_CTL, "Vibration on buttons", null, "ctl_haptic", true, new BoolCb() { public void on(boolean v) { applyControl(); } });
        }
    }

    // ---- the panel (game is paused while it is open) ----
    int curTab = 0; Runnable refreshTab;
    void openSettings() {
        if (settingsLayer != null) return;
        mask = 0; nInput(kmask); nWheelUp(); nCamRelease(); nPause(1);
        final FrameLayout layer = new FrameLayout(this); layer.setBackgroundColor(0x88000000); layer.setClickable(true);
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        final int pw = Math.min((int) dp(620), dm.widthPixels - (int) dp(32)), ph = Math.min((int) dp(340), dm.heightPixels - (int) dp(24));
        LinearLayout panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(pill(0xEE111720, 0x33FFFFFF, 22)); panel.setPadding((int) dp(18), (int) dp(12), (int) dp(18), (int) dp(10));
        // header: title, reset, close
        LinearLayout head = new LinearLayout(this); head.setOrientation(LinearLayout.HORIZONTAL); head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = tv("Settings", 19f, 0xFFFFFFFF, true); head.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        final TextView reset = tv("Reset", 12.5f, 0xFFFB923C, true); reset.setPadding((int) dp(12), (int) dp(6), (int) dp(12), (int) dp(6)); reset.setBackground(pill(0x22FB923C, 0x99FB923C, 14));
        head.addView(reset);
        SvgView close = new SvgView(this, SvgIcon.CLOSE, 0xFFEAF0F6); LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams((int) dp(38), (int) dp(38)); clp.leftMargin = (int) dp(8);
        close.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { closeSettings(); } }); head.addView(close, clp);
        panel.addView(head);
        // tabs
        LinearLayout tabs = new LinearLayout(this); tabs.setOrientation(LinearLayout.HORIZONTAL);
        final String[] names = {"Graphics", "Sound", "HUD", "Control"}; final int[] accs = {ACC_GFX, ACC_SND, ACC_HUD, ACC_CTL};
        final TextView[] tabViews = new TextView[4];
        final LinearLayout content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        final Runnable[] show = new Runnable[1];
        for (int i = 0; i < 4; i++) {
            final int idx = i; tabViews[i] = tv(names[i], 13.5f, 0xAAFFFFFF, true); tabViews[i].setGravity(Gravity.CENTER); tabViews[i].setPadding(0, (int) dp(8), 0, (int) dp(8));
            LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f); tlp.setMargins((int) dp(3), (int) dp(8), (int) dp(3), (int) dp(4));
            tabViews[i].setOnClickListener(new View.OnClickListener() { public void onClick(View v) { curTab = idx; show[0].run(); } });
            tabs.addView(tabViews[i], tlp);
        }
        panel.addView(tabs);
        show[0] = new Runnable() { public void run() {
            for (int i = 0; i < 4; i++) {
                if (i == curTab) { tabViews[i].setBackground(pill((accs[i] | 0x33000000), accs[i] | 0xFF000000, 14)); tabViews[i].setTextColor(accs[i] | 0xFF000000); }
                else { tabViews[i].setBackground(null); tabViews[i].setTextColor(0xAAFFFFFF); }
            }
            content.removeAllViews(); buildTab(content, curTab);
        } };
        reset.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { sp.edit().clear().apply(); applyAll(); show[0].run(); } });
        ScrollView sv = new ScrollView(this); sv.setFillViewport(true); sv.setVerticalScrollBarEnabled(false); sv.addView(content);
        panel.addView(sv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        refreshTab = show[0]; show[0].run();
        layer.addView(panel, new FrameLayout.LayoutParams(pw, ph, Gravity.CENTER));
        rootView.addView(layer, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        settingsLayer = layer;
    }
    void closeSettings() {
        if (settingsLayer == null) return;
        rootView.removeView(settingsLayer); settingsLayer = null; refreshTab = null; nPause(0);
    }

    // =====================================================================================
    //  Engine + tyre sound: synthesised live (no sound files). Pitch follows the car's rpm, loudness the throttle, a noise burst the skid.
    // =====================================================================================
    static class EngineSound implements Runnable {
        volatile float master = 0.8f, eng = 1f, skid = 0.8f; volatile boolean run; Thread th;
        void start() { if (run) return; run = true; th = new Thread(this, "engine-sound"); th.start(); }
        void stop() { run = false; if (th != null) { try { th.join(400); } catch (InterruptedException e) { } th = null; } }
        public void run() {
            final int sr = 22050; AudioTrack at;
            try {
                final int minB = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
                at = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    .setAudioFormat(new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(Math.max(minB, 4096)).setTransferMode(AudioTrack.MODE_STREAM).build();
                at.play();
            } catch (Throwable t) { run = false; return; }
            final short[] buf = new short[512]; final float[] st = new float[4];
            double ph = 0, ph2 = 0; float rpm = 900, thr = 0, sk = 0, l1 = 0, l2 = 0; int seed = 12345;
            final double TWO_PI = Math.PI * 2;
            while (run) {
                MainActivity.nSound(st); final float rT = st[0], tT = st[1], sT = st[2];
                for (int i = 0; i < buf.length; i++) {
                    rpm += (rT - rpm) * 0.0016f; thr += (tT - thr) * 0.0016f; sk += (sT - sk) * 0.0016f;
                    final double f = rpm / 60.0 * 2.0;                                  // firing frequency
                    ph += f / sr; if (ph >= 1) ph -= 1; ph2 += f * 0.5 / sr; if (ph2 >= 1) ph2 -= 1;
                    final double w = ph * TWO_PI, bright = 0.35 + 0.65 * thr;
                    float s = (float) (0.55 * Math.sin(w) + 0.30 * Math.sin(2 * w + 0.5) + bright * (0.22 * Math.sin(3 * w) + 0.14 * Math.sin(4 * w + 1.0) + 0.09 * Math.sin(5 * w))
                              + 0.22 * Math.sin(ph2 * TWO_PI));
                    seed = seed * 1664525 + 1013904223; final float n = ((seed >>> 8) / 8388608f) - 1f;
                    final float gain = 0.30f + 0.70f * thr;
                    l1 += (n - l1) * 0.35f; l2 += (l1 - l2) * 0.35f;                    // band-passed noise = tyre squeal / hiss
                    float out = (s * 0.30f * eng * gain + n * 0.02f * eng * gain + (l1 - l2) * sk * 1.6f * skid) * master;
                    out = out / (1f + Math.abs(out));                                    // soft clip
                    buf[i] = (short) (out * 26000f);
                }
                if (at.write(buf, 0, buf.length) < 0) break;
            }
            try { at.stop(); } catch (Throwable t) { }
            at.release();
        }
    }

    // =====================================================================================
    //  Minimap (round, top-left): roads, river, dirt track, lake, village + the car.
    //  Default = zoomed, heading-up (the car always points up). Tap = whole map, north-up.
    // =====================================================================================
    class MiniMapView extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Path roads = new Path(), conn = new Path(), river = new Path(), track = new Path(), bound = new Path();
        final java.util.ArrayList<float[]> huts = new java.util.ArrayList<>(), churches = new java.util.ArrayList<>();
        float lakeX, lakeZ, lakeR; boolean haveLake, loaded;
        final float[] pose = new float[3]; boolean full;
        final Matrix m = new Matrix(); final float[] mv = new float[9];
        final Path clip = new Path(), arrow = new Path();
        static final float ZOOM_R = 230f, FULL_R = 1480f;      // metres shown from the centre to the edge

        MiniMapView(android.content.Context ctx) {
            super(ctx); setClickable(true);
            setOnClickListener(new View.OnClickListener() { public void onClick(View v) { full = !full; invalidate(); } });
            p.setStrokeJoin(Paint.Join.ROUND); p.setStrokeCap(Paint.Cap.ROUND);
        }
        void load() {
            float[] d = nMapData(); if (d == null) return;
            int i = 0;
            while (i + 1 < d.length) {
                int kind = (int) d[i], n = (int) d[i + 1]; i += 2;
                if (kind == 4) { lakeX = d[i]; lakeZ = d[i + 1]; lakeR = d[i + 2]; haveLake = true; i += 3; continue; }
                Path t = kind == 0 ? roads : kind == 1 ? conn : kind == 2 ? river : kind == 3 ? track : kind == 7 ? bound : null;
                float[] pts = (t == null) ? new float[n * 2] : null;
                for (int k = 0; k < n; k++) {
                    float x = d[i + k * 2], z = d[i + k * 2 + 1];
                    if (t != null) { if (k == 0) t.moveTo(x, z); else t.lineTo(x, z); } else { pts[k * 2] = x; pts[k * 2 + 1] = z; }
                }
                if (kind == 7) bound.close();
                if (kind == 5) huts.add(pts); else if (kind == 6) churches.add(pts);
                i += n * 2;
            }
            loaded = true;
        }
        void tick() {
            if (!loaded) load();
            nCarPose(pose); invalidate();
        }
        @Override public boolean performClick() { return super.performClick(); }

        void line(Canvas c, Path path, float wMetres, float minPx, float s, int col) {
            p.setStyle(Paint.Style.STROKE); p.setColor(col); p.setStrokeWidth(Math.max(wMetres, dp(minPx) / s)); c.drawPath(path, p);
        }
        void dots(Canvas c, java.util.ArrayList<float[]> list, float rPx, float s, int col) {
            p.setStyle(Paint.Style.FILL); p.setColor(col);
            for (float[] a : list) for (int k = 0; k + 1 < a.length; k += 2) c.drawCircle(a[k], a[k + 1], rPx / s, p);
        }
        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), cx = w / 2, cy = h / 2, r = Math.min(w, h) / 2 - dp(2);
            // background disc
            p.setStyle(Paint.Style.FILL); p.setColor(0xCC1E3324); c.drawCircle(cx, cy, r, p);
            if (!loaded) return;
            final float R = full ? FULL_R : ZOOM_R, s = r / R;
            final float hd = pose[2], sH = (float) Math.sin(hd), cH = (float) Math.cos(hd);
            float a, b, cc, d;                 // screen = M * (x, z)
            if (full) { a = -s; b = 0; cc = 0; d = -s; } else { a = -cH * s; b = sH * s; cc = -sH * s; d = -cH * s; }
            float cxW = full ? 0 : pose[0], czW = full ? 0 : pose[1];
            mv[0] = a; mv[1] = b; mv[2] = cx - (a * cxW + b * czW);
            mv[3] = cc; mv[4] = d; mv[5] = cy - (cc * cxW + d * czW);
            mv[6] = 0; mv[7] = 0; mv[8] = 1; m.setValues(mv);
            c.save(); clip.reset(); clip.addCircle(cx, cy, r, Path.Direction.CW); c.clipPath(clip);
            c.concat(m);
            // lake, river, dirt track, roads (dark casing first, light surface on top)
            if (haveLake) { p.setStyle(Paint.Style.FILL); p.setColor(0xFF2F8FD0); c.drawCircle(lakeX, lakeZ, lakeR, p); }
            line(c, bound, 6f, 2.2f, s, 0xFFFF4D4D);                      // world boundary: the car cannot go beyond this red line
            line(c, river, 20f, 3f, s, 0xFF3D9BE0);
            line(c, track, 8f, 1.6f, s, 0xFFB08A5A);
            line(c, roads, 22f, 4.2f, s, 0xFF0E1216); line(c, conn, 18f, 3.6f, s, 0xFF0E1216);
            line(c, roads, 14f, 2.6f, s, 0xFFC9CED6); line(c, conn, 12f, 2.2f, s, 0xFFC9CED6);
            dots(c, huts, 2.6f, s, 0xFFFFB866);
            dots(c, churches, 4.2f, s, 0xFFFFFFFF);
            c.restore();
            // frame + north mark
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); p.setColor(0xCCFFFFFF); c.drawCircle(cx, cy, r, p);
            float nx = full ? 0 : sH, ny = full ? -1 : -cH;               // screen direction of "north" (+Z)
            float nr = r - dp(9);
            p.setStyle(Paint.Style.FILL); p.setColor(0xFFFF4D5A); c.drawCircle(cx + nx * nr, cy + ny * nr, dp(7), p);
            p.setColor(0xFFFFFFFF); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(dp(9));
            p.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
            c.drawText("N", cx + nx * nr, cy + ny * nr - (p.ascent() + p.descent()) / 2f, p);
            // the car: arrow (always up when zoomed; rotated by -heading on the whole map)
            float carX = cx, carY = cy;
            if (full) { carX = mv[0] * pose[0] + mv[1] * pose[1] + mv[2]; carY = mv[3] * pose[0] + mv[4] * pose[1] + mv[5]; }
            c.save(); c.translate(carX, carY); if (full) c.rotate((float) -Math.toDegrees(hd));
            float q = dp(7);
            arrow.reset(); arrow.moveTo(0, -q * 1.4f); arrow.lineTo(q, q); arrow.lineTo(0, q * 0.4f); arrow.lineTo(-q, q); arrow.close();
            p.setStyle(Paint.Style.FILL); p.setColor(0xFF29B6F6); c.drawPath(arrow, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.5f)); p.setColor(0xFFFFFFFF); c.drawPath(arrow, p);
            c.restore();
        }
    }

    // the HTML sky pictures (embedded JPEG / PNG): decode here, hand the RGBA pixels to the C++ sky
    void loadSky() {
        String[] names = {"sky_0.jpg", "sky_1.jpg", "sky_2.jpg", "sky_3.jpg", "sky_4.jpg", "mtn_col.jpg", "mtn_data.png"};
        for (int i = 0; i < names.length; i++) {
            try {
                BitmapFactory.Options o = new BitmapFactory.Options(); o.inPreferredConfig = Bitmap.Config.ARGB_8888; o.inScaled = false;
                Bitmap b = BitmapFactory.decodeStream(getAssets().open(names[i]), null, o);
                if (b == null) continue;
                ByteBuffer bb = ByteBuffer.allocateDirect(b.getWidth() * b.getHeight() * 4);
                b.copyPixelsToBuffer(bb); bb.rewind();
                nSkyImg(i, b.getWidth(), b.getHeight(), bb); b.recycle();
            } catch (Exception e) { /* missing picture: that part of the sky stays plain */ }
        }
    }

    // keyboard (HTML: W / S / A / D, arrows, Space = handbrake, R = reset)
    int keyBit(int k) {
        switch (k) {
            case KeyEvent.KEYCODE_W: case KeyEvent.KEYCODE_DPAD_UP: return 4;
            case KeyEvent.KEYCODE_S: case KeyEvent.KEYCODE_DPAD_DOWN: return 8;
            case KeyEvent.KEYCODE_A: case KeyEvent.KEYCODE_DPAD_LEFT: return 32;
            case KeyEvent.KEYCODE_D: case KeyEvent.KEYCODE_DPAD_RIGHT: return 64;
            case KeyEvent.KEYCODE_SPACE: return 16;
        }
        return 0;
    }
    @Override public boolean onKeyDown(int k, KeyEvent e) {
        if (k == KeyEvent.KEYCODE_R) { if (e.getRepeatCount() == 0) nReset(); return true; }
        int b = keyBit(k); if (b == 0) return super.onKeyDown(k, e);
        kmask |= b; nInput(mask | kmask); return true;
    }
    @Override public boolean onKeyUp(int k, KeyEvent e) {
        int b = keyBit(k); if (b == 0) return super.onKeyUp(k, e);
        kmask &= ~b; nInput(mask | kmask); return true;
    }

    @Override protected void onPause() { super.onPause(); engine.stop(); gl.onPause(); }
    @Override protected void onResume() { super.onResume(); gl.onResume(); engine.start(); }
    @Override public void onBackPressed() { if (settingsLayer != null) closeSettings(); else super.onBackPressed(); }
}
