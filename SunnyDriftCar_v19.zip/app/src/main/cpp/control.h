#pragma once
// Sunny Drift - car CONTROL layer, ported 1:1 from the HTML game:
//   keyboard (W/A/S/D, arrows, Space, R), touch pedals, drag-to-turn steering wheel (Settings > Controls > wheel),
//   steering sensitivity (steerSens = 1.8 by default, 0.6 ... 3), reset car (resetCar).
// The physics itself (Veh::step) lives in car_core.h and is identical to the HTML (verified numerically).
#include "car_core.h"
#include "road.h"

namespace Ctrl {
    // bit mask sent from Java
    enum { LEFT = 1, RIGHT = 2, GAS = 4, BRAKE = 8, HAND = 16, KLEFT = 32, KRIGHT = 64 };   // K* = keyboard steering (A / D / arrows)

    static double steerSens = 1.8;                         // HTML: let steerSens = 1.8
    static void setSens(double v){ if (v >= 0.6 && v <= 3) steerSens = v; }

    // ---- drag-to-turn steering wheel (HTML: settings.wheelRange = 135, rot in degrees, + = clockwise = right) ----
    struct Wheel {
        static constexpr double RANGE = 135;
        double rot = 0, lastA = 0; bool drag = false, wheelMode = false;
        void setMode(bool w){ wheelMode = w; rot = 0; drag = false; }
        void down(double angDeg){ drag = true; lastA = angDeg; }
        void move(double a){                                // pointermove
            if (!drag) return;
            double d = a - lastA; if (d > 180) d -= 360; if (d < -180) d += 360; lastA = a;
            rot = clampd(rot + d, -RANGE, RANGE);
        }
        void release(){ drag = false; }
        void frame(double dt = 1.0 / 60){                    // spring(): self-centres smoothly on release (0.78 per 1/60 s, whatever the frame rate)
            if (drag || rot == 0) return;
            rot *= pow(0.78, dt * 60); if (fabs(rot) < 0.5) rot = 0;
        }
        // touchState.analog: null in button mode, else -clamp(rot / range) (-1 right ... +1 left)
        bool analog(double& out) const { if (!wheelMode) return false; out = -clampd(rot / RANGE, -1, 1); return true; }
    };
    static Wheel wheel;

    // pedals + steering -> Veh::Input   (HTML: gas / brake / left / right / hand + analog rule)
    static void build(Input& in, int mask){
        in.left  = mask & (LEFT  | KLEFT);
        in.right = mask & (RIGHT | KRIGHT);
        in.gas   = mask & GAS;
        in.brake = mask & BRAKE;
        in.hand  = mask & HAND;
        in.sens  = steerSens;
        double a = 0; const bool kbSteer = mask & (KLEFT | KRIGHT);
        in.useAnalog = wheel.analog(a) && !kbSteer;          // analog is ignored while a steering key is held
        in.analog = in.useAnalog ? a : 0;
    }

    // HTML resetCar(): put the car on the nearest road point (360 samples on every road), facing the way it was going, everything at rest
    static void reset(CarState& S){
        const Road::Curve* roads[5] = { &Road::gNet.A, &Road::gNet.B, &Road::gNet.C, &Road::gNet.D, &Road::gNet.E };
        double bd = 1e18, bt = 0; const Road::Curve* bc = roads[0];
        for (const Road::Curve* cv : roads) for (int i = 0; i < 360; i++){
            const double t = i / 360.0; const Road::V3 p = cv->getPointAt(t);
            const double dx = p.x - S.x, dz = p.z - S.z, d = dx * dx + dz * dz;
            if (d < bd){ bd = d; bc = cv; bt = t; }
        }
        const Road::V3 p = bc->getPointAt(bt), tn = bc->getTangentAt(bt);
        double hd = atan2(tn.x, tn.z);
        if (cos(hd - S.heading) < 0) hd += M_PI;             // keep facing roughly the way you were going
        S.x = p.x; S.z = p.z; S.heading = hd;
        S.speed = S.vy = S.yaw = S.steer = S.steerAngle = 0;
        S.throttle = S.brake = S.hb = S.drift = 0; S.gear = 1; S.rpm = 900; S.shiftT = 0; S.slope = 0;
        S.fd = 0; S.ax = S.ay = S.axS = 0; S.revTimer = 0;
    }
}
