// Sunny Drift - Swiss village: where the wooden chalets and the church stand (pure C++, no OpenGL; drawing is in village_render.h).
//  * the village is laid out beside one stretch of a ring road: chalets on both sides, facing the road, the church with its pointed
//    spire in the middle, set back a little further so a small square opens in front of it
//  * a stretch is only used if every house has dry, fairly level ground, no other road / the river / the dirt track nearby
//  * blocked() keeps the trees and pines away from the houses (tree_render.h asks it), collide() makes the houses solid for the car
//  Call plan() once, after Road::init() and Terrain::init() and BEFORE the trees are planted.
#pragma once
#include <algorithm>
#include <cmath>
#include <random>
#include <vector>
#include "car_core.h"
#include "road.h"
#include "river.h"
#include "terrain.h"
#include "fence.h"

namespace Village {

enum { CHALET = 0, CHURCH = 1 };

struct Building {
    float x, z, y;            // position (y = ground height under the middle of the house)
    float rot;                // yaw: local +Z (the front, balcony / door side) points to (sin rot, cos rot) in the world
    float scale, ws;          // overall size, extra width factor (chalets only)
    float var;                // 0..1: wood tone + shutter colour
    int type;
    float hx, zMin, zMax;     // footprint in the house's own frame (already scaled): |x| <= hx, zMin <= z <= zMax
};
static std::vector<Building> gB;
static bool gPlanned = false;

// chalet footprint (local, before scaling): 7 m wide, 8.5 m deep + 1.6 m balcony at the front; church: 8.6 m wide, 19.6 m long (tower at the front)
static void footprint(Building& b){
    if (b.type == CHURCH){ b.hx = 4.4f * b.scale; b.zMin = -10.4f * b.scale; b.zMax = 9.9f * b.scale; }
    else { b.hx = (3.65f * b.ws + 0.15f) * b.scale; b.zMin = -4.5f * b.scale; b.zMax = 6.0f * b.scale; }
}

static inline void toLocal(const Building& b, float x, float z, float& lx, float& lz){
    const float dx = x - b.x, dz = z - b.z, c = std::cos(b.rot), s = std::sin(b.rot); lx = c * dx - s * dz; lz = s * dx + c * dz;
}
static inline void toWorldDir(const Building& b, float lx, float lz, float& wx, float& wz){
    const float c = std::cos(b.rot), s = std::sin(b.rot); wx = c * lx + s * lz; wz = -s * lx + c * lz;
}

// true if (x,z) is within `margin` metres of any house (used to keep trees away)
static bool blocked(float x, float z, float margin){
    for (const Building& b : gB){
        const float dx = x - b.x, dz = z - b.z; if (dx*dx + dz*dz > 900.f) continue;          // houses are < 25 m across: cheap reject
        float lx, lz; toLocal(b, x, z, lx, lz);
        if (std::fabs(lx) < b.hx + margin && lz > b.zMin - margin && lz < b.zMax + margin) return true;
    }
    return false;
}

static float groundAt(float x, float z){ return (float)Terrain::fieldH(x, z); }

// is a house of this type OK at (x,z) facing rot? fills the ground height
static bool siteOk(const Building& b, float expectClear, float& gy){
    if (std::fabs(River::riverSd(b.x, b.z)) < 48.0 || Terrain::trackDist(b.x, b.z) < 22.0) return false;
    if (Road::clearance(b.x, b.z) < expectClear - 3.5f) return false;                          // another road comes closer than the one we stand beside
    const float cr = std::cos(b.rot), sr = std::sin(b.rot); float lo = 1e9f, hi = -1e9f, sum = 0; int n = 0;
    const float xs[3] = {-b.hx, 0.f, b.hx}, zs[3] = {b.zMin, 0.5f * (b.zMin + b.zMax), b.zMax};
    for (float lx : xs) for (float lz : zs){
        const float wx = b.x + cr * lx + sr * lz, wz = b.z - sr * lx + cr * lz;
        if (std::fabs(River::riverSd(wx, wz)) < 40.0 || Road::clearance(wx, wz) < 5.5f) return false;   // no corner on the road / its verge
        const float h = groundAt(wx, wz); lo = std::min(lo, h); hi = std::max(hi, h); sum += h; n++;
    }
    if (hi - lo > (b.type == CHURCH ? 2.4f : 1.5f)) return false;
    gy = sum / n; return true;
}

static bool overlaps(const Building& a, float gap){
    for (const Building& b : gB){
        const float dx = a.x - b.x, dz = a.z - b.z, r = (a.type == CHURCH ? 15.f : 8.5f) * a.scale + (b.type == CHURCH ? 15.f : 8.5f) * b.scale;
        if (dx*dx + dz*dz < (r - gap) * (r - gap)) return true;
    }
    return false;
}

// lay the village out along `cv` starting at arc fraction u0; returns how many houses fit (placed into out)
static int layout(const Road::Curve& cv, double u0, uint32_t seed, std::vector<Building>& out){
    gB.clear();
    std::mt19937 rng(seed); auto U = [&]{ return std::uniform_real_distribution<float>(0.f, 1.f)(rng); };
    const double len = cv.length(), hw = cv.hw; const int SLOTS = 8; const double STEP = 16.0;
    int placed = 0; bool churchDone = false;
    const int churchSlot = 3, churchSide = (seed & 1) ? 1 : -1;
    for (int i = 0; i < SLOTS; i++) for (int sd : {1, -1}){
        const bool isChurch = (i == churchSlot && sd == churchSide);
        if (sd == churchSide && (i == churchSlot - 1 || i == churchSlot + 1) ) continue;             // the church needs the room of its neighbours
        const double s = (u0 * len + i * STEP + (sd > 0 ? 0.0 : STEP * 0.5) + (U() - 0.5) * 3.0) / len;
        const Road::V3 p = cv.getPointAt(std::fmod(s, 1.0)), tg = cv.getTangentAt(std::fmod(s, 1.0));
        const double tl = std::hypot(tg.x, tg.z); if (tl < 1e-6) continue;
        const double nx = -tg.z / tl, nz = tg.x / tl;                                                    // left normal of the road
        Building b; b.type = isChurch ? CHURCH : CHALET; b.scale = isChurch ? 1.0f : 0.95f + 0.2f * U(); b.ws = isChurch ? 1.f : 0.9f + 0.4f * U();
        b.var = U(); footprint(b);
        // distance of the house's centre from the road centre line: front edge (balcony / steps) ends ~8 m from the tarmac edge
        const double frontReach = isChurch ? b.zMax : b.zMax + 0.6;
        const double off = hw + (isChurch ? 11.0 : 8.0) + frontReach + (isChurch ? 0.0 : U() * 2.5);
        b.x = (float)(p.x + nx * sd * off); b.z = (float)(p.z + nz * sd * off);
        const double fx = -nx * sd, fz = -nz * sd;                                                       // front of the house points to the road
        b.rot = (float)std::atan2(fx, fz) + (isChurch ? 0.f : (U() - 0.5f) * 0.10f);
        float gy; if (!siteOk(b, (float)(off - hw), gy)) continue;
        if (overlaps(b, 1.5f)) continue;
        b.y = gy; out.push_back(b); gB.push_back(b); placed++; if (isChurch) churchDone = true;
    }
    return churchDone ? placed : 0;                                                                       // no church, no village
}

static void plan(){
    if (gPlanned) return; gPlanned = true; gB.clear();
    std::vector<Building> best; int bestN = 0;
    const Road::Curve* rings[2] = {&Road::gNet.A, &Road::gNet.B};
    for (int attempt = 0; attempt < 2 && bestN < 13; attempt++){
        for (int ri = 0; ri < 2 && bestN < 13; ri++){
            const Road::Curve& cv = *rings[ri]; const double len = cv.length(), span = (8 * 16.0 + 20.0) / len;
            for (int k = 0; k < 60 && bestN < 13; k++){
                const double u0 = 0.12 + (0.76 - span) * (double)((k * 37) % 60) / 60.0;                 // never across the start line (u = 0)
                std::vector<Building> out; const int n = layout(cv, u0, 7001u + (uint32_t)(attempt * 2 + (k & 1)), out);
                if (n > bestN){ bestN = n; best = out; }
            }
        }
    }
    gB = best;
}

// ---------- the houses are solid ----------
// the car body is 3 circles along its length; each is pushed out of the house's footprint (a rectangle in the house's own frame)
static void collide(CarState& S){
    if (gB.empty()) return;
    const double sH = std::sin(S.heading), cH = std::cos(S.heading), R = 1.05; static const double OFS[3] = {-1.5, 0.0, 1.5};
    for (const Building& b : gB){
        const double dx = b.x - S.x, dz = b.z - S.z; if (dx*dx + dz*dz > 32.0 * 32.0) continue;
        for (double o : OFS){
            const float px = (float)(S.x + sH * o), pz = (float)(S.z + cH * o); float lx, lz; toLocal(b, px, pz, lx, lz);
            const float cx = std::max(-b.hx, std::min(b.hx, lx)), cz = std::max(b.zMin, std::min(b.zMax, lz)), vx = lx - cx, vz = lz - cz; float nlx, nlz, pen;
            const float d = std::sqrt(vx*vx + vz*vz);
            if (d > 1e-4f){ if (d >= R) continue; nlx = vx / d; nlz = vz / d; pen = (float)R - d; }
            else {                                                                                        // centre is inside the footprint: leave through the nearest side
                const float e[4] = {b.hx - lx, lx + b.hx, b.zMax - lz, lz - b.zMin}; int k = 0; for (int j = 1; j < 4; j++) if (e[j] < e[k]) k = j;
                nlx = (k == 0) ? 1.f : (k == 1 ? -1.f : 0.f); nlz = (k == 2) ? 1.f : (k == 3 ? -1.f : 0.f); pen = e[k] + (float)R;
            }
            float wx, wz; toWorldDir(b, nlx, nlz, wx, wz);
            S.x += wx * pen; S.z += wz * pen;
            Fence::bounceOff(S, wx, wz, 0.22, 0.30);
        }
    }
}

} // namespace Village
