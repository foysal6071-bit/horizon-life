#pragma once
// Sunny Drift - the HTML "makeGrassTexture()" (256 px tile: pale base, soft patches, 5200 blades, specks) painted on the CPU.
// The ground / hills multiply their vertex colour by it (HTML: MeshLambertMaterial map x vertexColors, repeat 500 over 2000 m = one tile per 4 m).
#include "bridge.h"
namespace Bridge {
static void hsl2rgb(double h, double s, double l, double& r, double& g, double& b){      // h in degrees, s / l 0..1 -> 0..255
    auto f = [&](double n){ const double k = std::fmod(n + h / 30.0, 12.0), a = s * std::min(l, 1 - l); return 255.0 * (l - a * std::max(-1.0, std::min(std::min(k - 3, 9 - k), 1.0))); };
    r = f(0); g = f(8); b = f(4);
}
static void strokeLine(Img& im, double x0, double y0, double x1, double y1, double w, double r, double g, double b, double a){   // anti-aliased thick segment, wraps around the tile
    const double dx = x1 - x0, dy = y1 - y0, L2 = std::max(dx*dx + dy*dy, 1e-9), hw = w / 2 + 0.5;
    for (int yy = (int)std::floor(std::min(y0, y1) - hw); yy <= (int)std::ceil(std::max(y0, y1) + hw); yy++)
        for (int xx = (int)std::floor(std::min(x0, x1) - hw); xx <= (int)std::ceil(std::max(x0, x1) + hw); xx++){
            const double px = xx + .5, py = yy + .5, t = std::min(1.0, std::max(0.0, ((px - x0)*dx + (py - y0)*dy) / L2));
            const double d = std::hypot(px - (x0 + dx*t), py - (y0 + dy*t)), cov = std::min(1.0, std::max(0.0, w / 2 + 0.5 - d));
            if (cov > 0) blendPx(im, xx, yy, r, g, b, a * cov);
        }
}
static Img makeGrassTex(){
    // dense short lawn like a close-up photo: dark soil-shadow under-layer, then thousands of FINE tapered blades (dark root -> lime tip), standing up
    // with a slight lean, in many fresh green shades, plus soft swaths of flattened / lit grass. 512 px tile (the shader samples it at 4 m, ~0.9 m and ~0.2 m
    // per tile, so the same tile reads as long swaths far away and as individual small blades close up).
    const int W = 512; Img im(W, W);
    fillRect(im, 0, 0, W, W, 0x7e, 0xa0, 0x4c, 1);
    for (int i = 0; i < 90; i++){                                                // large soft swaths (flattened / lit grass)
        const bool dark = rnd01() < 0.5; const double a = 0.07 + rnd01() * 0.09, x = rnd01() * W, y = rnd01() * W, r = 22 + rnd01() * 60;
        disc(im, x, y, r, dark ? 55 : 225, dark ? 100 : 245, dark ? 28 : 120, a);
    }
    // a blade = 3 tapered segments, colour from dark at the root to bright at the tip
    auto blade = [&](double x, double y, double h, double lean, double w, double hue, double sat, double l0, double l1, double al){
        double px = x, py = y;
        for (int k = 0; k < 3; k++){
            const double t0 = k / 3.0, t1 = (k + 1) / 3.0, t = (t0 + t1) / 2;
            const double nx = x + lean * t1 * t1, ny = y - h * t1;                  // curved: the tip leans over a little more
            double r, g, b; hsl2rgb(hue, sat, l0 + (l1 - l0) * t, r, g, b);
            strokeLine(im, px, py, nx, ny, std::max(0.55, w * (1.0 - 0.75 * t)), r, g, b, al);
            px = nx; py = ny;
        }
    };
    for (int i = 0; i < 16000; i++){                                             // shadowed under-layer
        const double h = 7 + rnd01() * 14;
        blade(rnd01() * W, rnd01() * W, h, (rnd01() - 0.5) * 6, 1.5 + rnd01() * 0.8, 90 + rnd01() * 22, (40 + rnd01() * 22) / 100, 0.22, 0.38, 0.85);
    }
    for (int i = 0; i < 42000; i++){                                             // main blades: thin, upright, fresh green -> lime
        const double h = 9 + rnd01() * 18;
        blade(rnd01() * W, rnd01() * W, h, (rnd01() - 0.5) * 8, 1.1 + rnd01() * 0.7, 72 + rnd01() * 40, (50 + rnd01() * 28) / 100, 0.34 + rnd01() * 0.08, 0.58 + rnd01() * 0.20, 0.55 + rnd01() * 0.40);
    }
    for (int i = 0; i < 600; i++){                                              // sun-glints on a few blade tips
        const double x = rnd01() * W, y = rnd01() * W; fillRect(im, x, y, 1, 1 + rnd01() * 2, 215, 238, 120, 0.22);
    }
    return im;
}
}
