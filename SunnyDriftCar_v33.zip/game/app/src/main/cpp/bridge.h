// Sunny Drift - wooden river bridges: C++ port of the HTML "Deep river with real bridges" block (pure C++, no OpenGL).
//  * buildBridges(curve) lofts the deck, plank roadway, dirt layers, road-blend patches, stringers, kerbs, rails along the road
//    centre line exactly like the HTML (same offsets, heights, arch, repeat counts), then fence posts, cross beams and pile bents
//  * the three procedural textures (planks, timber, dragged-in dirt) are rasterised here the same way the HTML paints its canvases
//  * bridgeLift()/riverCollide() are the HTML physics hooks: deck height + slope under the car, rails, river walls
#pragma once
#include "road.h"
#include "car_core.h"
#include <random>

namespace Bridge {
using Road::V3; using Road::Curve;

static const double BRIDGE_RISE = 1.2;                       // metres at mid-span
static inline double bsm(double x){ x = std::min(1.0, std::max(0.0, x)); return x*x*(3 - 2*x); }
static inline double bridgeArch(double f){ double q = std::sin(Road::PI * std::min(std::max(f, 0.0), 1.0)); return BRIDGE_RISE * q * q; }
static inline double bridgeArchD(double f){ return BRIDGE_RISE * Road::PI * std::sin(2 * Road::PI * std::min(std::max(f, 0.0), 1.0)); }

// vertex = pos(3) uv(2) normal(3) alpha(1)
struct BMesh { std::vector<float> v; std::vector<uint32_t> idx; };
enum { M_DECK, M_TOP, M_DIRT, M_DIRTEND, M_BLEND, M_BEAM, M_POST, M_COUNT };
static BMesh gMesh[M_COUNT];

struct Pt { double x, z, tx, tz, h, sl; };
struct B { std::vector<Pt> pts; double clampW, capW, cx, cz, r2; };
static std::vector<B> gBridges;
static B* gCur = nullptr;

struct StrProf { double o, y, u; };
typedef double (*LiftFn)(double);

// generic strip along the centre line (buildStrip in the HTML). Normals = computeVertexNormals (NOT forced upwards: the materials are double sided)
template <class LF, class AF>
static void strip(BMesh& m, const Curve& curve, int N, const std::vector<StrProf>& prof, double vRepeat, double t0, double t1, LF lift, AF alphaFn, bool useAlpha){
    const int P = (int)prof.size(); const uint32_t base = (uint32_t)(m.v.size() / 9);
    const int nv = (N + 1) * P; std::vector<double> pos(nv * 3), nor(nv * 3, 0.0); std::vector<float> uv(nv * 2), al(nv, 1.f);
    for (int i = 0; i <= N; i++){
        const double t = std::fmod(std::fmod(t0 + (t1 - t0) * i / N, 1.0) + 1.0, 1.0);
        V3 p = curve.getPointAt(t), tan = curve.getTangentAt(t);
        double nl = std::hypot(tan.x, tan.z); if (nl == 0) nl = 1; const double ux = -tan.z / nl, uz = tan.x / nl;
        for (int j = 0; j < P; j++){
            const int k = i * P + j;
            pos[k*3] = p.x + ux * prof[j].o; pos[k*3+1] = prof[j].y + lift((double)i / N); pos[k*3+2] = p.z + uz * prof[j].o;
            uv[k*2] = (float)prof[j].u; uv[k*2+1] = (float)((double)i / N * vRepeat);
            if (useAlpha) al[k] = (float)alphaFn((double)i / N, j);
        }
    }
    std::vector<uint32_t> idx;
    for (int i = 0; i < N; i++) for (int j = 0; j < P - 1; j++){ uint32_t a = i*P + j, b = (i+1)*P + j; uint32_t t[6] = {a, b, a+1, a+1, b, b+1}; idx.insert(idx.end(), t, t + 6); }
    for (size_t f = 0; f < idx.size(); f += 3){
        const double *A = &pos[idx[f]*3], *Bv = &pos[idx[f+1]*3], *C = &pos[idx[f+2]*3];
        const double cb[3] = {C[0]-Bv[0], C[1]-Bv[1], C[2]-Bv[2]}, ab[3] = {A[0]-Bv[0], A[1]-Bv[1], A[2]-Bv[2]};
        const double n[3] = {cb[1]*ab[2] - cb[2]*ab[1], cb[2]*ab[0] - cb[0]*ab[2], cb[0]*ab[1] - cb[1]*ab[0]};
        for (int q = 0; q < 3; q++) for (int c = 0; c < 3; c++) nor[idx[f+q]*3 + c] += n[c];
    }
    for (int k = 0; k < nv; k++){
        double l = std::sqrt(nor[k*3]*nor[k*3] + nor[k*3+1]*nor[k*3+1] + nor[k*3+2]*nor[k*3+2]); if (l == 0) l = 1;
        const float row[9] = {(float)pos[k*3], (float)pos[k*3+1], (float)pos[k*3+2], uv[k*2], uv[k*2+1], (float)(nor[k*3]/l), (float)(nor[k*3+1]/l), (float)(nor[k*3+2]/l), al[k]};
        m.v.insert(m.v.end(), row, row + 9);
    }
    for (uint32_t i : idx) m.idx.push_back(base + i);
}
struct NoAlpha { double operator()(double, int) const { return 1; } };
struct NoLift  { double operator()(double) const { return 0; } };

// ---------- instanced parts, baked into the meshes ----------
// box (three.js BoxGeometry) of size w,h,d, rotated about Y by ry, translated; (cx,cy,cz) = local centre offset before rotation
static void addBox(BMesh& m, double w, double h, double d, double ox, double oy, double oz, double sx, double sy, double sz, double ry, double px, double py, double pz){
    const double c = std::cos(ry), s = std::sin(ry);
    auto L = [&](double x, double y, double z, float* o){                      // local -> world (scale, rotate Y, translate)
        x *= sx; y *= sy; z *= sz; o[0] = (float)(c*x + s*z + px); o[1] = (float)(y + py); o[2] = (float)(-s*x + c*z + pz); };
    auto N = [&](double x, double y, double z, float* o){ double X = c*x + s*z, Z = -s*x + c*z; o[0] = (float)X; o[1] = (float)y; o[2] = (float)Z; };
    const double hx = w/2, hy = h/2, hz = d/2;
    struct F { double nx, ny, nz; double v[4][3]; };
    const F faces[6] = {
        { 1, 0, 0, {{ hx, hy, hz}, { hx, hy,-hz}, { hx,-hy,-hz}, { hx,-hy, hz}}}, {-1, 0, 0, {{-hx, hy,-hz}, {-hx, hy, hz}, {-hx,-hy, hz}, {-hx,-hy,-hz}}},
        { 0, 1, 0, {{-hx, hy,-hz}, { hx, hy,-hz}, { hx, hy, hz}, {-hx, hy, hz}}}, { 0,-1, 0, {{-hx,-hy, hz}, { hx,-hy, hz}, { hx,-hy,-hz}, {-hx,-hy,-hz}}},
        { 0, 0, 1, {{-hx, hy, hz}, { hx, hy, hz}, { hx,-hy, hz}, {-hx,-hy, hz}}}, { 0, 0,-1, {{ hx, hy,-hz}, {-hx, hy,-hz}, {-hx,-hy,-hz}, { hx,-hy,-hz}}} };
    static const float UV[4][2] = {{0, 1}, {1, 1}, {1, 0}, {0, 0}};
    for (const F& f : faces){
        const uint32_t base = (uint32_t)(m.v.size() / 9);
        for (int q = 0; q < 4; q++){
            float p[3], n[3]; L(f.v[q][0] + ox, f.v[q][1] + oy, f.v[q][2] + oz, p); N(f.nx / sx, f.ny / sy, f.nz / sz, n);
            double nl = std::sqrt((double)n[0]*n[0] + (double)n[1]*n[1] + (double)n[2]*n[2]); if (nl == 0) nl = 1;
            const float row[9] = {p[0], p[1], p[2], UV[q][0], UV[q][1], (float)(n[0]/nl), (float)(n[1]/nl), (float)(n[2]/nl), 1.f};
            m.v.insert(m.v.end(), row, row + 9);
        }
        const uint32_t t[6] = {base, base+1, base+2, base, base+2, base+3}; m.idx.insert(m.idx.end(), t, t + 6);
    }
}
// timber pile: CylinderGeometry(0.2, 0.25, 4.4, 8), centred at (px,py,pz), y scaled by sy
static void addPile(BMesh& m, double px, double py, double pz, double sy){
    const int R = 8; const double rt = 0.2, rb = 0.25, H = 4.4, slope = (rb - rt) / H;
    const uint32_t base = (uint32_t)(m.v.size() / 9);
    for (int i = 0; i <= R; i++){
        const double th = (double)i / R * 2 * Road::PI, sn = std::sin(th), cs = std::cos(th); double nx = sn, ny = slope, nz = cs, nl = std::sqrt(nx*nx + ny*ny + nz*nz);
        for (int k = 0; k < 2; k++){
            const double r = k ? rb : rt, y = (k ? -H : H) / 2 * sy;
            const float row[9] = {(float)(px + r*sn), (float)(py + y), (float)(pz + r*cs), (float)i / R, (float)k, (float)(nx/nl), (float)(ny/nl), (float)(nz/nl), 1.f};
            m.v.insert(m.v.end(), row, row + 9);
        }
    }
    for (int i = 0; i < R; i++){ const uint32_t a = base + i*2, b = a + 1, c = a + 2, d = a + 3; const uint32_t t[6] = {a, b, c, c, b, d}; m.idx.insert(m.idx.end(), t, t + 6); }
    for (int cap = 0; cap < 2; cap++){                                         // top / bottom discs
        const double y = (cap ? -H : H) / 2 * sy, r = cap ? rb : rt, ny = cap ? -1 : 1; const uint32_t c0 = (uint32_t)(m.v.size() / 9);
        { const float row[9] = {(float)px, (float)(py + y), (float)pz, 0.5f, 0.5f, 0, (float)ny, 0, 1.f}; m.v.insert(m.v.end(), row, row + 9); }
        for (int i = 0; i <= R; i++){ const double th = (double)i / R * 2 * Road::PI; const float row[9] = {(float)(px + r*std::sin(th)), (float)(py + y), (float)(pz + r*std::cos(th)), (float)(0.5 + 0.5*std::sin(th)), (float)(0.5 + 0.5*std::cos(th)), 0, (float)ny, 0, 1.f}; m.v.insert(m.v.end(), row, row + 9); }
        for (int i = 0; i < R; i++){ const uint32_t t[3] = {c0, c0 + 1 + i + (cap ? 1 : 0), c0 + 1 + i + (cap ? 0 : 1)}; m.idx.insert(m.idx.end(), t, t + 3); }
    }
}

// ---------- the bridge itself (buildBridges in the HTML) ----------
static void build(const Curve& curve){
    const double hw = curve.hw, len = curve.length(); const int S = (int)std::ceil(len / 1.2);
    std::vector<char> inside; for (int i = 0; i < S; i++){ V3 p = curve.getPointAt((double)i / S); inside.push_back(std::fabs(River::riverSd(p.x, p.z)) < River::RIVER_WALL + 5); }
    int s0 = -1; for (int i = 0; i < S; i++) if (!inside[i]){ s0 = i; break; }
    if (s0 < 0) return;
    auto wrapT = [](double t){ return std::fmod(std::fmod(t, 1.0) + 1.0, 1.0); };
    int i = 0;
    while (i < S){
        if (!inside[(s0 + i) % S]){ i++; continue; }
        int j = i; while (j < S && inside[(s0 + j) % S]) j++;
        const double pad = 2 / len, t0 = (double)(s0 + i) / S - pad, t1 = (double)(s0 + j) / S + pad, L = (t1 - t0) * len; const int N = std::max(8, (int)std::ceil(L / 1.5));
        const double dw = hw + 1.8, railO = hw + 1.45;
        NoAlpha na; auto arch = [](double f){ return bridgeArch(f); };
        // deck: plank roadway with a timber fascia + the plank top
        strip(gMesh[M_DECK], curve, N, {{dw, 0.10, 0}, {dw, -0.72, 0.3}, {-dw, -0.72, 0.7}, {-dw, 0.10, 1}}, L / 2.4, t0, t1, arch, na, false);
        strip(gMesh[M_TOP], curve, N, {{dw, 0.115, 0}, {-dw, 0.115, 1}}, L / 2.4, t0, t1, arch, na, false);
        // dirt / sand dragged onto the bridge: thin over the span, thick for the first and last 9 m
        {
            const double E = std::min(0.45, 9 / L); const int ne = std::max(4, (int)std::ceil(9 / 1.5)); const double RMP = 3.5;
            strip(gMesh[M_DIRT], curve, N, {{hw, 0.128, 0}, {-hw, 0.128, 1}}, L / 6, t0, t1, arch, [&](double f, int){ return bsm(f * L / RMP) * bsm((1 - f) * L / RMP); }, true);
            const double fas[2][2] = {{0, E}, {1 - E, 1}};
            for (int e = 0; e < 2; e++){
                const double fa = fas[e][0], fb = fas[e][1]; const int n2 = std::max(4, (int)std::ceil(ne * E * L / 9)); const bool first = fa == 0;
                strip(gMesh[M_DIRTEND], curve, n2, {{hw, 0.134, 0}, {-hw, 0.134, 1}}, E * L / 6, t0 + (t1 - t0) * fa, t0 + (t1 - t0) * fb,
                      [&](double f){ return bridgeArch(fa + (fb - fa) * f); }, [&](double f, int){ const double o = first ? f : 1 - f; return bsm(o * E * L / RMP); }, true);
            }
            // blend patch (road earth over the planks): 3 m onto the road, solid across the mouth, then 5.5 m fading away over the wood
            const double DO = 3, DS = 2.5, DF = 5.5, PL = DO + DS + DF; const int np = (int)std::ceil(PL / 0.75); const double ph = hw - 1.4;
            const double pw[4] = {hw, ph, -ph, -hw}; std::vector<StrProf> prof; for (int q = 0; q < 4; q++) prof.push_back({pw[q], 0.122, (pw[q] + hw) / (2 * hw)});
            for (int side = 0; side < 2; side++){
                const double fa = side ? 1 - (DS + DF) / L : -DO / L, fb = side ? 1 + DO / L : (DS + DF) / L, tt0 = t0 + (t1 - t0) * fa, tt1 = t0 + (t1 - t0) * fb;
                strip(gMesh[M_BLEND], curve, np, prof, PL / 8, tt0, tt1, [&](double f){ return bridgeArch(fa + (fb - fa) * f); },
                      [&](double f, int jj){ const double d = (side ? 1 - f : f) * PL; return (jj == 0 || jj == 3 ? 0.0 : 1.0) * (d < DO ? bsm(d / DO) : d < DO + DS ? 1.0 : 1 - bsm((d - DO - DS) / DF)); }, true);
            }
        }
        // 3 lengthwise stringers under the deck
        for (double c : {-hw * 0.55, 0.0, hw * 0.55}) strip(gMesh[M_BEAM], curve, N, {{c + .17, -0.1, 0}, {c + .17, -0.95, .3}, {c - .17, -0.95, .7}, {c - .17, -0.1, 1}}, L / 3, t0, t1, arch, na, false);
        for (int sd : {-1, 1}){
            const double k0 = sd * (hw + 0.05), k1 = sd * (hw + 0.42);                                     // wheel kerb
            strip(gMesh[M_BEAM], curve, N, {{k0, 0.10, 0}, {k0, 0.36, .3}, {k1, 0.36, .7}, {k1, 0.10, 1}}, L / 3, t0, t1, arch, na, false);
            const double rails[2][2] = {{0.93, 1.09}, {0.50, 0.62}};                                       // top handrail + mid rail
            for (auto& r : rails){
                const double a = sd * (railO - 0.07), b = sd * (railO + 0.07);
                strip(gMesh[M_BEAM], curve, N, {{a, r[0], 0}, {a, r[1], .3}, {b, r[1], .7}, {b, r[0], 1}}, L / 3, t0, t1, arch, na, false);
            }
        }
        // centre-line samples for the collision code
        B br; br.clampW = hw - 0.2; br.capW = hw + 1.0;
        for (int k = 0; k <= N; k++){
            const double t = wrapT(t0 + (t1 - t0) * k / N); V3 p = curve.getPointAt(t), tn = curve.getTangentAt(t); double nl = std::hypot(tn.x, tn.z); if (nl == 0) nl = 1;
            br.pts.push_back({p.x, p.z, tn.x / nl, tn.z / nl, bridgeArch((double)k / N), bridgeArchD((double)k / N) / L});
        }
        const Pt mid = br.pts[br.pts.size() >> 1]; double R = 0; for (const Pt& q : br.pts) R = std::max(R, std::hypot(q.x - mid.x, q.z - mid.z));
        br.cx = mid.x; br.cz = mid.z; br.r2 = (R + hw + 4) * (R + hw + 4); gBridges.push_back(br);
        // fence posts every 3 m, cross beams under the deck every 3 m, pile bents (4 timber piles + cap beam) every 9 m where there is water
        for (double d = 0; d <= L; d += 3){
            const double t = wrapT(t0 + d / len); V3 p = curve.getPointAt(t), tn = curve.getTangentAt(t); double nl = std::hypot(tn.x, tn.z); if (nl == 0) nl = 1;
            const double tx = tn.x / nl, tz = tn.z / nl, nx = -tz, nz = tx, ry = std::atan2(tx, tz);
            for (int sd : {-1, 1}) addBox(gMesh[M_POST], 0.2, 1.2, 0.2, 0, 0.7, 0, 1, 1, 1, ry, p.x + nx * sd * railO, bridgeArch(d / L), p.z + nz * sd * railO);
            addBox(gMesh[M_BEAM], 2, 0.26, 0.34, 0, 0, 0, dw, 1, 1, ry, p.x, -0.52 + bridgeArch(d / L), p.z);
        }
        for (double d = 3; d <= L; d += 9){
            const double t = wrapT(t0 + d / len); V3 p = curve.getPointAt(t), tn = curve.getTangentAt(t); double nl = std::hypot(tn.x, tn.z); if (nl == 0) nl = 1;
            if (std::fabs(River::riverSd(p.x, p.z)) > River::RIVER_WALL - 2) continue;
            const double tx = tn.x / nl, tz = tn.z / nl, nx = -tz, nz = tx, ry = std::atan2(tx, tz);
            addBox(gMesh[M_BEAM], 2, 0.26, 0.34, 0, 0, 0, dw, 1.25, 1.25, ry, p.x, -0.98 + bridgeArch(d / L), p.z);
            const double h = bridgeArch(d / L);
            for (double o : {-(dw - .5), -dw * .33, dw * .33, dw - .5}) addPile(gMesh[M_BEAM], p.x + nx * o, -2.75 + h / 2, p.z + nz * o, (4.4 + h) / 4.4);
        }
        i = j;
    }
}

// ---------- procedural textures (RGBA8, straight alpha), painted like the HTML canvases ----------
struct Img { int w, h; std::vector<uint8_t> px; Img(int W, int H) : w(W), h(H), px((size_t)W * H * 4, 0) {} };
static std::mt19937 gR(777);
static double rnd01(){ return std::uniform_real_distribution<double>(0.0, 1.0)(gR); }
static void blendPx(Img& im, int x, int y, double r, double g, double b, double a){
    x = ((x % im.w) + im.w) % im.w; y = ((y % im.h) + im.h) % im.h; uint8_t* p = &im.px[((size_t)y * im.w + x) * 4];
    for (int c = 0; c < 3; c++){ const double src = c == 0 ? r : c == 1 ? g : b; p[c] = (uint8_t)std::min(255.0, std::max(0.0, p[c] * (1 - a) + src * a)); } p[3] = 255;
}
static void fillRect(Img& im, double x, double y, double w, double h, double r, double g, double b, double a){
    for (int yy = (int)std::floor(y); yy < (int)std::ceil(y + h); yy++) for (int xx = (int)std::floor(x); xx < (int)std::ceil(x + w); xx++) blendPx(im, xx, yy, r, g, b, a);
}
static void disc(Img& im, double cx, double cy, double rad, double r, double g, double b, double a){
    for (int yy = (int)std::floor(cy - rad); yy <= (int)std::ceil(cy + rad); yy++) for (int xx = (int)std::floor(cx - rad); xx <= (int)std::ceil(cx + rad); xx++)
        if ((xx + .5 - cx)*(xx + .5 - cx) + (yy + .5 - cy)*(yy + .5 - cy) <= rad * rad) blendPx(im, xx, yy, r, g, b, a);
}
static void lineSeg(Img& im, double x0, double y0, double x1, double y1, double lw, double r, double g, double b, double a){
    const double L = std::hypot(x1 - x0, y1 - y0); const int n = std::max(1, (int)(L / 0.5));
    for (int i = 0; i <= n; i++) disc(im, x0 + (x1 - x0) * i / n, y0 + (y1 - y0) * i / n, std::max(0.5, lw / 2), r, g, b, a);
}
static void bezier(Img& im, double x0, double y0, double x1, double y1, double x2, double y2, double x3, double y3, double lw, double r, double g, double b, double a){
    double px = x0, py = y0;
    for (int i = 1; i <= 16; i++){ const double t = i / 16.0, u = 1 - t;
        const double x = u*u*u*x0 + 3*u*u*t*x1 + 3*u*t*t*x2 + t*t*t*x3, y = u*u*u*y0 + 3*u*u*t*y1 + 3*u*t*t*y2 + t*t*t*y3;
        lineSeg(im, px, py, x, y, lw, r, g, b, a); px = x; py = y; }
}
static void ellipseStroke(Img& im, double cx, double cy, double rx, double ry, double lw, double r, double g, double b, double a){
    double px = cx + rx, py = cy;
    for (int i = 1; i <= 24; i++){ const double th = i / 24.0 * 2 * Road::PI, x = cx + rx * std::cos(th), y = cy + ry * std::sin(th); lineSeg(im, px, py, x, y, lw, r, g, b, a); px = x; py = y; }
}
// plank roadway: 8 boards across the tile, grain, gaps, nails, knots
static Img makeWoodTex(){
    const int W = 256, PL = 8, ph = W / PL; Img im(W, W);
    for (int i = 0; i < PL; i++){
        const double b = 0.80 + rnd01() * 0.30, y = i * ph;
        fillRect(im, 0, y, W, ph, std::round(98 * b), std::round(68 * b), std::round(44 * b), 1);
        for (int k = 0; k < 26; k++){
            const bool dark = rnd01() < .5; const double a = 0.10 + rnd01() * 0.18, lw = 0.6 + rnd01() * 1.2, yy = y + 2 + rnd01() * (ph - 4);
            bezier(im, 0, yy, W * .3, yy + (rnd01() - .5) * 3, W * .7, yy + (rnd01() - .5) * 3, W, yy + (rnd01() - .5) * 2, lw, dark ? 45 : 140, dark ? 28 : 100, dark ? 16 : 66, a);
        }
        fillRect(im, 0, y, W, 1.6, 25, 15, 8, 0.85);                                   // gap between boards
        for (double nx : {10.0, W - 10.0}) disc(im, nx, y + ph / 2.0, 1.6, 30, 20, 12, 0.7);   // nails
        const double kx = 20 + rnd01() * (W - 40); ellipseStroke(im, kx, y + ph * .5, 5, 2.2, 1.2, 40, 25, 14, 0.5);   // knot
    }
    return im;
}
// timber beams / posts / piles: vertical grain, dark, weathered
static Img makeBeamTex(){
    const int W = 128; Img im(W, W); fillRect(im, 0, 0, W, W, 0x5a, 0x3f, 0x28, 1);
    for (int i = 0; i < 150; i++){
        const double x = rnd01() * W; const bool dark = rnd01() < .55; const double a = 0.10 + rnd01() * 0.22, lw = 0.5 + rnd01() * 1.8;
        bezier(im, x, 0, x + (rnd01() - .5) * 6, W * .3, x + (rnd01() - .5) * 6, W * .7, x + (rnd01() - .5) * 4, W, lw, dark ? 32 : 135, dark ? 20 : 98, dark ? 11 : 64, a);
    }
    for (int i = 0; i < 5; i++) ellipseStroke(im, 12 + rnd01() * (W - 24), rnd01() * W, 3.2, 6, 1.3, 30, 18, 10, 0.45);
    for (int i = 0; i < 260; i++){ const bool dark = rnd01() < .5; const double a = 0.05 + rnd01() * 0.10; fillRect(im, rnd01() * W, rnd01() * W, 1 + rnd01() * 3, 1 + rnd01() * 3, dark ? 20 : 110, dark ? 14 : 92, dark ? 8 : 60, a); }
    return im;
}
// dirt that cars dragged onto the planks (makeBridgeDirtTex): heavy along both edges, thin between the wheel tracks
static inline double hsh(int x, int y, int sd){
    int32_t h = (int32_t)((uint32_t)((int64_t)x * 374761393LL + (int64_t)y * 668265263LL + (int64_t)sd * 2147483647LL));
    h = (int32_t)((uint32_t)(h ^ (int32_t)((uint32_t)h >> 13)) * 1274126177u); return (double)((uint32_t)(h ^ (int32_t)((uint32_t)h >> 16))) / 4294967295.0;
}
static inline double vn(double x, double y, int px, int py, int sd){
    const double xi = std::floor(x), yi = std::floor(y), fx = bsm(x - xi), fy = bsm(y - yi);
    auto g2 = [&](int i, int j){ return hsh(((i % px) + px) % px, ((j % py) + py) % py, sd); };
    const int ix = (int)xi, iy = (int)yi; const double a0 = g2(ix, iy), b0 = g2(ix + 1, iy), a1 = g2(ix, iy + 1), b1 = g2(ix + 1, iy + 1);
    return (a0 + (b0 - a0) * fx) * (1 - fy) + (a1 + (b1 - a1) * fx) * fy;
}
static Img makeDirtTex(bool heavy){
    const int W = 256, H = 256; Img im(W, H);
    const double A[3] = {0x62, 0x50, 0x3f}, Bc[3] = {0x7c, 0x66, 0x49}, C[3] = {0x70, 0x5f, 0x44};
    for (int y = 0; y < H; y++) for (int x = 0; x < W; x++){
        const double u = (double)x / W, v = (double)y / H; uint8_t* o = &im.px[((size_t)y * W + x) * 4];
        const double nLow = vn(u*5, v*4, 5, 4, 1), nMid = vn(u*14, v*7, 14, 7, 2), nStr = vn(u*40, v*3, 40, 3, 3), nFine = hsh(x, y, 9);
        const double e = std::min(u, 1 - u) + (nLow - 0.5) * 0.20 + (nMid - 0.5) * 0.07;
        double den = std::max(0.0, 1 - e / 0.28); den = den * den * (3 - 2 * den);
        den *= 0.65 + 0.7 * nMid + 0.35 * (nStr - 0.5);
        const double mid = (heavy ? 0.55 : 0.22) * std::max(0.0, nLow * 1.2 + nStr * 0.5 - 0.55);
        const double trk = std::max(std::exp(-std::pow((u - 0.30) / 0.07, 2)), std::exp(-std::pow((u - 0.70) / 0.07, 2)));
        const double t = den * (heavy ? 1.35 : 1) + mid * (1 - 0.55 * trk) - 0.18 * trk;
        const double al = std::min(1.0, std::max(0.0, (t - 0.05) / 0.75)), alpha = al * al * (3 - 2 * al);
        const double k = nLow * 0.6 + nMid * 0.4, j = (nFine - 0.5) * 10;
        for (int c = 0; c < 3; c++){ const double m = k < 0.5 ? A[c] + (Bc[c] - A[c]) * bsm(k * 2) : Bc[c] + (C[c] - Bc[c]) * bsm((k - 0.5) * 2); o[c] = (uint8_t)std::min(255.0, std::max(0.0, m + j)); }
        o[3] = (uint8_t)(255 * std::min(0.92, alpha * (heavy ? 1.0 : 0.9)));
    }
    return im;
}

static bool ready = false;
static void init(){
    if (ready) return; ready = true;
    Road::init();
    build(Road::gNet.A); build(Road::gNet.B); build(Road::gNet.D);        // the connectors never cross a river
}

// ---------- physics hooks ----------
struct Loc { int i; const Pt* q; double al, ac; };
static Loc local(const B& b, double x, double z){
    int bi = 0; double bd = 1e18;
    for (size_t i = 0; i < b.pts.size(); i++){ const double dx = x - b.pts[i].x, dz = z - b.pts[i].z, d = dx*dx + dz*dz; if (d < bd){ bd = d; bi = (int)i; } }
    const Pt& q = b.pts[bi]; const double dx = x - q.x, dz = z - q.z;
    return {bi, &q, dx * q.tx + dz * q.tz, -dx * q.tz + dz * q.tx};
}
static double gS = 0, gTx = 0, gTz = 0;           // slope per metre along the road direction, road direction, left by lift()
static double lift(double x, double z, double lat = 0){
    gS = 0;
    for (const B& b : gBridges){
        const double dx = x - b.cx, dz = z - b.cz; if (dx*dx + dz*dz > b.r2) continue;
        const Loc l = local(b, x, z); const int n = (int)b.pts.size(), i = l.i;
        if ((i == 0 && l.al < 0) || (i == n - 1 && l.al > 0)) continue;
        if (std::fabs(l.ac) > (lat != 0 ? lat : b.capW)) continue;
        const int j = l.al >= 0 ? std::min(i + 1, n - 1) : std::max(i - 1, 0); const Pt &q = b.pts[i], &r = b.pts[j];
        double seg = std::hypot(r.x - q.x, r.z - q.z); if (seg == 0) seg = 1; const double u = std::min(1.0, std::fabs(l.al) / seg);
        gS = q.sl + (r.sl - q.sl) * u; gTx = q.tx; gTz = q.tz; return q.h + (r.h - q.h) * u;
    }
    return 0;
}
static double reach(const CarState& c, double tx, double tz){
    const double sH = std::sin(c.heading), cH = std::cos(c.heading), cc = std::fabs(sH * tx + cH * tz), sn = std::fabs(sH * tz - cH * tx);
    return 1.05 * cc + 2.4 * sn;
}
static void dampVel(CarState& c, double k){ c.speed *= k; c.vy *= k; c.yaw *= std::sqrt(k); }
// invisible walls: nobody can leave a bridge sideways or drive into the river (riverCollide in the HTML)
static void collide(CarState& c){
    double& px = c.x; double& pz = c.z;
    if (gCur){
        const B& b = *gCur; const Loc l = local(b, px, pz); const int n = (int)b.pts.size();
        const bool beyond = (l.i == 0 && l.al < 0) || (l.i == n - 1 && l.al > 0);
        if (!beyond){
            const double lim = std::max(0.0, std::min(b.clampW, b.clampW + 1.5 - reach(c, l.q->tx, l.q->tz)));
            if (std::fabs(l.ac) > lim){
                const double sg = l.ac < 0 ? -1 : 1, nac = sg * lim; px += (nac - l.ac) * (-l.q->tz); pz += (nac - l.ac) * l.q->tx;
                const double sH = std::sin(c.heading), cH = std::cos(c.heading);
                double wx = c.speed * sH + c.vy * cH, wz = c.speed * cH - c.vy * sH;
                const double nx = -l.q->tz * sg, nz = l.q->tx * sg, vn2 = wx * nx + wz * nz;
                if (vn2 > 0){ wx -= 1.15 * vn2 * nx; wz -= 1.15 * vn2 * nz; c.speed = wx * sH + wz * cH; c.vy = wx * cH - wz * sH; }
                dampVel(c, 0.97);
            }
            return;
        }
        gCur = nullptr;
    }
    for (B& b : gBridges){
        const Loc l = local(b, px, pz); const int n = (int)b.pts.size();
        const bool beyond = (l.i == 0 && l.al < 0) || (l.i == n - 1 && l.al > 0);
        if (!beyond && std::fabs(l.ac) < b.capW){ gCur = &b; return; }
        if (!beyond){   // alongside the bridge, outside its rails
            const double out = b.clampW + 1.65 + 0.12 + reach(c, l.q->tx, l.q->tz);
            if (std::fabs(l.ac) < out){ const double nac = (l.ac < 0 ? -1.0 : 1.0) * out; px += (nac - l.ac) * (-l.q->tz); pz += (nac - l.ac) * l.q->tx; dampVel(c, 0.97); }
        }
    }
    const double sd = River::riverSd(px, pz);
    if (std::fabs(sd) < River::RIVER_WALL){
        const double target = (sd >= 0 ? 1 : -1) * River::RIVER_WALL; px += (target - sd) * River::gGx; pz += (target - sd) * River::gGz; dampVel(c, 0.96);
    }
}

} // namespace Bridge
