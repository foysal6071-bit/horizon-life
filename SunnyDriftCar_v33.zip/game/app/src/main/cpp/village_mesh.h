// Sunny Drift - procedural models of the Swiss village (pure C++, no OpenGL): the wooden chalet and the church with its pointed spire.
//  Both are built once into one static vertex buffer each and drawn with instancing (village_render.h).
//  Vertex = position(3) normal(3) colour(3) material(1). Units are metres; the model's FRONT is +Z, the ground is y = 0.
//  material: 0 plain colour, 1 wood logs (tinted per house), 2 stone, 3 roof shingle / tile, 4 window glass, 5 shutters (accent colour per house), 6 plaster
#pragma once
#include <cmath>
#include <cstdint>
#include <vector>

namespace VillageMesh {

struct P3 { float x, y, z; };
static inline P3 operator+(P3 a, P3 b){ return {a.x + b.x, a.y + b.y, a.z + b.z}; }
static inline P3 operator-(P3 a, P3 b){ return {a.x - b.x, a.y - b.y, a.z - b.z}; }
static inline P3 operator-(P3 a){ return {-a.x, -a.y, -a.z}; }
static inline P3 operator*(P3 a, float k){ return {a.x * k, a.y * k, a.z * k}; }
static inline float dot(P3 a, P3 b){ return a.x * b.x + a.y * b.y + a.z * b.z; }
static inline P3 cross(P3 a, P3 b){ return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x}; }
static inline P3 norm(P3 a){ const float l = std::sqrt(dot(a, a)); return l > 1e-9f ? a * (1.f / l) : P3{0, 1, 0}; }

struct Col { float r, g, b; };
struct Mesh { std::vector<float> v; std::vector<uint16_t> i; int count() const { return (int)v.size() / 10; } };

// ---------- palette ----------
static const Col STONE  = {0.56f, 0.54f, 0.50f}, WOOD   = {0.50f, 0.31f, 0.16f}, WOOD_D = {0.36f, 0.22f, 0.12f}, WOOD_L = {0.62f, 0.42f, 0.24f};
static const Col ROOF   = {0.46f, 0.35f, 0.27f}, TILE   = {0.68f, 0.26f, 0.17f}, SLATE  = {0.23f, 0.26f, 0.32f};
static const Col GLASS  = {0.20f, 0.26f, 0.34f}, WHITE  = {0.93f, 0.91f, 0.85f}, PLASTER = {0.94f, 0.92f, 0.86f}, DARK = {0.07f, 0.06f, 0.05f};
static const Col LEAF   = {0.16f, 0.40f, 0.13f}, RED = {0.80f, 0.09f, 0.11f}, PINK = {0.90f, 0.35f, 0.50f}, FWHITE = {0.95f, 0.95f, 0.92f}, GOLD = {0.86f, 0.70f, 0.20f};
static const Col BLACK  = {0.05f, 0.05f, 0.05f};

// ---------- primitives ----------
static void quadN(Mesh& m, P3 a, P3 b, P3 c, P3 d, P3 n, Col col, float mat){
    const uint16_t base = (uint16_t)m.count(); const P3 q[4] = {a, b, c, d};
    for (int k = 0; k < 4; k++){ const float f[10] = {q[k].x, q[k].y, q[k].z, n.x, n.y, n.z, col.r, col.g, col.b, mat}; m.v.insert(m.v.end(), f, f + 10); }
    const uint16_t ix[6] = {0, 1, 2, 0, 2, 3}; for (uint16_t t : ix) m.i.push_back(base + t);
}
// quad whose normal is flipped to point along `hint`
static void quad(Mesh& m, P3 a, P3 b, P3 c, P3 d, P3 hint, Col col, float mat){
    P3 n = norm(cross(b - a, d - a)); if (dot(n, hint) < 0) n = n * -1.f; quadN(m, a, b, c, d, n, col, mat);
}
static void tri(Mesh& m, P3 a, P3 b, P3 c, P3 hint, Col col, float mat){
    P3 n = norm(cross(b - a, c - a)); if (dot(n, hint) < 0) n = n * -1.f;
    const uint16_t base = (uint16_t)m.count(); const P3 q[3] = {a, b, c};
    for (int k = 0; k < 3; k++){ const float f[10] = {q[k].x, q[k].y, q[k].z, n.x, n.y, n.z, col.r, col.g, col.b, mat}; m.v.insert(m.v.end(), f, f + 10); }
    m.i.push_back(base); m.i.push_back(base + 1); m.i.push_back(base + 2);
}
// box in a frame: centre c, horizontal unit vectors t (along) and n (outward), half sizes ht, hy, hn
static void obox(Mesh& m, P3 c, P3 t, P3 n, float ht, float hy, float hn, Col col, float mat){
    const P3 Y = {0, 1, 0}, T = t * ht, N = n * hn, H = Y * hy;
    auto face = [&](P3 ctr, P3 u, P3 w, P3 nrm){ quadN(m, ctr - u - w, ctr + u - w, ctr + u + w, ctr - u + w, nrm, col, mat); };
    face(c + N, T, H, n); face(c - N, T, H, n * -1.f); face(c + T, N, H, t); face(c - T, N, H, t * -1.f); face(c + H, T, N, Y); face(c - H, T, N, Y * -1.f);
}
static void box(Mesh& m, float x, float y, float z, float hx, float hy, float hz, Col col, float mat){ obox(m, {x, y, z}, {1, 0, 0}, {0, 0, 1}, hx, hy, hz, col, mat); }
// slab: quad a,b,c,d extruded `th` downwards (roof planes)
static void slab(Mesh& m, P3 a, P3 b, P3 c, P3 d, float th, Col col, float mat){
    const P3 dn = {0, -th, 0}, a2 = a + dn, b2 = b + dn, c2 = c + dn, d2 = d + dn, ctr = (a + b + c + d + a2 + b2 + c2 + d2) * 0.125f;
    auto q = [&](P3 p0, P3 p1, P3 p2, P3 p3){ quad(m, p0, p1, p2, p3, (p0 + p1 + p2 + p3) * 0.25f - ctr, col, mat); };
    q(a, b, c, d); q(a2, b2, c2, d2); q(a, b, b2, a2); q(b, c, c2, b2); q(c, d, d2, c2); q(d, a, a2, d2);
}
// n-sided pyramid (base ring at height y0, radius R, first vertex at angle a0) rising to apex
static void pyramid(Mesh& m, P3 centre, float R, int sides, float a0, P3 apex, Col col, float mat){
    for (int k = 0; k < sides; k++){
        const float a = a0 + 6.2831853f * k / sides, b = a0 + 6.2831853f * (k + 1) / sides;
        const P3 p = {centre.x + R * std::cos(a), centre.y, centre.z + R * std::sin(a)}, q = {centre.x + R * std::cos(b), centre.y, centre.z + R * std::sin(b)};
        tri(m, p, q, apex, (p + q) * 0.5f - P3{centre.x, centre.y + 4.f, centre.z}, col, mat);
    }
}

// ---------- parts ----------
// window on a wall: centre c on the wall surface, t = along the wall, n = outward. Glass + white frame + mullion + sill, optional shutters / flower box
static void flowerBox(Mesh& m, P3 c, P3 t, P3 n, float hw, Col wood){
    obox(m, c, t, n, hw, 0.13f, 0.17f, wood, 1);                                                  // the wooden box
    obox(m, c + P3{0, 0.17f, 0}, t, n, hw - 0.03f, 0.08f, 0.14f, LEAF, 0);                        // leaves
    const Col fc[5] = {RED, RED, PINK, FWHITE, RED}; const int cnt = std::max(3, (int)(hw / 0.17f));
    for (int k = 0; k < cnt; k++){                                                                 // flower heads along the box
        const float u = (cnt == 1 ? 0.f : (-1.f + 2.f * k / (cnt - 1))) * (hw - 0.12f), h = 0.26f + 0.05f * (float)((k * 7) % 3);
        obox(m, c + t * u + P3{0, h, 0} + n * (0.04f * (float)((k % 2) ? 1 : -1)), t, n, 0.10f, 0.07f, 0.10f, fc[k % 5], 0);
    }
}
static void window(Mesh& m, P3 c, P3 t, P3 n, float w, float h, bool shutters, bool fbox){
    const P3 Y = {0, 1, 0}, o = n * 0.025f;
    quadN(m, c + o - t * (w / 2) - Y * (h / 2), c + o + t * (w / 2) - Y * (h / 2), c + o + t * (w / 2) + Y * (h / 2), c + o - t * (w / 2) + Y * (h / 2), n, GLASS, 4);
    const float f = 0.06f;
    obox(m, c + t * (w / 2 + f / 2) + n * 0.035f, t, n, f / 2, h / 2 + f, 0.045f, WHITE, 0); obox(m, c - t * (w / 2 + f / 2) + n * 0.035f, t, n, f / 2, h / 2 + f, 0.045f, WHITE, 0);
    obox(m, c + Y * (h / 2 + f / 2) + n * 0.035f, t, n, w / 2 + f, f / 2, 0.045f, WHITE, 0);
    obox(m, c + n * 0.045f, t, n, 0.02f, h / 2, 0.03f, WHITE, 0); obox(m, c + n * 0.045f + Y * (h * 0.12f), t, n, w / 2, 0.02f, 0.03f, WHITE, 0);   // mullion + transom
    obox(m, c - Y * (h / 2 + 0.1f) + n * 0.09f, t, n, w / 2 + 0.14f, 0.04f, 0.10f, WHITE, 0);                                                          // sill
    if (shutters) for (int sd : {1, -1}) obox(m, c + t * (float)sd * (w / 2 + f + 0.27f) + n * 0.05f, t, n, 0.26f, h / 2 + 0.05f, 0.03f, WOOD, 5);
    if (fbox) flowerBox(m, c - Y * (h / 2 + 0.3f) + n * 0.2f, t, n, w / 2 + 0.12f, WOOD_D);
}
// pointed-arch window / opening (church): glass rectangle + triangular top + stone frame
static void archWindow(Mesh& m, P3 c, P3 t, P3 n, float w, float h, Col glass, float mat, bool frame){
    const P3 Y = {0, 1, 0}, o = n * 0.03f, top = c + Y * (h / 2);
    quadN(m, c + o - t * (w / 2) - Y * (h / 2), c + o + t * (w / 2) - Y * (h / 2), c + o + t * (w / 2) + Y * (h / 2), c + o - t * (w / 2) + Y * (h / 2), n, glass, mat);
    tri(m, top + o - t * (w / 2), top + o + t * (w / 2), top + o + Y * (w * 0.75f), n, glass, mat);
    if (frame){ const float f = 0.12f;
        obox(m, c + t * (w / 2 + f / 2) + n * 0.04f, t, n, f / 2, h / 2 + 0.02f, 0.05f, STONE, 2); obox(m, c - t * (w / 2 + f / 2) + n * 0.04f, t, n, f / 2, h / 2 + 0.02f, 0.05f, STONE, 2);
        obox(m, c - Y * (h / 2 + 0.05f) + n * 0.07f, t, n, w / 2 + 0.2f, 0.06f, 0.09f, STONE, 2); }
}

// ======================================================= the chalet =======================================================
static void buildChalet(Mesh& m){
    const float hw = 3.5f, hd = 4.25f, yw = 5.1f, tn = 0.404f /* tan 22 deg */, wu = hw + 0.12f, du = hd + 0.12f;
    const float yr = yw + 0.12f + wu * tn;                                                         // ridge height (roof plane through the wall top)
    const P3 X = {1, 0, 0}, Z = {0, 0, 1};
    // --- stone ground floor (with a deep foundation, so a house on a slope never floats)
    box(m, 0, 0.45f, 0, hw + 0.12f, 1.95f, hd + 0.12f, STONE, 2);                                  // y -1.5 .. 2.4
    box(m, 0, 2.43f, 0, hw + 0.2f, 0.05f, hd + 0.2f, STONE, 2);                                    // stone ledge under the wooden storey
    // --- wooden upper storey (horizontal logs) + the two gables
    box(m, 0, 3.75f, 0, wu, 1.35f, du, WOOD, 1);                                                   // y 2.4 .. 5.1
    for (float zs : {du, -du}){
        tri(m, {-wu, yw, zs}, {wu, yw, zs}, {0, yr - 0.17f, zs}, Z * zs, WOOD_L, 1);
        for (int k = -2; k <= 2; k++) obox(m, {k * 0.55f, yw + 0.3f + (2 - std::abs(k)) * 0.2f - 0.15f, zs * 1.0f}, X, Z, 0.012f, 0.0f + 0.01f, 0.012f, WOOD_D, 0);  // (tiny batten ticks)
    }
    // --- the broad, low roof: two slabs, big overhang at the eaves and over the balcony, ridge cap
    const float ex = 5.1f, ey = yr - ex * tn, zf = hd + 1.9f, zb = -(hd + 1.0f);
    slab(m, {-ex, ey, zf}, {0, yr, zf}, {0, yr, zb}, {-ex, ey, zb}, 0.17f, ROOF, 3);
    slab(m, {ex, ey, zf}, {0, yr, zf}, {0, yr, zb}, {ex, ey, zb}, 0.17f, ROOF, 3);
    box(m, 0, yr + 0.05f, (zf + zb) / 2, 0.13f, 0.07f, (zf - zb) / 2 + 0.02f, ROOF, 0);
    // --- stone chimney
    box(m, 1.7f, 6.7f, -1.6f, 0.42f, 1.5f, 0.42f, STONE, 2); box(m, 1.7f, 8.25f, -1.6f, 0.55f, 0.07f, 0.55f, STONE, 2);
    // --- front door + steps (ground floor), door to the balcony (upper floor)
    box(m, 0, 1.0f, du + 0.04f, 0.58f, 1.0f, 0.05f, WOOD_D, 0); box(m, 0, 2.08f, du + 0.05f, 0.75f, 0.08f, 0.07f, WHITE, 0);
    box(m, -0.66f, 1.04f, du + 0.05f, 0.07f, 1.04f, 0.07f, WHITE, 0); box(m, 0.66f, 1.04f, du + 0.05f, 0.07f, 1.04f, 0.07f, WHITE, 0);
    box(m, 0, 0.05f, du + 0.45f, 1.0f, 0.12f, 0.4f, STONE, 2);
    box(m, 0, 3.55f, du + 0.04f, 0.58f, 1.02f, 0.05f, WOOD_D, 0); box(m, 0, 4.62f, du + 0.05f, 0.75f, 0.07f, 0.07f, WHITE, 0);
    // --- balcony: deck, posts, railing with balusters, flower boxes on the rail
    const float bz0 = du, bz1 = du + 1.55f, bx = 3.3f, rail = 3.5f;
    box(m, 0, 2.46f, (bz0 + bz1) / 2, bx, 0.06f, (bz1 - bz0) / 2, WOOD_L, 1);
    for (int k = 0; k < 5; k++) box(m, -bx + 0.4f + k * (2 * bx - 0.8f) / 4.f, 2.28f, (bz0 + bz1) / 2, 0.06f, 0.14f, (bz1 - bz0) / 2, WOOD_D, 1);   // joists
    for (float px : {-3.2f, 3.2f}) box(m, px, 2.6f, bz1 - 0.1f, 0.09f, 2.6f, 0.09f, WOOD_D, 1);                                                          // corner posts up to the roof
    box(m, 0, rail, bz1 - 0.1f, bx, 0.045f, 0.06f, WOOD_L, 1); box(m, 0, 2.62f, bz1 - 0.1f, bx, 0.04f, 0.05f, WOOD_L, 1);                               // front rails
    for (float sx : {-3.2f, 3.2f}){ box(m, sx, rail, (bz0 + bz1) / 2, 0.06f, 0.045f, (bz1 - bz0) / 2, WOOD_L, 1); box(m, sx, 2.62f, (bz0 + bz1) / 2, 0.05f, 0.04f, (bz1 - bz0) / 2, WOOD_L, 1); }
    for (int k = 0; k <= 20; k++) box(m, -3.1f + k * 0.31f, 3.06f, bz1 - 0.1f, 0.025f, 0.44f, 0.025f, WOOD_L, 1);                                         // balusters (front)
    for (float sx : {-3.2f, 3.2f}) for (int k = 1; k <= 4; k++) box(m, sx, 3.06f, bz0 + k * (bz1 - bz0) / 5.f, 0.025f, 0.44f, 0.025f, WOOD_L, 1);          // balusters (sides)
    for (float px : {-2.0f, 0.0f, 2.0f}) flowerBox(m, {px, rail + 0.15f, bz1 - 0.1f}, X, Z, 0.7f, WOOD_D);
    // --- windows
    for (float sx : {-2.1f, 2.1f}){
        window(m, {sx, 1.35f, du}, X, Z, 0.9f, 1.1f, true, true);                                   // ground floor, with flower boxes
        window(m, {sx, 3.7f, du}, X, Z, 0.9f, 1.2f, true, false);                                   // upper floor (behind the balcony rail)
    }
    window(m, {0, 5.75f, du}, X, Z, 0.55f, 0.55f, true, false);                                     // little attic window in the gable
    for (int sd : {1, -1}){
        const P3 n = {(float)sd, 0, 0}, t = {0, 0, 1};
        for (float zz : {-1.6f, 1.5f}){ window(m, {sd * wu, 1.35f, zz}, t, n, 0.9f, 1.1f, true, false); window(m, {sd * wu, 3.65f, zz}, t, n, 0.9f, 1.2f, true, true); }
    }
    window(m, {-1.4f, 3.65f, -du}, X, {0, 0, -1}, 0.9f, 1.2f, true, false); window(m, {1.4f, 1.35f, -du}, X, {0, 0, -1}, 0.9f, 1.1f, false, false);
    // --- woodpile against the side wall
    for (int r = 0; r < 3; r++) for (int k = 0; k < 4 - r; k++) obox(m, {-(wu + 0.3f), 0.2f + r * 0.32f, -2.4f + k * 0.34f + r * 0.17f}, X, Z, 0.28f, 0.15f, 0.15f, WOOD_L, 1);
}

// ======================================================= the church =======================================================
static void clockFace(Mesh& m, P3 c, P3 t, P3 n){
    obox(m, c, t, n, 0.85f, 0.85f, 0.03f, STONE, 2); obox(m, c + n * 0.03f, t, n, 0.72f, 0.72f, 0.02f, WHITE, 0);
    obox(m, c + n * 0.06f + P3{0, 0.28f, 0}, t, n, 0.04f, 0.3f, 0.015f, BLACK, 0); obox(m, c + n * 0.06f + t * 0.2f, t, n, 0.24f, 0.04f, 0.015f, BLACK, 0);
}
static void buildChurch(Mesh& m){
    const P3 X = {1, 0, 0}, Z = {0, 0, 1};
    // --- nave (white plaster, steep tiled roof), on a stone plinth with a deep foundation
    const float nw = 3.8f, nz0 = -7.0f, wy = 6.5f, tn = 0.839f;
    box(m, 0, -0.45f, 0, nw + 0.15f, 1.05f, 7.15f, STONE, 2);
    box(m, 0, 3.25f, 0, nw, 3.25f, 7.0f, PLASTER, 6);
    const float yr = wy + 0.1f + nw * tn, ex = nw + 0.55f, ey = yr - ex * tn;
    slab(m, {-ex, ey, 7.2f}, {0, yr, 7.2f}, {0, yr, nz0 - 0.5f}, {-ex, ey, nz0 - 0.5f}, 0.2f, TILE, 3);
    slab(m, {ex, ey, 7.2f}, {0, yr, 7.2f}, {0, yr, nz0 - 0.5f}, {ex, ey, nz0 - 0.5f}, 0.2f, TILE, 3);
    tri(m, {-nw, wy, nz0 - 0.01f}, {nw, wy, nz0 - 0.01f}, {0, yr - 0.22f, nz0 - 0.01f}, -Z, PLASTER, 6);
    for (int sd : {1, -1}){ const P3 n = {(float)sd, 0, 0}, t = {0, 0, 1};
        for (float zz : {-4.6f, -1.6f, 1.4f}) archWindow(m, {sd * nw, 3.6f, zz}, t, n, 1.15f, 2.6f, GLASS, 4, true);
    }
    // --- choir at the back
    const float cw = 2.4f, cz0 = -10.3f, cy = 4.8f, ct = 0.781f, cyr = cy + 0.1f + cw * ct, cex = cw + 0.4f, cey = cyr - cex * ct;
    box(m, 0, -0.45f, (cz0 + nz0) / 2, cw + 0.1f, 1.05f, (nz0 - cz0) / 2 + 0.05f, STONE, 2);        // plinth + foundation of the choir
    box(m, 0, 3.4f, (cz0 + nz0) / 2, cw, 1.4f, (nz0 - cz0) / 2, PLASTER, 6);
    slab(m, {-cex, cey, nz0 + 0.1f}, {0, cyr, nz0 + 0.1f}, {0, cyr, cz0 - 0.4f}, {-cex, cey, cz0 - 0.4f}, 0.18f, TILE, 3);
    slab(m, {cex, cey, nz0 + 0.1f}, {0, cyr, nz0 + 0.1f}, {0, cyr, cz0 - 0.4f}, {cex, cey, cz0 - 0.4f}, 0.18f, TILE, 3);
    tri(m, {-cw, cy, cz0 - 0.01f}, {cw, cy, cz0 - 0.01f}, {0, cyr - 0.2f, cz0 - 0.01f}, -Z, PLASTER, 6);
    archWindow(m, {0, 3.2f, cz0}, X, -Z, 0.9f, 1.9f, GLASS, 4, true);
    // --- tower: shaft, cornices, belfry with openings, four little gables, needle spire, gilded ball
    const float tz = 7.3f, th = 2.3f;
    box(m, 0, -0.45f, tz, th + 0.2f, 1.05f, th + 0.2f, STONE, 2);                                  // plinth
    box(m, 0, 6.2f, tz, th, 7.8f, th, PLASTER, 6);                                                  // shaft y -1.6 .. 14
    for (float cx : {-th, th}) for (float cz : {tz - th, tz + th}) box(m, cx, 6.5f, cz, 0.16f, 6.5f, 0.16f, STONE, 2);   // corner stones
    box(m, 0, 13.98f, tz, th + 0.22f, 0.14f, th + 0.22f, STONE, 2);                                // cornice
    box(m, 0, 15.75f, tz, 2.0f, 1.75f, 2.0f, PLASTER, 6);                                          // belfry y 14 .. 17.5
    box(m, 0, 17.55f, tz, 2.22f, 0.12f, 2.22f, STONE, 2);                                          // cornice under the spire
    for (int sd = 0; sd < 4; sd++){ const float a = sd * 1.5707963f; const P3 n = {std::sin(a), 0, std::cos(a)}, t = {n.z, 0, -n.x};
        const P3 fc = P3{0, 0, tz} + n * 2.0f;
        archWindow(m, fc + P3{0, 15.9f, 0}, t, n, 1.15f, 2.1f, DARK, 0, true);                      // belfry opening
        for (int k = 0; k < 4; k++) obox(m, fc + P3{0, 15.0f + k * 0.5f, 0} + n * 0.05f, t, n, 0.55f, 0.04f, 0.04f, WOOD_D, 0);   // louvre slats
        tri(m, fc + t * -1.55f + P3{0, 17.55f, 0} + n * 0.15f, fc + t * 1.55f + P3{0, 17.55f, 0} + n * 0.15f, fc + P3{0, 19.9f, 0} + n * 0.15f, n, PLASTER, 6);   // gable
    }
    clockFace(m, {0, 11.2f, tz + th + 0.02f}, X, Z); clockFace(m, {th + 0.02f, 11.2f, tz}, {0, 0, -1}, X); clockFace(m, {-th - 0.02f, 11.2f, tz}, {0, 0, 1}, -X);
    for (int sd : {1, -1}) archWindow(m, {sd * (th + 0.01f), 6.5f, tz}, {0, 0, 1}, {(float)sd, 0, 0}, 0.65f, 1.5f, GLASS, 4, true);
    archWindow(m, {0, 7.0f, tz + th + 0.01f}, X, Z, 0.8f, 1.8f, GLASS, 4, true);
    // front door with pointed arch and stone surround, steps
    const float fz = tz + th;
    box(m, 0, 1.5f, fz + 0.03f, 0.95f, 1.5f, 0.05f, WOOD_D, 0); tri(m, {-0.95f, 3.0f, fz + 0.08f}, {0.95f, 3.0f, fz + 0.08f}, {0, 4.1f, fz + 0.08f}, Z, WOOD_D, 0);
    box(m, -1.12f, 1.65f, fz + 0.06f, 0.14f, 1.65f, 0.08f, STONE, 2); box(m, 1.12f, 1.65f, fz + 0.06f, 0.14f, 1.65f, 0.08f, STONE, 2); box(m, 0, 0.08f, fz + 0.6f, 1.6f, 0.18f, 0.6f, STONE, 2);
    // the needle: octagonal, very slender, slate; gilded ball + cross on top
    const P3 apex = {0, 31.0f, tz};
    pyramid(m, {0, 17.6f, tz}, 2.3f, 8, 0.3926991f, apex, SLATE, 3);
    obox(m, {0, 31.2f, tz}, X, Z, 0.22f, 0.22f, 0.22f, GOLD, 0);
}

} // namespace VillageMesh
