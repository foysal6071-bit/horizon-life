// Sunny Drift - OpenGL ES 3 rendering of the rolling hills and the distant mountain ring (see terrain.h).
//  The hills next to the river patch are two strips of the same 4 m lattice; the river patch itself (BridgeGL::drawTerrain) already carries
//  the hills inside its area. Both use the river-bed shader (vertex colour x sun + haze). The dirt track is drawn by RoadGL (mud material).
#pragma once
#include "terrain.h"
#include "bridge_render.h"

namespace TerrainGL {

static BridgeGL::Gpu gSouth, gNorth, gMountains, gOuter;
static void initLake();

// Call once with a current GL context, after Terrain::init() and BridgeGL::init() (it re-uses the bridge's terrain shader).
static void init(){
    auto up = [](const Terrain::GMesh& m){ const int n[3] = {3, 3, 3}, o[3] = {0, 12, 24}; return BridgeGL::upload(m.v.data(), m.v.size() * 4, m.idx, 36, n, o, 3); };
    gSouth = up(Terrain::gMeshes.southHills); gNorth = up(Terrain::gMeshes.northHills); gMountains = up(Terrain::gMeshes.mountains); gOuter = up(Terrain::gMeshes.outer);
    initLake();
}

static void draw(const float* VP, const float* eye){
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE);
    glUseProgram(BridgeGL::gProgT); glUniformMatrix4fv(BridgeGL::uT_VP, 1, GL_FALSE, VP); glUniform3fv(BridgeGL::uT_Cam, 1, eye); glUniform1f(BridgeGL::uT_Time, BridgeGL::gWindT);
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, BridgeGL::gGrass); glUniform1i(BridgeGL::uT_Grass, 0);
    BridgeGL::setCullVP(VP);
    BridgeGL::drawGpuCulled(gSouth); BridgeGL::drawGpuCulled(gNorth); BridgeGL::drawGpuCulled(gMountains); BridgeGL::drawGpuCulled(gOuter);
}

// ---------- mountain lake: the river-water shader (ripples, fresnel, sun glint, shore foam) in turquoise, with the mountains mirrored in it ----------
static const char* LAKE_VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in float dep;
uniform mat4 uVP; out float vD; out vec3 wp;
void main(){ vD = dep; wp = p; gl_Position = uVP * vec4(p, 1.0); }
)GLSL";
static const char* LAKE_FS = R"GLSL(#version 300 es
precision highp float;
in float vD; in vec3 wp; uniform vec3 uCam; uniform float uT; uniform sampler2D uSky; out vec4 o;
float h21(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float vn(vec2 p){ vec2 i = floor(p), f = fract(p); f = f*f*(3.0 - 2.0*f); return mix(mix(h21(i), h21(i + vec2(1,0)), f.x), mix(h21(i + vec2(0,1)), h21(i + vec2(1,1)), f.x), f.y); }
void main(){
  vec2 w = vec2(cos(wp.x*0.9 + sin(wp.z*0.7 + uT*0.9) + uT*1.1), cos(wp.z*1.1 + sin(wp.x*0.8 - uT*0.7) - uT*0.8));      // same ripples as the river, calmer
  vec3 N = normalize(vec3(w.x*0.03, 1.0, w.y*0.03)), Nr = normalize(vec3(w.x*0.07, 1.0, w.y*0.07));
  vec3 V = normalize(uCam - wp), L = normalize(vec3(0.4, 0.8, 0.3)), H = normalize(L + V);
  float fr = pow(1.0 - clamp(dot(N, V), 0.0, 1.0), 3.0);
  float dw = vD + 0.05*sin(uT*0.9 + wp.x*0.05 + wp.z*0.04);
  float dk = smoothstep(0.0, 4.5, dw);
  vec3 body = mix(vec3(0.16, 0.74, 0.72), vec3(0.015, 0.30, 0.52), dk) * (0.70 + 0.40*max(dot(N, L), 0.0));      // clear turquoise shallows -> deep blue
  // mirrored mountains: reflect the view ray, look the skyline up by azimuth
  vec3 R = reflect(-V, Nr); R.y = max(R.y, 0.01);
  float el = atan(R.y, length(R.xz)), az = atan(R.z, R.x)*0.15915494 + 0.5;
  float se = texture(uSky, vec2(az, 0.5)).r, crest = texture(uSky, vec2(az, 0.5)).g * 850.0;
  vec3 hzc = vec3(0.72, 0.87, 0.98);
  vec3 sky = mix(hzc, vec3(0.28, 0.54, 0.92), smoothstep(0.0, 1.0, el*1.5));
  float v = clamp(el / max(se, 0.001), 0.0, 1.0);
  float hg = v*crest + (vn(vec2(az*900.0, el*80.0)) - 0.5)*60.0;
  vec3 mc = mix(vec3(0.13, 0.29, 0.11), vec3(0.45, 0.44, 0.42), smoothstep(120.0, 200.0, hg));                // grass -> rock -> snow, like the real slopes
  mc = mix(mc, vec3(0.94, 0.96, 0.99), smoothstep(360.0, 440.0, hg));
  mc *= 0.78 + 0.34*vn(vec2(az*1800.0, el*160.0)); mc = mix(mc, hzc, 0.30);
  float mm = smoothstep(0.0015, -0.0015, el - se) * step(0.002, se);
  vec3 refl = mix(sky, mc, mm);
  vec3 c = mix(body, refl, 0.36 + 0.56*fr) + vec3(pow(max(dot(N, H), 0.0), 220.0) * 0.9);
  float foam = (1.0 - smoothstep(0.0, 0.14, dw)) * step(0.0, dw);
  c = mix(c, vec3(0.95, 0.99, 1.0), foam*0.55);
  float a = clamp(0.88 + 0.12*fr, 0.0, 1.0) * smoothstep(0.0, 0.30, dw);                                       // soft shoreline
  c = mix(c, hzc, clamp(length(uCam - wp) / 3750.0, 0.0, 1.0));
  o = vec4(c, a);
}
)GLSL";
static BridgeGL::Gpu gLakeG; static GLuint gLakeProg = 0, gLakeSky = 0; static GLint uL_VP, uL_Cam, uL_T, uL_Sky;
static void initLake(){
    if (!Terrain::gLake.on || Terrain::LAKE_I.empty()) return;
    gLakeProg = RoadGL::makeProg(LAKE_VS, LAKE_FS);
    uL_VP = glGetUniformLocation(gLakeProg, "uVP"); uL_Cam = glGetUniformLocation(gLakeProg, "uCam"); uL_T = glGetUniformLocation(gLakeProg, "uT"); uL_Sky = glGetUniformLocation(gLakeProg, "uSky");
    const int n[2] = {3, 1}, o[2] = {0, 12}; gLakeG = BridgeGL::upload(Terrain::LAKE_V.data(), Terrain::LAKE_V.size() * 4, Terrain::LAKE_I, 16, n, o, 2);
    glGenTextures(1, &gLakeSky); glBindTexture(GL_TEXTURE_2D, gLakeSky); glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, Terrain::LAKE_SKY_N, 1, 0, GL_RGBA, GL_UNSIGNED_BYTE, Terrain::LAKE_SKY.data());
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
}
// transparent: call after all opaque things (trees) are drawn
static void drawLake(const float* VP, const float* eye, float t){
    if (!gLakeG.count) return;
    glUseProgram(gLakeProg); glUniformMatrix4fv(uL_VP, 1, GL_FALSE, VP); glUniform3fv(uL_Cam, 1, eye); glUniform1f(uL_T, t);
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, gLakeSky); glUniform1i(uL_Sky, 0);
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); glDepthMask(GL_FALSE);
    BridgeGL::setCullVP(VP); BridgeGL::drawGpuCulled(gLakeG);
    glDepthMask(GL_TRUE); glDisable(GL_BLEND);
}

} // namespace TerrainGL
