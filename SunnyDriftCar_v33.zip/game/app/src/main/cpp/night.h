// Sunny Drift - night mode + realistic headlights.
//  * night is a smooth fade (button in the app): the finished picture is darkened with a blue multiply, then the lights are drawn on top
//  * headlights (this file) - physically motivated low-beam, two real lamps (Audi R8 lamp positions taken from the model):
//      1. ground light: per-pixel spot-light on the road (inverse-distance falloff, low-beam cut-off, hot-spot ~10-20 m ahead,
//         wide soft spill, two overlapping beams).  It is applied as a MULTIPLY (road texture / mud / grass stay visible and are
//         simply lit up) plus a small warm additive part, so it looks like light falling on the surface instead of a flat glow plane
//      2. soft volumetric light cones in the air in front of each lamp (additive, fresnel-faded edges, fade with distance)
//      3. lens glare / bloom sprite on each lamp, only visible when you look at the car from the front
//    the lights follow the car body (pitch on hills / bridge arch, roll, suspension), not only the heading
#pragma once
#include <GLES3/gl3.h>
#include <cmath>
#include <vector>

namespace NightGL {

static float night = 0, target = 0;
static GLuint gProgOv = 0, gProgPool = 0, gPoolVBO = 0, gProgCone = 0, gConeVBO = 0, gProgGlow = 0, gGlowVBO = 0;
static GLint uOvMul, uPoolVP, uPoolK, uPoolMode, uPoolL0, uPoolL1;
static GLint uConeVP, uConeEye, uConeK;
static GLint uGlowVP, uGlowC, uGlowRt, uGlowUp, uGlowS, uGlowI;

// ---- lamp placement in the car model frame (x forward, y up, z across) measured from the R8 "light" mesh ----
static const float LAMP_X = 2.04f, LAMP_Y = 0.595f, LAMP_Z = 0.75f;
static const float BEAM_DOWN = 0.022f;          // beam axis points ~1.3 degrees below the horizon

static const char* OV_VS = R"GLSL(#version 300 es
void main(){ vec2 p = vec2((gl_VertexID == 1) ? 3.0 : -1.0, (gl_VertexID == 2) ? 3.0 : -1.0); gl_Position = vec4(p, 0.0, 1.0); }
)GLSL";
static const char* OV_FS = R"GLSL(#version 300 es
precision mediump float; uniform vec3 uMul; out vec4 o;
void main(){ o = vec4(uMul, 1.0); }
)GLSL";

// ------------------------------------------------------------------------------------------------ ground light
static const char* POOL_VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in vec2 fl;       // fl = (metres ahead of the car centre, metres to the right)
uniform mat4 uVP; out vec2 vFL;
void main(){ vFL = fl; gl_Position = uVP*vec4(p, 1.0); }
)GLSL";
static const char* POOL_FS = R"GLSL(#version 300 es
precision highp float;
in vec2 vFL; uniform float uK; uniform int uMode; uniform vec3 uL0, uL1;   // lamp: (ahead, right, height above the road)
out vec4 o;

// illuminance of one low-beam lamp at this road point
float beam(vec3 L){
  float f = vFL.x - L.x, l = vFL.y - L.y, h = max(L.z, 0.25);
  if (f < 0.15) return 0.0;
  float dist2 = f*f + l*l + h*h;
  float al = atan(l, f);                                        // angle left/right of the beam axis
  float av = atan(h, f);                                        // angle below the horizon (far road = small angle)
  float lat = 0.82*exp(-al*al/0.17) + 0.18*exp(-al*al/0.6);     // bright core + soft side spill
  float vert = smoothstep(0.004, 0.020, av) * (0.5 + 0.5*exp(-pow((av - 0.05)/0.035, 2.0)));   // low-beam cut-off + hot-spot
  return lat * vert * 3.2 / (pow(dist2, 0.85) + 30.0);
}
void main(){
  float f = vFL.x, l = vFL.y;
  float mask = smoothstep(1.8, 3.6, f) * smoothstep(0.0, 8.0, 62.0 - f) * smoothstep(0.0, 5.0, 28.0 - abs(l));
  float E = beam(uL0) + beam(uL1);
  float e = (1.0 - exp(-E * 35.0)) * mask * uK;                  // soft tone-curve: no hard clipping
  vec3 warm = vec3(1.0, 0.925, 0.74);                            // halogen / xenon white, slightly warm
  if (uMode == 0) o = vec4(warm * e, 1.0);                       // multiply pass: surface x (1 + light)
  else            o = vec4(warm * e * 0.16, 1.0);                // faint additive veil (wet / dusty road sheen)
}
)GLSL";

// ------------------------------------------------------------------------------------------------ volumetric cone
static const char* CONE_VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in vec3 n; layout(location=2) in float t;
uniform mat4 uVP; uniform vec3 uEye; out vec3 vN; out vec3 vV; out float vT;
void main(){ vN = n; vV = uEye - p; vT = t; gl_Position = uVP*vec4(p, 1.0); }
)GLSL";
static const char* CONE_FS = R"GLSL(#version 300 es
precision highp float;
in vec3 vN; in vec3 vV; in float vT; uniform float uK; out vec4 o;
void main(){
  float nd = abs(dot(normalize(vN), normalize(vV)));            // soft edges: faces seen edge-on fade out
  float a = pow(nd, 1.6) * pow(1.0 - vT, 1.8) * smoothstep(0.0, 0.07, vT) * 0.17 * uK;
  o = vec4(vec3(1.0, 0.93, 0.78) * a, 1.0);
}
)GLSL";

// ------------------------------------------------------------------------------------------------ lens glare sprite
static const char* GLOW_VS = R"GLSL(#version 300 es
layout(location=0) in vec2 q;
uniform mat4 uVP; uniform vec3 uC, uRt, uUp; uniform float uS; out vec2 vQ;
void main(){ vQ = q; gl_Position = uVP*vec4(uC + (uRt*q.x + uUp*q.y)*uS, 1.0); }
)GLSL";
static const char* GLOW_FS = R"GLSL(#version 300 es
precision mediump float;
in vec2 vQ; uniform float uI; out vec4 o;
void main(){
  float r2 = dot(vQ, vQ);
  float core = exp(-r2*55.0);
  float halo = 0.34/(1.0 + r2*20.0);
  float streak = exp(-abs(vQ.y)*20.0) * exp(-abs(vQ.x)*2.0) * 0.32;
  float edge = smoothstep(1.0, 0.55, sqrt(r2));
  o = vec4(vec3(1.0, 0.95, 0.82) * (core*1.7 + halo + streak) * edge * uI, 1.0);
}
)GLSL";

static GLuint mk(const char* vs, const char* fs){
    GLuint p = glCreateProgram();
    GLuint a = glCreateShader(GL_VERTEX_SHADER); glShaderSource(a, 1, &vs, nullptr); glCompileShader(a);
    GLuint b = glCreateShader(GL_FRAGMENT_SHADER); glShaderSource(b, 1, &fs, nullptr); glCompileShader(b);
    glAttachShader(p, a); glAttachShader(p, b); glLinkProgram(p); return p;
}
static const int CONE_SEG = 24, CONE_VERTS = 2 * CONE_SEG * 6;     // 2 cones x 24 segments x 2 triangles
static void init(){
    gProgOv = mk(OV_VS, OV_FS); uOvMul = glGetUniformLocation(gProgOv, "uMul");
    gProgPool = mk(POOL_VS, POOL_FS);
    uPoolVP = glGetUniformLocation(gProgPool, "uVP"); uPoolK = glGetUniformLocation(gProgPool, "uK"); uPoolMode = glGetUniformLocation(gProgPool, "uMode");
    uPoolL0 = glGetUniformLocation(gProgPool, "uL0"); uPoolL1 = glGetUniformLocation(gProgPool, "uL1");
    glGenBuffers(1, &gPoolVBO); glBindBuffer(GL_ARRAY_BUFFER, gPoolVBO); glBufferData(GL_ARRAY_BUFFER, 6 * 5 * 4, nullptr, GL_DYNAMIC_DRAW);

    gProgCone = mk(CONE_VS, CONE_FS);
    uConeVP = glGetUniformLocation(gProgCone, "uVP"); uConeEye = glGetUniformLocation(gProgCone, "uEye"); uConeK = glGetUniformLocation(gProgCone, "uK");
    glGenBuffers(1, &gConeVBO); glBindBuffer(GL_ARRAY_BUFFER, gConeVBO); glBufferData(GL_ARRAY_BUFFER, CONE_VERTS * 7 * 4, nullptr, GL_DYNAMIC_DRAW);

    gProgGlow = mk(GLOW_VS, GLOW_FS);
    uGlowVP = glGetUniformLocation(gProgGlow, "uVP"); uGlowC = glGetUniformLocation(gProgGlow, "uC"); uGlowRt = glGetUniformLocation(gProgGlow, "uRt");
    uGlowUp = glGetUniformLocation(gProgGlow, "uUp"); uGlowS = glGetUniformLocation(gProgGlow, "uS"); uGlowI = glGetUniformLocation(gProgGlow, "uI");
    const float qd[12] = {-1,-1, 1,-1, -1,1, -1,1, 1,-1, 1,1};
    glGenBuffers(1, &gGlowVBO); glBindBuffer(GL_ARRAY_BUFFER, gGlowVBO); glBufferData(GL_ARRAY_BUFFER, sizeof(qd), qd, GL_STATIC_DRAW);
}
static void update(double dt){ night += (target - night) * (float)(1 - exp(-dt * 2.0)); if (fabsf(night - target) < 0.002f) night = target; }

// darken the whole picture (sky, hills, road, car) towards a moonlit blue
static void overlay(){
    if (night < 0.002f) return;
    const float k = night, m0 = 1 - k * (1 - 0.13f), m1 = 1 - k * (1 - 0.17f), m2 = 1 - k * (1 - 0.30f);
    glDisable(GL_DEPTH_TEST); glDepthMask(GL_FALSE); glEnable(GL_BLEND); glBlendFunc(GL_DST_COLOR, GL_ZERO);
    glUseProgram(gProgOv); glUniform3f(uOvMul, m0, m1, m2); glDrawArrays(GL_TRIANGLES, 0, 3);
    glEnable(GL_DEPTH_TEST); glDepthMask(GL_TRUE); glDisable(GL_BLEND);
}

struct V3f { float x, y, z; };
static inline V3f operator+(V3f a, V3f b){ return {a.x + b.x, a.y + b.y, a.z + b.z}; }
static inline V3f operator-(V3f a, V3f b){ return {a.x - b.x, a.y - b.y, a.z - b.z}; }
static inline V3f operator*(V3f a, float s){ return {a.x * s, a.y * s, a.z * s}; }
static inline float dot3(V3f a, V3f b){ return a.x * b.x + a.y * b.y + a.z * b.z; }
static inline V3f cross3(V3f a, V3f b){ return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x}; }
static inline V3f norm3(V3f a){ float l = sqrtf(dot3(a, a)); return l > 1e-6f ? a * (1.f / l) : a; }

// Mdl = car model matrix (column-major, model frame: nose +X, up +Y), eye = camera position, y = road height under the car
static void pool(const float* VP, const float* eye, const float* Mdl, double x, double z, double heading, double y){
    if (night < 0.02f) return;
    const V3f X = {Mdl[0], Mdl[1], Mdl[2]}, Y = {Mdl[4], Mdl[5], Mdl[6]}, Z = {Mdl[8], Mdl[9], Mdl[10]}, T = {Mdl[12], Mdl[13], Mdl[14]};
    const V3f lampW[2] = {T + X * LAMP_X + Y * LAMP_Y + Z * (-LAMP_Z), T + X * LAMP_X + Y * LAMP_Y + Z * LAMP_Z};
    const V3f E = {eye[0], eye[1], eye[2]};

    // ------------------------------------------------ 1. light on the road
    const float fx = (float)sin(heading), fz = (float)cos(heading), rx = fz, rz = -fx;          // forward / right (horizontal)
    const float py = (float)y + 0.15f;                                                            // ROAD_SURF + 0.07 above the car's ground
    const float F0 = 1.8f, F1 = 62.f, W = 28.f;
    auto v = [&](float f, float s, float u, float t, float* o){ o[0] = (float)x + fx * f + rx * s; o[1] = py; o[2] = (float)z + fz * f + rz * s; o[3] = u; o[4] = t; };
    float q[30]; v(F0, -W, F0, -W, q); v(F0, W, F0, W, q + 5); v(F1, -W, F1, -W, q + 10); v(F0, W, F0, W, q + 15); v(F1, W, F1, W, q + 20); v(F1, -W, F1, -W, q + 25);
    glBindBuffer(GL_ARRAY_BUFFER, gPoolVBO); glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(q), q);
    glUseProgram(gProgPool); glUniformMatrix4fv(uPoolVP, 1, GL_FALSE, VP); glUniform1f(uPoolK, night);
    for (int i = 0; i < 2; i++){                                                                  // lamp position relative to the car centre: (ahead, right, height)
        const float lf = (lampW[i].x - (float)x) * fx + (lampW[i].z - (float)z) * fz, lr = (lampW[i].x - (float)x) * rx + (lampW[i].z - (float)z) * rz;
        glUniform3f(i == 0 ? uPoolL0 : uPoolL1, lf, lr, lampW[i].y - py);
    }
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 20, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 20, (void*)12);
    glEnable(GL_DEPTH_TEST); glDepthMask(GL_FALSE); glDisable(GL_CULL_FACE); glEnable(GL_BLEND);
    glEnable(GL_POLYGON_OFFSET_FILL); glPolygonOffset(-5.f, -5.f);
    glUniform1i(uPoolMode, 0); glBlendFunc(GL_DST_COLOR, GL_ONE);                                 // dst *= (1 + light): three passes = up to x8 so the dark night road is truly lit
    for (int k = 0; k < 3; k++) glDrawArrays(GL_TRIANGLES, 0, 6);
    glUniform1i(uPoolMode, 1); glBlendFunc(GL_ONE, GL_ONE); glDrawArrays(GL_TRIANGLES, 0, 6);    // soft warm veil
    glDisable(GL_POLYGON_OFFSET_FILL);

    // ------------------------------------------------ 2. volumetric light cones in the air
    {
        const V3f A = norm3(X * cosf(BEAM_DOWN) - Y * sinf(BEAM_DOWN)), R = norm3(Z - A * dot3(Z, A)), U = cross3(A, R);
        const float LEN = 30.f, RH = 0.20f, RV = 0.075f, T0 = 0.04f;                              // half-angle ~11 deg sideways, ~4 deg up/down
        std::vector<float> buf; buf.reserve(CONE_VERTS * 7);
        auto push = [&](V3f p, V3f n, float t){ buf.push_back(p.x); buf.push_back(p.y); buf.push_back(p.z); buf.push_back(n.x); buf.push_back(n.y); buf.push_back(n.z); buf.push_back(t); };
        for (int li = 0; li < 2; li++){
            auto ring = [&](int s, float t, V3f& p, V3f& n){
                const float ph = 6.2831853f * s / CONE_SEG, c = cosf(ph), sn = sinf(ph), d = t * LEN;
                p = lampW[li] + A * d + R * (c * RH * d) + U * (sn * RV * d);
                n = norm3(R * (c * RV) + U * (sn * RH));
            };
            for (int s = 0; s < CONE_SEG; s++){
                V3f p0, n0, p1, n1, p2, n2, p3, n3;
                ring(s, T0, p0, n0); ring(s + 1, T0, p1, n1); ring(s, 1.f, p2, n2); ring(s + 1, 1.f, p3, n3);
                push(p0, n0, T0); push(p1, n1, T0); push(p2, n2, 1.f); push(p1, n1, T0); push(p3, n3, 1.f); push(p2, n2, 1.f);
            }
        }
        glBindBuffer(GL_ARRAY_BUFFER, gConeVBO); glBufferSubData(GL_ARRAY_BUFFER, 0, buf.size() * 4, buf.data());
        glUseProgram(gProgCone); glUniformMatrix4fv(uConeVP, 1, GL_FALSE, VP); glUniform3f(uConeEye, E.x, E.y, E.z); glUniform1f(uConeK, night);
        glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 28, (void*)0);
        glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 28, (void*)12);
        glEnableVertexAttribArray(2); glVertexAttribPointer(2, 1, GL_FLOAT, GL_FALSE, 28, (void*)24);
        glBlendFunc(GL_ONE, GL_ONE); glDrawArrays(GL_TRIANGLES, 0, CONE_VERTS);
        glDisableVertexAttribArray(2);
    }

    // ------------------------------------------------ 3. lens glare on each lamp (only when seen from the front)
    {
        glUseProgram(gProgGlow); glUniformMatrix4fv(uGlowVP, 1, GL_FALSE, VP);
        glBindBuffer(GL_ARRAY_BUFFER, gGlowVBO); glEnableVertexAttribArray(0); glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 8, (void*)0);
        glBlendFunc(GL_ONE, GL_ONE);
        for (int li = 0; li < 2; li++){
            const V3f toEye = norm3(E - lampW[li]);
            const float facing = dot3(X, toEye), I = night * fminf(fmaxf((facing + 0.15f) / 0.85f, 0.f), 1.f);
            if (I < 0.01f) continue;
            const V3f vd = toEye * -1.f, rt = norm3(cross3(vd, {0.f, 1.f, 0.f})), up = cross3(rt, vd), c = lampW[li] + toEye * 0.14f;
            glUniform3f(uGlowC, c.x, c.y, c.z); glUniform3f(uGlowRt, rt.x, rt.y, rt.z); glUniform3f(uGlowUp, up.x, up.y, up.z);
            glUniform1f(uGlowS, 0.85f); glUniform1f(uGlowI, I); glDrawArrays(GL_TRIANGLES, 0, 6);
        }
    }
    glDepthMask(GL_TRUE); glDisable(GL_BLEND);
}

} // namespace NightGL
