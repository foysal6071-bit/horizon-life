cmake_minimum_required(VERSION 3.18)
project(car)
set(CMAKE_CXX_STANDARD 17)
# The CI builds with `assembleDebug`, which would compile this library with -O0 (the debug flags come AFTER cppFlags and win).
# Force full optimisation for every build type: this is the single biggest CPU win (physics, culling, instance building).
set(CMAKE_BUILD_TYPE Release CACHE STRING "" FORCE)
set(CMAKE_CXX_FLAGS_DEBUG "-O3 -DNDEBUG")
set(CMAKE_CXX_FLAGS_RELEASE "-O3 -DNDEBUG")
set(CMAKE_C_FLAGS_DEBUG "-O3 -DNDEBUG")
add_library(car SHARED native-lib.cpp)
target_compile_options(car PRIVATE -O3 -fvisibility=hidden -fno-math-errno -ffunction-sections -fdata-sections)
target_link_options(car PRIVATE -Wl,--gc-sections)
target_link_libraries(car GLESv3 android log)
