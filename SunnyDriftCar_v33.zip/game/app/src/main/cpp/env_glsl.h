// Sunny Drift - the HTML "carEnv" sky reflection as GLSL (shared by the car shader and the wet road / puddle shader).
// gradient sky + ground, sun disc and two soft boxes, analytic instead of a PMREM cube; r = roughness (blurs the reflection).
#pragma once
#define ENV_GLSL R"GLSL(
vec3 L2(vec3 s){ return pow(s, vec3(2.2)); }

// ---- HTML "carEnv": gradient sky + ground, sun disc, two soft boxes (analytic instead of a PMREM cube) ----
vec3 envC(vec3 d, float r){
  vec3 TOP = L2(vec3(0.239,0.525,0.863)), MID = L2(vec3(0.812,0.902,0.984)), GND = L2(vec3(0.345,0.439,0.263));
  float h = d.y, e = 0.02 + 0.35*r;
  vec3 sky = mix(MID, TOP, pow(max(h*(1.0 - 0.4*r), 0.0), 0.5));
  vec3 gr  = mix(MID*0.5, GND, smoothstep(0.0, 0.25 + 0.3*r, -h));
  vec3 c = mix(gr, sky, smoothstep(-e, e, h));
  float R2 = r*r;
  vec3 S = normalize(vec3(40.0,45.0,30.0));
  float cs = dot(d, S), cr = cos(0.1187), w = 0.002 + 0.30*R2;
  c += vec3(14.0,12.0,9.0) * smoothstep(cr - w, cr + w, cs) / (1.0 + 45.0*R2);
  for (int i = 0; i < 2; i++){
    vec3 ce = i == 0 ? vec3(-50.0,22.0,26.0) : vec3(8.0,26.0,-55.0);
    vec2 sz = i == 0 ? vec2(36.0,12.0) : vec2(46.0,10.0);
    float dist = length(ce); vec3 cd = ce/dist, z = -cd, x = normalize(cross(vec3(0,1,0), z)), y = cross(z, x);
    float dn = dot(d, cd);
    if (dn > 0.05){
      vec3 q = d*(dist/dn) - ce; vec2 pl = vec2(dot(q, x), dot(q, y));
      float soft = 1.5 + 22.0*r;
      vec2 k = smoothstep(vec2(0.0), vec2(soft), sz*0.5 - abs(pl));
      c += vec3(3.0,3.0,3.2) * k.x * k.y / (1.0 + 6.0*R2);
    }
  }
  return c;
}
vec2 envBRDF(float rough, float NoV){
  const vec4 c0 = vec4(-1.0,-0.0275,-0.572,0.022), c1 = vec4(1.0,0.0425,1.04,-0.04);
  vec4 r = rough*c0 + c1; float a004 = min(r.x*r.x, exp2(-9.28*NoV))*r.x + r.y;
  return vec2(-1.04,1.04)*a004 + r.zw;
}
)GLSL"
