// Sunny Drift - waterfall site (GL-free): finds a steep mountain flank and the line the water runs down it.
//  Needs Terrain::init() (mountain heights). Called before the forest is planted so no tree stands in the stream.
#pragma once
#include <cmath>
#include <vector>
#include "terrain.h"

namespace NatureFx {

static std::vector<float> PX, PZ;       // stream centre line, top -> bottom, ~5 m apart
static bool gFallOn = false;

static bool trace(double x, double z, std::vector<float>& ox, std::vector<float>& oz, double& h0, double& h1){
    ox.clear(); oz.clear(); h0 = Terrain::mtnH(x, z); if (h0 < 0) return false;
    double dx = 0, dz = 0, h = h0;
    for (int i = 0; i < 64; i++){
        ox.push_back((float)x); oz.push_back((float)z);
        const double a = Terrain::mtnH(x + 6, z), b = Terrain::mtnH(x - 6, z), c = Terrain::mtnH(x, z + 6), d = Terrain::mtnH(x, z - 6);
        if (a < 0 || b < 0 || c < 0 || d < 0) break;
        double gx = (a - b) / 12, gz = (c - d) / 12; const double gl = std::sqrt(gx*gx + gz*gz);
        h = Terrain::mtnH(x, z); if (h < 3 || gl < 0.10) break;
        const double nx = -gx / gl, nz = -gz / gl;
        if (i == 0){ dx = nx; dz = nz; } else { dx = 0.6 * dx + 0.4 * nx; dz = 0.6 * dz + 0.4 * nz; const double l = std::sqrt(dx*dx + dz*dz); if (l > 1e-6){ dx /= l; dz /= l; } }
        x += dx * 5; z += dz * 5;
    }
    h1 = Terrain::mtnH(x, z); if (h1 < 0) h1 = h; return ox.size() >= 14;
}

static void plan(){
    gFallOn = false; PX.clear(); PZ.clear(); if (Terrain::MTN_H.empty()) return;
    double best = -1e9; std::vector<float> ox, oz;
    for (int ai = 0; ai < 360; ai++) for (double r = Terrain::MTN_R0 + 20; r <= Terrain::MTN_R0 + 320; r += 30){
        const double a = ai * Road::PI / 180, sx = std::cos(a) * r, sz = std::sin(a) * r;
        const double hs = Terrain::mtnH(sx, sz); if (hs < 130 || hs > 300) continue;
        double h0, h1; if (!trace(sx, sz, ox, oz, h0, h1)) continue;
        const double drop = h0 - h1, len = 5.0 * (double)ox.size(), slope = drop / len; if (drop < 90 || slope < 0.32) continue;
        double sc = std::min(drop, 220.0) + 120.0 * std::min(slope, 0.8) - 0.10 * (r - Terrain::MTN_R0);
        if (Terrain::gLake.on){ const double dl = std::hypot(ox.back() - Terrain::gLake.x, oz.back() - Terrain::gLake.z); sc += 120.0 * std::exp(-dl / 350.0); }   // best: it runs down towards the lake
        if (sc > best){ best = sc; PX = ox; PZ = oz; }
    }
    if (PX.size() < 14) { PX.clear(); PZ.clear(); return; }
    for (int pass = 0; pass < 3; pass++){ std::vector<float> a = PX, b = PZ;
        for (size_t i = 1; i + 1 < PX.size(); i++){ PX[i] = 0.25f * a[i-1] + 0.5f * a[i] + 0.25f * a[i+1]; PZ[i] = 0.25f * b[i-1] + 0.5f * b[i] + 0.25f * b[i+1]; } }
    gFallOn = true;
}

// is (x, z) within r metres of the stream? (used to keep trees out of the water)
static bool nearFall(float x, float z, float r){
    if (!gFallOn) return false; const float r2 = r * r;
    for (size_t i = 0; i < PX.size(); i++){ const float dx = PX[i] - x, dz = PZ[i] - z; if (dx*dx + dz*dz < r2) return true; }
    return false;
}

} // namespace NatureFx
