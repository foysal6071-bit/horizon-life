// Sunny Drift - what the tyres leave behind: black skid marks on the tarmac, white tyre smoke when a tyre really slides,
// and a dust trail behind the wheels on the verge / grass / dirt track. Everything is driven by the real slip of the physics model
// (Veh::step) and by the surface under EACH tyre. Cheap: one ring-buffer mesh (skid marks) + <= 256 point sprites (smoke / dust), 2 draw calls.
#pragma once
#include <GLES3/gl3.h>
#include <cmath>
#include <cstdlib>
#include <vector>
#include "car_core.h"

namespace TyreFx {

struct Contact { double x, z, y, clear, mu, rr; bool onRoad, onTrack, onDeck; };   // one tyre: world position, ground height, distance from the road edge, grip, surface class

static const char* MARK_VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in vec2 ua; uniform mat4 uVP; out vec2 v;
void main(){ v = ua; gl_Position = uVP * vec4(p, 1.0); }
)GLSL";
static const char* MARK_FS = R"GLSL(#version 300 es
precision mediump float; in vec2 v; out vec4 o;
void main(){ float a = v.y * (1.0 - smoothstep(0.55, 1.0, abs(v.x))); o = vec4(0.015, 0.015, 0.018, a); }
)GLSL";
static const char* PUFF_VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in float sz; layout(location=2) in vec4 col;
uniform mat4 uVP; uniform float uScale; out vec4 vc;
void main(){ vec4 c = uVP * vec4(p, 1.0); vc = col; gl_Position = c; gl_PointSize = clamp(sz * uScale / max(c.w, 0.5), 1.0, 72.0); }
)GLSL";
static const char* PUFF_FS = R"GLSL(#version 300 es
precision mediump float; in vec4 vc; out vec4 o;
void main(){ float d = length(gl_PointCoord - 0.5) * 2.0; float a = (1.0 - smoothstep(0.15, 1.0, d)); o = vec4(vc.rgb, vc.a * a * a); }
)GLSL";

// ---------- skid mark ring buffer: one segment = quad (2 triangles) = 6 vertices of (x, y, z, across, alpha) ----------
static const int MARK_CAP = 2400, MARK_V = 6, MARK_F = 5;
static GLuint gMarkProg = 0, gMarkVAO = 0, gMarkVBO = 0, gPuffProg = 0, gPuffVAO = 0, gPuffVBO = 0;
static GLint uM_VP, uP_VP, uP_Scale;
static int gMarkHead = 0, gMarkCount = 0;
struct Trail { bool on = false; double x = 0, z = 0, y = 0, a = 0, ux = 0, uz = 0; };   // last point of the mark being laid by one tyre (+ its side vector)
static Trail gTrail[4];

struct Puff { float x, y, z, vx, vy, vz, age, life, s0, s1, a0, r, g, b; };
static const int PUFF_CAP = 256; static Puff gPuff[PUFF_CAP]; static int gPuffN = 0; static double gAcc[4] = {0, 0, 0, 0}; static uint32_t gRng = 12345u;
static float rnd(){ gRng = gRng * 1664525u + 1013904223u; return (gRng >> 8) / 16777216.f; }

static void init(){
    auto sh = [](GLenum t, const char* s){ GLuint h = glCreateShader(t); glShaderSource(h, 1, &s, nullptr); glCompileShader(h); return h; };
    auto prog = [&](const char* vs, const char* fs){ GLuint p = glCreateProgram(); glAttachShader(p, sh(GL_VERTEX_SHADER, vs)); glAttachShader(p, sh(GL_FRAGMENT_SHADER, fs)); glLinkProgram(p); return p; };
    gMarkProg = prog(MARK_VS, MARK_FS); uM_VP = glGetUniformLocation(gMarkProg, "uVP");
    gPuffProg = prog(PUFF_VS, PUFF_FS); uP_VP = glGetUniformLocation(gPuffProg, "uVP"); uP_Scale = glGetUniformLocation(gPuffProg, "uScale");
    glGenVertexArrays(1, &gMarkVAO); glBindVertexArray(gMarkVAO);
    glGenBuffers(1, &gMarkVBO); glBindBuffer(GL_ARRAY_BUFFER, gMarkVBO); glBufferData(GL_ARRAY_BUFFER, (size_t)MARK_CAP * MARK_V * MARK_F * 4, nullptr, GL_DYNAMIC_DRAW);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, MARK_F * 4, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, MARK_F * 4, (void*)12);
    glGenVertexArrays(1, &gPuffVAO); glBindVertexArray(gPuffVAO);
    glGenBuffers(1, &gPuffVBO); glBindBuffer(GL_ARRAY_BUFFER, gPuffVBO); glBufferData(GL_ARRAY_BUFFER, PUFF_CAP * 8 * 4, nullptr, GL_STREAM_DRAW);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 32, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 1, GL_FLOAT, GL_FALSE, 32, (void*)12);
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 4, GL_FLOAT, GL_FALSE, 32, (void*)16);
    glBindVertexArray(0);
}
static void reset(){ for (Trail& t : gTrail) t.on = false; gPuffN = 0; }          // (after "reset car": no mark joins the old and the new place)

static void addSeg(const Trail& a, double x, double z, double y, double alpha, double ux, double uz){
    const double hw = 0.15;                                                                   // tyre width ~ 0.3 m
    float v[MARK_V * MARK_F]; int k = 0;
    auto P = [&](double px, double py, double pz, float across, double al){ v[k++] = (float)px; v[k++] = (float)py; v[k++] = (float)pz; v[k++] = across; v[k++] = (float)al; };
    const double ax = a.x + a.ux * hw, az = a.z + a.uz * hw, bx = a.x - a.ux * hw, bz = a.z - a.uz * hw, cx = x + ux * hw, cz = z + uz * hw, dx = x - ux * hw, dz = z - uz * hw;
    P(ax, a.y, az, 1, a.a); P(bx, a.y, bz, -1, a.a); P(cx, y, cz, 1, alpha);
    P(bx, a.y, bz, -1, a.a); P(dx, y, dz, -1, alpha); P(cx, y, cz, 1, alpha);
    glBindBuffer(GL_ARRAY_BUFFER, gMarkVBO);
    glBufferSubData(GL_ARRAY_BUFFER, (size_t)gMarkHead * MARK_V * MARK_F * 4, sizeof(v), v);
    gMarkHead = (gMarkHead + 1) % MARK_CAP; if (gMarkCount < MARK_CAP) gMarkCount++;
}
static void emit(double x, double y, double z, double vx, double vz, double life, double s0, double s1, double a0, float r, float g, float b){
    if (gPuffN >= PUFF_CAP) return;
    gPuff[gPuffN++] = {(float)x, (float)y, (float)z, (float)vx, 0.35f + 0.5f * rnd(), (float)vz, 0.f, (float)life, (float)s0, (float)s1, (float)a0, r, g, b};
}

// call once per physics step (after Veh::step). wheel[i]: i = 0..3 in CarGL's order; fl[i] / ll[i] = the tyre's metres forward / to the left of the car's centre
static void update(const CarState& S, double dt, const Contact* w, const double* fl, const double* ll, bool air){
    if (dt <= 0) return;
    const double sp = std::fabs(S.speed), uA = std::max(S.speed, 2.5);
    const double aF = std::fabs(std::atan2(S.vy + Veh::LA * S.yaw, uA) - S.steerAngle), aR = std::fabs(std::atan2(S.vy - Veh::LB * S.yaw, uA));
    const double latF = sp > 4 ? clampd((aF - 0.15) / 0.22, 0, 1) : 0, latR = sp > 4 ? clampd((aR - 0.15) / 0.22, 0, 1) : 0;
    const double hard = (S.brake > 0.9 && S.speed > 9) ? 1.0 : 0.0;                           // braking at the grip limit
    const double spin = (S.throttle > 0.8 && S.speed > 0 && S.speed < 10 && S.gear <= 2) ? S.throttle * (1 - S.speed / 10) : 0;   // launch wheelspin
    const double c = clampd(S.ay / 6, -1, 1), sH = std::sin(S.heading), cH = std::cos(S.heading);
    for (int i = 0; i < 4; i++){
        const bool front = fl[i] > 0, left = ll[i] > 0;
        double m = front ? std::max(latF, 0.45 * hard) : std::max(std::max(latR, 0.9 * S.hb * (sp > 5 ? 1 : 0)), std::max(0.35 * hard, 0.5 * spin));
        m *= clampd(1 + (left ? -0.4 : 0.4) * c, 0.4, 1.4);                                    // the outer tyre carries more load, so it marks harder
        if (air) m = 0; m = clampd(m, 0, 1);
        const Contact& k = w[i]; Trail& t = gTrail[i];
        // ---- skid mark on the tarmac ----
        if (m > 0.12 && k.onRoad && !k.onDeck){
            const double ux = cH, uz = -sH;                                                    // across the car (its left), unit
            const double al = clampd((m - 0.12) * 1.1, 0, 0.62), y = k.y + 0.012;
            if (!t.on){ t.on = true; t.x = k.x; t.z = k.z; t.y = y; t.a = 0; t.ux = ux; t.uz = uz; }       // starts with alpha 0: soft beginning
            else if ((k.x - t.x) * (k.x - t.x) + (k.z - t.z) * (k.z - t.z) > 0.30 * 0.30){
                addSeg(t, k.x, k.z, y, al, ux, uz); t.x = k.x; t.z = k.z; t.y = y; t.a = al; t.ux = ux; t.uz = uz; }
        } else if (t.on){ t.on = false; }
        // ---- tyre smoke where a tyre really slides on tarmac ----
        if (k.onRoad && m > 0.3){
            gAcc[i] += dt * 38 * m; while (gAcc[i] >= 1){ gAcc[i] -= 1;
                emit(k.x + (rnd() - .5) * 0.3, k.y + 0.12, k.z + (rnd() - .5) * 0.3, S.speed * sH * 0.25 + (rnd() - .5) * 0.8, S.speed * cH * 0.25 + (rnd() - .5) * 0.8,
                     0.9 + 0.7 * rnd(), 0.5, 2.4, 0.30 * m, 0.86f, 0.87f, 0.88f); }
        }
        // ---- dust behind a tyre rolling on the verge / grass / dirt track (rear tyres + a little from the front when sliding) ----
        else if (!k.onRoad && !front && sp > 4 && !air){
            const double soft = k.onTrack ? 1.0 : 0.55;                                         // the dry dirt track throws up more dust than the meadow
            gAcc[i] += dt * (6 + sp * 0.9 + 28 * m) * soft; while (gAcc[i] >= 1){ gAcc[i] -= 1;
                const float r = k.onTrack ? 0.64f : 0.50f, g = k.onTrack ? 0.56f : 0.52f, b = k.onTrack ? 0.42f : 0.36f;
                emit(k.x + (rnd() - .5) * 0.4, k.y + 0.10, k.z + (rnd() - .5) * 0.4, -S.speed * sH * 0.10 + (rnd() - .5) * 1.0, -S.speed * cH * 0.10 + (rnd() - .5) * 1.0,
                     0.9 + 0.8 * rnd(), 0.5, 2.6 + 0.04 * sp, (k.onTrack ? 0.30 : 0.18) * clampd(sp / 14, 0.35, 1.0), r, g, b); }
        }
    }
    // ---- advance the sprites ----
    for (int i = 0; i < gPuffN; ){
        Puff& p = gPuff[i]; p.age += (float)dt;
        if (p.age >= p.life){ p = gPuff[--gPuffN]; continue; }
        p.x += p.vx * (float)dt; p.y += p.vy * (float)dt; p.z += p.vz * (float)dt; p.vx *= 1 - 1.5f * (float)dt; p.vz *= 1 - 1.5f * (float)dt; p.vy *= 1 - 1.2f * (float)dt;
        i++;
    }
}

static void draw(const float* VP, int viewH){
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glDepthMask(GL_FALSE); glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    if (gMarkCount){
        glUseProgram(gMarkProg); glUniformMatrix4fv(uM_VP, 1, GL_FALSE, VP);
        glEnable(GL_POLYGON_OFFSET_FILL); glPolygonOffset(-10.f, -10.f);                      // above the road + its centre line paint
        glBindVertexArray(gMarkVAO); glDrawArrays(GL_TRIANGLES, 0, gMarkCount * MARK_V);
        glDisable(GL_POLYGON_OFFSET_FILL);
    }
    if (gPuffN){
        float buf[PUFF_CAP * 8];
        for (int i = 0; i < gPuffN; i++){
            const Puff& p = gPuff[i]; const float k = p.age / p.life, e = 1 - (1 - k) * (1 - k);
            const float a = p.a0 * (k < 0.15f ? k / 0.15f : 1.f) * (1 - k);                       // quick fade-in, then thins out
            float* o = buf + i * 8; o[0] = p.x; o[1] = p.y; o[2] = p.z; o[3] = p.s0 + (p.s1 - p.s0) * e; o[4] = p.r; o[5] = p.g; o[6] = p.b; o[7] = a;
        }
        glUseProgram(gPuffProg); glUniformMatrix4fv(uP_VP, 1, GL_FALSE, VP); glUniform1f(uP_Scale, viewH * 0.915f);    // fov 1.0 rad: pixels per metre at 1 m = H / (2 tan(0.5))
        glBindVertexArray(gPuffVAO); glBindBuffer(GL_ARRAY_BUFFER, gPuffVBO); glBufferSubData(GL_ARRAY_BUFFER, 0, gPuffN * 32, buf);
        glDrawArrays(GL_POINTS, 0, gPuffN);
    }
    glBindVertexArray(0); glDepthMask(GL_TRUE); glDisable(GL_BLEND);
}

} // namespace TyreFx
