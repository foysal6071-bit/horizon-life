// Sunny Drift - GL-free helpers for the road renderer: frustum chunk culling + baked noise textures.
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <vector>

namespace RoadCull {

// a chunk = a run of consecutive indices (strips are lofted along the road, so neighbouring triangles are close together)
struct Chunk { uint32_t first, count; float mn[3], mx[3]; };
static const uint32_t CHUNK_IDX = 1800;                         // 600 triangles per chunk

// v = interleaved floats (pos3 uv2 n3 = 8 floats), idx = triangle indices
static std::vector<Chunk> build(const float* v, const std::vector<uint32_t>& idx, size_t stride = 8, uint32_t chunkIdx = CHUNK_IDX){
    std::vector<Chunk> out;
    for (size_t f = 0; f < idx.size(); f += chunkIdx){
        Chunk c; c.first = (uint32_t)f; c.count = (uint32_t)std::min<size_t>(chunkIdx, idx.size() - f);
        for (int k = 0; k < 3; k++){ c.mn[k] = 1e30f; c.mx[k] = -1e30f; }
        for (uint32_t i = 0; i < c.count; i++){
            const float* p = v + (size_t)idx[f + i] * stride;
            for (int k = 0; k < 3; k++){ c.mn[k] = std::min(c.mn[k], p[k]); c.mx[k] = std::max(c.mx[k], p[k]); }
        }
        c.mn[1] -= 1.f; c.mx[1] += 1.f;                           // small safety margin for polygon offset / bumps
        out.push_back(c);
    }
    return out;
}

// six frustum planes (a,b,c,d; inside = a*x+b*y+c*z+d >= 0) from a column-major view-projection matrix
static void planes(const float* m, float pl[6][4]){
    for (int i = 0; i < 4; i++){
        pl[0][i] = m[i*4+3] + m[i*4+0]; pl[1][i] = m[i*4+3] - m[i*4+0];
        pl[2][i] = m[i*4+3] + m[i*4+1]; pl[3][i] = m[i*4+3] - m[i*4+1];
        pl[4][i] = m[i*4+3] + m[i*4+2]; pl[5][i] = m[i*4+3] - m[i*4+2];
    }
}
static bool visible(const Chunk& c, const float pl[6][4]){
    for (int i = 0; i < 6; i++){
        const float* q = pl[i];
        float x = q[0] >= 0 ? c.mx[0] : c.mn[0], y = q[1] >= 0 ? c.mx[1] : c.mn[1], z = q[2] >= 0 ? c.mx[2] : c.mn[2];
        if (q[0]*x + q[1]*y + q[2]*z + q[3] < 0) return false;
    }
    return true;
}
// merge neighbouring visible chunks into as few index ranges as possible
static void ranges(const std::vector<Chunk>& ch, const float pl[6][4], std::vector<std::pair<uint32_t,uint32_t>>& out){
    out.clear();
    for (const Chunk& c : ch){
        if (!visible(c, pl)) continue;
        if (!out.empty() && out.back().first + out.back().second == c.first) out.back().second += c.count;
        else out.push_back({c.first, c.count});
    }
}

// ---------- baked noise ----------
static inline uint32_t ihash(uint32_t x){ x ^= x >> 16; x *= 0x7feb352dU; x ^= x >> 15; x *= 0x846ca68bU; x ^= x >> 16; return x; }

// 256x256 RGBA white noise (each texel independent); bilinear filtering turns it into value noise
static std::vector<uint8_t> whiteNoise(int S = 256){
    std::vector<uint8_t> d((size_t)S * S * 4); uint32_t s = 0x9e3779b9u;
    for (size_t i = 0; i < d.size(); i++){ s = ihash(s + 0x6d2b79f5u); d[i] = (uint8_t)(s >> 24); }
    return d;
}
// tileable fbm, 4 independent channels. Octave k has 8*2^k lattice cells across the texture, so 256 px always wraps cleanly
static std::vector<uint8_t> tileFbm(int S = 256){
    std::vector<uint8_t> d((size_t)S * S * 4);
    for (int ch = 0; ch < 4; ch++){
        std::vector<float> acc((size_t)S * S, 0.f); float amp = 0.5f;
        for (int o = 0; o < 4; o++, amp *= 0.5f){
            const int cells = 8 << o; std::vector<float> lat((size_t)cells * cells);
            for (int j = 0; j < cells; j++) for (int i = 0; i < cells; i++)
                lat[(size_t)j * cells + i] = (ihash((uint32_t)(i + j * 131 + o * 7919 + ch * 104729) * 2654435761u + 77u) >> 8) / 16777216.f;
            for (int y = 0; y < S; y++) for (int x = 0; x < S; x++){
                float fx = (float)x * cells / S, fy = (float)y * cells / S; int ix = (int)fx, iy = (int)fy; fx -= ix; fy -= iy;
                fx = fx*fx*(3.f - 2.f*fx); fy = fy*fy*(3.f - 2.f*fy);
                const int x1 = (ix + 1) % cells, y1 = (iy + 1) % cells;
                float a = lat[(size_t)iy*cells+ix], b = lat[(size_t)iy*cells+x1], c = lat[(size_t)y1*cells+ix], e = lat[(size_t)y1*cells+x1];
                acc[(size_t)y * S + x] += amp * ((a + (b - a) * fx) * (1.f - fy) + (c + (e - c) * fx) * fy);
            }
        }
        for (size_t i = 0; i < acc.size(); i++){ float v = acc[i] / 0.9375f; d[i*4 + ch] = (uint8_t)std::min(255.f, std::max(0.f, v * 255.f + 0.5f)); }
    }
    return d;
}

} // namespace RoadCull
