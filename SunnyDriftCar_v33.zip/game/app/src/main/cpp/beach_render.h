// Sunny Drift - OpenGL ES 3 drawing of the beach props + the world boundary fence (models and layout: beach.h).
//  One static vertex buffer (pos, normal, colour), one index buffer split into chunks: chunk 0 = the beach, the others = 4 degree sections of the fence.
//  Only chunks near the camera are drawn. Lighting / fog use the same sun + haze as the pine forest.
#pragma once
#include <GLES3/gl3.h>
#include "beach.h"
#include "road_render.h"      // RoadGL::makeProg

namespace BeachGL {

static const char* VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in vec3 n; layout(location=2) in vec3 c;
uniform mat4 uVP; out vec3 vc; out vec3 vn; out vec3 wp;
void main(){ wp = p; vn = n; vc = c; gl_Position = uVP * vec4(p, 1.0); }
)GLSL";
static const char* FS = R"GLSL(#version 300 es
precision highp float;
in vec3 vc; in vec3 vn; in vec3 wp; uniform vec3 uCam; out vec4 o;
void main(){
  vec3 V = uCam - wp; float dist = length(V); V /= dist;
  vec3 N = normalize(vn); if (dot(N, V) < 0.0) N = -N;                       // double sided
  vec3 L = normalize(vec3(0.4, 0.8, 0.3));
  float nd = dot(N, L); float d = max(nd, 0.0), wrap = max(nd*0.5 + 0.5, 0.0);
  vec3 sky = vec3(0.50, 0.66, 0.95), gnd = vec3(0.45, 0.40, 0.30);
  vec3 amb = mix(gnd, sky, N.y*0.5 + 0.5) * 0.80 + vec3(0.05);
  vec3 col = vc * (amb + vec3(1.10, 1.00, 0.84)*(0.60*d + 0.30*wrap));
  float fog = 1.0 - exp(-pow(dist/2850.0, 1.35));
  o = vec4(mix(col, vec3(0.72, 0.87, 0.98), clamp(fog, 0.0, 1.0)), 1.0);
}
)GLSL";

static GLuint gProg = 0, gVAO = 0, gVBO = 0, gIBO = 0; static GLint uVP = -1, uCam = -1; static bool gOk = false;

static void init(){
    if (Beach::gMesh.i.empty()) return;
    gProg = RoadGL::makeProg(VS, FS); if (!gProg) return;
    uVP = glGetUniformLocation(gProg, "uVP"); uCam = glGetUniformLocation(gProg, "uCam");
    glGenVertexArrays(1, &gVAO); glBindVertexArray(gVAO);
    glGenBuffers(1, &gVBO); glBindBuffer(GL_ARRAY_BUFFER, gVBO); glBufferData(GL_ARRAY_BUFFER, Beach::gMesh.v.size() * 4, Beach::gMesh.v.data(), GL_STATIC_DRAW);
    for (int a = 0; a < 3; a++){ glEnableVertexAttribArray(a); glVertexAttribPointer(a, 3, GL_FLOAT, GL_FALSE, 36, (void*)(size_t)(a * 12)); }
    glGenBuffers(1, &gIBO); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gIBO); glBufferData(GL_ELEMENT_ARRAY_BUFFER, Beach::gMesh.i.size() * 4, Beach::gMesh.i.data(), GL_STATIC_DRAW);
    glBindVertexArray(0); gOk = true;
}

static void draw(const float* VP, const float* eye){
    if (!gOk) return;
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glDisable(GL_BLEND);
    glUseProgram(gProg); glUniformMatrix4fv(uVP, 1, GL_FALSE, VP); glUniform3fv(uCam, 1, eye);
    glBindVertexArray(gVAO);
    for (size_t k = 0; k < Beach::gChunks.size(); k++){
        const Beach::Chunk& c = Beach::gChunks[k];
        const float dx = c.cx - eye[0], dz = c.cz - eye[2], lim = (k == 0 ? 1400.f : 900.f) + c.rad;
        if (dx * dx + dz * dz > lim * lim) continue;
        glDrawElements(GL_TRIANGLES, (GLsizei)c.count, GL_UNSIGNED_INT, (void*)(size_t)(c.first * 4));
    }
    glBindVertexArray(0);
}

} // namespace BeachGL
