const fs=require('fs'); eval(fs.readFileSync('/tmp/eq/veh_only.js','utf8')+';globalThis.Veh=Veh;');
const S={pos:{x:0,z:0},heading:0,speed:0,vy:0,yaw:0,steer:0,steerAngle:0,throttle:0,brake:0,ax:0,ay:0,axS:0,revTimer:0,gear:1,rpm:900,shiftT:0,ayLim:9,hb:0,drift:0,fd:0,slope:0,reverse:false,braking:false,handOn:false};
const surf={mu:1.15,rr:0.028}; const out=[];
for(let i=0;i<6000;i++){
  const t=i*0.016;
  const inp={gas:t<40||(t>60),brake:(t>45&&t<52),left:Math.sin(t*0.7)>0.4,right:Math.sin(t*0.7)<-0.6,hand:(t>20&&t<23)||(t>70&&t<72),sens:1.8,analog:null};
  S.slope=0.05*Math.sin(t*0.3);
  if(t>30&&t<36){surf.mu=0.85;surf.rr=0.088;}else{surf.mu=1.15;surf.rr=0.028;}
  Veh.step(S,inp,surf,0.016);
  if(i%100==0)out.push([S.pos.x,S.pos.z,S.heading,S.speed,S.vy,S.yaw,S.rpm,S.gear,S.drift].map(v=>v.toFixed(6)).join(' '));
}
console.log(out.join('\n'));
