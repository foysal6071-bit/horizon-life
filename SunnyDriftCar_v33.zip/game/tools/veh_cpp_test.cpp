#include "car_core_v18_html_port.h"   // the HTML-parity port (the game itself now uses the v19 realistic model in car_core.h)
int main(){
  CarState S; Surface surf; Input inp; inp.sens=1.8;
  for(int i=0;i<6000;i++){
    double t=i*0.016;
    inp.gas=t<40||(t>60); inp.brake=(t>45&&t<52); inp.left=sin(t*0.7)>0.4; inp.right=sin(t*0.7)<-0.6; inp.hand=(t>20&&t<23)||(t>70&&t<72);
    S.slope=0.05*sin(t*0.3);
    if(t>30&&t<36){surf.mu=0.85;surf.rr=0.088;}else{surf.mu=1.15;surf.rr=0.028;}
    Veh::step(S,inp,surf,0.016);
    if(i%100==0)printf("%.6f %.6f %.6f %.6f %.6f %.6f %.6f %d %.6f\n",S.x,S.z,S.heading,S.speed,S.vy,S.yaw,S.rpm,S.gear,S.drift);
  }
}
