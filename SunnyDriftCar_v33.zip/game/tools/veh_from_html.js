const Veh = (()=>{
  const clamp=(v,a,b)=>Math.min(Math.max(v,a),b);
  const G=9.81, MASS=1650, WHEELBASE=2.8, CG_A=1.3, WR=0.40;
  const RPM_K = 1/(0.10472*WR);                              // rpm = speed * overall ratio * RPM_K
  const VMAX = 220/3.6;                                      // TOP SPEED: 220 km/h
  const IDLE=900, REDLINE=7000, TMAX=400, EFF=0.9, ENGINE_BRAKE=35;
  const R6 = REDLINE/(VMAX*RPM_K);                           // 6th gear reaches the redline exactly at 220 km/h
  const RATIOS=[0, R6*3.297, R6*2.286, R6*1.670, R6*1.319, R6*1.121, R6];
  const REV_MAX=20/3.6, REV_FORCE=3200;                      // REVERSE top speed: 20 km/h
  const BRAKE_DECEL=17.0;                                    // powerful brakes (~1.4 g), ABS limited by grip
  const K_AERO=0.40, K_DOWN=1.8;                            // more downforce -> real grip at 200 km/h
  const TYRE_K=1.05, TYRE_B=16, TYRE_C=1.35, DRIVE_REAR=0.45;  // tyre grip, stiffness, shape, rear drive share
  const LA=1.35, LB=1.45, IZ=3000, HCG=0.45;                  // CG to front/rear axle, yaw inertia, CG height                             // 0.5*rho*CdA, 0.5*rho*ClA
  const STEER_LOCK=0.55, STEER_RATE=3.6, STEER_RETURN=6.0;
  const MAX_SPEED = REDLINE/(RATIOS[6]*RPM_K);               // ~64 m/s = 232 km/h at the limiter in 6th
  const torque = rpm => TMAX*clamp(1-0.55*Math.pow((rpm-4800)/4200,2),0.3,1)*clamp((REDLINE+300-rpm)/300,0,1);

  function step(S, inp, surf, dt){
    // ---- pedals: S brakes while rolling forward, becomes reverse only after standing still ----
    const vx0 = S.speed;
    let thrT=0, brkT=0, rev=false;
    if (inp.gas && inp.brake) brkT=1;
    else if (inp.gas){ if (vx0 < -0.8) brkT=1; else thrT=1; }
    else if (inp.brake){
      if (vx0 > 0.8) brkT=1;
      else { S.revTimer += dt; if (S.revTimer>0.3 || vx0<-0.8){ rev=true; thrT=1; } else brkT=1; }
    }
    if (!inp.brake || inp.gas) S.revTimer = 0;
    if (inp.hand){   // handbrake: holds the car when slow; at speed it unloads the rear tyres -> DRIFT (keep gas down to hold the slide)
      if (S.speed>6){ brkT = inp.brake ? 1 : (inp.gas ? 0 : ((inp.left||inp.right) ? 0.18 : 0.45)); }
      else { brkT = 1; thrT = 0; rev = false; }
    }   // handbrake: holds the car; at speed it tightens the turn (no sliding)
    S.reverse = rev;
    S.throttle += (thrT-S.throttle)*(1-Math.exp(-dt*(thrT>S.throttle?7:14)));
    S.brake    += (brkT-S.brake)   *(1-Math.exp(-dt*(brkT>S.brake?22:20)));
    S.braking = S.brake>0.25;
    S.handOn = !!inp.hand;
    S.hb += (((inp.hand && S.speed>5)?1:0) - S.hb)*(1-Math.exp(-dt*6));
    S.drift = S.drift||0;
    S.rearSpin = false;

    const av = Math.abs(S.speed);

    // ---- steering input (slower at speed, self-centring) ----
    const steerIn = (typeof inp.analog==='number') ? inp.analog : (inp.left?1:0)-(inp.right?1:0);   // analog = steering wheel (−1 right … +1 left)
    const rate = ((steerIn===0 || Math.sign(steerIn)!==Math.sign(S.steer)) ? STEER_RETURN : STEER_RATE)*(inp.sens||1)/(1+av/120);
    const dS = steerIn-S.steer;
    S.steer += Math.sign(dS)*Math.min(Math.abs(dS), rate*dt);

    // ---- automatic gearbox ----
    S.shiftT = Math.max(0, S.shiftT-dt);
    if (S.reverse || S.speed < -0.5) S.gear = 0;
    else {
      if (S.gear===0) S.gear = 1;
      const sp = Math.max(S.speed,0), rpmG = sp*RATIOS[S.gear]*RPM_K;
      if (S.shiftT<=0){
        if (S.gear<6 && (rpmG>6600 || (rpmG>5200 && S.throttle<0.15))){ S.gear++; S.shiftT=0.2; }
        else if (S.gear>1 && (rpmG<2300 || (S.throttle>0.9 && rpmG<3300)) && sp*RATIOS[S.gear-1]*RPM_K<6300){ S.gear--; S.shiftT=0.15; }
      }
    }
    const gearR = S.gear===0 ? 14 : RATIOS[S.gear];
    const rpmW = av*gearR*RPM_K, clutch = 1-clamp(av/6,0,1);
    const rpmTgt = Math.max(rpmW, IDLE + S.throttle*3200*clutch);
    S.rpm += (rpmTgt-S.rpm)*(1-Math.exp(-dt*(rpmTgt>S.rpm?10:6)));
    S.rpm = Math.min(S.rpm, REDLINE+300);

    // ---- engine force ----
    let Fdrive=0;
    if (S.throttle>0.001){
      if (S.reverse) Fdrive = -S.throttle*REV_FORCE*clamp((REV_MAX+S.speed)/3,0,1);
      else Fdrive = S.throttle*torque(Math.max(S.rpm,2800))*RATIOS[S.gear]*EFF/WR*(S.shiftT>0 ? 1-0.5*Math.sin(Math.PI*(1-Math.min(S.shiftT/0.2,1))) : 1);   // smooth torque dip while shifting (no hard cut = no jerk)
    }

    if (!S.reverse) Fdrive *= clamp((VMAX-S.speed)/1.2,0,1);        // power fades out smoothly into the 220 km/h limit

    S.fd = (S.fd||0) + (Fdrive-(S.fd||0))*(1-Math.exp(-dt*14)); Fdrive = S.fd;      // smooth drive force: no forward/back kick

    // ---- grip budget (friction circle) -> steering authority ----
    const gripN0 = surf.mu*TYRE_K*(MASS*G + K_DOWN*S.speed*S.speed);
    const Flong = Math.max(Math.min(Math.abs(Fdrive),0.8*gripN0), S.brake*Math.min(BRAKE_DECEL*MASS,0.97*gripN0));
    S.ayLim = Math.sqrt(Math.max(gripN0*gripN0-Flong*Flong, 0.04*gripN0*gripN0))/MASS*0.97;   // max lateral accel (m/s^2)
    const sensK = clamp(0.7+0.3*(inp.sens||1),0.85,1.6);
    // steering lock shrinks with speed, but far less than before -> the car still answers at 200 km/h
    const lockSpeed = sensK*STEER_LOCK/(1+Math.pow(av/46,2));
    const lockGrip  = 0.06*sensK + Math.atan(WHEELBASE*S.ayLim*1.1/Math.max(S.speed*S.speed,1));
    const dDrv = S.steer*Math.min(lockSpeed, lockGrip);
    let delta = dDrv;

    // ---- integrate: dynamic bicycle model (slip angles + saturating tyres), kinematic below ~4 m/s ----
    const N = Math.max(1, Math.ceil(dt/0.005)), h = dt/N;
    let axAcc = 0;
    for (let it=0; it<N; it++){
      const vx = S.speed, sp = Math.abs(vx), sgn = clamp(vx/0.4,-1,1);
      const wDyn = clamp((vx-3)/4,0,1);                                          // 0 = kinematic (crawling / reversing), 1 = full tyre model
      const down = K_DOWN*vx*vx;
      const mu = surf.mu*TYRE_K;
      const gripN = surf.mu*(MASS*G + down);
      const wasDrift = S.drift>0.3;
      const Fd = clamp(Fdrive, -(wasDrift?1.0:0.62)*gripN, (wasDrift?1.0:0.62)*gripN);   // traction control relaxes once the car is sliding
      const Fb = S.brake*Math.min(BRAKE_DECEL*MASS, 0.97*gripN);               // ABS: no lock-up
      let Fres = -sgn*(surf.rr*MASS*G + K_AERO*vx*vx + MASS*Math.abs(S.ay)*0.04);
      if (S.gear>0){
        const eb = clamp(1-S.throttle/0.15,0,1)*clamp(1-S.brake/0.15,0,1);
        Fres -= sgn*clamp(sp/2,0,1)*ENGINE_BRAKE*RATIOS[S.gear]*(S.rpm/REDLINE)/WR*eb;
      }
      const Fg = -MASS*G*(S.slope||0);
      const Fx = Fd - sgn*Fb + Fres + Fg;

      // --- per-axle load (weight transfer: braking loads the nose, accelerating loads the tail) ---
      const dFz = clamp(MASS*(S.axS||0)*HCG/WHEELBASE, -0.22*MASS*G, 0.22*MASS*G);
      const FzF = Math.max(MASS*G*LB/WHEELBASE - dFz + down*0.40, 800);
      const FzR = Math.max(MASS*G*LA/WHEELBASE + dFz + down*0.60, 800);
      const uA = Math.max(vx, 2.5);
      const beta = Math.atan2(S.vy, uA);
      // --- friction circle per axle: drive / brake force eats lateral grip ---
      const usF = clamp(Fb*0.70/(mu*FzF), 0, 0.95);
      const usR = clamp(0.6*Math.abs(Fd*DRIVE_REAR - sgn*Fb*0.30)/(mu*FzR), 0, 0.9);
      const capF = Math.sqrt(1-usF*usF);
      const capR = Math.sqrt(1-usR*usR)*(1-0.55*S.hb)*(1+1.3*clamp((Math.abs(beta)-0.55)/0.4,0,1));   // handbrake: rear tyres lose side grip; arcade anti-spin when the car is nearly sideways
      // --- driver steering + counter-steer assist (like FH5 steering assist) ---
      const wAs = clamp((Math.abs(beta)-0.08)/0.15,0,1)*0.85*wDyn;
      delta = clamp(dDrv + wAs*clamp(beta,-0.7,0.7), -0.65, 0.65);
      // --- slip angles and tyre forces ---
      const aF = Math.atan2(S.vy + LA*S.yaw, uA) - delta;
      const aR = Math.atan2(S.vy - LB*S.yaw, uA);
      const FyF = -mu*FzF*capF*Math.sin(TYRE_C*Math.atan(TYRE_B*aF));
      const FyR = -mu*FzR*capR*Math.sin(TYRE_C*Math.atan(TYRE_B*aR));
      const cd = Math.cos(delta), sd = Math.sin(delta);

      S.speed += (Fx - FyF*sd*wDyn)/MASS*h;
      S.speed = clamp(S.speed, -REV_MAX, VMAX*(1 + 0.03*clamp(-(S.slope||0)*8,0,1)));
      axAcc += Fx/MASS;
      S.vy  += (FyF*cd + FyR)/MASS*h*wDyn;
      S.yaw += ((LA*FyF*cd - LB*FyR)/IZ - 1.4*S.yaw)*h*wDyn;
      // low speed: plain kinematic steering so parking / reversing stay easy
      if (wDyn < 1){
        const rK = S.speed*Math.tan(delta)/WHEELBASE;
        S.yaw += (rK-S.yaw)*(1-Math.exp(-h/0.05))*(1-wDyn);
        S.vy  *= Math.exp(-8*(1-wDyn)*h);
      }
      S.yaw = clamp(S.yaw, -2.6, 2.6);
      if (Math.abs(S.speed)<0.08 && S.throttle<0.02 && (Math.abs(S.slope||0) < 0.3 || S.brake > 0.3 || S.handOn)){ S.speed=0; S.vy=0; S.yaw=0; }
      { const dH = S.yaw*h; S.heading += dH;
        const a = dH*wDyn, c = Math.cos(a), sn = Math.sin(a), sp0 = S.speed;   // the car turns but its momentum keeps going -> it slides
        S.speed = sp0*c + S.vy*sn; S.vy = -sp0*sn + S.vy*c; }
      const sH=Math.sin(S.heading), cH=Math.cos(S.heading);
      S.pos.x += (S.speed*sH + S.vy*cH)*h;
      S.pos.z += (S.speed*cH - S.vy*sH)*h;
    }
    S.steerAngle = clamp(delta,-0.6,0.6);                                       // front wheels show the real (counter-)steer
    // drift amount (smoke, tyre marks, sound) comes from the REAL rear-tyre slip angle
    { const bR = Math.abs(Math.atan2(S.vy - LB*S.yaw, Math.max(S.speed,2.5)));
      const tgt = S.speed>5 ? clamp((bR-0.12)/0.2,0,1) : 0;
      S.drift += (tgt-S.drift)*(1-Math.exp(-dt*(tgt>S.drift?10:3))); }
    S.ax = axAcc/N;
    S.axS = (S.axS||0) + (S.ax-(S.axS||0))*(1-Math.exp(-dt*5));          // filtered acceleration for the body pitch + load transfer
    S.ay = S.speed*S.yaw;               // > 0 = pushed to the left (a left-hand corner)
  }
  return { step, MAX_SPEED, CG_A };
})();

