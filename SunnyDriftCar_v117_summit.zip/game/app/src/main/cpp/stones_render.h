// Sunny Drift - small stones scattered over the alpine meadow on the middle slopes of the big mountain (cosmetic, no collision).
//  * placed once at start-up (CPU): clusters of grey-brown stones, a few big ones with pebbles round them, only on gentle meadow ground
//    (Terrain::alpineBand), never on the road / verge, the summit or beside the houses
//  * one low-poly stone mesh (flat-shaded, lumpy icosphere, 80 triangles) drawn instanced: x, y, z, size / rotation, tone, flatness
//  * stones farther than ~230 m or outside the view are skipped on the CPU
#pragma once
#include <GLES3/gl3.h>
#include <cmath>
#include <cstdint>
#include <random>
#include <vector>
#include <algorithm>
#include "sun_light.h"
#include "terrain.h"
#include "village.h"

namespace StonesGL {

static GLuint gProg = 0, gVao = 0, gVbo = 0, gInst = 0; static GLint uVP = -1, uCam = -1; static GLsizei gVerts = 0; static bool gOk = false;
struct Stone { float x, y, z, s, rot, tone, flat, seed; };
static std::vector<Stone> gSt;
static const float MAX_DIST = 230.f;

static const char* VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in vec3 n;
layout(location=2) in vec4 ia; layout(location=3) in vec4 ib;          // ia = (x, y, z, size)   ib = (yaw, tone, flatness, seed)
uniform mat4 uVP;
out vec3 vn; out vec3 wp; out float vT; out float vS;
void main(){
  float cs = cos(ib.x), sn = sin(ib.x); mat3 Ry = mat3(cs, 0., -sn, 0., 1., 0., sn, 0., cs);
  vec3 q = vec3(p.x, p.y * ib.z, p.z) * ia.w;
  wp = Ry * q + ia.xyz; vn = normalize(Ry * vec3(n.x, n.y / max(ib.z, 0.3), n.z)); vT = ib.y; vS = ib.w;
  gl_Position = uVP * vec4(wp, 1.0);
}
)GLSL";

static const char* FS = R"GLSL(#version 300 es
precision highp float;
in vec3 vn; in vec3 wp; in float vT; in float vS;
uniform vec3 uCam;
out vec4 o;
float h3(vec3 p){ p = fract(p * 0.1031); p += dot(p, p.yzx + 33.33); return fract((p.x + p.y) * p.z); }
void main(){
  vec3 V = uCam - wp; float dist = length(V); V /= dist;
  vec3 N = normalize(vn);
  float grain = h3(floor(wp * 9.0)) * 0.5 + h3(floor(wp * 3.0)) * 0.5;
  vec3 alb = mix(vec3(0.43, 0.42, 0.40), vec3(0.62, 0.58, 0.50), vT) * (0.80 + 0.35 * grain);          // grey granite to warm limestone
  alb = mix(alb, vec3(0.22, 0.33, 0.13), clamp(N.y, 0.0, 1.0) * 0.30 * step(0.5, fract(vS * 7.3)));        // some stones wear a little moss on top
  vec3 L = SUNL;
  float nd = dot(N, L); float d = max(nd, 0.0), wrap = max(nd * 0.6 + 0.4, 0.0);
  vec3 amb = mix(vec3(0.24, 0.28, 0.16), vec3(0.50, 0.66, 0.95), N.y * 0.5 + 0.5) * 0.85;
  vec3 col = alb * (amb + vec3(1.00, 0.93, 0.80) * (0.85 * d + 0.24 * wrap));
  float fog = 1.0 - exp(-pow(dist / 2850.0, 1.35));
  col = mix(col, vec3(0.72, 0.87, 0.98), clamp(fog, 0.0, 1.0));
  o = vec4(col, 1.0);
}
)GLSL";

static GLuint compile(GLenum t, const char* s){ GLuint x = glCreateShader(t); SunLight::shaderSource(x, s); glCompileShader(x); return x; }

// lumpy flat-shaded stone: icosahedron split once (80 triangles), every vertex pushed in / out a little
static std::vector<float> buildMesh(){
    struct V3 { float x, y, z; };
    const float t = (1.f + std::sqrt(5.f)) / 2.f; std::vector<V3> v = {{-1,t,0},{1,t,0},{-1,-t,0},{1,-t,0},{0,-1,t},{0,1,t},{0,-1,-t},{0,1,-t},{t,0,-1},{t,0,1},{-t,0,-1},{-t,0,1}};
    for (V3& a : v){ const float l = std::sqrt(a.x*a.x + a.y*a.y + a.z*a.z); a.x /= l; a.y /= l; a.z /= l; }
    const int F[20][3] = {{0,11,5},{0,5,1},{0,1,7},{0,7,10},{0,10,11},{1,5,9},{5,11,4},{11,10,2},{10,7,6},{7,1,8},{3,9,4},{3,4,2},{3,2,6},{3,6,8},{3,8,9},{4,9,5},{2,4,11},{6,2,10},{8,6,7},{9,8,1}};
    std::vector<V3> tris;
    auto mid = [&](V3 a, V3 b){ V3 m = {(a.x + b.x) / 2, (a.y + b.y) / 2, (a.z + b.z) / 2}; const float l = std::sqrt(m.x*m.x + m.y*m.y + m.z*m.z); return V3{m.x / l, m.y / l, m.z / l}; };
    for (auto& f : F){ const V3 a = v[f[0]], b = v[f[1]], c = v[f[2]], ab = mid(a, b), bc = mid(b, c), ca = mid(c, a);
        const V3 q[12] = {a, ab, ca, ab, b, bc, ca, bc, c, ab, bc, ca}; tris.insert(tris.end(), q, q + 12); }
    auto bump = [](V3 p){ const float h = std::sin(p.x * 91.7f + p.y * 37.3f + p.z * 53.1f) * 43758.5453f; return 0.80f + 0.30f * (h - std::floor(h)); };   // same dent for the same corner
    std::vector<float> out;
    for (size_t i = 0; i + 2 < tris.size(); i += 3){
        V3 a = tris[i], b = tris[i+1], c = tris[i+2]; const float ka = bump(a), kb = bump(b), kc = bump(c);
        a = {a.x*ka, a.y*ka, a.z*ka}; b = {b.x*kb, b.y*kb, b.z*kb}; c = {c.x*kc, c.y*kc, c.z*kc};
        V3 e1 = {b.x - a.x, b.y - a.y, b.z - a.z}, e2 = {c.x - a.x, c.y - a.y, c.z - a.z}; V3 n = {e1.y*e2.z - e1.z*e2.y, e1.z*e2.x - e1.x*e2.z, e1.x*e2.y - e1.y*e2.x};
        const float l = std::sqrt(n.x*n.x + n.y*n.y + n.z*n.z); n = {n.x / l, n.y / l, n.z / l};
        if (n.x*(a.x + b.x + c.x) + n.y*(a.y + b.y + c.y) + n.z*(a.z + b.z + c.z) < 0){ n = {-n.x, -n.y, -n.z}; std::swap(b, c); }
        for (const V3& p : {a, b, c}){ const float f[6] = {p.x, p.y, p.z, n.x, n.y, n.z}; out.insert(out.end(), f, f + 6); }
    }
    return out;
}

// plan once (needs Terrain::init + Village::plan / planSummit done)
static void plan(){
    gSt.clear(); if (!Terrain::PEAK.on) return;
    std::mt19937 rng(777123u); auto U = [&]{ return std::uniform_real_distribution<float>(0.f, 1.f)(rng); };
    const double R = Terrain::PEAK.R;
    auto ground = [&](double x, double z, double& gy, double& band){
        band = Terrain::alpineBand(x, z); if (band < 0.25) return false;
        if (Terrain::latSlope(x, z) > 0.75) return false;                                         // not on cliffs
        if (Terrain::trackDist(x, z) < Terrain::TRK_W * 0.5 + 3.0 || Terrain::summitCleared(x, z, 0.0) || Village::blocked((float)x, (float)z, 3.f)) return false;
        gy = Terrain::meshH(x, z); return true; };
    for (int t = 0; t < 70000 && gSt.size() < 4500; t++){
        const double a = U() * 6.2831853, r = std::sqrt((double)U()) * R * 1.15, x = Terrain::PEAK.x + r * std::cos(a), z = Terrain::PEAK.z + r * std::sin(a); double gy, band;
        if (!ground(x, z, gy, band)) continue;
        const float cl = Terrain::fNoise(x / 13.0 + 5.1, z / 13.0 - 2.7) * 0.6f + Terrain::fNoise(x / 4.0 - 1.3, z / 4.0 + 8.8) * 0.4f;           // stones come in patches
        if (U() > 0.10f + 0.9f * std::max(0.f, (cl - 0.45f) / 0.35f)) continue;
        const bool big = U() < 0.10f; const float s = big ? 0.55f + 0.55f * U() : 0.12f + 0.30f * U();
        gSt.push_back({(float)x, (float)gy - 0.18f * s, (float)z, s, U() * 6.2831853f, U(), 0.45f + 0.35f * U(), U()});
        if (big) for (int k = 0, n = 2 + (int)(U() * 4); k < n; k++){                              // pebbles round a big stone
            const double pa = U() * 6.2831853, pr = (0.8 + 1.8 * U()) * s, px = x + pr * std::cos(pa), pz = z + pr * std::sin(pa); double g2, b2;
            if (!ground(px, pz, g2, b2)) continue; const float ps = 0.07f + 0.13f * U();
            gSt.push_back({(float)px, (float)g2 - 0.15f * ps, (float)pz, ps, U() * 6.2831853f, U(), 0.5f + 0.3f * U(), U()}); }
    }
}

static void init(){
    plan(); if (gSt.empty()) return;
    gProg = glCreateProgram(); glAttachShader(gProg, compile(GL_VERTEX_SHADER, VS)); glAttachShader(gProg, compile(GL_FRAGMENT_SHADER, FS)); glLinkProgram(gProg); SunLight::attach(gProg);
    uVP = glGetUniformLocation(gProg, "uVP"); uCam = glGetUniformLocation(gProg, "uCam");
    const std::vector<float> m = buildMesh(); gVerts = (GLsizei)(m.size() / 6);
    glGenVertexArrays(1, &gVao); glBindVertexArray(gVao);
    glGenBuffers(1, &gVbo); glBindBuffer(GL_ARRAY_BUFFER, gVbo); glBufferData(GL_ARRAY_BUFFER, m.size() * 4, m.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 24, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 24, (void*)12);
    glGenBuffers(1, &gInst); glBindBuffer(GL_ARRAY_BUFFER, gInst);
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 4, GL_FLOAT, GL_FALSE, 32, (void*)0);  glVertexAttribDivisor(2, 1);
    glEnableVertexAttribArray(3); glVertexAttribPointer(3, 4, GL_FLOAT, GL_FALSE, 32, (void*)16); glVertexAttribDivisor(3, 1);
    glBindVertexArray(0); gOk = true;
}

static void draw(const float* VP, const float* eye){
    if (!gOk) return;
    static std::vector<float> B; B.clear();
    float pl[6][4];
    for (int i = 0; i < 6; i++){ const int a = i >> 1; const float sg = (i & 1) ? 1.f : -1.f;
        for (int j = 0; j < 4; j++) pl[i][j] = VP[j*4 + 3] + sg * VP[j*4 + a];
        const float l = std::sqrt(pl[i][0]*pl[i][0] + pl[i][1]*pl[i][1] + pl[i][2]*pl[i][2]); if (l > 1e-6f) for (int j = 0; j < 4; j++) pl[i][j] /= l; }
    const float md2 = MAX_DIST * MAX_DIST;
    for (const Stone& s : gSt){
        const float dx = s.x - eye[0], dz = s.z - eye[2]; if (dx*dx + dz*dz > md2) continue;
        bool out = false; for (int i = 0; i < 6 && !out; i++) if (pl[i][0]*s.x + pl[i][1]*s.y + pl[i][2]*s.z + pl[i][3] < -1.5f * s.s - 0.3f) out = true;
        if (out) continue;
        const float f[8] = {s.x, s.y, s.z, s.s, s.rot, s.tone, s.flat, s.seed}; B.insert(B.end(), f, f + 8);
    }
    const int cnt = (int)(B.size() / 8); if (!cnt) return;
    glEnable(GL_DEPTH_TEST); glDepthMask(GL_TRUE); glDisable(GL_BLEND); glDisable(GL_CULL_FACE);
    glUseProgram(gProg); glUniformMatrix4fv(uVP, 1, GL_FALSE, VP); glUniform3fv(uCam, 1, eye);
    glBindVertexArray(gVao); glBindBuffer(GL_ARRAY_BUFFER, gInst); glBufferData(GL_ARRAY_BUFFER, B.size() * 4, B.data(), GL_STREAM_DRAW);
    glDrawArraysInstanced(GL_TRIANGLES, 0, gVerts, cnt);
    glBindVertexArray(0);
}

} // namespace StonesGL
