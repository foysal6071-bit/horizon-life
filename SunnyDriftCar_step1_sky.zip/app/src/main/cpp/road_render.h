// Sunny Drift - OpenGL ES 3 rendering of the muddy road network (see road.h for the geometry).
//  draw order = HTML: ring roads (depth bias -2) + dirt track (-2) -> connector road (-5) -> ring verges (-4, blended) -> connector verges (-7, blended) + track verges (-4)
#pragma once
#include <GLES3/gl3.h>
#include <cstring>
#include <vector>
#include <android/log.h>
#include "road.h"
#include "road_shaders.h"

namespace RoadGL {

struct GpuMesh { GLuint vao = 0, vbo = 0, ibo = 0; GLsizei count = 0; };
static GpuMesh gRoad, gRoadC, gVerge, gVergeC, gTrk, gTrkV;
static GLuint gProgRoad = 0, gProgVerge = 0;
static GLuint gColA = 0, gColB = 0, gHgtA = 0, gHgtB = 0, gVergeTex = 0;
static GLint uR_VP, uR_Cam, uR_Col1, uR_Col2, uR_Hgt1, uR_Hgt2, uV_VP, uV_Cam, uV_Tex;

static bool gLastOk = true;                       // did the last makeProg() compile + link?
static GLuint compileSh(GLenum t, const char* s){
    GLuint sh = glCreateShader(t); glShaderSource(sh, 1, &s, nullptr); glCompileShader(sh);
    GLint ok = 0; glGetShaderiv(sh, GL_COMPILE_STATUS, &ok);
    if (!ok){ char log[1024]; GLsizei n = 0; glGetShaderInfoLog(sh, sizeof log - 1, &n, log); log[n] = 0; gLastOk = false;
              __android_log_print(ANDROID_LOG_ERROR, "SunnyDrift", "%s shader compile failed: %s", t == GL_VERTEX_SHADER ? "vertex" : "fragment", log); }
    return sh;
}
static GLuint makeProg(const char* vs, const char* fs){
    gLastOk = true;
    GLuint p = glCreateProgram(); glAttachShader(p, compileSh(GL_VERTEX_SHADER, vs)); glAttachShader(p, compileSh(GL_FRAGMENT_SHADER, fs));
    glLinkProgram(p);
    GLint ok = 0; glGetProgramiv(p, GL_LINK_STATUS, &ok);
    if (!ok){ gLastOk = false; char log[1024]; GLsizei n = 0; glGetProgramInfoLog(p, sizeof log - 1, &n, log); log[n] = 0; __android_log_print(ANDROID_LOG_ERROR, "SunnyDrift", "program link failed: %s", log); }
    return p;
}

// asset = int32 width, int32 height, then pixels (row 0 = texture v 0, like three.js with flipY)
static GLuint makeTex(const std::vector<char>& f, bool oneChannel){
    if (f.size() < 8) return 0;
    int w, h; memcpy(&w, f.data(), 4); memcpy(&h, f.data() + 4, 4);
    GLuint t; glGenTextures(1, &t); glBindTexture(GL_TEXTURE_2D, t);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    if (oneChannel) glTexImage2D(GL_TEXTURE_2D, 0, GL_R8, w, h, 0, GL_RED, GL_UNSIGNED_BYTE, f.data() + 8);
    else            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, f.data() + 8);
    glGenerateMipmap(GL_TEXTURE_2D);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    const char* ext = (const char*)glGetString(GL_EXTENSIONS);
    if (ext && strstr(ext, "GL_EXT_texture_filter_anisotropic")){                    // sharp mud at grazing angles
        GLfloat mx = 1; glGetFloatv(0x84FF, &mx); glTexParameterf(GL_TEXTURE_2D, 0x84FE, mx < 8.f ? mx : 8.f);
    }
    return t;
}

static GpuMesh upload(const Road::Mesh& m){
    GpuMesh g; g.count = (GLsizei)m.idx.size(); if (!g.count) return g;
    glGenVertexArrays(1, &g.vao); glBindVertexArray(g.vao);
    glGenBuffers(1, &g.vbo); glBindBuffer(GL_ARRAY_BUFFER, g.vbo); glBufferData(GL_ARRAY_BUFFER, m.v.size() * 4, m.v.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 32, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 32, (void*)12);
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 32, (void*)20);
    glGenBuffers(1, &g.ibo); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, g.ibo); glBufferData(GL_ELEMENT_ARRAY_BUFFER, m.idx.size() * 4, m.idx.data(), GL_STATIC_DRAW);
    glBindVertexArray(0); return g;
}
static void drawMesh(const GpuMesh& g){ if (!g.count) return; glBindVertexArray(g.vao); glDrawElements(GL_TRIANGLES, g.count, GL_UNSIGNED_INT, (void*)0); glBindVertexArray(0); }

// Call once with a current GL context (after Road::init()).
static void init(const std::vector<char>& colA, const std::vector<char>& hgtA, const std::vector<char>& colB,
                 const std::vector<char>& hgtB, const std::vector<char>& verge){
    gProgRoad = makeProg(ROAD_VS, ROAD_FS); gProgVerge = makeProg(ROAD_VS, VERGE_FS);
    uR_VP = glGetUniformLocation(gProgRoad, "uVP"); uR_Cam = glGetUniformLocation(gProgRoad, "uCam");
    uR_Col1 = glGetUniformLocation(gProgRoad, "uCol1"); uR_Col2 = glGetUniformLocation(gProgRoad, "uCol2");
    uR_Hgt1 = glGetUniformLocation(gProgRoad, "uHgt1"); uR_Hgt2 = glGetUniformLocation(gProgRoad, "uHgt2");
    uV_VP = glGetUniformLocation(gProgVerge, "uVP"); uV_Cam = glGetUniformLocation(gProgVerge, "uCam"); uV_Tex = glGetUniformLocation(gProgVerge, "uTex");
    gColA = makeTex(colA, false); gHgtA = makeTex(hgtA, true); gColB = makeTex(colB, false); gHgtB = makeTex(hgtB, true);
    gVergeTex = makeTex(verge, false);
    gRoad = upload(Road::gNet.road); gRoadC = upload(Road::gNet.roadC); gVerge = upload(Road::gNet.verge); gVergeC = upload(Road::gNet.vergeC);
    gTrk = upload(Road::gNet.trk); gTrkV = upload(Road::gNet.trkV);                       // dirt track over the hills (same mud material as the roads)
}

static void draw(const float* VP, const float* eye){
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glEnable(GL_POLYGON_OFFSET_FILL);
    // --- mud road ---
    glUseProgram(gProgRoad); glUniformMatrix4fv(uR_VP, 1, GL_FALSE, VP); glUniform3fv(uR_Cam, 1, eye);
    const GLuint tex[4] = {gColA, gColB, gHgtA, gHgtB}; const GLint loc[4] = {uR_Col1, uR_Col2, uR_Hgt1, uR_Hgt2};
    for (int i = 0; i < 4; i++){ glActiveTexture(GL_TEXTURE0 + i); glBindTexture(GL_TEXTURE_2D, tex[i]); glUniform1i(loc[i], i); }
    glPolygonOffset(-2.f, -2.f); drawMesh(gRoad);
    glPolygonOffset(-2.f, -2.f); drawMesh(gTrk);                                          // dirt track (HTML renderOrder 0)
    glPolygonOffset(-5.f, -5.f); drawMesh(gRoadC);                                      // connector wins cleanly at the T-junctions
    // --- sand verge (alpha blended, no depth write) ---
    glUseProgram(gProgVerge); glUniformMatrix4fv(uV_VP, 1, GL_FALSE, VP); glUniform3fv(uV_Cam, 1, eye);
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, gVergeTex); glUniform1i(uV_Tex, 0);
    glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); glDepthMask(GL_FALSE);
    glPolygonOffset(-4.f, -4.f); drawMesh(gVerge);
    glPolygonOffset(-7.f, -7.f); drawMesh(gVergeC);
    glPolygonOffset(-4.f, -4.f); drawMesh(gTrkV);                                         // dirt track verges (renderOrder 1)
    glDepthMask(GL_TRUE); glDisable(GL_BLEND); glDisable(GL_POLYGON_OFFSET_FILL);
    glActiveTexture(GL_TEXTURE0);
}

} // namespace RoadGL
