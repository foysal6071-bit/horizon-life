// Sunny Drift - night mode + the headlight light pool (port of hlG / hlM in the HTML game).
//  * the HTML pool is a 10 m x 24 m additive glow plane 12 m in front of the car, colour 0xfff0c8, opacity 0.5 * night, 7 cm above the road
//  * this project has no sun cycle, so night is a smooth fade (button in the app): the finished picture is darkened with a blue multiply,
//    then the pool and the car lights are drawn on top, so they stay bright
#pragma once
#include <GLES3/gl3.h>
#include <cmath>

namespace NightGL {

static float night = 0, target = 0;
static GLuint gProgOv = 0, gProgPool = 0, gPoolVBO = 0;
static GLint uOvMul, uPoolVP, uPoolOp;

static const char* OV_VS = R"GLSL(#version 300 es
void main(){ vec2 p = vec2((gl_VertexID == 1) ? 3.0 : -1.0, (gl_VertexID == 2) ? 3.0 : -1.0); gl_Position = vec4(p, 0.0, 1.0); }
)GLSL";
static const char* OV_FS = R"GLSL(#version 300 es
precision mediump float; uniform vec3 uMul; out vec4 o;
void main(){ o = vec4(uMul, 1.0); }
)GLSL";
static const char* POOL_VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in vec2 uv;
uniform mat4 uVP; out vec2 vUv;
void main(){ vUv = uv; gl_Position = uVP*vec4(p, 1.0); }
)GLSL";
static const char* POOL_FS = R"GLSL(#version 300 es
precision mediump float;
in vec2 vUv; uniform float uOp; out vec4 o;
void main(){                                   // radialTex(): white 1.0 -> 0.35 at 35% -> 0 at the edge
  float r = length(vUv*2.0 - 1.0);
  float a = r < 0.35 ? mix(1.0, 0.35, r/0.35) : mix(0.35, 0.0, clamp((r - 0.35)/0.65, 0.0, 1.0));
  o = vec4(1.0, 0.94, 0.78, a*uOp);
}
)GLSL";

static GLuint mk(const char* vs, const char* fs){
    GLuint p = glCreateProgram();
    GLuint a = glCreateShader(GL_VERTEX_SHADER); glShaderSource(a, 1, &vs, nullptr); glCompileShader(a);
    GLuint b = glCreateShader(GL_FRAGMENT_SHADER); glShaderSource(b, 1, &fs, nullptr); glCompileShader(b);
    glAttachShader(p, a); glAttachShader(p, b); glLinkProgram(p); return p;
}
static void init(){
    gProgOv = mk(OV_VS, OV_FS); uOvMul = glGetUniformLocation(gProgOv, "uMul");
    gProgPool = mk(POOL_VS, POOL_FS); uPoolVP = glGetUniformLocation(gProgPool, "uVP"); uPoolOp = glGetUniformLocation(gProgPool, "uOp");
    glGenBuffers(1, &gPoolVBO); glBindBuffer(GL_ARRAY_BUFFER, gPoolVBO); glBufferData(GL_ARRAY_BUFFER, 6 * 5 * 4, nullptr, GL_DYNAMIC_DRAW);
}
static void update(double dt){ night += (target - night) * (float)(1 - exp(-dt * 2.0)); if (fabsf(night - target) < 0.002f) night = target; }

// darken the whole picture (sky, hills, road, car) towards a moonlit blue
static void overlay(){
    if (night < 0.002f) return;
    const float k = night, m0 = 1 - k * (1 - 0.13f), m1 = 1 - k * (1 - 0.17f), m2 = 1 - k * (1 - 0.30f);
    glDisable(GL_DEPTH_TEST); glDepthMask(GL_FALSE); glEnable(GL_BLEND); glBlendFunc(GL_DST_COLOR, GL_ZERO);
    glUseProgram(gProgOv); glUniform3f(uOvMul, m0, m1, m2); glDrawArrays(GL_TRIANGLES, 0, 3);
    glEnable(GL_DEPTH_TEST); glDepthMask(GL_TRUE); glDisable(GL_BLEND);
}

// light pool on the road in front of the headlights: centre 12 m ahead, 10 m wide, 24 m long, additive, opacity 0.5 * night
static void pool(const float* VP, double x, double z, double heading, double y){
    if (night < 0.02f) return;
    const float fx = (float)sin(heading), fz = (float)cos(heading), rx = fz, rz = -fx;          // forward / right (horizontal)
    const float cx = (float)x + fx * 12.f, cz = (float)z + fz * 12.f, py = (float)y + 0.15f;      // ROAD_SURF + 0.07 above the car's ground
    const float L = 12.f, W = 5.f;
    auto v = [&](float f, float s, float u, float t, float* o){ o[0] = cx + fx * f * L + rx * s * W; o[1] = py; o[2] = cz + fz * f * L + rz * s * W; o[3] = u; o[4] = t; };
    float q[30]; v(-1, -1, 0, 0, q); v(-1, 1, 1, 0, q + 5); v(1, -1, 0, 1, q + 10); v(-1, 1, 1, 0, q + 15); v(1, 1, 1, 1, q + 20); v(1, -1, 0, 1, q + 25);
    glBindBuffer(GL_ARRAY_BUFFER, gPoolVBO); glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(q), q);
    glUseProgram(gProgPool); glUniformMatrix4fv(uPoolVP, 1, GL_FALSE, VP); glUniform1f(uPoolOp, 0.5f * night);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 20, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 20, (void*)12);
    glEnable(GL_DEPTH_TEST); glDepthMask(GL_FALSE); glDisable(GL_CULL_FACE); glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE);
    glEnable(GL_POLYGON_OFFSET_FILL); glPolygonOffset(-5.f, -5.f); glDrawArrays(GL_TRIANGLES, 0, 6); glDisable(GL_POLYGON_OFFSET_FILL);
    glDepthMask(GL_TRUE); glDisable(GL_BLEND);
}

} // namespace NightGL
