// Sunny Drift - green trees: OpenGL ES 3 rendering + planting (C++ port of the HTML "Trees" + "Tree LOD" blocks).
//  * leaves: alpha-tested cards with the leaf texture, gentle wind sway (trSway in the HTML)
//  * bark: 6-sided tubes with the bark texture
//  * every tree is one instance (x, z, scale, rotation); trees within NEAR metres are drawn as the full model,
//    farther ones as a camera-facing billboard baked once from the model (same idea as bakeProto / updateTreeLOD)
#pragma once
#include <GLES3/gl3.h>
#include <cstdlib>
#include <random>
#include "tree_model.h"
#include "road.h"
#include "terrain.h"

namespace TreeGL {

// ---------- tunables (same numbers as the HTML) ----------
const float NEAR_DIST = 38.f, HYST = 8.f;            // low-poly LOD: full model only very close (was 70 / 14)
const float MAX_DIST = 600.f;                         // distance culling: nothing farther than this is drawn at all
const float CULL_R = 7.f;                             // bounding radius (m, before tree scale) used for frustum culling
const int   GREEN_TREES = 240, GROVE_TREES = 170;    // 400 total in the HTML = 330 green + 70 maple; maple is not part of this port

struct Tree { float x, z, s, r, y; };                 // y = ground height (the hills)

static std::vector<Tree> gTrees;
static std::vector<uint8_t> gIsNear;
static GLuint gMeshProg = 0, gBillProg = 0, gNearVBO = 0, gFarVBO = 0;
static GLuint gLeafVAO = 0, gBarkVAO = 0, gBillVAO = 0, gLeafTex = 0, gBarkTex = 0, gBillTex = 0;
static GLuint gLeafVBO = 0, gLeafIBO = 0, gBarkVBO = 0, gBarkIBO = 0, gQuadVBO = 0;
static int gLeafIdx = 0, gBarkIdx = 0;
static float gBbHalfW = 1, gBbY0 = 0, gBbH = 1;
static GLint uM_VP, uM_Wind, uM_Sway, uM_Tex, uM_Cam, uM_Tint, uM_Emis, uM_Alpha, uM_Leaf;
static GLint uB_VP, uB_Right, uB_Size, uB_Tex, uB_Cam;

static const char* MESH_VS =
    "#version 300 es\n"
    "layout(location=0) in vec3 p; layout(location=1) in vec3 n; layout(location=2) in vec2 t; layout(location=3) in vec4 inst; layout(location=4) in float instY;\n"
    "uniform mat4 uVP; uniform float uWind; uniform float uSway;\n"
    "out vec2 vt; out vec3 vn; out vec3 wp;\n"
    "void main(){\n"
    " vec3 q = p;\n"
    " if (uSway > 0.5){\n"                                   // trSway(): wind moves the upper part of the crown
    "  float wv = sin(uWind*1.5 + inst.x*.11 + inst.y*.09)*.6 + sin(uWind*2.9 + q.x*1.3 + q.z*1.1 + inst.x*.2)*.4;\n"
    "  float hh = max(q.y - 1.5, 0.);\n"
    "  q.x += wv*.03*hh; q.z += wv*.02*hh;\n"
    " }\n"
    " q *= inst.z;\n"
    " float c = cos(inst.w), s = sin(inst.w);\n"
    " mat3 Ry = mat3(c,0.,-s, 0.,1.,0., s,0.,c);\n"
    " wp = Ry*q + vec3(inst.x, instY, inst.y); vn = Ry*n; vt = t;\n"
    " gl_Position = uVP*vec4(wp,1.);\n"
    "}";
static const char* MESH_FS =
    "#version 300 es\nprecision mediump float;\n"
    "in vec2 vt; in vec3 vn; in vec3 wp;\n"
    "uniform sampler2D uTex; uniform vec3 uCam, uTint, uEmis; uniform float uAlpha, uLeaf;\n"
    "out vec4 o;\n"
    "void main(){\n"
    " vec4 tx = texture(uTex, vt);\n"
    " if (uAlpha > 0. && tx.a < uAlpha) discard;\n"
    " vec3 N = normalize(vn); if (uLeaf < .5 && !gl_FrontFacing) N = -N;\n"
    " float d = max(dot(N, normalize(vec3(0.4,0.8,0.3))), 0.0);\n"
    " vec3 c = tx.rgb*uTint*(0.35 + 0.75*d) + uEmis;\n"
    " c = mix(c, vec3(0.62,0.80,0.95), clamp(length(uCam-wp)/2500.0, 0.0, 1.0));\n"
    " o = vec4(c,1.);\n"
    "}";
static const char* BILL_VS =
    "#version 300 es\n"
    "layout(location=0) in vec2 q; layout(location=3) in vec4 inst; layout(location=4) in float instY;\n"
    "uniform mat4 uVP; uniform vec3 uRight; uniform vec3 uSize;\n"   // uSize = (half width, y0, height) of the baked model
    "out vec2 vt; out vec3 wp;\n"
    "void main(){\n"
    " wp = vec3(inst.x, instY, inst.y) + uRight*(q.x*uSize.x*inst.z) + vec3(0., (uSize.y + q.y*uSize.z)*inst.z, 0.);\n"
    " vt = vec2(q.x*.5 + .5, q.y); gl_Position = uVP*vec4(wp,1.);\n"
    "}";
static const char* BILL_FS =
    "#version 300 es\nprecision mediump float;\n"
    "in vec2 vt; in vec3 wp; uniform sampler2D uTex; uniform vec3 uCam; out vec4 o;\n"
    "void main(){\n"
    " vec4 tx = texture(uTex, vt); if (tx.a < 0.4) discard;\n"
    " vec3 c = mix(tx.rgb, vec3(0.62,0.80,0.95), clamp(length(uCam-wp)/2500.0, 0.0, 1.0));\n"
    " o = vec4(c,1.);\n"
    "}";

static GLuint compileSh(GLenum t, const char* s){ GLuint sh = glCreateShader(t); glShaderSource(sh, 1, &s, nullptr); glCompileShader(sh); return sh; }
static GLuint makeProg(const char* vs, const char* fs){
    GLuint p = glCreateProgram(); glAttachShader(p, compileSh(GL_VERTEX_SHADER, vs)); glAttachShader(p, compileSh(GL_FRAGMENT_SHADER, fs));
    glLinkProgram(p); return p;
}

// raw RGBA file: int32 width, int32 height, then w*h*4 bytes
static GLuint makeTexture(const std::vector<char>& f){
    if (f.size() < 8) return 0;
    int w, h; memcpy(&w, f.data(), 4); memcpy(&h, f.data() + 4, 4);
    GLuint t; glGenTextures(1, &t); glBindTexture(GL_TEXTURE_2D, t);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, f.data() + 8);   // row 0 = v 0 (three.js flipY = false)
    glGenerateMipmap(GL_TEXTURE_2D);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_BASE_LEVEL, 1);                 // low texture quality: start at mip 1 (half resolution, a quarter of the bandwidth)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    return t;
}

static void makePart(const TreeModel::Mesh& m, GLuint tex, GLuint& vao, GLuint& vbo, GLuint& ibo, int& idxCount){
    (void)tex;
    const int n = m.vertexCount();
    std::vector<float> vb((size_t)n * 8);
    for (int i = 0; i < n; i++){
        for (int k = 0; k < 3; k++){ vb[i*8+k] = m.pos[i*3+k]; vb[i*8+3+k] = m.nrm[i*3+k]; }
        vb[i*8+6] = m.uv[i*2]; vb[i*8+7] = m.uv[i*2+1];
    }
    glGenVertexArrays(1, &vao); glBindVertexArray(vao);
    glGenBuffers(1, &vbo); glBindBuffer(GL_ARRAY_BUFFER, vbo); glBufferData(GL_ARRAY_BUFFER, vb.size() * 4, vb.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 32, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 32, (void*)12);
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 32, (void*)24);
    glGenBuffers(1, &ibo); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, m.idx.size() * 2, m.idx.data(), GL_STATIC_DRAW);
    idxCount = (int)m.idx.size();
    glBindBuffer(GL_ARRAY_BUFFER, gNearVBO);                                   // per-instance (x, z, scale, rotation, y)
    glEnableVertexAttribArray(3); glVertexAttribPointer(3, 4, GL_FLOAT, GL_FALSE, 20, (void*)0); glVertexAttribDivisor(3, 1);
    glEnableVertexAttribArray(4); glVertexAttribPointer(4, 1, GL_FLOAT, GL_FALSE, 20, (void*)16); glVertexAttribDivisor(4, 1);
    glBindVertexArray(0);
}

static void setMeshUniforms(const float* VP, const float* eye, float t){
    glUseProgram(gMeshProg);
    glUniformMatrix4fv(uM_VP, 1, GL_FALSE, VP); glUniform1f(uM_Wind, t); glUniform3fv(uM_Cam, 1, eye); glUniform1i(uM_Tex, 0);
}
static void drawModel(int instances){
    glActiveTexture(GL_TEXTURE0);
    // bark
    glBindTexture(GL_TEXTURE_2D, gBarkTex); glUniform1f(uM_Sway, 0); glUniform1f(uM_Alpha, 0); glUniform1f(uM_Leaf, 0);
    glUniform3f(uM_Tint, 1.f, 1.f, 1.f); glUniform3f(uM_Emis, 0.04f, 0.04f, 0.035f);
    glBindVertexArray(gBarkVAO); glDrawElementsInstanced(GL_TRIANGLES, gBarkIdx, GL_UNSIGNED_SHORT, (void*)0, instances);
    // leaves (alpha-tested, swaying, slightly warm green tint + soft green glow like the HTML material)
    glBindTexture(GL_TEXTURE_2D, gLeafTex); glUniform1f(uM_Sway, 1); glUniform1f(uM_Alpha, 0.5f); glUniform1f(uM_Leaf, 1);
    glUniform3f(uM_Tint, 1.1f, 1.15f, 0.95f); glUniform3f(uM_Emis, 0.07f, 0.18f, 0.05f);
    glBindVertexArray(gLeafVAO); glDrawElementsInstanced(GL_TRIANGLES, gLeafIdx, GL_UNSIGNED_SHORT, (void*)0, instances);
    glBindVertexArray(0);
}

// ---------- planting (plantTree / plantGrove / randClear from the HTML) ----------
// Trees stand on the rolling ground (Terrain::fieldH). "Clear" = at least ~16 m from the edge of every road (like farFromRoad(16) in the HTML).
static std::mt19937 gRng(20260101);
static float rnd(){ return std::uniform_real_distribution<float>(0.f, 1.f)(gRng); }
static float gauss(){ return (rnd() + rnd() + rnd() - 1.5f) / 0.75f; }          // ~N(0,1)-ish, in [-2,2]
static bool treeOk(float x, float z, float roadHalfWidth){ (void)roadHalfWidth; return Road::clearance(x, z) > 16.5f && std::fabs(River::riverSd(x, z)) > 34.0 && Terrain::trackDist(x, z) > 12.0; }   // also off the dirt track (HTML isClear: trackDist > 12)   // also keep the river clear (HTML: |riverSd| < r+32)
static void plant(float x, float z){ const float s = 0.8f + rnd() * 0.9f, r = rnd() * 6.2831853f; gTrees.push_back({x, z, s, r, (float)Terrain::fieldH(x, z)}); }   // stands on the hill
static bool randClear(float rw, float& x, float& z){
    for (int t = 0; t < 60; t++){
        float a = rnd() * 6.2831853f, d = 30.f + rnd() * 640.f; x = std::cos(a) * d; z = std::sin(a) * d;
        if (treeOk(x, z, rw)) return true;
    }
    return false;
}
static int plantGrove(int n, float rad, float rw){
    float cx, cz; if (!randClear(rw, cx, cz)) return 0;
    int done = 0;
    for (int k = 0; k < n * 8 && done < n; k++){
        float x = cx + gauss() * rad * 0.5f, z = cz + gauss() * rad * 0.5f;
        if (!treeOk(x, z, rw)) continue;
        bool tooClose = false;
        for (const Tree& t : gTrees){ float dx = t.x - x, dz = t.z - z; if (dx*dx + dz*dz < 9.f){ tooClose = true; break; } }
        if (tooClose) continue;
        plant(x, z); done++;
    }
    return done;
}
static void plantAll(float roadHalfWidth){
    gTrees.clear(); int guard = 0;
    while ((int)gTrees.size() < GROVE_TREES && guard++ < 400) plantGrove(8 + (int)(rnd() * 11), 14.f + rnd() * 10.f, roadHalfWidth);   // groves of 8-18
    while ((int)gTrees.size() < GREEN_TREES && guard++ < 2000){ float x, z; if (randClear(roadHalfWidth, x, z)) plant(x, z); }          // lone trees
    gIsNear.assign(gTrees.size(), 0);
}

// ---------- billboard bake: render the tree once from the side into a texture ----------
static void bakeBillboard(const TreeModel::Model& M){
    gBbHalfW = M.halfWidth * 1.02f; gBbY0 = M.minY; float y1 = M.maxY * 1.01f; gBbH = y1 - gBbY0;
    const int W = 128; int H = std::max(32, (int)std::lround(W * gBbH / (2 * gBbHalfW) / 8.0) * 8); if (H > 256) H = 256;
    GLint oldFbo = 0, vp[4]; glGetIntegerv(GL_FRAMEBUFFER_BINDING, &oldFbo); glGetIntegerv(GL_VIEWPORT, vp);
    glGenTextures(1, &gBillTex); glBindTexture(GL_TEXTURE_2D, gBillTex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, W, H, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    GLuint fbo, depth; glGenFramebuffers(1, &fbo); glBindFramebuffer(GL_FRAMEBUFFER, fbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, gBillTex, 0);
    glGenRenderbuffers(1, &depth); glBindRenderbuffer(GL_RENDERBUFFER, depth);
    glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT16, W, H);
    glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, depth);
    if (glCheckFramebufferStatus(GL_FRAMEBUFFER) == GL_FRAMEBUFFER_COMPLETE){
        glViewport(0, 0, W, H); glClearColor(0, 0, 0, 0); glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        glEnable(GL_DEPTH_TEST);
        float P[16] = {0}; P[0] = 1.f / gBbHalfW; P[5] = 2.f / gBbH; P[10] = -0.01f; P[13] = -(y1 + gBbY0) / gBbH; P[15] = 1;   // side-on orthographic
        const float one[5] = {0, 0, 1, 0, 0}, eye[3] = {0, 0, 0};
        glBindBuffer(GL_ARRAY_BUFFER, gNearVBO); glBufferData(GL_ARRAY_BUFFER, sizeof(one), one, GL_STREAM_DRAW);
        setMeshUniforms(P, eye, 0.f); drawModel(1);
    }
    glBindFramebuffer(GL_FRAMEBUFFER, oldFbo); glDeleteRenderbuffers(1, &depth); glDeleteFramebuffers(1, &fbo);
    glViewport(vp[0], vp[1], vp[2], vp[3]);
    glBindTexture(GL_TEXTURE_2D, gBillTex); glGenerateMipmap(GL_TEXTURE_2D);
}

// ---------- public API ----------
static bool gReady = false;

// Call once with a current GL context. rawBlob = tree_raw.bin, meta = tree_meta.txt, leafTex/barkTex = *.rgba assets.
static bool init(const std::vector<char>& rawBlob, const std::vector<char>& meta, const std::vector<char>& leafTex,
                 const std::vector<char>& barkTex, float roadHalfWidth){
    TreeModel::Meta M; if (!TreeModel::parseMeta(std::string(meta.begin(), meta.end()), M)) return false;
    if (rawBlob.size() < (size_t)(M.t0 + M.t1)) return false;
    TreeModel::Model model;
    if (!TreeModel::parse((const uint8_t*)rawBlob.data(), rawBlob.size() - M.t0 - M.t1, M, model)) return false;

    gMeshProg = makeProg(MESH_VS, MESH_FS); gBillProg = makeProg(BILL_VS, BILL_FS);
    uM_VP = glGetUniformLocation(gMeshProg, "uVP"); uM_Wind = glGetUniformLocation(gMeshProg, "uWind"); uM_Sway = glGetUniformLocation(gMeshProg, "uSway");
    uM_Tex = glGetUniformLocation(gMeshProg, "uTex"); uM_Cam = glGetUniformLocation(gMeshProg, "uCam"); uM_Tint = glGetUniformLocation(gMeshProg, "uTint");
    uM_Emis = glGetUniformLocation(gMeshProg, "uEmis"); uM_Alpha = glGetUniformLocation(gMeshProg, "uAlpha"); uM_Leaf = glGetUniformLocation(gMeshProg, "uLeaf");
    uB_VP = glGetUniformLocation(gBillProg, "uVP"); uB_Right = glGetUniformLocation(gBillProg, "uRight"); uB_Size = glGetUniformLocation(gBillProg, "uSize");
    uB_Tex = glGetUniformLocation(gBillProg, "uTex"); uB_Cam = glGetUniformLocation(gBillProg, "uCam");

    glGenBuffers(1, &gNearVBO); glGenBuffers(1, &gFarVBO);
    gLeafTex = makeTexture(leafTex); gBarkTex = makeTexture(barkTex);
    makePart(model.leaf, gLeafTex, gLeafVAO, gLeafVBO, gLeafIBO, gLeafIdx);
    makePart(model.bark, gBarkTex, gBarkVAO, gBarkVBO, gBarkIBO, gBarkIdx);

    const float quad[8] = {-1, 0,  1, 0,  -1, 1,  1, 1};                       // billboard quad: x -1..1, y 0..1
    glGenVertexArrays(1, &gBillVAO); glBindVertexArray(gBillVAO);
    glGenBuffers(1, &gQuadVBO); glBindBuffer(GL_ARRAY_BUFFER, gQuadVBO); glBufferData(GL_ARRAY_BUFFER, sizeof(quad), quad, GL_STATIC_DRAW);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 8, (void*)0);
    glBindBuffer(GL_ARRAY_BUFFER, gFarVBO);
    glEnableVertexAttribArray(3); glVertexAttribPointer(3, 4, GL_FLOAT, GL_FALSE, 20, (void*)0); glVertexAttribDivisor(3, 1);
    glEnableVertexAttribArray(4); glVertexAttribPointer(4, 1, GL_FLOAT, GL_FALSE, 20, (void*)16); glVertexAttribDivisor(4, 1);
    glBindVertexArray(0);

    bakeBillboard(model);
    plantAll(roadHalfWidth);
    gReady = true; return true;
}

// VP = projection*view (column-major), V = view matrix (for the billboard's right vector), eye = camera position
static void draw(const float* VP, const float* V, const float* eye, float timeSec){
    if (!gReady) return;
    static std::vector<float> nearB, farB; nearB.clear(); farB.clear();
    const float n2 = NEAR_DIST * NEAR_DIST, h2 = (NEAR_DIST + HYST) * (NEAR_DIST + HYST), m2 = MAX_DIST * MAX_DIST;
    float pl[6][4];                                                                   // frustum planes from the column-major view-projection matrix
    for (int i = 0; i < 6; i++){ const int a = i >> 1; const float sg = (i & 1) ? 1.f : -1.f;
        for (int j = 0; j < 4; j++) pl[i][j] = VP[j*4 + 3] + sg * VP[j*4 + a];
        const float l = std::sqrt(pl[i][0]*pl[i][0] + pl[i][1]*pl[i][1] + pl[i][2]*pl[i][2]); if (l > 1e-6f) for (int j = 0; j < 4; j++) pl[i][j] /= l; }
    for (size_t k = 0; k < gTrees.size(); k++){
        const Tree& t = gTrees[k]; float dx = t.x - eye[0], dz = t.z - eye[2], d2 = dx*dx + dz*dz;
        if (d2 > m2) { gIsNear[k] = 0; continue; }                                      // too far: culled
        { const float cy = t.y + 3.f * t.s, rad = CULL_R * t.s; bool out = false;      // outside the view: culled (no draw, no GPU upload)
          for (int i = 0; i < 6 && !out; i++) if (pl[i][0]*t.x + pl[i][1]*cy + pl[i][2]*t.z + pl[i][3] < -rad) out = true;
          if (out) continue; }
        bool near = gIsNear[k] ? d2 < h2 : d2 < n2; gIsNear[k] = near;               // hysteresis so trees do not flicker between LODs
        std::vector<float>& B = near ? nearB : farB; B.push_back(t.x); B.push_back(t.z); B.push_back(t.s); B.push_back(t.r); B.push_back(t.y);
    }
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glActiveTexture(GL_TEXTURE0);
    int nn = (int)(nearB.size() / 5), nf = (int)(farB.size() / 5);
    if (nn){
        glBindBuffer(GL_ARRAY_BUFFER, gNearVBO); glBufferData(GL_ARRAY_BUFFER, nearB.size() * 4, nearB.data(), GL_STREAM_DRAW);
        setMeshUniforms(VP, eye, timeSec); drawModel(nn);
    }
    if (nf){
        glBindBuffer(GL_ARRAY_BUFFER, gFarVBO); glBufferData(GL_ARRAY_BUFFER, farB.size() * 4, farB.data(), GL_STREAM_DRAW);
        glUseProgram(gBillProg); glUniformMatrix4fv(uB_VP, 1, GL_FALSE, VP); glUniform3fv(uB_Cam, 1, eye); glUniform1i(uB_Tex, 0);
        float rx = V[0], rz = V[8], l = std::sqrt(rx*rx + rz*rz); if (l < 1e-6f) l = 1;                  // camera-right, kept horizontal
        glUniform3f(uB_Right, rx / l, 0.f, rz / l); glUniform3f(uB_Size, gBbHalfW, gBbY0, gBbH);
        glBindTexture(GL_TEXTURE_2D, gBillTex);
        glBindVertexArray(gBillVAO); glDrawArraysInstanced(GL_TRIANGLE_STRIP, 0, 4, nf); glBindVertexArray(0);
    }
}

} // namespace TreeGL
