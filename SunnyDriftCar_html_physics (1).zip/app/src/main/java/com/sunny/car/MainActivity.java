package com.sunny.car;

import android.app.Activity;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.os.Handler;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MainActivity extends Activity {
    static { System.loadLibrary("car"); }
    static native void nInit(AssetManager am);
    static native void nResize(int w, int h);
    static native void nDraw();
    static native void nInput(int mask);
    static native void nNight(int on);
    static native float nSpeed();
    static native void nSens(float v);          // steering sensitivity (HTML steerSens, 0.6 ... 3, default 1.8)
    static native void nReset();                // HTML resetCar()
    static native void nWheelMode(int on);      // HTML Settings > Controls: buttons / wheel
    static native void nWheelDown(float deg);
    static native void nWheelMove(float deg);
    static native void nWheelUp();
    static native float nWheelRot();            // wheel angle in degrees (+ = clockwise)

    int mask = 0, kmask = 0;   // 1=left 2=right 4=gas 8=brake 16=handbrake 32=key left 64=key right   (mask = touch, kmask = keyboard)
    GLSurfaceView gl; TextView speed; View wheelView; Button bl, br;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        gl = new GLSurfaceView(this);
        gl.setEGLContextClientVersion(3);
        gl.setEGLConfigChooser(8, 8, 8, 8, 24, 0);
        gl.setRenderer(new GLSurfaceView.Renderer() {
            public void onSurfaceCreated(GL10 g, EGLConfig c) { nInit(getAssets()); }
            public void onSurfaceChanged(GL10 g, int w, int h) { nResize(w, h); }
            public void onDrawFrame(GL10 g) { nDraw(); }
        });
        FrameLayout root = new FrameLayout(this);
        root.addView(gl);
        add(root, "<", 1, Gravity.BOTTOM | Gravity.START, 24, 24);
        add(root, ">", 2, Gravity.BOTTOM | Gravity.START, 24 + 150, 24);
        add(root, "GAS", 4, Gravity.BOTTOM | Gravity.END, 24, 24 + 110);
        add(root, "BRAKE", 8, Gravity.BOTTOM | Gravity.END, 24, 24);
        add(root, "HAND", 16, Gravity.BOTTOM | Gravity.END, 24 + 200, 24);
        final Button nb = new Button(this);          // day / night switch (night shows the headlight light pool)
        nb.setText("NIGHT"); nb.setAlpha(0.6f);
        nb.setOnClickListener(new View.OnClickListener() {
            boolean on = false;
            public void onClick(View v) { on = !on; nb.setText(on ? "DAY" : "NIGHT"); nNight(on ? 1 : 0); }
        });
        float dn = getResources().getDisplayMetrics().density;
        FrameLayout.LayoutParams nlp = new FrameLayout.LayoutParams((int) (110 * dn), (int) (56 * dn), Gravity.TOP | Gravity.START);
        nlp.setMargins((int) (16 * dn), (int) (16 * dn), 0, 0);
        root.addView(nb, nlp);
        bl = (Button) root.getChildAt(1); br = (Button) root.getChildAt(2);
        wheelView = new View(this) {      // drag-to-turn steering wheel (HTML #tWheel): rotation comes from the C++ Ctrl::Wheel
            final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            @Override protected void onDraw(Canvas c) {
                float w = getWidth(), h = getHeight(), r = Math.min(w, h) / 2 - 8;
                c.save(); c.rotate(nWheelRot(), w / 2, h / 2);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(r * 0.22f); p.setColor(0xCC202020); c.drawCircle(w / 2, h / 2, r, p);
                p.setStrokeWidth(r * 0.12f); p.setColor(0xCC404040);
                c.drawLine(w / 2 - r, h / 2, w / 2 + r, h / 2, p); c.drawLine(w / 2, h / 2, w / 2, h / 2 + r, p);
                p.setStyle(Paint.Style.FILL); p.setColor(0xFFCC2222); c.drawRect(w / 2 - r * 0.07f, h / 2 - r - r * 0.11f, w / 2 + r * 0.07f, h / 2 - r + r * 0.11f, p);   // 12 o'clock mark
                c.restore();
            }
            @Override public boolean onTouchEvent(MotionEvent e) {
                float deg = (float) Math.toDegrees(Math.atan2(e.getY() - getHeight() / 2f, e.getX() - getWidth() / 2f));
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: nWheelDown(deg); break;
                    case MotionEvent.ACTION_MOVE: nWheelMove(deg); break;
                    case MotionEvent.ACTION_UP: case MotionEvent.ACTION_CANCEL: nWheelUp(); break;
                }
                return true;
            }
        };
        float dw = getResources().getDisplayMetrics().density;
        FrameLayout.LayoutParams wlp = new FrameLayout.LayoutParams((int) (200 * dw), (int) (200 * dw), Gravity.BOTTOM | Gravity.START);
        wlp.leftMargin = (int) (24 * dw); wlp.bottomMargin = (int) (24 * dw);
        wheelView.setLayoutParams(wlp); wheelView.setVisibility(View.GONE); root.addView(wheelView);
        final Button wb = new Button(this);          // controls switch: buttons <-> steering wheel (HTML Settings > Controls)
        wb.setText("WHEEL"); wb.setAlpha(0.6f);
        wb.setOnClickListener(new View.OnClickListener() {
            boolean on = false;
            public void onClick(View v) {
                on = !on; wb.setText(on ? "BUTTONS" : "WHEEL"); nWheelMode(on ? 1 : 0);
                wheelView.setVisibility(on ? View.VISIBLE : View.GONE);
                bl.setVisibility(on ? View.GONE : View.VISIBLE); br.setVisibility(on ? View.GONE : View.VISIBLE);
            }
        });
        FrameLayout.LayoutParams wblp = new FrameLayout.LayoutParams((int) (110 * dw), (int) (56 * dw), Gravity.TOP | Gravity.START);
        wblp.setMargins((int) (136 * dw), (int) (16 * dw), 0, 0); root.addView(wb, wblp);
        final Button rb = new Button(this);          // reset car (HTML resetCar / R key)
        rb.setText("RESET"); rb.setAlpha(0.6f);
        rb.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { nReset(); } });
        FrameLayout.LayoutParams rblp = new FrameLayout.LayoutParams((int) (110 * dw), (int) (56 * dw), Gravity.TOP | Gravity.START);
        rblp.setMargins((int) (256 * dw), (int) (16 * dw), 0, 0); root.addView(rb, rblp);
        final Handler wh = new Handler();
        wh.post(new Runnable() { public void run() { if (wheelView.getVisibility() == View.VISIBLE) wheelView.invalidate(); wh.postDelayed(this, 16); } });
        nSens(1.8f);
        speed = new TextView(this);
        speed.setTextColor(Color.WHITE); speed.setTextSize(26);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END);
        lp.setMargins(0, 20, 30, 0);
        root.addView(speed, lp);
        setContentView(root);
        final Handler h = new Handler();
        h.post(new Runnable() { public void run() {
            speed.setText((int) nSpeed() + " km/h"); h.postDelayed(this, 100); } });
    }

    void add(FrameLayout root, String text, final int bit, int grav, int mx, int my) {
        Button bt = new Button(this);
        bt.setText(text); bt.setAlpha(0.6f);
        bt.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent e) {
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN) mask |= bit;
                else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) mask &= ~bit;
                nInput(mask | kmask);
                return true;
            }
        });
        int w = (bit <= 2) ? 140 : 190, hh = 100;
        float d = getResources().getDisplayMetrics().density;
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int) (w * d), (int) (hh * d), grav);
        if ((grav & Gravity.START) != 0) lp.leftMargin = (int) (mx * d); else lp.rightMargin = (int) (mx * d);
        lp.bottomMargin = (int) (my * d);
        root.addView(bt, lp);
    }

    // keyboard (HTML: W / S / A / D, arrows, Space = handbrake, R = reset)
    int keyBit(int k) {
        switch (k) {
            case KeyEvent.KEYCODE_W: case KeyEvent.KEYCODE_DPAD_UP: return 4;
            case KeyEvent.KEYCODE_S: case KeyEvent.KEYCODE_DPAD_DOWN: return 8;
            case KeyEvent.KEYCODE_A: case KeyEvent.KEYCODE_DPAD_LEFT: return 32;
            case KeyEvent.KEYCODE_D: case KeyEvent.KEYCODE_DPAD_RIGHT: return 64;
            case KeyEvent.KEYCODE_SPACE: return 16;
        }
        return 0;
    }
    @Override public boolean onKeyDown(int k, KeyEvent e) {
        if (k == KeyEvent.KEYCODE_R) { if (e.getRepeatCount() == 0) nReset(); return true; }
        int b = keyBit(k); if (b == 0) return super.onKeyDown(k, e);
        kmask |= b; nInput(mask | kmask); return true;
    }
    @Override public boolean onKeyUp(int k, KeyEvent e) {
        int b = keyBit(k); if (b == 0) return super.onKeyUp(k, e);
        kmask &= ~b; nInput(mask | kmask); return true;
    }

    @Override protected void onPause() { super.onPause(); gl.onPause(); }
    @Override protected void onResume() { super.onResume(); gl.onResume(); }
}
