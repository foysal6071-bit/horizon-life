// Sunny Drift - draws the meadow ponds (see pond.h): one camera-facing-free quad per pond, shaded like the road puddles (sky reflection, sun glint, wake rings).
#pragma once
#include <GLES3/gl3.h>
#include "road_render.h"
#include "pond.h"
#include "env_glsl.h"

namespace PondGL {
static const char* VS = R"GLSL(#version 300 es
uniform mat4 uVP; uniform vec4 uPond;   // x, y, z, radius
out vec2 vL; out vec3 wp;
void main(){ vec2 c = vec2(float(gl_VertexID & 1), float((gl_VertexID >> 1) & 1)) * 2.0 - 1.0; vL = c * 1.4; wp = vec3(uPond.x + c.x * uPond.w * 1.4, uPond.y, uPond.z + c.y * uPond.w * 1.4); gl_Position = uVP * vec4(wp, 1.0); }
)GLSL";
static const char* FS = R"GLSL(#version 300 es
precision highp float;
in vec2 vL; in vec3 wp; uniform vec3 uCam; uniform float uSeed, uClk, uSunK; uniform vec3 uSunD; uniform vec4 uRp[24]; uniform int uRpN; out vec4 o;
)GLSL" ENV_GLSL R"GLSL(
void main(){
  float d = length(vL), a = atan(vL.y, vL.x);
  float e = 1.0 + 0.12 * sin(3.0 * a + uSeed * 6.0) + 0.08 * sin(5.0 * a + 2.1 * uSeed * 6.0 + 1.3);
  float m = smoothstep(e, e - 0.12, d); if (m <= 0.0) discard;
  vec3 toCam = uCam - wp; float dist = length(toCam); vec3 V = toCam / dist;
  vec2 rw = wp.xz;
  vec2 gr = vec2(sin(rw.x * 1.7 + uClk * 0.8) * cos(rw.y * 1.3 - uClk * 0.6), cos(rw.x * 1.1 - uClk * 0.5) * sin(rw.y * 1.9 + uClk * 0.7)) * 0.03;
  if (dist < 70.0) for (int i = 0; i < 24; i++){
    if (i >= uRpN) break;
    vec4 rp = uRp[i]; vec2 dv = rw - rp.xy; float dd = length(dv);
    float rr0 = 0.25 + rp.z * 2.6, fade = rp.w * exp(-rp.z * 1.7);
    float k1 = (dd - rr0) * 6.0, k2 = (dd - rr0 * 0.6) * 8.0;
    gr += dv / max(dd, 0.02) * (exp(-k1 * k1) * sin((dd - rr0) * 22.0) + 0.5 * exp(-k2 * k2) * sin((dd - rr0 * 0.6) * 26.0)) * fade * 0.55;
  }
  vec3 N = normalize(vec3(gr.x, 1.0, gr.y));
  float NoV = max(dot(N, V), 1e-3);
  float F = clamp(0.04 + 0.96 * pow(1.0 - NoV, 5.0), 0.0, 1.0); F = max(F, 0.22);
  vec3 Rf = reflect(-V, N);
  vec3 refl = envC(Rf, 0.04);
  float depth = smoothstep(1.0, 0.35, d);                                   // shallow at the shore, deeper in the middle
  vec3 body = mix(L2(vec3(0.30, 0.34, 0.22)), L2(vec3(0.07, 0.11, 0.10)), depth);   // muddy green-brown water over the meadow soil
  vec3 glint = mix(vec3(1.0, 0.97, 0.92), vec3(1.0, 0.62, 0.28), uSunK) * pow(max(dot(Rf, uSunD), 0.0), 400.0) * 1.5;
  vec3 lin = mix(body, refl, F) + glint;
  vec3 c = pow(lin, vec3(1.0 / 2.2));
  c = mix(c, vec3(0.62, 0.80, 0.95), clamp(dist / 3750.0, 0.0, 1.0));
  o = vec4(c, m * mix(0.70, 0.92, depth));
}
)GLSL";
static GLuint gProg = 0, gVao = 0; static GLint uVP, uPond, uCam, uSeed, uClk, uSunK, uSunD, uRp, uRpN;
static void init(){
    gProg = RoadGL::makeProg(VS, FS); glGenVertexArrays(1, &gVao);
    uVP = glGetUniformLocation(gProg, "uVP"); uPond = glGetUniformLocation(gProg, "uPond"); uCam = glGetUniformLocation(gProg, "uCam"); uSeed = glGetUniformLocation(gProg, "uSeed");
    uClk = glGetUniformLocation(gProg, "uClk"); uSunK = glGetUniformLocation(gProg, "uSunK"); uSunD = glGetUniformLocation(gProg, "uSunD"); uRp = glGetUniformLocation(gProg, "uRp[0]"); uRpN = glGetUniformLocation(gProg, "uRpN");
}
static void draw(const float* VP, const float* eye){
    if (Pond::gP.empty() || !gProg) return;
    glUseProgram(gProg); glUniformMatrix4fv(uVP, 1, GL_FALSE, VP); glUniform3fv(uCam, 1, eye); glUniform1f(uClk, Weather::clock); glUniform1f(uSunK, Weather::sun); glUniform3fv(uSunD, 1, Weather::sunDir);
    float rp[WaterFx::MAXR * 4]; for (int i = 0; i < WaterFx::N; i++){ const WaterFx::Rip& q = WaterFx::R[i]; rp[i*4] = q.x; rp[i*4+1] = q.z; rp[i*4+2] = q.age; rp[i*4+3] = q.amp; }
    glUniform1i(uRpN, WaterFx::N); if (WaterFx::N) glUniform4fv(uRp, WaterFx::N, rp);
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); glDepthMask(GL_FALSE);
    glBindVertexArray(gVao);
    for (const Pond::P& p : Pond::gP){
        const float dx = p.x - eye[0], dz = p.z - eye[2]; if (dx*dx + dz*dz > 1400.f * 1400.f) continue;
        glUniform4f(uPond, p.x, p.y, p.z, p.r); glUniform1f(uSeed, p.seed); glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    }
    glBindVertexArray(0); glDepthMask(GL_TRUE); glDisable(GL_BLEND);
}
}   // namespace PondGL
