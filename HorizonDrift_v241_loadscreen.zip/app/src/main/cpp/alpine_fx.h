// Sunny Drift - alpine weather + light:
//   * valley fog      : a few soft, patchy fog sheets lying low over the valley (thickest at sunrise, thin at noon, a little at dusk)
//   * summit clouds   : cloud belts hugging the mountain flanks (sheets at 330 .. 610 m; the peaks poke through them)
//   * alpenglow       : sun-facing snow / ice glows pink (sunrise) or orange (sunset) - done in the terrain shader (bridge_render.h), strength set here
//   * snow patches + glacier tongues on the upper slopes - also in the terrain shader, switched on here
// Call update() once per frame (after SkyGL::stepTod), draw() right AFTER SkyGL::draw (the sheets are blended over ground and sky, no depth writes).
#pragma once
#include "nature_fx.h"
#include "quality.h"

namespace AlpineFx {

static const char* VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; uniform mat4 uVP; uniform float uY; out vec3 wp;
void main(){ wp = vec3(p.x, uY, p.z); gl_Position = uVP * vec4(wp, 1.0); }
)GLSL";
static const char* FS = R"GLSL(#version 300 es
precision highp float;
in vec3 wp; uniform vec3 uCam, uCol, uHaze; uniform float uT, uAmt, uMode, uSeed; uniform sampler2D uFbm; out vec4 o;
void main(){
  vec2 q = wp.xz; float d = length(q - uCam.xz);
  float n; float a;
  if (uMode < 0.5){                                   // ---- valley fog: broad patches, slowly drifting, clear right around the car ----
    n = 0.60*texture(uFbm, q*0.0016 + vec2(uT*0.0022 + uSeed, uT*0.0009)).r + 0.40*texture(uFbm, q*0.0049 - vec2(uT*0.0035, -uT*0.0016) + uSeed).g;
    float m = smoothstep(0.34, 0.66, n);
    float f = smoothstep(90.0, 420.0, d) * (1.0 - smoothstep(1500.0, 2600.0, d));
    a = m * f * uAmt;
  } else {                                            // ---- summit clouds: big soft banks, thicker in the middle, ragged at the rims ----
    n = 0.58*texture(uFbm, q*0.00055 + vec2(uT*0.0011 + uSeed, -uT*0.0006)).r + 0.42*texture(uFbm, q*0.0017 + vec2(-uT*0.0019, uT*0.0010) + uSeed).g;
    float m = smoothstep(0.42, 0.70, n);
    float f = smoothstep(500.0, 1100.0, d) * (1.0 - smoothstep(3000.0, 4200.0, d));
    a = m * f * uAmt;
    n = n * 0.5 + 0.5*m;
  }
  vec3 col = uCol * (0.86 + 0.20*n);
  col = mix(col, uHaze, clamp(d / 5200.0, 0.0, 0.45));
  o = vec4(col, clamp(a, 0.0, 0.85));
}
)GLSL";

static GLuint gProg = 0; static GLint uVP, uY, uCam, uCol, uHaze, uT, uAmt, uMode, uSeed, uFbm; static BridgeGL::Gpu gDisc; static bool gOk = false;
// current look (filled by update())
static float gFog = 0.f, gCloud = 0.f, gGlow = 0.f, gFogCol[3] = {0.9f, 0.93f, 0.97f}, gCloudCol[3] = {1, 1, 1}, gHazeC[3] = {0.72f, 0.87f, 0.98f}, gGlowCol[3] = {1.f, 0.55f, 0.42f};

static void init(){
    gProg = RoadGL::makeProg(VS, FS); if (!RoadGL::gLastOk){ gOk = false; return; }
    uVP = glGetUniformLocation(gProg, "uVP"); uY = glGetUniformLocation(gProg, "uY"); uCam = glGetUniformLocation(gProg, "uCam"); uCol = glGetUniformLocation(gProg, "uCol");
    uHaze = glGetUniformLocation(gProg, "uHaze"); uT = glGetUniformLocation(gProg, "uT"); uAmt = glGetUniformLocation(gProg, "uAmt"); uMode = glGetUniformLocation(gProg, "uMode");
    uSeed = glGetUniformLocation(gProg, "uSeed"); uFbm = glGetUniformLocation(gProg, "uFbm");
    // one big disc, 5 rings (1 / 700 / 1500 / 2600 / 4400 m), 64 segments; every layer re-uses it at another height (uY)
    const float R[5] = {1.f, 700.f, 1500.f, 2600.f, 4400.f}; const int NS = 64; std::vector<float> v; std::vector<uint32_t> idx;
    for (int i = 0; i < 5; i++) for (int j = 0; j < NS; j++){ const float a = (float)j / NS * 6.2831853f; v.push_back(std::cos(a) * R[i]); v.push_back(0.f); v.push_back(std::sin(a) * R[i]); }
    for (int i = 0; i < 4; i++) for (int j = 0; j < NS; j++){ const uint32_t a = i*NS + j, b = i*NS + (j+1) % NS, c = (i+1)*NS + j, d = (i+1)*NS + (j+1) % NS; const uint32_t t[6] = {a, c, b, b, c, d}; idx.insert(idx.end(), t, t + 6); }
    const int n[1] = {3}, o[1] = {0}; gDisc = BridgeGL::upload(v.data(), v.size() * 4, idx, 12, n, o, 1);
    gOk = gDisc.count > 0;
}

// every frame: how foggy / cloudy / glowing is it right now? (from the sun's height + side)
static void update(){
    const SkyGL::Env& E = SkyGL::gEnv; const float e = E.sun[1];
    const float dayW = E.day, lowK = (1.f - SkyGL::ss(.12f, .55f, e)) * dayW, morn = 1.f - SkyGL::ss(-.25f, .25f, E.sun[0]);
    // fog: strongest in the morning, light all day, a thin veil at dusk, almost none deep in the night
    gFog = std::min(1.f, 0.14f + 0.95f * lowK * morn + 0.32f * lowK * (1.f - morn) + 0.30f * E.tw) * (1.f - 0.55f * E.night);
    gCloud = std::min(1.f, 0.40f + 0.35f * dayW + 0.25f * E.tw) * (1.f - 0.35f * E.night);
    // alpenglow: only while the sun is low (sunrise / sunset / the twilight just after) - pink at sunrise, orange-red at sunset
    const float warm = std::min(1.f, std::max(SkyGL::warmK(), E.tw * 0.9f));
    gGlow = warm * (1.f - SkyGL::ss(0.30f, 0.80f, E.night));
    const float pink[3] = {1.00f, 0.52f, 0.50f}, orange[3] = {1.00f, 0.46f, 0.18f};
    for (int i = 0; i < 3; i++) gGlowCol[i] = orange[i] + (pink[i] - orange[i]) * morn;
    // colours: fog = the horizon air, cloud = the sky's cloud colour (white / gold / pink / dark at night)
    for (int i = 0; i < 3; i++){ gFogCol[i] = std::min(1.f, E.hor[i] * 0.55f + 0.45f * E.cl[i]); gCloudCol[i] = std::min(1.f, E.cl[i]); gHazeC[i] = E.hor[i]; }
    if (E.night > 0.01f){ const float k = 1.f - 0.80f * E.night; for (int i = 0; i < 3; i++){ gFogCol[i] *= k; gCloudCol[i] *= 1.f; } }
}

// push the alpine look into the terrain shader (alpenglow + snow patches + glacier). Call every frame before the ground is drawn.
static void applyTerrain(){
    const float snow = Quality::flat ? 0.f : 1.f;
    BridgeGL::setAlpine(Quality::level == 0 ? gGlow * 0.8f : gGlow, snow, gGlowCol, SkyGL::gEnv.sun);
}

static void draw(const float* VP, const float* eye, float t){
    if (!gOk || Quality::flat) return;
    const int lvl = Quality::level;                                   // 0 low, 1 normal, 2 high
    glEnable(GL_DEPTH_TEST); glDepthMask(GL_FALSE); glDisable(GL_CULL_FACE); glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glUseProgram(gProg); glUniformMatrix4fv(uVP, 1, GL_FALSE, VP); glUniform3fv(uCam, 1, eye); glUniform1f(uT, t); glUniform3fv(uHaze, 1, gHazeC);
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, RoadGL::gFbmTex); glUniform1i(uFbm, 0);
    // valley fog: low sheets, hills / banks above the sheet stay clear, the hollows fill up
    {   static const float Y[4] = {3.5f, 9.f, 17.f, 29.f}, W[4] = {0.55f, 0.45f, 0.38f, 0.30f}, S[4] = {0.f, 0.37f, 0.71f, 0.13f};
        const int nl = lvl == 0 ? 2 : (lvl == 1 ? 3 : 4);
        glUniform1f(uMode, 0.f); glUniform3fv(uCol, 1, gFogCol);
        for (int i = 0; i < nl; i++){ if (eye[1] > Y[i] + 25.f) continue; glUniform1f(uY, Y[i]); glUniform1f(uSeed, S[i]); glUniform1f(uAmt, gFog * W[i] * (lvl == 0 ? 1.25f : 1.f)); BridgeGL::drawGpu(gDisc); }
    }
    // summit clouds: belts at different heights wrapping the flanks and peaks
    {   static const float Y[3] = {330.f, 470.f, 610.f}, W[3] = {0.44f, 0.40f, 0.36f}, S[3] = {0.21f, 0.58f, 0.83f};
        const int nl = lvl == 0 ? 1 : (lvl == 1 ? 2 : 3); const int first = lvl == 0 ? 1 : 0;
        glUniform1f(uMode, 1.f); glUniform3fv(uCol, 1, gCloudCol);
        for (int i = first; i < first + nl && i < 3; i++){ glUniform1f(uY, Y[i]); glUniform1f(uSeed, S[i]); glUniform1f(uAmt, gCloud * W[i]); BridgeGL::drawGpu(gDisc); }
    }
    glDepthMask(GL_TRUE); glDisable(GL_BLEND);
}

} // namespace AlpineFx
