#pragma once
// Sunny Drift - Audi R8 car: C++ physics (v19 "realistic" rewrite of the HTML Veh model).
//  Dynamic bicycle model with, compared with the old HTML port (kept as tools/car_core_v18_html_port.h):
//    * real R8 mass distribution (44 / 56 front / rear), lower yaw inertia (mid-engine), 4-wheel track for load transfer
//    * Pacejka-style tyres with realistic cornering stiffness (B 13), load sensitivity and LATERAL load transfer (the axle that carries
//      the weight transfer loses grip) -> natural understeer on entry / power, lift-off rotation, trail-braking effects
//    * tyre relaxation (slip angle builds up over a short rolling distance) -> smooth, non-twitchy turn-in, less yaw ringing
//    * street-tyre grip: ~1.05 g lateral, ~1.2 g braking, realistic downforce (~140 kg at 200 km/h) and aero drag
//    * V10 torque curve (flat 5000-7000 rpm), AWD traction (front axle gets a share of the drive and loads the friction circle),
//      dual-clutch shifts (0.1 s), clutch-slip launch
//    * lighter electronic counter-steer assist in a slide (still there so touch / button steering stays drivable)
//  v20 (realism pass): real R8 top speed (320 km/h, electronically limited like the real car) with a 7-speed dual-clutch box, the gearbox holds its gear
//    in a drift and blips down under braking, a real handbrake (locks the REAL rear axle: slows the car and collapses rear grip), tyres that lose grip
//    smoothly once they slide (peak ~7.5 degrees, ~85 % left when sliding), speed-sensitive steering speed, softer counter-steer assist (no snap-back).
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include "tuning.h"
using namespace std;

static inline double clampd(double v, double a, double b){ return min(max(v, a), b); }
static inline double sgn(double v){ return v > 0 ? 1 : (v < 0 ? -1 : 0); }

// ======================= PHYSICS =======================
struct CarState {
    double x = 0, z = 0, heading = 0;
    double speed = 0, vy = 0, yaw = 0, steer = 0, steerAngle = 0;
    double throttle = 0, brake = 0, ax = 0, ay = 0, axS = 0, revTimer = 0;
    int gear = 1; double rpm = 900, shiftT = 0, ayLim = 9, hb = 0, drift = 0, fd = 0, slope = 0;
    bool reverse = false, braking = false, handOn = false;
    double aFr = 0, aRr = 0;          // relaxed (lagged) front / rear tyre slip angles
    double absAct = 0, tcsAct = 0, escAct = 0, lockF = 0, lockR = 0;   // telemetry: 0..1 activity of ABS / TCS / ESC, brake-lock level per axle
    double brakeTemp = 0, muNow = 1.15, rearUse = 0, frontUse = 0, assistAct = 0;   // brake temperature 0..1, grip under the tyres now (after the road condition), rear / front grip utilisation 0..1, drift / steering assist activity
    double latG = 0, lonG = 0;           // true body-frame accelerations in g (from the tyre forces; ay / ax above are kinematic)
    int shiftDir = 0;                  // last gear change: +1 up, -1 down (for the sound)
    bool limiter = false;              // engine on the rev limiter
};
struct Input   { bool gas = false, brake = false, left = false, right = false, hand = false; double thr = -1, brk = -1;   /* analog pedals 0..1, < 0 = use the on/off flags */ double sens = 1; bool useAnalog = false; double analog = 0; int shift = 0;   /* manual box: +1 = shift up, -1 = shift down (one pulse; ignored in automatic) */ };
// grip / rolling resistance under the tyres. mu / rr = mean of the four tyres; muF / muR = mean grip of the front / rear axle (< 0: same as mu);
// pull = (rolling resistance left side - right side): the car is dragged towards the side that is on the softer ground;
// muSide = (grip left - right) / (grip left + right): braking with one side on grass pulls the car towards the grippier side.
struct Surface { double mu = 1.15, rr = 0.028, muF = -1, muR = -1, pull = 0, muSide = 0; };   // default: tarmac

namespace Veh {
    const double G = 9.81, MASS = 1650, WHEELBASE = 2.8, WR = 0.40;
    const double RPM_K = 1.0 / (0.10472 * WR);
    const double TOP_KMH = 320.0;                    // R8 V10: electronically limited to ~320 km/h (change this one number to make the car slower / faster)
    const double VMAX = TOP_KMH / 3.6;
    const double IDLE = 900, REDLINE = 7000, EFF = 0.92, ENGINE_BRAKE = 30;
    // 7-speed S tronic: road speed (km/h) reached at the redline in each gear -> overall gear ratio (engine rpm per wheel rpm)
    const double RK = REDLINE * 3.6 / RPM_K;
    const double RATIOS[8] = {0, RK/78.0, RK/118.0, RK/162.0, RK/206.0, RK/250.0, RK/292.0, RK/338.0};
    const int TOP_GEAR = 7;
    const double REV_MAX = 20.0 / 3.6, REV_FORCE = 3600;
    const double BRAKE_DECEL = 13.0, K_AERO = 0.40, K_DOWN = 0.45, RR_OFFSET = 0.015;   // drag 0.5*rho*CdA, downforce ~140 kg at 200 km/h
    // tyres
    const double TYRE_K = 0.97, TYRE_KL = 1.06;      // peak friction: lateral / longitudinal (road tyres brake harder than they corner)
    const double TYRE_B = 12.2, TYRE_C = 1.5;        // cornering stiffness ~ 18 /rad, peak slip ~ 7.5 degrees, ~85 % of the peak force left in a full slide
    const double LOAD_SENS = 0.13, FZ_REF = MASS * G / 4;
    const double RELAX = 0.45;                       // tyre relaxation length (m)
#ifndef TUNE_DR
#define TUNE_DR 0.66
#endif
#ifndef TUNE_AS
#define TUNE_AS 0.5
#endif
    const double DRIVE_REAR = TUNE_DR;               // AWD, rear biased (R8: the front axle only gets power when the rear slips; 66 % rear on average)
    // chassis
    const double LA = 1.55, LB = 1.25, IZ = 2700, HCG = 0.46, TRACK = 1.64, LT_FRONT = 0.54;   // 44 / 56 weight distribution
    const double STEER_LOCK = 0.55, STEER_RATE = 3.6, STEER_RETURN = 6.0;
    const double MAX_SPEED = REDLINE / (RATIOS[7] * RPM_K);

    // 5.2 V10 style: strong low-end, flat 5000 - 7000 rpm
    double torque(double rpm){
        static const double R[8] = {900, 1500, 2500, 3500, 4500, 5500, 6500, 7300};
        static const double T[8] = {230, 330, 430, 500, 545, 565, 560, 500};
        double v;
        if (rpm <= R[0]) v = T[0];
        else if (rpm >= R[7]) v = T[7];
        else { int i = 0; while (rpm > R[i + 1]) i++; v = T[i] + (T[i + 1] - T[i]) * (rpm - R[i]) / (R[i + 1] - R[i]); }
        return v * clampd((REDLINE + 300 - rpm) / 300, 0, 1);       // rev limiter
    }

    // axle grip factor: static load sensitivity x lateral load transfer (per-tyre load swing dF on a tyre carrying Fz0)
    static inline double axleGrip(double Fa, double dF){
        const double fz0 = Fa * 0.5, k0 = 1 - LOAD_SENS * (fz0 / FZ_REF - 1), r = min(dF / max(fz0, 1.0), 1.0);
        return max(k0, 0.4) * (1 - LOAD_SENS * 1.6 * r * r);
    }

    static inline bool sane(const CarState& S){
        return std::isfinite(S.x) && std::isfinite(S.z) && std::isfinite(S.heading) && std::isfinite(S.speed) && std::isfinite(S.vy) && std::isfinite(S.yaw) &&
               std::isfinite(S.rpm) && std::isfinite(S.aFr) && std::isfinite(S.aRr) && std::isfinite(S.fd) && fabs(S.speed) < 200 && fabs(S.vy) < 80;
    }

    void step(CarState& S, const Input& inp, const Surface& surfIn, double dt){
        dt = clampd(dt, 0.0, 0.25);                                  // a stalled frame never becomes one huge physics step
        if (dt <= 0) return;
        const CarState S0 = S;                                       // known-good copy: if anything goes non-finite we fall back to it (no NaN, no teleport)
        // road condition (dry / wet / snow / ice) scales the grip + drag of every tyre; each tyre still samples its own surface
        Surface surf = surfIn; { const double km = Tune::roadMu(); surf.mu *= km; if (surf.muF > 0) surf.muF *= km; if (surf.muR > 0) surf.muR *= km; surf.rr *= Tune::roadRr(); }
        S.muNow = surf.mu;
        // ---- pedals ----
        double vx0 = S.speed, thrT = 0, brkT = 0; bool rev = false;
        const double gP = inp.gas ? (inp.thr >= 0 ? clampd(inp.thr, 0, 1) : 1.0) : 0.0, bP = inp.brake ? (inp.brk >= 0 ? clampd(inp.brk, 0, 1) : 1.0) : 0.0;
        const double gC = pow(gP, Tune::throttleCurve), bC = pow(bP, Tune::brakeCurve);      // pedal travel -> demand
        if (inp.gas && inp.brake) brkT = bC;
        else if (inp.gas){ if (vx0 < -0.8) brkT = 1; else thrT = gC; }
        else if (inp.brake){
            if (vx0 > 0.8) brkT = bC;
            else { S.revTimer += dt; if (S.revTimer > 0.3 || vx0 < -0.8){ rev = true; thrT = max(gC, bC); } else brkT = bC; }
        }
        if (!inp.brake || inp.gas) S.revTimer = 0;
        if (inp.hand){
            if (S.speed > 6) brkT = inp.brake ? 1 : 0;       // the handbrake lever only locks the rear axle (see below)
            else { brkT = 1; thrT = 0; rev = false; }
        }
        S.reverse = rev;
        S.throttle += (thrT - S.throttle) * (1 - exp(-dt * (thrT > S.throttle ? 7 : 14)));
        S.brake    += (brkT - S.brake)    * (1 - exp(-dt * (brkT > S.brake ? 18 : 20)));      // hydraulic brakes build up a little slower
        S.braking = S.brake > 0.25;
        S.handOn = inp.hand;
        { const double hbT = (inp.hand && S.speed > 5) ? 1 : 0; S.hb += (hbT - S.hb) * (1 - exp(-dt * (hbT > S.hb ? Tune::handbrakeRise : Tune::handbrakeRelease))); }   // locks fast, lets the rear grip come back progressively

        const double av = fabs(S.speed);

        // ---- steering input ----
        double steerIn = inp.useAnalog ? inp.analog : (inp.left ? 1 : 0) - (inp.right ? 1 : 0);
        double rate = ((steerIn == 0 || sgn(steerIn) != sgn(S.steer)) ? STEER_RETURN : STEER_RATE) * inp.sens / (1 + av / 55);        // the faster you go, the slower the wheel is turned (real steering feel)
        double dS = steerIn - S.steer;
        S.steer += sgn(dS) * min(fabs(dS), rate * dt);

        // ---- automatic dual-clutch gearbox ----
        S.shiftT = max(0.0, S.shiftT - dt);
        if (S.reverse || S.speed < -0.5) S.gear = 0;
        else {
            if (S.gear == 0) S.gear = 1;
            double sp = max(S.speed, 0.0), rpmG = sp * RATIOS[S.gear] * RPM_K;
            if (Tune::manualBox){
                // manual: the player shifts (one pulse per press); the box only protects the engine (no downshift into over-revving, 1st gear at a stop)
                if (S.shiftT <= 0 && inp.shift > 0 && S.gear < TOP_GEAR){ S.gear++; S.shiftT = 0.12; S.shiftDir = 1; }
                else if (S.shiftT <= 0 && inp.shift < 0 && S.gear > 1 && sp * RATIOS[S.gear - 1] * RPM_K < REDLINE - 200){ S.gear--; S.shiftT = 0.10; S.shiftDir = -1; }
                else if (S.gear > 1 && sp < 1.5 && S.throttle < 0.05){ S.gear = 1; }
            }
            else if (S.shiftT <= 0){
                const bool sliding = S.drift > 0.25;                                   // in a drift the box holds its gear (no upshift when you lift) and kicks down to stay in the power band
                if (S.gear < TOP_GEAR && (rpmG > 6700 || (!sliding && rpmG > 5200 && S.throttle < 0.15))){ S.gear++; S.shiftT = 0.12; S.shiftDir = 1; }
                else if (S.gear > 1 && sp * RATIOS[S.gear - 1] * RPM_K < 6400 &&
                         (rpmG < 2300 || (S.throttle > 0.9 && rpmG < 3600) || (sliding && S.throttle > 0.4 && rpmG < 4600) || (S.brake > 0.5 && rpmG < 3400))){ S.gear--; S.shiftT = 0.10; S.shiftDir = -1; }
            }
        }
        double gearR = S.gear == 0 ? 14 : RATIOS[S.gear];
        double rpmW = av * gearR * RPM_K, clutch = 1 - clampd(av / 6, 0, 1);
        double rpmTgt = max(rpmW, IDLE + S.throttle * 3600 * clutch);
        S.rpm += (rpmTgt - S.rpm) * (1 - exp(-dt * (rpmTgt > S.rpm ? 12 : 7)));
        S.rpm = min(S.rpm, REDLINE + 300);

        // ---- engine force ----
        double Fdrive = 0;
        if (S.throttle > 0.001){
            if (S.reverse) Fdrive = -S.throttle * REV_FORCE * clampd((REV_MAX + S.speed) / 3, 0, 1);
            else Fdrive = S.throttle * torque(max(S.rpm, 3300.0)) * RATIOS[S.gear] * EFF / WR *      // clutch slip keeps the engine in its torque band at the launch
                          (S.shiftT > 0 ? 1 - 0.5 * sin(M_PI * (1 - min(S.shiftT / 0.12, 1.0))) : 1);
        }
        if (!S.reverse) Fdrive *= clampd((VMAX - S.speed) / 2.5, 0, 1);
        S.fd += (Fdrive - S.fd) * (1 - exp(-dt * 16)); Fdrive = S.fd;

        // ---- grip budget -> steering authority ----
        const double rrS = max(surf.rr - RR_OFFSET, 0.008);          // tarmac 0.028 -> 0.013; soft ground keeps almost all of its drag
        double gripN0 = surf.mu * TYRE_K * (MASS * G + K_DOWN * S.speed * S.speed), gripL0 = surf.mu * TYRE_KL * (MASS * G + K_DOWN * S.speed * S.speed);
        double Flong = max(min(fabs(Fdrive), 0.8 * gripL0), S.brake * min(BRAKE_DECEL * MASS, 0.97 * gripL0));
        S.ayLim = sqrt(max(gripN0 * gripN0 - Flong * Flong, 0.04 * gripN0 * gripN0)) / MASS * 0.97;
        double sensK = clampd(0.7 + 0.3 * inp.sens, 0.85, 1.6);
        double lockSpeed = sensK * STEER_LOCK / (1 + pow(av / 46, 2));
        double lockGrip  = 0.06 * sensK + atan(WHEELBASE * S.ayLim * 1.1 / max(S.speed * S.speed, 1.0));
        double dDrv = S.steer * min(lockSpeed, lockGrip);
        double delta = dDrv;

        // ---- integrate: dynamic bicycle model ----
        int N = max(1, (int)ceil(dt / 0.005)); double h = dt / N, axAcc = 0, ayAcc = 0;
        for (int it = 0; it < N; it++){
            double vx = S.speed, sp = fabs(vx), sg = clampd(vx / 0.4, -1, 1);
            double wDyn = clampd((vx - 3) / 4, 0, 1);
            double down = K_DOWN * vx * vx;
            double muFl = (surf.muF > 0 ? surf.muF : surf.mu), muRl = (surf.muR > 0 ? surf.muR : surf.mu);
            double gripN = surf.mu * TYRE_KL * (MASS * G + down);
            bool wasDrift = S.drift > 0.3;
            double lim = (wasDrift ? 1.0 : 0.80) * gripN;
            double Fd = clampd(Fdrive, -lim, lim);
            double Fb = 0;   // (computed below, once the axle loads are known)
            double Fres = -sg * (rrS * MASS * G + K_AERO * vx * vx + MASS * fabs(S.ay) * 0.04);
            if (S.gear > 0){
                double eb = clampd(1 - S.throttle / 0.15, 0, 1) * clampd(1 - S.brake / 0.15, 0, 1);
                Fres -= sg * clampd(sp / 2, 0, 1) * ENGINE_BRAKE * RATIOS[S.gear] * (S.rpm / REDLINE) / WR * eb;
            }
            double Fg = -MASS * G * S.slope;

            // vertical loads: longitudinal transfer (accel / brake), downforce split 40 / 60, then lateral transfer per axle
            double dFz = clampd(MASS * S.axS * HCG / WHEELBASE, -0.22 * MASS * G, 0.22 * MASS * G);
            double FzF = max(MASS * G * LB / WHEELBASE - dFz + down * 0.40, 800.0);
            double FzR = max(MASS * G * LA / WHEELBASE + dFz + down * 0.60, 800.0);
            double latT = MASS * fabs(S.ay) * HCG / TRACK;                       // total lateral load transfer
            double gF = axleGrip(FzF, latT * LT_FRONT), gR = axleGrip(FzR, latT * (1 - LT_FRONT));
            double muF = muFl * TYRE_K * gF, muR = muRl * TYRE_K * gR;
            double muFL = muFl * TYRE_KL * gF, muRL = muRl * TYRE_KL * gR;
            // brake force per axle: pedal pressure -> front / rear bias -> each axle limited by ITS grip (load transfer makes the front do most of the work)
            double lockLatF = 1, lockLatR = 1;
            {
                const double fadeK = Tune::brakeFadeOn ? clampd((S.brakeTemp - 0.55) / 0.45, 0, 1) : 0.0;           // cooked brakes lose bite (optional)
                const double dem = S.brake * BRAKE_DECEL * MASS * (1 - Tune::fadeLoss * fadeK), cF = 0.97 * muFL * FzF, cR = 0.97 * muRL * FzR;
                double bF = dem * Tune::brakeBias, bR = dem * (1 - Tune::brakeBias);
                if (Tune::absOn){
                    const double pF = Tune::absFloor * cF / 0.97, pR = Tune::absFloor * cR / 0.97;
                    S.absAct = (bF > pF || bR > pR) ? 1.0 : S.absAct * exp(-h * 12);
                    bF = min(bF, pF); bR = min(bR, pR); S.lockF = S.lockR = 0;
                } else {
                    S.absAct = 0;
                    S.lockF = clampd((bF / max(cF, 1.0) - 1) / 0.25, 0, 1); S.lockR = clampd((bR / max(cR, 1.0) - 1) / 0.25, 0, 1);
                    if (S.lockF > 0){ bF = min(bF, cF) * (1 - (1 - Tune::lockedGrip) * S.lockF); lockLatF = 1 - (1 - Tune::lockedLateral) * S.lockF; }
                    if (S.lockR > 0){ bR = min(bR, cR) * (1 - (1 - Tune::lockedGrip) * S.lockR); lockLatR = 1 - (1 - Tune::lockedLateral) * S.lockR; }
                }
                Fb = bF + bR;
                // brake temperature: heated by the braking work (F * v), cooled by airflow; 0.30 per MJ -> two hard stops from 200 km/h cook the brakes
                S.brakeTemp = clampd(S.brakeTemp + Fb * sp * h * Tune::fadeHeat * 1e-6 - S.brakeTemp * (Tune::fadeCool + 0.002 * sp) * h, 0, 1.2);
            }
            // traction control: cut the drive force when the rear tyres are asked for more than they have (leaves room for power oversteer)
            S.tcsAct *= exp(-h * 10);
            if (Tune::tcsOn && S.gear > 0 && !S.reverse && S.hb < 0.2){
                const double uD = 0.8 * fabs(Fd) * DRIVE_REAR / max(muRL * FzR, 1.0), k = clampd((uD - Tune::tcsStart) / 0.16, 0, 1);
                if (k > 0){ Fd *= 1 - Tune::tcsStrength * k; S.tcsAct = max(S.tcsAct, k); }
            }

            double uA = max(vx, 2.5), beta = atan2(S.vy, uA);
            double usF = clampd((Fb * 0.68 + fabs(Fd) * (1 - DRIVE_REAR) * 0.8) / (muFL * FzF), 0, 0.95);
            const double Fhb = S.hb * Tune::handbrakeStrength * muRL * FzR;                          // handbrake: the rear tyres are (nearly) locked, they brake the car with part of their grip
            double usR = clampd((Tune::rearDriveLoad * fabs(Fd * DRIVE_REAR - sg * Fb * 0.32) + Fhb) / (muRL * FzR), 0, 0.92);
            double Fx = Fd - sg * Fb - sg * Fhb * clampd(sp / 3, 0, 1) + Fres + Fg;
            double capF = sqrt(1 - usF * usF) * lockLatF;
            // braking while turning at speed: the weight leaves the rear axle and the rear tyres give up first -> the tail steps out into a drift
            const double bkD = (vx > 0 ? 1.0 : 0.0) * S.brake * clampd(fabs(S.steer) / 0.35, 0, 1) * clampd((sp - 9) / 12, 0, 1);
            double capR = lockLatR * sqrt(1 - usR * usR) * (1 - 0.35 * S.hb) * (1 - 0.22 * bkD) * (1 + 1.3 * clampd((fabs(beta) - 0.55) / 0.4, 0, 1));
            // drift assist: up to ~30 deg of slide the electronic counter-steer only helps half as much (the player holds the angle with the wheel), beyond ~45 deg it helps MORE (rescue before a spin)
            const double asK = Tune::driftAssist ? 0.5 + (0.5 + Tune::driftAssistK) * clampd((fabs(beta) - 0.55) / 0.25, 0, 1) : 1.0;
            double wAs = clampd((fabs(beta) - 0.08) / 0.15, 0, 1) * Tune::counterSteer * asK * wDyn;   // counter-steer assist in a slide
            delta = clampd(dDrv + wAs * clampd(beta, -0.7, 0.7), -0.65, 0.65);
            if (Tune::steerAssist && wDyn > 0.5 && fabs(beta) < 0.2 && S.aFr * delta < 0){   // understeer relief (only while gripping, never while sliding): take lock off a plowing front axle
                const double u = clampd((fabs(S.aFr) - Tune::steerAssistStart) / 0.16, 0, 1); delta *= 1 - 0.45 * u; S.assistAct = max(S.assistAct * exp(-h * 6), u);
            } else S.assistAct *= exp(-h * 6);
            if (Tune::driftAssist && S.throttle > 0.4 && S.hb < 0.3 && S.drift > 0.25 && wDyn > 0.5)      // throttle keeps the tail out: power takes rear grip, the driver steers the angle with the wheel
                capR *= 1 - Tune::driftHold * S.throttle * clampd((fabs(beta) - 0.15) / 0.25, 0, 1) * clampd((0.85 - fabs(beta)) / 0.25, 0, 1);
            if (Tune::driftAssist && S.throttle < 0.1 && S.hb < 0.2 && S.drift > 0.3) capR *= 1 + 0.25 * clampd((fabs(beta) - 0.2) / 0.4, 0, 1);   // lift-off in a slide: the rear tyres bite back progressively

            // slip angles with tyre relaxation: the lateral force follows the kinematic slip over ~RELAX metres of rolling
            double aFk = atan2(S.vy + LA * S.yaw, uA) - delta;
            double aRk = atan2(S.vy - LB * S.yaw, uA);
            double kr = 1 - exp(-max(sp, 4.0) * h / RELAX);
            S.aFr += (aFk - S.aFr) * kr; S.aRr += (aRk - S.aRr) * kr;
            double FyF = -muF * FzF * capF * sin(TYRE_C * atan(TYRE_B * S.aFr));
            double FyR = -muR * FzR * capR * sin(TYRE_C * atan(TYRE_B * S.aRr));
            double cd = cos(delta), sd = sin(delta);

            S.speed += (Fx - FyF * sd * wDyn) / MASS * h;
            S.speed = clampd(S.speed, -REV_MAX, VMAX * (1 + 0.03 * clampd(-S.slope * 8, 0, 1)));
            axAcc += Fx / MASS; ayAcc += (FyF * cd + FyR) / MASS;
            S.vy  += (FyF * cd + FyR) / MASS * h * wDyn; S.vy = clampd(S.vy, -60, 60);
            S.frontUse = usF; S.rearUse = usR;
            // left / right asymmetry: the side on softer ground drags more (rolling resistance), and under braking the grippier side bites harder
            const double yawAsym = (0.5 * MASS * G * surf.pull * clampd(sp / 2, 0, 1) + 0.5 * Fb * surf.muSide) * 0.85 / IZ;
            S.yaw += ((LA * FyF * cd - LB * FyR) / IZ - 0.55 * S.yaw + yawAsym) * h * wDyn;
            if (wDyn < 1){
                double rK = S.speed * tan(delta) / WHEELBASE;
                S.yaw += (rK - S.yaw) * (1 - exp(-h / 0.05)) * (1 - wDyn);
                S.vy  *= exp(-8 * (1 - wDyn) * h);
                S.aFr *= exp(-8 * (1 - wDyn) * h); S.aRr *= exp(-8 * (1 - wDyn) * h);
            }
            if (Tune::escOn && wDyn > 0.5 && S.hb < 0.3){                          // stability control: damp a yaw that is running away (large slip angle); small drift angles are left alone
                const double e = clampd((fabs(beta) - Tune::escStart) / 0.35, 0, 1) * (S.throttle > 0.5 ? 0.6 : 1.0);
                S.escAct = max(S.escAct * exp(-h * 8), e); S.yaw *= exp(-Tune::escStrength * 2.2 * e * h);
            } else S.escAct *= exp(-h * 8);
            S.yaw = clampd(S.yaw, -2.6, 2.6);
            if (fabs(S.speed) < 0.08 && S.throttle < 0.02 && (fabs(S.slope) < 0.3 || S.brake > 0.3 || S.handOn)){ S.speed = 0; S.vy = 0; S.yaw = 0; S.aFr = S.aRr = 0; }
            double dH = S.yaw * h; S.heading += dH;
            double a = dH * wDyn, c = cos(a), sn = sin(a), sp0 = S.speed;
            S.speed = sp0 * c + S.vy * sn; S.vy = -sp0 * sn + S.vy * c;
            double sH = sin(S.heading), cH = cos(S.heading);
            S.x += (S.speed * sH + S.vy * cH) * h;
            S.z += (S.speed * cH - S.vy * sH) * h;
        }
        S.steerAngle = clampd(delta, -0.6, 0.6);
        double bR = fabs(atan2(S.vy - LB * S.yaw, max(S.speed, 2.5)));
        double tgt = S.speed > 5 ? clampd((bR - 0.12) / 0.2, 0, 1) : 0;
        S.drift += (tgt - S.drift) * (1 - exp(-dt * (tgt > S.drift ? 10 : 3)));
        S.ax = axAcc / N; S.latG += (ayAcc / N / G - S.latG) * (1 - exp(-dt * 12)); S.lonG += (S.ax / G - S.lonG) * (1 - exp(-dt * 12));
        S.axS += (S.ax - S.axS) * (1 - exp(-dt * 5));
        S.ay = S.speed * S.yaw;
        S.limiter = S.rpm > REDLINE + 50 && S.throttle > 0.3;
        if (!sane(S)){ S = S0; S.speed = S.vy = S.yaw = S.aFr = S.aRr = S.fd = 0; }    // a non-finite / runaway state falls back to the last good one, standing still
    }
}
