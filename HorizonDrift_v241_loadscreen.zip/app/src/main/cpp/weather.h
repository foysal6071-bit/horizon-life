#pragma once
// Sunny Drift - rain / wet road / fog / golden-light weather has been REMOVED. The look now comes from the time of day (sky.h: morning, noon,
// afternoon, sunset, dusk, night). This tiny header only keeps what the road shader and the post pass still read: constant zeros, the clock and the sun direction.
#include <cmath>

namespace Weather {

static const float rain = 0.f, fog = 0.f;                  // no rain falling, clear air
static const float wet = 0.85f;                              // just after the rain: damp dark tarmac with wet patches, puddles in the dips, fallen leaves (road_shaders.h)
static float sun = 0.f;                                    // warm low-sun amount 0..1 (set every frame from the time of day, see native-lib.cpp)
static float clock = 0.f;                                  // seconds
static float sunDir[3] = {0.f, 0.f, 0.f};                  // unit vector towards the sun (filled from the sky each frame)

static void update(float dt){ clock += dt; if (clock > 4000.f) clock -= 4000.f; }

}   // namespace Weather
