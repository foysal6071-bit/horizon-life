#pragma once
// Sunny Drift - one shared "sun direction" for every lit surface (terrain, trees, road, car, village, water ...).
// The shaders used to hard-code the light direction; now they write SUNL, and a tiny uniform block (binding point 7) carries the real sun of the current
// time of day: low and long-shadowed in the morning / evening, high at noon. The shader source is patched when it is compiled (see patch()),
// and every program that uses SUNL is attached to the block after linking (see attach()).
#include <GLES3/gl3.h>
#include <cmath>
#include <string>

namespace SunLight {

static GLuint gUbo = 0;
static float gL[4] = {0.4f / 0.94f, 0.8f / 0.94f, 0.3f / 0.94f, 0.f};     // same as the old fixed light until the first update

static void ensure(){
    if (gUbo) return;
    glGenBuffers(1, &gUbo); glBindBuffer(GL_UNIFORM_BUFFER, gUbo);
    glBufferData(GL_UNIFORM_BUFFER, 16, gL, GL_DYNAMIC_DRAW);
    glBindBufferBase(GL_UNIFORM_BUFFER, 7, gUbo);
}
// shader source -> source with the block declared (only if it mentions SUNL)
static std::string patch(const char* src){
    std::string s(src);
    if (s.find("SUNL") == std::string::npos) return s;
    const size_t p = s.find('\n');
    if (p == std::string::npos) return s;
    s.insert(p + 1, "layout(std140) uniform SunBlk { highp vec4 uSunL; };\n#define SUNL uSunL.xyz\n");
    return s;
}
static void shaderSource(GLuint sh, const char* src){ const std::string s = patch(src); const char* c = s.c_str(); glShaderSource(sh, 1, &c, nullptr); }
// call after glLinkProgram
static void attach(GLuint prog){
    if (!prog) return;
    const GLuint bi = glGetUniformBlockIndex(prog, "SunBlk");
    if (bi == GL_INVALID_INDEX) return;
    ensure(); glUniformBlockBinding(prog, bi, 7);
}
// sun = unit vector towards the sun (world). The direction follows the sun, but its height is compressed so the ground never goes black when the sun is low
// (no camera exposure in this renderer): noon keeps the old strong top light, morning / evening get a clearly lower, longer-shadow light.
static void update(const float* sun){
    ensure();
    float hx = sun[0], hz = sun[2]; float hl = std::sqrt(hx*hx + hz*hz); if (hl < 1e-4f){ hx = 0.f; hz = 1.f; hl = 1.f; }
    hx /= hl; hz /= hl;
    const float sy = std::fmin(std::fmax(sun[1], 0.f), 1.f);
    const float ey = 0.38f + 0.50f * sy, ex = std::sqrt(std::fmax(1.f - ey*ey, 0.f));
    gL[0] = hx * ex; gL[1] = ey; gL[2] = hz * ex; gL[3] = 0.f;
    glBindBuffer(GL_UNIFORM_BUFFER, gUbo); glBufferSubData(GL_UNIFORM_BUFFER, 0, 16, gL);
}

}   // namespace SunLight
