// Sunny Drift - OpenGL ES 3 rendering of the river (carved bed + water) and the concrete road bridges (see river.h / bridge.h).
//  draw order = HTML: river bed -> roads -> bridge deck / beams / rails / posts (opaque) -> water -> dirt + road-blend overlays (blended)
#pragma once
#include <GLES3/gl3.h>
#include <cstring>
#include "bridge.h"
#include "quality.h"
#include "grass_tex.h"       // HTML grass texture (blades + patches) painted on the CPU
#include "road_render.h"

namespace BridgeGL {

static const char* TER_VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in vec3 c; layout(location=2) in vec3 n;
uniform mat4 uVP; out vec3 vC; out vec3 vN; out vec3 wp;
void main(){ vC = c; vN = n; wp = p; gl_Position = uVP * vec4(p, 1.0); }
)GLSL";
static const char* TER_FS = R"GLSL(#version 300 es
precision highp float;
in vec3 vC; in vec3 vN; in vec3 wp; uniform vec3 uCam; uniform sampler2D uGrass; uniform float uTime; out vec4 o;
uniform vec4 uAlp;       // x = alpenglow strength, y = snow-patch + glacier amount, z/w = unused
uniform vec3 uAlpCol;    // alpenglow colour (pink at sunrise, orange at sunset)
uniform vec3 uSunW;      // real sun direction (world)
uniform float uMQ;       // Settings > Graphics level for the mountains: 0 Low (cheap), 1 Normal, 2 High
float h21(vec2 p){ vec3 p3 = fract(vec3(p.xyx)*0.1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y)*p3.z); }   // sin-free hash: pure ALU, cheaper on mobile GPUs
float vn(vec2 p){ vec2 i = floor(p), f = fract(p); f = f*f*(3.0 - 2.0*f);
  return mix(mix(h21(i), h21(i + vec2(1,0)), f.x), mix(h21(i + vec2(0,1)), h21(i + vec2(1,1)), f.x), f.y); }
float fbm2(vec2 p){ return vn(p)*0.667 + vn(p*2.03)*0.333; }                                   // cheap 2-octave noise
float fbm3(vec2 p){ return vn(p)*0.571 + vn(p*2.03)*0.286 + vn(p*4.12)*0.143; }               // 3-octave noise
void main(){
  float dist = length(uCam - wp);
  float near = 1.0 - smoothstep(60.0, 420.0, dist);
  vec2 q = wp.xz;
  vec3 N = normalize(vN);
  float slope = 1.0 - clamp(N.y, 0.0, 1.0);
  float flatG = 1.0 - smoothstep(0.25, 0.6, slope);                                  // 1 on grass, 0 on steep rock
  float h0 = 0.5;
  // ---- fine relief + blade glitter: only within ~150 m (the expensive part is skipped for everything far away) ----
  float nearB = 0.0;
  if (dist < 90.0){
    float e = 0.35; h0 = fbm2(q*0.9); float hx = fbm2((q + vec2(e, 0.0))*0.9), hz = fbm2((q + vec2(0.0, e))*0.9);
    N = normalize(N + vec3(h0 - hx, 0.0, h0 - hz) * (1.6*near));
    nearB = (1.0 - smoothstep(12.0, 85.0, dist)) * flatG;
    if (nearB > 0.02){ float b1 = vn(q*17.0), b2 = vn(q*17.0 + vec2(7.3, 2.1));
      N = normalize(N + vec3(b1 - 0.5, 0.0, b2 - 0.5)*1.1*nearB); }                    // every blade leans a different way
  }
  // ---- mountain rock relief (Normal / High): ridged noise bends the normal on steep faces, so cliffs read as broken rock instead of smooth low-poly planes; fades far away (no shimmer) ----
  float rockK = 0.0, rockV = 0.5;
  if (uMQ > 0.5 && wp.y > 60.0 && dist > 90.0 && dist < 3200.0){
    rockK = smoothstep(0.16, 0.42, slope) * smoothstep(60.0, 150.0, wp.y) * (1.0 - smoothstep(1800.0, 3200.0, dist));
    if (rockK > 0.01){
      vec2 rp = wp.xz*0.055 + vec2(wp.y*0.11, -wp.y*0.07); const float e = 0.12;
      float r0 = 1.0 - abs(2.0*vn(rp) - 1.0), rx = 1.0 - abs(2.0*vn(rp + vec2(e, 0.0)) - 1.0), rz = 1.0 - abs(2.0*vn(rp + vec2(0.0, e)) - 1.0);
      if (uMQ > 1.5){ vec2 rp2 = rp*2.7 + 5.0; r0 += 0.5*(1.0 - abs(2.0*vn(rp2) - 1.0)); rx += 0.5*(1.0 - abs(2.0*vn(rp2 + vec2(e*2.7, 0.0)) - 1.0)); rz += 0.5*(1.0 - abs(2.0*vn(rp2 + vec2(0.0, e*2.7)) - 1.0)); }
      N = normalize(N + vec3(r0 - rx, 0.0, r0 - rz) * (2.2 + 1.2*(uMQ - 1.0)) * rockK);
      rockV = r0 * (uMQ > 1.5 ? 0.667 : 1.0);
    }
  }
  vec3 L = SUNL;
  float m1 = fbm3(q*0.045), m2 = (dist < 200.0) ? fbm2(q*0.35) : 0.5, m3 = (dist < 120.0) ? vn(q*3.1) : 0.5;
  vec3 col = vC * (0.82 + 0.36*m1) * (0.92 + 0.16*m2) * (0.95 + 0.10*mix(0.5, m3, near));
  // ---- wind: gusts travel across the meadow as slow soft waves, with a faster ripple on top (0..1; 0.5 = calm). Only computed within ~450 m ----
  const vec2 WD = vec2(0.85, 0.53);
  float wv = 0.5;
  if (dist < 220.0 && flatG > 0.02){
    float gust = fbm2(q*0.03 - WD*uTime*2.2);
    float rip = sin(dot(q, WD)*0.6 - uTime*2.6 + fbm2(q*0.11)*5.0)*0.5 + 0.5;
    wv = mix(0.5, gust*0.65 + rip*0.35, 1.0 - smoothstep(120.0, 220.0, dist));
  }
  vec2 wo = WD*(wv - 0.5)*0.05;                                                     // blades bend with the wind: the fine blade pattern leans / shimmers
  vec3 gt = texture(uGrass, wp.xz*0.25).rgb * (0.72 + 0.56*texture(uGrass, wp.xz*0.0137 + 0.37).g);
  float nearD = 1.0 - smoothstep(10.0, 70.0, dist);
  gt *= mix(vec3(1.0), texture(uGrass, wp.xz*1.13 + 0.5).rgb*1.22, 0.60*nearD);   // 4x finer blade tile close up
  {   // close up: individual SMALL blades (two rotated, finer samples of the blade tile, ~0.2 - 0.35 m per tile, only their light / dark pattern so the colour stays)
    const float nearF = 1.0 - smoothstep(5.0, 55.0, dist);
    if (nearF > 0.01){
      const vec3 lw = vec3(0.299, 0.587, 0.114);
      float v = dot(texture(uGrass, wp.xz*4.3 + 0.21 + wo).rgb, lw) * dot(texture(uGrass, vec2(wp.z, -wp.x)*2.9 + 0.63 - wo).rgb, lw) / 0.37;
      gt *= mix(1.0, clamp(v, 0.35, 1.7), 0.60*nearF);
    }
  }
  float sw = 0.5;
  if (dist < 300.0){
    sw = fbm2(q*vec2(0.11, 0.045) + vec2(3.1, 8.7));                                 // long wind swaths: flattened grass is lighter / yellower
    col *= mix(vec3(0.93, 0.95, 0.86), vec3(1.12, 1.08, 0.82), smoothstep(0.35, 0.68, sw));
    col = mix(col, col*vec3(1.10, 0.98, 0.72), clamp((m1 - 0.52)*1.6, 0.0, 0.5));
  }
  float gk = (1.0 - smoothstep(0.55, 0.75, dot(vC, vec3(0.299,0.587,0.114)))) * smoothstep(-0.03, 0.02, vC.g - vC.r);   // no grass texture on snow / rock
  col *= mix(vec3(1.0), gt*1.08, (1.0 - smoothstep(0.25, 0.6, slope)) * gk);
  col *= 1.0 + (wv - 0.5)*0.34*flatG*gk*vec3(1.0, 1.04, 0.86);                       // where a gust bends the blades the field turns lighter / silvery, in the lulls darker
  if (dist < 160.0){                                                                   // realistic alpine wildflowers: meadow clumps of small 5-petal flowers, grass only
    float gm = flatG * gk * (1.0 - smoothstep(150.0, 260.0, wp.y));
    float pn = fbm3(q*0.028 + vec2(5.0, 9.0))*0.8 + fbm2(q*0.30)*0.2;                    // ragged, irregular drifts
    float dens = max(smoothstep(0.50, 0.74, pn), 0.05*smoothstep(0.40, 0.55, pn)) * gm;  // dense in drifts, a few strays elsewhere
    if (dens > 0.01){
      vec2 pc = floor(q*0.035);
      float s1 = h21(pc + 4.7), s2 = h21(pc + 13.3);
      vec3 cY = vec3(0.98, 0.78, 0.08), cW = vec3(0.96, 0.96, 0.92), cP = vec3(0.50, 0.24, 0.78), cB = vec3(0.34, 0.36, 0.86);
      vec3 sp1 = s1 < 0.42 ? cY : (s1 < 0.74 ? cW : cP);                                // main species of this drift
      vec3 sp2 = s2 < 0.35 ? cY : (s2 < 0.65 ? cW : (s2 < 0.85 ? cP : cB));             // second species mixed in
      float fade = 1.0 - smoothstep(45.0, 100.0, dist);
      float cover = 0.0;
      if (fade > 0.01){
        vec3 fcol = vec3(0.0); float fa = 0.0;
        for (int L = 0; L < 2; L++){
          float cs = (L == 0) ? 0.32 : 0.85, Rr = (L == 0) ? 0.055 : 0.10;
          vec2 g = (q + WD*(wv - 0.5)*0.08 + WD*sin(uTime*2.3 + q.x*0.9 + q.y*0.7)*0.012*(0.5 + wv))/cs, id = floor(g), f = fract(g) - 0.5;   // flowers sway in the gusts

          vec2 off = (vec2(h21(id + 3.1 + float(L)*5.0), h21(id + 7.7 + float(L)*5.0)) - 0.5)*0.6;
          float hs = h21(id + 1.3 + float(L)*9.0);
          float has = step(1.0 - dens*(L == 0 ? 0.85 : 0.5), hs);
          if (has > 0.5){
            vec2 dv = (f - off)*cs; float d = length(dv);
            float R = Rr*(0.7 + 0.6*h21(id + 2.2));
            float ang = (dist < 45.0) ? atan(dv.y, dv.x) : 0.0;
            float rr = d / (1.0 + ((dist < 45.0) ? 0.28*cos(5.0*ang + hs*6.0) : 0.0));  // 5 petals up close
            float pet = smoothstep(R, R*0.72, rr);
            vec3 pc2 = (h21(id + 9.1) < 0.7) ? ((L == 0) ? sp1 : sp2) : ((L == 0) ? sp2 : sp1);
            pc2 *= 0.85 + 0.25*h21(id + 6.6);                                                  // petal tone varies flower to flower
            vec3 cen = (pc2.b > 0.6 && pc2.r > 0.9) ? vec3(0.95, 0.72, 0.05) : pc2*0.55;      // daisy / bellflower centre
            pc2 = mix(pc2, cen, smoothstep(R*0.38, R*0.22, d));
            pc2 *= 0.80 + 0.20*smoothstep(0.0, R, d) ;                                          // slightly shadowed toward the middle
            if (pet > fa){ fa = pet; fcol = pc2; }
          }
        }
        col = mix(col, fcol, fa*fade);
      }
      cover = dens*0.22*smoothstep(30.0, 80.0, dist)*(1.0 - smoothstep(100.0, 160.0, dist)); // far away: the drift reads as a soft colour haze
      col = mix(col, col*0.82 + sp1*0.22, cover);
    }
  }
  col *= 1.0 + rockK*(rockV - 0.55)*0.55;                                              // rock texture: darker cracks, lighter ribs
  float strata = sin(wp.y*2.2 + m1*6.0)*0.5 + 0.5;
  col *= 1.0 - smoothstep(0.25, 0.6, slope) * (0.10 + 0.12*strata);
  // ---- alpine extras (mountain ring only: > 400 m from the camera and high up) ----
  float iceK = 0.0, snowK = 0.0;
  if (uAlp.y > 0.01 && wp.y > 90.0 && dist > 380.0){
    const vec3 lw2 = vec3(0.299, 0.587, 0.114);
    float farK = smoothstep(380.0, 700.0, dist);
    // snow patches: ragged drifts on the upper slopes, below the solid snow line, mostly on gentler / shaded ground
    float pn = fbm3(q*0.012 + vec2(17.0, 3.0))*0.75 + fbm2(q*0.05)*0.25;
    float alt = smoothstep(95.0, 240.0, wp.y + (pn - 0.5)*70.0);
    snowK = smoothstep(0.50, 0.60, pn) * alt * (1.0 - smoothstep(0.40, 0.75, slope)) * farK * uAlp.y;
    col = mix(col, vec3(0.92, 0.95, 1.00), snowK*0.92);
    // glacier: blue-white ice tongues in the snow zone, crevasses across the flow
    float sm = smoothstep(0.62, 0.82, dot(col, lw2));
    float gm = smoothstep(0.52, 0.64, fbm2(q*0.0042 + vec2(5.0, 31.0)));
    float galt = smoothstep(210.0, 290.0, wp.y) * (1.0 - smoothstep(560.0, 700.0, wp.y));
    float gsl = smoothstep(0.04, 0.12, slope) * (1.0 - smoothstep(0.34, 0.50, slope));
    iceK = gm * galt * gsl * sm * farK * uAlp.y;
    vec2 fl = normalize(N.xz + 1e-4);
    float cv = vn(vec2(dot(q, fl)*0.060, dot(q, vec2(-fl.y, fl.x))*0.40));
    float crev = (1.0 - smoothstep(0.0, 0.06, abs(cv - 0.5))) * 0.5;
    vec3 ice = mix(vec3(0.60, 0.80, 0.93), vec3(0.74, 0.90, 0.98), vn(q*0.05));
    ice *= 1.0 - crev*0.35;
    col = mix(col, ice, iceK*0.85);
  }
  float d = max(dot(N, L), 0.0);
  float wrap = max(dot(N, L)*0.5 + 0.5, 0.0);
  vec3 sun = vec3(1.06, 0.97, 0.84), sky = vec3(0.50, 0.66, 0.95), gnd = vec3(0.30, 0.27, 0.20);
  vec3 amb = mix(gnd, sky, N.y*0.5 + 0.5) * 0.55;
  float ao = 0.78 + 0.22*smoothstep(0.35, 0.65, h0*0.5 + m1*0.5);
  vec3 c = col * (amb*ao + sun*(0.55*d + 0.20*wrap));
  if (dist < 150.0 && flatG > 0.05){                                                  // grass sheen / back-light: mid-range only
    vec3 V = normalize(uCam - wp);
    float g2 = flatG * (0.35 + 0.65*near);
    float back = pow(max(dot(-V, L), 0.0), 3.0) * (0.4 + 0.6*clamp(N.y, 0.0, 1.0));
    c += col * vec3(0.85, 1.0, 0.20) * back * 0.55 * g2;
    float rim = pow(1.0 - max(dot(N, V), 0.0), 3.0);
    c += vec3(0.50, 0.68, 0.28) * rim * (0.10 + 0.14*sw) * g2 * (0.4 + d);
  }
  vec3 hzc = vec3(0.72, 0.87, 0.98);
  float fog = 1.0 - exp(-pow(dist/2850.0, 1.35));
  if (uMQ > 0.5 && wp.y > 40.0){                                                         // atmospheric perspective: far mountains fade to a cool blue-grey veil, lower slopes hazier than the summits
    float aer = smoothstep(900.0, 4200.0, dist) * (0.30 + 0.12*uMQ) * (1.0 - 0.45*clamp(wp.y/700.0, 0.0, 1.0));
    fog = clamp(fog + aer*(1.0 - fog), 0.0, 1.0);
  }
  c = mix(c, mix(hzc, vec3(0.66, 0.80, 0.96), clamp(wp.y/120.0, 0.0, 1.0)), clamp(fog, 0.0, 1.0));
  if (iceK > 0.01){                                                                    // ice is glossy: a cool sheen toward the sun
    vec3 Vv = normalize(uCam - wp); float sh = pow(max(dot(reflect(-L, N), Vv), 0.0), 18.0);
    c += vec3(0.55, 0.75, 0.90) * sh * 0.35 * iceK;
  }
  if (uAlp.x > 0.01 && wp.y > 120.0 && dist > 380.0){                                  // ALPENGLOW: sun-facing snow / ice glows pink-orange at sunrise + sunset
    float lum = dot(vC, vec3(0.299, 0.587, 0.114));
    float snowM = max(smoothstep(0.62, 0.82, lum), max(snowK, iceK));
    float hi = smoothstep(140.0, 330.0, wp.y);
    float face = smoothstep(-0.15, 0.55, dot(normalize(vN), normalize(vec3(uSunW.x, 0.25, uSunW.z))));
    float k = clamp(uAlp.x * snowM * hi * (0.25 + 0.75*face), 0.0, 1.0);
    c = mix(c, uAlpCol * (0.80 + 0.35*face), k * 0.72);
  }
  o = vec4(c, 1.0);
}
)GLSL";

static const char* TER_FS_SAFE = R"GLSL(#version 300 es
precision highp float;
in vec3 vC; in vec3 vN; in vec3 wp; uniform vec3 uCam; uniform sampler2D uGrass; out vec4 o;
void main(){
  float dist = length(uCam - wp);
  vec3 N = normalize(vN); vec3 L = SUNL;
  vec3 gt = texture(uGrass, wp.xz * 0.25).rgb * (0.72 + 0.56 * texture(uGrass, wp.xz * 0.0137 + 0.37).g);
  float slope = 1.0 - clamp(vN.y, 0.0, 1.0);
  vec3 col = vC * mix(vec3(1.0), gt * 1.08, 1.0 - smoothstep(0.25, 0.6, slope));
  float d = max(dot(N, L), 0.0);
  vec3 c = col * (mix(vec3(0.30, 0.27, 0.20), vec3(0.55, 0.68, 0.90), N.y * 0.5 + 0.5) * 0.55 + vec3(1.0, 0.94, 0.82) * (0.55 * d + 0.2 * (d * 0.5 + 0.5)));
  float fog = 1.0 - exp(-pow(dist / 2850.0, 1.35));
  c = mix(c, vec3(0.70, 0.88, 0.97), clamp(fog, 0.0, 1.0));
  o = vec4(c, 1.0);
}
)GLSL";

static const char* WAT_VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in float dep;
uniform mat4 uVP; out float vD; out vec3 wp;
void main(){ vD = dep; wp = p; gl_Position = uVP * vec4(p, 1.0); }
)GLSL";
static const char* WAT_FS = R"GLSL(#version 300 es
precision highp float;
in float vD; in vec3 wp; uniform vec3 uCam; uniform float uT; out vec4 o;
// layered travelling waves: 4 directions / scales (the fine ones fade out with distance so the far water stays calm and does not shimmer)
vec2 waveN(vec2 p, float t, float dist){
  float fine = 1.0 - smoothstep(25.0, 140.0, dist);
  vec2 n = vec2(0.80, 0.60) * cos(dot(p, vec2(0.80, 0.60))*1.9 - t*1.6) * 0.50;
  n += vec2(-0.55, 0.84) * cos(dot(p, vec2(-0.55, 0.84))*3.1 - t*2.1 + 1.3) * 0.32;
  n += vec2(0.30, -0.95) * cos(dot(p, vec2(0.30, -0.95))*5.7 - t*2.9 + 2.1) * 0.18 * (0.35 + 0.65*fine);
  n += vec2(-0.95, -0.30) * cos(dot(p, vec2(-0.95, -0.30))*9.3 - t*3.6 + 0.4) * 0.10 * fine;
  return n;
}
void main(){
  float dist = length(uCam - wp);
  vec2 wv = waveN(wp.xz, uT, dist);
  vec3 N = normalize(vec3(wv.x*0.060, 1.0, wv.y*0.060));
  vec3 V = (uCam - wp)/dist, L = SUNL, H = normalize(L + V);
  float ndv = clamp(dot(N, V), 0.0, 1.0), fr = 0.02 + 0.98*pow(1.0 - ndv, 5.0);        // Schlick fresnel of water
  float dw = vD + 0.07 * sin(uT * 0.9 + wp.x * 0.05 + wp.z * 0.04);
  float rvD = smoothstep(0.0, 1.9, dw);
  // body colour: sandy-green shallows -> dark teal deep water, lit by sun + sky
  vec3 body = mix(vec3(0.30, 0.46, 0.38), vec3(0.06, 0.22, 0.25), rvD) * (0.55 + 0.55*max(dot(N, L), 0.0));
  // reflected sky (gradient) and sun glitter on the ripples
  vec3 R = reflect(-V, N); R.y = abs(R.y);
  vec3 sky = mix(vec3(0.72, 0.87, 0.98), vec3(0.28, 0.54, 0.92), pow(clamp(R.y, 0.0, 1.0), 0.55));
  float sunS = pow(max(dot(N, H), 0.0), 260.0)*1.1 + pow(max(dot(N, H), 0.0), 40.0)*0.10;
  vec3 c = body*(1.0 - fr*0.85) + sky*fr*0.95 + vec3(1.0, 0.96, 0.85)*sunS;
  // foam: lapping lines and a ragged shore rim
  float lap = smoothstep(0.35, 0.95, sin(dw * 11.0 - uT * 1.7 + wv.x*1.5)) * (1.0 - smoothstep(0.05, 1.3, dw));
  float rim = (1.0 - smoothstep(0.0, 0.22, dw)) * (0.70 + 0.30*sin(wp.x*3.1 + wp.z*2.7 + uT*0.8 + wv.y*2.0));
  float edge = smoothstep(0.0, 0.07, dw);
  float foam = clamp(lap * 0.50 + rim * 0.9, 0.0, 1.0) * step(0.0, dw);
  c = mix(c, vec3(0.94, 0.98, 1.0), foam * 0.80);
  float a = (0.32 + 0.30 * rvD + 0.34 * fr) * smoothstep(0.0, 0.75, dw);              // see-through: the bed shows, more near the banks
  a = clamp(max(a, foam * 0.8 * edge), 0.0, 1.0);
  c = mix(c, vec3(0.62, 0.80, 0.95), clamp(dist / 3750.0, 0.0, 1.0));
  o = vec4(c, a);
}
)GLSL";

static const char* BR_VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in vec2 uv; layout(location=2) in vec3 n; layout(location=3) in float al;
uniform mat4 uVP; out vec2 vUv; out vec3 vN; out vec3 wp; out float vA;
void main(){ vUv = uv; vN = n; vA = al; wp = p; gl_Position = uVP * vec4(p, 1.0); }
)GLSL";
// uMode 0 = opaque, 1 = texture alpha * vertex alpha (dirt), 2 = vertex alpha only (road blend patch; its texture alpha is roughness)
static const char* BR_FS = R"GLSL(#version 300 es
precision highp float;
in vec2 vUv; in vec3 vN; in vec3 wp; in float vA;
uniform sampler2D uTex; uniform vec3 uCam; uniform vec3 uTint; uniform int uMode; out vec4 o;
void main(){
  vec4 tx = texture(uTex, vUv);
  vec3 alb = pow(tx.rgb, vec3(2.2)) * pow(uTint, vec3(2.2));
  vec3 N = normalize(vN); if (!gl_FrontFacing) N = -N;                                  // double sided, like three.js
  float d = max(dot(N, SUNL), 0.0);
  vec3 c = pow(alb * (0.35 + 0.75 * d), vec3(1.0 / 2.2));
  c = mix(c, vec3(0.62, 0.80, 0.95), clamp(length(uCam - wp) / 3750.0, 0.0, 1.0));
  float a = uMode == 0 ? 1.0 : (uMode == 1 ? tx.a * vA : vA);
  o = vec4(c, a);
}
)GLSL";

struct Gpu { GLuint vao = 0, vbo = 0, ibo = 0; GLsizei count = 0; std::vector<RoadCull::Chunk> chunks; };
static Gpu gTer, gWat, gPart[Bridge::M_COUNT];
static GLuint gGrass = 0, gProgT = 0, gProgW = 0, gProgB = 0, gConcrete = 0, gSteel = 0;
static float gWindT = 0;     // seconds, drives the wind in the ground shader
static GLint uT_Alp = -1, uT_AlpCol = -1, uT_SunW = -1, uT_MQ = -1;
static GLint uT_Time, uT_VP, uT_Cam, uT_Grass, uW_VP, uW_Cam, uW_T, uB_VP, uB_Cam, uB_Tex, uB_Tint, uB_Mode;

static Gpu upload(const void* v, size_t vbytes, const std::vector<uint32_t>& idx, int stride, const int* attrN, const int* attrOff, int nAttr){
    Gpu g; g.count = (GLsizei)idx.size(); if (!g.count) return g;
    glGenVertexArrays(1, &g.vao); glBindVertexArray(g.vao);
    glGenBuffers(1, &g.vbo); glBindBuffer(GL_ARRAY_BUFFER, g.vbo); glBufferData(GL_ARRAY_BUFFER, vbytes, v, GL_STATIC_DRAW);
    for (int i = 0; i < nAttr; i++){ glEnableVertexAttribArray(i); glVertexAttribPointer(i, attrN[i], GL_FLOAT, GL_FALSE, stride, (void*)(intptr_t)attrOff[i]); }
    glGenBuffers(1, &g.ibo); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, g.ibo); glBufferData(GL_ELEMENT_ARRAY_BUFFER, idx.size() * 4, idx.data(), GL_STATIC_DRAW);
    glBindVertexArray(0);
    g.chunks = RoadCull::build((const float*)v, idx, (size_t)stride / 4, 3000);        // bounding boxes of index runs, for frustum culling (drawGpuCulled)
    return g;
}
// per-frame alpine look for the terrain shader (alpenglow strength, snow-patch / glacier amount, colour, sun); stays set on the program
static void setAlpine(float glow, float snow, const float* col, const float* sun){
    if (!gProgT) return; glUseProgram(gProgT);
    if (uT_Alp >= 0) glUniform4f(uT_Alp, glow, snow, 0.f, 0.f);
    if (uT_AlpCol >= 0) glUniform3fv(uT_AlpCol, 1, col);
    if (uT_SunW >= 0) glUniform3fv(uT_SunW, 1, sun);
}
static void drawGpu(const Gpu& g){ if (!g.count) return; glBindVertexArray(g.vao); glDrawElements(GL_TRIANGLES, g.count, GL_UNSIGNED_INT, (void*)0); glBindVertexArray(0); }
// same picture, but index runs that lie completely outside the camera frustum are skipped (they could not be seen anyway)
static float gCullPl[6][4]; static std::vector<std::pair<uint32_t,uint32_t>> gCullRanges;
static void setCullVP(const float* VP){ RoadCull::planes(VP, gCullPl); }
static void drawGpuCulled(const Gpu& g){
    if (!g.count) return;
    RoadCull::ranges(g.chunks, gCullPl, gCullRanges); if (gCullRanges.empty()) return;
    glBindVertexArray(g.vao);
    for (const auto& r : gCullRanges) glDrawElements(GL_TRIANGLES, (GLsizei)r.second, GL_UNSIGNED_INT, (void*)((size_t)r.first * 4));
    glBindVertexArray(0);
}

static GLuint texFromImg(const Bridge::Img& im){
    GLuint t; glGenTextures(1, &t); glBindTexture(GL_TEXTURE_2D, t); glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, im.w, im.h, 0, GL_RGBA, GL_UNSIGNED_BYTE, im.px.data()); glGenerateMipmap(GL_TEXTURE_2D);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    const char* ext = (const char*)glGetString(GL_EXTENSIONS);
    if (ext && strstr(ext, "GL_EXT_texture_filter_anisotropic")){ GLfloat mx = 1; glGetFloatv(0x84FF, &mx); glTexParameterf(GL_TEXTURE_2D, 0x84FE, mx < 4.f ? mx : 4.f); }
    return t;
}

// Call once with a current GL context, after Road::init() and RoadGL::init().
static void init(){
    Bridge::init();
    gProgT = RoadGL::makeProg(TER_VS, TER_FS); if (!RoadGL::gLastOk) gProgT = RoadGL::makeProg(TER_VS, TER_FS_SAFE); gProgW = RoadGL::makeProg(WAT_VS, WAT_FS); gProgB = RoadGL::makeProg(BR_VS, BR_FS);
    uT_VP = glGetUniformLocation(gProgT, "uVP"); uT_Cam = glGetUniformLocation(gProgT, "uCam"); uT_Grass = glGetUniformLocation(gProgT, "uGrass"); uT_Time = glGetUniformLocation(gProgT, "uTime");
    uT_Alp = glGetUniformLocation(gProgT, "uAlp"); uT_AlpCol = glGetUniformLocation(gProgT, "uAlpCol"); uT_SunW = glGetUniformLocation(gProgT, "uSunW"); uT_MQ = glGetUniformLocation(gProgT, "uMQ");
    uW_VP = glGetUniformLocation(gProgW, "uVP"); uW_Cam = glGetUniformLocation(gProgW, "uCam"); uW_T = glGetUniformLocation(gProgW, "uT");
    uB_VP = glGetUniformLocation(gProgB, "uVP"); uB_Cam = glGetUniformLocation(gProgB, "uCam"); uB_Tex = glGetUniformLocation(gProgB, "uTex");
    uB_Tint = glGetUniformLocation(gProgB, "uTint"); uB_Mode = glGetUniformLocation(gProgB, "uMode");
    River::TerrainMesh tm; River::WaterMesh wm; River::buildTerrain(tm, wm, &River::gHooks);                      // river bed + hills (Terrain hooks) on the 4 m patch
    { const int n[3] = {3, 3, 3}, o[3] = {0, 12, 24}; gTer = upload(tm.v.data(), tm.v.size() * 4, tm.idx, 36, n, o, 3); }
    { const int n[2] = {3, 1}, o[2] = {0, 12}; gWat = upload(wm.v.data(), wm.v.size() * 4, wm.idx, 16, n, o, 2); }
    for (int m = 0; m < Bridge::M_COUNT; m++){ const int n[4] = {3, 2, 3, 1}, o[4] = {0, 12, 20, 32}; gPart[m] = upload(Bridge::gMesh[m].v.data(), Bridge::gMesh[m].v.size() * 4, Bridge::gMesh[m].idx, 36, n, o, 4); }
    gGrass = texFromImg(Bridge::makeGrassTex());
    gConcrete = texFromImg(Bridge::makeConcreteTex()); gSteel = texFromImg(Bridge::makeSteelTex());
}

// carved river bed (replaces the flat ground inside the river patch)
static void drawTerrain(const float* VP, const float* eye){
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE);
    glUseProgram(gProgT); glUniformMatrix4fv(uT_VP, 1, GL_FALSE, VP); glUniform3fv(uT_Cam, 1, eye); glUniform1f(uT_Time, gWindT); if (uT_MQ >= 0) glUniform1f(uT_MQ, Quality::flat ? 0.f : (float)Quality::level);
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, gGrass); glUniform1i(uT_Grass, 0); setCullVP(VP); drawGpuCulled(gTer);
}

static void bridgePart(int mesh, GLuint tex, float r, float g, float b, int mode, float off){
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, tex); glUniform1i(uB_Tex, 0);
    glUniform3f(uB_Tint, r, g, b); glUniform1i(uB_Mode, mode);
    if (off != 0.f){ glEnable(GL_POLYGON_OFFSET_FILL); glPolygonOffset(off, off); } else glDisable(GL_POLYGON_OFFSET_FILL);
    drawGpu(gPart[mesh]);
}
static inline float hx(int v){ return v / 255.f; }

// bridges + water; call after RoadGL::draw
static void draw(const float* VP, const float* eye, float timeSec){
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE);
    // opaque concrete + steel (the asphalt roadway on top is part of the road mesh, drawn by RoadGL)
    glUseProgram(gProgB); glUniformMatrix4fv(uB_VP, 1, GL_FALSE, VP); glUniform3fv(uB_Cam, 1, eye);
    bridgePart(Bridge::M_DECK, gConcrete, 0.97f, 0.96f, 0.94f, 0, 0.f);
    bridgePart(Bridge::M_BEAM, gConcrete, 0.80f, 0.79f, 0.77f, 0, 0.f);
    bridgePart(Bridge::M_POST, gSteel,    0.92f, 0.96f, 1.00f, 0, 0.f);
    glDisable(GL_POLYGON_OFFSET_FILL);
    // water
    glUseProgram(gProgW); glUniformMatrix4fv(uW_VP, 1, GL_FALSE, VP); glUniform3fv(uW_Cam, 1, eye); glUniform1f(uW_T, timeSec);
    glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); glDepthMask(GL_FALSE);
    setCullVP(VP); drawGpuCulled(gWat);
    glDepthMask(GL_TRUE); glDisable(GL_BLEND); glDisable(GL_POLYGON_OFFSET_FILL);
}

} // namespace BridgeGL
