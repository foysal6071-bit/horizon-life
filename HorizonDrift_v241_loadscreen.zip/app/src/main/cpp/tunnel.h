// Sunny Drift - tunnel portals at the two dead ends of the dirt track (pure C++, no OpenGL).
//  * a concrete arch + an earth mound with a dark tunnel mouth, so the track seems to disappear underground
//  * an invisible wall (oriented box in front of the arch and around the mound): the car cannot get in
//  * blocked() keeps the pine forest from growing through the mound
#pragma once
#include <algorithm>
#include <cmath>
#include <vector>
#include "terrain.h"
#include "village.h"
#include "fence.h"          // bounceOff
#include "pond.h"           // ponds: floating petals

namespace Tunnel {

struct Portal { double x, z, bx, bz, y0; };         // (x, z) = centre of the arch front; (bx, bz) = unit vector pointing INTO the tunnel; y0 = ground height there
static std::vector<Portal> gP;

static const double ARCH_R = 4.2, SIDE_H = 2.6, WALL_T = 3.0, DEPTH = 16.0, MOUND_L = 26.0, MOUND_SPREAD = 1.7;
static const double HALF_U = 13.0, W_FRONT = -1.0, W_BACK = 27.0;      // the invisible wall: lateral half width, in front of the arch, behind the mound

static void toLocal(const Portal& P, double x, double z, double& u, double& w){
    const double dx = x - P.x, dz = z - P.z; u = dx * (-P.bz) + dz * P.bx; w = dx * P.bx + dz * P.bz;
}

// call after Terrain::init(): one portal at each end of the dirt track
static void plan(){
    gP.clear(); if (!Terrain::TRK.on || Terrain::TRK.n < 6 || Terrain::PEAK.on) return;   // no tunnel mouths on the hill road
    const std::vector<float>& p = Terrain::TRK.pts; const int n = Terrain::TRK.n;
    auto add = [&](int e, int nb){
        double x = p[e*2], z = p[e*2+1], dx = x - p[nb*2], dz = z - p[nb*2+1]; const double l = std::hypot(dx, dz); if (l < 1e-6) return;
        Portal P; P.x = x; P.z = z; P.bx = dx / l; P.bz = dz / l; P.y0 = Terrain::meshH(x, z); gP.push_back(P);     // away from the track = into the tunnel
    };
    add(0, 3); add(n - 1, n - 4);
}

static bool blocked(double x, double z, double margin){
    for (const Portal& P : gP){ double u, w; toLocal(P, x, z, u, w); if (std::fabs(u) < HALF_U + margin && w > W_FRONT - margin && w < W_BACK + margin) return true; }
    return false;
}

// the invisible wall: three circles along the car, each pushed out of the box (same scheme as the houses)
static void collide(CarState& S){
    if (gP.empty()) return;
    const double sH = std::sin(S.heading), cH = std::cos(S.heading), R = 1.05; static const double OFS[3] = {-1.5, 0.0, 1.5};
    for (const Portal& P : gP){
        const double dx = P.x - S.x, dz = P.z - S.z; if (dx*dx + dz*dz > 70.0 * 70.0) continue;
        for (double o : OFS){
            double u, w; toLocal(P, S.x + sH * o, S.z + cH * o, u, w);
            const double cu = std::max(-HALF_U, std::min(HALF_U, u)), cw = std::max(W_FRONT, std::min(W_BACK, w)), vu = u - cu, vw = w - cw, d = std::sqrt(vu*vu + vw*vw);
            double nu, nw, pen;
            if (d > 1e-6){ if (d >= R) continue; nu = vu / d; nw = vw / d; pen = R - d; }
            else {                                                                                  // centre inside the box: leave through the nearest side
                const double e[4] = {HALF_U - u, u + HALF_U, W_BACK - w, w - W_FRONT}; int k = 0; for (int j = 1; j < 4; j++) if (e[j] < e[k]) k = j;
                nu = (k == 0) ? 1.0 : (k == 1 ? -1.0 : 0.0); nw = (k == 2) ? 1.0 : (k == 3 ? -1.0 : 0.0); pen = e[k] + R;
            }
            const double wx = -P.bz * nu + P.bx * nw, wz = P.bx * nu + P.bz * nw;                   // local -> world direction
            S.x += wx * pen; S.z += wz * pen;
            Fence::bounceOff(S, wx, wz, 0.22, 0.30);
        }
    }
}


// ---------- ROAD TUNNELS (v207): where the player's new road (Road::NEW_EDGE) runs into the mountains, the ground above it is a mountain, so the road becomes a tunnel through it ----------
//  planRoad() finds the buried stretches; the car drives on the road level inside them (groundOverride), the tube (lining + portal rings) is built by build().
struct RSeg { std::vector<float> p; };            // x, z, tx, tz every 2 m
static std::vector<RSeg> gSeg;
static const double TUN_R = 5.4, TUN_SIDE = 3.2, TUN_EXT = 14.0;
static void planRoad(){
    gSeg.clear(); return;   // the ginkgo road no longer goes into the mountain: no tunnel
    const Road::Curve& cv = Road::gNet.roads[Road::NEW_EDGE]; const double len = cv.length(); const int N = (int)(len / 2.0);
    std::vector<char> bur(N + 1, 0);
    for (int i = 0; i <= N; i++){ const Road::V3 q = cv.getPointAt(std::min((double)i / N, 0.99999)); bur[i] = (!Terrain::inLattice(q.x, q.z) && Terrain::meshH(q.x, q.z) > 2.0) ? 1 : 0; }
    const int ext = (int)(TUN_EXT / 2.0); std::vector<char> m(N + 1, 0);
    for (int i = 0; i <= N; i++) if (bur[i]) for (int j = std::max(0, i - ext); j <= std::min(N, i + ext); j++) m[j] = 1;
    for (int i = 0; i <= N; ){ if (!m[i]){ i++; continue; } int j = i; while (j <= N && m[j]) j++;
        if (j - i > 8){ RSeg s; for (int k = i; k < j; k++){ const double u = std::min((double)k / N, 0.99999); const Road::V3 q = cv.getPointAt(u), tg = cv.getTangentAt(u); double l = std::hypot(tg.x, tg.z); if (l == 0) l = 1;
                s.p.push_back((float)q.x); s.p.push_back((float)q.z); s.p.push_back((float)(tg.x / l)); s.p.push_back((float)(tg.z / l)); } gSeg.push_back(s); }
        i = j; }
}
// true (and y = road level) when (x, z) is inside a tunnel: the car must not climb the mountain above it
static bool inRoadTunnel(double x, double z){
    for (const RSeg& s : gSeg){ if (s.p.size() < 8) continue;
        const double dx0 = x - s.p[0], dz0 = z - s.p[1]; if (dx0*dx0 + dz0*dz0 > 1.0e8 && false) continue;
        for (size_t k = 0; k + 3 < s.p.size(); k += 4){ const double dx = x - s.p[k], dz = z - s.p[k+1]; if (dx*dx + dz*dz < TUN_R * TUN_R) return true; } }
    return false;
}

// ---------- geometry (world space; vertex = pos(3) + normal(3)) ----------
enum { PART_FRAME = 0, PART_MOUND = 1, PART_DARK = 2, PART_FLOOR = 3, PART_LINING = 4, PART_LIGHT = 5, PART_LEAF0 = 6, PART_LEAF1 = 7, PART_LEAF2 = 8,
       PART_MUD = 9, PART_MUD2 = 10, PART_PUDDLE = 11, PART_FRUIT = 12, PART_FRUIT2 = 13, PART_STONE = 14, PART_TWIG = 15, PART_POST = 16, PART_POSTB = 17, PART_REFL = 18, PARTS = 19 };
static const float PART_COL[PARTS][3] = {{0.55f, 0.54f, 0.51f}, {0.28f, 0.40f, 0.22f}, {0.045f, 0.045f, 0.05f}, {0.34f, 0.33f, 0.31f}, {0.36f, 0.36f, 0.37f}, {1.0f, 0.93f, 0.62f}, {0.98f, 0.70f, 0.80f}, {0.95f, 0.55f, 0.70f}, {1.0f, 0.86f, 0.91f},
    {0.20f, 0.14f, 0.09f}, {0.38f, 0.29f, 0.19f}, {0.30f, 0.31f, 0.30f}, {0.88f, 0.68f, 0.22f}, {0.46f, 0.31f, 0.13f}, {0.46f, 0.44f, 0.40f}, {0.27f, 0.19f, 0.12f}, {0.88f, 0.88f, 0.84f}, {0.05f, 0.05f, 0.05f}, {0.95f, 0.45f, 0.05f}};

static void build(std::vector<float> out[PARTS]){
    for (int i = 0; i < PARTS; i++) out[i].clear();
    typedef std::pair<double, double> UV;
    for (const Portal& P : gP){
        auto W = [&](double u, double v, double w, double* o){ o[0] = P.x - P.bz * u + P.bx * w; o[1] = P.y0 + v; o[2] = P.z + P.bx * u + P.bz * w; };
        auto groundV = [&](double u, double w){ double q[3]; W(u, 0, w, q); return Terrain::meshH(q[0], q[2]) - P.y0; };
        // triangle with a flat normal turned away from (away = true) or towards (false) the reference point (ru, rv, rw)
        auto tri = [&](int part, const double* a, const double* b, const double* c, const double* ref, bool away){
            double e1[3] = {b[0]-a[0], b[1]-a[1], b[2]-a[2]}, e2[3] = {c[0]-a[0], c[1]-a[1], c[2]-a[2]};
            double nx = e1[1]*e2[2] - e1[2]*e2[1], ny = e1[2]*e2[0] - e1[0]*e2[2], nz = e1[0]*e2[1] - e1[1]*e2[0];
            const double l = std::sqrt(nx*nx + ny*ny + nz*nz); if (l < 1e-9) return; nx /= l; ny /= l; nz /= l;
            const double d = nx*(a[0]-ref[0]) + ny*(a[1]-ref[1]) + nz*(a[2]-ref[2]); if ((d < 0) == away){ nx = -nx; ny = -ny; nz = -nz; }
            for (const double* q : {a, b, c}){ out[part].push_back((float)q[0]); out[part].push_back((float)q[1]); out[part].push_back((float)q[2]); out[part].push_back((float)nx); out[part].push_back((float)ny); out[part].push_back((float)nz); }
        };
        auto quad = [&](int part, const double* a, const double* b, const double* c, const double* d, const double* ref, bool away){ tri(part, a, b, c, ref, away); tri(part, a, c, d, ref, away); };
        // arch outline: left wall up, half circle over the top, right wall down (same point count for every radius -> matching rings)
        auto outline = [&](double r, double vbL, double vbR){
            std::vector<UV> o; const int ns = 3, na = 14;
            for (int i = 0; i < ns; i++) o.push_back({-r, vbL + (SIDE_H - vbL) * i / ns});
            for (int k = 0; k <= na; k++){ const double th = M_PI * (1.0 - (double)k / na); o.push_back({r * std::cos(th), SIDE_H + r * std::sin(th)}); }
            for (int i = 1; i <= ns; i++) o.push_back({r, SIDE_H + (vbR - SIDE_H) * i / ns});
            return o;
        };
        const double RO = ARCH_R + WALL_T, FLOOR = 0.14;
        const std::vector<UV> in = outline(ARCH_R, FLOOR - 0.02, FLOOR - 0.02);
        const std::vector<UV> outr = outline(RO, groundV(-RO, 0) - 0.4, groundV(RO, 0) - 0.4);
        const size_t N = in.size();
        const double inside[3] = {0, 3, 14}, axisFront[3] = {0, SIDE_H, 0}, axisTube[3] = {0, SIDE_H, DEPTH * 0.5};
        double a[3], b[3], c[3], d[3];
        // 1) concrete frame: front ring (0.5 m proud of the mound), rim between ring and mound, reveal inside the opening
        for (size_t i = 0; i + 1 < N; i++){
            W(in[i].first, in[i].second, -0.5, a);   W(in[i+1].first, in[i+1].second, -0.5, b);
            W(outr[i+1].first, outr[i+1].second, -0.5, c); W(outr[i].first, outr[i].second, -0.5, d);
            quad(PART_FRAME, a, b, c, d, inside, true);
            W(outr[i].first, outr[i].second, 0, a); W(outr[i+1].first, outr[i+1].second, 0, b);
            quad(PART_FRAME, d, c, b, a, inside, true);
            double e[3], f[3]; W(in[i].first, in[i].second, 0, e); W(in[i+1].first, in[i+1].second, 0, f);
            double g[3], h[3]; W(in[i].first, in[i].second, -0.5, g); W(in[i+1].first, in[i+1].second, -0.5, h);
            quad(PART_FRAME, g, h, f, e, axisFront, false);
        }
        // 2) earth mound: from the outer ring back to the ground, spreading sideways like a hillside
        std::vector<std::vector<double>> back(N, std::vector<double>(3));
        for (size_t i = 0; i < N; i++){ const double ub = outr[i].first * MOUND_SPREAD; double q[3]; W(ub, groundV(ub, MOUND_L) - 0.5, MOUND_L, q); back[i] = {q[0], q[1], q[2]}; }
        for (size_t i = 0; i + 1 < N; i++){
            W(outr[i].first, outr[i].second, 0, a); W(outr[i+1].first, outr[i+1].second, 0, b);
            quad(PART_MOUND, a, b, back[i+1].data(), back[i].data(), inside, true);
        }
        // 3) dark tunnel: inner walls + black back wall
        for (size_t i = 0; i + 1 < N; i++){
            W(in[i].first, in[i].second, 0, a); W(in[i+1].first, in[i+1].second, 0, b); W(in[i+1].first, in[i+1].second, DEPTH, c); W(in[i].first, in[i].second, DEPTH, d);
            quad(PART_DARK, a, b, c, d, axisTube, false);
            double ctr[3]; W(0, SIDE_H, DEPTH, ctr); tri(PART_DARK, ctr, c, d, axisFront, false);
        }
        { double ctr[3], l0[3], l1[3]; W(0, SIDE_H, DEPTH, ctr); W(in[N-1].first, in[N-1].second, DEPTH, l0); W(in[0].first, in[0].second, DEPTH, l1); tri(PART_DARK, ctr, l0, l1, axisFront, false); }
        // 4) the track carries on into the tunnel: dirt floor
        W(-ARCH_R, FLOOR + 0.01, -3.0, a); W(ARCH_R, FLOOR + 0.01, -3.0, b); W(ARCH_R, FLOOR + 0.01, DEPTH, c); W(-ARCH_R, FLOOR + 0.01, DEPTH, d);
        { const double up[3] = {0, 50, 0}; quad(PART_FLOOR, a, b, c, d, up, false); }
    }

    // ROAD TUNNEL tubes: lining + a concrete ring at both portals
    for (const RSeg& s : gSeg){
        const int n = (int)(s.p.size() / 4); if (n < 2) continue; const int na = 12;
        std::vector<std::pair<double,double>> prof;                     // (lateral, height): left wall, half circle roof, right wall
        prof.push_back({-TUN_R, 0.0}); prof.push_back({-TUN_R, TUN_SIDE * 0.5});
        for (int k = 0; k <= na; k++){ const double th = M_PI * (1.0 - (double)k / na); prof.push_back({TUN_R * std::cos(th), TUN_SIDE + TUN_R * std::sin(th)}); }
        prof.push_back({TUN_R, TUN_SIDE * 0.5}); prof.push_back({TUN_R, 0.0});
        auto P3 = [&](int i, double lat, double h, double* o, double grow){ const float x = s.p[i*4], z = s.p[i*4+1], tx = s.p[i*4+2], tz = s.p[i*4+3]; o[0] = x - tz * lat; o[1] = 0.06 + h; o[2] = z + tx * lat; (void)grow; };
        auto push = [&](int part, const double* a, const double* b, const double* c, double nx, double ny, double nz){ for (const double* q : {a, b, c}){ out[part].push_back((float)q[0]); out[part].push_back((float)q[1]); out[part].push_back((float)q[2]); out[part].push_back((float)nx); out[part].push_back((float)ny); out[part].push_back((float)nz); } };
        for (int i = 0; i + 1 < n; i++) for (size_t j = 0; j + 1 < prof.size(); j++){
            double a[3], b[3], c[3], d[3]; P3(i, prof[j].first, prof[j].second, a, 0); P3(i, prof[j+1].first, prof[j+1].second, b, 0); P3(i+1, prof[j+1].first, prof[j+1].second, c, 0); P3(i+1, prof[j].first, prof[j].second, d, 0);
            const double mx = (prof[j].first + prof[j+1].first) * 0.5, my = (prof[j].second + prof[j+1].second) * 0.5 - TUN_SIDE; double nl = std::hypot(mx, my); if (nl < 1e-6) nl = 1;
            const double lx = -mx / nl, ly = -my / nl; const double tx = s.p[i*4+2], tz = s.p[i*4+3];                 // normal points to the tunnel axis
            const double nx = -tz * lx, nz = tx * lx;
            push(PART_LINING, a, b, c, nx, ly, nz); push(PART_LINING, a, c, d, nx, ly, nz);
        }

        // lamps: a ceiling light every 10 m + a continuous warm light strip along both walls
        for (int i = 0; i + 1 < n; i++){
            const bool lamp = (i % 5) < 2;
            auto quadL = [&](double l0, double h0, double l1, double h1, int i0, int i1){ double a[3], b[3], c[3], d[3]; P3(i0, l0, h0, a, 0); P3(i0, l1, h1, b, 0); P3(i1, l1, h1, c, 0); P3(i1, l0, h0, d, 0);
                push(PART_LIGHT, a, b, c, 0, -1, 0); push(PART_LIGHT, a, c, d, 0, -1, 0); };
            if (lamp) quadL(-0.9, TUN_SIDE + TUN_R - 0.12, 0.9, TUN_SIDE + TUN_R - 0.12, i, i + 1);
            for (int sd = -1; sd <= 1; sd += 2) quadL(sd * (TUN_R - 0.06), 2.0, sd * (TUN_R - 0.06), 2.3, i, i + 1);
        }
        for (int e = 0; e < 2; e++){                                       // portal rings (concrete): a band round the opening, 1.2 m proud
            const int i = e ? n - 1 : 0; const double dirx = (e ? 1 : -1) * s.p[i*4+2], dirz = (e ? 1 : -1) * s.p[i*4+3];
            for (size_t j = 0; j + 1 < prof.size(); j++){
                double a[3], b[3], c[3], d[3]; P3(i, prof[j].first, prof[j].second, a, 0); P3(i, prof[j+1].first, prof[j+1].second, b, 0);
                const double k1 = 1.9; const double r0 = std::hypot(prof[j].first, prof[j].second - TUN_SIDE), r1 = std::hypot(prof[j+1].first, prof[j+1].second - TUN_SIDE);
                P3(i, prof[j+1].first * (1 + k1 / std::max(r1, 1.0)), TUN_SIDE + (prof[j+1].second - TUN_SIDE) * (1 + k1 / std::max(r1, 1.0)), c, 0); P3(i, prof[j].first * (1 + k1 / std::max(r0, 1.0)), TUN_SIDE + (prof[j].second - TUN_SIDE) * (1 + k1 / std::max(r0, 1.0)), d, 0);
                for (double* q : {a, b, c, d}){ q[0] += dirx * 0.6; q[2] += dirz * 0.6; }
                push(PART_FRAME, a, b, c, dirx, 0, dirz); push(PART_FRAME, a, c, d, dirx, 0, dirz);
            }
        }
    }

    // FALLEN CHERRY PETALS along the whole new road (v237+): petals hug the slope of the ground (each corner follows the terrain, edges slightly curled),
    // lie in drifts under the canopy and along the road edge, are blown along the tarmac in the direction of the road, and float on the river / ponds near the avenue.
    {
        const Road::Curve& cv = Road::gNet.roads[Road::NEW_EDGE]; const double len = cv.length(), hw = cv.hw; uint32_t rs = 0x9e3779b9u;
        auto R = [&]{ rs = rs * 1664525u + 1013904223u; return (rs >> 8) / 16777216.0; };
        // one petal: centre (x, z), ground height y0 (< -100 = follow the terrain), size sz, heading ang, colour part, tilt = how much the edges curl up
        auto petal = [&](double x, double z, double y0, double sz, double ang, int part, double curl){
            const double ca = std::cos(ang), sa = std::sin(ang), a0 = sz * 0.55, b0 = sz * 0.32;
            const double lxs[6] = {0.0, 0.0, b0, 0.72 * b0, -0.72 * b0, -b0}, lzs[6] = {0.10 * a0, -0.35 * a0, 0.0, 0.75 * a0, 0.75 * a0, 0.0}, lift[6] = {0.0, 0.004, 0.010 * curl, 0.016 * curl, 0.016 * curl, 0.010 * curl};
            double fx[6], fz[6], fy[6];
            for (int v = 0; v < 6; v++){ fx[v] = x + ca * lzs[v] - sa * lxs[v]; fz[v] = z + sa * lzs[v] + ca * lxs[v]; fy[v] = (y0 < -100.0 ? Terrain::meshH(fx[v], fz[v]) + 0.03 : y0) + lift[v]; }
            static const int PT[5][2] = {{1, 2}, {2, 3}, {3, 4}, {4, 5}, {5, 1}};
            for (int v = 0; v < 5; v++){
                const int idx[3] = {0, PT[v][0], PT[v][1]};
                for (int w = 0; w < 3; w++){ out[part].push_back((float)fx[idx[w]]); out[part].push_back((float)fy[idx[w]]); out[part].push_back((float)fz[idx[w]]); out[part].push_back(0.f); out[part].push_back(1.f); out[part].push_back(0.f); }
            }
        };
        auto blocked = [&](double x, double z){ return std::fabs(River::riverSd(x, z)) < River::RIVER_WALL + 4.0 || Village::blocked(x, z, 1.0); };
        for (double s = 8.0; s < len - 8.0; s += 1.0){
            const Road::V3 p = cv.getPointAt(s / len), tg = cv.getTangentAt(s / len); double nl = std::hypot(tg.x, tg.z); if (nl == 0) continue;
            if (inRoadTunnel(p.x, p.z) || std::fabs(River::riverSd(p.x, p.z)) < River::RIVER_WALL + 8.0) continue;
            const double nx = -tg.z / nl, nz = tg.x / nl, tx = tg.x / nl, tz = tg.z / nl, roadAng = std::atan2(tz, tx);
            // a) loose petals: under the canopy (6-9 m wide band) and thinning out into the meadow, both sides of the road
            for (int k = 0; k < 4; k++){
                const double side = R() < 0.5 ? -1.0 : 1.0, r = R(), u = R() < 0.6 ? hw + 1.0 + 8.0 * r : hw + 0.3 + 14.0 * r * r;
                const double x = p.x + nx * u * side + tx * (R() - 0.5), z = p.z + nz * u * side + tz * (R() - 0.5);
                if (blocked(x, z)) continue;
                petal(x, z, -1000.0, 0.15 + 0.15 * R(), R() * 6.2831853, PART_LEAF0 + (int)(R() * 2.999), 0.5 + R());
            }
            // b) drifts: a small heap of 5-9 overlapping petals, mostly along the road edge where the wind collects them
            if (R() < 0.30){
                const double side = R() < 0.5 ? -1.0 : 1.0, u = hw + 0.15 + 2.5 * R() * R(), cx = p.x + nx * u * side, cz = p.z + nz * u * side;
                if (!blocked(cx, cz)){ const int n = 5 + (int)(R() * 5.0), base = R() < 0.5 ? 0 : 1;
                    for (int k = 0; k < n; k++) petal(cx + (R() - 0.5) * 0.7, cz + (R() - 0.5) * 0.5, -1000.0, 0.14 + 0.12 * R(), R() * 6.2831853, PART_LEAF0 + (base + (int)(R() * 2.0)) % 3, 0.6 + 1.2 * R()); }
            }
            // c) on the tarmac: a few petals blown along the road (they point roughly with the road, a little random), more near the edges
            if (R() < 0.55){
                const double side = R() < 0.5 ? -1.0 : 1.0, r = R(), u = (hw - 0.2) * (0.35 + 0.65 * r), x = p.x + nx * u * side, z = p.z + nz * u * side;
                petal(x, z, 0.115, 0.14 + 0.12 * R(), roadAng + (R() - 0.5) * 1.1 + (R() < 0.5 ? 0.0 : 3.1415927), PART_LEAF0 + (int)(R() * 2.999), 0.4);
            }
        }
        // d) FLOATING petals: rafts of petals drifting on the river and the meadow ponds near the avenue (flat on the water, just above the surface)
        {
            std::vector<std::pair<double, double>> av; for (double s = 8.0; s < len - 8.0; s += 4.0){ const Road::V3 q = cv.getPointAt(s / len); if (!inRoadTunnel(q.x, q.z)) av.push_back({q.x, q.z}); }
            auto avDist = [&](double x, double z){ double d = 1e9; for (const auto& a : av) d = std::min(d, std::hypot(x - a.first, z - a.second)); return d; };
            // ponds
            for (const Pond::P& pd : Pond::gP){
                const double dist = avDist(pd.x, pd.z); if (dist > pd.r * 1.3 + 110.0) continue;
                const double near = 1.0 - std::min(1.0, std::max(0.0, (dist - pd.r) / 110.0));            // closer to the avenue = more petals
                const int rafts = 3 + (int)(pd.r * 0.9 * near);
                for (int q = 0; q < rafts; q++){
                    const double ca = R() * 6.2831853, rr = pd.r * 0.82 * std::sqrt(R()), cx = pd.x + std::cos(ca) * rr, cz = pd.z + std::sin(ca) * rr;
                    if (Pond::waterAt(cx, cz) < 0.9) continue;
                    const int n = 3 + (int)(R() * 6.0);
                    for (int k = 0; k < n; k++){ const double x = cx + (R() - 0.5) * 1.6, z = cz + (R() - 0.5) * 1.6; if (Pond::waterAt(x, z) < 0.85) continue;
                        petal(x, z, (double)pd.y + 0.02, 0.18 + 0.16 * R(), R() * 6.2831853, PART_LEAF0 + (int)(R() * 2.999), 0.0); }
                }
            }
            // river: rafts on the water within ~110 m of the avenue
            for (size_t i = 0; i < av.size(); i++){
                for (int k = 0; k < 14; k++){
                    const double ang = R() * 6.2831853, d = 12.0 + 98.0 * R(), x = av[i].first + std::cos(ang) * d, z = av[i].second + std::sin(ang) * d;
                    if (std::fabs(River::riverSd(x, z)) > River::RIVER_WALL || Terrain::meshH(x, z) > River::WATER_Y - 0.25) continue;
                    const int n = 3 + (int)(R() * 6.0);
                    for (int m = 0; m < n; m++){ const double px = x + (R() - 0.5) * 2.0, pz = z + (R() - 0.5) * 2.0; if (Terrain::meshH(px, pz) > River::WATER_Y - 0.2) continue;
                        petal(px, pz, River::WATER_Y + 0.02, 0.18 + 0.16 * R(), R() * 6.2831853, PART_LEAF0 + (int)(R() * 2.999), 0.0); }
                }
            }
        }
    }
    // ---- ROAD DETAILS (v224): mud in the wheel ruts, mud smeared in from the verges, muddy puddles, ginkgo fruit, stones, twigs + a broken branch now and then, reflector posts ----
    {
        const Road::Curve& cv = Road::gNet.roads[Road::NEW_EDGE]; const double len = cv.length(), hw = cv.hw; uint32_t rs = 0x51ed270bu;
        auto R = [&]{ rs = rs * 1664525u + 1013904223u; return (rs >> 8) / 16777216.0; };
        auto push = [&](int part, const double* a, double nx, double ny, double nz){
            out[part].push_back((float)a[0]); out[part].push_back((float)a[1]); out[part].push_back((float)a[2]); out[part].push_back((float)nx); out[part].push_back((float)ny); out[part].push_back((float)nz); };
        auto triUp = [&](int part, const double* a, const double* b, const double* c){                       // flat triangle, normal turned upwards
            double e1[3] = {b[0]-a[0], b[1]-a[1], b[2]-a[2]}, e2[3] = {c[0]-a[0], c[1]-a[1], c[2]-a[2]};
            double nx = e1[1]*e2[2] - e1[2]*e2[1], ny = e1[2]*e2[0] - e1[0]*e2[2], nz = e1[0]*e2[1] - e1[1]*e2[0];
            const double l = std::sqrt(nx*nx + ny*ny + nz*nz); if (l < 1e-12) return; nx /= l; ny /= l; nz /= l; if (ny < 0){ nx = -nx; ny = -ny; nz = -nz; }
            push(part, a, nx, ny, nz); push(part, b, nx, ny, nz); push(part, c, nx, ny, nz); };
        auto ellipse = [&](int part, double x, double z, double y, double ra, double rb, double ang, double wob){    // irregular flat blob, ra along the road
            const int N = 10; const double ca = std::cos(ang), sa = std::sin(ang); double px[N], pz[N];
            for (int k = 0; k < N; k++){ const double a = k * 6.2831853 / N, r = 1.0 + wob * (R() - 0.5), lx = ra * std::cos(a) * r, lz = rb * std::sin(a) * r; px[k] = x + ca * lx - sa * lz; pz[k] = z + sa * lx + ca * lz; }
            const double c[3] = {x, y, z};
            for (int k = 0; k < N; k++){ const int k2 = (k + 1) % N; const double a[3] = {px[k], y, pz[k]}, b[3] = {px[k2], y, pz[k2]}; triUp(part, c, a, b); } };
        auto dome = [&](int part, double x, double y, double z, double r, double hgt){                             // little lump: fruit, stone
            const int N = 6; double bx[N], bz[N]; const double a0 = R() * 6.2831853;
            for (int k = 0; k < N; k++){ const double a = a0 + k * 6.2831853 / N, rr = r * (0.75 + 0.5 * R()); bx[k] = x + std::cos(a) * rr; bz[k] = z + std::sin(a) * rr; }
            const double ap[3] = {x + (R() - 0.5) * r * 0.4, y + hgt, z + (R() - 0.5) * r * 0.4};
            for (int k = 0; k < N; k++){ const int k2 = (k + 1) % N; const double a[3] = {bx[k], y, bz[k]}, b[3] = {bx[k2], y, bz[k2]}; triUp(part, ap, a, b); } };
        auto strip = [&](int part, double x, double z, double y, double len2, double w, double ang){               // thin flat stick
            const double ca = std::cos(ang), sa = std::sin(ang), hl = len2 * 0.5, hwid = w * 0.5;
            const double a[3] = {x - ca*hl + sa*hwid, y, z - sa*hl - ca*hwid}, b[3] = {x + ca*hl + sa*hwid, y, z + sa*hl - ca*hwid},
                         c[3] = {x + ca*hl - sa*hwid, y, z + sa*hl + ca*hwid}, d[3] = {x - ca*hl - sa*hwid, y, z - sa*hl + ca*hwid};
            triUp(part, a, b, c); triUp(part, a, c, d); };
        auto box = [&](int part, double cx, double y0, double cz, double hx, double h, double hz, double yaw){
            const double ca = std::cos(yaw), sa = std::sin(yaw); double v[8][3];
            for (int i = 0; i < 8; i++){ const double lx = (i & 1) ? hx : -hx, ly = (i & 2) ? h : 0.0, lz = (i & 4) ? hz : -hz; v[i][0] = cx + ca * lx - sa * lz; v[i][1] = y0 + ly; v[i][2] = cz + sa * lx + ca * lz; }
            static const int F[6][4] = {{0,2,6,4}, {1,3,7,5}, {0,1,5,4}, {2,3,7,6}, {0,1,3,2}, {4,5,7,6}};
            const double mc[3] = {cx, y0 + h * 0.5, cz};
            for (int f = 0; f < 6; f++){
                const double* a = v[F[f][0]]; const double* b = v[F[f][1]]; const double* c = v[F[f][2]]; const double* d = v[F[f][3]];
                double e1[3] = {b[0]-a[0], b[1]-a[1], b[2]-a[2]}, e2[3] = {c[0]-a[0], c[1]-a[1], c[2]-a[2]};
                double nx = e1[1]*e2[2] - e1[2]*e2[1], ny = e1[2]*e2[0] - e1[0]*e2[2], nz = e1[0]*e2[1] - e1[1]*e2[0];
                const double l = std::sqrt(nx*nx + ny*ny + nz*nz); if (l < 1e-12) continue; nx /= l; ny /= l; nz /= l;
                if (nx * (a[0] - mc[0]) + ny * (a[1] - mc[1]) + nz * (a[2] - mc[2]) < 0){ nx = -nx; ny = -ny; nz = -nz; }
                push(part, a, nx, ny, nz); push(part, b, nx, ny, nz); push(part, c, nx, ny, nz); push(part, a, nx, ny, nz); push(part, c, nx, ny, nz); push(part, d, nx, ny, nz); } };
        auto stationOk = [&](double x, double z){ return !(inRoadTunnel(x, z) || std::fabs(River::riverSd(x, z)) < River::RIVER_WALL + 8.0); };
        auto gy = [&](double x, double z, bool onRoad){ return onRoad ? 0.115 : Terrain::meshH(x, z) + 0.03; };

        // (a) mud in the wheel ruts: four tracks (two per lane), on and off in stretches of 6-28 m, a little wobble, tapering at both ends
        static const double RUT_U[4] = {-2.55, -0.95, 0.95, 2.55};
        for (int ri = 0; ri < 4; ri++){
            double segLeft = 0, segLen = 1; bool on = false, prevOk = false; const double seed = R() * 100.0; double pLx = 0, pLz = 0, pRx = 0, pRz = 0;
            for (double s = 8.0; s < len - 8.0; s += 1.0){
                if (segLeft <= 0){ on = !on; segLen = segLeft = on ? 6.0 + 22.0 * R() : 8.0 + 40.0 * R(); }
                segLeft -= 1.0;
                if (!on){ prevOk = false; continue; }
                const Road::V3 p = cv.getPointAt(s / len), tg = cv.getTangentAt(s / len); const double nl = std::hypot(tg.x, tg.z); if (nl == 0 || !stationOk(p.x, p.z)){ prevOk = false; continue; }
                const double nx = -tg.z / nl, nz = tg.x / nl, pos = segLen - segLeft, taper = std::min(1.0, std::min(pos, segLeft + 1.0) / 3.0);
                const double uc = RUT_U[ri] + 0.12 * std::sin(s * 0.13 + seed), wr = (0.17 + 0.07 * std::sin(s * 0.31 + seed)) * taper + 0.01;
                const double lx = p.x + nx * (uc - wr), lz = p.z + nz * (uc - wr), rx = p.x + nx * (uc + wr), rz = p.z + nz * (uc + wr);
                if (prevOk){ const double a[3] = {pLx, 0.111, pLz}, b[3] = {pRx, 0.111, pRz}, c[3] = {rx, 0.111, rz}, d[3] = {lx, 0.111, lz}; triUp(PART_MUD, a, b, c); triUp(PART_MUD, a, c, d); }
                pLx = lx; pLz = lz; pRx = rx; pRz = rz; prevOk = true;
            }
        }

        // (b) everything else, station by station along the road
        for (double s = 8.0; s < len - 8.0; s += 1.5){
            const Road::V3 p = cv.getPointAt(s / len), tg = cv.getTangentAt(s / len); const double nl = std::hypot(tg.x, tg.z); if (nl == 0 || !stationOk(p.x, p.z)) continue;
            const double nx = -tg.z / nl, nz = tg.x / nl, tx = tg.x / nl, tz = tg.z / nl, dirA = std::atan2(tz, tx);
            auto at = [&](double u, double along, double& x, double& z){ x = p.x + nx * u + tx * along; z = p.z + nz * u + tz * along; };
            auto sideU = [&](double sd, bool onRoad){ return onRoad ? sd * R() * (hw - 0.3) : sd * (hw + 0.3 + 6.0 * R() * R()); };
            double x, z;
            // dried mud smeared in from the verge along the road edge
            if (R() < 0.22){ const double sd = R() < 0.5 ? -1.0 : 1.0; at(sd * (hw - 0.6 - 0.5 * R()), (R() - 0.5) * 1.4, x, z); ellipse(PART_MUD2, x, z, 0.112, 0.7 + 1.8 * R(), 0.25 + 0.45 * R(), dirA + (R() - 0.5) * 0.4, 0.5); }
            // muddy puddles in the ruts: dark wet rim, brownish water on top
            if (R() < 0.025){ const double u = (R() < 0.5 ? -1.0 : 1.0) * (R() < 0.5 ? 0.95 : 2.55), ra = 1.2 + 3.0 * R(), rb = 0.5 + 0.5 * R(), an = dirA + (R() - 0.5) * 0.2; at(u, 0, x, z);
                ellipse(PART_MUD, x, z, 0.1135, ra * 1.25, rb * 1.3, an, 0.35); ellipse(PART_PUDDLE, x, z, 0.116, ra, rb, an, 0.3); }
            // ginkgo fruit under the trees (yellow, some already brown and squashed)
            if (false){   // no ginkgo fruit under the cherry trees
                const double sd = R() < 0.5 ? -1.0 : 1.0; const bool onRoad = R() < 0.2; const double u = sideU(sd, onRoad); at(u, (R() - 0.5) * 1.5, x, z);
                if (onRoad || (!Village::blocked(x, z, 1.0) && std::fabs(River::riverSd(x, z)) >= River::RIVER_WALL + 4.0)){
                    const int cnt = 2 + (int)(R() * 6.0);
                    for (int k = 0; k < cnt; k++){ const double fx = x + (R() - 0.5) * 0.8, fz = z + (R() - 0.5) * 0.8; dome(R() < 0.7 ? PART_FRUIT : PART_FRUIT2, fx, gy(fx, fz, onRoad), fz, 0.045 + 0.03 * R(), 0.055); }
                }
            }
            // stones
            if (R() < 0.2){
                const double sd = R() < 0.5 ? -1.0 : 1.0; const bool onRoad = R() < 0.2; const double u = onRoad ? sd * (hw - 0.8 * R()) : sideU(sd, false); at(u, (R() - 0.5) * 1.5, x, z);
                if (onRoad || (!Village::blocked(x, z, 1.0) && std::fabs(River::riverSd(x, z)) >= River::RIVER_WALL + 4.0)){
                    const int cnt = 1 + (int)(R() * 3.0);
                    for (int k = 0; k < cnt; k++){ const double sx = x + (R() - 0.5) * 0.7, sz = z + (R() - 0.5) * 0.7, r = 0.05 + 0.14 * R() * R(); dome(PART_STONE, sx, gy(sx, sz, onRoad), sz, r, r * 0.7); }
                }
            }
            // small twigs (a fork now and then) + a big broken branch very rarely
            if (R() < 0.18){
                const double sd = R() < 0.5 ? -1.0 : 1.0; const bool onRoad = R() < 0.45; const double u = onRoad ? sd * (hw - 0.2 - 2.0 * R()) : sideU(sd, false); at(u, 0, x, z);
                if (onRoad || (!Village::blocked(x, z, 1.0) && std::fabs(River::riverSd(x, z)) >= River::RIVER_WALL + 4.0)){
                    const int cnt = 1 + (int)(R() * 3.0);
                    for (int k = 0; k < cnt; k++){ const double tx2 = x + (R() - 0.5) * 0.8, tz2 = z + (R() - 0.5) * 0.8, an = R() * 3.14159, l2 = 0.4 + R() * 1.0, y = gy(tx2, tz2, onRoad) + 0.012;
                        strip(PART_TWIG, tx2, tz2, y, l2, 0.025 + 0.025 * R(), an);
                        if (R() < 0.4) strip(PART_TWIG, tx2 + std::cos(an) * l2 * 0.3 + 0.1, tz2 + std::sin(an) * l2 * 0.3, y, l2 * 0.5, 0.02, an + (R() < 0.5 ? 0.6 : -0.6)); }
                }
            }
            if (R() < 0.008){
                const double sd = R() < 0.5 ? -1.0 : 1.0; at(sd * (hw - 0.5 - 1.2 * R()), 0, x, z); const double an = dirA + (R() - 0.5) * 1.6, l2 = 1.0 + 1.2 * R();
                box(PART_TWIG, x, 0.115, z, l2, 0.09 + 0.04 * R(), 0.05 + 0.04 * R(), an);
                for (int k = 0; k < 3; k++){ const double a2 = an + (R() - 0.5) * 1.4, o = (R() - 0.5) * l2; strip(PART_TWIG, x + std::cos(an) * o, z + std::sin(an) * o, 0.13, 0.5 + 0.6 * R(), 0.03, a2); }
            }
        }

        // (c) white reflector posts every 30 m on both sides: black band + orange reflector facing the road
        for (double s = 15.0; s < len - 15.0; s += 30.0){
            const Road::V3 p = cv.getPointAt(s / len), tg = cv.getTangentAt(s / len); const double nl = std::hypot(tg.x, tg.z); if (nl == 0 || !stationOk(p.x, p.z)) continue;
            const double nx = -tg.z / nl, nz = tg.x / nl, yaw = std::atan2(tg.z, tg.x);
            for (int sd = -1; sd <= 1; sd += 2){
                const double x = p.x + nx * (hw + 0.9) * sd, z = p.z + nz * (hw + 0.9) * sd;
                if (Village::blocked(x, z, 1.0) || std::fabs(River::riverSd(x, z)) < River::RIVER_WALL + 4.0) continue;
                const double y0 = Terrain::meshH(x, z) - 0.02;
                box(PART_POST, x, y0, z, 0.055, 0.90, 0.055, yaw);
                box(PART_POSTB, x, y0 + 0.55, z, 0.058, 0.12, 0.058, yaw);
                box(PART_REFL, x - nx * sd * 0.062, y0 + 0.58, z - nz * sd * 0.062, 0.03, 0.08, 0.006, yaw);
            }
        }
    }
}

} // namespace Tunnel
