// Horizon Drift - ROAD SIGNS & MARKERS (all static, built once into one vertex buffer, drawn per 120 m cell):
//  * kilometre stones   : a small white stone with a red cap and a black number plate, every KM metres beside every road
//  * curve warning signs: red-bordered triangle with a black bent arrow, ~45 m BEFORE every bend (one for each driving direction, on the right-hand side)
//  * chevron boards     : yellow boards with a black double arrow on the OUTER side of the tight bends, every 12 m, pointing the way the road turns
//  * reflector posts    : white posts with a black band + bright reflectors along both edges of every bend (white on the inside, orange on the outside);
//                         the reflectors shine brighter than the rest by day and light up at night (see drawNight)
//  Pure decoration, no collision. Kept clear of rivers, bridges, junctions, houses, lamps, power poles and guardrails.
#pragma once
#include <GLES3/gl3.h>
#include <algorithm>
#include <cmath>
#include <map>
#include <vector>
#include "powerline.h"

namespace RoadSigns {

static const double KM        = 250.0;   // distance between kilometre stones (m)
static const double TURN_WARN = 0.22;     // |turn| (rad, over 24 m of road) from which a bend gets a warning sign + reflector posts
static const double TURN_TIGHT= 0.34;     // ... and from which it also gets chevron boards
static const double CELLW     = 120.0;

struct P3 { double x, y, z; };
static inline P3 sub(P3 a, P3 b){ return {a.x - b.x, a.y - b.y, a.z - b.z}; }
static inline P3 cross(P3 a, P3 b){ return {a.y*b.z - a.z*b.y, a.z*b.x - a.x*b.z, a.x*b.y - a.y*b.x}; }
static inline P3 norm(P3 a){ double l = std::sqrt(a.x*a.x + a.y*a.y + a.z*a.z); if (l < 1e-9) return {0, 1, 0}; return {a.x / l, a.y / l, a.z / l}; }

struct Cell { std::vector<uint32_t> s, g; };                      // s = solid indices, g = reflector (glow) indices
static std::map<long long, Cell> gCells;
static std::vector<float> gV;
static std::vector<uint32_t>* OUT = nullptr;
struct Chunk { uint32_t sFirst = 0, sCount = 0, gFirst = 0, gCount = 0; float cx = 0, cz = 0; };
static std::vector<Chunk> gChunks; static std::vector<uint32_t> gIdx;
static GLuint gProg = 0, gVao = 0, gVbo = 0, gIbo = 0; static GLint uVP = -1, uCam = -1, uMode = -1, uN = -1; static bool gOk = false;

static inline uint32_t vcount(){ return (uint32_t)(gV.size() / 9); }
static void vtx(P3 p, P3 n, float r, float g, float b){
    gV.push_back((float)p.x); gV.push_back((float)p.y); gV.push_back((float)p.z); gV.push_back((float)n.x); gV.push_back((float)n.y); gV.push_back((float)n.z);
    gV.push_back(r); gV.push_back(g); gV.push_back(b);
}
static void useCell(double x, double z, bool glow){
    const long long k = (long long)(std::floor(x / CELLW) + 10000) * 20011LL + (long long)(std::floor(z / CELLW) + 10000);
    Cell& c = gCells[k]; OUT = glow ? &c.g : &c.s;
}
static void tube(P3 a, P3 b, double ra, double rb, int n, float r, float g, float bl, bool caps = true){
    const P3 ax = norm(sub(b, a)); P3 u = std::fabs(ax.y) < 0.95 ? norm(cross(ax, {0, 1, 0})) : P3{1, 0, 0}; const P3 v = norm(cross(ax, u)); const uint32_t base = vcount();
    for (int i = 0; i < n; i++){ const double th = i * 6.283185307 / n, c = std::cos(th), s = std::sin(th); const P3 d = {u.x*c + v.x*s, u.y*c + v.y*s, u.z*c + v.z*s};
        vtx({a.x + d.x*ra, a.y + d.y*ra, a.z + d.z*ra}, d, r, g, bl); vtx({b.x + d.x*rb, b.y + d.y*rb, b.z + d.z*rb}, d, r, g, bl); }
    for (int i = 0; i < n; i++){ const uint32_t a0 = base + i*2, a1 = a0 + 1, b0 = base + ((i + 1) % n) * 2, b1 = b0 + 1; OUT->insert(OUT->end(), {a0, b0, a1, a1, b0, b1}); }
    if (caps) for (int e = 0; e < 2; e++){
        const P3 c0 = e ? b : a, nn = e ? ax : P3{-ax.x, -ax.y, -ax.z}; const double rr = e ? rb : ra; if (rr <= 0) continue;
        const uint32_t ctr = vcount(); vtx(c0, nn, r, g, bl); const uint32_t r0 = vcount();
        for (int i = 0; i < n; i++){ const double th = i * 6.283185307 / n, c = std::cos(th), s = std::sin(th); vtx({c0.x + (u.x*c + v.x*s)*rr, c0.y + (u.y*c + v.y*s)*rr, c0.z + (u.z*c + v.z*s)*rr}, nn, r, g, bl); }
        for (int i = 0; i < n; i++){ const uint32_t p0 = r0 + i, p1 = r0 + (i + 1) % n; OUT->insert(OUT->end(), {p0, p1, ctr}); }
    }
}
// box with centre c, half sizes along ex (hx), up (hy), ez (hz); both windings, so it never disappears
static void obox(P3 c, P3 ex, P3 ez, double hx, double hy, double hz, float r, float g, float b){
    const P3 ey = {0, 1, 0}; static const int S[6][3] = {{1,0,0},{-1,0,0},{0,1,0},{0,-1,0},{0,0,1},{0,0,-1}};
    for (int f = 0; f < 6; f++){
        const P3 n = {ex.x*S[f][0] + ey.x*S[f][1] + ez.x*S[f][2], ex.y*S[f][0] + ey.y*S[f][1] + ez.y*S[f][2], ex.z*S[f][0] + ey.z*S[f][1] + ez.z*S[f][2]};
        P3 t1, t2; double h1, h2;
        if (S[f][0]){ t1 = ey; h1 = hy; t2 = ez; h2 = hz; } else if (S[f][1]){ t1 = ex; h1 = hx; t2 = ez; h2 = hz; } else { t1 = ex; h1 = hx; t2 = ey; h2 = hy; }
        const double hn = S[f][0] ? hx : (S[f][1] ? hy : hz); const P3 fc = {c.x + n.x*hn, c.y + n.y*hn, c.z + n.z*hn}; const uint32_t base = vcount();
        for (int a = -1; a <= 1; a += 2) for (int bb = -1; bb <= 1; bb += 2) vtx({fc.x + t1.x*h1*a + t2.x*h2*bb, fc.y + t1.y*h1*a + t2.y*h2*bb, fc.z + t1.z*h1*a + t2.z*h2*bb}, n, r, g, b);
        OUT->insert(OUT->end(), {base, base + 1, base + 2, base + 1, base + 3, base + 2, base, base + 2, base + 1, base + 1, base + 2, base + 3});
    }
}
static void tri(P3 a, P3 b, P3 c, P3 n, float r, float g, float bl){
    const uint32_t base = vcount(); vtx(a, n, r, g, bl); vtx(b, n, r, g, bl); vtx(c, n, r, g, bl);
    OUT->insert(OUT->end(), {base, base + 1, base + 2, base, base + 2, base + 1});
}

// ------------------------------------------------------------------------------------------------ the props
// all of them: position (x,z), ground gy, `n` = horizontal unit vector the face looks along (towards the driver)
static void signPost(double x, double z, double gy, double top){ tube({x, gy - 0.1, z}, {x, gy + top, z}, 0.032, 0.032, 8, 0.55f, 0.57f, 0.60f); }

// triangular curve warning sign. right = true: the road bends to the right (as seen by the driver this sign faces)
static void warnSign(double x, double z, double gy, P3 n, bool right){
    signPost(x, z, gy, 2.38);
    const P3 w = {n.z, 0, -n.x};                                                                  // screen-right of a viewer who looks against n
    const double s = 0.95, h = s * 0.866; const P3 c = {x + n.x * 0.05, gy + 1.82, z + n.z * 0.05};
    auto P = [&](double u, double v, double off){ return P3{c.x + w.x*u + n.x*off, c.y + v, c.z + w.z*u + n.z*off}; };
    const double k = 0.68;
    tri(P(0, 2*h/3, -0.012), P(-s/2, -h/3, -0.012), P(s/2, -h/3, -0.012), {-n.x, 0, -n.z}, 0.55f, 0.57f, 0.60f);                       // grey back
    tri(P(0, 2*h/3, 0), P(-s/2, -h/3, 0), P(s/2, -h/3, 0), n, 0.80f, 0.05f, 0.05f);                                                    // red border triangle
    tri(P(0, 2*h/3*k, 0.006), P(-s/2*k, -h/3*k, 0.006), P(s/2*k, -h/3*k, 0.006), n, 0.96f, 0.96f, 0.94f);                              // white inside
    const double sg = right ? 1.0 : -1.0;
    const double pu[5] = {-0.02, -0.02, 0.05, 0.12, 0.12}, pv[5] = {-0.22, -0.06, 0.04, 0.10, 0.10};
    for (int i = 0; i < 3; i++) tube(P(pu[i] * sg, pv[i] - 0.02, 0.014), P(pu[i+1] * sg, pv[i+1] - 0.02, 0.014), 0.026, 0.026, 4, 0.02f, 0.02f, 0.02f, false);
    { const P3 tip = P(0.13 * sg, 0.12 - 0.02, 0.014);                                           // arrow head
      tube(tip, P(0.03 * sg, 0.12 - 0.02, 0.014), 0.026, 0.026, 4, 0.02f, 0.02f, 0.02f, false);
      tube(tip, P(0.13 * sg, 0.02 - 0.02, 0.014), 0.026, 0.026, 4, 0.02f, 0.02f, 0.02f, false); }
}
// chevron board. right = true: arrow points to the viewer's right
static void chevron(double x, double z, double gy, P3 n, bool right){
    signPost(x, z, gy, 1.60);
    const P3 w = {n.z, 0, -n.x}; const P3 c = {x + n.x * 0.06, gy + 1.25, z + n.z * 0.06};
    obox({c.x - n.x * 0.010, c.y, c.z - n.z * 0.010}, w, n, 0.47, 0.34, 0.010, 0.04f, 0.04f, 0.04f);                                  // black frame
    obox(c, w, n, 0.44, 0.31, 0.012, 0.96f, 0.78f, 0.06f);                                                                             // yellow face
    auto P = [&](double u, double v){ return P3{c.x + w.x*u + n.x*0.016, c.y + v, c.z + w.z*u + n.z*0.016}; };
    const double sg = right ? 1.0 : -1.0;
    for (int k = 0; k < 2; k++){ const double sh = (k ? -0.20 : 0.06) * sg; const P3 T = P(0.16 * sg + sh, 0.0), A = P(-0.08 * sg + sh, 0.20), B = P(-0.08 * sg + sh, -0.20);
        tube(A, T, 0.030, 0.030, 4, 0.02f, 0.02f, 0.02f, false); tube(B, T, 0.030, 0.030, 4, 0.02f, 0.02f, 0.02f, false); }
}
// white guide post with a black band; reflector inserts (glow list) facing along +t / -t. outerOrange: the reflectors are orange instead of white
static void reflectorPost(double x, double z, double gy, double tx, double tz, bool outerOrange){
    useCell(x, z, false);
    tube({x, gy - 0.05, z}, {x, gy + 1.12, z}, 0.046, 0.046, 8, 0.80f, 0.80f, 0.78f);
    tube({x, gy + 0.76, z}, {x, gy + 0.98, z}, 0.050, 0.050, 8, 0.02f, 0.02f, 0.025f, false);
    useCell(x, z, true);
    const P3 ex = {-tz, 0, tx}, ez = {tx, 0, tz}; const float r = 1.0f, g = outerOrange ? 0.50f : 1.0f, b = outerOrange ? 0.06f : 0.88f;
    for (int sgn = -1; sgn <= 1; sgn += 2) obox({x + tx * 0.052 * sgn, gy + 0.87, z + tz * 0.052 * sgn}, ex, ez, 0.032, 0.052, 0.007, r, g, b);
}
static void kmStone(double x, double z, double gy, P3 n){
    const P3 w = {n.z, 0, -n.x}; useCell(x, z, false);
    obox({x, gy + 0.26, z}, w, n, 0.10, 0.31, 0.065, 0.86f, 0.86f, 0.82f);                                                             // white stone
    obox({x, gy + 0.62, z}, w, n, 0.106, 0.07, 0.070, 0.80f, 0.10f, 0.08f);                                                            // red cap
    obox({x + n.x * 0.066, gy + 0.33, z + n.z * 0.066}, w, n, 0.062, 0.095, 0.004, 0.03f, 0.03f, 0.03f);                                // number plate
    obox({x + n.x * 0.069, gy + 0.33, z + n.z * 0.069}, w, n, 0.042, 0.022, 0.003, 0.92f, 0.92f, 0.90f);                                // "digits"
}

// ------------------------------------------------------------------------------------------------ placement
static bool nearGuard(double x, double z, double r){
    const long cx = (long)std::floor(x / Fence::CELL), cz = (long)std::floor(z / Fence::CELL);
    for (long i = cx - 1; i <= cx + 1; i++) for (long j = cz - 1; j <= cz + 1; j++){
        auto it = Fence::gGGrid.find(Fence::gkey(i, j)); if (it == Fence::gGGrid.end()) continue;
        for (int gi : it->second){ const double dx = Fence::gGPts[(size_t)gi*2] - x, dz = Fence::gGPts[(size_t)gi*2+1] - z; if (dx*dx + dz*dz < r*r) return true; } }
    return false;
}

static void build(){
    if (gOk) return;
    const std::vector<const Road::Curve*> ROADS = Road::all(); const int NRD = (int)ROADS.size();
    std::vector<std::vector<double>> pts(NRD);
    for (int r = 0; r < NRD; r++){ const Road::Curve& cv = *ROADS[r]; const int n = std::max(8, (int)std::ceil(cv.length() / 3.0));
        for (int k = 0; k <= n; k++){ Road::V3 p = cv.getPointAt(cv.open ? std::min((double)k / n, 0.99999) : (double)(k % n) / n); pts[r].push_back(p.x); pts[r].push_back(p.z); } }
    auto blocked = [&](double x, double z, int ci, double rad){
        if (std::fabs(River::riverSd(x, z)) < 34.0) return true;
        if (Terrain::trackDist(x, z) < 14.0 || Terrain::coastDist(x, z) > -52.0) return true;
        for (int r = 0; r < NRD; r++){ if (r == ci) continue; const double lim = ROADS[r]->hw + 8.0, l2 = lim * lim; const auto& a = pts[r];
            for (size_t k = 0; k < a.size(); k += 2){ const double dx = x - a[k], dz = z - a[k+1]; if (dx*dx + dz*dz < l2) return true; } }
        for (const Village::Building& b : Village::gB){ const double dx = x - b.x, dz = z - b.z; if (dx*dx + dz*dz < 9.0 * 9.0) return true; }
        for (const Fence::Lamp& l : Fence::gLamps){ const double dx = x - l.x, dz = z - l.z; if (dx*dx + dz*dz < 2.5 * 2.5) return true; }
        for (size_t i = 0; i + 1 < PowerLine::gPos.size(); i += 2){ const double dx = x - PowerLine::gPos[i], dz = z - PowerLine::gPos[i+1]; if (dx*dx + dz*dz < 3.0 * 3.0) return true; }
        return nearGuard(x, z, rad); };

    for (int ci = 0; ci < NRD; ci++){
        const Road::Curve& cv = *ROADS[ci]; const double L = cv.length(), hw = cv.hw; const bool closed = !cv.open;
        const int N = std::max(12, (int)std::ceil(L / 4.0));                                     // one sample every ~4 m
        const int M = closed ? N : N + 1;
        struct S { double x, z, tx, tz; }; std::vector<S> sm(M);
        for (int i = 0; i < M; i++){ const double t = closed ? (double)i / N : std::min((double)i / N, 0.99999); Road::V3 p = cv.getPointAt(t), tg = cv.getTangentAt(t);
            double l = std::hypot(tg.x, tg.z); if (l < 1e-9) l = 1; sm[i] = {p.x, p.z, tg.x / l, tg.z / l}; }
        auto at = [&](int i, bool& ok){ ok = true; if (closed) return ((i % M) + M) % M; if (i < 0 || i >= M){ ok = false; return 0; } return i; };
        std::vector<double> turn(M, 0.0);                                                         // signed turn over +-12 m: > 0 = left, < 0 = right
        // (cr < 0 = turning right, so `turn` is positive for a RIGHT turn from here on)
        for (int i = 0; i < M; i++){ bool o1, o2; const int a = at(i - 3, o1), b = at(i + 3, o2); if (!o1 || !o2) { turn[i] = 0; continue; }
            const double cr = sm[a].tz * sm[b].tx - sm[a].tx * sm[b].tz, dt = sm[a].tx * sm[b].tx + sm[a].tz * sm[b].tz; turn[i] = -std::atan2(cr, dt); }

        // ---- kilometre stones (right-hand side of the +direction)
        for (int km = 1; km * KM < L - 40.0; km++){
            const double t = (km * KM) / L; Road::V3 p = cv.getPointAt(t), tg = cv.getTangentAt(t); double l = std::hypot(tg.x, tg.z); if (l < 1e-9) continue; const double tx = tg.x / l, tz = tg.z / l;
            const double rx = -tz, rz = tx;                                                       // right of the travel direction
            const double d = hw + 1.5, x = p.x + rx * d, z = p.z + rz * d; if (blocked(x, z, ci, 1.4)) continue;
            P3 n = norm({-rx * 0.9 - tx * 0.45, 0, -rz * 0.9 - tz * 0.45}); kmStone(x, z, Terrain::fieldH(x, z), n);
        }

        // ---- bends: find runs where |turn| > TURN_WARN
        int i = 0;
        while (i < M){
            if (std::fabs(turn[i]) < TURN_WARN){ i++; continue; }
            const double sgn = turn[i] > 0 ? 1.0 : -1.0; int j = i, gap = 0, last = i; double mx = std::fabs(turn[i]);
            while (j + 1 < M && gap <= 3){ j++; if (turn[j] * sgn >= TURN_WARN * 0.8){ last = j; gap = 0; mx = std::max(mx, std::fabs(turn[j])); } else gap++; }
            const int i0 = i, i1 = last; i = last + 1;
            const bool right = sgn > 0;                                                           // bend direction for a driver travelling in the +direction
            // warning signs: 11 samples (~44 m) before the bend for each driving direction
            for (int dir = 0; dir < 2; dir++){
                bool ok; const int k = at(dir == 0 ? i0 - 11 : i1 + 11, ok); if (!ok) continue; const S& s = sm[k];
                const double fx = dir == 0 ? s.tx : -s.tx, fz = dir == 0 ? s.tz : -s.tz;           // travel direction of this driver
                const double rx = -fz, rz = fx, d = hw + 1.7, x = s.x + rx * d, z = s.z + rz * d; if (blocked(x, z, ci, 1.4)) continue;
                P3 n = norm({-fx * 0.96 - rx * 0.28, 0, -fz * 0.96 - rz * 0.28});
                warnSign(x, z, Terrain::fieldH(x, z), n, dir == 0 ? right : !right);
            }
            // reflector posts on both edges, every 2 samples, a little beyond the bend
            for (int k0 = i0 - 2; k0 <= i1 + 2; k0 += 2){
                bool ok; const int k = at(k0, ok); if (!ok) continue; const S& s = sm[k];
                for (int side = -1; side <= 1; side += 2){
                    const double rx = -s.tz * side, rz = s.tx * side, d = hw + 1.5, x = s.x + rx * d, z = s.z + rz * d; if (blocked(x, z, ci, 1.8)) continue;
                    const bool outer = (side > 0) != right;                                          // +side = right of +direction; the outer side of a right bend is the left
                    reflectorPost(x, z, Terrain::fieldH(x, z) , s.tx, s.tz, outer);
                }
            }
            // chevrons on the outer side of tight bends
            if (mx >= TURN_TIGHT){
                int cnt = 0;
                for (int k0 = i0; k0 <= i1; k0 += 3, cnt++){
                    if (std::fabs(turn[k0]) < TURN_TIGHT * 0.85) continue; bool ok; const int k = at(k0, ok); if (!ok) continue; const S& s = sm[k];
                    const double ox = right ? s.tz : -s.tz, oz = right ? -s.tx : s.tx;               // outer side: left of +direction for a right bend (= -right vector)
                    const double d = hw + 2.4, x = s.x + ox * d, z = s.z + oz * d; if (blocked(x, z, ci, 1.3)) continue;
                    const bool fwd = (cnt % 2 == 0);                                                 // alternate: faces the +direction traffic, then the -direction traffic
                    const double inx = -ox, inz = -oz, tx = fwd ? s.tx : -s.tx, tz = fwd ? s.tz : -s.tz;   // tx,tz = travel direction of the driver this board faces
                    P3 n = norm({-tx * 0.80 + inx * 0.60, 0, -tz * 0.80 + inz * 0.60});
                    useCell(x, z, false); chevron(x, z, Terrain::fieldH(x, z), n, fwd ? right : !right);
                }
            }
        }
    }
    // ---- pack the cells into one index buffer (solid part first, reflector part after it)
    std::vector<uint32_t> all;
    for (auto& kv : gCells){
        Chunk c; c.sFirst = (uint32_t)all.size(); all.insert(all.end(), kv.second.s.begin(), kv.second.s.end()); c.sCount = (uint32_t)kv.second.s.size();
        c.gFirst = (uint32_t)all.size(); all.insert(all.end(), kv.second.g.begin(), kv.second.g.end()); c.gCount = (uint32_t)kv.second.g.size();
        const long long k = kv.first; const long long ix = k / 20011LL - 10000, iz = k % 20011LL - 10000; c.cx = (float)((ix + 0.5) * CELLW); c.cz = (float)((iz + 0.5) * CELLW);
        if (c.sCount || c.gCount) gChunks.push_back(c);
    }
    gCells.clear(); gIdx.swap(all);
}

static const char* VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in vec3 n; layout(location=2) in vec3 c;
uniform mat4 uVP; out vec3 vn; out vec3 wp; out vec3 vc;
void main(){ wp = p; vn = n; vc = c; gl_Position = uVP * vec4(p, 1.0); }
)GLSL";
static const char* FS = R"GLSL(#version 300 es
precision highp float;
in vec3 vn; in vec3 wp; in vec3 vc; uniform vec3 uCam; uniform int uMode; uniform float uN; out vec4 o;
void main(){
  float dist = length(uCam - wp);
  if (uMode == 2){ float fade = 1.0 - smoothstep(30.0, 190.0, dist); o = vec4(vc * uN * (0.45 + 1.1 * fade), 1.0); return; }
  vec3 N = normalize(vn); if (!gl_FrontFacing) N = -N;
  vec3 base = pow(vc, vec3(2.2)) * (uMode == 1 ? 1.7 : 1.0);
  vec3 L = SUNL; float d = max(dot(N, L), 0.0), wrap = max(dot(N, L) * 0.5 + 0.5, 0.0);
  vec3 amb = mix(vec3(0.20, 0.18, 0.13), vec3(0.32, 0.39, 0.50), N.y * 0.5 + 0.5);
  vec3 lit = base * (amb + vec3(1.0, 0.93, 0.78) * (0.78 * d + 0.12 * wrap));
  vec3 c = pow(lit, vec3(1.0 / 2.2));
  c = mix(c, vec3(0.62, 0.80, 0.95), clamp(dist / 3750.0, 0.0, 1.0));
  o = vec4(c, 1.0);
}
)GLSL";
static GLuint sh(GLenum t, const char* s){ GLuint x = glCreateShader(t); SunLight::shaderSource(x, s); glCompileShader(x); return x; }

// call once with a current GL context, after PowerLine::init() (needs the lamp, pole and guardrail layout)
static void init(){
    if (gOk) return;
    build(); if (gIdx.empty()) return;
    gProg = glCreateProgram(); glAttachShader(gProg, sh(GL_VERTEX_SHADER, VS)); glAttachShader(gProg, sh(GL_FRAGMENT_SHADER, FS)); glLinkProgram(gProg); SunLight::attach(gProg);
    uVP = glGetUniformLocation(gProg, "uVP"); uCam = glGetUniformLocation(gProg, "uCam"); uMode = glGetUniformLocation(gProg, "uMode"); uN = glGetUniformLocation(gProg, "uN");
    glGenVertexArrays(1, &gVao); glBindVertexArray(gVao);
    glGenBuffers(1, &gVbo); glBindBuffer(GL_ARRAY_BUFFER, gVbo); glBufferData(GL_ARRAY_BUFFER, gV.size() * 4, gV.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 36, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 36, (void*)12);
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 36, (void*)24);
    glGenBuffers(1, &gIbo); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gIbo); glBufferData(GL_ELEMENT_ARRAY_BUFFER, gIdx.size() * 4, gIdx.data(), GL_STATIC_DRAW);
    glBindVertexArray(0);
    std::vector<float>().swap(gV); std::vector<uint32_t>().swap(gIdx); gOk = true;
}
static void pass(const float* eye, int mode, bool glowList, float range){
    glUniform1i(uMode, mode);
    for (const Chunk& c : gChunks){
        const uint32_t cnt = glowList ? c.gCount : c.sCount; if (!cnt) continue;
        const float dx = c.cx - eye[0], dz = c.cz - eye[2], lim = range + 100.f; if (dx*dx + dz*dz > lim*lim) continue;
        glDrawElements(GL_TRIANGLES, (GLsizei)cnt, GL_UNSIGNED_INT, (void*)(uintptr_t)((glowList ? c.gFirst : c.sFirst) * 4));
    }
}
static void draw(const float* VP, const float* eye){
    if (!gOk) return;
    const float sc = Quality::distScale();
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glDisable(GL_BLEND);
    glUseProgram(gProg); glUniformMatrix4fv(uVP, 1, GL_FALSE, VP); glUniform3fv(uCam, 1, eye); glUniform1f(uN, 0.f);
    glBindVertexArray(gVao);
    pass(eye, 0, false, 260.f * sc);          // posts, boards, signs, stones
    pass(eye, 1, true, 200.f * sc);           // reflectors: shiny by day
    glBindVertexArray(0);
}
// after NightGL::overlay(): the reflectors glow in the dark (like they catch the headlights)
static void drawNight(const float* VP, const float* eye, float night){
    if (!gOk) return;
    float t = (night - 0.08f) / 0.47f; t = t < 0.f ? 0.f : (t > 1.f ? 1.f : t); const float N = t * t * (3.f - 2.f * t); if (N < 0.01f) return;
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glDisable(GL_BLEND); glDepthFunc(GL_LEQUAL); glDepthMask(GL_FALSE);
    glUseProgram(gProg); glUniformMatrix4fv(uVP, 1, GL_FALSE, VP); glUniform3fv(uCam, 1, eye); glUniform1f(uN, N);
    glBindVertexArray(gVao); pass(eye, 2, true, 200.f * Quality::distScale()); glBindVertexArray(0);
    glDepthMask(GL_TRUE); glDepthFunc(GL_LESS);
}

} // namespace RoadSigns
