#pragma once
// Sunny Drift - central driving-feel tuning + driver assists (one place for the values that are meant to be adjusted).
// Physical constants of the car itself (mass, ratios, tyre model) stay in car_core.h namespace Veh.
namespace Tune {
    // ---- electronic aids (Settings -> Controls) ----
    static bool   absOn = true, tcsOn = true, escOn = true;
    static bool   driftAssist = true;        // keeps a slide controllable on a touch screen: stronger counter-steer + faster rear-grip recovery once you lift
    static bool   steerAssist = true;        // understeer relief: takes some lock off when the front tyres are clearly past their grip peak
    static bool   manualBox   = false;       // false = 7-speed dual-clutch automatic, true = manual (shift up / down buttons, keys E / Q)
    static bool   brakeFadeOn = false;       // optional advanced feature: brakes lose bite when they are cooked by repeated hard stops
    static int    roadCond    = 0;           // 0 dry, 1 wet, 2 snow, 3 ice: multiplies the grip of every surface
    // ---- pedals ----
    static double throttleCurve = 1.35;      // analog throttle: engine demand = pedal ^ curve (>1 = gentler first half of the pedal travel)
    static double brakeCurve    = 1.25;      // analog brake:    brake demand  = pedal ^ curve
    // ---- brakes ----
    static double brakeBias     = 0.62;      // share of the brake force on the FRONT axle (R8-like, front biased)
    static double absFloor      = 0.97;      // ABS holds each axle at this share of its grip peak (stays strong, never locks)
    static double lockedGrip    = 0.82;      // without ABS a locked axle only delivers this share of its peak braking force
    static double lockedLateral = 0.55;      // ... and keeps only this share of its lateral grip
    static double fadeHeat      = 0.30;    // brake temperature gain per MJ of braking work (0.30: two hard stops from 200 km/h)
    static double fadeCool      = 0.045;     // base cooling per second (+ airflow with speed)
    static double fadeLoss      = 0.30;      // share of braking force lost when the brakes are fully cooked
    // ---- handbrake ----
    static double handbrakeStrength = 0.55;  // share of the rear-tyre grip the locked rear axle uses to brake the car
    static double handbrakeRise     = 4.0;   // 1/s: how fast the lever locks the rear axle
    static double handbrakeRelease  = 2.6;   // 1/s: how fast the rear grip comes back after the lever is let go (progressive recovery, no snap)
    // ---- drive aids ----
    static double tcsStart      = 0.86;      // rear grip utilisation (drive force) above which TCS starts to cut power
    static double tcsStrength   = 0.70;      // 0..1: how much power TCS removes at full wheel-spin (0.7 leaves room for power oversteer)
    static double escStrength   = 0.55;      // 0..1: yaw damping of the stability control once the slip angle is large
    static double escStart      = 0.50;      // body slip angle (rad) where ESC starts to act (drift angles below this are never touched)
    static double rearDriveLoad = 1.0;       // how much of the drive force counts against the rear friction circle (1.0 = full power oversteer, 0.8 = grippy)
    static double counterSteer  = 0.50;      // electronic counter-steer in a slide (0 = none, 1 = strong)
    static double driftHold     = 0.80;      // drift assist: share of the rear grip that throttle takes away while sliding (0 = none)
    static double driftAssistK  = 0.8;       // extra counter-steer gain with the drift assist on
    static double steerAssistStart = 0.16;   // front slip angle (rad) where the steering assist starts to take lock off
    // ---- road condition: grip multiplier per setting ----
    static inline double roadMu(){ static const double K[4] = {1.0, 0.72, 0.40, 0.20}; return K[roadCond < 0 ? 0 : (roadCond > 3 ? 3 : roadCond)]; }
    static inline double roadRr(){ static const double K[4] = {1.0, 1.0, 1.9, 1.3}; return K[roadCond < 0 ? 0 : (roadCond > 3 ? 3 : roadCond)]; }
}
