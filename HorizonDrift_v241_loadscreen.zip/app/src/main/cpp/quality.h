// Sunny Drift - graphics quality preset (0 = Low, 1 = Normal, 2 = High). Scales how far trees / fences / houses are drawn.
#pragma once
namespace Quality {
  static int level = 1;
  static bool flat = false;                        // Settings > Graphics quality > "Super smooth": every tree is only a 2D picture, no grass / flowers / bushes, little tyre smoke
  static float bbDist = 200.f;                     // trees nearer than this are real 3D models, farther ones are 2D pictures that always face the camera
  static int grassMode = 0;                         // Settings toggles: 0 = mixed (3D near, 2D far), 1 = all grass 3D, 2 = all grass 2D
  static bool grassOff = false;                   // Settings > Graphics > "Grass" switch: off = no grass blades, tall grass or flowers at all (bushes stay)
  static float grassScale = 1.f;                  // Settings > "Grass distance": 0.2 .. 1 of the full grass / flower / tall-grass range
  static float viewScale = 1.f;                    // Settings > "World draw distance": 0.4 .. 2 x (houses, fences, lamps, boulders, tree detail ranges)
  static float treeDist = 4000.f;                  // Settings > "Tree distance": how far away trees are still drawn (far ones as 2D pictures of the real tree)
  static bool billboards(){ return true; }         // far trees are always baked camera-facing pictures (never a dark flat shape)
  static float distScale(){ return (level == 0 ? 0.55f : (level == 2 ? 1.4f : 1.0f)) * viewScale; }   // Normal = the original look
}
