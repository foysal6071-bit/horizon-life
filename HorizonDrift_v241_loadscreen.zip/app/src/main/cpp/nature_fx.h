// Sunny Drift - very light nature effects: a waterfall down a mountain flank (one small animated ribbon + a soft spray puff)
// and a thin, patchy layer of low cloud drifting over the valley (one flat disc, 2 texture lookups per pixel).
// Both are alpha-blended, write no depth and are drawn before the night overlay, so they darken with the rest of the picture.
#pragma once
#include "nature_plan.h"
#include "terrain_render.h"
#include "weather.h"
#include "tunnel.h"

namespace NatureFxGL {

static const char* FALL_VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in vec2 uv;
uniform mat4 uVP; uniform int uMode; uniform vec3 uBase, uRight; uniform float uSize; out vec2 vuv; out vec3 wp;
void main(){
  vec3 w = p;
  if (uMode == 1) w = uBase + uRight * (uv.x * uSize) + vec3(0.0, (uv.y * 0.5 + 0.5) * uSize * 0.55, 0.0);
  vuv = uv; wp = w; gl_Position = uVP * vec4(w, 1.0);
}
)GLSL";
static const char* FALL_FS = R"GLSL(#version 300 es
precision mediump float;
in vec2 vuv; in vec3 wp; uniform int uMode; uniform float uT; uniform vec3 uCam; out vec4 o;
float h21(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float vn(vec2 p){ vec2 i = floor(p), f = fract(p); f = f*f*(3.0 - 2.0*f); return mix(mix(h21(i), h21(i + vec2(1,0)), f.x), mix(h21(i + vec2(0,1)), h21(i + vec2(1,1)), f.x), f.y); }
void main(){
  vec3 hz = vec3(0.72, 0.87, 0.98);
  float fog = clamp(length(uCam - wp) / 3750.0, 0.0, 1.0);
  if (uMode == 1){                                            // spray at the foot: a soft, slowly breathing puff
    float r = length(vuv); float a = (1.0 - smoothstep(0.15, 1.0, r)) * (0.26 + 0.07 * sin(uT * 0.8 + vuv.x * 2.0));
    o = vec4(mix(vec3(0.96, 0.98, 1.0), hz, fog), a * (1.0 - 0.6 * fog)); return;
  }
  float c = abs(vuv.x * 2.0 - 1.0);
  float edge = 1.0 - smoothstep(0.50, 1.0, c);
  float s = 0.55 * vn(vec2(vuv.x * 7.0, vuv.y * 0.12 + uT * 2.2)) + 0.45 * vn(vec2(vuv.x * 17.0 + 3.0, vuv.y * 0.25 + uT * 3.6));   // streaks running down
  vec3 col = mix(vec3(0.62, 0.80, 0.92), vec3(1.0), smoothstep(0.30, 0.80, s));
  float a = edge * (0.40 + 0.50 * s) * smoothstep(0.0, 14.0, vuv.y) * 0.85;
  o = vec4(mix(col, hz, fog), a * (1.0 - 0.5 * fog));
}
)GLSL";
static const char* CLOUD_VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; uniform mat4 uVP; out vec3 wp;
void main(){ wp = p; gl_Position = uVP * vec4(p, 1.0); }
)GLSL";
static const char* CLOUD_FS = R"GLSL(#version 300 es
precision mediump float;
in vec3 wp; uniform vec3 uCam; uniform float uT; uniform sampler2D uFbm; out vec4 o;
void main(){
  vec2 q = wp.xz;
  float n = 0.62 * texture(uFbm, q * 0.0021 + vec2(uT * 0.0030, uT * 0.0012)).r + 0.38 * texture(uFbm, q * 0.0062 - vec2(uT * 0.0045, -uT * 0.0020)).g;
  float m = smoothstep(0.48, 0.74, n);                                   // patchy: only part of the valley is covered
  float d = length(q - uCam.xz);
  float f = smoothstep(140.0, 450.0, d) * (1.0 - smoothstep(1050.0, 1650.0, d));   // clear around the car, melts away far off
  vec3 col = vec3(0.96, 0.98, 1.0) * (0.90 + 0.10 * n);
  col = mix(col, vec3(0.72, 0.87, 0.98), clamp(d / 4500.0, 0.0, 0.5));
  o = vec4(col, m * f * 0.30);                                           // at most 30 % opaque: a light veil
}
)GLSL";

// ---- SUN SHAFTS in the ginkgo forest: soft additive columns that follow the real sun direction (SUNL), standing in the gaps between the trees ----
static const char* SHAFT_VS = R"GLSL(#version 300 es
layout(location=0) in vec3 base; layout(location=1) in vec4 prm;
uniform mat4 uVP; uniform vec3 uCam; out vec2 vuv; out vec3 wp; out float vseed;
void main(){
  vec3 L = SUNL; float u = prm.x, v = prm.y, w = prm.z;
  vec3 c = base + L * (v * 17.0 / max(L.y, 0.3));                       // a column along the sun's rays, from the ground up to ~17 m height
  vec3 r = cross(L, uCam - c); float rl = length(r); r = rl > 1e-3 ? r / rl : vec3(1.0, 0.0, 0.0);   // turned round the ray axis towards the camera
  c += r * (u * w * (0.80 + 0.20 * v));
  vuv = vec2(u, v); wp = c; vseed = prm.w; gl_Position = uVP * vec4(c, 1.0);
}
)GLSL";
static const char* SHAFT_FS = R"GLSL(#version 300 es
precision mediump float;
in vec2 vuv; in vec3 wp; in float vseed; uniform vec3 uCam; uniform float uT, uK, uWarm; out vec4 o;
void main(){
  float e = 1.0 - vuv.x * vuv.x; e *= e;                                                   // soft sides
  float fv = smoothstep(0.0, 0.20, vuv.y) * (1.0 - smoothstep(0.62, 1.0, vuv.y));          // melts into the air at both ends
  float d = length(uCam - wp);
  float fd = smoothstep(7.0, 24.0, d) * (1.0 - smoothstep(110.0, 240.0, d));               // never a hard wall in front of the camera, gone far away
  float dust = 0.72 + 0.28 * sin(uT * 0.7 + vseed * 40.0 + vuv.y * 5.0);                   // slow shimmer
  float a = e * fv * fd * dust * uK * 0.30;
  vec3 col = mix(vec3(1.0, 0.91, 0.64), vec3(1.0, 0.76, 0.38), uWarm);
  o = vec4(col, a);
}
)GLSL";
static GLuint gShaftProg = 0; static GLint uS_VP = -1, uS_Cam = -1, uS_T = -1, uS_K = -1, uS_Warm = -1; static BridgeGL::Gpu gShaft;

static void initShafts(){
    if (!Road::gNet.ready || (int)Road::gNet.roads.size() <= Road::NEW_EDGE) return;
    gShaftProg = RoadGL::makeProg(SHAFT_VS, SHAFT_FS);
    uS_VP = glGetUniformLocation(gShaftProg, "uVP"); uS_Cam = glGetUniformLocation(gShaftProg, "uCam"); uS_T = glGetUniformLocation(gShaftProg, "uT");
    uS_K = glGetUniformLocation(gShaftProg, "uK"); uS_Warm = glGetUniformLocation(gShaftProg, "uWarm");
    const Road::Curve& cv = Road::gNet.roads[Road::NEW_EDGE]; const double len = cv.length(), hw = cv.hw; uint32_t rs = 0x2c1b3c6du;
    auto R = [&]{ rs = rs * 1664525u + 1013904223u; return (float)((rs >> 8) / 16777216.0); };
    std::vector<float> v; std::vector<uint32_t> idx; int n = 0;
    for (double s = 14.0; s < len - 14.0 && n < 520; s += 5.0 + 5.0 * R()){
        const Road::V3 p = cv.getPointAt(s / len), tg = cv.getTangentAt(s / len); const double nl = std::hypot(tg.x, tg.z); if (nl == 0 || Tunnel::inRoadTunnel(p.x, p.z)) continue;
        const double nx = -tg.z / nl, nz = tg.x / nl; const int cnt = 1 + (R() < 0.45f ? 1 : 0);
        for (int k = 0; k < cnt; k++){
            if (R() < 0.30f) continue;
            const double sd = R() < 0.5f ? -1.0 : 1.0, q = R(); const bool onRoad = R() < 0.22f;
            const double u = onRoad ? q * (hw - 0.3) : hw + 2.0 + 40.0 * q * q;
            const float x = (float)(p.x + nx * u * sd), z = (float)(p.z + nz * u * sd);
            if (!onRoad && (std::fabs(River::riverSd(x, z)) < River::RIVER_WALL + 6.0 || Village::blocked(x, z, 2.f))) continue;
            const float y = onRoad ? 0.1f : (float)Terrain::meshH(x, z), w = 1.3f + 3.2f * R(), seed = R();
            const float c4[4][4] = {{-1, 0, w, seed}, {1, 0, w, seed}, {-1, 1, w, seed}, {1, 1, w, seed}};
            const uint32_t b0 = (uint32_t)(v.size() / 7);
            for (int c = 0; c < 4; c++){ const float row[7] = {x, y, z, c4[c][0], c4[c][1], c4[c][2], c4[c][3]}; v.insert(v.end(), row, row + 7); }
            const uint32_t t[6] = {b0, b0 + 1, b0 + 2, b0 + 1, b0 + 3, b0 + 2}; idx.insert(idx.end(), t, t + 6); n++;
        }
    }
    if (!n) return;
    const int an[2] = {3, 4}, ao[2] = {0, 12}; gShaft = BridgeGL::upload(v.data(), v.size() * 4, idx, 28, an, ao, 2);
}
// additive, after the trees: strength follows the sun height (none at night / dusk), warmer when the sun is low
static void drawShafts(const float* VP, const float* eye, float t){
    if (!gShaft.count) return;
    const float sy = Weather::sunDir[1]; const float k = std::min(1.f, std::max(0.f, (sy - 0.04f) / 0.20f)); if (k <= 0.001f) return;
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glDepthMask(GL_FALSE); glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE);
    glUseProgram(gShaftProg); glUniformMatrix4fv(uS_VP, 1, GL_FALSE, VP); glUniform3fv(uS_Cam, 1, eye); glUniform1f(uS_T, t); glUniform1f(uS_K, k); glUniform1f(uS_Warm, Weather::sun);
    BridgeGL::drawGpu(gShaft);
    glDepthMask(GL_TRUE); glDisable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
}

static GLuint gFallProg = 0, gCloudProg = 0, gCloudTex = 0;
static GLint uF_VP, uF_Mode, uF_Base, uF_Right, uF_Size, uF_T, uF_Cam, uC_VP, uC_Cam, uC_T, uC_Fbm;
static BridgeGL::Gpu gFall, gMist, gCloud; static float gBase[3] = {0, 0, 0}; static bool gOk = false;

// Call once with a GL context, after Terrain::init(), NatureFx::plan(), RoadGL::init() and BridgeGL::init().
static void init(){
    gFallProg = RoadGL::makeProg(FALL_VS, FALL_FS); gCloudProg = RoadGL::makeProg(CLOUD_VS, CLOUD_FS);
    uF_VP = glGetUniformLocation(gFallProg, "uVP"); uF_Mode = glGetUniformLocation(gFallProg, "uMode"); uF_Base = glGetUniformLocation(gFallProg, "uBase");
    uF_Right = glGetUniformLocation(gFallProg, "uRight"); uF_Size = glGetUniformLocation(gFallProg, "uSize"); uF_T = glGetUniformLocation(gFallProg, "uT"); uF_Cam = glGetUniformLocation(gFallProg, "uCam");
    uC_VP = glGetUniformLocation(gCloudProg, "uVP"); uC_Cam = glGetUniformLocation(gCloudProg, "uCam"); uC_T = glGetUniformLocation(gCloudProg, "uT"); uC_Fbm = glGetUniformLocation(gCloudProg, "uFbm");
    // low cloud: one flat disc 55 m above the zero level (rings 1 / 400 / 900 / 1700 m)
    {   const float R[4] = {1.f, 600.f, 1350.f, 2550.f}; const int NS = 48; std::vector<float> v; std::vector<uint32_t> idx;
        for (int i = 0; i < 4; i++) for (int j = 0; j < NS; j++){ const float a = (float)j / NS * 6.2831853f; v.push_back(std::cos(a) * R[i]); v.push_back(55.f); v.push_back(std::sin(a) * R[i]); }
        for (int i = 0; i < 3; i++) for (int j = 0; j < NS; j++){ const uint32_t a = i*NS + j, b = i*NS + (j+1) % NS, c = (i+1)*NS + j, d = (i+1)*NS + (j+1) % NS; const uint32_t t[6] = {a, c, b, b, c, d}; idx.insert(idx.end(), t, t + 6); }
        const int n[1] = {3}, o[1] = {0}; gCloud = BridgeGL::upload(v.data(), v.size() * 4, idx, 12, n, o, 1); gCloudTex = RoadGL::gFbmTex; }
    // waterfall ribbon: 5 columns across, every column sits 0.9 m above the real mountain surface
    if (NatureFx::gFallOn){
        const int N = (int)NatureFx::PX.size(), C = 5; std::vector<float> v; std::vector<uint32_t> idx; float lastY = 0;
        for (int i = 0; i < N; i++){
            const int a = std::max(0, i - 1), b = std::min(N - 1, i + 1);
            float tx = NatureFx::PX[b] - NatureFx::PX[a], tz = NatureFx::PZ[b] - NatureFx::PZ[a]; const float tl = std::sqrt(tx*tx + tz*tz); if (tl < 1e-4f){ tx = 1; tz = 0; } else { tx /= tl; tz /= tl; }
            const float sx = -tz, sz = tx, t = (float)i / (N - 1), hw = 0.5f * (3.0f + 5.0f * t * t * (3 - 2 * t));
            for (int c = 0; c < C; c++){
                const float u = (float)c / (C - 1), off = (u * 2 - 1) * hw, x = NatureFx::PX[i] + sx * off, z = NatureFx::PZ[i] + sz * off;
                double h = Terrain::mtnH(x, z); const float y = (h >= 0 ? (float)h : lastY) + 0.9f; lastY = y;
                const float row[5] = {x, y, z, u, 5.f * i}; v.insert(v.end(), row, row + 5);
            }
        }
        for (int i = 0; i + 1 < N; i++) for (int c = 0; c + 1 < C; c++){ const uint32_t a = i*C + c, b = i*C + c + 1, d = (i+1)*C + c, e = (i+1)*C + c + 1; const uint32_t t[6] = {a, b, d, b, e, d}; idx.insert(idx.end(), t, t + 6); }
        const int n[2] = {3, 2}, o[2] = {0, 12}; gFall = BridgeGL::upload(v.data(), v.size() * 4, idx, 20, n, o, 2);
        const float q[4][5] = {{0,0,0,-1,-1}, {0,0,0,1,-1}, {0,0,0,-1,1}, {0,0,0,1,1}}; std::vector<float> mv(&q[0][0], &q[0][0] + 20); std::vector<uint32_t> mi = {0, 1, 2, 1, 3, 2};
        gMist = BridgeGL::upload(mv.data(), mv.size() * 4, mi, 20, n, o, 2);
        gBase[0] = NatureFx::PX[N - 1]; gBase[2] = NatureFx::PZ[N - 1]; const double hb = Terrain::mtnH(gBase[0], gBase[2]); gBase[1] = (hb >= 0 ? (float)hb : 0.f) + 1.0f;
    }
    initShafts();
    gOk = true;
}

// transparent: call after the opaque scene (and the lake), before the night overlay
static void draw(const float* VP, const float* eye, float t){
    if (!gOk) return;
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glDepthMask(GL_FALSE); glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    if (gFall.count){
        glUseProgram(gFallProg); glUniformMatrix4fv(uF_VP, 1, GL_FALSE, VP); glUniform3fv(uF_Cam, 1, eye); glUniform1f(uF_T, t);
        glEnable(GL_POLYGON_OFFSET_FILL); glPolygonOffset(-3.f, -3.f);
        glUniform1i(uF_Mode, 0); BridgeGL::drawGpu(gFall);
        glDisable(GL_POLYGON_OFFSET_FILL);
        float rx = eye[2] - gBase[2], rz = -(eye[0] - gBase[0]), l = std::sqrt(rx*rx + rz*rz); if (l < 1e-4f) l = 1;      // spray puff faces the camera (horizontal right vector)
        glUniform1i(uF_Mode, 1); glUniform3f(uF_Base, gBase[0], gBase[1], gBase[2]); glUniform3f(uF_Right, rx / l, 0.f, rz / l); glUniform1f(uF_Size, 22.f); BridgeGL::drawGpu(gMist);
    }
    glUseProgram(gCloudProg); glUniformMatrix4fv(uC_VP, 1, GL_FALSE, VP); glUniform3fv(uC_Cam, 1, eye); glUniform1f(uC_T, t);
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, gCloudTex); glUniform1i(uC_Fbm, 0);
    BridgeGL::drawGpu(gCloud);
    glDepthMask(GL_TRUE); glDisable(GL_BLEND);
}

} // namespace NatureFxGL
