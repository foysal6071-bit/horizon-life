// Sunny Drift - baked, tileable asphalt texture (replaces the old white-noise lookups in the road shader).
// One tile = TILE_M metres. Channels: R = aggregate / speckle albedo (0.5 = neutral), G = hairline crack mask,
// B / A = baked height gradient d/dx, d/dy (0.5 = flat) -> smooth bump without screen-space derivatives (no 2x2 pixel blocks).
// Size follows Settings > Graphics: Low 512, Normal 1024, High 2048. Everything mipmaps to neutral, so far asphalt stays calm.
#pragma once
#include <vector>
#include <cstdint>
#include <cmath>
#include <algorithm>

namespace AsphaltTex {
static const float TILE_M = 4.f;                                   // world size of one tile (metres)
static inline int sizeFor(int lv){ return lv <= 0 ? 512 : (lv == 1 ? 1024 : 2048); }

static inline uint32_t hsh(uint32_t x){ x ^= x >> 16; x *= 0x7feb352dU; x ^= x >> 15; x *= 0x846ca68bU; x ^= x >> 16; return x; }
static inline float hf(uint32_t x){ return (hsh(x) >> 8) / 16777216.f; }
static inline float sm(float a, float b, float x){ float t = std::min(1.f, std::max(0.f, (x - a) / (b - a))); return t * t * (3.f - 2.f * t); }

// tileable value noise at (u,v) in [0,1) with `cells` lattice cells across the tile
static float vn(int cells, uint32_t seed, float u, float v){
    float fx = u * cells, fy = v * cells; int ix = (int)std::floor(fx), iy = (int)std::floor(fy); fx -= ix; fy -= iy;
    fx = fx * fx * (3.f - 2.f * fx); fy = fy * fy * (3.f - 2.f * fy);
    const int x0 = ((ix % cells) + cells) % cells, y0 = ((iy % cells) + cells) % cells, x1 = (x0 + 1) % cells, y1 = (y0 + 1) % cells;
    auto L = [&](int i, int j){ return hf((uint32_t)(i + j * 977) * 2654435761u + seed); };
    const float a = L(x0, y0), b = L(x1, y0), c = L(x0, y1), d = L(x1, y1);
    return (a + (b - a) * fx) * (1.f - fy) + (c + (d - c) * fx) * fy;
}

static std::vector<uint8_t> build(int S){
    const size_t N = (size_t)S * S;
    std::vector<float> H(N, 0.f);
    // ---- fine multi-octave grain: lattice 16 .. S/4 cells, finer octaves weigh more (stone chips, not clouds) ----
    float wsum = 0.f; int k = 0;
    for (int cells = 16; cells <= S / 4; cells *= 2, k++){
        const float amp = 1.f + 0.35f * k; wsum += amp;
        std::vector<float> lat((size_t)cells * cells);
        for (int j = 0; j < cells; j++) for (int i = 0; i < cells; i++) lat[(size_t)j * cells + i] = hf((uint32_t)(i + j * 977) * 2654435761u + 91u + (uint32_t)k * 40503u);
        const float inv = (float)cells / S;
        for (int y = 0; y < S; y++){
            float fy = (y + 0.5f) * inv; int iy = (int)fy; fy -= iy; fy = fy * fy * (3.f - 2.f * fy); const int y1 = (iy + 1) % cells;
            for (int x = 0; x < S; x++){
                float fx = (x + 0.5f) * inv; int ix = (int)fx; fx -= ix; fx = fx * fx * (3.f - 2.f * fx); const int x1 = (ix + 1) % cells;
                const float a = lat[(size_t)iy * cells + ix], b = lat[(size_t)iy * cells + x1], c = lat[(size_t)y1 * cells + ix], d = lat[(size_t)y1 * cells + x1];
                H[(size_t)y * S + x] += amp * ((a + (b - a) * fx) * (1.f - fy) + (c + (d - c) * fx) * fy);
            }
        }
    }
    for (size_t i = 0; i < N; i++) H[i] /= wsum;

    // ---- hairline cracks: warped Worley cell edges, only in some areas and broken up so they never form a visible grid ----
    const int C = 6; std::vector<float> jx(C * C), jy(C * C);
    for (int j = 0; j < C; j++) for (int i = 0; i < C; i++){ jx[j * C + i] = 0.1f + 0.8f * hf((uint32_t)(i + j * 31) * 2654435761u + 5u); jy[j * C + i] = 0.1f + 0.8f * hf((uint32_t)(i + j * 31) * 2654435761u + 77u); }
    const float wLine = std::max(0.010f, 2.0f * C / S);                // line width in cell units (never thinner than ~2 texels)
    std::vector<float> crack(N, 0.f);
    for (int y = 0; y < S; y++) for (int x = 0; x < S; x++){
        const float u = (x + 0.5f) / S, v = (y + 0.5f) / S;
        const float mask = sm(0.50f, 0.68f, vn(4, 311u, u, v)) * sm(0.30f, 0.50f, vn(32, 733u, u, v));
        if (mask <= 0.f) continue;
        const float px = u * C + (vn(24, 1301u, u, v) - 0.5f) * 0.45f, py = v * C + (vn(24, 1999u, u, v) - 0.5f) * 0.45f;
        const int cx = (int)std::floor(px), cy = (int)std::floor(py); float f1 = 9.f, f2 = 9.f;
        for (int dj = -1; dj <= 1; dj++) for (int di = -1; di <= 1; di++){
            const int ci = cx + di, cj = cy + dj, wi = ((ci % C) + C) % C, wj = ((cj % C) + C) % C;
            const float qx = ci + jx[wj * C + wi] - px, qy = cj + jy[wj * C + wi] - py, d = std::sqrt(qx * qx + qy * qy);
            if (d < f1){ f2 = f1; f1 = d; } else if (d < f2) f2 = d;
        }
        crack[(size_t)y * S + x] = (1.f - sm(0.f, wLine, f2 - f1)) * mask;
    }

    // ---- compose: albedo, height, baked gradient ----
    std::vector<float> Ht(N);
    for (size_t i = 0; i < N; i++){
        const float h = H[i];
        const float stones = sm(0.575f, 0.68f, h), pits = sm(0.425f, 0.32f, h);
        Ht[i] = h + 0.10f * stones - 0.06f * pits - 0.30f * crack[i];
    }
    std::vector<uint8_t> d(N * 4);
    const float gain = 4.0f * S / 1024.f;
    auto at = [&](int x, int y){ return Ht[(size_t)((y + S) % S) * S + ((x + S) % S)]; };
    for (int y = 0; y < S; y++) for (int x = 0; x < S; x++){
        const size_t i = (size_t)y * S + x; const float h = H[i];
        const float stones = sm(0.575f, 0.68f, h), pits = sm(0.425f, 0.32f, h);
        float alb = 0.5f + (h - 0.5f) * 1.5f + 0.12f * stones - 0.10f * pits - 0.35f * crack[i];
        const float gx = (at(x + 1, y) - at(x - 1, y)) * gain, gy = (at(x, y + 1) - at(x, y - 1)) * gain;
        auto q = [](float f){ return (uint8_t)(std::min(1.f, std::max(0.f, f)) * 255.f + 0.5f); };
        d[i * 4] = q(alb); d[i * 4 + 1] = q(crack[i]); d[i * 4 + 2] = q(0.5f + gx); d[i * 4 + 3] = q(0.5f + gy);
    }
    return d;
}
} // namespace AsphaltTex
