// Sunny Drift - ripples that the tyres leave on a puddle (pure C++, no OpenGL).
//  tyre_fx.h adds one ring source per wheel that is rolling through standing water, road_render.h hands the live list to the road shader,
//  which draws the rings as expanding waves in the water normal (the Forza Horizon "wake" look).
#pragma once
#include <cmath>

namespace WaterFx {

struct Rip { float x, z, age, amp; };
static const int MAXR = 24;
static Rip R[MAXR]; static int N = 0;
static float gSplash = 0.f;                      // 0..1: how much water the tyres are throwing right now (drives the water sound)

static void add(float x, float z, float amp){
    if (N >= MAXR){ for (int i = 1; i < N; i++) R[i - 1] = R[i]; N = MAXR - 1; }       // oldest ring goes first
    R[N++] = {x, z, 0.f, amp};
}
static void update(float dt){
    int k = 0; for (int i = 0; i < N; i++){ R[i].age += dt; if (R[i].age <= 1.6f) R[k++] = R[i]; } N = k;      // order kept: R[0] is always the oldest
}
static void reset(){ N = 0; gSplash = 0.f; }

}   // namespace WaterFx
