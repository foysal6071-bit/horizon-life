// Horizon Drift - CABLE CAR (aerial tramway) between the summits of the two north-west mountains: two station halls, two steel support towers, two carrier ropes, a docked cabin in each station. Static decoration.
#pragma once
#include <GLES3/gl3.h>
#include <cmath>
#include <vector>
#include <algorithm>
#include "wetland.h"
#include "terrain.h"
#include "village.h"
#include "road.h"
#include "river.h"
#include "fence.h"          // Fence::bounceOff
#include "car_core.h"

namespace CableCar {
struct V3 { double x, y, z; };
static std::vector<float> gV; static std::vector<uint32_t> gI; static GLuint gProg = 0, gVao = 0, gVbo = 0, gIbo = 0; static GLint uVP = -1, uCam = -1, uT = -1; static bool gOk = false;
static GLsizei gCount = 0; static V3 gA, gB; static double gDx = 0, gDz = 1;                                   // station centres (ground y), unit direction valley -> summit

static uint32_t vt(double x, double y, double z, double nx, double ny, double nz, float r, float g, float b){
    const uint32_t i = (uint32_t)(gV.size() / 10); const float a[10] = {(float)x, (float)y, (float)z, (float)nx, (float)ny, (float)nz, r, g, b, 0.f}; gV.insert(gV.end(), a, a + 10); return i; }
static void quad(V3 a, V3 b, V3 c, V3 d, float r, float g, float bl){                 // a,b,c,d counter-clockwise; flat normal
    const double ux = b.x - a.x, uy = b.y - a.y, uz = b.z - a.z, wx = d.x - a.x, wy = d.y - a.y, wz = d.z - a.z; double nx = uy * wz - uz * wy, ny = uz * wx - ux * wz, nz = ux * wy - uy * wx; const double l = std::sqrt(nx*nx + ny*ny + nz*nz) + 1e-12; nx /= l; ny /= l; nz /= l;
    const uint32_t A = vt(a.x, a.y, a.z, nx, ny, nz, r, g, bl), B = vt(b.x, b.y, b.z, nx, ny, nz, r, g, bl), C = vt(c.x, c.y, c.z, nx, ny, nz, r, g, bl), D = vt(d.x, d.y, d.z, nx, ny, nz, r, g, bl); gI.insert(gI.end(), {A, B, C, A, C, D}); }
static void tri(V3 a, V3 b, V3 c, float r, float g, float bl){                       // a,b,c counter-clockwise; flat normal
    const double ux = b.x - a.x, uy = b.y - a.y, uz = b.z - a.z, wx = c.x - a.x, wy = c.y - a.y, wz = c.z - a.z; double nx = uy * wz - uz * wy, ny = uz * wx - ux * wz, nz = ux * wy - uy * wx; const double l = std::sqrt(nx*nx + ny*ny + nz*nz) + 1e-12; nx /= l; ny /= l; nz /= l;
    const uint32_t A = vt(a.x, a.y, a.z, nx, ny, nz, r, g, bl), B = vt(b.x, b.y, b.z, nx, ny, nz, r, g, bl), C = vt(c.x, c.y, c.z, nx, ny, nz, r, g, bl); gI.insert(gI.end(), {A, B, C}); }
// local frame of a station: u along the line (towards the OTHER station = the rope exit side), v across, y up
struct Fr { double ox, oz, dx, dz; };
static V3 W(const Fr& f, double u, double v, double y){ return {f.ox + f.dx * u - f.dz * v, y, f.oz + f.dz * u + f.dx * v}; }
static void box(const Fr& f, double u0, double u1, double v0, double v1, double y0, double y1, float r, float g, float b){
    V3 p[8] = {W(f,u0,v0,y0), W(f,u1,v0,y0), W(f,u1,v1,y0), W(f,u0,v1,y0), W(f,u0,v0,y1), W(f,u1,v0,y1), W(f,u1,v1,y1), W(f,u0,v1,y1)};
    quad(p[4], p[5], p[6], p[7], r, g, b); quad(p[0], p[3], p[2], p[1], r*0.5f, g*0.5f, b*0.5f);
    quad(p[0], p[1], p[5], p[4], r*0.9f, g*0.9f, b*0.9f); quad(p[1], p[2], p[6], p[5], r*0.8f, g*0.8f, b*0.8f); quad(p[2], p[3], p[7], p[6], r*0.9f, g*0.9f, b*0.9f); quad(p[3], p[0], p[4], p[7], r*0.8f, g*0.8f, b*0.8f);
}
static void tube(V3 a, V3 b, double rad, int n, float r, float g, float bl){                 // thin prism between two points (ropes, legs, wheel axles)
    double dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z; const double L = std::sqrt(dx*dx + dy*dy + dz*dz); if (L < 1e-6) return; dx /= L; dy /= L; dz /= L;
    double px = -dz, py = 0, pz = dx; double pl = std::sqrt(px*px + pz*pz); if (pl < 1e-6){ px = 1; pz = 0; pl = 1; } px /= pl; pz /= pl; const double qx = dy * pz - dz * py, qy = dz * px - dx * pz, qz = dx * py - dy * px;
    std::vector<uint32_t> ia, ib;
    for (int i = 0; i < n; i++){ const double t = i * 6.2831853 / n, c = std::cos(t), s = std::sin(t), nx = px * c + qx * s, ny = py * c + qy * s, nz = pz * c + qz * s; const float k = 0.75f + 0.25f * (float)ny;
        ia.push_back(vt(a.x + nx * rad, a.y + ny * rad, a.z + nz * rad, nx, ny, nz, r * k, g * k, bl * k)); ib.push_back(vt(b.x + nx * rad, b.y + ny * rad, b.z + nz * rad, nx, ny, nz, r * k, g * k, bl * k)); }
    for (int i = 0; i < n; i++){ const int j = (i + 1) % n; gI.insert(gI.end(), {ia[i], ib[i], ia[j], ia[j], ib[i], ib[j]}); }
}
// ---------------------------------------------------------------------------------------------------------------------
//  LAYOUT: an aerial tramway (reversible "Pendelbahn") between the summits of the two north-west mountains (Terrain::HILLS).
//  Both stations stand on the levelled summit pads (Terrain::hillPadY), the hall opens towards the other mountain, a steel
//  support tower in front of every station lifts the two carrier ropes clear of the shoulder, and one long span crosses the valley.
// ---------------------------------------------------------------------------------------------------------------------
static const double HL = 9.5, HW = 5.6;                   // station hall: half length (u) / half width (v)
static const double TOWER_D = 19.0, TOWER_H = 12.0;       // support tower: distance in front of the hall's front wall, height above the pad
static const double ROPE_H = 5.1, ROPE_V = 1.8;           // carrier rope height above the platform floor, and half the distance between the two ropes
static const double APR_U0 = -17.0, APR_U1 = 14.0, APR_V = 8.5;   // concrete apron round the hall
static const double ANNEX = 6.0;                          // machine room behind the hall
static double gTow[2][2] = {{0, 0}, {0, 0}};              // tower positions (x, z): [0] at station A, [1] at station B
struct CBox { double ox, oz, dx, dz, u0, u1, v0, v1; };
static std::vector<CBox> gCB; static bool gPlanned = false;

static void cabin(const Fr& f, double uc, double F){      // the docked cabin: red + white body, window band, roof plate, hangers up to the carriages on the ropes
    const double L = 2.5, Wd = 1.7, y0 = F + 0.45, y1 = F + 3.0, ry = F + ROPE_H;
    box(f, uc - L, uc + L, -Wd, Wd, y0, y1, 0.74f, 0.09f, 0.09f);
    box(f, uc - L - 0.02, uc + L + 0.02, -Wd - 0.02, Wd + 0.02, y0, y0 + 0.50, 0.90f, 0.90f, 0.91f);                                   // white skirt
    for (int s : {-1, 1}){ const double a = s > 0 ? Wd - 0.01 : -Wd - 0.04, b = s > 0 ? Wd + 0.04 : -Wd + 0.01;
        box(f, uc - L + 0.35, uc + L - 0.35, a, b, y0 + 0.85, y1 - 0.40, 0.08f, 0.12f, 0.17f);                                         // side windows
        for (int k = -1; k <= 1; k++) box(f, uc + k * 1.55 - 0.05, uc + k * 1.55 + 0.05, a - (s > 0 ? 0.0 : 0.01), b + (s > 0 ? 0.01 : 0.0), y0 + 0.85, y1 - 0.40, 0.80f, 0.80f, 0.82f); }   // window posts
    for (int e : {-1, 1}) box(f, e > 0 ? uc + L - 0.01 : uc - L - 0.04, e > 0 ? uc + L + 0.04 : uc - L + 0.01, -Wd + 0.30, Wd - 0.30, y0 + 0.85, y1 - 0.40, 0.08f, 0.12f, 0.17f);   // end windows
    box(f, uc - L - 0.15, uc + L + 0.15, -Wd - 0.15, Wd + 0.15, y1, y1 + 0.18, 0.84f, 0.84f, 0.86f);                                   // roof plate
    for (int e : {-1, 1}){ const double ue = uc + e * 1.6;
        box(f, ue - 0.10, ue + 0.10, -ROPE_V, ROPE_V, y1 + 0.55, y1 + 0.70, 0.30f, 0.31f, 0.33f);                                      // cross bar
        for (int s : {-1, 1}){
            box(f, ue - 0.55, ue + 0.55, s * ROPE_V - 0.22, s * ROPE_V + 0.22, ry - 0.30, ry + 0.22, 0.20f, 0.21f, 0.23f);              // carriage (runs on the rope)
            tube(W(f, ue, s * ROPE_V, ry - 0.30), W(f, ue, s * 1.0, y1 + 0.18), 0.06, 6, 0.55f, 0.56f, 0.58f); } }                      // hanger
}
static void station(const V3& c, double dx, double dz){
    const Fr f = {c.x, c.z, dx, dz}; const double F = c.y;
    const float cr = 0.62f, cg = 0.60f, cb = 0.57f;                                                                              // concrete
    // apron + low parapet round it
    box(f, APR_U0, APR_U1, -APR_V, APR_V, F - 0.7, F + 0.04, 0.56f, 0.55f, 0.53f);
    for (int s : {-1, 1}) box(f, APR_U0, APR_U1, s > 0 ? APR_V - 0.25 : -APR_V, s > 0 ? APR_V : -APR_V + 0.25, F, F + 0.45, 0.50f, 0.49f, 0.47f);
    box(f, APR_U0, APR_U0 + 0.25, -APR_V, APR_V, F, F + 0.45, 0.50f, 0.49f, 0.47f);
    for (int s : {-1, 1}){ const double v = s * (APR_V - 0.12);                                                                  // steel handrail on the parapet, open in front
        for (double u = APR_U0 + 0.5; u < APR_U1 - 0.1; u += 3.0) tube(W(f, u, v, F + 0.45), W(f, u, v, F + 1.15), 0.035, 4, 0.25f, 0.27f, 0.30f);
        tube(W(f, APR_U0 + 0.5, v, F + 1.15), W(f, APR_U1 - 0.5, v, F + 1.15), 0.03, 4, 0.25f, 0.27f, 0.30f); }
    // machine room behind the hall (drive + bull wheel), flat roof, door, vent
    box(f, -HL - ANNEX, -HL, -HW + 0.9, HW - 0.9, F, F + 4.6, cr, cg, cb);
    box(f, -HL - ANNEX - 0.3, -HL + 0.3, -HW + 0.6, HW - 0.6, F + 4.6, F + 4.95, 0.24f, 0.25f, 0.27f);
    box(f, -HL - ANNEX - 0.04, -HL - ANNEX + 0.01, -0.95, 0.95, F, F + 2.3, 0.10f, 0.12f, 0.15f);                                 // service door
    box(f, -HL - 3.5, -HL - 1.5, -1.0, 1.0, F + 4.95, F + 6.0, 0.55f, 0.56f, 0.58f);                                              // ventilation housing
    // hall: platform floor, side walls (concrete) with glazing, rear wall, front wall with the rope portal
    box(f, -HL, HL, -HW, HW, F, F + 0.28, 0.46f, 0.45f, 0.44f);
    box(f, -HL + 0.5, HL - 0.2, -HW + 0.55, -HW + 0.95, F + 0.28, F + 0.31, 0.90f, 0.78f, 0.12f);                                 // yellow safety line on the platform
    box(f, -HL + 0.5, HL - 0.2, HW - 0.95, HW - 0.55, F + 0.28, F + 0.31, 0.90f, 0.78f, 0.12f);
    const double RB = F + 6.6;                                                                                                   // eaves height
    for (int s : {-1, 1}){ const double a = s > 0 ? HW - 0.5 : -HW, b = s > 0 ? HW : -HW + 0.5;
        box(f, -HL, HL, a, b, F + 0.28, RB, cr, cg, cb);
        const double ga = s > 0 ? HW - 0.01 : -HW - 0.06, gb = s > 0 ? HW + 0.06 : -HW + 0.01;
        box(f, -HL + 1.4, HL - 1.4, ga, gb, F + 1.5, F + 4.7, 0.08f, 0.12f, 0.17f);                                              // glazing band
        for (int k = -3; k <= 3; k++) box(f, k * 2.4 - 0.09, k * 2.4 + 0.09, ga - (s > 0 ? 0.0 : 0.02), gb + (s > 0 ? 0.02 : 0.0), F + 1.5, F + 4.7, 0.70f, 0.70f, 0.72f);   // mullions
        box(f, -HL, HL, ga, gb, F + 4.8, RB, 0.40f, 0.26f, 0.14f); }                                                             // timber cladding under the eaves
    box(f, -HL - 0.5, -HL, -HW, HW, F + 0.28, RB, cr, cg, cb);                                                                   // rear wall
    for (int s : {-1, 1}){ const double a = s > 0 ? 2.9 : -HW, b = s > 0 ? HW : -2.9; box(f, HL - 0.5, HL, a, b, F + 0.28, RB, cr, cg, cb); }   // front pillars either side of the portal (opening 5.8 m wide, 5.9 m high)
    box(f, HL - 0.5, HL, -2.9, 2.9, F + 5.9, RB, cr, cg, cb);                                                                    // lintel
    for (int s : {-1, 1}) box(f, HL - 0.05, HL + 0.12, s * 2.9 - (s > 0 ? 0.0 : 0.2), s * 2.9 + (s > 0 ? 0.2 : 0.0), F + 0.28, F + 5.9, 0.28f, 0.30f, 0.33f);   // steel portal frame
    box(f, HL - 0.05, HL + 0.12, -2.9, 2.9, F + 5.9, F + 6.1, 0.28f, 0.30f, 0.33f);
    // name board over the portal
    box(f, HL + 0.10, HL + 0.40, -2.6, 2.6, F + 6.85, F + 7.75, 0.72f, 0.10f, 0.10f); box(f, HL + 0.38, HL + 0.44, -2.2, 2.2, F + 7.10, F + 7.50, 0.94f, 0.94f, 0.94f);
    // gable roof, ridge along the line, canopy over the front
    const double ov = 1.3, ovF = 3.2, rh = 2.2, W2 = HW + ov;
    V3 e0 = W(f, -HL - ov, -W2, RB), e1 = W(f, -HL - ov, W2, RB), e2 = W(f, HL + ovF, W2, RB), e3 = W(f, HL + ovF, -W2, RB), r0 = W(f, -HL - ov, 0, RB + rh), r1 = W(f, HL + ovF, 0, RB + rh);
    quad(e1, e2, r1, r0, 0.26f, 0.27f, 0.29f); quad(e3, e0, r0, r1, 0.22f, 0.23f, 0.25f);
    tri(e2, e3, r1, 0.30f, 0.22f, 0.14f);                                                                                        // front gable
    tri(e0, e1, r0, 0.30f, 0.22f, 0.14f);                                                                                        // rear gable
    box(f, -HL - ov - 0.05, HL + ovF + 0.05, -0.12, 0.12, RB + rh - 0.02, RB + rh + 0.12, 0.18f, 0.19f, 0.20f);                  // ridge cap
    // docked cabin
    cabin(f, HL - 4.3, F);
}
static void pylon(const V3& g, double H){
    const Fr f = {g.x, g.z, gDx, gDz}; const double b = 2.0, t = 0.55; const double y0 = g.y - 0.8, y1 = g.y + H;
    for (int sx : {-1, 1}) for (int sz : {-1, 1}) tube(W(f, sx * b, sz * b, y0), W(f, sx * t, sz * t, y1), 0.13, 5, 0.62f, 0.64f, 0.66f);
    for (int k = 1; k <= 4; k++){ const double y = g.y + H * k / 5.0, w = b + (t - b) * (y - y0) / (y1 - y0); for (int s : {-1, 1}){ tube(W(f, -w, s * w, y), W(f, w, s * w, y), 0.05, 4, 0.58f, 0.60f, 0.62f); tube(W(f, s * w, -w, y), W(f, s * w, w, y), 0.05, 4, 0.58f, 0.60f, 0.62f); } }
    for (int k = 0; k < 4; k++){ const double ya = g.y + H * k / 5.0, yb = g.y + H * (k + 1) / 5.0, wa = b + (t - b) * (ya - y0) / (y1 - y0), wb = b + (t - b) * (yb - y0) / (y1 - y0); tube(W(f, -wa, -wa, ya), W(f, wb, -wb, yb), 0.035, 4, 0.56f, 0.58f, 0.60f); tube(W(f, wa, wa, ya), W(f, -wb, wb, yb), 0.035, 4, 0.56f, 0.58f, 0.60f); }   // diagonal bracing
    box(f, -0.7, 0.7, -3.2, 3.2, y1, y1 + 0.35, 0.9f, 0.35f, 0.08f);                                                  // cross-arm, safety orange
    for (int s : {-1, 1}) box(f, -0.45, 0.45, s * ROPE_V - 0.3, s * ROPE_V + 0.3, y1 - 0.4, y1, 0.25f, 0.26f, 0.28f);     // sheave housings
    box(f, -2.6, 2.6, -2.6, 2.6, g.y - 1.0, g.y + 0.4, 0.55f, 0.54f, 0.52f);                                         // concrete footing
}
static void rope(const std::vector<V3>& pts){ for (size_t i = 0; i + 1 < pts.size(); i++) tube(pts[i], pts[i + 1], 0.06, 5, 0.18f, 0.18f, 0.19f); }
static void plan(){
    if (gPlanned) return; gPlanned = true;
    const Terrain::HillT& hS = Terrain::HILLS[1]; const Terrain::HillT& hN = Terrain::HILLS[0];                      // south mountain = station A, north mountain = station B
    gA = {hS.x, Terrain::fieldH(hS.x, hS.z), hS.z}; gB = {hN.x, Terrain::fieldH(hN.x, hN.z), hN.z};
    gDx = gB.x - gA.x; gDz = gB.z - gA.z; const double L = std::hypot(gDx, gDz); gDx /= L; gDz /= L;
    gCB.clear();
    for (int k = 0; k < 2; k++){ const V3& c = k ? gB : gA; const double dx = k ? -gDx : gDx, dz = k ? -gDz : gDz;
        gCB.push_back({c.x, c.z, dx, dz, -HL - ANNEX - 0.2, HL + 0.2, -HW - 0.2, HW + 0.2});                       // hall + machine room
        const Fr f = {c.x, c.z, dx, dz}; const V3 tw = W(f, HL + TOWER_D, 0, 0); gTow[k][0] = tw.x; gTow[k][1] = tw.z;
        gCB.push_back({tw.x, tw.z, gDx, gDz, -2.6, 2.6, -2.6, 2.6}); }                                           // support tower footing
}
static bool blocked(double x, double z, double margin){        // inside a station apron / tower footing (no flowers or grass there)
    if (!gPlanned) return false;
    for (int k = 0; k < 2; k++){ const V3& c = k ? gB : gA; const double dx = k ? -gDx : gDx, dz = k ? -gDz : gDz, ex = x - c.x, ez = z - c.z;
        if (ex*ex + ez*ez > 60.0*60.0) continue;
        const double u = dx * ex + dz * ez, v = -dz * ex + dx * ez;
        if (u > APR_U0 - margin && u < APR_U1 + margin && std::fabs(v) < APR_V + margin) return true;
        const double tx = x - gTow[k][0], tz = z - gTow[k][1]; if (tx*tx + tz*tz < (4.0 + margin) * (4.0 + margin)) return true; }
    return false;
}
// the car body (3 circles) cannot drive through the station halls or the towers
static void collide(CarState& S){
    if (!gPlanned) return;
    const double sH = std::sin(S.heading), cH = std::cos(S.heading), R = 1.05; static const double OFS[3] = {-1.5, 0.0, 1.5};
    for (const CBox& B : gCB){
        const double ex = B.ox - S.x, ez = B.oz - S.z; if (ex*ex + ez*ez > 80.0 * 80.0) continue;
        for (double o : OFS){
            const double px = S.x + sH * o - B.ox, pz = S.z + cH * o - B.oz, u = B.dx * px + B.dz * pz, v = -B.dz * px + B.dx * pz;
            const double cu = std::max(B.u0, std::min(B.u1, u)), cv = std::max(B.v0, std::min(B.v1, v)), vu = u - cu, vv = v - cv, d = std::sqrt(vu*vu + vv*vv);
            double nu, nv, pen;
            if (d > 1e-6){ if (d >= R) continue; nu = vu / d; nv = vv / d; pen = R - d; }
            else { const double e[4] = {B.u1 - u, u - B.u0, B.v1 - v, v - B.v0}; int k = 0; for (int j = 1; j < 4; j++) if (e[j] < e[k]) k = j;
                nu = (k == 0) ? 1.0 : (k == 1 ? -1.0 : 0.0); nv = (k == 2) ? 1.0 : (k == 3 ? -1.0 : 0.0); pen = e[k] + R; }
            const double wx = B.dx * nu - B.dz * nv, wz = B.dz * nu + B.dx * nv;
            S.x += wx * pen; S.z += wz * pen;
            Fence::bounceOff(S, wx, wz, 0.22, 0.30);
        }
    }
}
static void build(){
    plan(); std::vector<float>().swap(gV); gI.clear();
    const Fr fA = {gA.x, gA.z, gDx, gDz}, fB = {gB.x, gB.z, -gDx, -gDz};
    station(gA, gDx, gDz); station(gB, -gDx, -gDz);
    const V3 tA = W(fA, HL + TOWER_D, 0, 0), tB = W(fB, HL + TOWER_D, 0, 0);
    const double gyA = Terrain::fieldH(tA.x, tA.z), gyB = Terrain::fieldH(tB.x, tB.z), yTA = gyA + TOWER_H, yTB = gyB + TOWER_H;
    pylon({tA.x, gyA, tA.z}, TOWER_H); pylon({tB.x, gyB, tB.z}, TOWER_H);
    for (int s : {-1, 1}){                                                                                              // two parallel carrier ropes
        const double v = s * ROPE_V;
        const V3 p0 = W(fA, -HL + 1.0, v, gA.y + ROPE_H), p1 = W(fA, HL, v, gA.y + ROPE_H), p2 = W(fA, HL + TOWER_D, v, yTA);
        const V3 p3 = W(fB, HL + TOWER_D, -v, yTB), p4 = W(fB, HL, -v, gB.y + ROPE_H), p5 = W(fB, -HL + 1.0, -v, gB.y + ROPE_H);
        std::vector<V3> pts = {p0, p1, p2};
        const double span = std::hypot(p3.x - p2.x, p3.z - p2.z), sag = span * 0.022; const int n = std::max(12, (int)(span / 10));      // one long span, hanging in a catenary
        for (int k = 1; k < n; k++){ const double t = (double)k / n; pts.push_back({p2.x + (p3.x - p2.x) * t, p2.y + (p3.y - p2.y) * t - 4.0 * sag * t * (1 - t), p2.z + (p3.z - p2.z) * t}); }
        pts.push_back(p3); pts.push_back(p4); pts.push_back(p5);
        rope(pts); }
}
static void init(){
    if (gOk) return; build(); if (gI.empty()) return;
    gProg = glCreateProgram(); glAttachShader(gProg, Wetland::sh(GL_VERTEX_SHADER, Wetland::VS)); glAttachShader(gProg, Wetland::sh(GL_FRAGMENT_SHADER, Wetland::FS)); glLinkProgram(gProg); SunLight::attach(gProg);
    uVP = glGetUniformLocation(gProg, "uVP"); uCam = glGetUniformLocation(gProg, "uCam"); uT = glGetUniformLocation(gProg, "uT");
    glGenVertexArrays(1, &gVao); glBindVertexArray(gVao); glGenBuffers(1, &gVbo); glBindBuffer(GL_ARRAY_BUFFER, gVbo); glBufferData(GL_ARRAY_BUFFER, gV.size() * 4, gV.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 40, (void*)0); glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 40, (void*)12);
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 40, (void*)24); glEnableVertexAttribArray(3); glVertexAttribPointer(3, 1, GL_FLOAT, GL_FALSE, 40, (void*)36);
    glGenBuffers(1, &gIbo); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gIbo); glBufferData(GL_ELEMENT_ARRAY_BUFFER, gI.size() * 4, gI.data(), GL_STATIC_DRAW); glBindVertexArray(0);
    gCount = (GLsizei)gI.size(); std::vector<float>().swap(gV); std::vector<uint32_t>().swap(gI); gOk = true;
}
static void draw(const float* VP, const float* eye, float time){
    if (!gOk) return; const double mx = (gA.x + gB.x) * 0.5 - eye[0], mz = (gA.z + gB.z) * 0.5 - eye[2]; if (mx*mx + mz*mz > 1800.0*1800.0) return;
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glDisable(GL_BLEND); glUseProgram(gProg); glUniformMatrix4fv(uVP, 1, GL_FALSE, VP); glUniform3fv(uCam, 1, eye); glUniform1f(uT, time);
    glBindVertexArray(gVao); glDrawElements(GL_TRIANGLES, gCount, GL_UNSIGNED_INT, (void*)0); glBindVertexArray(0);
}
}
