#pragma once
// Sunny Drift - the HTML sky, ported 1:1: "Sky: gradient + sun glow + drifting procedural clouds" (skyMat fragment shader) + the sky part of updateEnv().
//  * 5 "Dramatic Skys" cube faces (sky_0..4.jpg, 576 px) are packed into the same 3x2 atlas the HTML builds on a canvas
//  * baked 360 deg photo mountains (mtn_col.jpg + mtn_data.png, 6144 x 512) sit on the horizon, tinted by the live haze
//  * time of day: the HTML game is frozen at tod = 175 s (1 PM). The app's day / night button slides tod from 175 s to deep night (sun sets, moon + stars + milky way)
//  * the dome is a full-screen triangle drawn LAST at depth 1 (only where nothing else was drawn), so the night overlay does not darken it twice
#include <GLES3/gl3.h>
#include <cmath>
#include <cstring>
#include <cstdint>
#include <vector>
#include <algorithm>

namespace SkyGL {

// ---------------- images handed over from Java (BitmapFactory): 0..4 = faces, 5 = mountain colour, 6 = mountain data ----------------
struct Pic { int w = 0, h = 0; std::vector<uint8_t> px; };           // RGBA8, first row = top
static Pic gPic[7];
static void setImage(int id, int w, int h, const uint8_t* rgba){ if (id < 0 || id > 6) return; gPic[id].w = w; gPic[id].h = h; gPic[id].px.assign(rgba, rgba + (size_t)w * h * 4); }

// ---------------- the HTML sky fragment shader (OCT = 4) ----------------
static const char* VS = R"GLSL(#version 300 es
uniform vec3 uF, uR, uU; uniform vec2 uT; out vec3 vD;
void main(){
  vec2 p = vec2((gl_VertexID == 1) ? 3.0 : -1.0, (gl_VertexID == 2) ? 3.0 : -1.0);
  vD = uF + uR * (p.x * uT.x) + uU * (p.y * uT.y);
  gl_Position = vec4(p, 1.0, 1.0);
}
)GLSL";
static const char* FS = R"GLSL(#version 300 es
precision highp float;
#define OCT 4
in vec3 vD; out vec4 outC;
uniform float uTime,uNight,uTw,uRain,uCubeAmt,uInset,uMtnAmt,uQ; uniform vec3 uSun,uMoon,uHor,uMid,uZen,uCl,uCs,uCubeTint; uniform sampler2D uCubeTex,uMtnTex,uMtnData;
float hash(vec2 p){ p=fract(p*vec2(123.34,456.21)); p+=dot(p,p+45.32); return fract(p.x*p.y); }
float noise(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.-2.*f);
  return mix(mix(hash(i),hash(i+vec2(1.,0.)),f.x), mix(hash(i+vec2(0.,1.)),hash(i+vec2(1.,1.)),f.x), f.y); }
float fbm(vec2 p){ float a=.5, s=0.; for(int i=0;i<OCT;i++){ s+=a*noise(p); p=p*2.03+vec2(17.1,9.7); a*=.5; } return s; }
float h31(vec3 p){ p=fract(p*.1031); p+=dot(p,p.yzx+33.33); return fract((p.x+p.y)*p.z); }
vec3 skyTex(vec3 d){
  vec3 a = abs(d); vec2 uv; float f;
  if (a.y > a.x && a.y > a.z){ uv = vec2(d.x, d.z)/a.y; f = 4.; }
  else if (a.z >= a.x){ if (d.z < 0.){ uv = vec2(d.x, d.y)/a.z; f = 0.; } else { uv = vec2(-d.x, d.y)/a.z; f = 2.; } }
  else { if (d.x > 0.){ uv = vec2(d.z, d.y)/a.x; f = 1.; } else { uv = vec2(-d.z, d.y)/a.x; f = 3.; } }
  uv = clamp(uv*.5+.5, vec2(uInset), vec2(1.-uInset));
  float c = mod(f,3.), r = floor(f/3.);
  return texture(uCubeTex, vec2((c+uv.x)/3., (1.-r+uv.y)/2.)).rgb;
}
vec3 star(vec3 d,float S,float dens,float r){
  vec3 g=d*S, id=floor(g), f=fract(g);
  float e=h31(id+3.3); if(e>dens) return vec3(0.);
  vec3 rp=.2+.6*vec3(h31(id),h31(id+19.19),h31(id+47.7));
  float dd=length(f-rp), b=exp(-dd*dd/(r*r));
  float tw=.78+.22*sin(uTime*(1.5+e*20./dens)+e*90.);
  return b*tw*(.3+.7*h31(id+8.1))*mix(vec3(.7,.82,1.),vec3(1.,.86,.68),h31(id+5.5));
}
void main(){
  vec3 d = normalize(vD); float h = d.y;
  vec3 col = mix(uHor, uMid, smoothstep(0.,.28,h));
  col = mix(col, uZen, smoothstep(.25,.95,h));
  if (h < 0.) col = mix(uHor, uHor*.7, pow(-h,.5));
  if (uCubeAmt > .001){
    float cr = uTime*.0025, cs = sin(cr), cc = cos(cr);
    vec3 dr = normalize(vec3(cc*d.x - cs*d.z, max(d.y,0.), cs*d.x + cc*d.z));
    vec3 sc = skyTex(dr);
    float lm = dot(sc, vec3(.299,.587,.114));
    sc = pow(max(sc,vec3(0.)), vec3(.72)); sc = mix(vec3(lm), sc, 1.0-.5*uRain) * uCubeTint;
    sc = mix(sc, uHor, (1.-smoothstep(0.,.14,h))*.35);
    col = mix(col, sc, uCubeAmt*mix(.55,1.,uNight)*smoothstep(-.03,.0,h));
  }
  float sd = max(dot(d,uSun),0.); float sv = smoothstep(-.12,.04,uSun.y);
  col = mix(col, uHor*vec3(1.02,1.02,1.0), exp(-max(h,0.)*11.)*.30*step(0.,h));       // thicker, brighter air near the horizon (aerial perspective)
  // ---- sun + atmosphere: colour of the sun depends on its height (white at noon -> gold -> orange-red at the horizon) ----
  float lowS = 1.0 - smoothstep(.08, .5, uSun.y);
  vec3 sunC = mix(vec3(1.,.97,.90), vec3(1.,.66,.36), lowS); sunC = mix(sunC, vec3(1.,.50,.22), uTw*.6);
  col *= 1.0 - .08*(1.0 - sd)*smoothstep(.10, .70, h)*(1.0 - uNight);                    // sky opposite the sun is a little deeper blue (Rayleigh)
  col += mix(vec3(1.,.90,.72), sunC, .5)*pow(sd,2.2)*.075*sv*(1.-uNight);                // wide forward-scattering haze round the sun
  col += (sunC*pow(sd,6.)*.20 + sunC*pow(sd,48.)*.42 + vec3(1.,.97,.90)*pow(sd,300.)*.55)*sv;   // aureole + inner glare
  col += vec3(1.,.4,.12)*pow(sd,3.)*uTw*.55*(1.-smoothstep(0.,.5,h));
  col += sunC*exp(-max(h,0.)*7.)*pow(sd,2.)*.10*lowS*sv*(1.-uNight)*step(0.,h);          // warm glow along the horizon under a low sun
  {   // the sun itself: a small bright disc with a darker limb and a soft edge
    float rr = (1.0 - sd)/.00018; float mu = sqrt(clamp(1.0 - rr, 0.0, 1.0));
    col += sunC*(.55 + .45*mu)*smoothstep(.99982, .99990, sd)*3.0*sv;
  }
  if (uNight > .01 && h > -.02){
    float vis = uNight*smoothstep(-.02,.18,h);
    float md = dot(d,uMoon);
    vec3 mwN = normalize(vec3(.35,.75,-.55)), mA = normalize(cross(mwN,vec3(0.,1.,0.))), mB = cross(mwN,mA);
    float dn = dot(d,mwN), band = exp(-dn*dn/.03), mw = 0.;
    if (band > .02 && uQ > .5){ vec2 mp = vec2(dot(d,mA),dot(d,mB))*4.;
      mw = band*(.4+.9*fbm(mp))*(.6+.6*fbm(mp*3.1+7.))*(1.-.5*smoothstep(.5,.8,fbm(mp*2.+3.))); }
    vec3 st = star(d,26.,.09,.2)*1.7 + star(d,55.,.35,.16) + (uQ > .5 ? star(d,115.,.4+.35*band,.2)*.7 : vec3(0.));
    float wash = 1.-clamp(pow(max(md,0.),6.)*1.4,0.,1.);
    col += (st + vec3(.5,.58,.85)*mw*.2)*wash*vis;
    col += vec3(.5,.62,.95)*(pow(max(md,0.),70.)*.4 + pow(max(md,0.),7.)*.08)*uNight;
    float MR = .034;
    if (md > cos(MR)){
      vec3 r = normalize(cross(vec3(0.,1.,0.),uMoon)); vec3 u = cross(uMoon,r);
      vec2 q = vec2(dot(d,r),dot(d,u))/sin(MR); float q2 = dot(q,q);
      if (q2 < 1.){
        vec3 n = vec3(q,sqrt(1.-q2)); vec3 L = normalize(vec3(.75,.25,.6));
        float lit = smoothstep(-.05,.12,dot(n,L));
        vec3 alb = vec3(.88,.86,.80)*(.62+.5*fbm(q*2.6+5.))*(.85+.3*fbm(q*9.+1.));
        alb *= mix(1.,.55,smoothstep(.55,.7,fbm(q*2.+11.)));
        col = mix(col, alb*(lit+.05)*1.5, smoothstep(1.,.95,sqrt(q2)));
      }
    }
  }
  if (h > 0.04 && uQ > .5){   // high, thin cirrus: stretched wispy streaks, lit by the sun
    vec2 cu = d.xz/(h + .28)*vec2(.55, 1.9) + vec2(uTime*.006, 0.);
    float ci = smoothstep(.52, .92, fbm(cu*1.4 + vec2(5., 2.)) * (.6 + .7*fbm(cu*3.7))) * smoothstep(.04, .30, h) * .55 * (1. - uRain*.5);
    if (ci > .004){
      vec3 c2 = mix(uCs, uCl, .85); c2 += sunC*pow(sd,6.)*.45*sv*(1.-uNight);
      col = mix(col, c2, ci*(1. - uNight*.7));
    }
  }
  if (h > 0.01){
    vec2 uv = d.xz/(h+.12)*1.4 + vec2(uTime*.012, uTime*.004);
    float n = fbm(uv*.9);
    float c = smoothstep(.60-.35*uRain,.86-.3*uRain,n) * smoothstep(.0,.16,h);
    if (c > .004){
      float lit = fbm(uv*.9 + uSun.xz*.35);
      vec3 cc = mix(uCs, uCl, clamp(1.-(lit-n)*2.4,0.,1.));
      cc += vec3(1.,.85,.6)*pow(sd,8.)*.25*(1.-uNight)*sv;
      cc += vec3(.25,.3,.45)*pow(max(dot(d,uMoon),0.),12.)*uNight*.5;
      float edge = 1.-smoothstep(.0,.5,c); cc += mix(vec3(1.,.93,.80), sunC, .6)*edge*pow(sd,6.)*.55*sv*(1.-uNight);   // silver lining on thin cloud edges facing the sun
      cc *= 1.-.18*smoothstep(.45,1.,n)*(1.-sv*.4);                                                      // dense cores a little darker (cloud depth)
      col = mix(col, cc, c*.92*(1.-.50*uCubeAmt));
    }
  }
  if (uMtnAmt > .001){
    float hz = max(length(d.xz),1e-3); float e = d.y/hz;
    float v = (e+.05)/.37;
    if (v > 0. && v < 1.){
      vec2 muv = vec2(atan(d.z,d.x)/6.2831853+.5, v);
      vec3 mc = texture(uMtnTex, muv).rgb; vec2 md = texture(uMtnData, muv).rg;
      float light = clamp(dot(uHor,vec3(.299,.587,.114))*1.35,.05,1.);
      mc = mix(vec3(dot(mc,vec3(.299,.587,.114))), mc, 1.5) * vec3(.92,1.14,.72);   // greener, more saturated hills
      mc *= light * mix(vec3(1.), vec3(1.25,.88,.66), uTw*.7);
      float haze = clamp(md.g + uRain*.5 + (1.-smoothstep(-.02,.014,e))*.8, 0., .97);
      mc = mix(mc, uHor, haze);
      mc = mix(mc, uHor*vec3(.80,.92,1.08), (1.-smoothstep(.0,.60,v))*.40*(1.-uNight));      // distant-range haze: bluish veil over the foothills
      mc += vec3(1.,.55,.25)*pow(sd,4.)*uTw*.25*(1.-haze*.4);
      col = mix(col, mc, md.r*uMtnAmt*smoothstep(-.05,-.03,e));
    }
  }
  col = mix(vec3(dot(col,vec3(.299,.587,.114))), col, 1.04);                       // a touch more natural saturation
  outC = vec4(col + (hash(gl_FragCoord.xy) - .5)/255., 1.);                         // dither: no colour banding in the smooth sky gradient
}
)GLSL";

// ---------------- environment (HTML updateEnv, rain = 0, no lightning) ----------------
struct Env {
    float sun[3], moon[3], hor[3], mid[3], zen[3], cl[3], cs[3], tint[3], fog[3]; float night, tw, day;
};
static float ss(float a, float b, float x){ x = std::min(1.f, std::max(0.f, (x - a) / (b - a))); return x * x * (3 - 2 * x); }
static void mixA(const float* a, const float* b, float t, float* o){ for (int i = 0; i < 3; i++) o[i] = a[i] + (b[i] - a[i]) * t; }
static void normalize3(float* v){ float l = std::sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]); if (l > 0) for (int i = 0; i < 3; i++) v[i] /= l; }
static void envAt(float tod, Env& E){
    tod = std::fmod(std::fmod(tod, 480.f) + 480.f, 480.f);          // one full day = 300 s of sun + 180 s of night
    const float DAY_S = 300, NIGHT_S = 180, PI = 3.14159265f;
    static const float SKY_DAY[3][3] = {{.74f,.88f,.98f},{.34f,.65f,.98f},{.09f,.34f,.88f}}, SKY_DUSK[3][3] = {{1,.52f,.26f},{.62f,.38f,.56f},{.17f,.21f,.47f}}, SKY_NIGHT[3][3] = {{.035f,.05f,.10f},{.012f,.02f,.055f},{.004f,.008f,.025f}};
    const float th = tod < DAY_S ? PI * tod / DAY_S : PI + PI * (tod - DAY_S) / NIGHT_S;
    E.sun[0] = -std::cos(th) * .85f; E.sun[1] = std::sin(th) * .95f; E.sun[2] = .45f; normalize3(E.sun);
    if (tod >= DAY_S){ const float m = PI * (tod - DAY_S) / NIGHT_S; E.moon[0] = -std::cos(m) * .8f; E.moon[1] = std::sin(m) * .62f; E.moon[2] = -.55f; normalize3(E.moon); }
    else { E.moon[0] = 0; E.moon[1] = -1; E.moon[2] = 0; }
    const float e = E.sun[1], dayW = ss(-.10f, .32f, e), tw = std::exp(-std::pow((e - .03f) / .15f, 2.f)) * .9f, night = 1 - ss(-.22f, -.02f, e);
    E.day = dayW; E.tw = tw; E.night = night;
    float* outs[3] = {E.hor, E.mid, E.zen};
    for (int i = 0; i < 3; i++){ float a[3]; mixA(SKY_NIGHT[i], SKY_DAY[i], dayW, a); mixA(a, SKY_DUSK[i], tw, outs[i]); }
    {   // daytime looks: the same blue day sky is pale + misty in the MORNING, deep and clean at NOON, golden in the AFTERNOON
        const float lowK = (1.f - ss(.12f, .55f, e)) * dayW;                    // 1 while the sun is low (but up)
        const float morn = 1.f - ss(-.25f, .25f, E.sun[0]);                     // 1 on the sunrise side, 0 on the sunset side
        const float highK = ss(.55f, .92f, e) * dayW;                           // noon: clear, deep blue
        const float mistC[3] = {.84f, .89f, .93f}, goldC[3] = {1.00f, .80f, .56f}, midMist[3] = {.62f, .78f, .94f}, midGold[3] = {.78f, .74f, .78f};
        float t[3];
        mixA(E.hor, mistC, lowK * morn * .55f, t); memcpy(E.hor, t, 12);       // morning: pale, hazy horizon
        mixA(E.hor, goldC, lowK * (1.f - morn) * .50f, t); memcpy(E.hor, t, 12); // afternoon: golden horizon
        mixA(E.mid, midMist, lowK * morn * .35f, t); memcpy(E.mid, t, 12);
        mixA(E.mid, midGold, lowK * (1.f - morn) * .30f, t); memcpy(E.mid, t, 12);
        for (int k = 0; k < 3; k++){ E.zen[k] *= 1.f - .10f * highK; E.zen[k] *= 1.f + .12f * lowK * morn; }   // noon zenith a little deeper, morning zenith lighter
        { const float dz[3] = {.07f, .27f, .80f}; mixA(E.zen, dz, highK * .35f, t); memcpy(E.zen, t, 12); }
        // cloud colour: bright white at noon, creamy gold in the afternoon, soft pink-white at sunrise
        { const float c1[3] = {1.f, .93f, .82f}, c2[3] = {1.f, .92f, .90f}; float u[3]; mixA(E.cl, c1, lowK * (1.f - morn) * .5f, u); mixA(u, c2, lowK * morn * .4f, E.cl); }
    }
    { const float a0[3] = {.07f,.09f,.16f}, a1[3] = {1,1,1}, a2[3] = {1,.62f,.45f}; float a[3]; mixA(a0, a1, dayW, a); mixA(a, a2, tw, E.cl); }
    { const float a0[3] = {.025f,.035f,.07f}, a1[3] = {.86f,.91f,.97f}, a2[3] = {.45f,.32f,.42f}; float a[3]; mixA(a0, a1, dayW, a); mixA(a, a2, tw, E.cs); }
    { const float a0[3] = {.05f,.065f,.13f}, a1[3] = {1.40f,1.50f,1.68f}, a2[3] = {1.38f,.86f,.62f}; float a[3]; mixA(a0, a1, dayW, a); mixA(a, a2, tw * .8f, E.tint); }
    { const float b[3] = {.70f,.88f,.97f}; float f[3]; mixA(E.hor, b, dayW * (1 - tw), E.fog); (void)f; }   // scene.fog / background colour
}

// ---------------- GL ----------------
static GLuint gProg = 0, gCube = 0, gMtnC = 0, gMtnD = 0;
static GLint uF, uR, uU, uT, uTime, uNight, uTwL, uRain, uCubeAmt, uInset, uMtnAmt, uQ, uSun, uMoon, uHor, uMid, uZen, uCl, uCs, uTint, uCubeTex, uMtnTex, uMtnData;
static float gInset = 0.002f; static bool gHaveCube = false, gHaveMtn = false;

static GLuint compileSh(GLenum t, const char* s){ GLuint sh = glCreateShader(t); glShaderSource(sh, 1, &s, nullptr); glCompileShader(sh); return sh; }
static GLuint upload(const uint8_t* px, int w, int h, bool repeatS){                // rows are flipped so the top image row is at v = 1 (three.js flipY)
    std::vector<uint8_t> f((size_t)w * h * 4);
    for (int y = 0; y < h; y++) memcpy(&f[(size_t)y * w * 4], &px[(size_t)(h - 1 - y) * w * 4], (size_t)w * 4);
    GLuint t; glGenTextures(1, &t); glBindTexture(GL_TEXTURE_2D, t); glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, f.data());
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, repeatS ? GL_REPEAT : GL_CLAMP_TO_EDGE); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    return t;
}
static Pic halve(const Pic& p){ Pic o; o.w = p.w / 2; o.h = p.h / 2; o.px.resize((size_t)o.w * o.h * 4);
    for (int y = 0; y < o.h; y++) for (int x = 0; x < o.w; x++) for (int c = 0; c < 4; c++){
        int s = p.px[((size_t)(2*y) * p.w + 2*x) * 4 + c] + p.px[((size_t)(2*y) * p.w + 2*x + 1) * 4 + c] + p.px[((size_t)(2*y + 1) * p.w + 2*x) * 4 + c] + p.px[((size_t)(2*y + 1) * p.w + 2*x + 1) * 4 + c];
        o.px[((size_t)y * o.w + x) * 4 + c] = (uint8_t)(s / 4); }
    return o; }

// Call once with a current GL context, after setImage() for every picture that exists.
static void init(){
    gProg = glCreateProgram(); glAttachShader(gProg, compileSh(GL_VERTEX_SHADER, VS)); glAttachShader(gProg, compileSh(GL_FRAGMENT_SHADER, FS)); glLinkProgram(gProg);
    #define U(n) glGetUniformLocation(gProg, n)
    uF = U("uF"); uR = U("uR"); uU = U("uU"); uT = U("uT"); uTime = U("uTime"); uNight = U("uNight"); uTwL = U("uTw"); uRain = U("uRain"); uCubeAmt = U("uCubeAmt"); uInset = U("uInset"); uMtnAmt = U("uMtnAmt"); uQ = U("uQ");
    uSun = U("uSun"); uMoon = U("uMoon"); uHor = U("uHor"); uMid = U("uMid"); uZen = U("uZen"); uCl = U("uCl"); uCs = U("uCs"); uTint = U("uCubeTint"); uCubeTex = U("uCubeTex"); uMtnTex = U("uMtnTex"); uMtnData = U("uMtnData");
    #undef U
    // cube atlas: 3 x 2 faces, canvas filled #5b7a96 (the 6th cell stays empty, like the HTML)
    if (gPic[0].w > 0){
        const int S = gPic[0].w, W = S * 3, H = S * 2; std::vector<uint8_t> a((size_t)W * H * 4);
        for (size_t i = 0; i < (size_t)W * H; i++){ a[i*4] = 0x5b; a[i*4+1] = 0x7a; a[i*4+2] = 0x96; a[i*4+3] = 255; }
        for (int f = 0; f < 5; f++){
            const Pic& p = gPic[f]; if (p.w != S || p.h != S) continue;
            for (int y = 0; y < S; y++) memcpy(&a[((size_t)((f / 3) * S + y) * W + (f % 3) * S) * 4], &p.px[(size_t)y * S * 4], (size_t)S * 4);
        }
        gCube = upload(a.data(), W, H, false); gInset = 1.5f / S; gHaveCube = true;
    }
    if (gPic[5].w > 0 && gPic[6].w > 0){
        GLint mx = 2048; glGetIntegerv(GL_MAX_TEXTURE_SIZE, &mx);
        Pic c = gPic[5], d = gPic[6];
        while (c.w > mx){ c = halve(c); d = halve(d); }
        gMtnC = upload(c.px.data(), c.w, c.h, true); gMtnD = upload(d.px.data(), d.w, d.h, true); gHaveMtn = true;
    }
    for (Pic& p : gPic){ p.px.clear(); p.px.shrink_to_fit(); }
}

// ---- time of day (Settings / the sun-moon button): Morning, Noon, Afternoon, Sunset, Dusk, Night ----
// tod is the HTML clock in seconds: 0 = sunrise, 150 = noon, 300 = sunset, 300..480 = night. It glides to the chosen preset by the shortest way round the clock.
static Env gEnv;
static const float TOD_PRESET[6] = {28.f, 150.f, 262.f, 295.f, 304.f, 420.f};     // morning, noon, afternoon, sunset, dusk (twilight), night
static float gTod = 150.f, gTodTarget = 150.f; static bool gTodInit = false;
static float gRainK = 0.f;                                   // kept for the sky shader (always 0: no more rain)
static void setTimeOfDay(int idx){
    if (idx < 0) idx = 0; if (idx > 5) idx = 5;
    gTodTarget = TOD_PRESET[idx];
    if (!gTodInit){ gTod = gTodTarget; gTodInit = true; }    // first call (app start): no glide
}
static void stepTod(float dt){
    float d = std::fmod(gTodTarget - gTod, 480.f); if (d > 240.f) d -= 480.f; if (d < -240.f) d += 480.f;
    if (std::fabs(d) > 0.05f){
        float st = d * (1.f - std::exp(-dt * 2.2f)); const float mn = 14.f * dt;        // ease out, but never crawl
        if (std::fabs(st) < mn) st = d > 0 ? mn : -mn;
        if (std::fabs(st) > std::fabs(d)) st = d;
        gTod += st;
    } else gTod = gTodTarget;
    gTod = std::fmod(gTod + 480.f, 480.f);
    envAt(gTod, gEnv);
}
// ---- a different bloom for every time of day (colour, threshold, strength, softness, spread, god-ray strength); blended smoothly while the clock glides ----
struct BloomFx { float tint[3], thr, gain, soft, rad, ray; };
static BloomFx bloomFx(float tod){
    static const BloomFx B[6] = {
        {{1.00f, .94f, .82f}, .66f, 1.00f, .070f, 1.20f, 1.00f},   // morning : soft misty glow, pale gold
        {{1.02f, 1.00f, .95f}, .78f, .75f, .030f, .85f, .60f},     // noon    : crisp, only the brightest glints bloom, neutral white
        {{1.10f, .95f, .76f}, .70f, 1.00f, .050f, 1.00f, .95f},    // afternoon: warm golden glow
        {{1.22f, .74f, .46f}, .56f, 1.40f, .090f, 1.50f, 1.30f},   // sunset  : wide warm orange glow round the sun
        {{1.00f, .74f, .92f}, .50f, 1.15f, .075f, 1.30f, .30f},    // dusk    : subtle rose-violet glow
        {{.82f, .92f, 1.18f}, .40f, 1.30f, .040f, 1.00f, .00f}};   // night   : cool white halos round lamps and the moon
    float t = std::fmod(std::fmod(tod, 480.f) + 480.f, 480.f); if (t < TOD_PRESET[0]) t += 480.f;
    int i = 0; float f = 0.f;
    for (; i < 6; i++){ const float a = TOD_PRESET[i], b = i < 5 ? TOD_PRESET[i + 1] : TOD_PRESET[0] + 480.f; if (t >= a && t <= b){ f = ss(0.f, 1.f, (t - a) / (b - a)); break; } }
    if (i > 5) i = 5;
    const BloomFx &p = B[i], &q = B[(i + 1) % 6]; BloomFx o;
    for (int k = 0; k < 3; k++) o.tint[k] = p.tint[k] + (q.tint[k] - p.tint[k]) * f;
    o.thr = p.thr + (q.thr - p.thr) * f; o.gain = p.gain + (q.gain - p.gain) * f; o.soft = p.soft + (q.soft - p.soft) * f; o.rad = p.rad + (q.rad - p.rad) * f; o.ray = p.ray + (q.ray - p.ray) * f;
    return o;
}
// how warm / golden the light is: strongest when the sun is low (morning, sunset), fades as the sun goes under the horizon
static float warmK(){ const float e = gEnv.sun[1]; return std::min(1.f, std::max(0.f, 1.f - (e - .10f) / .55f)) * ss(-.14f, .02f, e); }

// eye / ctr = the game camera (fov in radians, aspect = width / height); call LAST (after the night overlay): it only fills pixels nothing else covered
static void draw(const float* eye, const float* ctr, float fov, float aspect, float tSec, const float* upv = nullptr){   // upv = camera up (cockpit cameras roll with the body); default = world up
    float f[3] = {ctr[0]-eye[0], ctr[1]-eye[1], ctr[2]-eye[2]}; normalize3(f);
    const float U0[3] = {0.f, 1.f, 0.f}; const float* uu = upv ? upv : U0;
    float s[3] = {f[1]*uu[2] - f[2]*uu[1], f[2]*uu[0] - f[0]*uu[2], f[0]*uu[1] - f[1]*uu[0]}; normalize3(s);                  // f x up
    float u[3] = {s[1]*f[2]-s[2]*f[1], s[2]*f[0]-s[0]*f[2], s[0]*f[1]-s[1]*f[0]};
    const float th = std::tan(fov / 2);
    glEnable(GL_DEPTH_TEST); glDepthFunc(GL_LEQUAL); glDepthMask(GL_FALSE); glDisable(GL_CULL_FACE); glDisable(GL_BLEND);
    glUseProgram(gProg);
    glUniform3fv(uF, 1, f); glUniform3fv(uR, 1, s); glUniform3fv(uU, 1, u); glUniform2f(uT, th * aspect, th);
    glUniform1f(uTime, tSec); glUniform1f(uNight, gEnv.night); glUniform1f(uTwL, gEnv.tw); glUniform1f(uRain, gRainK);
    glUniform1f(uCubeAmt, gHaveCube ? 1.f : 0.f); glUniform1f(uInset, gInset); glUniform1f(uMtnAmt, 0.f);   /* flat photo mountains off: real 3D Alps are drawn by terrain.h */ glUniform1f(uQ, 1.f);
    glUniform3fv(uSun, 1, gEnv.sun); glUniform3fv(uMoon, 1, gEnv.moon); glUniform3fv(uHor, 1, gEnv.hor); glUniform3fv(uMid, 1, gEnv.mid); glUniform3fv(uZen, 1, gEnv.zen);
    glUniform3fv(uCl, 1, gEnv.cl); glUniform3fv(uCs, 1, gEnv.cs); glUniform3fv(uTint, 1, gEnv.tint);
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, gCube); glUniform1i(uCubeTex, 0);
    glActiveTexture(GL_TEXTURE1); glBindTexture(GL_TEXTURE_2D, gMtnC); glUniform1i(uMtnTex, 1);
    glActiveTexture(GL_TEXTURE2); glBindTexture(GL_TEXTURE_2D, gMtnD); glUniform1i(uMtnData, 2);
    GLuint vao = 0; static GLuint sVao = 0; if (!sVao) glGenVertexArrays(1, &sVao); vao = sVao; glBindVertexArray(vao);
    glDrawArrays(GL_TRIANGLES, 0, 3);
    glBindVertexArray(0); glActiveTexture(GL_TEXTURE0); glDepthMask(GL_TRUE); glDepthFunc(GL_LESS);
}

}   // namespace SkyGL
