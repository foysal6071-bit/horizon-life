# SunnyDriftCar v140 – Forza-inspired driving physics (builds on v139)

## Status
| Item | State |
|---|---|
| C++ physics (car_core.h, tuning.h, control.h) | compiled and tested headless (g++), all checks pass |
| native-lib.cpp | syntax / type checked against stub GL + Android headers only (-fsyntax-only). NOT built with the NDK |
| MainActivity.java | no syntax errors (javac reports only missing Android classes). NOT compiled against android.jar |
| APK | NOT built (no Android SDK / NDK / network here). CI workflow now runs the physics tests, then `gradle assembleDebug` |
| On-device feel | NOT tested on a phone. All numbers below come from tools/physics_test*.cpp |

## Already in v139 (kept)
Analog throttle / brake (touch height on the pedal), pedal curves, front/rear brake bias with per-axle load limits, ABS, no-ABS lock model, traction control, stability control, 7-speed DCT, handbrake on the rear axle, per-tyre surface sampling.

## New in v140
* **Manual gearbox** (Settings > Controls > Gearbox). Shift buttons appear (SHIFT + / SHIFT -), keys E / Q (Page up / down). No auto-shift; downshifts that would over-rev are refused; 1st gear at a stop. No neutral (not added).
* **Drift assist** (on by default): up to ~30 deg of slide the electronic counter-steer only helps half as much; beyond ~45 deg it helps more (spin rescue); throttle takes part of the rear grip while sliding so the tail stays out; lift-off gives the rear grip back progressively.
* **Power oversteer**: the full drive force now counts against the rear friction circle (`Tune::rearDriveLoad` 0.8 -> 1.0).
* **Handbrake**: strength slider, locks at 4/s, rear grip comes back at 2.6/s (was 6/s both ways) = no snap-back on release.
* **Steering assist** (on by default): takes lock off a ploughing front axle, only while gripping.
* **Road condition**: Dry / Wet / Snow / Ice scales the grip of all four tyres (x1.0 / 0.72 / 0.40 / 0.20) and the drag. There is no wet or snow visual (weather was removed from the game earlier). It is a physics setting.
* **Brake fade** (optional, off by default): brake temperature from braking work, cooling by airflow, up to 30 % lost.
* **Telemetry overlay** (Settings > Controls > Telemetry, off by default): speed, rpm, gear, throttle, brake, steering, drift angle, front / rear slip, lateral / longitudinal g (true body-frame, from tyre forces), grip, TCS / ABS / ESC, brake temperature, handbrake, rear grip use.
* **Safety**: dt clamped, state snapshot + automatic fall-back if anything turns non-finite or runs away, lateral velocity clamp.
* **Sound**: nSound now carries brake, gear-change, gear and limiter; throttle dips during a shift (torque interruption); skid also reacts to wheel lock, ABS chatter and wheelspin.
* **Tyre FX**: ABS braking no longer smokes / marks like a locked stop; power wheelspin makes smoke from real rear grip use.

## Measured (tools/results_physics_test.txt, results_physics_test_v2.txt)
* 0-100 km/h 3.50 s, 0-200 10.50 s, top 313 km/h (30 / 60 / 120 fps within 0.05 s).
* Full braking 100 km/h: 33.9 m (1.18 g); 200 km/h: 127.3 m. 30 / 60 / 120 fps: 73.7 / 73.9 / 74.0 m from 150 km/h.
* Road condition, 100 km/h stop: dry 33.9 m, wet 45.3 m, snow 75.1 m, ice 146.0 m.
* Brake fade, four stops from 200 km/h: 127 -> 136 -> 158 -> 161 m.
* Drift: handbrake kick 0.5 s + full throttle + a proportional-steering driver model holds the slide (11-49 deg) 100 % of the time over 9 s from 70 / 90 / 110 km/h, left and right, at 30 / 60 / 120 fps, no spin. With drift assist OFF the same driver holds it 0 % of the time (it recovers grip). The driver model is a test script, not a person.
* Handbrake release: biggest yaw-rate change per frame 0.08 rad/s, rear lock drops <= 0.042 per frame.
* Fuzz: 200 000 random steps (pedals, surfaces, shifts, road conditions, dt up to 0.4 s): every state finite.

## Known limitations
* The handbrake kick over-rotates at first (peak slide 52-62 deg before the driver settles it at ~20-35 deg). Needs on-device tuning (`Tune::handbrakeRise`, `handbrakeStrength`).
* Throttle-only power oversteer is mild (rear slides ~6 deg at 50 km/h in 2nd, rear grip use 0.88): AWD car. Full drifts start with handbrake or trail braking (33 deg in the test).
* Steering assist triggers (up to 18 % on mu 0.4) but changes yaw / lateral g by less than the display precision in my test; its value is unproven.
* Lift-off oversteer is weak (yaw 0.28 -> 0.35 rad/s).
* Gravel, dirt and grass are not separate surface classes: the game only reports mu / rolling resistance per tyre (tarmac, verge, grass, dirt track), so they differ by grip and dust only. No gravel particles, no snow visuals, no wet look.
* Physics step: variable dt (<= 1/60 s per sub-step, several sub-steps for a long frame), internally 5 ms integration. Tested frame-rate independent at 30 / 60 / 120 fps; a strict fixed-step accumulator was not added because it would need render interpolation.
* Suspension: the existing spring-damper body roll / pitch / heave (car_render.h) was kept unchanged; not re-tuned or re-tested.
* Brake lights use the existing `braking` flag. Camera effects are unchanged.

## Modified files
.github/workflows/build.yml, app/src/main/cpp/{car_core.h, tuning.h, control.h, native-lib.cpp, tyre_fx.h}, app/src/main/java/com/sunny/car/MainActivity.java, tools/physics_test_v2.cpp (new), tools/results_*.txt (new). World, roads, terrain, car model, camera, minimap untouched (verified with diff against the v139 zip).
