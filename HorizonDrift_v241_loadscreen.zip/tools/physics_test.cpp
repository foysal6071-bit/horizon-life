// Headless physics tests for car_core.h (no rendering).  Build: g++ -std=c++17 -O1 -I../app/src/main/cpp physics_test.cpp -o physics_test
#include "car_core.h"
#include <cstdio>
static Surface asphalt(){ return Surface(); }
static double stepsRun(CarState& S, Input in, const Surface& su, double secs, double dt, double* t60=nullptr, double* t100=nullptr, double* t200=nullptr){
    double t=0; for(;t<secs;t+=dt){ Veh::step(S,in,su,dt); double k=S.speed*3.6; double* p; if(t60&&*t60<0&&k>=60)*t60=t; if(t100&&*t100<0&&k>=100)*t100=t; if(t200&&*t200<0&&k>=200)*t200=t; if(!std::isfinite(S.speed)||!std::isfinite(S.yaw)){printf("NaN!\n");return -1;} } return t; }
int main(){
    Surface su=asphalt(); int fails=0;
    for(double dt: {1/30.,1/60.,1/120.}){                                   // TEST 1: acceleration, frame-rate independence
        CarState S; Input in; in.gas=true; double a=-1,b=-1,c=-1; stepsRun(S,in,su,40,dt,&a,&b,&c);
        printf("ACCEL dt=%.4f: 0-60 %.2fs 0-100 %.2fs 0-200 %.2fs  vmax %.0f km/h gear %d rpm %.0f\n",dt,a,b,c,S.speed*3.6,S.gear,S.rpm);
    }
    for(double v0: {100.,200.}) for(int pedal=0; pedal<3; pedal++){      // TEST 2: braking
        double p = pedal==0?0.25:(pedal==1?0.6:1.0);
        CarState S; S.speed=v0/3.6; S.gear=v0>150?5:3; S.rpm=5000; Input in; in.brake=true; in.brk=p; double d=0,t=0,dt=1/60.;
        while(S.speed>0.3&&t<30){ double v=S.speed; Veh::step(S,in,su,dt); d+=0.5*(v+S.speed)*dt; t+=dt; }
        printf("BRAKE from %3.0f km/h pedal %.2f: %.1f m in %.2fs (mean decel %.2f g) %s\n",v0,p,d,t,(v0/3.6)/t/9.81, "");
        if(pedal==2){ double g=(v0/3.6)/t/9.81; if(g<0.9||g>1.45){printf("  FAIL decel out of range\n");fails++;} }
    }
    { CarState S; S.speed=100/3.6; S.gear=4; Input in; in.brake=true; in.left=true; double dt=1/60.; stepsRun(S,in,su,0.6,dt);   // braking while turning stays stable
      printf("BRAKE+TURN: speed %.1f km/h yaw %.2f vy %.2f absAct %.2f\n",S.speed*3.6,S.yaw,S.vy,S.absAct); if(fabs(S.yaw)>1.6){printf("  FAIL spin\n");fails++;} }
    { Tune::absOn=false; CarState S; S.speed=100/3.6; S.gear=4; Input in; in.brake=true; double t=0,d=0,dt=1/60.; while(S.speed>0.3&&t<30){double v=S.speed;Veh::step(S,in,su,dt);d+=0.5*(v+S.speed)*dt;t+=dt;}
      printf("BRAKE no-ABS 100 km/h: %.1f m (lock %.2f/%.2f)\n",d,S.lockF,S.lockR); Tune::absOn=true; }
    { CarState S; S.speed=100/3.6; S.gear=4; Input in; in.gas=true; in.left=true; stepsRun(S,in,su,3,1/60.);                  // TEST 3: cornering
      printf("CORNER 100 km/h full lock + gas: yaw %.2f lat %.2f g drift %.2f\n",S.yaw,S.ay/9.81,S.drift); }
    { CarState S; S.speed=90/3.6; S.gear=3; Input in; in.hand=true; in.left=true; double mx=0,mxYaw=0; for(double t=0;t<0.9;t+=1/60.){Veh::step(S,in,su,1/60.); mx=max(mx,S.drift); mxYaw=max(mxYaw,fabs(S.yaw));}   // TEST 4: handbrake drift
      Input rel; rel.gas=true; rel.right=true; double dr=0; for(double t=0;t<2.5;t+=1/60.){ Veh::step(S,rel,su,1/60.); dr=max(dr,S.drift); }
      printf("HANDBRAKE 0.9s @90 km/h: max drift %.2f max yaw %.2f rad/s; then gas+countersteer 2.5s: drift %.2f (peak %.2f) speed %.0f km/h yaw %.2f\n",mx,mxYaw,S.drift,dr,S.speed*3.6,S.yaw);
      if(!(mx>0.3)){printf("  FAIL handbrake does not start a slide\n");fails++;} if(fabs(S.yaw)>2.5){printf("  FAIL snap spin\n");fails++;} }
    for(double mu: {1.15,0.7,0.55,0.4}){                                     // TEST 5: surfaces
        Surface g; g.mu=mu; g.rr= mu>1?0.028:0.06; CarState S; S.speed=100/3.6; S.gear=4; Input in; in.brake=true; double t=0,d=0,dt=1/60.;
        while(S.speed>0.3&&t<40){double v=S.speed;Veh::step(S,in,g,dt);d+=0.5*(v+S.speed)*dt;t+=dt;}
        printf("SURFACE mu %.2f: braking 100 km/h -> %.1f m\n",mu,d); }
    { CarState S; Input in; in.gas=true; in.thr=0.3; stepsRun(S,in,su,5,1/60.); double a=S.speed*3.6; CarState T; Input f; f.gas=true; stepsRun(T,f,su,5,1/60.);
      printf("THROTTLE 30%% for 5 s: %.0f km/h  vs full: %.0f km/h  (%s)\n",a,T.speed*3.6,a<T.speed*3.6*0.8?"ok":"FAIL"); if(!(a<T.speed*3.6*0.8))fails++; }
    printf("%s (%d failures)\n",fails?"FAILED":"ALL CHECKS PASSED",fails); return fails;
}
