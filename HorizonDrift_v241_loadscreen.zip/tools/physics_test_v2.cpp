// Headless physics tests, part 2 (v140 additions): manual gearbox, brake fade, road conditions, long drift with a simple driver model,
// handbrake release, assists on / off, frame-rate independence of the drift and a NaN / abuse fuzz.  No rendering.
// Build: g++ -std=c++17 -O1 -I../app/src/main/cpp physics_test_v2.cpp -o physics_test_v2 && ./physics_test_v2
#include "car_core.h"
#include <cstdio>
static int fails = 0;
#define CHECK(c, msg) do { if (!(c)){ printf("  FAIL: %s\n", msg); fails++; } } while (0)
static Surface tarmac(){ return Surface(); }
static double brakeDist(double kmh, double pedal, const Surface& su, double dt = 1 / 60., int gear = 4){
    CarState S; S.speed = kmh / 3.6; S.gear = gear; S.rpm = 5000; Input in; in.brake = true; in.brk = pedal; double d = 0, t = 0;
    while (S.speed > 0.3 && t < 60){ double v = S.speed; Veh::step(S, in, su, dt); d += 0.5 * (v + S.speed) * dt; t += dt; }
    return d;
}
// drift driver: handbrake kick, then full throttle and proportional steering towards a target slide angle. sign = +1 left drift, -1 right drift
struct DriftRun { double maxAng = 0, minAngHold = 9, endAng = 0, maxYaw = 0, kmhEnd = 0, frac = 0; bool spun = false; };
static DriftRun driftRun(double dt, double sign, double kmh0, int gear0, double hbT = 0.5, double secs = 9.0, double thr = 1.0, double target = 0.5){
    CarState S; S.speed = kmh0 / 3.6; S.gear = gear0; S.rpm = 5500; Surface su = tarmac(); DriftRun r; int n = 0, ok = 0;
    for (double t = 0; t < secs; t += dt){
        Input in; const double beta = atan2(S.vy - Veh::LB * S.yaw, max(S.speed, 2.5)), ang = -sign * beta;   // slide angle, positive when the tail is out
        double steer;
        if (t < hbT){ in.hand = true; steer = sign; in.gas = true; in.thr = 0.5; }
        else { in.gas = true; in.thr = thr; steer = sign * clampd(0.3 + 2.0 * (target - ang), -1.0, 1.0); }
        in.useAnalog = true; in.analog = steer; in.sens = 1.8;
        Veh::step(S, in, su, dt);
        r.maxAng = max(r.maxAng, ang); r.maxYaw = max(r.maxYaw, fabs(S.yaw)); r.endAng = ang;
        if (t > 2.5){ n++; if (ang > 0.2 && ang < 0.85) ok++; r.minAngHold = min(r.minAngHold, ang); }
        if (fabs(S.yaw) > 2.4 || ang > 1.5) r.spun = true;
    }
    r.kmhEnd = S.speed * 3.6; r.frac = n ? (double)ok / n : 0; return r;
}

int main(){
    Surface su = tarmac();

    printf("== T1 manual gearbox ==\n");
    { Tune::manualBox = true; CarState S; Input in; in.gas = true; double dt = 1 / 60.; int ups = 0; double t = 0, t100 = -1;
      for (; t < 20; t += dt){ in.shift = 0; if (S.rpm > 6500 && S.gear < 7 && S.shiftT <= 0){ in.shift = 1; ups++; } Veh::step(S, in, su, dt); if (t100 < 0 && S.speed * 3.6 >= 100) t100 = t; }
      printf("manual full-throttle run, shifting at 6500 rpm: 0-100 %.2fs  gear after 20 s %d, %d upshifts, speed %.0f km/h\n", t100, S.gear, ups, S.speed * 3.6);
      CHECK(ups >= 5 && S.gear >= 6, "manual upshifts did not take effect");
      CarState S2; S2.gear = 5; S2.speed = 150 / 3.6; S2.rpm = 4500; Input d; d.shift = -1; CarState T = S2; Veh::step(T, d, su, dt); { CarState W = S; Veh::step(W, d, su, dt); CHECK(W.gear == S.gear, "downshift into an over-rev was not refused"); } printf("downshift at 150 km/h: gear %d -> %d; at %.0f km/h the box refuses a downshift that would over-rev\n", S2.gear, T.gear, S.speed * 3.6); CHECK(T.gear == 4, "manual downshift did not happen");
      // no auto-shift in manual mode: hold 2nd gear at 90 km/h-class speed -> rev limiter, gear stays
      CarState H; H.gear = 2; H.speed = 20; H.rpm = 6000; Input g; g.gas = true; for (int i = 0; i < 300; i++) Veh::step(H, g, su, dt);
      printf("manual, held in 2nd gear on full throttle: gear %d, rpm %.0f, %.0f km/h (limiter %d)\n", H.gear, H.rpm, H.speed * 3.6, (int)H.limiter);
      CHECK(H.gear == 2 && H.rpm <= Veh::REDLINE + 310, "manual box shifted by itself / over-revved");
      Tune::manualBox = false; }

    printf("== T2 brake fade (optional) ==\n");
    { double dt = 1 / 60.; Tune::brakeFadeOn = true; CarState S; Input b; b.brake = true; Input g; g.gas = true; double d[4];
      for (int k = 0; k < 4; k++){ S.speed = 200 / 3.6; S.gear = 5; S.rpm = 5500; double dd = 0, t = 0; while (S.speed > 0.3 && t < 30){ double v = S.speed; Veh::step(S, b, su, dt); dd += 0.5 * (v + S.speed) * dt; t += dt; } d[k] = dd;
          printf("stop %d from 200 km/h: %.1f m, brake temp %.2f\n", k + 1, dd, S.brakeTemp); }
      CHECK(d[3] > d[0] * 1.08, "no visible fade after four hard stops");
      CHECK(d[3] < d[0] * 1.6, "fade too strong (brakes should stay usable)");
      Tune::brakeFadeOn = false; double off = brakeDist(200, 1.0, su, dt, 5); printf("fade off: %.1f m (unchanged)\n", off); CHECK(fabs(off - d[0]) < 2.0, "fade-off braking differs from first fade-on stop"); }

    printf("== T3 road condition / surfaces (braking 100 km/h, ABS on) ==\n");
    { const char* nm[4] = {"dry", "wet", "snow", "ice"}; double dist[4];
      for (int c = 0; c < 4; c++){ Tune::roadCond = c; dist[c] = brakeDist(100, 1.0, su); printf("%-4s: %.1f m\n", nm[c], dist[c]); }
      Tune::roadCond = 0; CHECK(dist[1] > dist[0] * 1.2 && dist[2] > dist[1] * 1.4 && dist[3] > dist[2] * 1.6, "road conditions do not lengthen the stopping distance progressively");
      // ice: car must still be controllable (no NaN, bounded yaw) with full-lock steering at speed
      Tune::roadCond = 3; CarState S; S.speed = 60 / 3.6; S.gear = 3; Input in; in.gas = true; in.left = true; double my = 0; for (double t = 0; t < 4; t += 1 / 60.){ Veh::step(S, in, su, 1 / 60.); my = max(my, fabs(S.yaw)); }
      printf("ice, 60 km/h, full lock + throttle for 4 s: max yaw %.2f rad/s, final speed %.0f km/h\n", my, S.speed * 3.6); CHECK(std::isfinite(S.speed) && my < 2.6, "ice abuse unstable"); Tune::roadCond = 0;
      for (double mu : {1.15, 0.7, 0.55, 0.4}){ Surface g; g.mu = mu; printf("surface mu %.2f: %.1f m   ", mu, brakeDist(100, 1.0, g)); } printf("\n"); }

    printf("== T4 long drift: handbrake kick 0.5 s, then full throttle + proportional steering to a 29 deg slide, 9 s ==\n");
    for (double dt : {1 / 30., 1 / 60., 1 / 120.}) for (double kmh : {70., 90., 110.}){
      DriftRun r = driftRun(dt, +1, kmh, kmh < 80 ? 2 : 3);
      printf("dt %.4f start %3.0f km/h: peak %.0f deg, min after 2.5 s %.0f deg, in 11-49 deg %.0f%% of the time, max yaw %.2f rad/s, end %.0f km/h spun=%d\n", dt, kmh, r.maxAng * 57.3, r.minAngHold * 57.3, r.frac * 100, r.maxYaw, r.kmhEnd, r.spun);
      CHECK(!r.spun, "drift driver spun the car"); CHECK(r.frac > 0.7, "the drift could not be held");
    }
    { DriftRun r = driftRun(1 / 60., -1, 90, 3); printf("right-hand drift 90 km/h: in 11-49 deg %.0f%%, spun=%d\n", r.frac * 100, r.spun); CHECK(!r.spun && r.frac > 0.7, "right drift not symmetric"); }
    { for (int a = 0; a < 2; a++){ Tune::driftAssist = a; DriftRun r = driftRun(1 / 60., +1, 90, 3); printf("drift assist %s, same driver: in 11-49 deg %.0f%% of the time, peak %.0f deg, spun=%d\n", a ? "ON " : "OFF", r.frac * 100, r.maxAng * 57.3, r.spun); } Tune::driftAssist = true; }
    { for (int a = 0; a < 2; a++){ Tune::driftAssist = a; CarState S; S.speed = 90 / 3.6; S.gear = 3; S.rpm = 5500; double mx = 0, mYaw = 0;
        for (double t = 0; t < 6; t += 1 / 60.){ Input in; in.gas = true; in.thr = 0.9; if (t < 0.5){ in.hand = true; in.left = true; } else if (t < 1.2) in.left = true; Veh::step(S, in, su, 1 / 60.); mx = max(mx, fabs(atan2(S.vy - Veh::LB * S.yaw, max(S.speed, 2.5)))); mYaw = max(mYaw, fabs(S.yaw)); }
        printf("hands-off after the kick, assist %s: peak slide %.0f deg, yaw max %.2f rad/s, after 6 s %.0f km/h\n", a ? "ON " : "OFF", mx * 57.3, mYaw, S.speed * 3.6); CHECK(mYaw < 2.3, "snap spin without steering input"); } Tune::driftAssist = true; }
    { CarState S; S.speed = 50 / 3.6; S.gear = 2; S.rpm = 5200; double mx = 0, mu = 0; Input in; in.gas = true; in.left = true; for (double t = 0; t < 1.5; t += 1 / 60.){ Veh::step(S, in, su, 1 / 60.); mx = max(mx, fabs(atan2(S.vy - Veh::LB * S.yaw, max(S.speed, 2.5)))); mu = max(mu, S.rearUse); }
      printf("power oversteer test 50 km/h full throttle + left: peak rear slide angle %.0f deg, peak rear grip use %.2f\n", mx * 57.3, mu); CHECK(mu > 0.75, "throttle never loads the rear tyres to their limit"); }
    { CarState S; S.speed = 120 / 3.6; S.gear = 5; S.rpm = 5000; Input a; a.gas = true; a.thr = 0.6; a.useAnalog = true; a.analog = 0.5; for (double t = 0; t < 2.0; t += 1 / 60.) Veh::step(S, a, su, 1 / 60.);
      const double y0 = S.yaw; Input b; b.useAnalog = true; b.analog = 0.5; double mx = 0; for (double t = 0; t < 1.0; t += 1 / 60.){ Veh::step(S, b, su, 1 / 60.); mx = max(mx, fabs(atan2(S.vy - Veh::LB * S.yaw, max(S.speed, 2.5)))); }
      printf("lift-off in a 120 km/h corner: yaw %.2f -> %.2f rad/s, peak rear slide %.1f deg\n", y0, S.yaw, mx * 57.3); }
    { CarState S; S.speed = 120 / 3.6; S.gear = 5; S.rpm = 5000; Input a; a.brake = true; a.brk = 0.6; a.useAnalog = true; a.analog = 0.6; double mx = 0, yw = 0; for (double t = 0; t < 1.5; t += 1 / 60.){ Veh::step(S, a, su, 1 / 60.); mx = max(mx, fabs(atan2(S.vy - Veh::LB * S.yaw, max(S.speed, 2.5)))); yw = max(yw, fabs(S.yaw)); }
      printf("trail braking 120 km/h, brake 60%% + steering: peak rear slide %.1f deg, peak yaw %.2f rad/s, ABS %.2f\n", mx * 57.3, yw, S.absAct); CHECK(yw < 2.0, "trail braking spins the car"); }

    printf("== T5 handbrake: release is progressive ==\n");
    { CarState S; S.speed = 100 / 3.6; S.gear = 4; S.rpm = 5000; double dt = 1 / 60.; Input in; in.hand = true; in.gas = true; in.thr = 0.3; in.left = true;
      for (double t = 0; t < 0.8; t += dt) Veh::step(S, in, su, dt);
      const double hb0 = S.hb, v0 = S.speed * 3.6; printf("after 0.8 s of handbrake: hb %.2f, speed %.0f km/h, drift %.2f, yaw %.2f\n", hb0, v0, S.drift, S.yaw);
      CHECK(S.hb > 0.9, "handbrake does not lock the rear axle fast enough");
      Input rel; rel.gas = true; rel.thr = 0.3; double prevHb = S.hb, maxDrop = 0, prevYaw = S.yaw, maxYawJump = 0;
      for (double t = 0; t < 1.5; t += dt){ Veh::step(S, rel, su, dt); maxDrop = max(maxDrop, prevHb - S.hb); prevHb = S.hb; maxYawJump = max(maxYawJump, fabs(S.yaw - prevYaw)); prevYaw = S.yaw; }
      printf("release: hb %.2f after 1.5 s, biggest hb drop per frame %.3f, biggest yaw change per frame %.3f rad/s, drift %.2f\n", S.hb, maxDrop, maxYawJump, S.drift);
      CHECK(maxDrop < 0.08, "handbrake grip snapped back in one frame"); CHECK(maxYawJump < 0.35, "yaw rate jumped on release (snap-back)"); }

    printf("== T6 steering: speed-sensitive lock, assist ==\n");
    { for (double kmh : {20., 60., 120., 200.}){ CarState S; S.speed = kmh / 3.6; S.gear = kmh < 50 ? 2 : (kmh < 130 ? 4 : 6); Input in; in.left = true; in.gas = true; in.thr = 0.3; for (int i = 0; i < 60; i++) Veh::step(S, in, su, 1 / 60.);
          printf("%.0f km/h full lock: wheel angle %.1f deg, lat %.2f g, yaw %.2f rad/s drift %.2f\n", kmh, S.steerAngle * 57.3, S.ay / 9.81, S.yaw, S.drift); }
      for (int a = 0; a < 2; a++){ Tune::steerAssist = a; CarState S; S.speed = 120 / 3.6; S.gear = 5; Input in; in.left = true; in.gas = true; in.thr = 0.5; double mx = 0; for (int i = 0; i < 180; i++){ Veh::step(S, in, su, 1 / 60.); mx = max(mx, S.ay / 9.81); }
        printf("120 km/h full lock, steer assist %s: peak lateral %.2f g, final yaw %.2f, assist activity %.2f\n", a ? "ON " : "OFF", mx, S.yaw, S.assistAct); } Tune::steerAssist = true;
      // rate limit: the wheel never moves faster than STEER_RATE (frame-rate independent)
      for (double dt : {1 / 30., 1 / 120.}){ CarState S; S.speed = 20; S.gear = 3; Input in; in.left = true; double t = 0; while (S.steer < 0.5 && t < 5){ Veh::step(S, in, su, dt); t += dt; } printf("steer to 0.5 at 72 km/h: %.2f s (dt %.4f)\n", t, dt); } }

    printf("== T7 frame-rate independence of braking + cornering ==\n");
    { double a = brakeDist(150, 1.0, su, 1 / 30.), b = brakeDist(150, 1.0, su, 1 / 60.), c = brakeDist(150, 1.0, su, 1 / 120.); printf("brake 150 km/h: %.1f / %.1f / %.1f m at 30 / 60 / 120 fps\n", a, b, c); CHECK(fabs(a - c) < 2.0 && fabs(b - c) < 1.5, "braking depends on frame rate");
      double h[3]; int k = 0; for (double dt : {1 / 30., 1 / 60., 1 / 120.}){ CarState S; S.speed = 100 / 3.6; S.gear = 4; Input in; in.left = true; in.gas = true; in.thr = 0.4; for (double t = 0; t < 4; t += dt) Veh::step(S, in, su, dt); h[k++] = S.heading; }
      printf("heading after 4 s of cornering: %.3f / %.3f / %.3f rad\n", h[0], h[1], h[2]); CHECK(fabs(h[0] - h[2]) < 0.12 && fabs(h[1] - h[2]) < 0.08, "cornering depends on frame rate"); }

    printf("== T8 abuse / NaN fuzz (200000 random steps, random pedals, surfaces, dt up to 0.25 s) ==\n");
    { uint32_t r = 7; auto rnd = [&](){ r = r * 1664525u + 1013904223u; return (r >> 8) / 16777216.0; };
      CarState S; Surface g; Input in; bool bad = false; double maxV = 0, maxYaw = 0;
      for (int i = 0; i < 200000 && !bad; i++){
          if (i % 40 == 0 || rnd() < 0.01){ in = Input(); in.gas = rnd() < 0.7; in.brake = rnd() < 0.3; in.hand = rnd() < 0.15; in.left = rnd() < 0.4; in.right = rnd() < 0.4; if (rnd() < 0.3){ in.thr = rnd(); in.brk = rnd(); }
          } in.shift = rnd() < 0.05 ? (rnd() < 0.5 ? 1 : -1) : 0; if (i % 5000 == 0) Tune::manualBox = !Tune::manualBox; Tune::roadCond = (i / 7000) % 4; Tune::brakeFadeOn = (i / 9000) & 1;
          g.mu = 0.2 + rnd() * 1.1; g.rr = 0.02 + rnd() * 0.1; g.pull = (rnd() - 0.5) * 0.1; g.muSide = (rnd() - 0.5) * 0.6; g.muF = rnd() < 0.5 ? -1 : 0.3 + rnd(); g.muR = rnd() < 0.5 ? -1 : 0.3 + rnd();
          S.slope = (rnd() - 0.5) * 0.6; double dt = rnd() < 0.02 ? rnd() * 0.4 : 1 / 120. + rnd() / 40.;
          Veh::step(S, in, g, dt); maxV = max(maxV, fabs(S.speed)); maxYaw = max(maxYaw, fabs(S.yaw));
          if (!Veh::sane(S) || !std::isfinite(S.ax) || !std::isfinite(S.drift) || S.rpm < 0 || S.rpm > 8000){ bad = true; printf("  bad state at step %d\n", i); } }
      Tune::manualBox = false; Tune::roadCond = 0; Tune::brakeFadeOn = false;
      printf("fuzz done: max |speed| %.0f km/h, max |yaw| %.2f rad/s, %s\n", maxV * 3.6, maxYaw, bad ? "BAD STATE" : "all states finite"); CHECK(!bad, "fuzz produced a non-finite or runaway state"); }

    printf("%s (%d failures)\n", fails ? "FAILED" : "ALL CHECKS PASSED", fails); return fails;
}
