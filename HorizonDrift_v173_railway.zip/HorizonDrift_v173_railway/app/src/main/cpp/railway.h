// Horizon Drift - SWISS RAILWAY: West End terminus -> Dorf -> Ost -> river viaduct -> Mountain-foot station -> tunnel -> cog railway up the big mountain.
//  * valley line on a low embankment (ballast, sleepers, rails), level crossings with the roads, concrete viaduct over the river
//  * 3 stations + 2 termini (platform, canopy, timber station building)  * rack rail + tunnel(s) with stone portals wherever the mountain covers the line
//  * Railway::blocked() keeps trees off the line. Static decoration (trains: later).
#pragma once
#include <GLES3/gl3.h>
#include <cmath>
#include <vector>
#include <algorithm>
#include <unordered_map>
#include "wetland.h"
#include "terrain.h"
#include "village.h"
#include "road.h"
#include "river.h"
#include "cablecar.h"

namespace Railway {
struct V3 { double x, y, z; };
struct Smp { double x, z, y, s, tx, tz; };
struct Stn { int i; int side; bool term; };
static std::vector<Smp> gS; static std::vector<char> gTun, gVia, gRiv; static std::vector<Stn> gStn; static int gIP = 0;
static std::vector<float> gV; static std::vector<uint32_t> gI; static GLuint gProg = 0, gVao = 0, gVbo = 0, gIbo = 0; static GLint uVP = -1, uCam = -1, uT = -1; static bool gOk = false, gPlanned = false; static GLsizei gCount = 0;
static std::unordered_map<long long, std::vector<int>> gGrid; static const double CELL = 16.0;
static inline long long ck(long cx, long cz){ return (long long)(cx + 100000) * 200003LL + (cz + 100000); }
static inline double sst(double a, double b, double x){ double t = std::min(std::max((x - a) / (b - a), 0.0), 1.0); return t*t*(3 - 2*t); }

// ---------- mesh helpers (same vertex layout as the cable car: pos, normal, colour, sway) ----------
static uint32_t vt(const V3& p, const V3& n, float r, float g, float b){ const uint32_t i = (uint32_t)(gV.size() / 10); const float a[10] = {(float)p.x, (float)p.y, (float)p.z, (float)n.x, (float)n.y, (float)n.z, r, g, b, 0.f}; gV.insert(gV.end(), a, a + 10); return i; }
static void quad(V3 a, V3 b, V3 c, V3 d, float r, float g, float bl){
    const double ux = b.x - a.x, uy = b.y - a.y, uz = b.z - a.z, wx = d.x - a.x, wy = d.y - a.y, wz = d.z - a.z; double nx = uy * wz - uz * wy, ny = uz * wx - ux * wz, nz = ux * wy - uy * wx; const double l = std::sqrt(nx*nx + ny*ny + nz*nz) + 1e-12; const V3 n = {nx / l, ny / l, nz / l};
    const uint32_t A = vt(a, n, r, g, bl), B = vt(b, n, r, g, bl), C = vt(c, n, r, g, bl), D = vt(d, n, r, g, bl); gI.insert(gI.end(), {A, B, C, A, C, D}); }
struct Fr { double ox, oz, tx, tz; };
static V3 W(const Fr& f, double u, double v, double y){ return {f.ox + f.tx * u - f.tz * v, y, f.oz + f.tz * u + f.tx * v}; }
static void box(const Fr& f, double u0, double u1, double v0, double v1, double y0, double y1, float r, float g, float b, bool bottom = false){
    V3 p[8] = {W(f,u0,v0,y0), W(f,u1,v0,y0), W(f,u1,v1,y0), W(f,u0,v1,y0), W(f,u0,v0,y1), W(f,u1,v0,y1), W(f,u1,v1,y1), W(f,u0,v1,y1)};
    quad(p[4], p[5], p[6], p[7], r, g, b); if (bottom) quad(p[0], p[3], p[2], p[1], r*0.5f, g*0.5f, b*0.5f);
    quad(p[0], p[1], p[5], p[4], r*0.9f, g*0.9f, b*0.9f); quad(p[1], p[2], p[6], p[5], r*0.8f, g*0.8f, b*0.8f); quad(p[2], p[3], p[7], p[6], r*0.9f, g*0.9f, b*0.9f); quad(p[3], p[0], p[4], p[7], r*0.8f, g*0.8f, b*0.8f);
}
static Fr frAt(int i){ const Smp& s = gS[i]; return {s.x, s.z, s.tx, s.tz}; }
static V3 P(int i, double lat, double dy){ const Smp& s = gS[i]; return {s.x - s.tz * lat, s.y + dy, s.z + s.tx * lat}; }
static void ribbon(int i, double a, double b, double ya, double yb, float r, float g, float bl){ quad(P(i, a, ya), P(i + 1, a, ya), P(i + 1, b, yb), P(i, b, yb), r, g, bl); }

// ---------- planning: path, heights, tunnel / viaduct flags ----------
static double gnd(double x, double z){ return Terrain::meshH(x, z); }
static void plan(){
    if (gPlanned) return; gPlanned = true; CableCar::plan();
    struct W2 { double x, z; };
    // valley line, read off the planning map (x, z): terminus -> Dorf -> Ost -> viaduct -> mountain foot -> portal
    std::vector<W2> wp = {{-1133,-381},{-1000,-310},{-850,-200},{-700,-60},{-560,60},{-425,135},{-300,163},{-130,172},{0,150},{100,143},{170,212},{215,270},{310,410},{450,517},{500,506},{552,488},{604,432}};
    const int nPortalWp = (int)wp.size() - 1, nStn1 = 5, nStn2 = 10, nStn3 = 13;
    double sx = 870, sz = -122, sy = 160; if (Terrain::PEAK.on){ sx = Terrain::PEAK.x; sz = Terrain::PEAK.z; sy = Terrain::PEAK.padY; }
    const double Rp = Road::gPark[2] > 45.f ? Road::gPark[2] : 60.0; const W2 po = wp[nPortalWp];
    double a0 = std::atan2(po.z - sz, po.x - sx) + 0.95, tx_ = sx + std::cos(a0) * (Rp - 10), tz_ = sz + std::sin(a0) * (Rp - 10);
    for (int k = 0; k < 14; k++){ bool hit = false; for (const Village::Building& b : Village::gB){ const double ex = tx_ - b.x, ez = tz_ - b.z; if (ex*ex + ez*ez < 20.0*20.0) hit = true; } { const double ex = tx_ - CableCar::gB.x, ez = tz_ - CableCar::gB.z; if (ex*ex + ez*ez < 26.0*26.0) hit = true; } if (!hit) break; a0 += 0.18; tx_ = sx + std::cos(a0) * (Rp - 10); tz_ = sz + std::sin(a0) * (Rp - 10); }
    const double dx = tx_ - po.x, dz = tz_ - po.z, dl = std::hypot(dx, dz), lx = -dz / dl, lz = dx / dl;     // cog line: gentle S-curve up the slope
    wp.push_back({po.x + dx * 0.30 + lx * 45, po.z + dz * 0.30 + lz * 45}); wp.push_back({po.x + dx * 0.62 - lx * 35, po.z + dz * 0.62 - lz * 35}); wp.push_back({tx_, tz_});
    // Catmull-Rom through the waypoints, resampled every 4 m
    std::vector<W2> dense; std::vector<int> wpDense(wp.size(), 0);
    for (size_t k = 0; k + 1 < wp.size(); k++){
        const W2 p0 = wp[k ? k - 1 : 0], p1 = wp[k], p2 = wp[k + 1], p3 = wp[k + 2 < wp.size() ? k + 2 : k + 1]; const int n = std::max(8, (int)(std::hypot(p2.x - p1.x, p2.z - p1.z) / 2.0)); wpDense[k] = (int)dense.size();
        for (int j = 0; j < n; j++){ const double t = (double)j / n, t2 = t*t, t3 = t2*t; auto cr = [&](double a, double b, double c, double d){ return 0.5 * ((2*b) + (-a + c) * t + (2*a - 5*b + 4*c - d) * t2 + (-a + 3*b - 3*c + d) * t3); }; dense.push_back({cr(p0.x, p1.x, p2.x, p3.x), cr(p0.z, p1.z, p2.z, p3.z)}); } }
    wpDense[wp.size() - 1] = (int)dense.size(); dense.push_back(wp.back());
    std::vector<double> ds(dense.size(), 0.0); for (size_t i = 1; i < dense.size(); i++) ds[i] = ds[i-1] + std::hypot(dense[i].x - dense[i-1].x, dense[i].z - dense[i-1].z);
    std::vector<W2> pt; std::vector<int> wpS(wp.size(), 0); { const double STEP = 4.0; double next = 0; size_t k = 0; const double total = ds.back();
        for (; next < total; next += STEP){ while (k + 1 < dense.size() && ds[k + 1] < next) k++; const double f = (ds[k+1] - ds[k]) > 1e-9 ? (next - ds[k]) / (ds[k+1] - ds[k]) : 0; pt.push_back({dense[k].x + (dense[k+1].x - dense[k].x) * f, dense[k].z + (dense[k+1].z - dense[k].z) * f}); }
        pt.push_back(dense.back()); for (size_t w = 0; w < wp.size(); w++){ int best = 0; double bd = 1e18; for (size_t i = 0; i < pt.size(); i++){ const double e = std::hypot(pt[i].x - wp[w].x, pt[i].z - wp[w].z); if (e < bd){ bd = e; best = (int)i; } } wpS[w] = best; } }
    const int N = (int)pt.size(); const int iP = wpS[nPortalWp]; gIP = iP;
    // keep clear of chalets and of the cable car (except the terminus ends)
    for (int it = 0; it < 6; it++){
        for (int i = 1; i < N - 1; i++){
            for (const Village::Building& b : Village::gB){ const double ex = pt[i].x - b.x, ez = pt[i].z - b.z, d2 = ex*ex + ez*ez, R = 17.0; if (d2 < R*R && d2 > 1e-6){ const double d = std::sqrt(d2), k = (R - d) * 0.6; pt[i].x += ex / d * k; pt[i].z += ez / d * k; } }
            if (i > iP - 6){ const double ax = CableCar::gA.x, az = CableCar::gA.z, bx = CableCar::gB.x - ax, bz = CableCar::gB.z - az, L2 = bx*bx + bz*bz; double t = ((pt[i].x - ax) * bx + (pt[i].z - az) * bz) / L2; t = std::min(std::max(t, 0.0), 1.0); const double qx = ax + bx * t, qz = az + bz * t, ex = pt[i].x - qx, ez = pt[i].z - qz, d = std::hypot(ex, ez), R = 16.0; if (d < R && d > 1e-6){ pt[i].x += ex / d * (R - d) * 0.7; pt[i].z += ez / d * (R - d) * 0.7; } }
        }
        for (int pass = 0; pass < 3; pass++){ std::vector<W2> q = pt; for (int i = 1; i < N - 1; i++){ q[i].x = (pt[i-1].x + 2*pt[i].x + pt[i+1].x) * 0.25; q[i].z = (pt[i-1].z + 2*pt[i].z + pt[i+1].z) * 0.25; } pt = q; }
    }
    gS.assign(N, Smp()); double s = 0; for (int i = 0; i < N; i++){ if (i) s += std::hypot(pt[i].x - pt[i-1].x, pt[i].z - pt[i-1].z); gS[i].x = pt[i].x; gS[i].z = pt[i].z; gS[i].s = s; }
    for (int i = 0; i < N; i++){ const int a = std::max(0, i - 1), b = std::min(N - 1, i + 1); double tx = gS[b].x - gS[a].x, tz = gS[b].z - gS[a].z; const double l = std::hypot(tx, tz) + 1e-9; gS[i].tx = tx / l; gS[i].tz = tz / l; }
    // heights
    std::vector<double> gc(N), gm(N), rd(N); gRiv.assign(N, 0); gTun.assign(N, 0); gVia.assign(N, 0);
    for (int i = 0; i < N; i++){ gc[i] = gnd(gS[i].x, gS[i].z); double m = gc[i]; for (double lat : {-5.0, -2.5, 2.5, 5.0}) m = std::max(m, gnd(gS[i].x - gS[i].tz * lat, gS[i].z + gS[i].tx * lat)); gm[i] = m; rd[i] = std::fabs(River::riverSd(gS[i].x, gS[i].z)); gRiv[i] = (i < iP && rd[i] < 30.0) ? 1 : 0; }
    auto smooth = [&](std::vector<double>& a, int lo, int hi, int passes, int rad){ for (int p = 0; p < passes; p++){ std::vector<double> q = a; for (int i = lo; i <= hi; i++){ double sum = 0; int c = 0; for (int j = std::max(lo, i - rad); j <= std::min(hi, i + rad); j++){ sum += a[j]; c++; } q[i] = sum / c; } a = q; } };
    std::vector<double> gp = gm;                                                                           // river span: take the bank height instead of the river bed
    for (int i = 0; i < iP; i++) if (gRiv[i]){ int a = i, b = i; while (a > 0 && gRiv[a]) a--; while (b < iP && gRiv[b]) b++; gp[i] = std::max(gm[a], gm[std::min(b, iP)]); }
    std::vector<double> y(N, 0), dr(N, 1e9); { int last = -100000; for (int i = 0; i < iP; i++){ if (gRiv[i]) last = i; dr[i] = (i - last) * 4.0; } last = 100000; for (int i = iP - 1; i >= 0; i--){ if (gRiv[i]) last = i; dr[i] = std::min(dr[i], (last - i) * 4.0); } }
    std::vector<double> ys = gp; smooth(ys, 0, iP, 4, 6);
    for (int i = 0; i <= iP; i++){ y[i] = ys[i] + 0.35 + 3.4 * (1.0 - sst(8.0, 60.0, dr[i])); if (!gRiv[i]) y[i] = std::max(y[i], gm[i] + 0.25); }
    smooth(y, 0, iP, 2, 2); for (int i = 0; i <= iP; i++) if (!gRiv[i]) y[i] = std::max(y[i], gm[i] + 0.2);
    // cog part: follows the mountain (smoothed), buried 9 m for the first ~250 m (the mountain-foot tunnel), then daylight; max grade 40 %
    const double yT = (Terrain::PEAK.on && Terrain::PEAK.padOn ? sy : gc[N - 1]) + 0.3;
    std::vector<double> yb = gm; smooth(yb, iP, N - 1, 5, 14);
    for (int i = iP; i < N; i++){ const double sr = gS[i].s - gS[iP].s; yb[i] -= 9.0 * (1.0 - sst(240.0, 380.0, sr)); }
    yb[iP] = y[iP]; yb[N - 1] = yT; const double MG = 1.6;                                                  // 0.40 * 4 m
    for (int it = 0; it < 4; it++){ yb[iP] = y[iP]; for (int i = iP + 1; i < N; i++) yb[i] = std::min(std::max(yb[i], yb[i-1] - MG), yb[i-1] + MG);
        yb[N - 1] = yT; for (int i = N - 2; i >= iP; i--) yb[i] = std::min(std::max(yb[i], yb[i+1] - MG), yb[i+1] + MG); }      // grade limit, pinned at both ends (backward pass last: the summit is exact)
    for (int i = iP + 1; i < N; i++) y[i] = yb[i];
    { bool in = false; for (int i = iP + 1; i < N; i++){ const double c = gm[i] - yb[i]; if (!in && c > 1.5) in = true; else if (in && c < 0.3) in = false; gTun[i] = in; }
      for (int i = iP; i < N; ){ if (!gTun[i]){ i++; continue; } int j = i; while (j < N && gTun[j]) j++; if (j - i < 10 && j < N) for (int k = i; k < j; k++) gTun[k] = 0; i = j; } }   // runs under 40 m are cuttings, not tunnels
    for (int i = std::max(iP + 1, N - 26); i < N; i++) gTun[i] = 0;                                        // the last 100 m are in the open: the summit station
    { std::vector<double> yo = y; for (int i = iP + 1; i < N; i++) if (!gTun[i]) yo[i] = std::max(yb[i], gm[i] + 0.2); int i = iP + 1; while (i < N){ if (gTun[i]){ i++; continue; } int j = i; while (j < N && !gTun[j]) j++; smooth(yo, i, j - 1, 3, 3); i = j; } for (int k = iP + 1; k < N; k++) y[k] = gTun[k] ? yb[k] : std::max(yo[k], gm[k] + 0.2); }
    for (int i = 0; i < N; i++){ gS[i].y = y[i]; gVia[i] = (!gTun[i] && (y[i] - gc[i] > 3.2 || gRiv[i])) ? 1 : 0; }
    for (int i = 0; i < N; i++){ const long long k = ck((long)std::floor(gS[i].x / CELL), (long)std::floor(gS[i].z / CELL)); gGrid[k].push_back(i); }
    // stations: West End, Dorf, Ost, Mountain foot, summit; the building goes on the side with more room
    auto side = [&](int i){ double sc[2]; int idx = 0; for (int sgn : {1, -1}){ double m = 1e9; const double cx = gS[i].x - gS[i].tz * sgn * 11.0, cz = gS[i].z + gS[i].tx * sgn * 11.0; for (const Village::Building& b : Village::gB) m = std::min(m, std::hypot(cx - b.x, cz - b.z)); m = std::min(m, std::fabs(River::riverSd(cx, cz)) + 10.0); sc[idx++] = m; } return sc[0] >= sc[1] ? 1 : -1; };
    gStn.clear(); for (int idx : {0, wpS[nStn1], wpS[nStn2], wpS[nStn3], N - 1}) gStn.push_back({std::min(N - 6, std::max(6, idx)), 1, idx == 0 || idx == N - 1}); for (Stn& st : gStn) st.side = side(st.i);
    gStn.front().i = 6; gStn.back().i = N - 6;
}
static bool blocked(double x, double z, double margin){
    if (!gPlanned) return false; const long cx = (long)std::floor(x / CELL), cz = (long)std::floor(z / CELL);
    for (int a = -1; a <= 1; a++) for (int b = -1; b <= 1; b++){ auto it = gGrid.find(ck(cx + a, cz + b)); if (it == gGrid.end()) continue; for (int i : it->second){ const double dx = x - gS[i].x, dz = z - gS[i].z, r = 5.5 + margin; if (dx*dx + dz*dz < r*r) return true; } }
    for (const Stn& st : gStn){ const double dx = x - gS[st.i].x, dz = z - gS[st.i].z, r = 22.0 + margin; if (dx*dx + dz*dz < r*r) return true; }
    return false;
}

// ---------- building the mesh ----------
static void stationBuilding(const Stn& st){
    const Fr f = frAt(st.i); const double y = gS[st.i].y, sg = st.side; const double pl = 24.0;
    box(f, -pl, pl, sg * 2.15, sg * 5.6, y - 2.5, y + 0.5, 0.70f, 0.69f, 0.66f);                                    // platform
    box(f, -pl, pl, sg * 2.15, sg * 2.35, y + 0.5, y + 0.52, 0.92f, 0.80f, 0.12f);                                   // yellow safety edge
    for (double u : {-pl + 2, -pl / 2, 0.0, pl / 2, pl - 2}) box(f, u - 0.1, u + 0.1, sg * 5.3 - 0.1, sg * 5.3 + 0.1, y + 0.5, y + 3.6, 0.30f, 0.22f, 0.15f);       // canopy posts
    box(f, -pl, pl, sg * 2.5, sg * 6.4, y + 3.6, y + 3.85, 0.30f, 0.21f, 0.14f);                                      // canopy roof
    const double v0 = sg * 8.5, v1 = sg * 14.5, lo = std::min(v0, v1), hi = std::max(v0, v1), hl = 7.0;
    box(f, -hl, hl, lo, hi, y - 3.0, y + 0.5, 0.62f, 0.60f, 0.57f);                                                    // stone plinth
    box(f, -hl + 0.2, hl - 0.2, lo + 0.2, hi - 0.2, y + 0.5, y + 4.6, 0.84f, 0.77f, 0.60f);                           // walls
    for (int k = -2; k <= 2; k++) box(f, k * 2.4 - 0.5, k * 2.4 + 0.5, sg * 8.5 - 0.06, sg * 8.5 + 0.06, y + 1.6, y + 3.4, 0.18f, 0.22f, 0.26f);   // windows toward the platform
    const double ry = y + 4.6, ov = 1.2, rh = 2.6; V3 e0 = W(f, -hl - ov, lo - ov, ry), e1 = W(f, -hl - ov, hi + ov, ry), e2 = W(f, hl + ov, hi + ov, ry), e3 = W(f, hl + ov, lo - ov, ry), r0 = W(f, -hl - ov, (lo + hi) / 2, ry + rh), r1 = W(f, hl + ov, (lo + hi) / 2, ry + rh);
    quad(e3, e0, r0, r1, 0.45f, 0.20f, 0.14f); quad(e1, e2, r1, r0, 0.50f, 0.22f, 0.15f); quad(e0, e1, r0, e0, 0.40f, 0.18f, 0.12f); quad(e2, e3, r1, e2, 0.40f, 0.18f, 0.12f);   // red-brown gable roof + gable ends
    box(f, hl - 1.5, hl - 0.5, (lo + hi) / 2 - 0.5, (lo + hi) / 2 + 0.5, ry + rh, ry + rh + 1.4, 0.55f, 0.52f, 0.50f);   // chimney
    if (st.term){ const int e = st.i < 20 ? 0 : (int)gS.size() - 1; const Fr g = frAt(e); const double dir = st.i < 20 ? -1.0 : 1.0; (void)dir; box(g, -0.8, 0.4, -1.3, 1.3, gS[e].y + 0.1, gS[e].y + 1.1, 0.70f, 0.12f, 0.10f); }   // buffer stop
}
static void build(){
    plan(); const int N = (int)gS.size(); if (N < 10) return;
    for (int i = 0; i + 1 < N; i++){
        const double y = gS[i].y;
        quad(P(i, -1.9, 0), P(i + 1, -1.9, 0), P(i + 1, 1.9, 0), P(i, 1.9, 0), 0.47f, 0.46f, 0.44f);                  // ballast top
        ribbon(i, -2.4, -1.9, -0.45, 0, 0.40f, 0.39f, 0.37f); ribbon(i, 1.9, 2.4, 0, -0.45, 0.40f, 0.39f, 0.37f);
        for (int sg : {-1, 1}){ const double a = sg * 0.72; ribbon(i, a - 0.05, a + 0.05, 0.34, 0.34, 0.62f, 0.62f, 0.65f); ribbon(i, a + 0.05, a + 0.05, 0.14, 0.34, 0.40f, 0.40f, 0.43f); ribbon(i, a - 0.05, a - 0.05, 0.34, 0.14, 0.40f, 0.40f, 0.43f); }
        const bool cog = i >= gIP; const Smp &a = gS[i], &b = gS[i + 1];
        for (double u = 0; u < 4.0; u += 0.85){ const double f = u / 4.0, ox = a.x + (b.x - a.x) * f, oz = a.z + (b.z - a.z) * f, oy = a.y + (b.y - a.y) * f; const Fr fr = {ox, oz, a.tx, a.tz}; box(fr, -0.13, 0.13, -1.3, 1.3, oy, oy + 0.14, 0.27f, 0.20f, 0.15f); }
        if (cog){ ribbon(i, -0.09, 0.09, 0.44, 0.44, 0.34f, 0.34f, 0.38f); for (double u = 0.2; u < 4.0; u += 0.6){ const double f = u / 4.0, ox = a.x + (b.x - a.x) * f, oz = a.z + (b.z - a.z) * f, oy = a.y + (b.y - a.y) * f; const Fr fr = {ox, oz, a.tx, a.tz}; box(fr, -0.06, 0.06, -0.16, 0.16, oy + 0.14, oy + 0.54, 0.26f, 0.26f, 0.30f); } }   // rack rail + teeth
        if (gTun[i] && gTun[i + 1]){                                                                                   // tunnel tube: dark inside, concrete outside
            for (int sg : {-1, 1}){ quad(P(i, sg * 3.0, -0.3), P(i + 1, sg * 3.0, -0.3), P(i + 1, sg * 3.0, 4.4), P(i, sg * 3.0, 4.4), 0.08f, 0.08f, 0.09f); quad(P(i, sg * 3.45, -0.3), P(i + 1, sg * 3.45, -0.3), P(i + 1, sg * 3.45, 4.85), P(i, sg * 3.45, 4.85), 0.55f, 0.54f, 0.52f); }
            quad(P(i, -3.0, 4.4), P(i + 1, -3.0, 4.4), P(i + 1, 3.0, 4.4), P(i, 3.0, 4.4), 0.06f, 0.06f, 0.07f); quad(P(i, -3.45, 4.85), P(i + 1, -3.45, 4.85), P(i + 1, 3.45, 4.85), P(i, 3.45, 4.85), 0.55f, 0.54f, 0.52f);
        } else if (gVia[i] && gVia[i + 1]){                                                                             // viaduct: slab + parapets (+ pillars below)
            quad(P(i, -2.8, -0.08), P(i + 1, -2.8, -0.08), P(i + 1, 2.8, -0.08), P(i, 2.8, -0.08), 0.60f, 0.60f, 0.58f); ribbon(i, -2.8, -2.8, -1.05, -0.08, 0.55f, 0.55f, 0.53f); ribbon(i, 2.8, 2.8, -0.08, -1.05, 0.55f, 0.55f, 0.53f); ribbon(i, -2.8, 2.8, -1.05, -1.05, 0.40f, 0.40f, 0.40f);
            for (int sg : {-1, 1}){ ribbon(i, sg * 2.8, sg * 2.8, -0.08, 0.62, 0.72f, 0.72f, 0.70f); ribbon(i, sg * 2.55, sg * 2.8, 0.62, 0.62, 0.78f, 0.78f, 0.76f); ribbon(i, sg * 2.55, sg * 2.55, 0.62, -0.08, 0.66f, 0.66f, 0.64f); }
            if (i % 4 == 0){ const double g = gnd(a.x, a.z); const Fr fr = frAt(i); box(fr, -0.9, 0.9, -2.1, 2.1, g - 2.0, y - 1.0, 0.68f, 0.67f, 0.64f); box(fr, -1.1, 1.1, -2.4, 2.4, y - 1.9, y - 1.0, 0.64f, 0.63f, 0.60f); }   // pier + cap
        } else if (!gTun[i]){                                                                                           // embankment slopes down to the meadow
            for (int sg : {-1, 1}){ const double gs = gnd(a.x - a.tz * sg * 3.0, a.z + a.tx * sg * 3.0), w = std::min(std::max((y - 0.45 - gs) * 1.5, 0.6), 12.0); const V3 o = {a.x - a.tz * sg * (2.4 + w), 0, a.z + a.tx * sg * (2.4 + w)}, o2 = {b.x - b.tz * sg * (2.4 + w), 0, b.z + b.tx * sg * (2.4 + w)};
                const double h1 = gnd(o.x, o.z) - 0.1, h2 = gnd(o2.x, o2.z) - 0.1; if (h1 > y - 0.5 || h2 > b.y - 0.5) continue; quad(P(i, sg * 2.4, -0.45), P(i + 1, sg * 2.4, -0.45), {o2.x, h2, o2.z}, {o.x, h1, o.z}, 0.34f, 0.37f, 0.24f); }
        }
        (void)y;
    }
    for (int i = 1; i + 1 < N; i++){                                                                                   // tunnel portals: stone frame at both ends of every tunnel
        const bool start = gTun[i] && !gTun[i - 1], end = gTun[i] && !gTun[i + 1]; if (!start && !end) continue; const Fr f = frAt(i); const double y = gS[i].y, u = start ? -0.6 : 0.6;
        for (int sg : {-1, 1}) box(f, u - 0.6, u + 0.6, sg * 3.0 - (sg < 0 ? 1.8 : 0), sg * 3.0 + (sg > 0 ? 1.8 : 0), y - 0.4, y + 5.7, 0.60f, 0.58f, 0.55f);
        box(f, u - 0.6, u + 0.6, -4.8, 4.8, y + 4.4, y + 5.7, 0.62f, 0.60f, 0.57f); box(f, u - 0.75, u + 0.75, -5.0, 5.0, y + 5.7, y + 6.0, 0.50f, 0.49f, 0.47f);
    }
    for (int i = 2; i + 8 < gIP; i++){                                                                                 // level crossings: boards over the rails + St Andrew's crosses
        if (gRiv[i] || Road::clearance((float)gS[i].x, (float)gS[i].z) > 0.3f || Road::clearance((float)gS[i - 1].x, (float)gS[i - 1].z) <= 0.3f) continue; int j = i; while (j < gIP && Road::clearance((float)gS[j].x, (float)gS[j].z) <= 0.3f) j++;
        for (int k = i - 1; k < j && k + 1 < N; k++) ribbon(k, -2.2, 2.2, 0.16, 0.16, 0.20f, 0.20f, 0.21f);
        for (int sg : {-1, 1}){ const int k = sg < 0 ? std::max(0, i - 2) : std::min(N - 1, j + 1); const Fr f = frAt(k); const double y = gS[k].y, v = sg * 4.6; box(f, -0.07, 0.07, v - 0.07, v + 0.07, y, y + 2.6, 0.85f, 0.85f, 0.85f); box(f, -0.04, 0.04, v - 0.8, v + 0.8, y + 2.2, y + 2.6, 0.85f, 0.12f, 0.10f); box(f, -0.05, 0.05, v - 0.8, v + 0.8, y + 2.0, y + 2.2, 0.95f, 0.95f, 0.95f); }
        i = j;
    }
    for (const Stn& st : gStn) stationBuilding(st);
}
static void init(){
    if (gOk) return; build(); if (gI.empty()) return;
    gProg = glCreateProgram(); glAttachShader(gProg, Wetland::sh(GL_VERTEX_SHADER, Wetland::VS)); glAttachShader(gProg, Wetland::sh(GL_FRAGMENT_SHADER, Wetland::FS)); glLinkProgram(gProg); SunLight::attach(gProg);
    uVP = glGetUniformLocation(gProg, "uVP"); uCam = glGetUniformLocation(gProg, "uCam"); uT = glGetUniformLocation(gProg, "uT");
    glGenVertexArrays(1, &gVao); glBindVertexArray(gVao); glGenBuffers(1, &gVbo); glBindBuffer(GL_ARRAY_BUFFER, gVbo); glBufferData(GL_ARRAY_BUFFER, gV.size() * 4, gV.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 40, (void*)0); glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 40, (void*)12);
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 40, (void*)24); glEnableVertexAttribArray(3); glVertexAttribPointer(3, 1, GL_FLOAT, GL_FALSE, 40, (void*)36);
    glGenBuffers(1, &gIbo); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gIbo); glBufferData(GL_ELEMENT_ARRAY_BUFFER, gI.size() * 4, gI.data(), GL_STATIC_DRAW); glBindVertexArray(0);
    gCount = (GLsizei)gI.size(); std::vector<float>().swap(gV); std::vector<uint32_t>().swap(gI); gOk = true;
}
static void draw(const float* VP, const float* eye, float time){
    if (!gOk) return; glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glDisable(GL_BLEND); glUseProgram(gProg); glUniformMatrix4fv(uVP, 1, GL_FALSE, VP); glUniform3fv(uCam, 1, eye); glUniform1f(uT, time);
    glBindVertexArray(gVao); glDrawElements(GL_TRIANGLES, gCount, GL_UNSIGNED_INT, (void*)0); glBindVertexArray(0);
}
}
