// Sunny Drift - OpenGL ES 3 rendering of the rolling hills and the distant mountain ring (see terrain.h).
//  The hills next to the river patch are two strips of the same 4 m lattice; the river patch itself (BridgeGL::drawTerrain) already carries
//  the hills inside its area. Both use the river-bed shader (vertex colour x sun + haze). The dirt track is drawn by RoadGL (mud material).
#pragma once
#include "terrain.h"
#include "bridge_render.h"

namespace TerrainGL {

static BridgeGL::Gpu gSouth, gNorth, gMountains;

// Call once with a current GL context, after Terrain::init() and BridgeGL::init() (it re-uses the bridge's terrain shader).
static void init(){
    auto up = [](const Terrain::GMesh& m){ const int n[3] = {3, 3, 3}, o[3] = {0, 12, 24}; return BridgeGL::upload(m.v.data(), m.v.size() * 4, m.idx, 36, n, o, 3); };
    gSouth = up(Terrain::gMeshes.southHills); gNorth = up(Terrain::gMeshes.northHills); gMountains = up(Terrain::gMeshes.mountains);
}

static void draw(const float* VP, const float* eye){
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE);
    glUseProgram(BridgeGL::gProgT); glUniformMatrix4fv(BridgeGL::uT_VP, 1, GL_FALSE, VP); glUniform3fv(BridgeGL::uT_Cam, 1, eye);
    BridgeGL::drawGpu(gSouth); BridgeGL::drawGpu(gNorth); BridgeGL::drawGpu(gMountains);
}

} // namespace TerrainGL
