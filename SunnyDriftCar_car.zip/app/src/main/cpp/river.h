// Sunny Drift - river: C++ port of the HTML "River constants" / groundH() block (pure C++, no OpenGL).
//  * RIVER_CTRL is the same hand-traced centre line as in the HTML, sampled with the same Catmull-Rom spline
//  * riverSd() = signed distance from that line (the bridges, the road cuts, the walls and the trees all use it)
//  * riverGroundH() = the carved river bed (bank slope + noise), terrainMesh()/waterMesh() build the visible river
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <unordered_map>
#include <vector>

namespace River {

static const double RIVER_WALL = 24, RIVER_DEPTH = 3.2, WATER_Y = -1.3;
static const int RV_CELL = 64; static const double RV_RANGE = 280;

static std::vector<double> RV_X, RV_Z;
static std::unordered_map<int, std::vector<int>> rvGrid;
static double gGx = 0, gGz = 1;          // unit vector pointing away from the river centre line (gradient of riverSd)
static bool ready = false;
static double FSEED0 = 0.5;               // per-launch noise seed (FSEED[0] in the HTML); Terrain::setSeed() overwrites it

static inline double sstep(double a, double b, double x){ double t = std::min(std::max((x - a) / (b - a), 0.0), 1.0); return t*t*(3 - 2*t); }

static void init(){
    if (ready) return; ready = true;
    static const double P[19][2] = {{-882,-47},{-533,-70},{-465,-69},{-397,-79},{-328,-89},{-260,-91},{-192,-81},{-124,-60},{-56,-30},{12,12},
        {80,73},{148,160},{216,254},{284,299},{352,326},{420,331},{488,314},{550,286},{881,173}};
    const int n = 19;
    for (int i = 0; i < n - 1; i++){
        const double *p0 = P[std::max(i-1, 0)], *p1 = P[i], *p2 = P[i+1], *p3 = P[std::min(i+2, n-1)];
        const int m = std::max(2, (int)std::ceil(std::hypot(p2[0]-p1[0], p2[1]-p1[1]) / 10));
        for (int k = 0; k < m; k++){
            const double t = (double)k / m, t2 = t*t, t3 = t2*t;
            for (int c = 0; c < 2; c++){
                const double v = 0.5 * ((2*p1[c]) + (-p0[c]+p2[c])*t + (2*p0[c]-5*p1[c]+4*p2[c]-p3[c])*t2 + (-p0[c]+3*p1[c]-3*p2[c]+p3[c])*t3);
                (c ? RV_Z : RV_X).push_back(v);
            }
        }
    }
    RV_X.push_back(P[n-1][0]); RV_Z.push_back(P[n-1][1]);
    for (int cx = -24; cx <= 24; cx++) for (int cz = -24; cz <= 24; cz++){
        const double mx = (cx + 0.5) * RV_CELL, mz = (cz + 0.5) * RV_CELL, lim = RV_RANGE + 0.72 * RV_CELL; std::vector<int> list;
        for (size_t i = 0; i + 1 < RV_X.size(); i++){
            const double ax = RV_X[i], az = RV_Z[i], bx = RV_X[i+1] - ax, bz = RV_Z[i+1] - az, bb = bx*bx + bz*bz;
            const double t = std::min(std::max(((mx-ax)*bx + (mz-az)*bz) / (bb == 0 ? 1 : bb), 0.0), 1.0), dx = mx - ax - bx*t, dz = mz - az - bz*t;
            if (dx*dx + dz*dz < lim*lim) list.push_back((int)i);
        }
        if (!list.empty()) rvGrid[(cx + 32) * 128 + (cz + 32)] = list;
    }
}

static double riverSd(double x, double z){
    auto it = rvGrid.find((int)(std::floor(x / RV_CELL) + 32) * 128 + (int)(std::floor(z / RV_CELL) + 32));
    if (it == rvGrid.end()){ gGx = 0; gGz = 1; return 9999; }
    double bd = 1e18, bs = 1, bgx = 0, bgz = 1;
    for (int i : it->second){
        const double ax = RV_X[i], az = RV_Z[i], bx = RV_X[i+1] - ax, bz = RV_Z[i+1] - az; double bb = bx*bx + bz*bz; if (bb == 0) bb = 1;
        const double t = std::min(std::max(((x-ax)*bx + (z-az)*bz) / bb, 0.0), 1.0), ox = x - ax - bx*t, oz = z - az - bz*t, d2 = ox*ox + oz*oz;
        if (d2 < bd){
            bd = d2; const double bl = std::sqrt(bb); bs = (ox*bz - oz*bx) >= 0 ? 1 : -1; bgx = bz / bl; bgz = -bx / bl;
            if (d2 > 1e-8){ const double d = std::sqrt(d2); bgx = ox / d * bs; bgz = oz / d * bs; }
        }
    }
    gGx = bgx; gGz = bgz; return bs * std::sqrt(bd);
}

// ---- fNoise (value noise) used to make the bank wander in and out ----
static double fHash(double x, double y){ const double h = std::sin(x*127.1 + y*311.7 + FSEED0 * 0.37) * 43758.5453; return h - std::floor(h); }
static double fNoise(double x, double y){
    const double ix = std::floor(x), iy = std::floor(y), fx = x - ix, fy = y - iy, u = fx*fx*(3 - 2*fx), v = fy*fy*(3 - 2*fy);
    return (fHash(ix, iy)*(1-u) + fHash(ix+1, iy)*u)*(1-v) + (fHash(ix, iy+1)*(1-u) + fHash(ix+1, iy+1)*u)*v;
}
// height of the carved river bed (groundH in the HTML without the sea part): 0 on dry land, down to -3.2 m in the channel
static double groundH(double x, double z){
    double d = std::fabs(riverSd(x, z)), rv = 0;
    if (d < 33){
        d += (fNoise(x/46 + 3.1, z/46 - 1.7) - 0.5) * 5.0 + (fNoise(x/13 - 4.2, z/13 + 8.8) - 0.5) * 1.7;
        const double t = std::min(std::max((d - 11) / 17, 0.0), 1.0);
        rv = d >= 28 ? 0 : -RIVER_DEPTH * (1 - t*t*(3 - 2*t) * (0.88 + 0.12*t));
    }
    return rv;
}

// ---- visible river: terrain patch (grass -> wet mud -> gravel) + water surface ----
// terrain vertex = pos(3) colour(3) normal(3);  water vertex = pos(3) depth(1)
struct TerrainMesh { std::vector<float> v; std::vector<uint32_t> idx; };
struct WaterMesh   { std::vector<float> v; std::vector<uint32_t> idx; };
static const double GX0 = -960, GX1 = 960, GZ0 = -230, GZ1 = 460, GCELL = 4.0;     // patch that is carved (ground quad has a hole here)
static const int PNX = 480, PNZ = 173;                                              // cells of the patch (round((GX1-GX0)/GCELL), round((GZ1-GZ0)/GCELL))
static const double PZ1 = GZ0 + PNZ * GCELL;                                        // real far edge of the patch (462)

// optional extras supplied by Terrain: hill height added to the bed, and the grass base colour (hills / sand / dirt tint)
struct Hooks {
    double (*fieldH)(double x, double z) = nullptr;
    void (*grass)(double x, double z, double fieldH, double& r, double& g, double& b) = nullptr;
};

static Hooks gHooks;                                                                // filled by Terrain::init

static void buildTerrain(TerrainMesh& tm, WaterMesh& wm, const Hooks* hk = nullptr){
    const int nx = PNX, nz = PNZ, W = nx + 1;
    auto hAt = [&](double x, double z){ return groundH(x, z) + (hk && hk->fieldH ? hk->fieldH(x, z) : 0.0); };
    std::vector<float> H((size_t)W * (nz + 1)), D((size_t)W * (nz + 1)), F((size_t)W * (nz + 1));
    for (int j = 0; j <= nz; j++) for (int i = 0; i <= nx; i++){
        const double x = GX0 + i * GCELL, z = GZ0 + j * GCELL; const size_t k = (size_t)j*W + i;
        const double f = hk && hk->fieldH ? hk->fieldH(x, z) : 0.0;
        F[k] = (float)f; H[k] = (float)(groundH(x, z) + f); D[k] = (float)std::fabs(riverSd(x, z));
    }
    // height with one extra ring around the patch so the edge normals are true central differences (they must match the neighbouring hill strips)
    auto hv = [&](int i, int j) -> double {
        if (i >= 0 && i <= nx && j >= 0 && j <= nz) return H[(size_t)j*W + i];
        return hAt(GX0 + i * GCELL, GZ0 + j * GCELL);
    };
    tm.v.reserve((size_t)W * (nz + 1) * 9);
    for (int j = 0; j <= nz; j++) for (int i = 0; i <= nx; i++){
        const size_t k = (size_t)j*W + i; const double h = H[k], x = GX0 + i * GCELL, z = GZ0 + j * GCELL;
        const double hxm = hv(i-1, j), hxp = hv(i+1, j), hzm = hv(i, j-1), hzp = hv(i, j+1);
        double nxv = (hxm - hxp) / (2*GCELL), nzv = (hzm - hzp) / (2*GCELL), l = std::sqrt(nxv*nxv + nzv*nzv + 1);
        // colours: project grass -> pale dry lip -> dark wet mud at the water line -> gravel / sand under the water
        double r = 0.30, g = 0.58, b = 0.25;
        if (hk && hk->grass) hk->grass(x, z, F[k], r, g, b);
        const double dwl = h - WATER_Y;                                  // metres above the water line
        const double bank = 1 - sstep(21, 33, D[k]);                     // damp strip along the river
        auto mix3 = [&](double a0, double a1, double a2, double t){ r += (a0 - r) * t; g += (a1 - g) * t; b += (a2 - b) * t; };
        mix3(0.42, 0.36, 0.22, bank * 0.55);                              // dry pale soil lip above the water
        if (dwl < 0.9) mix3(0.20, 0.16, 0.10, 1 - sstep(0.0, 0.9, dwl));  // dark wet mud at the water line
        if (dwl < 0) mix3(0.46, 0.42, 0.30, sstep(0.0, 0.6, -dwl));       // gravel / sand under the water
        float row[9] = {(float)x, (float)h, (float)z, (float)r, (float)g, (float)b, (float)(nxv / l), (float)(1 / l), (float)(nzv / l)};
        tm.v.insert(tm.v.end(), row, row + 9);
    }
    for (int j = 0; j < nz; j++) for (int i = 0; i < nx; i++){
        const uint32_t a = j*W + i, b = a + 1, c = a + W, d = c + 1; const uint32_t t[6] = {a, c, b, b, c, d};
        tm.idx.insert(tm.idx.end(), t, t + 6);
    }
    // water: cells that touch at least one wet vertex. depth = metres of water above the bed (negative = dry)
    std::vector<int> map((size_t)W * (nz + 1), -1);
    auto vert = [&](int i, int j) -> uint32_t {
        int& m = map[(size_t)j*W + i];
        if (m < 0){ m = (int)(wm.v.size() / 4); const float row[4] = {(float)(GX0 + i*GCELL), (float)WATER_Y, (float)(GZ0 + j*GCELL), (float)(WATER_Y - H[(size_t)j*W + i])}; wm.v.insert(wm.v.end(), row, row + 4); }
        return (uint32_t)m;
    };
    for (int j = 0; j < nz; j++) for (int i = 0; i < nx; i++){
        const float *h0 = &H[(size_t)j*W + i], *h1 = &H[(size_t)(j+1)*W + i];
        if (!(h0[0] < WATER_Y + 0.05 || h0[1] < WATER_Y + 0.05 || h1[0] < WATER_Y + 0.05 || h1[1] < WATER_Y + 0.05)) continue;
        const uint32_t a = vert(i, j), b = vert(i+1, j), c = vert(i, j+1), d = vert(i+1, j+1); const uint32_t t[6] = {a, c, b, b, c, d};
        wm.idx.insert(wm.idx.end(), t, t + 6);
    }
}

} // namespace River
