// Sunny Drift - OpenGL ES 3 rendering of the river (carved bed + water) and the wooden bridges (see river.h / bridge.h).
//  draw order = HTML: river bed -> roads -> bridge deck / beams / rails / posts (opaque) -> water -> dirt + road-blend overlays (blended)
#pragma once
#include <GLES3/gl3.h>
#include <cstring>
#include "bridge.h"
#include "road_render.h"

namespace BridgeGL {

static const char* TER_VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in vec3 c; layout(location=2) in vec3 n;
uniform mat4 uVP; out vec3 vC; out vec3 vN; out vec3 wp;
void main(){ vC = c; vN = n; wp = p; gl_Position = uVP * vec4(p, 1.0); }
)GLSL";
static const char* TER_FS = R"GLSL(#version 300 es
precision highp float;
in vec3 vC; in vec3 vN; in vec3 wp; uniform vec3 uCam; out vec4 o;
void main(){
  vec3 N = normalize(vN), L = normalize(vec3(0.4, 0.8, 0.3));
  vec3 c = vC * (0.35 + 0.75 * max(dot(N, L), 0.0));
  c = mix(c, vec3(0.62, 0.80, 0.95), clamp(length(uCam - wp) / 2500.0, 0.0, 1.0));
  o = vec4(c, 1.0);
}
)GLSL";

static const char* WAT_VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in float dep;
uniform mat4 uVP; out float vD; out vec3 wp;
void main(){ vD = dep; wp = p; gl_Position = uVP * vec4(p, 1.0); }
)GLSL";
static const char* WAT_FS = R"GLSL(#version 300 es
precision highp float;
in float vD; in vec3 wp; uniform vec3 uCam; uniform float uT; out vec4 o;
void main(){
  // ripples
  vec2 w = vec2(cos(wp.x*0.9 + sin(wp.z*0.7 + uT*0.9) + uT*1.1), cos(wp.z*1.1 + sin(wp.x*0.8 - uT*0.7) - uT*0.8)) * 0.06;
  vec3 N = normalize(vec3(w.x, 1.0, w.y));
  vec3 V = normalize(uCam - wp), L = normalize(vec3(0.4, 0.8, 0.3)), H = normalize(L + V);
  float ndv = clamp(dot(N, V), 0.0, 1.0), fr = pow(1.0 - ndv, 3.0);
  float dw = vD + 0.07 * sin(uT * 0.9 + wp.x * 0.05 + wp.z * 0.04);
  float rvD = smoothstep(0.0, 1.9, dw);
  vec3 base = vec3(0.18, 0.55, 0.62) * (0.45 + 0.55 * max(dot(N, L), 0.0)) + vec3(pow(max(dot(N, H), 0.0), 220.0) * 0.9) + vec3(0.62, 0.80, 0.95) * fr * 0.45;
  vec3 rvCol = mix(vec3(0.30, 0.46, 0.38), vec3(0.09, 0.26, 0.27), rvD);          // sandy-green shallows, dark teal-green deep water
  vec3 c = mix(base, rvCol + base * 0.22, 0.80);
  float edge = smoothstep(0.0, 0.07, dw);
  float lap = smoothstep(0.35, 0.95, sin(dw * 11.0 - uT * 1.7)) * (1.0 - smoothstep(0.05, 1.3, dw));
  float rim = 1.0 - smoothstep(0.0, 0.22, dw);
  float foam = clamp(lap * 0.55 + rim * 0.9, 0.0, 1.0) * step(0.0, dw);
  c = mix(c, vec3(0.95, 0.99, 1.0), foam * 0.85);
  float a = (0.30 + 0.30 * rvD + 0.30 * fr) * smoothstep(0.0, 0.75, dw);          // see-through: the bed shows, more near the banks
  a = clamp(max(a, foam * 0.8 * edge), 0.0, 1.0);
  c = mix(c, vec3(0.62, 0.80, 0.95), clamp(length(uCam - wp) / 2500.0, 0.0, 1.0));
  o = vec4(c, a);
}
)GLSL";

static const char* BR_VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in vec2 uv; layout(location=2) in vec3 n; layout(location=3) in float al;
uniform mat4 uVP; out vec2 vUv; out vec3 vN; out vec3 wp; out float vA;
void main(){ vUv = uv; vN = n; vA = al; wp = p; gl_Position = uVP * vec4(p, 1.0); }
)GLSL";
// uMode 0 = opaque, 1 = texture alpha * vertex alpha (dirt), 2 = vertex alpha only (road blend patch; its texture alpha is roughness)
static const char* BR_FS = R"GLSL(#version 300 es
precision highp float;
in vec2 vUv; in vec3 vN; in vec3 wp; in float vA;
uniform sampler2D uTex; uniform vec3 uCam; uniform vec3 uTint; uniform int uMode; out vec4 o;
void main(){
  vec4 tx = texture(uTex, vUv);
  vec3 alb = pow(tx.rgb, vec3(2.2)) * pow(uTint, vec3(2.2));
  vec3 N = normalize(vN); if (!gl_FrontFacing) N = -N;                                  // double sided, like three.js
  float d = max(dot(N, normalize(vec3(0.4, 0.8, 0.3))), 0.0);
  vec3 c = pow(alb * (0.35 + 0.75 * d), vec3(1.0 / 2.2));
  c = mix(c, vec3(0.62, 0.80, 0.95), clamp(length(uCam - wp) / 2500.0, 0.0, 1.0));
  float a = uMode == 0 ? 1.0 : (uMode == 1 ? tx.a * vA : vA);
  o = vec4(c, a);
}
)GLSL";

struct Gpu { GLuint vao = 0, vbo = 0, ibo = 0; GLsizei count = 0; };
static Gpu gTer, gWat, gPart[Bridge::M_COUNT];
static GLuint gProgT = 0, gProgW = 0, gProgB = 0, gWood = 0, gBeam = 0, gDirt = 0, gDirtEnd = 0;
static GLint uT_VP, uT_Cam, uW_VP, uW_Cam, uW_T, uB_VP, uB_Cam, uB_Tex, uB_Tint, uB_Mode;

static Gpu upload(const void* v, size_t vbytes, const std::vector<uint32_t>& idx, int stride, const int* attrN, const int* attrOff, int nAttr){
    Gpu g; g.count = (GLsizei)idx.size(); if (!g.count) return g;
    glGenVertexArrays(1, &g.vao); glBindVertexArray(g.vao);
    glGenBuffers(1, &g.vbo); glBindBuffer(GL_ARRAY_BUFFER, g.vbo); glBufferData(GL_ARRAY_BUFFER, vbytes, v, GL_STATIC_DRAW);
    for (int i = 0; i < nAttr; i++){ glEnableVertexAttribArray(i); glVertexAttribPointer(i, attrN[i], GL_FLOAT, GL_FALSE, stride, (void*)(intptr_t)attrOff[i]); }
    glGenBuffers(1, &g.ibo); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, g.ibo); glBufferData(GL_ELEMENT_ARRAY_BUFFER, idx.size() * 4, idx.data(), GL_STATIC_DRAW);
    glBindVertexArray(0); return g;
}
static void drawGpu(const Gpu& g){ if (!g.count) return; glBindVertexArray(g.vao); glDrawElements(GL_TRIANGLES, g.count, GL_UNSIGNED_INT, (void*)0); glBindVertexArray(0); }

static GLuint texFromImg(const Bridge::Img& im){
    GLuint t; glGenTextures(1, &t); glBindTexture(GL_TEXTURE_2D, t); glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, im.w, im.h, 0, GL_RGBA, GL_UNSIGNED_BYTE, im.px.data()); glGenerateMipmap(GL_TEXTURE_2D);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    const char* ext = (const char*)glGetString(GL_EXTENSIONS);
    if (ext && strstr(ext, "GL_EXT_texture_filter_anisotropic")){ GLfloat mx = 1; glGetFloatv(0x84FF, &mx); glTexParameterf(GL_TEXTURE_2D, 0x84FE, mx < 8.f ? mx : 8.f); }
    return t;
}

// Call once with a current GL context, after Road::init() and RoadGL::init().
static void init(){
    Bridge::init();
    gProgT = RoadGL::makeProg(TER_VS, TER_FS); gProgW = RoadGL::makeProg(WAT_VS, WAT_FS); gProgB = RoadGL::makeProg(BR_VS, BR_FS);
    uT_VP = glGetUniformLocation(gProgT, "uVP"); uT_Cam = glGetUniformLocation(gProgT, "uCam");
    uW_VP = glGetUniformLocation(gProgW, "uVP"); uW_Cam = glGetUniformLocation(gProgW, "uCam"); uW_T = glGetUniformLocation(gProgW, "uT");
    uB_VP = glGetUniformLocation(gProgB, "uVP"); uB_Cam = glGetUniformLocation(gProgB, "uCam"); uB_Tex = glGetUniformLocation(gProgB, "uTex");
    uB_Tint = glGetUniformLocation(gProgB, "uTint"); uB_Mode = glGetUniformLocation(gProgB, "uMode");
    River::TerrainMesh tm; River::WaterMesh wm; River::buildTerrain(tm, wm, &River::gHooks);                      // river bed + hills (Terrain hooks) on the 4 m patch
    { const int n[3] = {3, 3, 3}, o[3] = {0, 12, 24}; gTer = upload(tm.v.data(), tm.v.size() * 4, tm.idx, 36, n, o, 3); }
    { const int n[2] = {3, 1}, o[2] = {0, 12}; gWat = upload(wm.v.data(), wm.v.size() * 4, wm.idx, 16, n, o, 2); }
    for (int m = 0; m < Bridge::M_COUNT; m++){ const int n[4] = {3, 2, 3, 1}, o[4] = {0, 12, 20, 32}; gPart[m] = upload(Bridge::gMesh[m].v.data(), Bridge::gMesh[m].v.size() * 4, Bridge::gMesh[m].idx, 36, n, o, 4); }
    gWood = texFromImg(Bridge::makeWoodTex()); gBeam = texFromImg(Bridge::makeBeamTex());
    gDirt = texFromImg(Bridge::makeDirtTex(false)); gDirtEnd = texFromImg(Bridge::makeDirtTex(true));
}

// carved river bed (replaces the flat ground inside the river patch)
static void drawTerrain(const float* VP, const float* eye){
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE);
    glUseProgram(gProgT); glUniformMatrix4fv(uT_VP, 1, GL_FALSE, VP); glUniform3fv(uT_Cam, 1, eye); drawGpu(gTer);
}

static void bridgePart(int mesh, GLuint tex, float r, float g, float b, int mode, float off){
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, tex); glUniform1i(uB_Tex, 0);
    glUniform3f(uB_Tint, r, g, b); glUniform1i(uB_Mode, mode);
    if (off != 0.f){ glEnable(GL_POLYGON_OFFSET_FILL); glPolygonOffset(off, off); } else glDisable(GL_POLYGON_OFFSET_FILL);
    drawGpu(gPart[mesh]);
}
static inline float hx(int v){ return v / 255.f; }

// bridges + water; call after RoadGL::draw
static void draw(const float* VP, const float* eye, float timeSec){
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE);
    // opaque timber (materials: deckMat 0xa88a70, stoneMat posts 0xc4a284, beamMat 0xb09478, bridgeTopMat 0xd0b090 + offset -2)
    glUseProgram(gProgB); glUniformMatrix4fv(uB_VP, 1, GL_FALSE, VP); glUniform3fv(uB_Cam, 1, eye);
    bridgePart(Bridge::M_DECK, gWood, hx(0xa8), hx(0x8a), hx(0x70), 0, 0.f);
    bridgePart(Bridge::M_POST, gWood, hx(0xc4), hx(0xa2), hx(0x84), 0, 0.f);
    bridgePart(Bridge::M_BEAM, gBeam, hx(0xb0), hx(0x94), hx(0x78), 0, 0.f);
    bridgePart(Bridge::M_TOP,  gWood, hx(0xd0), hx(0xb0), hx(0x90), 0, -2.f);
    glDisable(GL_POLYGON_OFFSET_FILL);
    // water
    glUseProgram(gProgW); glUniformMatrix4fv(uW_VP, 1, GL_FALSE, VP); glUniform3fv(uW_Cam, 1, eye); glUniform1f(uW_T, timeSec);
    glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); glDepthMask(GL_FALSE);
    drawGpu(gWat);
    // dragged-in dirt + the road earth blended over the first / last metres of planks
    glUseProgram(gProgB);
    bridgePart(Bridge::M_BLEND,   RoadGL::gColA, 1, 1, 1, 2, -3.f);
    bridgePart(Bridge::M_DIRT,    gDirt,    1, 1, 1, 1, -4.f);
    bridgePart(Bridge::M_DIRTEND, gDirtEnd, 1, 1, 1, 1, -4.f);
    glDepthMask(GL_TRUE); glDisable(GL_BLEND); glDisable(GL_POLYGON_OFFSET_FILL);
}

} // namespace BridgeGL
