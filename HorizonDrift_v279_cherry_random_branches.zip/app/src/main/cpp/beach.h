// Sunny Drift - the BEACH on the lake shore + the world boundary fence (pure C++ here: planning, models, collision; drawing is in beach_render.h).
//  * the lake shore is a gentle golden-sand beach (ground slope + colour live in terrain.h: lakeCarve / beachK)
//  * on the shore facing the valley (SWISS version): a wooden pier, a timber boat shed with a Swiss flag, rowing boats, a bench, rocks - no palms / parasols / surf props
//  * the car cannot drive into the deep water (soft wall at the shallows) and the props are solid
//  * WORLD BOUNDARY: a red / white fence runs round the playable area. Its radius follows the foot of the mountains (where the mountain mesh would
//    swallow the car), so the car never ends up inside a mountain. The old hard wall at 1440 m is replaced by a soft slow-down + a clean bounce.
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <vector>
#include "terrain.h"
#include "fence.h"      // bounceOff

namespace Beach {

// ====================================================================== world boundary
static const int BN = 720;                       // angular samples of the boundary radius
static float gBoundR[BN];
static bool gBoundOk = false;

static double boundR(double a){                  // fence radius at angle a (atan2(z, x))
    if (!gBoundOk) return 1400.0;
    double f = a / 6.283185307179586; f -= std::floor(f); f *= BN;
    const int i0 = (int)f % BN, i1 = (i0 + 1) % BN; const double u = f - std::floor(f);
    return gBoundR[i0] * (1 - u) + gBoundR[i1] * u;
}
static void planBoundary(){
    // The fence stands where the ground stops being a safe, drivable meadow: the first radius where the mountain mesh gets close to the ground the car drives on,
    // where the drawn surface rises above the driving height, or where the slope turns into a wall. Then it is pulled in 30 m, widened to a smooth curve (no spikes).
    std::vector<float> raw(BN), mn(BN), t(BN);
    for (int k = 0; k < BN; k++){
        const double a = k * 6.283185307179586 / BN, c = std::cos(a), s = std::sin(a); double lim = 1440;
        for (double r = 1100; r <= 1440; r += 2){
            const double x = r * c, z = r * s, g = Terrain::driveH(x, z), m = Terrain::mtnH(x, z);
            const double g2 = Terrain::driveH((r + 12) * c, (r + 12) * s), slope = (g2 - g) / 12.0;
            const bool mtnNear = m >= 0 && m - 0.3 > g - 0.4;                       // mountain mesh is about to come through the ground
            if (mtnNear || (r > 1250 && slope > 0.85)){ lim = r; break; }            // ... or the ground turns into a cliff wall
        }
        raw[k] = (float)(lim - 30);
    }
    for (int k = 0; k < BN; k++){ float m = raw[k]; for (int d = -30; d <= 30; d++) m = std::min(m, raw[(k + d + BN) % BN]); mn[k] = m; }   // never further out than any neighbour within +-15 deg
    for (int pass = 0; pass < 2; pass++){                                          // two box blurs = a smooth, round fence line
        for (int k = 0; k < BN; k++){ double s = 0; for (int d = -12; d <= 12; d++) s += mn[(k + d + BN) % BN]; t[k] = (float)(s / 25.0); }
        mn = t;
    }
    for (int k = 0; k < BN; k++) gBoundR[k] = (float)std::max(1150.0, std::min(1430.0, (double)mn[k]));
    gBoundOk = true;
}
// call every frame: slows the car down smoothly near the fence and stops it cleanly
static void edge(CarState& S, double dt){
    if (!gBoundOk) return;
    const double r = std::hypot(S.x, S.z); if (r < 1e-3) return;
    const double lim = boundR(std::atan2(S.z, S.x)) - 3.0;                          // the car's centre stops 3 m before the fence
    const double soft = lim - 35.0;
    if (r > soft){
        const double pen = std::min(1.0, (r - soft) / 35.0), nx = S.x / r, nz = S.z / r;
        const double sH = std::sin(S.heading), cH = std::cos(S.heading), out = (S.speed * sH + S.vy * cH) * nx + (S.speed * cH - S.vy * sH) * nz;
        if (out > 0){ const double k = std::exp(-1.8 * pen * pen * dt); S.speed *= k; S.vy *= k; }        // gentle brake while driving towards the fence
    }
    if (r > lim){
        const double nx = S.x / r, nz = S.z / r; S.x = nx * lim; S.z = nz * lim;
        Fence::bounceOff(S, -nx, -nz, 0.25, 0.30);
    }
}

// ====================================================================== beach site
struct Circle { float x, z, r; };
struct Box { float x, z, hx, hz, c, s; };      // local x axis = (c, -s) in world
static std::vector<Circle> gCircles; static std::vector<Box> gBoxes;
static bool gOn = false; static double gLx = 0, gLz = 0, gLR = 150, gUx = 0, gUz = 1, gTx = -1, gTz = 0;

// ---------- tiny mesh builder (vertex = pos, normal, colour; flat shaded) ----------
struct V3 { float x, y, z; };
static inline V3 operator+(V3 a, V3 b){ return {a.x + b.x, a.y + b.y, a.z + b.z}; }
static inline V3 operator-(V3 a, V3 b){ return {a.x - b.x, a.y - b.y, a.z - b.z}; }
static inline V3 operator*(V3 a, float k){ return {a.x * k, a.y * k, a.z * k}; }
static inline V3 cross(V3 a, V3 b){ return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x}; }
static inline float dot(V3 a, V3 b){ return a.x * b.x + a.y * b.y + a.z * b.z; }
static inline V3 norm(V3 a){ const float l = std::sqrt(dot(a, a)); return l > 1e-8f ? a * (1.f / l) : V3{0, 1, 0}; }
struct Col { float r, g, b; };
static inline Col shade(Col c, float k){ return {c.r * k, c.g * k, c.b * k}; }
struct Mesh {
    std::vector<float> v; std::vector<uint32_t> i;
    void tri(V3 a, V3 b, V3 c, Col col){
        const V3 n = norm(cross(b - a, c - a)); const uint32_t base = (uint32_t)(v.size() / 9);
        for (const V3& p : {a, b, c}){ v.push_back(p.x); v.push_back(p.y); v.push_back(p.z); v.push_back(n.x); v.push_back(n.y); v.push_back(n.z); v.push_back(col.r); v.push_back(col.g); v.push_back(col.b); }
        i.push_back(base); i.push_back(base + 1); i.push_back(base + 2);
    }
    void quad(V3 a, V3 b, V3 c, V3 d, Col col){ tri(a, b, c, col); tri(a, c, d, col); }
    // box centred at (cx, cy, cz), half sizes, local x axis along world direction (dx, dz)
    void box(float cx, float cy, float cz, float hx, float hy, float hz, float dx, float dz, Col col){
        const float c = dx, s = -dz;
        auto P = [&](float lx, float ly, float lz){ return V3{cx + c * lx + s * lz, cy + ly, cz - s * lx + c * lz}; };
        const V3 p000 = P(-hx, -hy, -hz), p100 = P(hx, -hy, -hz), p110 = P(hx, hy, -hz), p010 = P(-hx, hy, -hz), p001 = P(-hx, -hy, hz), p101 = P(hx, -hy, hz), p111 = P(hx, hy, hz), p011 = P(-hx, hy, hz);
        quad(p010, p110, p111, p011, col);                                  // top
        quad(p000, p100, p110, p010, shade(col, 0.88f)); quad(p001, p101, p111, p011, shade(col, 0.88f));
        quad(p000, p001, p011, p010, shade(col, 0.80f)); quad(p100, p101, p111, p110, shade(col, 0.80f));
    }
    // tube along a polyline with a radius per point; colours alternate by ring when colB is given (bands)
    void tube(const std::vector<V3>& p, const std::vector<float>& rad, int seg, Col a, Col b, bool band){
        const int n = (int)p.size(); std::vector<std::vector<V3>> ring(n);
        for (int k = 0; k < n; k++){
            const V3 d = norm(p[std::min(k + 1, n - 1)] - p[std::max(k - 1, 0)]);
            V3 u = cross(d, V3{0, 0, 1}); if (dot(u, u) < 1e-4f) u = cross(d, V3{1, 0, 0}); u = norm(u); const V3 w = cross(d, u);
            for (int q = 0; q < seg; q++){ const float t = q * 6.2831853f / seg; ring[k].push_back(p[k] + (u * std::cos(t) + w * std::sin(t)) * rad[k]); }
        }
        for (int k = 0; k + 1 < n; k++) for (int q = 0; q < seg; q++){
            const int q2 = (q + 1) % seg; quad(ring[k][q], ring[k][q2], ring[k + 1][q2], ring[k + 1][q], (band && (k & 1)) ? b : a);
        }
    }
    // striped beach ball: 12 longitude slices, colour per pair of slices
    void ball(V3 c, float r, const Col* cols, int ncol){
        const int lon = 12, lat = 6;
        auto P = [&](int i2, int j){ const float th = i2 * 6.2831853f / lon, ph = j * 3.14159265f / lat; return V3{c.x + std::sin(ph) * std::cos(th) * r, c.y + std::cos(ph) * r, c.z + std::sin(ph) * std::sin(th) * r}; };
        for (int j = 0; j < lat; j++) for (int i2 = 0; i2 < lon; i2++){
            const Col col = cols[(i2 / 2) % ncol]; const V3 a = P(i2, j), b = P(i2 + 1, j), d = P(i2, j + 1), e = P(i2 + 1, j + 1);
            if (j > 0) tri(a, d, b, col); if (j < lat - 1) tri(b, d, e, col);
        }
    }
    // low-poly sphere / rock (radius jitter by hash so rocks look irregular)
    void blob(V3 c, float rx, float ry, float rz, int lon, int lat, Col col, uint32_t seed, float jitter){
        auto H = [&](int a, int b){ uint32_t h = (uint32_t)(a * 73856093u) ^ (uint32_t)(b * 19349663u) ^ seed * 83492791u; h ^= h >> 13; h *= 0x5bd1e995u; h ^= h >> 15; return (h & 0xffff) / 65535.f; };
        auto P = [&](int i2, int j){ const float th = i2 * 6.2831853f / lon, ph = j * 3.14159265f / lat; const float k = 1.f + (H(i2 % lon, j) - 0.5f) * jitter * ((j == 0 || j == lat) ? 0.f : 1.f);
            return V3{c.x + std::sin(ph) * std::cos(th) * rx * k, c.y + std::cos(ph) * ry * k, c.z + std::sin(ph) * std::sin(th) * rz * k}; };
        for (int j = 0; j < lat; j++) for (int i2 = 0; i2 < lon; i2++){
            const float shd = 0.82f + 0.30f * H(i2 + 7, j + 3);
            const V3 a = P(i2, j), b = P(i2 + 1, j), d = P(i2, j + 1), e = P(i2 + 1, j + 1);
            if (j > 0) tri(a, d, b, shade(col, shd)); if (j < lat - 1) tri(b, d, e, shade(col, shd * 0.96f));
        }
    }
};

// ---------- ground height of what is actually drawn (outer ground = 16 m grid) ----------
static double gy(double x, double z){
    if (Terrain::inLattice(x, z)) return Terrain::meshH(x, z);
    const double S = 16.0, X0 = -2880, Z0 = -2880, fx = (x - X0) / S, fz = (z - Z0) / S; int i = (int)std::floor(fx), k = (int)std::floor(fz);
    auto H = [&](int a, int b){ const double px = X0 + a * S, pz = Z0 + b * S; return River::groundH(px, pz) + Terrain::outerH(px, pz); };
    const double u = fx - i, v = fz - k, ha = H(i, k), hb = H(i + 1, k), hc = H(i, k + 1), hd = H(i + 1, k + 1);
    return (u + v <= 1) ? ha + u*(hb - ha) + v*(hc - ha) : hb*(1 - v) + hc*(1 - u) + hd*(u + v - 1);
}

struct Rng { uint32_t s; float f(){ s ^= s << 13; s ^= s >> 17; s ^= s << 5; return (s >> 8) / 16777216.f; } };

// ---------- models ----------
static void palm(Mesh& m, Rng& R, float x, float z){
    const float y0 = (float)gy(x, z) - 0.25f, H = 5.8f + R.f() * 2.4f, lean = 0.8f + R.f() * 1.6f, az = R.f() * 6.2831853f, lx = std::cos(az), lz = std::sin(az);
    std::vector<V3> pts; std::vector<float> rad;
    for (int k = 0; k <= 8; k++){ const float t = k / 8.f; pts.push_back({x + lx * lean * t * t, y0 + H * t, z + lz * lean * t * t}); rad.push_back(0.33f - 0.15f * t); }
    m.tube(pts, rad, 7, {0.50f, 0.40f, 0.30f}, {0.40f, 0.32f, 0.24f}, true);
    const V3 top = pts.back() + V3{0, 0.1f, 0};
    for (int q = 0; q < 3; q++){ const float a = q * 2.1f; m.blob(top + V3{std::cos(a) * 0.28f, -0.30f, std::sin(a) * 0.28f}, 0.17f, 0.17f, 0.17f, 6, 4, {0.32f, 0.22f, 0.10f}, (uint32_t)(q + 1), 0.1f); }   // coconuts
    const int nf = 11; const float L = 2.7f + R.f() * 0.7f;
    for (int f = 0; f < nf; f++){
        const float a = f * 6.2831853f / nf + R.f() * 0.4f, dx = std::cos(a), dz = std::sin(a), up0 = 0.9f + R.f() * 0.5f, len = L * (0.85f + R.f() * 0.3f), W = 0.55f;
        const V3 wv = {-dz, 0, dx}; const int ns = 8; V3 prevL{}, prevR{}; bool have = false;
        for (int s = 0; s <= ns; s++){
            const float t = s / (float)ns, h = len * t, ww = W * std::sin(3.14159265f * std::pow(t, 0.75f)) * (0.35f + 0.65f * (1 - t * 0.6f));
            const V3 c = top + V3{dx * h, up0 * h * (1.f - t) * 1.1f - len * 0.45f * t * t, dz * h} + V3{0, 0.25f * std::sin(t * 3.14159f) * len * 0.15f, 0};
            const V3 Lp = c + wv * ww + V3{0, -ww * 0.35f, 0}, Rp = c - wv * ww + V3{0, -ww * 0.35f, 0};   // leaflets droop at the edges
            const float tone = 0.78f + 0.40f * t; const Col g = {0.12f * tone, 0.38f * tone, 0.10f * tone};
            if (have){ m.quad(prevL, prevR, Rp, Lp, g); }
            prevL = Lp; prevR = Rp; have = true;
            (void)c;
        }
    }
}
static void parasol(Mesh& m, Rng& R, float x, float z, Col c1, Col c2){
    const float y0 = (float)gy(x, z) - 0.05f, tilt = 0.10f + R.f() * 0.10f, az = R.f() * 6.2831853f, tx = std::cos(az) * tilt, tz = std::sin(az) * tilt, Hh = 2.35f;
    const V3 foot = {x, y0, z}, top = {x + tx * Hh, y0 + Hh, z + tz * Hh};
    m.tube({foot, top}, {0.035f, 0.03f}, 5, {0.85f, 0.85f, 0.82f}, {0, 0, 0}, false);
    const int N = 10; const float rim = 1.95f; const V3 apex = top + V3{0, 0.32f, 0};
    for (int k = 0; k < N; k++){
        const float a0 = k * 6.2831853f / N, a1 = (k + 1) * 6.2831853f / N, am = (a0 + a1) / 2;
        const V3 p0 = top + V3{std::cos(a0) * rim, -0.38f, std::sin(a0) * rim}, p1 = top + V3{std::cos(a1) * rim, -0.38f, std::sin(a1) * rim}, pm = top + V3{std::cos(am) * rim * 1.02f, -0.50f, std::sin(am) * rim * 1.02f};
        const Col c = (k & 1) ? c1 : c2; m.tri(apex, p0, pm, c); m.tri(apex, pm, p1, c);
    }
}
static void lounger(Mesh& m, float x, float z, float dx, float dz, Col towel){
    const float y = (float)gy(x, z); const float px = -dz, pz = dx;
    m.box(x, y + 0.26f, z, 0.95f, 0.04f, 0.32f, dx, dz, {0.93f, 0.93f, 0.90f});                                  // seat
    m.box(x - dx * 0.95f + dx * 0.0f, y + 0.46f, z - dz * 0.95f, 0.04f, 0.26f, 0.32f, dx, dz, {0.93f, 0.93f, 0.90f});   // back rest (upright-ish)
    for (int s = -1; s <= 1; s += 2) for (int e = -1; e <= 1; e += 2) m.box(x + dx * 0.85f * e + px * 0.28f * s, y + 0.13f, z + dz * 0.85f * e + pz * 0.28f * s, 0.025f, 0.13f, 0.025f, dx, dz, {0.75f, 0.75f, 0.72f});
    m.box(x + dx * 0.05f, y + 0.31f, z + dz * 0.05f, 0.80f, 0.012f, 0.26f, dx, dz, towel);                          // towel on the seat
}
static void towel(Mesh& m, float x, float z, float dx, float dz, Col c){ m.box(x, (float)gy(x, z) + 0.015f, z, 0.95f, 0.012f, 0.45f, dx, dz, c); m.box(x + dx * 0.1f, (float)gy(x, z) + 0.03f, z + dz * 0.1f, 0.18f, 0.006f, 0.45f, dx, dz, shade(c, 1.25f)); }
static void surfboard(Mesh& m, float x, float z, float az, Col c, float lean){
    const float y = (float)gy(x, z); const float ax = std::cos(az), az2 = std::sin(az);
    // a board standing in the sand, leaning: long thin slab + pointed nose
    const V3 foot = {x, y - 0.1f, z}, up = norm(V3{ax * lean, 1.f, az2 * lean}), side = norm(V3{-az2, 0, ax}); const float L = 2.1f, W = 0.26f;
    const V3 a = foot + side * (-W), b = foot + side * W, c2 = foot + up * (L * 0.9f) + side * W, d = foot + up * (L * 0.9f) - side * W, tip = foot + up * L;
    m.quad(a, b, c2, d, c); m.tri(d, c2, tip, c); m.quad(a + norm(cross(side, up)) * 0.05f, b + norm(cross(side, up)) * 0.05f, c2 + norm(cross(side, up)) * 0.05f, d + norm(cross(side, up)) * 0.05f, shade(c, 0.85f));
}
static void lifeguard(Mesh& m, float x, float z, float dx, float dz){
    const float y = (float)gy(x, z) - 0.1f, px = -dz, pz = dx;
    const Col wood = {0.62f, 0.45f, 0.28f}, red = {0.80f, 0.12f, 0.10f}, white = {0.95f, 0.94f, 0.92f};
    for (int a = -1; a <= 1; a += 2) for (int b = -1; b <= 1; b += 2) m.box(x + dx * 1.2f * a + px * 1.2f * b, y + 1.15f, z + dz * 1.2f * a + pz * 1.2f * b, 0.09f, 1.15f, 0.09f, dx, dz, wood);
    m.box(x, y + 2.30f, z, 1.45f, 0.07f, 1.45f, dx, dz, wood);                                                      // platform
    m.box(x, y + 3.20f, z, 0.95f, 0.07f, 0.95f, dx, dz, wood);
    m.box(x, y + 2.75f, z, 0.95f, 0.37f, 0.95f, dx, dz, white);                                                     // cabin (white lower)
    m.box(x, y + 3.00f, z + 0.f, 0.97f, 0.06f, 0.97f, dx, dz, red);
    const V3 apex = {x, y + 4.05f, z};
    const V3 c0 = {x + dx * 1.25f + px * 1.25f, y + 3.28f, z + dz * 1.25f + pz * 1.25f}, c1 = {x + dx * 1.25f - px * 1.25f, y + 3.28f, z + dz * 1.25f - pz * 1.25f},
             c2 = {x - dx * 1.25f - px * 1.25f, y + 3.28f, z - dz * 1.25f - pz * 1.25f}, c3 = {x - dx * 1.25f + px * 1.25f, y + 3.28f, z - dz * 1.25f + pz * 1.25f};
    m.tri(apex, c0, c1, red); m.tri(apex, c1, c2, shade(red, 0.9f)); m.tri(apex, c2, c3, red); m.tri(apex, c3, c0, shade(red, 0.9f));   // pyramid roof
    for (int k = 0; k < 6; k++) m.box(x + dx * 1.55f, y + 0.2f + k * 0.4f, z + dz * 1.55f, 0.35f, 0.03f, 0.04f, px, pz, wood);   // ladder rungs
    m.box(x + dx * 1.55f + px * 0.35f, y + 1.3f, z + dz * 1.55f + pz * 0.35f, 0.03f, 1.15f, 0.03f, dx, dz, wood); m.box(x + dx * 1.55f - px * 0.35f, y + 1.3f, z + dz * 1.55f - pz * 0.35f, 0.03f, 1.15f, 0.03f, dx, dz, wood);
    m.box(x - dx * 1.2f + px * 1.2f, y + 3.9f, z - dz * 1.2f + pz * 1.2f, 0.02f, 0.6f, 0.02f, dx, dz, {0.9f, 0.9f, 0.9f});                    // flag pole
    m.box(x - dx * 1.2f + px * 1.2f + px * 0.3f, y + 4.3f, z - dz * 1.2f + pz * 1.2f + pz * 0.3f, 0.01f, 0.18f, 0.30f, px, pz, {0.95f, 0.75f, 0.10f});
}
// ---- Swiss lake-shore props ----
static void swissFlag(Mesh& m, float x, float y, float z, float dx, float dz, float h){
    const float px = -dz, pz = dx;
    m.box(x, y + h * 0.5f, z, 0.03f, h * 0.5f, 0.03f, dx, dz, {0.85f, 0.85f, 0.85f});
    const float fx = x + px * 0.42f, fz = z + pz * 0.42f, fy = y + h - 0.42f;
    m.box(fx, fy, fz, 0.01f, 0.40f, 0.40f, px, pz, {0.86f, 0.10f, 0.10f});                                        // red field
    m.box(fx + dx * 0.012f, fy, fz + dz * 0.012f, 0.008f, 0.20f, 0.06f, px, pz, {1.f, 1.f, 1.f});               // white cross
    m.box(fx + dx * 0.012f, fy, fz + dz * 0.012f, 0.008f, 0.06f, 0.20f, px, pz, {1.f, 1.f, 1.f});
}
static void boathouse(Mesh& m, float x, float z, float dx, float dz){
    const float y = (float)gy(x, z) - 0.1f, px = -dz, pz = dx;
    const Col wood = {0.42f, 0.28f, 0.17f}, dark = {0.30f, 0.20f, 0.12f}, stone = {0.62f, 0.60f, 0.56f}, roof = {0.33f, 0.24f, 0.18f};
    m.box(x, y + 0.45f, z, 3.0f, 0.45f, 2.3f, dx, dz, stone);                                                       // stone base
    m.box(x, y + 1.95f, z, 3.0f, 1.05f, 2.3f, dx, dz, wood);                                                        // timber walls
    m.box(x + dx * 2.31f, y + 1.3f, z + dz * 2.31f, 1.0f, 0.95f, 0.04f, px, pz, dark);                              // big door
    for (int e = -1; e <= 1; e += 2) m.box(x + dx * 2.32f + px * 2.0f * e, y + 2.1f, z + dz * 2.32f + pz * 2.0f * e, 0.35f, 0.35f, 0.04f, px, pz, {0.90f, 0.88f, 0.80f});
    const V3 r0 = {x + dx * 2.7f + px * 3.4f, y + 3.0f, z + dz * 2.7f + pz * 3.4f}, r1 = {x + dx * 2.7f - px * 3.4f, y + 3.0f, z + dz * 2.7f - pz * 3.4f};
    const V3 r2 = {x - dx * 2.7f - px * 3.4f, y + 3.0f, z - dz * 2.7f - pz * 3.4f}, r3 = {x - dx * 2.7f + px * 3.4f, y + 3.0f, z - dz * 2.7f + pz * 3.4f};
    const V3 a0 = {x + dx * 2.7f, y + 3.9f, z + dz * 2.7f}, a1 = {x - dx * 2.7f, y + 3.9f, z - dz * 2.7f};
    m.quad(r0, a0, a1, r3, roof); m.quad(r1, r2, a1, a0, shade(roof, 0.85f));                                       // low gable roof (ridge runs front-back)
    m.tri(r0, r1, a0, shade(roof, 0.9f)); m.tri(r3, a1, r2, shade(roof, 0.9f));
    swissFlag(m, x - dx * 2.2f + px * 3.0f, y + 3.0f, z - dz * 2.2f + pz * 3.0f, dx, dz, 2.6f);
}
static void rowboat(Mesh& m, float x, float z, float dx, float dz, Col hull){
    const float y = (float)gy(x, z) + 0.28f, px = -dz, pz = dx;
    m.box(x, y, z, 2.1f, 0.14f, 0.58f, dx, dz, hull); m.box(x, y + 0.16f, z, 1.9f, 0.04f, 0.50f, dx, dz, {0.62f, 0.46f, 0.30f});
    for (int k = -1; k <= 1; k++) m.box(x + dx * 0.7f * k, y + 0.22f, z + dz * 0.7f * k, 0.03f, 0.03f, 0.55f, dx, dz, {0.55f, 0.40f, 0.26f}); (void)px; (void)pz;
}
static void bench(Mesh& m, float x, float z, float dx, float dz){
    const float y = (float)gy(x, z), px = -dz, pz = dx; const Col wood = {0.50f, 0.36f, 0.22f}, dark = {0.30f, 0.22f, 0.15f};
    m.box(x, y + 0.45f, z, 0.25f, 0.03f, 0.95f, dx, dz, wood); m.box(x - dx * 0.22f, y + 0.80f, z - dz * 0.22f, 0.03f, 0.22f, 0.95f, dx, dz, wood);
    for (int e = -1; e <= 1; e += 2) m.box(x + px * 0.8f * e, y + 0.22f, z + pz * 0.8f * e, 0.2f, 0.22f, 0.04f, dx, dz, dark);
}
static void pier(Mesh& m, double sx, double sz, double dx, double dz, double len){
    const Col wood = {0.58f, 0.42f, 0.27f}, dark = {0.35f, 0.25f, 0.17f};
    const float px = (float)-dz, pz = (float)dx; const float yD = 0.80f;
    for (double s = 0; s < len; s += 0.9){
        const float cx = (float)(sx + dx * (s + 0.45)), cz = (float)(sz + dz * (s + 0.45)); const float tone = 0.88f + 0.20f * (float)std::fmod(std::sin(s * 12.9) * 43.7, 1.0);
        m.box(cx, yD, cz, 0.43f, 0.05f, 1.55f, (float)dx, (float)dz, shade(wood, std::fabs(tone)));                  // one plank group
        if (std::fmod(s, 3.6) < 0.5){ for (int e = -1; e <= 1; e += 2){ const float qx = cx + px * 1.45f * e, qz = cz + pz * 1.45f * e; m.box(qx, yD + 0.55f, qz, 0.05f, 0.55f, 0.05f, (float)dx, (float)dz, dark);
            m.tube({{qx, (float)Terrain::gLake.y - 1.6f, qz}, {qx, yD, qz}}, {0.11f, 0.11f}, 6, dark, dark, false); } }                                                // pile + rail post
    }
    for (int e = -1; e <= 1; e += 2){                                                                              // hand rails
        m.box((float)(sx + dx * len * 0.5) + px * 1.45f * e, yD + 0.95f, (float)(sz + dz * len * 0.5) + pz * 1.45f * e, (float)len * 0.5f, 0.03f, 0.03f, (float)dx, (float)dz, wood);
        m.box((float)(sx + dx * len * 0.5) + px * 1.45f * e, yD + 0.55f, (float)(sz + dz * len * 0.5) + pz * 1.45f * e, (float)len * 0.5f, 0.025f, 0.025f, (float)dx, (float)dz, wood);
    }
    m.box((float)(sx + dx * (len + 0.3)), yD + 0.05f, (float)(sz + dz * (len + 0.3)), 0.12f, 0.06f, 1.7f, (float)dx, (float)dz, dark);   // end beam
}

// ====================================================================== plan / meshes
struct Chunk { uint32_t first, count; float cx, cz, rad; };
static Mesh gMesh; static std::vector<Chunk> gChunks;       // chunk 0 = the beach, the rest = fence sections

static void finishChunk(Mesh& whole, const Mesh& part, std::vector<Chunk>& ch, float cx, float cz, float rad){
    if (part.i.empty()) return;
    const uint32_t base = (uint32_t)(whole.v.size() / 9), first = (uint32_t)whole.i.size();
    whole.v.insert(whole.v.end(), part.v.begin(), part.v.end()); for (uint32_t k : part.i) whole.i.push_back(base + k);
    ch.push_back({first, (uint32_t)part.i.size(), cx, cz, rad});
}

static void buildBeach(Mesh& m){
    Rng R{0x2468ace1u};
    auto P = [&](double phi, double dn, double& x, double& z){ const double a = std::cos(phi) * gLR * dn, b = std::sin(phi) * gLR * dn; x = gLx + gUx * a + gTx * b; z = gLz + gUz * a + gTz * b; };
    // pier straight into the lake from the middle of the beach
    double sx, sz; P(0, 1.04, sx, sz); const double pdx = -gUx, pdz = -gUz, plen = 62.0;
    pier(m, sx, sz, pdx, pdz, plen);
    { const double mx = sx + pdx * plen * 0.5, mz = sz + pdz * plen * 0.5; const float c = (float)pdx, s = (float)-pdz; gBoxes.push_back({(float)mx, (float)mz, (float)plen * 0.5f + 0.4f, 1.9f, c, s}); }
    auto lat = [&](double x, double z){ return std::fabs((x - sx) * gTx + (z - sz) * gTz); };    // distance from the pier axis
    // SWISS lake shore: no parasols / palms / surfboards. A wooden jetty (above), a boat shed, two rowing boats, a bench and a Swiss flag.
    int n = 0; (void)n; (void)lat;
    { double x, z; P(0.55, 1.16, x, z); boathouse(m, (float)x, (float)z, (float)-gUx, (float)-gUz);
      const float c = (float)-gUx, s = (float)gUz; gBoxes.push_back({(float)x, (float)z, 3.4f, 2.6f, c, s}); }
    for (int k = 0; k < 2; k++){ double x, z; P(-0.45 - k * 0.22, 1.03, x, z); rowboat(m, (float)x, (float)z, (float)gTx, (float)gTz, k ? Col{0.55f, 0.20f, 0.15f} : Col{0.18f, 0.35f, 0.55f});
      gCircles.push_back({(float)x, (float)z, 1.8f}); }
    { double x, z; P(-0.10, 1.22, x, z); bench(m, (float)x, (float)z, (float)gUx, (float)gUz); gCircles.push_back({(float)x, (float)z, 1.0f}); }
    for (int k = 0; k < 11; k++){                                                                                  // rocks at both ends of the beach, half in the water
        const double side = (k & 1) ? 1.0 : -1.0, phi = side * (1.05 + R.f() * 0.55), dn = 0.97 + R.f() * 0.20; double x, z; P(phi, dn, x, z);
        const float s = 0.7f + R.f() * 1.4f; const float y = (float)gy(x, z);
        m.blob({(float)x, y + s * 0.18f, (float)z}, s * 1.2f, s * 0.7f, s, 7, 5, {0.50f, 0.49f, 0.46f}, (uint32_t)(k * 31 + 5), 0.45f);
        gCircles.push_back({(float)x, (float)z, s * 0.95f});
    }
}

static void buildFence(Mesh& whole, std::vector<Chunk>& ch){
    const Col post = {0.40f, 0.29f, 0.19f}, red = {0.47f, 0.34f, 0.22f}, white = {0.52f, 0.38f, 0.25f};   // SWISS: natural wooden pasture fence (was red / white barrier)
    const double spacing = 10.0, chunkAng = 6.283185307179586 / 90.0; double a = 0; int idx = 0; int cur = 0;
    Mesh part; double ccx = 0, ccz = 0; int cn = 0;
    auto flush = [&](){ if (cn) finishChunk(whole, part, ch, (float)(ccx / cn), (float)(ccz / cn), 130.f); part = Mesh(); ccx = ccz = 0; cn = 0; };
    double px = 0, pz = 0, py = 0; bool have = false;
    while (a < 6.283185307179586 - 1e-6){
        const double R = boundR(a) + 0.0, x = R * std::cos(a), z = R * std::sin(a); double y = Terrain::meshH(x, z); const double mt = Terrain::mtnH(x, z); if (mt >= 0) y = std::max(y, mt - 0.3);
        // post
        const float dx = (float)-std::sin(a), dz = (float)std::cos(a);     // tangent
        part.box((float)x, (float)y + 0.62f, (float)z, 0.10f, 0.95f, 0.10f, dx, dz, post);
        if (have){
            const double mx = (x + px) * 0.5, mz = (z + pz) * 0.5, my = (y + py) * 0.5, L = std::hypot(x - px, z - pz); const float tx = (float)((x - px) / L), tz = (float)((z - pz) / L);
            const Col c = (idx & 1) ? red : white;
            part.box((float)mx, (float)my + 1.20f, (float)mz, (float)L * 0.5f, 0.09f, 0.025f, tx, tz, c);
            part.box((float)mx, (float)my + 0.80f, (float)mz, (float)L * 0.5f, 0.09f, 0.025f, tx, tz, (idx & 1) ? white : red);
        }
        ccx += x; ccz += z; cn++; idx++; px = x; pz = z; py = y; have = true;
        const int nc = (int)(a / chunkAng); if (nc != cur){ flush(); cur = nc; }
        a += spacing / R;
    }
    flush();
}

static void plan(){
    planBoundary();
    gMesh = Mesh(); gChunks.clear(); gCircles.clear(); gBoxes.clear(); gOn = false;
    if (Terrain::gLake.on){
        gLx = Terrain::gLake.x; gLz = Terrain::gLake.z; gLR = Terrain::gLake.r;
        const double l = std::hypot(gLx, gLz); gUx = -gLx / l; gUz = -gLz / l; gTx = -gUz; gTz = gUx;       // u = from the lake towards the valley
        Mesh b; buildBeach(b); finishChunk(gMesh, b, gChunks, (float)gLx, (float)gLz, 400.f);
        gOn = true;
    }
    buildFence(gMesh, gChunks);
}

// ====================================================================== collision (call every frame after the physics step)
static inline void push(CarState& S, double nx, double nz, double pen){
    S.x += nx * pen; S.z += nz * pen;
    const double sH = std::sin(S.heading), cH = std::cos(S.heading), vx = S.speed * sH + S.vy * cH, vz = S.speed * cH - S.vy * sH, vn = -(vx * nx + vz * nz);
    if (vn > 0) Fence::bounceOff(S, nx, nz, 0.10, 0.30);
}
static void collide(CarState& S){
    if (!gOn) return;
    const double lx = S.x - gLx, lz = S.z - gLz, dl = std::hypot(lx, lz);
    if (dl > gLR * 2.2) return;                                                   // far from the beach
    // water: the car may wade through the very shallow edge only
    { const double dn = dl / gLR, lim = 0.955;
      if (dn < lim && dl > 1e-3){ push(S, lx / dl, lz / dl, (lim - dn) * gLR); } }
    const double sH = std::sin(S.heading), cH = std::cos(S.heading), R = 1.05; static const double OFS[3] = {-1.5, 0.0, 1.5};
    for (double o : OFS){
        const double px = S.x + sH * o, pz = S.z + cH * o;
        for (const Circle& c : gCircles){
            const double qx = px - c.x, qz = pz - c.z, r = R + c.r, d2 = qx * qx + qz * qz; if (d2 >= r * r) continue;
            const double d = std::sqrt(d2), nx = d > 1e-4 ? qx / d : -sH, nz = d > 1e-4 ? qz / d : -cH; push(S, nx, nz, r - d);
        }
        for (const Box& b : gBoxes){
            const double dx = px - b.x, dz = pz - b.z, lx2 = b.c * dx - b.s * dz, lz2 = b.s * dx + b.c * dz;
            const double cx = std::max(-(double)b.hx, std::min((double)b.hx, lx2)), cz = std::max(-(double)b.hz, std::min((double)b.hz, lz2)), ex = lx2 - cx, ez = lz2 - cz, d2 = ex * ex + ez * ez;
            if (d2 >= R * R) continue;
            double nlx, nlz, pen;
            if (d2 > 1e-8){ const double d = std::sqrt(d2); nlx = ex / d; nlz = ez / d; pen = R - d; }
            else { const double ox = b.hx - std::fabs(lx2), oz = b.hz - std::fabs(lz2); if (ox < oz){ nlx = lx2 < 0 ? -1 : 1; nlz = 0; pen = ox + R; } else { nlx = 0; nlz = lz2 < 0 ? -1 : 1; pen = oz + R; } }
            push(S, b.c * nlx + b.s * nlz, -b.s * nlx + b.c * nlz, pen);
        }
    }
}

} // namespace Beach
