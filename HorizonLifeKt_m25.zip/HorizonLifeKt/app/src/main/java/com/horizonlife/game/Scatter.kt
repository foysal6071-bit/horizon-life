package com.horizonlife.game

import java.util.concurrent.ConcurrentHashMap
import kotlin.math.*
import kotlin.random.Random

/**
 * Port of the JS scatterInstanced() bushes (65 % planted right around trees), rocks and the 1000 grass tufts, as a deterministic scatter per
 * 128 m chunk (same chunk grid as TreeField / Terrain). Purely decorative: like the JS, bushes / rocks / grass have no collision.
 * Also JS buildRiverBank (boulders / pebbles at the water line + reed clumps in the shallows) and the shore rocks of the island block.
 * Instance layout (10 floats): x y z | sx sy sz | rotY | r g b.
 */
object Scatter {
    const val CH = 128.0; const val F = 10
    class Chunk(val bush: FloatArray, val rock: FloatArray, val grass: FloatArray, val bank: FloatArray, val reed: FloatArray)
    private val cache = ConcurrentHashMap<Long, Chunk>()
    private fun key(cx: Int, cz: Int) = (cx.toLong() shl 32) xor (cz.toLong() and 0xffffffffL)
    private fun hash(a: Int, b: Int, k: Int): Double { val h = sin(a * 127.1 + b * 311.7 + k * 74.7 + 19.3) * 43758.5453; return h - floor(h) }

    /** JS isClear(x,z,12): off the roads, river, coast and dirt track */
    private fun clear(x: Double, z: Double): Boolean =
        World.coastDist(x, z) < -56 && abs(World.riverSd(x, z)) >= 40 && World.roadClearance(x, z) >= 12 && Track.dist(x, z) > 12 && !Harbor.near(x, z, 6.0)

    private fun hsl(h: Double, s: Double, l: Double, o: FloatArray, at: Int) {
        val q = if (l < 0.5) l * (1 + s) else l + s - l * s; val p = 2 * l - q
        fun f(t0: Double): Double { var t = t0; if (t < 0) t += 1.0; if (t > 1) t -= 1.0; return if (t < 1.0 / 6) p + (q - p) * 6 * t else if (t < 0.5) q else if (t < 2.0 / 3) p + (q - p) * (2.0 / 3 - t) * 6 else p }
        o[at] = f(h + 1.0 / 3).toFloat(); o[at + 1] = f(h).toFloat(); o[at + 2] = f(h - 1.0 / 3).toFloat()
    }

    private fun put(out: ArrayList<Float>, x: Double, y: Double, z: Double, sx: Double, sy: Double, sz: Double, rot: Double, r: Float, g: Float, b: Float) {
        out.add(x.toFloat()); out.add(y.toFloat()); out.add(z.toFloat()); out.add(sx.toFloat()); out.add(sy.toFloat()); out.add(sz.toFloat())
        out.add(rot.toFloat()); out.add(r); out.add(g); out.add(b)
    }

    private val RV = World.riverPolyline()
    private val TONES = arrayOf(0x8a8780, 0x77736b, 0x9a8f78, 0x6c6558, 0x857a66, 0x5f5b55)

    /** JS buildRiverBank restricted to the river samples that fall inside this chunk (own LCG per chunk instead of one global sequence) */
    private fun riverBank(cx: Int, cz: Int, bank: ArrayList<Float>, reed: ArrayList<Float>) {
        val rvx = RV.first; val rvz = RV.second; val n = rvx.size
        val x0 = cx * CH; val z0 = cz * CH; val rnd = Random((cx * 73856093L) xor (cz * 19349663L) xor 424242L)
        for (i in 0 until n - 1) {
            val ax = rvx[i]; val az = rvz[i]; val bx = rvx[i + 1] - ax; val bz = rvz[i + 1] - az
            if (max(ax, ax + bx) < x0 - 40 || min(ax, ax + bx) > x0 + CH + 40 || max(az, az + bz) < z0 - 40 || min(az, az + bz) > z0 + CH + 40) continue
            val L = hypot(bx, bz).let { if (it == 0.0) 1.0 else it }; val tx = bx / L; val tz = bz / L; val nx = -tz; val nz = tx
            var s0 = 0.0
            while (s0 < L) {
                val px = ax + tx * s0; val pz = az + tz * s0; s0 += 2.6
                if (px < x0 || px >= x0 + CH || pz < z0 || pz >= z0 + CH) continue
                for (side in intArrayOf(1, -1)) {
                    var wo = -1.0; var o = 8.0                          // water line on this side: first offset where the carved ground rises above the water
                    while (o < 34) { if (World.height(px + nx * side * o, pz + nz * side * o) > World.WATER_Y) { wo = o; break }; o += 0.5 }
                    if (wo < 0) continue
                    val qx = px + nx * side * wo; val qz = pz + nz * side * wo
                    if (World.roadClearance(qx, qz) < 9 || abs(World.riverSd(qx, qz)) < 11) continue      // leave bridges and roads alone
                    val cl = World.fNoise(qx / 17 + 9.1, qz / 17 - 3.3)                                   // clumpy: rocky, reedy or bare stretches
                    if (cl > 0.52 && rnd.nextDouble() < 0.85) {
                        val k = 1 + rnd.nextInt(2)
                        for (r in 0 until k) {
                            val oo = wo - 0.6 + rnd.nextDouble() * 1.6; val jx = (rnd.nextDouble() - 0.5) * 2.4; val jz = (rnd.nextDouble() - 0.5) * 2.4
                            val x = px + nx * side * (oo - wo) + tx * jx + nx * side * wo; val z = pz + nz * side * (oo - wo) + tz * jz + nz * side * wo
                            val h = World.height(x, z); val hs = 0.8 + rnd.nextDouble() * 0.9
                            if (h < -1.05 || h > 0.15) continue
                            put(reed, x, h, z, hs, hs, hs, rnd.nextDouble() * 6.283, 1f, 1f, 1f)
                        }
                    }
                    if (cl < 0.62 && rnd.nextDouble() < 0.8) {
                        val k = 1 + rnd.nextInt(3)
                        for (r in 0 until k) {
                            val oo = wo + (rnd.nextDouble() - 0.7) * 2.6
                            val x = px + nx * side * oo + tx * (rnd.nextDouble() - 0.5) * 2.4; val z = pz + nz * side * oo + tz * (rnd.nextDouble() - 0.5) * 2.4
                            val h = World.height(x, z)
                            val big = rnd.nextDouble() < 0.18; val sc = if (big) 0.55 + rnd.nextDouble() * 0.7 else 0.10 + rnd.nextDouble() * 0.30
                            val rot = rnd.nextDouble() * 6.283; val sx = 0.7 + rnd.nextDouble() * 0.5; val sy = 0.7 + rnd.nextDouble() * 0.4; val sz = 0.85 + rnd.nextDouble() * 0.4
                            if (h < -1.9 || h > 0.6) continue
                            val tone = TONES[rnd.nextInt(TONES.size)]; val wet = (if (h < -0.5) 0.62 else 0.9 + rnd.nextDouble() * 0.2) * (0.85 + rnd.nextDouble() * 0.3)
                            put(bank, x, h + sc * 0.12, z, sc * sx, sc * sy * 0.62, sc * sz * 1.08, rot,
                                ((tone shr 16 and 255) / 255f * wet).toFloat(), ((tone shr 8 and 255) / 255f * wet).toFloat(), ((tone and 255) / 255f * wet).toFloat())
                        }
                    }
                }
            }
        }
    }

    private val pool = java.util.concurrent.Executors.newSingleThreadExecutor { r -> Thread(r, "scatter-warm").apply { isDaemon = true; priority = Thread.MIN_PRIORITY } }
    private val queued = ConcurrentHashMap.newKeySet<Long>()
    /** GL-thread safe: the cached chunk, or null (and the chunk is built on a background thread so a later frame finds it) */
    fun peek(cx: Int, cz: Int): Chunk? {
        cache[key(cx, cz)]?.let { return it }
        val k = key(cx, cz)
        if (queued.add(k)) pool.execute { try { chunk(cx, cz) } catch (e: Throwable) { android.util.Log.e("HL", "scatter warm failed", e) } finally { queued.remove(k) } }
        return null
    }

    fun chunk(cx: Int, cz: Int): Chunk {
        cache[key(cx, cz)]?.let { return it }
        val bush = ArrayList<Float>(); val rock = ArrayList<Float>(); val grass = ArrayList<Float>(); val bank = ArrayList<Float>(); val reed = ArrayList<Float>()
        val trees = TreeField.chunk(cx, cz); val nt = trees.size / 5
        // bushes: 65 % right around a tree of this chunk (2-7 m), the rest anywhere clear
        for (k in 0 until 6) {
            val b = 100 + k * 8; val x: Double; val z: Double
            if (nt > 0 && hash(cx, cz, b) < 0.65) {
                val ti = min((hash(cx, cz, b + 1) * nt).toInt(), nt - 1); val a = hash(cx, cz, b + 2) * 2 * PI; val r = 2 + hash(cx, cz, b + 3) * 5
                x = trees[ti * 5] + cos(a) * r; z = trees[ti * 5 + 2] + sin(a) * r
            } else { x = (cx + hash(cx, cz, b + 1)) * CH; z = (cz + hash(cx, cz, b + 2)) * CH }
            if (!clear(x, z)) continue
            val s = 0.6 + hash(cx, cz, b + 4) * 1.0
            put(bush, x, World.height(x, z), z, s, s * (0.85 + 0.3 * hash(cx, cz, b + 6)), s, hash(cx, cz, b + 5) * 2 * PI, 0.302f, 0.427f, 0.212f)   // 0x4d6d36
        }
        // rocks: low-poly dodecahedra, 0.35-1.6 m, sitting 0.3 m above the ground like the JS
        for (k in 0 until 3) {
            val b = 200 + k * 8
            if (hash(cx, cz, b) > 0.45) continue
            val x = (cx + hash(cx, cz, b + 1)) * CH; val z = (cz + hash(cx, cz, b + 2)) * CH
            if (!clear(x, z)) continue
            val s = 0.35 + hash(cx, cz, b + 3) * 1.25
            put(rock, x, World.height(x, z) + 0.3, z, s, s, s, hash(cx, cz, b + 4) * 2 * PI, 0.553f, 0.600f, 0.682f)   // 0x8d99ae
        }
        // grass tufts: mostly the road verge (densest next to the shoulder), a few in the open field, never on the road
        val col = FloatArray(3)
        for (k in 0 until 24) {
            val b = 300 + k * 9
            val x = (cx + hash(cx, cz, b)) * CH; val z = (cz + hash(cx, cz, b + 1)) * CH
            val c = World.roadClearance(x, z)
            if (c < 3.0) continue
            val acc = if (c < 16.0) 0.12 + 0.6 * (1 - (c - 3) / 13).pow(1.5) else if (c >= 6) 0.10 else 0.0
            if (hash(cx, cz, b + 2) > acc) continue
            if (abs(World.riverSd(x, z)) < 30 || World.coastDist(x, z) > -52 || Harbor.near(x, z) || Track.dist(x, z) < 5) continue
            val s = 0.55 + hash(cx, cz, b + 3) * 0.75
            hsl(0.17 + hash(cx, cz, b + 4) * 0.08, 0.26 + hash(cx, cz, b + 5) * 0.17, 0.27 + hash(cx, cz, b + 6) * 0.14, col, 0)
            put(grass, x, World.height(x, z), z, s * (1.1 + hash(cx, cz, b + 7) * 0.6), s * (0.35 + hash(cx, cz, b + 8) * 0.4), s * (1.1 + hash(cx, cz, b + 7) * 0.6),
                hash(cx, cz, b + 2) * 97.0 % (2 * PI), col[0], col[1], col[2])
        }
        // shore rocks: dodecahedra on the beach / in the shallows, squashed, grey-brown (JS island block)
        val sc = FloatArray(3)
        for (k in 0 until 16) {
            val b = 500 + k * 7
            val x = (cx + hash(cx, cz, b)) * CH; val z = (cz + hash(cx, cz, b + 1)) * CH
            val cd = World.coastDist(x, z); if (cd < -24 || cd > 6 || abs(World.riverSd(x, z)) < 36 || Harbor.near(x, z, 2.0)) continue
            val s = 0.7 + hash(cx, cz, b + 2) * 2.0; val y = max(World.groundH(x, z), World.WATER_Y - 0.7) + 0.25 * s
            hsl(0.08 + hash(cx, cz, b + 3) * 0.05, 0.05 + hash(cx, cz, b + 4) * 0.1, 0.34 + hash(cx, cz, b + 5) * 0.2, sc, 0)
            put(rock, x, y, z, s * 1.25, s * 0.7, s, hash(cx, cz, b + 6) * 2 * PI, sc[0], sc[1], sc[2])
        }
        riverBank(cx, cz, bank, reed)
        val ch = Chunk(bush.toFloatArray(), rock.toFloatArray(), grass.toFloatArray(), bank.toFloatArray(), reed.toFloatArray())
        if (cache.size > 400) cache.clear()
        cache[key(cx, cz)] = ch
        return ch
    }
}
