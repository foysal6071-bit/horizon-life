package com.horizonlife.gl

import android.opengl.GLES30
import com.horizonlife.game.Environment
import com.horizonlife.game.Gardens
import com.horizonlife.game.TreeField
import com.horizonlife.game.Scatter
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.*

/** Instanced bushes (icosphere), rocks (dodecahedron) and crossed-quad grass tufts around the camera. Data: game/Scatter.kt. */
class ScatterRenderer {
    private val prog = GlUtil.program(Shaders.SCAT_VS, Shaders.SCAT_FS)
    private val locs = HashMap<String, Int>()
    private fun u(n: String) = locs.getOrPut(n) { GLES30.glGetUniformLocation(prog, n) }

    private class Inst(val vao: Int, val vbo: Int, val nVert: Int, val max: Int, val cpu: FloatBuffer, val tmp: FloatArray)
    private val bushes: Inst; private val rocks: Inst; private val grass: Inst; private val bank: Inst; private val reeds: Inst
    private val flowers: Array<Inst>
    private val farTrees: Inst

    companion object { const val RANGE_BUSH = 230.0; const val RANGE_ROCK = 230.0; const val RANGE_GRASS = 85.0; const val RANGE_BANK = 170.0; const val RANGE_REED = 150.0; const val RANGE_FLOWER = 95.0; const val MAX_FLOWER = 2600; const val FAR_MIN = 200.0; const val FAR_MAX = 540.0 }

    init {
        bushes = make(icosphere(0.9f), false, 320)
        rocks = make(dodecahedron(1f), false, 260)
        grass = make(grassQuads(), true, 520)
        bank = make(dodecahedron(1f), false, 700)
        reeds = make(reedClump(), true, 400)
        flowers = Array(3) { make(flowerGeo(it), true, MAX_FLOWER) }
        farTrees = make(icosphere(1f), false, 1100)
        // flower gardens removed on request (Gardens.start() no longer called)
    }

    // ---- geometry: flat shaded, interleaved pos(3) normal(3) uv(2) ----
    private fun tri(out: ArrayList<Float>, a: FloatArray, b: FloatArray, c: FloatArray) {
        var nx = (b[1] - a[1]) * (c[2] - a[2]) - (b[2] - a[2]) * (c[1] - a[1])
        var ny = (b[2] - a[2]) * (c[0] - a[0]) - (b[0] - a[0]) * (c[2] - a[2])
        var nz = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])
        val l = sqrt(nx * nx + ny * ny + nz * nz).let { if (it == 0f) 1f else it }; nx /= l; ny /= l; nz /= l
        val cx = (a[0] + b[0] + c[0]) / 3; val cy = (a[1] + b[1] + c[1]) / 3; val cz = (a[2] + b[2] + c[2]) / 3
        if (nx * cx + ny * cy + nz * cz < 0) { nx = -nx; ny = -ny; nz = -nz }          // always outward (shape is convex round the origin)
        for (v in arrayOf(a, b, c)) { out.add(v[0]); out.add(v[1]); out.add(v[2]); out.add(nx); out.add(ny); out.add(nz); out.add(0f); out.add(0f) }
    }
    private fun norm(v: FloatArray, r: Float): FloatArray { val l = sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]); return floatArrayOf(v[0] / l * r, v[1] / l * r, v[2] / l * r) }
    private fun mid(a: FloatArray, b: FloatArray) = floatArrayOf((a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2)

    /** THREE.IcosahedronGeometry(r, 1): 20 faces x 4 = 80 triangles */
    private fun icosphere(r: Float): FloatArray {
        val t = (1 + sqrt(5f)) / 2
        val v = arrayOf(floatArrayOf(-1f, t, 0f), floatArrayOf(1f, t, 0f), floatArrayOf(-1f, -t, 0f), floatArrayOf(1f, -t, 0f), floatArrayOf(0f, -1f, t), floatArrayOf(0f, 1f, t),
            floatArrayOf(0f, -1f, -t), floatArrayOf(0f, 1f, -t), floatArrayOf(t, 0f, -1f), floatArrayOf(t, 0f, 1f), floatArrayOf(-t, 0f, -1f), floatArrayOf(-t, 0f, 1f)).map { norm(it, r) }
        val f = intArrayOf(0, 11, 5, 0, 5, 1, 0, 1, 7, 0, 7, 10, 0, 10, 11, 1, 5, 9, 5, 11, 4, 11, 10, 2, 10, 7, 6, 7, 1, 8, 3, 9, 4, 3, 4, 2, 3, 2, 6, 3, 6, 8, 3, 8, 9, 4, 9, 5, 2, 4, 11, 6, 2, 10, 8, 6, 7, 9, 8, 1)
        val out = ArrayList<Float>()
        for (i in 0 until 20) {
            val a = v[f[i * 3]]; val b = v[f[i * 3 + 1]]; val c = v[f[i * 3 + 2]]
            val ab = norm(mid(a, b), r); val bc = norm(mid(b, c), r); val ca = norm(mid(c, a), r)
            tri(out, a, ab, ca); tri(out, ab, b, bc); tri(out, ca, bc, c); tri(out, ab, bc, ca)
        }
        return out.toFloatArray()
    }

    /** THREE.DodecahedronGeometry(r, 0): 12 pentagons -> 36 triangles. Faces found from the 12 icosahedron directions (5 nearest vertices each). */
    private fun dodecahedron(r: Float): FloatArray {
        val t = (1 + sqrt(5f)) / 2; val ri = 1 / t
        val v = ArrayList<FloatArray>()
        for (x in intArrayOf(-1, 1)) for (y in intArrayOf(-1, 1)) for (z in intArrayOf(-1, 1)) v.add(norm(floatArrayOf(x.toFloat(), y.toFloat(), z.toFloat()), r))
        for (s1 in intArrayOf(-1, 1)) for (s2 in intArrayOf(-1, 1)) {
            v.add(norm(floatArrayOf(0f, s1 * ri, s2 * t), r)); v.add(norm(floatArrayOf(s1 * ri, s2 * t, 0f), r)); v.add(norm(floatArrayOf(s2 * t, 0f, s1 * ri), r))
        }
        val dirs = ArrayList<FloatArray>()
        // face normals of this dodecahedron: (0, +-phi, +-1) and its cyclic permutations
        for (s1 in intArrayOf(-1, 1)) for (s2 in intArrayOf(-1, 1)) { dirs.add(floatArrayOf(0f, s1 * t, s2.toFloat())); dirs.add(floatArrayOf(s1 * t, s2.toFloat(), 0f)); dirs.add(floatArrayOf(s2.toFloat(), 0f, s1 * t)) }
        val out = ArrayList<Float>()
        for (d0 in dirs) {
            val d = norm(d0, 1f)
            val face = v.sortedByDescending { it[0] * d[0] + it[1] * d[1] + it[2] * d[2] }.take(5)
            val c = FloatArray(3); for (p in face) { c[0] += p[0] / 5; c[1] += p[1] / 5; c[2] += p[2] / 5 }
            // two tangent axes round d
            val up = if (abs(d[1]) < 0.9f) floatArrayOf(0f, 1f, 0f) else floatArrayOf(1f, 0f, 0f)
            val ax = norm(floatArrayOf(up[1] * d[2] - up[2] * d[1], up[2] * d[0] - up[0] * d[2], up[0] * d[1] - up[1] * d[0]), 1f)
            val ay = floatArrayOf(d[1] * ax[2] - d[2] * ax[1], d[2] * ax[0] - d[0] * ax[2], d[0] * ax[1] - d[1] * ax[0])
            val ord = face.sortedBy { p -> val rx = p[0] - c[0]; val ry = p[1] - c[1]; val rz = p[2] - c[2]; atan2(rx * ay[0] + ry * ay[1] + rz * ay[2], rx * ax[0] + ry * ax[1] + rz * ax[2]) }
            for (i in 1..3) tri(out, ord[0], ord[i], ord[i + 1])
        }
        return out.toFloatArray()
    }

    /** two crossed unit quads: x -0.5..0.5, y 0..1, uv (0..1) */
    private fun grassQuads(): FloatArray {
        val out = ArrayList<Float>()
        for (q in 0..1) {
            val a = q * PI.toFloat() / 2; val cx = cos(a) * 0.5f; val cz = sin(a) * 0.5f
            val p = arrayOf(floatArrayOf(-cx, 0f, -cz, 0f, 0f), floatArrayOf(cx, 0f, cz, 1f, 0f), floatArrayOf(cx, 1f, cz, 1f, 1f), floatArrayOf(-cx, 1f, -cz, 0f, 1f))
            for (i in intArrayOf(0, 1, 2, 0, 2, 3)) { val v = p[i]; out.add(v[0]); out.add(v[1]); out.add(v[2]); out.add(0f); out.add(1f); out.add(0f); out.add(v[3]); out.add(v[4]) }
        }
        return out.toFloatArray()
    }

    /** one reed clump: 8 tapered blades (3 triangles each) leaning outwards; uv.y = height / 1.9 drives the green -> straw colour in SCAT_FS */
    private fun reedClump(): FloatArray {
        val rnd = java.util.Random(7); val out = ArrayList<Float>()
        fun v(x: Float, y: Float, z: Float) { out.add(x); out.add(y); out.add(z); out.add(0f); out.add(1f); out.add(0f); out.add(0f); out.add(max(y, 0f) / 1.9f) }
        for (b in 0 until 8) {
            val a = rnd.nextFloat() * 6.283f; val d0 = rnd.nextFloat() * 0.35f; val bx = cos(a) * d0; val bz = sin(a) * d0
            val h = 0.9f + rnd.nextFloat() * 0.9f; val w = 0.035f + rnd.nextFloat() * 0.03f; val la = rnd.nextFloat() * 6.283f; val lean = 0.12f + rnd.nextFloat() * 0.28f
            val dx = cos(la); val dz = sin(la); val px = -dz; val pz = dx
            val p0 = floatArrayOf(bx, -0.05f, bz); val p1 = floatArrayOf(bx + dx * lean * h * 0.35f, h * 0.55f, bz + dz * lean * h * 0.35f); val p2 = floatArrayOf(bx + dx * lean * h, h, bz + dz * lean * h)
            fun e(p: FloatArray, s: Float) = v(p[0] + px * s, p[1], p[2] + pz * s)
            e(p0, -w); e(p0, w); e(p1, -w * 0.7f); e(p0, w); e(p1, w * 0.7f); e(p1, -w * 0.7f); e(p1, -w * 0.7f); e(p1, w * 0.7f); e(p2, 0f)
        }
        return out.toFloatArray()
    }


    // ---- flower clumps (JS makeGardenGeos, low poly): 3 flowers per instance; uv.x = 0 green / 0.5 cup / 1 petals ----
    private fun flowerGeo(sp: Int): FloatArray {
        val out = ArrayList<Float>()
        fun tri(a: FloatArray, b: FloatArray, c: FloatArray, u: Float) {
            var nx = (b[1] - a[1]) * (c[2] - a[2]) - (b[2] - a[2]) * (c[1] - a[1])
            var ny = (b[2] - a[2]) * (c[0] - a[0]) - (b[0] - a[0]) * (c[2] - a[2])
            var nz = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])
            val l0 = sqrt(nx * nx + ny * ny + nz * nz).let { if (it == 0f) 1f else it }; nx /= l0; ny /= l0; nz /= l0
            if (ny < 0) { nx = -nx; ny = -ny; nz = -nz }
            ny += 0.9f; val l = sqrt(nx * nx + ny * ny + nz * nz); nx /= l; ny /= l; nz /= l       // lean towards the sky: thin double-sided parts stay lit
            for (v in arrayOf(a, b, c)) { out.add(v[0]); out.add(v[1]); out.add(v[2]); out.add(nx); out.add(ny); out.add(nz); out.add(u); out.add(0f) }
        }
        fun p(x: Float, y: Float, z: Float) = floatArrayOf(x, y, z)
        fun quad(a: FloatArray, b: FloatArray, c: FloatArray, d: FloatArray, u: Float) { tri(a, b, c, u); tri(a, c, d, u) }
        fun stem(x: Float, z: Float, h: Float, bx: Float, bz: Float) {
            val w = 0.012f
            quad(p(x - w, 0f, z), p(x + w, 0f, z), p(x + bx + w, h, z + bz), p(x + bx - w, h, z + bz), 0f)
            quad(p(x, 0f, z - w), p(x, 0f, z + w), p(x + bx, h, z + bz + w), p(x + bx, h, z + bz - w), 0f)
        }
        fun leaf(x: Float, z: Float, ang: Float, len: Float, w: Float, rise: Float) {
            val dx = cos(ang); val dz = sin(ang); val px = -dz; val pz = dx
            val b0 = p(x + px * w, 0f, z + pz * w); val b1 = p(x - px * w, 0f, z - pz * w)
            val m0 = p(x + dx * len * .45f + px * w * .8f, rise * .75f, z + dz * len * .45f + pz * w * .8f); val m1 = p(x + dx * len * .45f - px * w * .8f, rise * .75f, z + dz * len * .45f - pz * w * .8f)
            val tip = p(x + dx * len, rise * .8f, z + dz * len)
            quad(b0, b1, m1, m0, 0f); tri(m0, m1, tip, 0f)
        }
        val offs = arrayOf(floatArrayOf(0f, 0f, 1f), floatArrayOf(0.13f, 0.07f, 0.85f), floatArrayOf(-0.09f, 0.12f, 0.93f))
        for ((i, o) in offs.withIndex()) {
            val x = o[0]; val z = o[1]; val k = o[2]
            when (sp) {
                0 -> {   // marigold pom-pom: dome of 2 rings + top fan
                    val H = 0.30f * k
                    stem(x, z, H, 0.01f, 0.01f)
                    val n = 8; val r0 = 0.085f; val r1 = 0.055f
                    fun ring(r: Float, y: Float, a: Int) = p(x + cos(a * 6.2832f / n) * r, y, z + sin(a * 6.2832f / n) * r)
                    for (a in 0 until n) {
                        tri(ring(r0, H, a), ring(r0, H, a + 1), ring(r1, H + .045f, a), 1f); tri(ring(r0, H, a + 1), ring(r1, H + .045f, a + 1), ring(r1, H + .045f, a), 1f)
                        tri(ring(r1, H + .045f, a), ring(r1, H + .045f, a + 1), p(x, H + .075f, z), 1f)
                    }
                    for (a in 0..1) leaf(x, z, (i * 2 + a) * 2.1f, 0.16f, 0.025f, 0.10f)
                }
                1 -> {   // daffodil: flat star of petals + short cup (trumpet) + strap leaves
                    val H = 0.62f * k
                    stem(x, z, H, 0f, 0.03f)
                    val n = 6; val zz = z + 0.03f
                    fun ring(r: Float, y: Float, a: Int) = p(x + cos(a * 6.2832f / n) * r, y, zz + sin(a * 6.2832f / n) * r)
                    for (a in 0 until n) {
                        tri(p(x, H, zz), ring(0.095f, H + 0.008f, a), ring(0.095f, H + 0.008f, a + 1), 1f)
                        quad(ring(0.036f, H, a), ring(0.036f, H, a + 1), ring(0.046f, H + .07f, a + 1), ring(0.046f, H + .07f, a), 0.5f)
                    }
                    for (a in 0..2) leaf(x, z, (i * 3 + a) * 2.1f + 0.35f, 0.30f * k, 0.02f, 0.30f)
                }
                else -> {   // tulip: ovoid cup (2 rings + point) + two broad blades
                    val H = 0.50f * k
                    stem(x, z, H, 0f, 0.02f)
                    val n = 6; val zz = z + 0.02f
                    fun ring(r: Float, y: Float, a: Int) = p(x + cos(a * 6.2832f / n) * r, y, zz + sin(a * 6.2832f / n) * r)
                    for (a in 0 until n) {
                        quad(ring(0.032f, H, a), ring(0.032f, H, a + 1), ring(0.048f, H + .05f, a + 1), ring(0.048f, H + .05f, a), 1f)
                        tri(ring(0.048f, H + .05f, a), ring(0.048f, H + .05f, a + 1), p(x, H + .11f, zz), 1f)
                    }
                    for (a in 0..1) leaf(x, z, (i * 2 + a) * 3.14f + 0.6f, 0.26f * k, 0.035f, 0.20f)
                }
            }
        }
        return out.toFloatArray()
    }


    /** far-LOD trees (stand-in for the JS impostors): one dark green ellipsoid crown per tree between FAR_MIN and FAR_MAX */
    private fun gatherFar(s: Inst, camX: Double, camZ: Double): Int {
        val lo = FAR_MIN * FAR_MIN; val hi = FAR_MAX * FAR_MAX; var n = 0
        val ccx = floor(camX / TreeField.CH).toInt(); val ccz = floor(camZ / TreeField.CH).toInt(); val rc = ceil(FAR_MAX / TreeField.CH).toInt()
        for (i in ccx - rc..ccx + rc) for (j in ccz - rc..ccz + rc) {
            val a = TreeField.peek(i, j) ?: continue; var k = 0
            while (k < a.size && n < s.max) {
                val dx = a[k] - camX; val dz = a[k + 2] - camZ; val d2 = dx * dx + dz * dz
                if (d2 in lo..hi) {
                    val sc = a[k + 3] * 1.25f; val o = n * Scatter.F; val rot = a[k + 4] % 10f; val v = 0.85f + 0.3f * ((rot * 7f) % 1f)
                    s.tmp[o] = a[k]; s.tmp[o + 1] = a[k + 1] + 5.2f * sc; s.tmp[o + 2] = a[k + 2]
                    s.tmp[o + 3] = 2.9f * sc; s.tmp[o + 4] = 4.6f * sc; s.tmp[o + 5] = 2.9f * sc; s.tmp[o + 6] = rot
                    s.tmp[o + 7] = 0.15f * v; s.tmp[o + 8] = 0.29f * v; s.tmp[o + 9] = 0.11f * v; n++
                }
                k += 5
            }
        }
        return n
    }

    private fun gatherFlowers(sp: Int, s: Inst, camX: Double, camZ: Double): Int {
        val r2 = RANGE_FLOWER * RANGE_FLOWER; var n = 0
        val ccx = floor(camX / Gardens.CELLC).toInt(); val ccz = floor(camZ / Gardens.CELLC).toInt(); val rc = ceil(RANGE_FLOWER / Gardens.CELLC).toInt()
        for (i in ccx - rc..ccx + rc) for (j in ccz - rc..ccz + rc) {
            val a = Gardens.bucket(i, j)?.lists?.get(sp) ?: continue; var k = 0
            while (k < a.size && n < s.max) {
                val dx = a[k] - camX; val dz = a[k + 2] - camZ
                if (dx * dx + dz * dz < r2) { System.arraycopy(a, k, s.tmp, n * Scatter.F, Scatter.F); n++ }
                k += Scatter.F
            }
        }
        return n
    }

    private fun make(geo: FloatArray, withUv: Boolean, max: Int): Inst {
        val id = IntArray(1)
        GLES30.glGenVertexArrays(1, id, 0); val vao = id[0]; GLES30.glBindVertexArray(vao)
        GLES30.glGenBuffers(1, id, 0); GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, id[0])
        val gb = ByteBuffer.allocateDirect(geo.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(geo).also { it.position(0) }
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, geo.size * 4, gb, GLES30.GL_STATIC_DRAW)
        GLES30.glEnableVertexAttribArray(0); GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 32, 0)
        GLES30.glEnableVertexAttribArray(1); GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 32, 12)
        if (withUv) { GLES30.glEnableVertexAttribArray(6); GLES30.glVertexAttribPointer(6, 2, GLES30.GL_FLOAT, false, 32, 24) }
        GLES30.glGenBuffers(1, id, 0); val vbo = id[0]; GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, max * Scatter.F * 4, null, GLES30.GL_DYNAMIC_DRAW)
        val st = Scatter.F * 4
        GLES30.glEnableVertexAttribArray(2); GLES30.glVertexAttribPointer(2, 3, GLES30.GL_FLOAT, false, st, 0); GLES30.glVertexAttribDivisor(2, 1)
        GLES30.glEnableVertexAttribArray(3); GLES30.glVertexAttribPointer(3, 3, GLES30.GL_FLOAT, false, st, 12); GLES30.glVertexAttribDivisor(3, 1)
        GLES30.glEnableVertexAttribArray(4); GLES30.glVertexAttribPointer(4, 1, GLES30.GL_FLOAT, false, st, 24); GLES30.glVertexAttribDivisor(4, 1)
        GLES30.glEnableVertexAttribArray(5); GLES30.glVertexAttribPointer(5, 3, GLES30.GL_FLOAT, false, st, 28); GLES30.glVertexAttribDivisor(5, 1)
        GLES30.glBindVertexArray(0)
        return Inst(vao, vbo, geo.size / 8, max, ByteBuffer.allocateDirect(max * Scatter.F * 4).order(ByteOrder.nativeOrder()).asFloatBuffer(), FloatArray(max * Scatter.F))
    }

    private fun gather(s: Inst, camX: Double, camZ: Double, range: Double, pick: (Scatter.Chunk) -> FloatArray): Int {
        val r2 = range * range; var n = 0
        val ccx = floor(camX / Scatter.CH).toInt(); val ccz = floor(camZ / Scatter.CH).toInt(); val rc = ceil(range / Scatter.CH).toInt()
        for (i in ccx - rc..ccx + rc) for (j in ccz - rc..ccz + rc) {
            val a = pick(Scatter.peek(i, j) ?: continue); var k = 0
            while (k < a.size && n < s.max) {
                val dx = a[k] - camX; val dz = a[k + 2] - camZ
                if (dx * dx + dz * dz < r2) { System.arraycopy(a, k, s.tmp, n * Scatter.F, Scatter.F); n++ }
                k += Scatter.F
            }
        }
        return n
    }

    private fun drawSet(s: Inst, n: Int, grassMode: Boolean, reedMode: Boolean = false) {
        if (n == 0) return
        s.cpu.clear(); s.cpu.put(s.tmp, 0, n * Scatter.F); s.cpu.position(0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, s.vbo); GLES30.glBufferSubData(GLES30.GL_ARRAY_BUFFER, 0, n * Scatter.F * 4, s.cpu)
        GLES30.glUniform1f(u("uGrass"), if (grassMode) 1f else 0f); GLES30.glUniform1f(u("uReed"), if (reedMode) 1f else 0f)
        GLES30.glBindVertexArray(s.vao); GLES30.glDrawArraysInstanced(GLES30.GL_TRIANGLES, 0, s.nVert, n)
    }

    fun draw(vp: FloatArray, env: Environment, sun: FloatArray, fog: FloatArray, camX: Float, camY: Float, camZ: Float, time: Float) {
        GLES30.glUseProgram(prog)
        GLES30.glUniformMatrix4fv(u("uVP"), 1, false, vp, 0)
        GLES30.glUniform3f(u("uCam"), camX, camY, camZ); GLES30.glUniform3fv(u("uFog"), 1, fog, 0); GLES30.glUniform3fv(u("uSun"), 1, sun, 0)
        GLES30.glUniform3fv(u("uSunCol"), 1, env.sunCol, 0); GLES30.glUniform3fv(u("uAmbCol"), 1, env.ambCol, 0); GLES30.glUniform1f(u("uTime"), time)
        GLES30.glDisable(GLES30.GL_CULL_FACE)
        GLES30.glUniform1f(u("uFlower"), 0f)
        drawSet(bushes, gather(bushes, camX.toDouble(), camZ.toDouble(), RANGE_BUSH) { it.bush }, false)
        drawSet(rocks, gather(rocks, camX.toDouble(), camZ.toDouble(), RANGE_ROCK) { it.rock }, false)
        drawSet(grass, gather(grass, camX.toDouble(), camZ.toDouble(), RANGE_GRASS) { it.grass }, true)
        drawSet(bank, gather(bank, camX.toDouble(), camZ.toDouble(), RANGE_BANK) { it.bank }, false)
        drawSet(reeds, gather(reeds, camX.toDouble(), camZ.toDouble(), RANGE_REED) { it.reed }, false, true)
        drawSet(farTrees, gatherFar(farTrees, camX.toDouble(), camZ.toDouble()), false)
        if (false && Gardens.ready) {
            GLES30.glUniform1f(u("uFlower"), 1f)
            for (sp in 0..2) drawSet(flowers[sp], gatherFlowers(sp, flowers[sp], camX.toDouble(), camZ.toDouble()), false)
            GLES30.glUniform1f(u("uFlower"), 0f)
        }
        GLES30.glBindVertexArray(0); GLES30.glEnable(GLES30.GL_CULL_FACE)
    }
}
