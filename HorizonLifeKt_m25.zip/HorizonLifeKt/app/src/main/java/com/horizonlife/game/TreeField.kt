package com.horizonlife.game

import java.util.concurrent.ConcurrentHashMap
import kotlin.math.*

/**
 * Deterministic tree scatter per 128 m terrain chunk (moved out of gl/Terrain.kt so the collision code sees exactly the same trees
 * the renderer draws). Result per chunk: x, y, z, scale, rot for every tree. Cached; safe to call from worker + GL threads.
 */
object TreeField {
    const val CH = 128.0
    const val MAPLE = 10f      // rot >= MAPLE marks a maple tree (rot - MAPLE = real rotation)
    private val cache = ConcurrentHashMap<Long, FloatArray>()
    private fun key(cx: Int, cz: Int) = (cx.toLong() shl 32) xor (cz.toLong() and 0xffffffffL)
    private fun hash(a: Int, b: Int, k: Int): Double { val h = sin(a * 127.1 + b * 311.7 + k * 74.7) * 43758.5453; return h - floor(h) }

    private val pool = java.util.concurrent.Executors.newSingleThreadExecutor { r -> Thread(r, "tree-warm").apply { isDaemon = true; priority = Thread.MIN_PRIORITY } }
    private val queued = ConcurrentHashMap.newKeySet<Long>()
    /** GL-thread safe: cached trees of the chunk or null (built in the background) */
    fun peek(cx: Int, cz: Int): FloatArray? {
        cache[key(cx, cz)]?.let { return it }
        val k = key(cx, cz)
        if (queued.add(k)) pool.execute { try { chunk(cx, cz) } catch (e: Throwable) { android.util.Log.e("HL", "tree warm failed", e) } finally { queued.remove(k) } }
        return null
    }

    fun chunk(cx: Int, cz: Int): FloatArray {
        cache[key(cx, cz)]?.let { return it }
        val out = ArrayList<Float>()
        for (k in 0 until 12) {
            val x = (cx + hash(cx, cz, k * 3)) * CH; val z = (cz + hash(cx, cz, k * 3 + 1)) * CH
            if (World.coastDist(x, z) > -90 || abs(World.riverSd(x, z)) < 40 || World.roadClearance(x, z) < 10 || Track.dist(x, z) < 12 || Harbor.near(x, z, 6.0)) continue
            val y = World.height(x, z); if (y < 0.4) continue
            out.add(x.toFloat()); out.add(y.toFloat() - 0.05f); out.add(z.toFloat())
            out.add((0.8 + hash(cx, cz, k * 3 + 2) * 0.9).toFloat()); out.add((hash(cz, cx, k) * 6.2832).toFloat() + (if (hash(cx, cz, k * 3 + 57) < 0.175) MAPLE else 0f))   // JS: 70 of 400 trees are maple
        }
        val a = out.toFloatArray()
        if (cache.size > 600) cache.clear()
        cache[key(cx, cz)] = a
        return a
    }
}
