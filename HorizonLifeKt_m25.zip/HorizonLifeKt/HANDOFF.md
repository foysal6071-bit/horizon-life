# HANDOFF — HTML (Three.js) → native Kotlin port of "Horizon Life"

Source of truth: `game_6_realistic_mud_tracks.html` (6538 lines, 2.8 MB; ~490 KB is code, rest base64 assets). Attach it again in the new chat.
Target: this Android Studio project (Kotlin + OpenGL ES 3.0, no WebView, no Three.js). Package `com.horizonlife`.
Status (m18): ~99% of the LIVE JS features are in some form, ~77% by code lines (see wc below vs JS = 6538 lines). Honest note: remaining items are visual polish; correctness is UNKNOWN until the first compile/run. NOTHING HAS BEEN COMPILED OR RUN yet (no Android SDK in the sandbox).
Original HTML is inside the user's APK: assets/html/game_6_realistic_mud_tracks (1).html (6538 lines, identical).

## Done (see README.md for the JS↔Kotlin table)
- game/VehiclePhysics.kt  1:1 port of JS `Veh` (lines ~3991-4160)
- game/CarState.kt, Game.kt (animate step, 4-wheel terrain follow, roll/pitch springs, reset), CameraRig.kt (chase cam, drag orbit, pinch)
- game/World.kt  groundH / coast / river (Catmull-Rom + grid) / fieldNoise / fieldH, fixed hill seed; surfaceAt (mu, rr, rideY) road vs grass only
- game/Roads.kt  ringRad rings 220/420, connector, roadClearance/fieldClear grid; game/Environment.kt day/night (updateEnv)
- gl/Terrain.kt (128 m streamed chunks, 2 worker threads, vertex colours), RoadMesh.kt, R8Model.kt (assets r8.bin + r8_meta.json),
  Trees.kt (assets tree_*.bin/png/jpg, instanced, nearest 40 within 220 m), Shaders.kt, GameRenderer.kt
- ui/ControlsView.kt  multitouch buttons, speed/gear HUD, ↺ reset, ☀/☾ day-night toggle

- m10: game/Potholes.kt (JS POTH, same seed/LCG; wheel spring + nod in Game.potholes, wheelDy -> R8Model, decal shader POTH_* + GameRenderer.drawPotholes),
  game/TreeField.kt (tree scatter moved out of Terrain, shared with collision) + game/Obstacles.kt (tree-trunk circles = JS collideWith, coastGuard wall 52 m inside the coast),
  clouds in SKY_FS (fbm deck, uCl/uCs from Environment.cloudLit/cloudShade; no SKY_FACES photo cubemap). Fixed a compile bug in Terrain.plantTrees (missing `;`).
- m11 (mud): game/Mud.kt (mudAt, tyre mud level, clumps/mist/splats = JS updateMud/updateTyreMud), game/Marks.kt (JS updateMarks ring buffer of 14000 strip quads),
  gl/MudRenderer.kt (+ MARK_/CLUMP_/MIST_/SPLAT_ shaders; Game.update calls Marks.update + Mud.update; wheels/rims tinted by Mud.lvl in R8Model.draw).
  Simplified vs JS: marks use a procedural tread/smear shader (no height/normal atlas), no puddle wetness, no dirt-track mud, no mud shader on the car body (only tyres/rims), no tyre smoke yet (Marks.smoke[] holds the intensity), no splat/clump shadows.
- m12 (dirt track, scatter, smoke): game/Track.kt (JS buildTrack/trackQ/trackDist, fixed phases, graded height, thread-safe query; built in Game.init BEFORE terrain workers start),
  hooks: World.fieldH (grading), World.surfaceAt (packed dirt mu 1.05 / rr 0.032), Mud.at (track = wet mud), TreeField (no trees within 12 m), Terrain.color (bare earth beside the track), Minimap (pale line).
  gl/TrackMesh.kt: ribbon + verges following the REAL 4 m terrain triangles (diagonal b-c), drawn with the ROAD shader after the roads.
  game/Scatter.kt + gl/ScatterRenderer.kt: bushes (icosphere, 65 % round trees), rocks (dodecahedron, +0.3 m), grass tufts (crossed quads, procedural blades, wind sway), per 128 m chunk, instanced, ranges 230 / 230 / 85 m. No collision (same as JS).
  game/Smoke.kt (+ SMOKE_* shaders in MudRenderer): JS updateSmoke, 110 puffs from Marks.smoke[w] (hard braking / drifting only).
- m13 (river bank + shore): Scatter.kt now also has JS buildRiverBank (boulders/pebbles at the water line = `bank`, reed clumps = `reed`, per-chunk LCG, walks the river polyline samples inside each chunk) and the island shore rocks (merged into `rock`). ScatterRenderer: `bank` (dodecahedron, 170 m) and `reeds` (8-blade clump, 150 m, colour from uv.y via uReed in SCAT_FS).
- m14 (harbor): game/Harbor.kt (JS PIER find(), pierLocal/nearPier, yard obstacles = gantry poles / warehouse / containers, pier rails + end rail in coastGuard, `onPier` -> no tyre marks/mud), flat ground round the pier (World.fieldMask term).
  gl/HarborRenderer.kt + HARBOR_VS/FS: merged static meshes (plank deck with procedural planks, piles, rails, gantry + textured "HARBOR PIER" sign made with Canvas, concrete apron, warehouse, containers), 7 bobbing boats (own meshes + model matrix), wooden coast rail round the whole island (gap at pier / river), blended shore foam band (drawn after the water). Minimap shows the pier.
  Exclusions added (nearPier): TreeField, Scatter (bushes/rocks/grass/shore rocks), Fence, Potholes.
  Simplified vs JS: piles / mast are square boxes (no cylinders), concrete is procedural (no makeConcreteTexture), no 'Harbor pier' toast, no lamp/night lighting on the pier, boats' random yaw fixed.
- m15 (sky + sea + map): assets sky_atlas.jpg (SKY_FACES 5 faces -> 3x2 atlas, 512 px), mtn_col.jpg / mtn_data.png (MTN_COL / MTN_DATA, 4096x512). SKY_FS = JS sky shader: photo cubemap (slow drift, Environment.cubeTint), baked 360 deg mountains (haze from uHor), real moon disc + Milky Way + 3 star layers, sun glow from Environment.skySun (true sun even at night). Textures are flipped on load (= Three.js flipY).
  WATER_FS = JS patchSea: 6 travelling peaked waves, analytic normals, crest glow/foam, depth map (GameRenderer builds the 512x512 R8 map from World.groundH on a background thread; water fades out at the waterline, sandy shallows, lapping shore foam, see-through teal river). The JS `foam` band mesh is visible=false, so HarborRenderer.drawFoam is no longer called.
  UI: Game.showToast + toast bar (shows 'Harbor pier' on entering the pier head); full-screen map (tap the minimap, tap to close; north up, car arrow, PIER label).
  Simplified vs JS: no rain/flash terms in the sky (JS never rains), no reflection (envmap) on the water, water base colour is a hand-tuned stand-in for the PBR material.
- m16 (settings + camera modes): game/Settings.kt (JS `settings`, SharedPreferences), ui/SettingsPanel.kt (Canvas window, tabs Graphics / Sound / Camera / Regulation / HUD; sliders, segmented buttons, scroll).
  CameraRig now has chase / close (x0.72) / hood / bumper (first person, car hidden in bumper), camera distance / height / sky lift / FOV, speed-FOV, high-speed shake. Resolution scale = GLSurfaceView fixed size (MainActivity.applyResolution). Master volume + mute, HUD toggles (minimap / speed / fps / buttons), HUD size + opacity. New top-right buttons: pause, settings. Toasts 'Bump!' and 'Car reset'.
  Not ported from the JS settings: render distance, tree detail distance, Optimization switches, control mode 'wheel' + steering sensitivity, HUD drag-to-move layout, ambient sound.
- m17 (ambient + wheel + quality settings): EngineSound ambient bed = JS initAmb/updateExtras (calm wind, night crickets 4.3 kHz with 34 Hz flutter + 2.6 Hz gate, daytime bird chirps every 1.5-6 s; rain/thunder skipped, JS never rains; Game.update -> EngineSound.setEnv(day, night)).
  Steering wheel mode (JS tWheel): drag-to-turn wheel (+-135 deg, self-centres, analog = -rot/135) replaces the L/R buttons; steering sensitivity slider feeds DriveInput.sens/analog. Settings > Control tab; Graphics tab: render distance (Terrain.RAD from Settings.renderDist 380-770 m) and tree detail count (Trees: nearest N <= 40).
- m18 (birds + flower gardens): game/Birds.kt = JS BSP/mkFlock/respawn/updateBirds (goose V-formations, gulls, small flocks, raptor orbits; 7 flocks, respawn ahead of the car, daytime only via Environment.skySun[1]); gl/BirdRenderer.kt + BIRD_VS/FS = JS birdGeo + wing flap in the vertex shader (instanced, 4 species). Settings.flocks (0-7) + slider in Graphics tab.
  game/Gardens.kt = JS buildGardens placement (2 m raster of bands behind the rope fence along every road, crest-limited depth, ragged ends, marigold 45 / daffodil 30 / tulip 25 % patches, spacing adapts to a 70k clump budget, built on a background thread); drawn by ScatterRenderer (uFlower mode in SCAT_VS/FS, 3 low-poly clump meshes, range 95 m, max 2600 clumps per species).
  Simplified vs JS: no stone border around gardens, no brown soil tint under gardens, no far-LOD flower meshes, birds have no rain logic (JS never rains).
- m19: far-LOD tree crowns (ellipsoids, no impostor textures, no maple), headlight lens halos, presets drive flocks/treeMax/renderDist, GitHub workflow. STILL NOT DONE: body mud shader, env-map reflections, HUD drag-to-move, garden stone border/soil tint, maple. NOT COMPILED.
- FINDING 2: walker mode (`walker.on`, `placeWalker`) and the ramp / air-time code (`rampHeight` returns 0, RAMP.L = 0) are dead code in the JS: nothing ever sets them. They are NOT missing and must not be ported.
- FINDING: the JS has puddles DISABLED (`n = 0 // puddles removed`) and NO weather (`wthr.target = 0`, never rains) -> puddles/rain/thunder are intentionally NOT ported.

- m22: body mud shader + wheel mud shader done (see README). Still open: env-map reflections, maple, HUD drag-to-move, garden stone border, Optimization switches, 3D tread lumps.

- m23: flower gardens REMOVED on request (do not re-add).

- m24: maple, analytic env reflections, 3D tread lumps, Optimization tab, HUD drag-to-move DONE (see README). Open: real cube-map reflections, garden border (gardens removed), anything the first compile/run reveals.

- m25: ANR + black 3D view seen on a real device (HUD drew, scene black, "isn't responding"). Suspected: heavy GL-thread work in the first frame (now moved to background). Check Logcat tag HL.

## Known gaps / simplifications
- Bridges (m6): game/Bridges.kt (spans, arch lift, rail walls, river-bank wall) + gl/BridgeMesh.kt (planks, stringers, kerbs, rails, posts, beams, piles). Missing vs JS: dirt blend layers on planks, wood texture (procedural now), bridge sound/mud.
- Car ride height now uses fieldH + bridge lift (JS carGroundH); river bed no longer carried by a fake road deck.
- m7: game/Lamps.kt (placement + solid poles that lean) + game/Collision.kt (bounceOff, bump counter `Collision.hits`, world-edge wall) + drawLamps/drawGlow in GameRenderer (lantern pools, halos, headlight pool; night factor = Environment.night). Missing: obstacle circles (roadObstacles/hillSpots), breakable fence, bump toast/sound, real headlight mesh glow, lamp wood texture/brace.
- m8: game/EngineSound.kt = JS `sfx` (R8 recording loops assets/engine_*.pcm decoded offline; RPM pitch + idle/main crossfade, wind, squeal, rev-limiter chop, gear dip, bump thud). Started/stopped in MainActivity onResume/onPause. Missing: ambient sound (wind/rain/crickets/birds/thunder), mute/volume UI (EngineSound.muted / .vol exist).
- m9: game/Fence.kt (post-and-rope roadside fence, breakable, restores after a lap; drawn in GameRenderer.drawFence with cube primitives, 130 m range), ui/Minimap.kt (rotating minimap, base bitmap 1 px/m: sea/coast/river/roads; no houses/pier/track yet), HUD: mute button (♪/✕) + bump counter.
- Dirt track: no mud shader dressing beyond the shared ROAD shader (m13 added bank rocks/reeds, m14 the pier / coast rail / boats; houses/garages do not exist in the JS: disabled)
- Water: m15 ported the wave/depth shader (no reflections / env maps / clearcoat on car or water); sky is complete except the rain terms
- Trees: no far impostor LOD, no maple; no flower gardens
- Still missing (live in the JS): (birds + flower gardens DONE in m18), tree far-LOD impostors + maple (MAPLE_B64), body mud shader (JS 3834-3964), real headlight mesh glow, env-map reflections / clearcoat on the car + water, Optimization switches.
- Not to be ported (dead in the JS): walker mode, ramp / air time, puddles, rain / thunder

## Suggested order for next chat
0. FIRST: build in Android Studio, fix compile errors / crashes / GL shader errors (ask user for Logcat or screenshots). Verify driving feels like the JS.
1. DONE: bridges m6, lamps m7, sound m8, fence/minimap m9, potholes/tree collision/clouds m10 (puddles+rain are disabled in the JS itself)
2. DONE m15: SKY_FACES cubemap + MTN_COL mountains + moon/Milky Way, ocean waves + shore. Still open: real headlight mesh glow
3. DONE m11: mud spray, tyre marks, splats, tyre mud tint. Still open: body mud shader (JS 3834-3964), tyre smoke (JS ~5470), tyre lumps
4. DONE m12: bushes/rocks/grass, dirt track. Still open: daffodil/marigold flower gardens (JS 2484-3064), tree LOD impostors + maple, (DONE m14: pier + harbor yard + boats + island coast rail.) (Houses/garages are disabled in the JS.)
5. DONE m15: full map + toast. DONE m16: settings UI (see above), camera modes, pause. DONE m17: ambient sound, wheel mode, render distance / tree count. Open: Optimization switches (LOW mode), HUD drag-to-move

## Workflow notes
- Large embedded assets are decoded OFFLINE with python/node into /assets (see how r8.bin and tree_*.bin were made); never ship base64 in Kotlin.
- JS line numbers refer to the uploaded HTML. Strip long base64 lines first: `awk 'length($0)>1500{print substr($0,1,100)"...";next}{print}' file.html > stripped.js`.
- JS frame: heading 0 faces +Z, positive heading turns left (+X). Kotlin keeps the same convention.
