// Sunny Drift - OpenGL ES 3 rendering of the asphalt road network (see road.h for the geometry).
//  draw order = HTML: ring roads (depth bias -2) + dirt track (-2) -> connector road (-5) -> ring verges (-4, blended) -> connector verges (-7, blended) + track verges (-4)
#pragma once
#include <GLES3/gl3.h>
#include <cstring>
#include <vector>
#include <android/log.h>
#include "road.h"
#include "road_shaders.h"
#include "weather.h"
#include "road_cull.h"
#include "sun_light.h"
#include "quality.h"
#include "water_fx.h"
#include "asphalt_tex.h"

namespace RoadGL {
static GLint uR_Pz = -1, uR_PzN = -1, uR_Rp = -1, uR_RpN = -1;                                                              // puddle zones of the road being drawn + wheel ripples
static GLint uR_Lite = -1, uR_Wet = -1, uR_Rip = -1, uR_SunK = -1, uR_Clk = -1, uR_Ref = -1, uR_SunD = -1, uV_Wet = -1;      // weather uniforms

struct GpuMesh { GLuint vao = 0, vbo = 0, ibo = 0; GLsizei count = 0; std::vector<RoadCull::Chunk> chunks; };
static GpuMesh gRoad, gVerge, gTrk, gTrkV;
static std::vector<GpuMesh> gEdges;                 // one asphalt ribbon per road of the web (own length -> paint stops 9 m before each junction)
static GLuint gProgRoad = 0, gProgVerge = 0;
static GLuint gAspTex = 0; static int gAspLv = -1; static GLint uR_Asp = -1;
static GLuint gColA = 0, gVergeTex = 0, gNoiseTex = 0, gFbmTex = 0;                   // gColA = small grey grain texture, only used for the bridge's asphalt blend patch
static GLint uR_Pk = -1, uV_Q = -1; static int gAnisoLv = -1;
static GLint uR_VP, uR_Cam, uR_EndL, uR_EndR, uR_Noise, uR_Fbm, uV_VP, uV_Cam, uV_Tex, uV_Noise;
static float gPlanes[6][4]; static std::vector<std::pair<uint32_t,uint32_t>> gRanges;   // frustum of the current frame

static bool gLastOk = true;                       // did the last makeProg() compile + link?
static GLuint compileSh(GLenum t, const char* s){
    GLuint sh = glCreateShader(t); SunLight::shaderSource(sh, s); glCompileShader(sh);
    GLint ok = 0; glGetShaderiv(sh, GL_COMPILE_STATUS, &ok);
    if (!ok){ char log[1024]; GLsizei n = 0; glGetShaderInfoLog(sh, sizeof log - 1, &n, log); log[n] = 0; gLastOk = false;
              __android_log_print(ANDROID_LOG_ERROR, "SunnyDrift", "%s shader compile failed: %s", t == GL_VERTEX_SHADER ? "vertex" : "fragment", log); }
    return sh;
}
static GLuint makeProg(const char* vs, const char* fs){
    gLastOk = true;
    GLuint p = glCreateProgram(); glAttachShader(p, compileSh(GL_VERTEX_SHADER, vs)); glAttachShader(p, compileSh(GL_FRAGMENT_SHADER, fs));
    glLinkProgram(p); SunLight::attach(p);
    GLint ok = 0; glGetProgramiv(p, GL_LINK_STATUS, &ok);
    if (!ok){ gLastOk = false; char log[1024]; GLsizei n = 0; glGetProgramInfoLog(p, sizeof log - 1, &n, log); log[n] = 0; __android_log_print(ANDROID_LOG_ERROR, "SunnyDrift", "program link failed: %s", log); }
    return p;
}

// asset = int32 width, int32 height, then pixels (row 0 = texture v 0, like three.js with flipY)
static GLuint makeTex(const std::vector<char>& f, bool oneChannel){
    if (f.size() < 8) return 0;
    int w, h; memcpy(&w, f.data(), 4); memcpy(&h, f.data() + 4, 4);
    GLuint t; glGenTextures(1, &t); glBindTexture(GL_TEXTURE_2D, t);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    if (oneChannel) glTexImage2D(GL_TEXTURE_2D, 0, GL_R8, w, h, 0, GL_RED, GL_UNSIGNED_BYTE, f.data() + 8);
    else            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, f.data() + 8);
    glGenerateMipmap(GL_TEXTURE_2D);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    const char* ext = (const char*)glGetString(GL_EXTENSIONS);
    if (ext && strstr(ext, "GL_EXT_texture_filter_anisotropic")){                    // sharp tarmac at grazing angles
        GLfloat mx = 1; glGetFloatv(0x84FF, &mx); glTexParameterf(GL_TEXTURE_2D, 0x84FE, mx < 8.f ? mx : 8.f);
    }
    return t;
}

static GpuMesh upload(const Road::Mesh& m){
    GpuMesh g; g.count = (GLsizei)m.idx.size(); if (!g.count) return g;
    glGenVertexArrays(1, &g.vao); glBindVertexArray(g.vao);
    glGenBuffers(1, &g.vbo); glBindBuffer(GL_ARRAY_BUFFER, g.vbo); glBufferData(GL_ARRAY_BUFFER, m.v.size() * 4, m.v.data(), GL_STATIC_DRAW);
    const GLsizei ST = Road::VSTRIDE * 4;                                                  // pos3 uv2 normal3 along1 curvature1
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, ST, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, ST, (void*)12);
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, ST, (void*)20);
    glEnableVertexAttribArray(3); glVertexAttribPointer(3, 2, GL_FLOAT, GL_FALSE, ST, (void*)32);
    glGenBuffers(1, &g.ibo); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, g.ibo); glBufferData(GL_ELEMENT_ARRAY_BUFFER, m.idx.size() * 4, m.idx.data(), GL_STATIC_DRAW);
    glBindVertexArray(0); g.chunks = RoadCull::build(m.v.data(), m.idx, Road::VSTRIDE); return g;
}
static void drawMesh(const GpuMesh& g){   // only the index ranges whose bounding box is inside the camera frustum
    if (!g.count) return;
    RoadCull::ranges(g.chunks, gPlanes, gRanges); if (gRanges.empty()) return;
    glBindVertexArray(g.vao);
    for (const auto& r : gRanges) glDrawElements(GL_TRIANGLES, (GLsizei)r.second, GL_UNSIGNED_INT, (void*)((size_t)r.first * 4));
    glBindVertexArray(0);
}

// RGBA8 texture from raw pixels (repeat + mipmaps + a little anisotropy)
static GLuint makeTexRaw(const std::vector<uint8_t>& px, int w, int h, float aniso){
    GLuint t; glGenTextures(1, &t); glBindTexture(GL_TEXTURE_2D, t); glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, px.data()); glGenerateMipmap(GL_TEXTURE_2D);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    const char* ext = (const char*)glGetString(GL_EXTENSIONS);
    if (aniso > 1.f && ext && strstr(ext, "GL_EXT_texture_filter_anisotropic")){ GLfloat mx = 1; glGetFloatv(0x84FF, &mx); glTexParameterf(GL_TEXTURE_2D, 0x84FE, mx < aniso ? mx : aniso); }
    return t;
}

// Call once with a current GL context (after Road::init()).
static void init(const std::vector<char>& colA, const std::vector<char>& hgtA, const std::vector<char>& colB,
                 const std::vector<char>& hgtB, const std::vector<char>& verge){
    Road::finish();                                                                       // (normally already done by the caller, with the village veto) builds the road meshes
    gProgRoad = makeProg(ROAD_VS, ROAD_FS); gProgVerge = makeProg(ROAD_VS, VERGE_FS);
    uR_VP = glGetUniformLocation(gProgRoad, "uVP"); uR_Cam = glGetUniformLocation(gProgRoad, "uCam");
    uR_Pk = glGetUniformLocation(gProgRoad, "uPk"); uR_EndL = glGetUniformLocation(gProgRoad, "uEndL"); uR_EndR = glGetUniformLocation(gProgRoad, "uEndR");
    uR_Wet = glGetUniformLocation(gProgRoad, "uWet"); uR_Rip = glGetUniformLocation(gProgRoad, "uRip"); uR_SunK = glGetUniformLocation(gProgRoad, "uSunK"); uR_Clk = glGetUniformLocation(gProgRoad, "uClk");
    uR_Ref = glGetUniformLocation(gProgRoad, "uRef"); uR_SunD = glGetUniformLocation(gProgRoad, "uSunD"); uV_Wet = glGetUniformLocation(gProgVerge, "uWet");
    uR_Pz = glGetUniformLocation(gProgRoad, "uPz[0]"); uR_PzN = glGetUniformLocation(gProgRoad, "uPzN"); uR_Rp = glGetUniformLocation(gProgRoad, "uRp[0]"); uR_RpN = glGetUniformLocation(gProgRoad, "uRpN");
    uR_Lite = glGetUniformLocation(gProgRoad, "uLite"); uR_Noise = glGetUniformLocation(gProgRoad, "uNoise"); uR_Fbm = glGetUniformLocation(gProgRoad, "uFbm"); uR_Asp = glGetUniformLocation(gProgRoad, "uAsp"); uV_Noise = glGetUniformLocation(gProgVerge, "uNoise");
    uV_VP = glGetUniformLocation(gProgVerge, "uVP"); uV_Cam = glGetUniformLocation(gProgVerge, "uCam"); uV_Tex = glGetUniformLocation(gProgVerge, "uTex"); uV_Q = glGetUniformLocation(gProgVerge, "uQ");
    {   // 64x64 grey tarmac grain (the old mud textures are no longer used)
        std::vector<char> g(8 + 64 * 64 * 4); int w = 64; memcpy(g.data(), &w, 4); memcpy(g.data() + 4, &w, 4);
        uint32_t s = 12345; for (int i = 0; i < 64 * 64; i++){ s = s * 1664525u + 1013904223u; int v = 98 + (int)((s >> 24) % 22);
            g[8 + i*4] = (char)v; g[9 + i*4] = (char)(v + 1); g[10 + i*4] = (char)(v + 2); g[11 + i*4] = (char)255; }
        gColA = makeTex(g, false);
    }
    (void)colA; (void)hgtA; (void)colB; (void)hgtB;
    gVergeTex = makeTex(verge, false);
    gNoiseTex = makeTexRaw(RoadCull::whiteNoise(256), 256, 256, 4.f);                    // baked once: replaces ~100 per-pixel sin() hashes in the tarmac shader
    gFbmTex   = makeTexRaw(RoadCull::tileFbm(256), 256, 256, 2.f);
    gAspTex = 0; gAspLv = -1;                                                              // (re)built on the first draw for the current graphics level
    gRoad = upload(Road::gNet.road); gVerge = upload(Road::gNet.verge);                    // bridge decks / sand shoulders of the whole web
    gEdges.clear(); for (const Road::Mesh& m : Road::gNet.roadM) gEdges.push_back(upload(m));
    gTrk = upload(Road::gNet.trk); gTrkV = upload(Road::gNet.trkV);                       // hill road (same asphalt material as the other roads)
}

// texture sharpness at grazing angles follows the graphics level: Low 2x, Normal 4x, High 8x anisotropy (set again only when the level changes)
static void applyAniso(int lv){
    if (lv == gAnisoLv) return; gAnisoLv = lv;
    const char* ext = (const char*)glGetString(GL_EXTENSIONS);
    if (!ext || !strstr(ext, "GL_EXT_texture_filter_anisotropic")) return;
    GLfloat mx = 1; glGetFloatv(0x84FF, &mx); const float want = lv == 0 ? 2.f : (lv == 1 ? 4.f : 8.f); const float a = mx < want ? mx : want;
    const GLuint ts[3] = {gNoiseTex, gFbmTex, gVergeTex};
    for (GLuint t : ts) if (t){ glBindTexture(GL_TEXTURE_2D, t); glTexParameterf(GL_TEXTURE_2D, 0x84FE, t == gFbmTex ? (a < 2.f ? a : 2.f) : a); }
}

// baked asphalt texture: size follows Settings > Graphics (Low 512 / Normal 1024 / High 2048), rebuilt only when the level changes. Trilinear + anisotropy 4/8/16.
static void ensureAsphalt(int lv){
    if (lv == gAspLv && gAspTex) return; gAspLv = lv;
    if (gAspTex){ glDeleteTextures(1, &gAspTex); gAspTex = 0; }
    const int S = AsphaltTex::sizeFor(lv); std::vector<uint8_t> px = AsphaltTex::build(S);
    glActiveTexture(GL_TEXTURE3); glGenTextures(1, &gAspTex); glBindTexture(GL_TEXTURE_2D, gAspTex); glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, S, S, 0, GL_RGBA, GL_UNSIGNED_BYTE, px.data()); glGenerateMipmap(GL_TEXTURE_2D);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    const char* ext = (const char*)glGetString(GL_EXTENSIONS);
    if (ext && strstr(ext, "GL_EXT_texture_filter_anisotropic")){ GLfloat mx = 1; glGetFloatv(0x84FF, &mx); const float want = lv == 0 ? 4.f : (lv == 1 ? 8.f : 16.f); glTexParameterf(GL_TEXTURE_2D, 0x84FE, mx < want ? mx : want); }
    glActiveTexture(GL_TEXTURE0);
}

static void draw(const float* VP, const float* eye){
    const int lv = Quality::level < 0 ? 0 : (Quality::level > 2 ? 2 : Quality::level); applyAniso(lv); ensureAsphalt(lv);
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glEnable(GL_POLYGON_OFFSET_FILL);
    RoadCull::planes(VP, gPlanes);
    glActiveTexture(GL_TEXTURE1); glBindTexture(GL_TEXTURE_2D, gNoiseTex); glActiveTexture(GL_TEXTURE2); glBindTexture(GL_TEXTURE_2D, gFbmTex); glActiveTexture(GL_TEXTURE3); glBindTexture(GL_TEXTURE_2D, gAspTex); glActiveTexture(GL_TEXTURE0);
    // --- asphalt road (procedural tarmac + white edge lines + double yellow centre line) ---
    glUseProgram(gProgRoad); glUniformMatrix4fv(uR_VP, 1, GL_FALSE, VP); glUniform3fv(uR_Cam, 1, eye); glUniform1i(uR_Noise, 1); glUniform1i(uR_Fbm, 2); glUniform1i(uR_Asp, 3);
    glUniform1f(uR_Wet, lv == 0 ? 0.f : Weather::wet); glUniform1f(uR_Rip, Weather::rain); glUniform1f(uR_SunK, Weather::sun); glUniform1f(uR_Clk, Weather::clock);
    glUniform3f(uR_Ref, 1.f + 0.35f * Weather::sun, 1.f - 0.12f * Weather::sun, 1.f - 0.45f * Weather::sun); glUniform3fv(uR_SunD, 1, Weather::sunDir);
    glUniform3f(uR_Pk, Road::gPark[0], Road::gPark[1], Road::gPark[2]);
    glUniform1f(uR_EndR, 0.f); glUniform1f(uR_EndL, 0.f); glUniform1f(uR_Lite, (float)lv);
    glUniform1i(uR_PzN, 0);                                                               // bridge decks / hill road: no puddles
    { float rp[WaterFx::MAXR * 4]; for (int i = 0; i < WaterFx::N; i++){ const WaterFx::Rip& q = WaterFx::R[i]; rp[i*4] = q.x; rp[i*4+1] = q.z; rp[i*4+2] = q.age; rp[i*4+3] = q.amp; }
      glUniform1i(uR_RpN, WaterFx::N); if (WaterFx::N) glUniform4fv(uR_Rp, WaterFx::N, rp); }
    glPolygonOffset(-4.f, -9.f); drawMesh(gRoad);
    glPolygonOffset(-4.f, -9.f); drawMesh(gTrk);                                          // hill road (HTML renderOrder 0)
    glPolygonOffset(-9.f, -21.f);                                                         // every road of the web: paint stops 9 m before each end (= the junction mouths)
    for (size_t e = 0; e < gEdges.size() && e < Road::gNet.roads.size(); e++){
        glUniform1f(uR_EndL, (float)Road::gNet.roads[e].length()); glUniform1f(uR_EndR, 9.f);
        int nz = 0; float pz[Road::MAXZ * 4];                                             // this road's puddle dips (start, end, seed, depth)
        if (e < Road::gEdgeZ.size()) for (int zi : Road::gEdgeZ[e]){ if (nz >= Road::MAXZ) break; const Road::Zone& z = Road::gZones[zi]; pz[nz*4] = (float)z.s0; pz[nz*4+1] = (float)z.s1; pz[nz*4+2] = z.seed; pz[nz*4+3] = z.depth; nz++; }
        if (lv == 0) nz = 0; glUniform1i(uR_PzN, nz); if (nz) glUniform4fv(uR_Pz, nz, pz);
        drawMesh(gEdges[e]); }
    glUniform1i(uR_PzN, 0);
    // --- sand verge (alpha blended, no depth write) ---
    glUseProgram(gProgVerge); glUniformMatrix4fv(uV_VP, 1, GL_FALSE, VP); glUniform3fv(uV_Cam, 1, eye); glUniform1f(uV_Wet, lv == 0 ? 0.f : Weather::wet); glUniform1f(uV_Q, (float)lv);
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, gVergeTex); glUniform1i(uV_Tex, 0); glUniform1i(uV_Noise, 1);
    glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); glDepthMask(GL_FALSE);
    glPolygonOffset(-10.f, -27.f); drawMesh(gVerge);
    glPolygonOffset(-6.f, -15.f); drawMesh(gTrkV);                                         // dirt track verges (renderOrder 1)
    glDepthMask(GL_TRUE); glDisable(GL_BLEND); glDisable(GL_POLYGON_OFFSET_FILL);
    glActiveTexture(GL_TEXTURE0);
}

} // namespace RoadGL
