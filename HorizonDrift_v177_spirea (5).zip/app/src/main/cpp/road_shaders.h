// Sunny Drift - GLSL ES 3.00 shaders for the asphalt road (procedural tarmac + lane paint) and its gravel shoulder.
// Port of the HTML roadMat.onBeforeCompile (world-space "no puddle" mask, colour grading, wet roughness, bump map)
// and of the sand-verge material. Lighting uses the same sun / ambient / fog as the rest of this project.
#pragma once
#include "env_glsl.h"

#define LEAF_FN R"GLSL(
// one layer of fallen leaves: one random leaf per cell of size cs (pointed, slightly curled, random rotation / size / colour). Returns coverage, fills col (wet, saturated).
// tone = low-frequency value 0..1 (same tree -> same colour in a patch). Only texelFetch inside: safe in any branch.
float leafLayer(vec2 pos, float cs, vec2 seed, float dens, float dist, float tone, float scl, out vec3 col){
  col = vec3(0.0);
  vec2 gq = pos / cs; vec2 gid = floor(gq), fr = (fract(gq) - 0.5) * cs;
  vec4 hq  = texelFetch(uNoise, ivec2(mod(gid + seed, 256.0)), 0);
  if (hq.a > dens) return 0.0;
  vec4 hq2 = texelFetch(uNoise, ivec2(mod(gid + seed + vec2(113.0, 59.0), 256.0)), 0);
  vec2 dv = fr - (hq.rg - 0.5) * cs * 0.34; float an = hq2.r * 6.2831853; float ca = cos(an), sa = sin(an);
  vec2 lp = vec2(ca * dv.x + sa * dv.y, -sa * dv.x + ca * dv.y);
  float len = (0.085 + 0.085 * hq2.g) * scl, wid = len * (0.42 + 0.22 * hq2.b);
  float t = lp.x / len;
  lp.y -= (hq.b - 0.5) * 0.6 * t * t * len;                                             // curl: the leaf is not a flat ellipse
  float prof = wid * pow(max(1.0 - t * t, 0.0), 0.65) * (1.0 - 0.28 * t);              // pointed tip, rounder base
  float aa = 0.010 + dist * 0.0011;
  float a = clamp((prof - abs(lp.y)) / aa + 0.5, 0.0, 1.0) * step(abs(t), 1.0);
  if (a <= 0.0) return 0.0;
  float k = fract(tone * 1.7 + (hq2.a - 0.5) * 0.30);
  vec3 c = k < 0.25 ? vec3(0.46, 0.11, 0.045) : (k < 0.50 ? vec3(0.66, 0.28, 0.05) : (k < 0.75 ? vec3(0.66, 0.48, 0.09) : vec3(0.30, 0.17, 0.08)));
  c = mix(c, vec3(0.36, 0.38, 0.09), step(0.93, hq.b) * 0.8);                           // the odd green leaf
  float inner = clamp((prof - abs(lp.y)) / max(wid, 1e-3), 0.0, 1.0);
  c *= mix(0.55, 1.05, smoothstep(0.0, 0.55, inner));                                  // dark wet rim, lighter body
  c = mix(c, c * 1.5 + 0.04, smoothstep(0.045, 0.0, abs(lp.y)) * step(-0.9, t) * 0.55); // pale midrib
  c *= 0.80 + 0.4 * hq.b;
  col = c * 0.72; return a;
}
)GLSL"

static const char* ROAD_VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in vec2 uv; layout(location=2) in vec3 n; layout(location=3) in vec2 aux;
uniform mat4 uVP;
out vec2 vUv; out vec3 vN; out vec3 wp; out vec2 vAux;
void main(){ vUv = uv; vN = n; wp = p; vAux = aux; gl_Position = uVP * vec4(p, 1.0); }
)GLSL";

static const char* ROAD_FS = R"GLSL(#version 300 es
precision highp float;
in vec2 vUv; in vec3 vN; in vec3 wp; in vec2 vAux;   // vUv.x = metres from the centre line, vUv.y = road half width, vAux.x = metres along the road, vAux.y = bend curvature (1 / radius)
uniform vec3 uCam;
uniform float uEndR, uEndL;   // connector road: no lane paint within uEndR metres (along the road) of either end = the junction mouths; uEndL = its length (uEndR = 0 elsewhere)
uniform sampler2D uNoise;   // 256x256 RGBA white noise (1 texel = 1 stone chip at scale 1), mipmapped -> detail fades by itself, no shimmer
uniform sampler2D uAsp;     // baked tileable asphalt (4 m tile): R grain, G hairline cracks, BA bump gradient
uniform sampler2D uFbm;     // 256x256 RGBA tileable fbm (4 independent channels), smooth large-scale variation
uniform vec3 uPk;   // summit parking ring: centre x, z, radius (0 = none)
uniform float uLite;   // graphics level 0 / 1 / 2 (Low / Normal / High): scales how far the tarmac detail reaches and switches off the costliest fine details on Low
uniform vec4 uPz[16]; uniform int uPzN;   // puddle dips of this road: x / y = start / end (metres along), z = seed, w = depth (m)
uniform vec4 uRp[24]; uniform int uRpN;   // rings the wheels left on the water: x, z, age (s), strength
uniform float uWet, uRip, uSunK, uClk; uniform vec3 uRef, uSunD;   // weather: wetness, rain ripples, golden light, clock, reflection tint, direction to the sun
out vec4 o;

// value-noise lookups: 1 texture fetch each. They use textureGrad with the screen derivatives of the world position taken once at the top, so they may sit inside
// the distance branches below (far pixels skip most of them) without breaking the derivative rules.
vec2 gX, gY;
vec4 aTg(vec2 p, float sc){ return textureGrad(uNoise, p * (1.0 / 256.0), gX * (sc / 256.0), gY * (sc / 256.0)); }
vec4 aFg(vec2 p, float sc){ return textureGrad(uFbm, p, gX * sc, gY * sc); }
)GLSL" ENV_GLSL LEAF_FN R"GLSL(
// anti-aliased painted stripe: coverage of a line of half width hwl centred on c (metres across the road)
float stripe(float x, float c, float hwl, float aa){ return clamp((hwl - abs(x - c)) / aa + 0.5, 0.0, 1.0); }

void main(){
  vec2 rw = wp.xz; gX = dFdx(rw); gY = dFdy(rw);
  vec3 toCam = uCam - wp;
  float dist = length(toCam);
  float u = vUv.x, hw = vUv.y;
  float sEnd = uEndR > 0.0 ? min(vAux.x, uEndL - vAux.x) : 1e4;                       // connector: metres to the nearest junction
  float jn = smoothstep(6.0, 8.0, sEnd);                                              // 0 on the ring road itself (the connector only overlays it there), 1 outside the junction
  float edgeD = mix(6.0, hw - abs(u), jn);                                            // metres to the nearest road edge (no edge wear on the part that lies on the ring road)
  float aa = max(fwidth(u) * 1.0, 0.0007), aaS = max(fwidth(vAux.x) * 1.0, 0.0007);
  float sc = uLite < 0.5 ? 0.45 : (uLite > 1.5 ? 1.25 : 1.0);                         // detail distance scale: Low 0.45, Normal 1.0 (the original look), High 1.25
  bool hiDet = uLite > 0.5;                                                           // Low skips the finest chips / tar snakes / weeds (only visible within a few metres anyway)
  float w3 = 1.0 - smoothstep(2.5 * sc, 11.0 * sc, dist), w2 = 1.0 - smoothstep(6.0 * sc, 28.0 * sc, dist);   // fine chip detail fades sooner: it only shimmers once it gets close to the pixel size
  bool nearPix = dist < 38.0 * sc;
  bool farPix = dist > 230.0 * sc;                                                    // very far: the big soft patches are sub-pixel, skip their fetches
                                                          // detail tier: everything below fades to nothing by 90 m, so the switch is invisible

  // ---- asphalt: stone chips (3 scales from the baked noise), large patches, repair tone ----
  // two taps of the baked asphalt (second one rotated + other scale = no visible tiling); trilinear + aniso, mips fade the detail to neutral by themselves
  const float TS = 0.25;                                                              // 1 / tile size in metres
  const mat2 RM = mat2(0.8, -0.6, 0.6, 0.8);
  vec4 aA = textureGrad(uAsp, rw * TS, gX * TS, gY * TS);
  vec4 aB = vec4(0.5, 0.0, 0.5, 0.5);
  if (hiDet) aB = textureGrad(uAsp, RM * rw * (TS * 0.37) + 0.37, RM * gX * (TS * 0.37), RM * gY * (TS * 0.37));
  float g1 = aA.r, g2 = aB.r, g3 = aB.r;
  float grain = hiDet ? 0.5 + (aA.r - 0.5) * 0.75 + (aB.r - 0.5) * 0.55 : 0.5 + (aA.r - 0.5) * 1.0;
  vec2 bumpG = (aA.ba - 0.5) + (hiDet ? transpose(RM) * (aB.ba - 0.5) * 0.7 : vec2(0.0));
  float crackT = max(aA.g, aB.g);                                                      // baked hairline cracks
  vec4 f1 = aFg(rw / 56.0, 1.0 / 56.0), f2 = vec4(0.5), f3 = vec4(0.5);
  if (!farPix){ f2 = aFg(rw / 360.0 + 0.31, 1.0 / 360.0); f3 = aFg(rw / 152.0 + 0.57, 1.0 / 152.0); }
  float pat = f1.r, big = f2.g;
  float repair = smoothstep(0.58, 0.64, f3.b);                                        // a few darker, fresher patches
  vec3 alb = L2(vec3(0.33, 0.34, 0.36));                                             // light alpine-pass grey
  alb *= (0.88 + 0.24 * grain) * (0.95 + 0.10 * pat) * (0.97 + 0.06 * big);   // smoother, freshly laid surface
  alb *= mix(1.0, 0.92, repair);

  // ---- wear: polished wheel paths, dust on the edges, weeds in the edge cracks, hairline + sealed cracks ----
  float lane = abs(abs(u) - hw * 0.5);                                                // distance from a lane centre
  float wheel = exp(-pow((lane - 0.85) / 0.42, 2.0)) * (0.55 + 0.45 * f1.g) * jn;
  float wheel2 = exp(-pow(lane / 0.30, 2.0)) * 0.5 * f2.b * jn;                            // oil drip between the wheels
  alb *= 1.0 - 0.15 * wheel - 0.06 * wheel2;                                         // darker, polished tyre tracks in both lanes
  float dustN = 0.5; if (!farPix) dustN = aTg(rw * 1.7, 1.7).a;
  float dust = (1.0 - smoothstep(0.0, 1.6, edgeD)) * (0.35 + 0.65 * dustN);
  alb = mix(alb, L2(vec3(0.50, 0.49, 0.46)), 0.12 * dust);                          // sand / earth washed onto the tarmac
  alb = mix(alb, L2(vec3(0.34, 0.31, 0.27)), (1.0 - smoothstep(0.0, 0.25, edgeD)) * 0.18);   // faint rim
  float crack = 0.0, seal = 0.0;
  if (nearPix){
    vec4 f4 = aFg(rw / 224.0 + 0.83, 1.0 / 224.0);
    vec2 wq = rw * 0.1 + 0.6 * (aTg(rw * 2.3 + 5.0, 2.3).rg - 0.5);
    crack = (1.0 - smoothstep(0.0, 0.040, abs(aFg(wq, 0.1).a - 0.5))) * smoothstep(0.52, 0.72, f4.r) * (1.0 - smoothstep(6.0 * sc, 22.0 * sc, dist));
    // sealed cracks ("tar snakes"): long, thin, slightly glossy black lines the road crews pour over old cracks
    vec2 sq = rw * 0.06 + 0.9 * (aTg(rw * 0.7 + 9.0, 0.7).rg - 0.5);
    if (hiDet) seal = (1.0 - smoothstep(0.0, 0.016, abs(aFg(sq, 0.06).b - 0.5))) * smoothstep(0.50, 0.66, f3.r) * (1.0 - smoothstep(7.0 * sc, 26.0 * sc, dist));
    // weeds / moss creeping in from the verge where the edge has broken up (only in some stretches)
    float weed = !hiDet ? 0.0 : (1.0 - smoothstep(0.04, 0.12 + 0.55 * aTg(rw * 3.1 + 7.7, 3.1).b, edgeD)) * smoothstep(0.56, 0.70, f2.r) * (1.0 - smoothstep(15.0 * sc, 55.0 * sc, dist));
    alb = mix(alb, L2(vec3(0.20, 0.25, 0.10)) * (0.8 + 0.4 * g3), 0.10 * weed);
  }
  alb *= 1.0 - 0.15 * crack;
  alb *= 1.0 - 0.45 * crackT * (1.0 - smoothstep(10.0 * sc, 45.0 * sc, dist));
  alb *= 1.0 - 0.20 * seal;

  // ---- lane paint: white edge lines + yellow centre line. Dashed (passing allowed) on straight stretches, solid double in bends / no-passing zones ----
  float zone = floor(vAux.x / 140.0), zh = fract(sin(zone * 12.9898 + 4.1) * 43758.5453);
  float passOK = step(0.38, zh) * (1.0 - smoothstep(1.0 / 320.0, 1.0 / 200.0, vAux.y));
  float dashCov = stripe(mod(vAux.x + 2.0, 12.0), 6.0, 2.0, aaS);                     // 4 m of paint, 8 m gap (like the alpine road)
  float cl = max(stripe(u, 0.0, 0.07, aa), 0.0);
  float yel = cl * mix(1.0, dashCov, max(passOK, 1.0 - smoothstep(1.0 / 320.0, 1.0 / 200.0, vAux.y)));   // single centre line: dashed on straights, solid in tight bends
  float whi = max(stripe(u, hw - 0.35, 0.09, aa), stripe(u, -(hw - 0.35), 0.09, aa));
  if (hw > 6.0){   // 4-lane highway: solid double yellow median, dashed white lane lines at the middle of each carriageway
    float lnD = stripe(mod(vAux.x + 2.0, 12.0), 6.0, 2.0, aaS);
    yel = max(stripe(u, -0.18, 0.07, aa), stripe(u, 0.18, 0.07, aa));
    whi = max(whi, max(stripe(u, hw * 0.5, 0.08, aa), stripe(u, -hw * 0.5, 0.08, aa)) * lnD);
  }
  float mask = uEndR > 0.0 ? smoothstep(uEndR, uEndR + 1.5, sEnd) : 1.0;     // measured along the road, so the flared fillets are covered too
  float wornN = 0.5; if (!farPix) wornN = aFg(rw / 20.8 + 0.4, 1.0 / 20.8).g;
  float worn = 1.0 - 0.12 * smoothstep(0.50, 0.78, wornN) - 0.05 * wheel;     // paint scuffed off, chips showing through
  float chip = 0.80 + 0.20 * smoothstep(0.25, 0.60, mix(0.5, grain, w2));
  float py = yel * mask * worn * chip, pw = whi * mask * worn * chip;
  alb = mix(alb, L2(vec3(0.90, 0.91, 0.90)) * (0.92 + 0.08 * pat), py);             // white centre line
  alb = mix(alb, L2(vec3(0.92, 0.93, 0.92)) * (0.92 + 0.08 * pat), pw);             // traffic white
  float pk = 0.0;                                                                     // PARKING_AREA: painted bays along the outer side of the summit ring
  if (uPk.z > 0.0){
    vec2 q = wp.xz - uPk.xy; float d = length(q), nb = floor(6.2831853 * uPk.z / 3.2), cell = abs(fract(atan(q.y, q.x) / 6.2831853 * nb + 0.5) - 0.5) * 6.2831853 * d / nb;
    float aaP = max(fwidth(d), 0.02), inB = step(uPk.z + 1.0, d) * step(d, uPk.z + 6.6);
    pk = max(inB * (1.0 - smoothstep(0.05, 0.05 + aaP, cell)), (1.0 - smoothstep(0.06, 0.06 + aaP, abs(d - (uPk.z + 1.0)))) * step(d, uPk.z + 6.8));
  }
  alb = mix(alb, L2(vec3(0.92, 0.93, 0.92)), pk * 0.95);
  float paint = max(max(py, pw), pk);
  float rough = clamp(0.90 - 0.12 * wheel - 0.10 * paint - 0.25 * seal, 0.5, 1.0);

  // ---- standing water in the dips of the country roads (same bell + wobble as Road::zoneWater in road.h) ----
  float wat = 0.0, damp = 0.0;
  for (int zi = 0; zi < 16; zi++){
    if (zi >= uPzN) break;
    vec4 pz = uPz[zi]; float tz = (vAux.x - pz.x) / (pz.y - pz.x);
    if (tz > 0.0 && tz < 1.0){
      float b = 0.5 - 0.5 * cos(6.2831853 * tz);
      float wob = sin(0.55 * vAux.x + 6.1 * pz.z + 2.3 * u) * sin(0.31 * vAux.x - 3.7 * pz.z + 1.7 * u);
      float q = b * (1.0 - 0.30 * abs(u) / hw) + 0.09 * wob;
      wat = max(wat, smoothstep(0.16, 0.26, q)); damp = max(damp, smoothstep(0.02, 0.20, q));
    }
  }
  // ---- wet road (weather): darker asphalt, glossy sheen, standing puddles in the wheel ruts ----
  float lw = max(uWet, damp * 0.85);                                                  // the tarmac round a puddle is damp too
  float pud = 0.0;
  if (uWet > 0.001){
    float pn = aFg(rw / 31.0 + 0.19, 1.0 / 31.0).r * 0.65 + aFg(rw / 9.0 + 0.71, 1.0 / 9.0).g * 0.35;
    pud = smoothstep(0.54 - 0.07 * wheel, 0.61 - 0.07 * wheel, pn) * uWet * (1.0 - smoothstep(0.0, 0.5, edgeD) * 0.8) * (1.0 - smoothstep(60.0, 220.0, dist) * 0.6);
  }
  pud = max(pud, wat);
  // ---- fallen leaves after the rain: two layers of leaves (big + small), clustered under "trees", thicker at the edges, swept out of the wheel ruts, stuck flat to the wet tarmac ----
  float leafA = 0.0; vec3 leafC = vec3(0.0); float stain = 0.0;
  {
    float clus = aFg(rw / 23.0 + 0.41, 1.0 / 23.0).r, tone = aFg(rw / 61.0 + 0.13, 1.0 / 61.0).g;
    float cl = smoothstep(0.42, 0.72, clus);
    float dens = (0.05 + 0.50 * cl) * (0.45 + 1.3 * (1.0 - smoothstep(0.0, 2.2, edgeD))) * (1.0 - 0.85 * wheel) * uWet / 0.6;
    stain = cl * 0.5 * (1.0 - smoothstep(40.0, 90.0, dist)) * min(uWet * 10.0, 1.0);                          // tannin-dark water stain under the leaf litter
    if (dist < 95.0){
      vec3 c1 = vec3(0.0), c2 = vec3(0.0); float a1 = leafLayer(rw, 0.85, vec2(37.0, 91.0), dens, dist, tone, 1.0, c1);
      float a2 = 0.0; if (dist < 45.0) a2 = leafLayer(rw + 0.31, 0.5, vec2(151.0, 17.0), dens * 0.8, dist, tone, 0.62, c2);
      float fade = 1.0 - smoothstep(60.0, 95.0, dist);
      a1 *= fade; a2 *= fade;
      leafC = c1; leafA = a1; if (a2 > 0.0){ leafC = mix(leafC, c2, a2); leafA = max(a1, a2); }
    } else leafC = vec3(0.0);
    float farTint = smoothstep(55.0, 100.0, dist) * dens * 0.30;                      // far away: just a brown tint, no popping
    alb = mix(alb, vec3(0.20, 0.10, 0.04), farTint);
  }
  if (lw > 0.001){
    alb *= mix(1.0, 0.58, lw);
    alb *= mix(1.0, 0.62, pud);
    alb *= 1.0 - 0.22 * stain;
    rough = mix(rough, 0.16, lw * 0.85);
    rough = mix(rough, 0.03, pud);
  }
  if (leafA > 0.0){ alb = mix(alb, leafC, leafA); rough = mix(rough, 0.28, leafA); pud *= (1.0 - 0.55 * leafA); }   // leaves cover the sheen and the puddle surface

  // ---- micro relief -> bump. Derivatives are taken unconditionally (H is 0 beyond 90 m anyway, no extra fetches there) ----
  // ---- micro relief: baked, filtered gradient (smooth, no screen-space derivatives -> no 2x2 pixel blocks) ----
  vec3 N0 = normalize(vN);
  float bFade = 1.0 - smoothstep(3.0 * sc, 22.0 * sc, dist);
  vec3 N = normalize(N0 - vec3(bumpG.x, 0.0, bumpG.y) * 0.9 * bFade);
  if (pud > 0.001){
    N = normalize(mix(N, N0, clamp(pud * 1.2, 0.0, 1.0)));                            // standing water is flat
    if (uRip > 0.001 && dist < 60.0){                                                 // rain: expanding rings on the puddles
      vec2 gq = rw * 1.7; vec2 gid = floor(gq), fr = fract(gq) - 0.5;
      vec4 hq = texelFetch(uNoise, ivec2(mod(gid, 256.0)), 0);
      vec2 cc = (hq.rg - 0.5) * 0.6; float ph = fract(uClk * (0.8 + 0.5 * hq.b) + hq.a);
      vec2 dv = fr - cc; float rr = length(dv), q = rr - ph * 0.45;
      float qq = q * 14.0; float ring = exp(-qq * qq) * (1.0 - ph) * step(0.45, hq.b);
      vec2 dir = dv / max(rr, 1e-3);
      N = normalize(N + vec3(dir.x, 0.0, dir.y) * ring * 0.55 * uRip * pud * (1.0 - smoothstep(25.0, 60.0, dist)));
    }
    if (dist < 60.0){
      vec2 wv = aFg(rw / 2.6 + uClk * 0.012, 1.0 / 2.6).rg - 0.5;                       // a faint breeze on the surface
      vec2 gr = wv * 0.10;
      for (int i = 0; i < 24; i++){                                                     // the Forza Horizon wake: rings spreading from every tyre that rolled through the puddle
        if (i >= uRpN) break;
        vec4 rp = uRp[i]; vec2 dv = rw - rp.xy; float dd = length(dv);
        float rr0 = 0.25 + rp.z * 2.6, fade = rp.w * exp(-rp.z * 1.7);
        float k1 = (dd - rr0) * 6.0, k2 = (dd - rr0 * 0.6) * 8.0;
        float wave = exp(-k1 * k1) * sin((dd - rr0) * 22.0) + 0.5 * exp(-k2 * k2) * sin((dd - rr0 * 0.6) * 26.0);
        gr += dv / max(dd, 0.02) * wave * fade;
      }
      N = normalize(N + vec3(gr.x, 0.0, gr.y) * 0.55 * pud * (1.0 - smoothstep(30.0, 60.0, dist)));
    }
  }

  vec3 L = SUNL, V = toCam / dist, Hh = normalize(L + V);
  float d = max(dot(N, L), 0.0), smo = 1.0 - rough;
  float NoV = max(dot(N, V), 1e-3);
  float spec = pow(max(dot(N, Hh), 0.0), mix(6.0, 120.0, smo * smo * 4.0)) * (0.02 + 0.5 * smo * smo * smo);   // dry tarmac: faint sheen
  // sky reflection: full analytic env only close to the car; far away a cheap fresnel-weighted sky tint
  vec3 refl;
  vec3 Rf = reflect(-V, N);
  if (dist < 70.0 * sc && (hiDet || dist < 25.0)){ vec2 ab = envBRDF(rough, NoV); refl = envC(Rf, rough) * (0.04 * ab.x + ab.y); }
  else { float fr = 0.04 + 0.96 * pow(1.0 - NoV, 5.0); refl = L2(vec3(0.62, 0.78, 0.95)) * fr * (1.0 - rough * 0.5); }
  // grazing-angle sheen: real tarmac turns glossy towards the horizon
  float graze = pow(1.0 - NoV, 4.0) * 0.12;
  float rl = dot(refl, vec3(0.299, 0.587, 0.114));
  refl = mix(refl, vec3(rl) * 0.85, uRip * 0.7) * uRef;                                // grey rainy sky / golden sky in the reflection
  float rScale = 0.32 + lw * 0.30 + pud * 0.95;
  vec3 glint = mix(vec3(1.0, 0.97, 0.92), vec3(1.0, 0.62, 0.28), uSunK) * pow(max(dot(Rf, uSunD), 0.0), mix(60.0, 600.0, 1.0 - rough)) * mix(0.55, 1.0, uSunK) * lw * (1.2 + 2.5 * pud);   // sun glittering on the wet tarmac / the puddle (white at noon, orange when low)   // low sun glittering on the wet tarmac
  vec3 lin = alb * (0.35 + 0.75 * d) + vec3(spec) + refl * rScale + glint + L2(vec3(0.7, 0.8, 0.95)) * graze * (1.0 - smoothstep(60.0, 400.0, dist)) * 0.5;
  vec3 c = pow(lin, vec3(1.0 / 2.2));
  c = mix(c, vec3(0.62, 0.80, 0.95), clamp(dist / 3750.0, 0.0, 1.0));
  o = vec4(c, 1.0);
}
)GLSL";

static const char* VERGE_FS = R"GLSL(#version 300 es
precision highp float;
in vec2 vUv; in vec3 vN; in vec3 wp;
uniform sampler2D uTex; uniform sampler2D uNoise; uniform vec3 uCam; uniform float uWet; uniform float uQ;   // uQ = graphics level 0 / 1 / 2
out vec4 o;
)GLSL" LEAF_FN R"GLSL(
void main(){
  vec4 tx = texture(uTex, vUv);
  float dist = length(uCam - wp);
  vec3 soil = pow(tx.rgb, vec3(2.2));
  // asphalt shoulder: grey-tan gravel and dust (noise from the baked texture: 3 fetches instead of 12 sin-hashes)
  vec3 nz = vec3(0.5);
  float nzD = uQ < 0.5 ? 90.0 : (uQ > 1.5 ? 180.0 : 140.0);
  if (dist < nzD) nz = vec3(texture(uNoise, wp.xz * (5.0 / 256.0)).r, texture(uNoise, wp.xz * (31.0 / 256.0)).g, texture(uNoise, wp.xz * (1.0 / 6.0 / 256.0)).b);   // far shoulder: flat average tone, no fetches
  float gr = 0.75 + 0.3 * nz.x + 0.2 * nz.y * (1.0 - smoothstep(10.0, 50.0, dist));
  // realistic roadside: u = vUv.x runs from the tarmac edge (0) out to the meadow (1)
  float e = vUv.x;
  float fine = (dist < nzD) ? nz.y : 0.5;
  vec3 gravel = pow(vec3(0.47, 0.45, 0.41), vec3(2.2)) * gr * (0.85 + 0.3 * nz.z);
  gravel *= 1.0 + 0.55 * step(0.84, fine) - 0.35 * step(fine, 0.14);                         // loose light stones + dark pits in the gravel
  vec3 dirt = mix(soil, pow(vec3(0.36, 0.28, 0.19), vec3(2.2)), 0.55) * (0.8 + 0.4 * nz.x);   // bare earth
  vec3 grassA = pow(vec3(0.20, 0.38, 0.10), vec3(2.2));                                      // lush, dark
  vec3 grassB = pow(vec3(0.42, 0.48, 0.17), vec3(2.2));                                      // sun-dried
  vec3 grass = mix(grassA, grassB, smoothstep(0.35, 0.8, nz.z)) * (0.62 + 0.75 * nz.x) * (0.8 + 0.4 * fine);   // clumps, blades, dry patches
  float rag = (nz.z - 0.5) * 0.26 + (nz.x - 0.5) * 0.12;                                      // ragged, irregular boundaries
  float gMask = 1.0 - smoothstep(0.26, 0.46, e + rag);                                        // gravel shoulder next to the tarmac
  float dMask = (1.0 - smoothstep(0.42, 0.78, e + rag * 1.6)) * 0.65;                         // bare earth patches fading into the grass
  vec3 alb = mix(grass, dirt, dMask);
  alb = mix(alb, gravel, gMask);
  alb *= mix(0.74, 1.0, smoothstep(0.08, 0.30, e));                                           // dust / oil darkening right at the edge of the asphalt
  alb *= mix(1.0, 0.62, uWet);                                                          // wet shoulder
  {   // fallen leaves on the shoulder: clustered, densest at the tarmac edge, two sizes
    float clus = texture(uNoise, wp.xz * (1.0 / 23.0 / 256.0)).r, tone = texture(uNoise, wp.xz * (1.0 / 61.0 / 256.0)).g;
    float cl = smoothstep(0.42, 0.72, clus);
    float dens = (0.10 + 0.55 * cl) * (1.0 - 0.55 * smoothstep(0.2, 0.9, e));
    if (dist < 80.0){
      vec3 c1 = vec3(0.0), c2 = vec3(0.0); float fade = 1.0 - smoothstep(50.0, 80.0, dist);
      float a1 = leafLayer(wp.xz, 0.8, vec2(71.0, 13.0), dens, dist, tone, 1.0, c1) * fade;
      float a2 = 0.0; if (dist < 40.0) a2 = leafLayer(wp.xz + 0.27, 0.5, vec2(190.0, 77.0), dens * 0.8, dist, tone, 0.62, c2) * fade;
      alb = mix(alb, c1, a1); alb = mix(alb, c2, a2);
    }
    alb = mix(alb, vec3(0.20, 0.10, 0.04), smoothstep(45.0, 90.0, dist) * dens * 0.22);
  }
  vec3 N = normalize(vN);
  float d = max(dot(N, SUNL), 0.0);
  vec3 c = pow(alb * (0.35 + 0.75 * d), vec3(1.0 / 2.2));
  c = mix(c, vec3(0.62, 0.80, 0.95), clamp(dist / 3750.0, 0.0, 1.0));
  o = vec4(c, tx.a);
}
)GLSL";
