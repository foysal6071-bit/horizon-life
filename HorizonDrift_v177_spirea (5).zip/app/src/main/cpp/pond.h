// Sunny Drift - shallow meadow ponds you can drive through (pure C++ planning + physics lookup; drawing is in pond_render.h).
//  Flat, low, open spots of the meadow, away from roads / river / lake / houses, get a shallow pond with a wobbly shoreline. waterAt() feeds the same
//  tyre spray + wake ripples + aquaplaning as the road puddles.
#pragma once
#include <algorithm>
#include <cmath>
#include <random>
#include <vector>
#include "village.h"

namespace Pond {

struct P { float x, z, y, r, seed; };                       // centre, water level, mean radius, shoreline seed
static std::vector<P> gP;

static inline float edgeAt(const P& p, float a){ return 1.f + 0.12f * std::sin(3.f * a + p.seed * 6.f) + 0.08f * std::sin(5.f * a + 2.1f * p.seed * 6.f + 1.3f); }   // MUST match pond_render.h
// 0..1 water depth factor under (x, z): 1 well inside, 0 outside, soft shore
static float waterAt(double x, double z){
    for (const P& p : gP){
        const double dx = x - p.x, dz = z - p.z; if (dx * dx + dz * dz > (p.r * 1.3) * (p.r * 1.3)) continue;
        const double d = std::sqrt(dx * dx + dz * dz) / p.r, e = edgeAt(p, (float)std::atan2(dz, dx));
        const double t = std::min(std::max((e - d) / 0.12, 0.0), 1.0); const double w = t * t * (3 - 2 * t); if (w > 0) return (float)w;
    }
    return 0.f;
}

static void plan(){
    gP.clear(); if (!Terrain::gReady) return;
    std::mt19937 rng(918273u); auto U = [&]{ return std::uniform_real_distribution<float>(0.f, 1.f)(rng); };
    struct Cand { P p; float score; }; std::vector<Cand> cs;
    for (int t = 0; t < 30000; t++){
        const float x = (U() * 2 - 1) * 1180.f, z = (U() * 2 - 1) * 840.f;
        const float cl = Road::clearance(x, z); if (cl < 16.f || cl > 260.f) continue;                   // reachable, and seen from the road
        if (std::fabs(River::riverSd(x, z)) < 90.0 || Terrain::trackDist(x, z) < 40.0 || Terrain::coastDist(x, z) > -170.0) continue;
        if (Terrain::gLake.on && Terrain::lakeDn(x, z) < 2.4) continue;
        if (Terrain::summitCleared(x, z, 40.0) || (Terrain::PEAK.on && std::hypot(x - Terrain::PEAK.x, z - Terrain::PEAK.z) < Terrain::PEAK.R * 1.25)) continue;
        bool near = false; for (const Village::Building& o : Village::gB){ const float dx = x - o.x, dz = z - o.z; if (dx*dx + dz*dz < 40.f * 40.f){ near = true; break; } } if (near) continue;
        const float r = 6.f + 8.f * U(); const float h0 = Village::groundAt(x, z); float lo = h0, hi = h0, sum = 0; int n = 0;
        for (int k = 0; k < 12; k++){ const float a = k * 0.5235988f, h = Village::groundAt(x + (r * 1.15f) * std::cos(a), z + (r * 1.15f) * std::sin(a)); lo = std::min(lo, h); hi = std::max(hi, h); sum += h; n++; }
        if (hi - lo > 0.55f || h0 > 8.f || h0 > sum / n + 0.04f) continue;                              // flat, low, in the valley floor, centre not higher than the rim
        if (Road::clearance(x, z) - r * 1.3f < 8.f) continue;
        P p{x, z, lo + 0.07f, r, U()}; cs.push_back({p, (sum / n - h0) + 0.4f * U() - (hi - lo)});
    }
    std::sort(cs.begin(), cs.end(), [](const Cand& a, const Cand& b){ return a.score > b.score; });
    for (const Cand& c : cs){
        if (gP.size() >= 18) break; bool ok = true;
        for (const P& o : gP){ const float dx = c.p.x - o.x, dz = c.p.z - o.z; if (dx*dx + dz*dz < 90.f * 90.f){ ok = false; break; } }
        if (ok) gP.push_back(c.p);
    }
}

}   // namespace Pond
