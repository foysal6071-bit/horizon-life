// Sunny Drift - draws the meadow ponds (see pond.h): one camera-facing-free quad per pond; v138 = depth / parallax / wet bank / lily-pad shading so they read as real 3D water.
#pragma once
#include <GLES3/gl3.h>
#include "road_render.h"
#include "pond.h"
#include "env_glsl.h"

namespace PondGL {
static const char* VS = R"GLSL(#version 300 es
uniform mat4 uVP; uniform vec4 uPond;   // x, y, z, radius
out vec2 vL; out vec3 wp;
void main(){ vec2 c = vec2(float(gl_VertexID & 1), float((gl_VertexID >> 1) & 1)) * 2.0 - 1.0; vL = c * 1.6; wp = vec3(uPond.x + c.x * uPond.w * 1.6, uPond.y, uPond.z + c.y * uPond.w * 1.6); gl_Position = uVP * vec4(wp, 1.0); }
)GLSL";
// v138: ponds no longer read as flat decals. Real depth (shore -> middle) with a refracted + parallax-shifted muddy/pebbly bottom and caustics, Beer-Lambert water colour,
//  noise-based wind waves (no sine grid), Fresnel sky + horizon-vegetation reflection, a lit/shaded wet mud bank (sun side vs shadow side), contact shadow + foam at the waterline,
//  lily pads on some ponds. The waterline stays inside the physics shoreline (edgeAt) so tyres splash where the water visibly is.
static const char* FS = R"GLSL(#version 300 es
precision highp float;
in vec2 vL; in vec3 wp; uniform vec3 uCam; uniform float uSeed, uClk, uSunK; uniform vec3 uSunD; uniform vec4 uRp[24]; uniform int uRpN; uniform vec4 uPond; out vec4 o;
)GLSL" ENV_GLSL R"GLSL(
float h21(vec2 p){ vec3 q = fract(vec3(p.xyx) * 0.1031); q += dot(q, q.yzx + 33.33); return fract((q.x + q.y) * q.z); }
vec3 vn(vec2 p){                                   // value noise: x = value, yz = d/dp
  vec2 i = floor(p), f = fract(p), u = f * f * (3.0 - 2.0 * f), du = 6.0 * f * (1.0 - f);
  float a = h21(i), b = h21(i + vec2(1.0, 0.0)), c = h21(i + vec2(0.0, 1.0)), d = h21(i + vec2(1.0, 1.0)), k = a - b - c + d;
  return vec3(a + (b - a) * u.x + (c - a) * u.y + k * u.x * u.y, du.x * ((b - a) + k * u.y), du.y * ((c - a) + k * u.x));
}
vec2 waves(vec2 p, float t, float lod){
  vec3 a = vn(p * 1.1 + vec2(t * 0.30, t * 0.18));
  vec3 b = vn(p * 1.9 - vec2(t * 0.22, -t * 0.27) + 17.0);
  vec3 c = vn(p * 4.3 + vec2(-t * 0.50, t * 0.40) + 41.0);
  vec3 d = vn(p * 9.7 + vec2(t * 0.70, t * 0.60) + 73.0);
  return a.yz * (1.1 * 0.016) + b.yz * (1.9 * 0.012) + (c.yz * (4.3 * 0.0045) + d.yz * (9.7 * 0.0022)) * lod;
}
vec3 bottomCol(vec2 q, float shal){
  float n1 = vn(q * 0.9).x, n2 = vn(q * 3.1).x, n3 = vn(q * 11.0).x;
  vec3 m = mix(L2(vec3(0.20, 0.16, 0.10)), L2(vec3(0.36, 0.30, 0.19)), n1 * 0.6 + n2 * 0.4);
  m = mix(m, L2(vec3(0.50, 0.47, 0.41)) * (0.7 + 0.5 * n2), smoothstep(0.64, 0.82, n3) * shal * 0.65);          // pebbles in the shallows
  return mix(m, L2(vec3(0.09, 0.18, 0.07)), smoothstep(0.55, 0.80, vn(q * 0.45 + 7.0).x) * 0.55);              // weed / algae patches
}
float caustic(vec2 q, float t){
  float w = abs(vn(q * 2.0 + vec2(t * 0.30, -t * 0.20) + 3.0 * vn(q * 1.1 - t * 0.15).x).x * 2.0 - 1.0);
  return pow(1.0 - w, 7.0);
}
vec4 lily(vec2 p, float seed){                      // one pad per 2.4 m cell (rgb, mask)
  vec2 cell = floor(p / 2.4), f = p / 2.4 - cell;
  if (h21(cell + seed * 37.0) < 0.45) return vec4(0.0);
  vec2 c = vec2(0.25 + 0.5 * h21(cell + 11.3), 0.25 + 0.5 * h21(cell + 5.7));
  vec2 dv = (f - c) * 2.4; float rad = 0.30 + 0.22 * h21(cell + 2.9), dd = length(dv);
  float an = atan(dv.y, dv.x) - h21(cell + 8.1) * 6.2832; an = atan(sin(an), cos(an));
  float m = (1.0 - smoothstep(rad - 0.03, rad, dd)) * smoothstep(0.14, 0.21, abs(an));
  vec3 col = mix(L2(vec3(0.10, 0.27, 0.08)), L2(vec3(0.24, 0.42, 0.12)), clamp(h21(cell + 1.3) * 0.8 + (1.0 - dd / rad) * 0.35, 0.0, 1.0));
  col *= 0.85 + 0.15 * sin(an * 11.0);                                                     // veins
  col *= 0.55 + 0.45 * smoothstep(rad * 0.98, rad * 0.78, dd);                             // darker rim
  return vec4(col, m);
}
void main(){
  float d = length(vL), a = atan(vL.y, vL.x);
  float e = 1.0 + 0.12 * sin(3.0 * a + uSeed * 6.0) + 0.08 * sin(5.0 * a + 2.1 * uSeed * 6.0 + 1.3);
  vec2 rw = wp.xz;
  float sdW = (d - (e - 0.06)) * uPond.w + (vn(rw * 0.8 + uSeed * 50.0).x - 0.5) * 0.4;       // metres from the visible waterline, <0 = in the water (inside the physics shore)
  if (sdW > 1.5) discard;
  vec3 toCam = uCam - wp; float dist = length(toCam); vec3 V = toCam / dist;
  float aa = max(fwidth(sdW), 1e-3), wm = 1.0 - smoothstep(-aa, aa, sdW);
  float lod = 1.0 - smoothstep(25.0, 130.0, dist), sunUp = max(uSunD.y, 0.0);
  vec3 sunC = mix(vec3(1.0, 0.97, 0.90), vec3(1.0, 0.62, 0.28), uSunK);
  float s = max(-sdW, 0.0);
  // ---------------- water ----------------
  vec2 gr = waves(rw, uClk, lod) * (0.35 + 0.65 * smoothstep(0.0, 1.5, s));
  if (dist < 70.0) for (int i = 0; i < 24; i++){
    if (i >= uRpN) break;
    vec4 rp = uRp[i]; vec2 dv = rw - rp.xy; float dd = length(dv);
    float rr0 = 0.25 + rp.z * 2.6, fade = rp.w * exp(-rp.z * 1.7);
    float k1 = (dd - rr0) * 6.0, k2 = (dd - rr0 * 0.6) * 8.0;
    gr += dv / max(dd, 0.02) * (exp(-k1 * k1) * sin((dd - rr0) * 22.0) + 0.5 * exp(-k2 * k2) * sin((dd - rr0 * 0.6) * 26.0)) * fade * 0.55;
  }
  vec3 N = normalize(vec3(gr.x, 1.0, gr.y));
  float NoV = max(dot(N, V), 1e-3);
  float F = clamp(0.02 + 0.98 * pow(1.0 - NoV, 5.0), 0.06, 1.0);
  vec3 Rf = reflect(-V, N); Rf.y = abs(Rf.y);
  vec3 refl = envC(Rf, 0.05);
  refl = mix(refl, L2(vec3(0.19, 0.29, 0.12)) * (0.45 + 0.35 * sunUp), smoothstep(0.30, 0.02, Rf.y) * 0.65);   // far shore / trees mirrored on the horizon
  float dep = 0.05 + 0.95 * (1.0 - exp(-s / (0.28 * uPond.w + 0.3)));                      // water depth in metres, 0 at the shore
  vec2 q = rw - V.xz / max(V.y, 0.18) * dep * 0.7 + gr * dep * 5.0;                        // refracted view ray -> where the bottom is really seen (parallax)
  float shal = 1.0 - smoothstep(0.1, 0.8, dep);
  vec3 bot = bottomCol(q, shal);
  bot = bot * (0.35 + 0.65 * sunUp) + vec3(1.0, 0.95, 0.80) * caustic(q, uClk) * sunUp * (1.0 - smoothstep(0.1, 0.7, dep)) * 0.35;
  vec3 T = exp(-vec3(2.3, 1.0, 1.5) * dep * 1.25);
  vec3 under = bot * T + L2(vec3(0.05, 0.11, 0.09)) * (0.5 + 0.5 * sunUp) * (1.0 - T);
  vec3 glint = sunC * pow(max(dot(Rf, uSunD), 0.0), 400.0) * 1.5 + sunC * pow(max(dot(Rf, uSunD), 0.0), 40.0) * 0.12;
  vec3 lin = mix(under, refl, F);
  float padM = 0.0; vec3 padC = vec3(0.0);
  if (dist < 140.0 && uSeed > 0.35 && s > 0.9){
    vec4 lp = lily(rw, uSeed);
    padM = lp.a * smoothstep(0.35, 0.60, vn(rw * 0.22 + uSeed * 91.0).x) * smoothstep(0.9, 1.8, s);
    padC = lp.rgb * (0.5 + 0.5 * sunUp) + sunC * pow(max(dot(Rf, uSunD), 0.0), 20.0) * 0.10;
  }
  lin += glint * (1.0 - padM);
  lin *= 1.0 - 0.30 * exp(-s / 0.45);                                                      // contact shadow under the bank
  lin = mix(lin, padC, padM);
  lin = mix(lin, vec3(0.35, 0.35, 0.30) * (0.5 + 0.5 * sunUp), exp(-s / 0.10) * smoothstep(0.45, 0.80, vn(rw * 5.0 + vec2(uClk * 0.3, 0.0)).x) * 0.5);   // foam / scum line
  // ---------------- bank (wet mud -> dry soil -> meadow) ----------------
  float bs = max(sdW, 0.0);
  vec2 od = rw - uPond.xz, on = od / max(length(od), 0.01);
  vec3 Nb = normalize(vec3(-on.x * 0.7, 1.0, -on.y * 0.7));                                 // bank tilts down towards the water: sun side lit, far side in shade
  float wet = 1.0 - smoothstep(0.0, 0.65, bs + (vn(rw * 2.3).x - 0.5) * 0.35);
  vec3 bc = mix(mix(L2(vec3(0.33, 0.26, 0.16)), L2(vec3(0.42, 0.34, 0.21)), vn(rw * 1.7).x), mix(L2(vec3(0.10, 0.075, 0.05)), L2(vec3(0.17, 0.13, 0.08)), vn(rw * 4.0).x), wet);
  bc = mix(bc, L2(vec3(0.45, 0.42, 0.37)) * (0.8 + 0.4 * vn(rw * 21.0).x), smoothstep(0.68, 0.84, vn(rw * 13.0).x) * 0.55);
  bc = mix(bc, L2(vec3(0.20, 0.30, 0.10)), smoothstep(0.45, 1.3, bs + (vn(rw * 1.3 + 9.0).x - 0.5) * 0.5) * 0.6);
  vec3 bl = bc * (sunC * clamp(dot(Nb, uSunD), 0.0, 1.0) * 0.8 + vec3(0.32, 0.40, 0.52) * 0.7 * (0.55 + 0.45 * Nb.y));
  vec3 Rb = reflect(-V, Nb); Rb.y = abs(Rb.y);
  bl += (envC(Rb, 0.25) * 0.10 + sunC * pow(max(dot(Rb, uSunD), 0.0), 24.0) * 0.18) * wet;  // wet mud gloss
  float ab = (1.0 - smoothstep(0.25, 1.0, bs + (vn(rw * 1.9 + 3.0).x - 0.5) * 0.5)) * 0.96;
  vec3 c = pow(mix(bl, lin, wm), vec3(1.0 / 2.2));
  c = mix(c, vec3(0.62, 0.80, 0.95), clamp(dist / 3750.0, 0.0, 1.0));
  o = vec4(c, mix(ab, 1.0, wm));
}
)GLSL";
static GLuint gProg = 0, gVao = 0; static GLint uVP, uPond, uCam, uSeed, uClk, uSunK, uSunD, uRp, uRpN;
static void init(){
    gProg = RoadGL::makeProg(VS, FS); glGenVertexArrays(1, &gVao);
    uVP = glGetUniformLocation(gProg, "uVP"); uPond = glGetUniformLocation(gProg, "uPond"); uCam = glGetUniformLocation(gProg, "uCam"); uSeed = glGetUniformLocation(gProg, "uSeed");
    uClk = glGetUniformLocation(gProg, "uClk"); uSunK = glGetUniformLocation(gProg, "uSunK"); uSunD = glGetUniformLocation(gProg, "uSunD"); uRp = glGetUniformLocation(gProg, "uRp[0]"); uRpN = glGetUniformLocation(gProg, "uRpN");
}
static void draw(const float* VP, const float* eye){
    if (Pond::gP.empty() || !gProg) return;
    glUseProgram(gProg); glUniformMatrix4fv(uVP, 1, GL_FALSE, VP); glUniform3fv(uCam, 1, eye); glUniform1f(uClk, Weather::clock); glUniform1f(uSunK, Weather::sun); glUniform3fv(uSunD, 1, Weather::sunDir);
    float rp[WaterFx::MAXR * 4]; for (int i = 0; i < WaterFx::N; i++){ const WaterFx::Rip& q = WaterFx::R[i]; rp[i*4] = q.x; rp[i*4+1] = q.z; rp[i*4+2] = q.age; rp[i*4+3] = q.amp; }
    glUniform1i(uRpN, WaterFx::N); if (WaterFx::N) glUniform4fv(uRp, WaterFx::N, rp);
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); glDepthMask(GL_FALSE);
    glBindVertexArray(gVao);
    for (const Pond::P& p : Pond::gP){
        const float dx = p.x - eye[0], dz = p.z - eye[2]; if (dx*dx + dz*dz > 1400.f * 1400.f) continue;
        glUniform4f(uPond, p.x, p.y, p.z, p.r); glUniform1f(uSeed, p.seed); glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    }
    glBindVertexArray(0); glDepthMask(GL_TRUE); glDisable(GL_BLEND);
}
}   // namespace PondGL
