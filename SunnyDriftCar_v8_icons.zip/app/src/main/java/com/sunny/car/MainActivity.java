package com.sunny.car;

import android.app.Activity;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.os.Handler;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import java.nio.ByteBuffer;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MainActivity extends Activity {
    static { System.loadLibrary("car"); }
    static native void nInit(AssetManager am);
    static native void nResize(int w, int h);
    static native void nDraw();
    static native void nInput(int mask);
    static native void nNight(int on);
    static native float nSpeed();
    static native void nSkyImg(int id, int w, int h, ByteBuffer rgba);   // sky pictures: 0..4 cube faces, 5 mountain colour, 6 mountain data
    static native void nSens(float v);          // steering sensitivity (HTML steerSens, 0.6 ... 3, default 1.8)
    static native void nReset();                // HTML resetCar()
    static native void nWheelMode(int on);      // HTML Settings > Controls: buttons / wheel
    static native void nWheelDown(float deg);
    static native void nWheelMove(float deg);
    static native void nWheelUp();
    static native float nWheelRot();            // wheel angle in degrees (+ = clockwise)
    static native float[] nMapData();           // minimap: roads, river, track, lake, village  [kind, n, payload...]
    static native void nCamDrag(float dx, float dy);   // free camera: finger drag in pixels
    static native void nCamRelease();
    static native void nCarPose(float[] out);   // minimap: car x, z, heading (rad)

    int mask = 0, kmask = 0;   // 1=left 2=right 4=gas 8=brake 16=handbrake 32=key left 64=key right   (mask = touch, kmask = keyboard)
    GLSurfaceView gl; SpeedView speed; MiniMapView miniMap; View wheelView, bl, br;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        gl = new GLSurfaceView(this);
        gl.setEGLContextClientVersion(3);
        gl.setEGLConfigChooser(8, 8, 8, 8, 24, 0);
        gl.setRenderer(new GLSurfaceView.Renderer() {
            public void onSurfaceCreated(GL10 g, EGLConfig c) { loadSky(); nInit(getAssets()); }
            public void onSurfaceChanged(GL10 g, int w, int h) { nResize(w, h); }
            public void onDrawFrame(GL10 g) { nDraw(); }
        });
        FrameLayout root = new FrameLayout(this);
        root.addView(gl);
        gl.setOnTouchListener(new View.OnTouchListener() {   // drag on the free part of the screen = orbit the camera round the car
            int pid = -1; float lx, ly;
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: case MotionEvent.ACTION_POINTER_DOWN:
                        if (pid < 0) { int i = e.getActionIndex(); pid = e.getPointerId(i); lx = e.getX(i); ly = e.getY(i); }
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        int i = e.findPointerIndex(pid); if (i < 0) return true;
                        float x = e.getX(i), y = e.getY(i); nCamDrag(x - lx, y - ly); lx = x; ly = y; return true;
                    }
                    case MotionEvent.ACTION_UP: case MotionEvent.ACTION_CANCEL: pid = -1; nCamRelease(); return true;
                    case MotionEvent.ACTION_POINTER_UP:
                        if (e.getPointerId(e.getActionIndex()) == pid) { pid = -1; nCamRelease(); }
                        return true;
                }
                return true;
            }
        });
        {   // render the 3D scene at a capped resolution (<= 720 px tall) and let the GPU scale it up: big FPS win on high-res phones
            android.util.DisplayMetrics dm = new android.util.DisplayMetrics();
            getWindowManager().getDefaultDisplay().getRealMetrics(dm);
            int sw = Math.max(dm.widthPixels, dm.heightPixels), sh = Math.min(dm.widthPixels, dm.heightPixels);
            float sc = Math.min(1f, 720f / sh);
            if (sc < 1f) gl.getHolder().setFixedSize(Math.round(sw * sc), Math.round(sh * sc));
        }
        final float dn = getResources().getDisplayMetrics().density;

        // ---- driving controls: steering arrows (left), brake + gas pedals and handbrake (right) ----
        bl  = addCtl(root, Ctl.LEFT,  2, 0, 28, 28, 104, 104);
        br  = addCtl(root, Ctl.RIGHT, 1, 0, 28 + 104 + 16, 28, 104, 104);
        addCtl(root, Ctl.GAS,   4,  Gravity.END, 28, 28, 92, 168);
        addCtl(root, Ctl.BRAKE, 8,  Gravity.END, 28 + 92 + 14, 28, 92, 118);
        addCtl(root, Ctl.HAND, 16,  Gravity.END, 28 + 92 + 14 + 14, 28 + 118 + 14, 70, 70);

        // ---- top-left round icon buttons: night / wheel / reset ----
        final IconBtn nb = new IconBtn(this, IconBtn.NIGHT);
        nb.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { nb.on = !nb.on; nb.invalidate(); nNight(nb.on ? 1 : 0); }
        });
        addTop(root, nb, 0);
        final IconBtn wb = new IconBtn(this, IconBtn.WHEEL);
        addTop(root, wb, 1);
        final IconBtn rb = new IconBtn(this, IconBtn.RESET);
        rb.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { nReset(); } });
        addTop(root, rb, 2);

        wheelView = new View(this) {      // drag-to-turn steering wheel (HTML #tWheel): rotation comes from the C++ Ctrl::Wheel
            final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            @Override protected void onDraw(Canvas c) {
                float w = getWidth(), h = getHeight(), cx = w / 2, cy = h / 2, r = Math.min(w, h) / 2 - dp(8);
                // soft base disc (does not rotate)
                p.setStyle(Paint.Style.FILL); p.setColor(0x33000000); c.drawCircle(cx, cy, r + dp(6), p);
                c.save(); c.rotate(nWheelRot(), cx, cy);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(r * 0.20f); p.setColor(0xEE16191E); c.drawCircle(cx, cy, r, p);
                p.setStrokeWidth(dp(2)); p.setColor(0x66FFFFFF); c.drawCircle(cx, cy, r + r * 0.10f, p); c.drawCircle(cx, cy, r - r * 0.10f, p);
                p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeWidth(r * 0.13f); p.setColor(0xEE2A2F38);
                c.drawLine(cx - r, cy, cx + r, cy, p); c.drawLine(cx, cy, cx, cy + r, p);
                p.setStyle(Paint.Style.FILL); p.setColor(0xFF1B1F26); c.drawCircle(cx, cy, r * 0.26f, p);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); p.setColor(0xFF29B6F6); c.drawCircle(cx, cy, r * 0.26f, p);
                p.setStyle(Paint.Style.FILL); p.setColor(0xFFFF3B3B);   // 12 o'clock mark
                c.drawRoundRect(new RectF(cx - r * 0.05f, cy - r - r * 0.10f, cx + r * 0.05f, cy - r + r * 0.10f), dp(2), dp(2), p);
                c.restore();
            }
            @Override public boolean onTouchEvent(MotionEvent e) {
                float deg = (float) Math.toDegrees(Math.atan2(e.getY() - getHeight() / 2f, e.getX() - getWidth() / 2f));
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: nWheelDown(deg); break;
                    case MotionEvent.ACTION_MOVE: nWheelMove(deg); break;
                    case MotionEvent.ACTION_UP: case MotionEvent.ACTION_CANCEL: nWheelUp(); break;
                }
                return true;
            }
        };
        FrameLayout.LayoutParams wlp = new FrameLayout.LayoutParams((int) dp(210), (int) dp(210), Gravity.BOTTOM | Gravity.START);
        wlp.leftMargin = (int) dp(28); wlp.bottomMargin = (int) dp(20);
        wheelView.setLayoutParams(wlp); wheelView.setVisibility(View.GONE); root.addView(wheelView);
        wb.setOnClickListener(new View.OnClickListener() {      // controls switch: buttons <-> steering wheel (HTML Settings > Controls)
            public void onClick(View v) {
                wb.on = !wb.on; wb.invalidate(); nWheelMode(wb.on ? 1 : 0);
                wheelView.setVisibility(wb.on ? View.VISIBLE : View.GONE);
                bl.setVisibility(wb.on ? View.GONE : View.VISIBLE); br.setVisibility(wb.on ? View.GONE : View.VISIBLE);
            }
        });
        final Handler wh = new Handler();
        wh.post(new Runnable() { public void run() { if (wheelView.getVisibility() == View.VISIBLE) wheelView.invalidate(); wh.postDelayed(this, 16); } });
        nSens(1.8f);

        speed = new SpeedView(this);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int) dp(200), (int) dp(92), Gravity.TOP | Gravity.END);
        lp.setMargins(0, (int) dp(14), (int) dp(20), 0);
        root.addView(speed, lp);
        // ---- minimap, top-left corner (tap it to switch between the zoomed follow view and the whole map) ----
        miniMap = new MiniMapView(this);
        FrameLayout.LayoutParams mlp = new FrameLayout.LayoutParams((int) dp(MAP_DP), (int) dp(MAP_DP), Gravity.TOP | Gravity.START);
        mlp.setMargins((int) dp(14), (int) dp(12), 0, 0);
        root.addView(miniMap, mlp);
        setContentView(root);
        final Handler h = new Handler();
        h.post(new Runnable() { public void run() { speed.set(nSpeed()); miniMap.tick(); h.postDelayed(this, 50); } });
    }

    static final float MAP_DP = 128;   // minimap size (dp)

    float dp(float v) { return v * getResources().getDisplayMetrics().density; }

    View addCtl(FrameLayout root, int kind, final int bit, int grav, int mx, int my, int w, int hh) {
        Ctl c = new Ctl(this, kind, bit);
        int g = Gravity.BOTTOM | (grav == Gravity.END ? Gravity.END : Gravity.START);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int) dp(w), (int) dp(hh), g);
        if (g == (Gravity.BOTTOM | Gravity.END)) lp.rightMargin = (int) dp(mx); else lp.leftMargin = (int) dp(mx);
        lp.bottomMargin = (int) dp(my);
        root.addView(c, lp);
        return c;
    }

    void addTop(FrameLayout root, View v, int slot) {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int) dp(48), (int) dp(48), Gravity.TOP | Gravity.START);
        lp.setMargins((int) dp(14 + MAP_DP + 14 + slot * 60), (int) dp(16), 0, 0);   // right of the minimap
        root.addView(v, lp);
    }

    // =====================================================================================
    //  Racing-style touch controls (custom drawn, translucent dark glass + accent colour)
    // =====================================================================================
    class Ctl extends View {
        static final int LEFT = 0, RIGHT = 1, GAS = 2, BRAKE = 3, HAND = 4;
        final int kind, bit, accent; boolean down;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Ctl(android.content.Context ctx, int kind, int bit) {
            super(ctx); this.kind = kind; this.bit = bit;
            accent = kind == GAS ? 0xFF2EE59D : kind == BRAKE ? 0xFFFF4D5A : kind == HAND ? 0xFFFFB020 : 0xFF29B6F6;
            setClickable(true);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) { down = true; mask |= bit; performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY); }
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) { down = false; mask &= ~bit; }
            else return true;
            nInput(mask | kmask); invalidate(); return true;
        }
        void text(Canvas c, String s, float cx, float cy, float size, int col) {
            p.setStyle(Paint.Style.FILL); p.setColor(col); p.setTextSize(size); p.setTextAlign(Paint.Align.CENTER);
            p.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
            c.drawText(s, cx, cy - (p.ascent() + p.descent()) / 2f, p);
        }
        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), cx = w / 2, cy = h / 2, pad = dp(5);
            c.save(); if (down) c.scale(0.95f, 0.95f, cx, cy);
            RectF r = new RectF(pad, pad, w - pad, h - pad);
            float rad = kind == HAND ? Math.min(w, h) / 2 : dp(24);
            final int rgb = accent & 0x00FFFFFF;
            p.setShader(null); p.setStyle(Paint.Style.FILL);
            if (down) { p.setColor(rgb | 0x55000000); c.drawRoundRect(new RectF(r.left - dp(4), r.top - dp(4), r.right + dp(4), r.bottom + dp(4)), rad + dp(4), rad + dp(4), p); }
            // transparent glass: a faint dark base, then a soft tint of the button's own colour (stronger while pressed)
            p.setColor(0x38101820); c.drawRoundRect(r, rad, rad, p);
            p.setShader(new LinearGradient(0, r.top, 0, r.bottom, rgb | (down ? 0x99000000 : 0x40000000), rgb | (down ? 0x55000000 : 0x14000000), Shader.TileMode.CLAMP));
            c.drawRoundRect(r, rad, rad, p); p.setShader(null);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2));
            p.setColor(down ? 0xFFFFFFFF : (rgb | 0xCC000000)); c.drawRoundRect(r, rad, rad, p);
            if (!down) { p.setStrokeWidth(dp(1)); p.setColor(0x26FFFFFF);                               // thin inner highlight
                c.drawRoundRect(new RectF(r.left + dp(5), r.top + dp(5), r.right - dp(5), r.bottom - dp(5)), rad - dp(4), rad - dp(4), p); }
            int ic = down ? 0xFFFFFFFF : accent;
            if (kind == LEFT || kind == RIGHT) {
                SvgIcon.draw(c, p, kind == LEFT ? SvgIcon.STEER_L : SvgIcon.STEER_R, cx, cy, Math.min(w, h) * 0.50f, ic, 2.6f, true);
            } else if (kind == GAS || kind == BRAKE) {
                SvgIcon.draw(c, p, kind == GAS ? SvgIcon.PEDAL_GAS : SvgIcon.PEDAL_BRAKE, cx, cy - dp(8), w * (kind == GAS ? 0.50f : 0.56f), ic, 2.0f, true);
                text(c, kind == GAS ? "GAS" : "BRAKE", cx, r.bottom - dp(18), dp(14), ic);
            } else {
                SvgIcon.draw(c, p, SvgIcon.HANDBRAKE, cx, cy, Math.min(w, h) * 0.66f, ic, 2.0f, true);
            }
            c.restore();
        }
    }

    // round glass icon button (night / wheel / reset)
    class IconBtn extends View {
        static final int NIGHT = 0, WHEEL = 1, RESET = 2;
        final int kind; boolean on;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        IconBtn(android.content.Context ctx, int kind) { super(ctx); this.kind = kind; setClickable(true); }
        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) { setAlpha(0.6f); performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY); }
            else if (e.getActionMasked() == MotionEvent.ACTION_UP || e.getActionMasked() == MotionEvent.ACTION_CANCEL) setAlpha(1f);
            return super.onTouchEvent(e);
        }
        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), cx = w / 2, cy = getHeight() / 2, r = w / 2 - dp(2);
            // every button has its own colour: night = violet (amber sun when on), wheel = teal, reset = orange
            final int col = kind == NIGHT ? (on ? 0xFFFBBF24 : 0xFFA78BFA) : kind == WHEEL ? 0xFF2DD4BF : 0xFFFB923C, rgb = col & 0x00FFFFFF;
            p.setStyle(Paint.Style.FILL); p.setColor(0x38101820); c.drawCircle(cx, cy, r, p);                     // transparent glass base
            p.setColor(rgb | (on ? 0x59000000 : 0x26000000)); c.drawCircle(cx, cy, r, p);                         // colour tint
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.8f)); p.setColor(rgb | (on ? 0xFF000000 : 0xB0000000)); c.drawCircle(cx, cy, r, p);
            String[] icon = kind == NIGHT ? (on ? SvgIcon.SUN : SvgIcon.MOON) : kind == WHEEL ? SvgIcon.WHEEL : SvgIcon.RESET;
            SvgIcon.draw(c, p, icon, cx, cy, r * 1.12f, col, 2.1f, true);
        }
    }

    // digital speedometer with a segmented rev-style bar
    class SpeedView extends View {
        float kmh;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        SpeedView(android.content.Context ctx) { super(ctx); }
        void set(float v) { if ((int) v != (int) kmh) { kmh = v; invalidate(); } else kmh = v; }
        int lerp(int a, int b, float t) {
            int ar = a >> 16 & 255, ag = a >> 8 & 255, ab = a & 255, br2 = b >> 16 & 255, bg = b >> 8 & 255, bb = b & 255;
            return 0xFF000000 | ((int) (ar + (br2 - ar) * t) << 16) | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
        }
        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            p.setStyle(Paint.Style.FILL); p.setColor(0x80101318); c.drawRoundRect(new RectF(0, 0, w, h), dp(18), dp(18), p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.5f)); p.setColor(0x33FFFFFF); c.drawRoundRect(new RectF(1, 1, w - 1, h - 1), dp(18), dp(18), p);
            p.setStyle(Paint.Style.FILL); p.setTextAlign(Paint.Align.CENTER); p.setColor(0xFFFFFFFF);
            p.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC)); p.setTextSize(dp(46));
            c.drawText(String.valueOf((int) kmh), w * 0.42f, dp(48), p);
            p.setTextSize(dp(13)); p.setColor(0xAAFFFFFF); p.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
            p.setTextAlign(Paint.Align.LEFT); c.drawText("KM/H", w * 0.42f + dp(52), dp(48), p);
            int n = 24, lit = Math.min(n, Math.round(kmh / 160f * n));
            float x0 = dp(14), gap = dp(3), sw = (w - 2 * x0 - gap * (n - 1)) / n, y0 = h - dp(24), hh = dp(10);
            for (int i = 0; i < n; i++) {
                float t = i / (n - 1f);
                p.setColor(i < lit ? (t < 0.6f ? lerp(0xFF2EE59D, 0xFFFFD600, t / 0.6f) : lerp(0xFFFFD600, 0xFFFF3D3D, (t - 0.6f) / 0.4f)) : 0x33FFFFFF);
                float x = x0 + i * (sw + gap);
                Path sp = new Path(); sp.moveTo(x + dp(3), y0); sp.lineTo(x + sw + dp(3), y0); sp.lineTo(x + sw, y0 + hh); sp.lineTo(x, y0 + hh); sp.close();   // slanted segments
                c.drawPath(sp, p);
            }
        }
    }



    // =====================================================================================
    //  Modern line icons: real SVG path data (24 x 24 viewBox, 2 px round-cap strokes, Lucide style) parsed at runtime.
    // =====================================================================================
    static class SvgIcon {
        static final String[] STEER_L = { "M14 5l-7 7 7 7", "M20 5l-7 7 7 7" };                 // double chevron (first = leading)
        static final String[] STEER_R = { "M10 5l7 7-7 7", "M4 5l7 7-7 7" };
        static final String[] PEDAL_GAS = { "M8 3h8a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z", "M9.5 8h5", "M9.5 12h5", "M9.5 16h5" };
        static final String[] PEDAL_BRAKE = { "M6 6h12a3 3 0 0 1 3 3v6a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V9a3 3 0 0 1 3-3z", "M8 10v4", "M12 10v4", "M16 10v4" };
        static final String[] HANDBRAKE = { "M12 3a9 9 0 1 0 0 18 9 9 0 1 0 0-18z", "M10 16V8h3a2.2 2.2 0 0 1 0 4.4h-3" };
        static final String[] MOON = { "M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9z" };
        static final String[] SUN = { "M12 8a4 4 0 1 0 0 8 4 4 0 1 0 0-8z", "M12 2v2", "M12 20v2", "M4.93 4.93l1.41 1.41", "M17.66 17.66l1.41 1.41", "M2 12h2", "M20 12h2", "M6.34 17.66l-1.41 1.41", "M19.07 4.93l-1.41 1.41" };
        static final String[] WHEEL = { "M12 3a9 9 0 1 0 0 18 9 9 0 1 0 0-18z", "M12 10a2 2 0 1 0 0 4 2 2 0 1 0 0-4z", "M3 12h7", "M14 12h7", "M12 14v7" };
        static final String[] RESET = { "M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8", "M3 3v5h5" };
        static final java.util.HashMap<String, Path> cache = new java.util.HashMap<>();

        // draws the icon centred at (cx, cy), `size` px wide, in colour `col`, with a soft glow underneath; later paths of a chevron pair are dimmer
        static void draw(Canvas c, Paint p, String[] paths, float cx, float cy, float size, int col, float stroke, boolean glow) {
            c.save(); c.translate(cx - size / 2, cy - size / 2); final float k = size / 24f; c.scale(k, k);
            p.setStyle(Paint.Style.STROKE); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND); p.setShader(null);
            for (int i = 0; i < paths.length; i++) {
                Path path = parse(paths[i]);
                final boolean dim = paths == STEER_L || paths == STEER_R ? i == 1 : false;
                final int cc = dim ? (col & 0x00FFFFFF) | 0x70000000 : col;
                if (glow) { p.setStrokeWidth(stroke * 2.3f); p.setColor((cc & 0x00FFFFFF) | ((cc >>> 24) / 4 << 24)); c.drawPath(path, p); }
                p.setStrokeWidth(stroke); p.setColor(cc); c.drawPath(path, p);
            }
            c.restore();
        }

        static Path parse(String d) {
            Path cached = cache.get(d); if (cached != null) return cached;
            java.util.ArrayList<String> t = new java.util.ArrayList<>();
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("[MmLlHhVvCcQqAaZz]|-?(?:\\d+\\.?\\d*|\\.\\d+)(?:[eE][-+]?\\d+)?").matcher(d);
            while (m.find()) t.add(m.group());
            Path path = new Path(); int i = 0; char cmd = 'M'; float x = 0, y = 0, sx = 0, sy = 0;
            while (i < t.size()) {
                String tok = t.get(i);
                if (Character.isLetter(tok.charAt(0))) { cmd = tok.charAt(0); i++; if (cmd == 'Z' || cmd == 'z') { path.close(); x = sx; y = sy; continue; } }
                final boolean rel = Character.isLowerCase(cmd);
                switch (Character.toUpperCase(cmd)) {
                    case 'M': { float nx = f(t, i++) + (rel ? x : 0), ny = f(t, i++) + (rel ? y : 0); path.moveTo(nx, ny); x = sx = nx; y = sy = ny; cmd = rel ? 'l' : 'L'; break; }
                    case 'L': { float nx = f(t, i++) + (rel ? x : 0), ny = f(t, i++) + (rel ? y : 0); path.lineTo(nx, ny); x = nx; y = ny; break; }
                    case 'H': { float nx = f(t, i++) + (rel ? x : 0); path.lineTo(nx, y); x = nx; break; }
                    case 'V': { float ny = f(t, i++) + (rel ? y : 0); path.lineTo(x, ny); y = ny; break; }
                    case 'C': { float x1 = f(t, i++) + (rel ? x : 0), y1 = f(t, i++) + (rel ? y : 0), x2 = f(t, i++) + (rel ? x : 0), y2 = f(t, i++) + (rel ? y : 0), nx = f(t, i++) + (rel ? x : 0), ny = f(t, i++) + (rel ? y : 0);
                        path.cubicTo(x1, y1, x2, y2, nx, ny); x = nx; y = ny; break; }
                    case 'Q': { float x1 = f(t, i++) + (rel ? x : 0), y1 = f(t, i++) + (rel ? y : 0), nx = f(t, i++) + (rel ? x : 0), ny = f(t, i++) + (rel ? y : 0);
                        path.quadTo(x1, y1, nx, ny); x = nx; y = ny; break; }
                    case 'A': { float rx = f(t, i++), ry = f(t, i++); i++; boolean large = f(t, i++) != 0, sweep = f(t, i++) != 0;
                        float nx = f(t, i++) + (rel ? x : 0), ny = f(t, i++) + (rel ? y : 0); arc(path, x, y, rx, ry, large, sweep, nx, ny); x = nx; y = ny; break; }
                    default: i++;
                }
            }
            cache.put(d, path); return path;
        }
        static float f(java.util.ArrayList<String> t, int i) { return i < t.size() ? Float.parseFloat(t.get(i)) : 0f; }

        // SVG elliptical arc (axis-aligned) -> Path.arcTo (endpoint to centre parameterisation, SVG spec F.6.5)
        static void arc(Path path, float x0, float y0, float rx, float ry, boolean large, boolean sweep, float x, float y) {
            rx = Math.abs(rx); ry = Math.abs(ry);
            if (rx == 0 || ry == 0 || (x0 == x && y0 == y)) { path.lineTo(x, y); return; }
            double dx = (x0 - x) / 2.0, dy = (y0 - y) / 2.0, lam = dx * dx / (rx * (double) rx) + dy * dy / (ry * (double) ry);
            if (lam > 1) { double sq = Math.sqrt(lam); rx *= sq; ry *= sq; }
            double num = rx * rx * ry * ry - rx * rx * dy * dy - ry * ry * dx * dx, den = rx * rx * dy * dy + ry * ry * dx * dx;
            double co = (large == sweep ? -1 : 1) * Math.sqrt(Math.max(0, num / den));
            double cxp = co * (rx * dy / ry), cyp = co * -(ry * dx / rx), cx = cxp + (x0 + x) / 2.0, cy = cyp + (y0 + y) / 2.0;
            double th1 = Math.atan2((dy - cyp) / ry, (dx - cxp) / rx), th2 = Math.atan2((-dy - cyp) / ry, (-dx - cxp) / rx), dth = th2 - th1;
            if (!sweep && dth > 0) dth -= 2 * Math.PI; else if (sweep && dth < 0) dth += 2 * Math.PI;
            path.arcTo(new RectF((float) (cx - rx), (float) (cy - ry), (float) (cx + rx), (float) (cy + ry)), (float) Math.toDegrees(th1), (float) Math.toDegrees(dth));
        }
    }

    // =====================================================================================
    //  Minimap (round, top-left): roads, river, dirt track, lake, village + the car.
    //  Default = zoomed, heading-up (the car always points up). Tap = whole map, north-up.
    // =====================================================================================
    class MiniMapView extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Path roads = new Path(), conn = new Path(), river = new Path(), track = new Path();
        final java.util.ArrayList<float[]> huts = new java.util.ArrayList<>(), churches = new java.util.ArrayList<>();
        float lakeX, lakeZ, lakeR; boolean haveLake, loaded;
        final float[] pose = new float[3]; boolean full;
        final Matrix m = new Matrix(); final float[] mv = new float[9];
        final Path clip = new Path(), arrow = new Path();
        static final float ZOOM_R = 230f, FULL_R = 980f;      // metres shown from the centre to the edge

        MiniMapView(android.content.Context ctx) {
            super(ctx); setClickable(true);
            setOnClickListener(new View.OnClickListener() { public void onClick(View v) { full = !full; invalidate(); } });
            p.setStrokeJoin(Paint.Join.ROUND); p.setStrokeCap(Paint.Cap.ROUND);
        }
        void load() {
            float[] d = nMapData(); if (d == null) return;
            int i = 0;
            while (i + 1 < d.length) {
                int kind = (int) d[i], n = (int) d[i + 1]; i += 2;
                if (kind == 4) { lakeX = d[i]; lakeZ = d[i + 1]; lakeR = d[i + 2]; haveLake = true; i += 3; continue; }
                Path t = kind == 0 ? roads : kind == 1 ? conn : kind == 2 ? river : kind == 3 ? track : null;
                float[] pts = (t == null) ? new float[n * 2] : null;
                for (int k = 0; k < n; k++) {
                    float x = d[i + k * 2], z = d[i + k * 2 + 1];
                    if (t != null) { if (k == 0) t.moveTo(x, z); else t.lineTo(x, z); } else { pts[k * 2] = x; pts[k * 2 + 1] = z; }
                }
                if (kind == 5) huts.add(pts); else if (kind == 6) churches.add(pts);
                i += n * 2;
            }
            loaded = true;
        }
        void tick() {
            if (!loaded) load();
            nCarPose(pose); invalidate();
        }
        @Override public boolean performClick() { return super.performClick(); }

        void line(Canvas c, Path path, float wMetres, float minPx, float s, int col) {
            p.setStyle(Paint.Style.STROKE); p.setColor(col); p.setStrokeWidth(Math.max(wMetres, dp(minPx) / s)); c.drawPath(path, p);
        }
        void dots(Canvas c, java.util.ArrayList<float[]> list, float rPx, float s, int col) {
            p.setStyle(Paint.Style.FILL); p.setColor(col);
            for (float[] a : list) for (int k = 0; k + 1 < a.length; k += 2) c.drawCircle(a[k], a[k + 1], rPx / s, p);
        }
        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), cx = w / 2, cy = h / 2, r = Math.min(w, h) / 2 - dp(2);
            // background disc
            p.setStyle(Paint.Style.FILL); p.setColor(0xCC1E3324); c.drawCircle(cx, cy, r, p);
            if (!loaded) return;
            final float R = full ? FULL_R : ZOOM_R, s = r / R;
            final float hd = pose[2], sH = (float) Math.sin(hd), cH = (float) Math.cos(hd);
            float a, b, cc, d;                 // screen = M * (x, z)
            if (full) { a = -s; b = 0; cc = 0; d = -s; } else { a = -cH * s; b = sH * s; cc = -sH * s; d = -cH * s; }
            float cxW = full ? 0 : pose[0], czW = full ? 0 : pose[1];
            mv[0] = a; mv[1] = b; mv[2] = cx - (a * cxW + b * czW);
            mv[3] = cc; mv[4] = d; mv[5] = cy - (cc * cxW + d * czW);
            mv[6] = 0; mv[7] = 0; mv[8] = 1; m.setValues(mv);
            c.save(); clip.reset(); clip.addCircle(cx, cy, r, Path.Direction.CW); c.clipPath(clip);
            c.concat(m);
            // lake, river, dirt track, roads (dark casing first, light surface on top)
            if (haveLake) { p.setStyle(Paint.Style.FILL); p.setColor(0xFF2F8FD0); c.drawCircle(lakeX, lakeZ, lakeR, p); }
            line(c, river, 20f, 3f, s, 0xFF3D9BE0);
            line(c, track, 8f, 1.6f, s, 0xFFB08A5A);
            line(c, roads, 22f, 4.2f, s, 0xFF0E1216); line(c, conn, 18f, 3.6f, s, 0xFF0E1216);
            line(c, roads, 14f, 2.6f, s, 0xFFC9CED6); line(c, conn, 12f, 2.2f, s, 0xFFC9CED6);
            dots(c, huts, 2.6f, s, 0xFFFFB866);
            dots(c, churches, 4.2f, s, 0xFFFFFFFF);
            c.restore();
            // frame + north mark
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); p.setColor(0xCCFFFFFF); c.drawCircle(cx, cy, r, p);
            float nx = full ? 0 : sH, ny = full ? -1 : -cH;               // screen direction of "north" (+Z)
            float nr = r - dp(9);
            p.setStyle(Paint.Style.FILL); p.setColor(0xFFFF4D5A); c.drawCircle(cx + nx * nr, cy + ny * nr, dp(7), p);
            p.setColor(0xFFFFFFFF); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(dp(9));
            p.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
            c.drawText("N", cx + nx * nr, cy + ny * nr - (p.ascent() + p.descent()) / 2f, p);
            // the car: arrow (always up when zoomed; rotated by -heading on the whole map)
            float carX = cx, carY = cy;
            if (full) { carX = mv[0] * pose[0] + mv[1] * pose[1] + mv[2]; carY = mv[3] * pose[0] + mv[4] * pose[1] + mv[5]; }
            c.save(); c.translate(carX, carY); if (full) c.rotate((float) -Math.toDegrees(hd));
            float q = dp(7);
            arrow.reset(); arrow.moveTo(0, -q * 1.4f); arrow.lineTo(q, q); arrow.lineTo(0, q * 0.4f); arrow.lineTo(-q, q); arrow.close();
            p.setStyle(Paint.Style.FILL); p.setColor(0xFF29B6F6); c.drawPath(arrow, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.5f)); p.setColor(0xFFFFFFFF); c.drawPath(arrow, p);
            c.restore();
        }
    }

    // the HTML sky pictures (embedded JPEG / PNG): decode here, hand the RGBA pixels to the C++ sky
    void loadSky() {
        String[] names = {"sky_0.jpg", "sky_1.jpg", "sky_2.jpg", "sky_3.jpg", "sky_4.jpg", "mtn_col.jpg", "mtn_data.png"};
        for (int i = 0; i < names.length; i++) {
            try {
                BitmapFactory.Options o = new BitmapFactory.Options(); o.inPreferredConfig = Bitmap.Config.ARGB_8888; o.inScaled = false;
                Bitmap b = BitmapFactory.decodeStream(getAssets().open(names[i]), null, o);
                if (b == null) continue;
                ByteBuffer bb = ByteBuffer.allocateDirect(b.getWidth() * b.getHeight() * 4);
                b.copyPixelsToBuffer(bb); bb.rewind();
                nSkyImg(i, b.getWidth(), b.getHeight(), bb); b.recycle();
            } catch (Exception e) { /* missing picture: that part of the sky stays plain */ }
        }
    }

    // keyboard (HTML: W / S / A / D, arrows, Space = handbrake, R = reset)
    int keyBit(int k) {
        switch (k) {
            case KeyEvent.KEYCODE_W: case KeyEvent.KEYCODE_DPAD_UP: return 4;
            case KeyEvent.KEYCODE_S: case KeyEvent.KEYCODE_DPAD_DOWN: return 8;
            case KeyEvent.KEYCODE_A: case KeyEvent.KEYCODE_DPAD_LEFT: return 32;
            case KeyEvent.KEYCODE_D: case KeyEvent.KEYCODE_DPAD_RIGHT: return 64;
            case KeyEvent.KEYCODE_SPACE: return 16;
        }
        return 0;
    }
    @Override public boolean onKeyDown(int k, KeyEvent e) {
        if (k == KeyEvent.KEYCODE_R) { if (e.getRepeatCount() == 0) nReset(); return true; }
        int b = keyBit(k); if (b == 0) return super.onKeyDown(k, e);
        kmask |= b; nInput(mask | kmask); return true;
    }
    @Override public boolean onKeyUp(int k, KeyEvent e) {
        int b = keyBit(k); if (b == 0) return super.onKeyUp(k, e);
        kmask &= ~b; nInput(mask | kmask); return true;
    }

    @Override protected void onPause() { super.onPause(); gl.onPause(); }
    @Override protected void onResume() { super.onResume(); gl.onResume(); }
}
