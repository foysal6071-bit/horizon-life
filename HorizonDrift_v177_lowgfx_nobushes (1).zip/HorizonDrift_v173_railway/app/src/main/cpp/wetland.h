// Horizon Drift - WETLAND PLANTS: reeds + cattails in the shallows, ferns and bushes on the banks - along the river and round every meadow pond.
// Static vertex buffer (pos, normal, colour, sway) in 100 m cells; the reeds / ferns sway in the wind in the vertex shader. Decoration only (no collision).
#pragma once
#include <GLES3/gl3.h>
#include <algorithm>
#include <cmath>
#include <map>
#include <random>
#include <vector>
#include "pond.h"
#include "river.h"
#include "road.h"
#include "sun_light.h"
#include "quality.h"

namespace Wetland {
static const double CW = 100.0;
struct Chunk { uint32_t first, count; float cx, cz; };
static std::map<long long, std::vector<uint32_t>> gCells; static std::vector<float> gV; static std::vector<uint32_t> gIdx, gFlat; static std::vector<Chunk> gChunks;
static std::vector<uint32_t>* OUT = nullptr;
static GLuint gProg = 0, gVao = 0, gVbo = 0, gIbo = 0; static GLint uVP = -1, uCam = -1, uT = -1; static bool gOk = false;
static std::mt19937 rng(5150u); static double U(){ return std::uniform_real_distribution<double>(0.0, 1.0)(rng); }

static void cell(double x, double z){ const long long k = (long long)(std::floor(x / CW) + 10000) * 20011LL + (long long)(std::floor(z / CW) + 10000); OUT = &gCells[k]; }
static uint32_t vtx(double x, double y, double z, double nx, double ny, double nz, float r, float g, float b, float sw){
    const uint32_t i = (uint32_t)(gV.size() / 10); const float a[10] = {(float)x, (float)y, (float)z, (float)nx, (float)ny, (float)nz, r, g, b, sw}; gV.insert(gV.end(), a, a + 10); return i; }
// curved ribbon: from (x,y,z) towards direction angle `az`, length L, width w0 -> 0, arcing over by `bend` (0 = straight up) ; sway scales with height
static void ribbon(double x, double y, double z, double az, double L, double w0, double bend, int seg, float r0, float g0, float b0, float r1, float g1, float b1, float swayK){
    const double dx = std::cos(az), dz = std::sin(az), px = -dz, pz = dx; uint32_t prevL = 0, prevR = 0;
    for (int i = 0; i <= seg; i++){
        const double t = (double)i / seg, a = bend * t * 1.5707963, h = std::sin(1.5707963 - a * 0.0) ; (void)h;
        const double hx = L * (std::sin(bend * t * t * 1.4) * t * 0.9), hy = L * t * (1.0 - 0.45 * bend * t), w = w0 * (1.0 - t * 0.92) * 0.5;
        const double cx = x + dx * hx, cz = z + dz * hx, cy = y + hy; const double nx = -dx * 0.6, nz = -dz * 0.6;
        const float r = (float)(r0 + (r1 - r0) * t), g = (float)(g0 + (g1 - g0) * t), b = (float)(b0 + (b1 - b0) * t), sw = (float)(swayK * t * t);
        const uint32_t L_ = vtx(cx - px * w, cy, cz - pz * w, nx, 0.8, nz, r, g, b, sw), R_ = vtx(cx + px * w, cy, cz + pz * w, nx, 0.8, nz, r, g, b, sw);
        if (i){ OUT->insert(OUT->end(), {prevL, prevR, L_, prevR, R_, L_}); } prevL = L_; prevR = R_;
    }
}
static void reedClump(double x, double y, double z){
    cell(x, z); const int n = 4 + (int)(U() * 4);
    for (int k = 0; k < n; k++){ const double ox = (U() - 0.5) * 0.9, oz = (U() - 0.5) * 0.9, L = 1.3 + U() * 1.3, v = 0.8 + U() * 0.4;
        ribbon(x + ox, y, z + oz, U() * 6.283, L, 0.07, 0.10 + U() * 0.35, 3, 0.20f * (float)v, 0.30f * (float)v, 0.08f, 0.55f * (float)v, 0.58f * (float)v, 0.22f, 1.0f); }
    if (U() < 0.45){ const double ox = (U() - 0.5) * 0.6, oz = (U() - 0.5) * 0.6, H = 1.5 + U() * 0.8;                                // cattail: stem + brown spike
        const double bx = x + ox, bz = z + oz; ribbon(bx, y, bz, 0.0, H, 0.045, 0.0, 2, 0.22f, 0.32f, 0.10f, 0.30f, 0.38f, 0.14f, 0.8f);
        for (int s = 0; s < 6; s++){ const double a0 = s * 1.0472, a1 = (s + 1) * 1.0472; const double y0 = y + H - 0.02, y1 = y + H + 0.34, r0 = 0.045;
            const uint32_t A = vtx(bx + std::cos(a0) * r0, y0, bz + std::sin(a0) * r0, std::cos(a0), 0, std::sin(a0), 0.30f, 0.17f, 0.08f, 0.8f), B = vtx(bx + std::cos(a1) * r0, y0, bz + std::sin(a1) * r0, std::cos(a1), 0, std::sin(a1), 0.30f, 0.17f, 0.08f, 0.8f);
            const uint32_t C = vtx(bx + std::cos(a0) * r0, y1, bz + std::sin(a0) * r0, std::cos(a0), 0, std::sin(a0), 0.22f, 0.12f, 0.06f, 0.85f), D = vtx(bx + std::cos(a1) * r0, y1, bz + std::sin(a1) * r0, std::cos(a1), 0, std::sin(a1), 0.22f, 0.12f, 0.06f, 0.85f);
            OUT->insert(OUT->end(), {A, B, C, B, D, C}); } }
}
static void fern(double x, double y, double z){
    cell(x, z); const int n = 8 + (int)(U() * 4); const double S = 0.7 + U() * 0.7, v = 0.8 + U() * 0.4;
    for (int k = 0; k < n; k++) ribbon(x, y + 0.05, z, k * 6.283 / n + U() * 0.3, 0.8 * S + U() * 0.3, 0.26 * S, 0.9 + U() * 0.4, 3, 0.10f * (float)v, 0.24f * (float)v, 0.06f, 0.22f * (float)v, 0.48f * (float)v, 0.14f, 0.35f);
}
static void bush(double x, double y, double z, float cr = 0.11f, float cg = 0.27f, float cb = 0.07f){
    cell(x, z); const double S = 0.8 + U() * 0.9, v = 0.75 + U() * 0.5; const int blobs = 3 + (int)(U() * 2);
    for (int b = 0; b < blobs; b++){
        const double cx = x + (U() - 0.5) * S * 1.1, cz = z + (U() - 0.5) * S * 1.1, rad = S * (0.45 + U() * 0.3), cy = y + rad * 0.65; const int W = 7, H = 4; std::vector<uint32_t> g;
        for (int j = 0; j <= H; j++) for (int i = 0; i <= W; i++){ const double a = i * 6.283185 / W, e = j * 3.14159 / H, nx = std::cos(a) * std::sin(e), ny = std::cos(e), nz = std::sin(a) * std::sin(e);
            const double lt = 0.65 + 0.35 * (ny * 0.5 + 0.5); g.push_back(vtx(cx + nx * rad, cy + ny * rad * 0.8, cz + nz * rad, nx, ny, nz, (float)(cr * v * lt), (float)(cg * v * lt), (float)(cb * lt), 0.12f)); }
        for (int j = 0; j < H; j++) for (int i = 0; i < W; i++){ const uint32_t a = g[j * (W + 1) + i], b2 = g[j * (W + 1) + i + 1], c = g[(j + 1) * (W + 1) + i], d = g[(j + 1) * (W + 1) + i + 1]; OUT->insert(OUT->end(), {a, c, b2, b2, c, d}); }
    }
}
static bool okSpot(double x, double z){
    if (Road::clearance((float)x, (float)z) < 5.0f) return false;
    for (const Village::Building& b : Village::gB){ const double dx = x - b.x, dz = z - b.z; if (dx*dx + dz*dz < 8.0 * 8.0) return false; }
    return true;
}

// ================= RIVERBANK PLANTS: yellow flag iris, purple loosestrife, rosebay willowherb, angelica, butterbur, marsh marigold, horsetail, sedge tufts, willow scrub =================
static uint32_t pv(double x, double y, double z, float r, float g, float b, float sw, double ny = 1.0){ return vtx(x, y, z, 0.0, ny, 0.0, r, g, b, sw); }
static void fanDisc(double cx, double cy, double cz, double rad, int n, float r, float g, float b, float cr, float cg, float cb, float sw, double dome, double tx, double tz){   // flat / domed disc: centre colour cr..cb, rim r..b
    const uint32_t c = pv(cx, cy + dome, cz, cr, cg, cb, sw); uint32_t first = 0, prev = 0;
    for (int i = 0; i < n; i++){ const double a = i * 6.2831853 / n, k = 1.0 + 0.18 * std::sin(a * 3.0 + cx * 7.0);
        const uint32_t q = pv(cx + std::cos(a) * rad * k, cy + tx * std::cos(a) * rad + tz * std::sin(a) * rad, cz + std::sin(a) * rad * k, r, g, b, sw); if (i == 0) first = q; else OUT->insert(OUT->end(), {c, prev, q}); prev = q; }
    OUT->insert(OUT->end(), {c, prev, first});
}
static void waterIris(double x, double y, double z){
    cell(x, z); const double v = 0.85 + U() * 0.3; const int nl = 6 + (int)(U() * 4);
    for (int k = 0; k < nl; k++){ const double a = U() * 6.283; ribbon(x + (U() - 0.5) * 0.3, y, z + (U() - 0.5) * 0.3, a, 0.8 + U() * 0.5, 0.075, 0.12 + U() * 0.30, 3, 0.10f * (float)v, 0.30f * (float)v, 0.12f * (float)v, 0.30f * (float)v, 0.50f * (float)v, 0.18f * (float)v, 0.8f); }
    const int nf = (U() < 0.7) ? 1 + (int)(U() * 3) : 0;
    for (int f = 0; f < nf; f++){ const double H = 0.95 + U() * 0.4, fx = x + (U() - 0.5) * 0.5, fz = z + (U() - 0.5) * 0.5, ph = U() * 6.283, R = 0.10 + U() * 0.03;
        ribbon(fx, y, fz, U() * 6.283, H, 0.025, 0.05, 2, 0.12f, 0.32f, 0.10f, 0.16f, 0.38f, 0.12f, 0.9f);
        const double hy = y + H; const uint32_t c = pv(fx, hy, fz, 0.78f, 0.42f, 0.04f, 0.9f);
        for (int p = 0; p < 3; p++){ const double a = ph + p * 2.0944;                                               // 3 drooping falls: yellow with an orange-brown signal patch
            const uint32_t L_ = pv(fx + std::cos(a - 0.45) * R * 0.55, hy + 0.01, fz + std::sin(a - 0.45) * R * 0.55, 0.98f * (float)v, 0.80f * (float)v, 0.05f, 0.9f), T = pv(fx + std::cos(a) * R * 1.25, hy - 0.07, fz + std::sin(a) * R * 1.25, 1.0f, 0.86f, 0.12f, 0.9f), R_ = pv(fx + std::cos(a + 0.45) * R * 0.55, hy + 0.01, fz + std::sin(a + 0.45) * R * 0.55, 0.98f * (float)v, 0.80f * (float)v, 0.05f, 0.9f);
            OUT->insert(OUT->end(), {c, L_, T, c, T, R_});
            const double b = a + 1.0472; const uint32_t sL = pv(fx + std::cos(b - 0.25) * R * 0.2, hy + 0.01, fz + std::sin(b - 0.25) * R * 0.2, 1.0f, 0.88f, 0.15f, 0.9f), sT = pv(fx + std::cos(b) * R * 0.5, hy + 0.10, fz + std::sin(b) * R * 0.5, 1.0f, 0.90f, 0.20f, 0.9f), sR = pv(fx + std::cos(b + 0.25) * R * 0.2, hy + 0.01, fz + std::sin(b + 0.25) * R * 0.2, 1.0f, 0.88f, 0.15f, 0.9f);
            OUT->insert(OUT->end(), {sL, sT, sR}); } }       // + 3 small upright standards
}
static void spike(double x, double y, double z, double H, int nfl, float r, float g, float b, float tipk){   // tall flower spike: stem + small florets spiralling up the top 45 %
    ribbon(x, y, z, U() * 6.283, H, 0.03, 0.04, 3, 0.10f, 0.27f, 0.07f, 0.16f, 0.34f, 0.10f, 0.9f);
    for (int i = 0; i < nfl; i++){ const double t = 0.55 + 0.45 * (double)i / nfl, a = i * 2.4, rr = 0.045 * (1.0 - 0.55 * (double)i / nfl) + 0.01, fy = y + H * t, fx = x + std::cos(a) * rr + 0.02 * H * t * t, fz = z + std::sin(a) * rr, sz = 0.034 * (1.0 - 0.5 * (double)i / nfl) + 0.01; const float j = 0.85f + 0.3f * (float)U();
        const float k = 1.0f - tipk * (float)i / nfl;
        const uint32_t A = pv(fx - sz, fy, fz, r * j * k, g * j * k, b * j * k, 0.9f), B = pv(fx + sz, fy, fz, r * j * k, g * j * k, b * j * k, 0.9f), C = pv(fx, fy + sz * 1.6, fz + sz * 0.5, r * j * 1.1f, g * j * 1.1f, b * j * 1.1f, 0.9f), D = pv(fx, fy + sz * 0.2, fz - sz, r * j * 0.8f, g * j * 0.8f, b * j * 0.8f, 0.9f);
        OUT->insert(OUT->end(), {A, B, C, A, D, B}); }
}
static void loosestrife(double x, double y, double z){ cell(x, z); const int n = 3 + (int)(U() * 4);
    for (int k = 0; k < n; k++){ const double ox = (U() - 0.5) * 0.7, oz = (U() - 0.5) * 0.7, H = 0.9 + U() * 0.6; spike(x + ox, y, z + oz, H, 22, 0.66f, 0.14f, 0.58f, 0.2f);
        for (int l = 0; l < 4; l++) ribbon(x + ox, y + H * (0.1 + 0.12 * l), z + oz, U() * 6.283, 0.22, 0.05, 0.9, 2, 0.12f, 0.30f, 0.08f, 0.18f, 0.40f, 0.12f, 0.7f); } }
static void willowherb(double x, double y, double z){ cell(x, z); const int n = 2 + (int)(U() * 3);
    for (int k = 0; k < n; k++){ const double ox = (U() - 0.5) * 0.6, oz = (U() - 0.5) * 0.6, H = 1.2 + U() * 0.6; spike(x + ox, y, z + oz, H, 20, 0.88f, 0.30f, 0.58f, 0.25f);
        for (int l = 0; l < 5; l++) ribbon(x + ox, y + H * (0.08 + 0.1 * l), z + oz, U() * 6.283, 0.18, 0.04, 0.9, 2, 0.12f, 0.30f, 0.08f, 0.20f, 0.42f, 0.12f, 0.7f); } }
static void angelica(double x, double y, double z){ cell(x, z); const int n = 2 + (int)(U() * 3);
    for (int k = 0; k < n; k++){ const double ox = (U() - 0.5) * 0.8, oz = (U() - 0.5) * 0.8, H = 1.0 + U() * 0.6, hx = x + ox, hz = z + oz;
        ribbon(hx, y, hz, U() * 6.283, H, 0.035, 0.05, 3, 0.20f, 0.36f, 0.12f, 0.24f, 0.42f, 0.16f, 0.9f);
        fanDisc(hx, y + H, hz, 0.15 + U() * 0.06, 9, 0.88f, 0.90f, 0.78f, 0.96f, 0.97f, 0.88f, 0.9f, 0.025, 0.0, 0.0);
        for (int s = 0; s < 3; s++){ const double a = U() * 6.283, d = 0.14 + U() * 0.1; fanDisc(hx + std::cos(a) * d, y + H - 0.08 - U() * 0.1, hz + std::sin(a) * d, 0.06, 6, 0.86f, 0.88f, 0.76f, 0.94f, 0.95f, 0.86f, 0.9f, 0.01, 0.0, 0.0); }
        for (int l = 0; l < 3; l++) ribbon(hx, y + 0.05, hz, U() * 6.283, 0.4, 0.14, 0.9, 3, 0.10f, 0.26f, 0.06f, 0.20f, 0.42f, 0.12f, 0.5f); } }
static void butterbur(double x, double y, double z){ cell(x, z); const int n = 3 + (int)(U() * 3);
    for (int k = 0; k < n; k++){ const double a = U() * 6.283, d = U() * 0.8, lx = x + std::cos(a) * d, lz = z + std::sin(a) * d, H = 0.45 + U() * 0.5, R = 0.26 + U() * 0.16, v = 0.85 + U() * 0.3;
        ribbon(lx, y, lz, U() * 6.283, H, 0.03, 0.0, 2, 0.14f, 0.30f, 0.08f, 0.16f, 0.34f, 0.10f, 0.6f);
        fanDisc(lx, y + H, lz, R, 9, 0.14f * (float)v, 0.36f * (float)v, 0.09f * (float)v, 0.20f * (float)v, 0.46f * (float)v, 0.12f * (float)v, 0.6f, -0.05, 0.35 * (U() - 0.5), 0.35 * (U() - 0.5)); } }
static void marshMarigold(double x, double y, double z){ cell(x, z); const int nl = 4 + (int)(U() * 3);
    for (int k = 0; k < nl; k++){ const double a = U() * 6.283, d = U() * 0.35; fanDisc(x + std::cos(a) * d, y + 0.10 + U() * 0.05, z + std::sin(a) * d, 0.10 + U() * 0.05, 7, 0.10f, 0.30f, 0.08f, 0.14f, 0.38f, 0.10f, 0.3f, 0.01, 0.0, 0.0); }
    const int nf = 2 + (int)(U() * 4);
    for (int k = 0; k < nf; k++){ const double a = U() * 6.283, d = U() * 0.3, fx = x + std::cos(a) * d, fz = z + std::sin(a) * d, H = 0.18 + U() * 0.14;
        ribbon(fx, y, fz, U() * 6.283, H, 0.015, 0.0, 1, 0.12f, 0.30f, 0.06f, 0.14f, 0.34f, 0.08f, 0.9f);
        fanDisc(fx, y + H, fz, 0.05 + U() * 0.015, 6, 1.0f, 0.86f, 0.05f, 0.92f, 0.62f, 0.04f, 0.9f, 0.012, 0.0, 0.0); } }
static void horsetail(double x, double y, double z){ cell(x, z); const int n = 6 + (int)(U() * 6);
    for (int k = 0; k < n; k++){ const double ox = (U() - 0.5) * 0.6, oz = (U() - 0.5) * 0.6, H = 0.5 + U() * 0.5, hx = x + ox, hz = z + oz;
        ribbon(hx, y, hz, U() * 6.283, H, 0.02, 0.0, 2, 0.30f, 0.46f, 0.16f, 0.40f, 0.56f, 0.22f, 0.8f);
        for (int w = 1; w <= 3; w++){ const double wy = y + H * w / 3.5; for (int s = 0; s < 6; s++) ribbon(hx, wy, hz, s * 1.0472 + w, 0.09 * (1.0 - 0.15 * w), 0.012, 0.8, 1, 0.30f, 0.46f, 0.16f, 0.38f, 0.54f, 0.20f, 0.8f); } } }
static void sedgeTuft(double x, double y, double z){ cell(x, z); const int n = 12 + (int)(U() * 8); const double S = 0.7 + U() * 0.6, v = 0.8 + U() * 0.4;
    for (int k = 0; k < n; k++) ribbon(x + (U() - 0.5) * 0.15, y, z + (U() - 0.5) * 0.15, U() * 6.283, (0.55 + U() * 0.4) * S, 0.035, 0.45 + U() * 0.6, 3, 0.16f * (float)v, 0.30f * (float)v, 0.07f, 0.42f * (float)v, 0.52f * (float)v, 0.16f, 1.0f); }
static void riversidePlants(){
    int nI = 0, nM = 0, nH = 0, nS = 0, nL = 0, nW = 0, nA = 0, nB = 0, nU = 0;
    for (int t = 0; t < 400000 && (nI < 260 || nM < 240 || nH < 220 || nS < 800 || nL < 300 || nW < 170 || nA < 190 || nB < 150 || nU < 25); t++){
        const double x = (U() * 2 - 1) * 1180.0, z = (U() * 2 - 1) * 840.0, sd = std::fabs(River::riverSd(x, z)); if (sd > 50) continue;
        const double g = River::groundH(x, z), y = g + Terrain::fieldH(x, z); if (!okSpot(x, z)) continue;
        if (g < -0.05 && g > -0.8){                                                               // the water's edge: shallow, wet feet
            const double yy = y - (g < -0.2 ? 0.10 : 0.0), q = U();
            if (q < 0.30 && nI < 260){ waterIris(x, yy, z); nI++; } else if (q < 0.55 && nM < 240){ marshMarigold(x, yy, z); nM++; }
            else if (q < 0.75 && nH < 220){ horsetail(x, yy, z); nH++; } else if (nS < 800){ sedgeTuft(x, yy, z); nS++; }
        } else if (g >= -0.05 && sd > 12 && sd < 46){                                             // the bank: tall damp-meadow plants and willow scrub
            const double q = U();
            if (q < 0.22 && nL < 300){ loosestrife(x, y, z); nL++; } else if (q < 0.36 && nW < 170){ willowherb(x, y, z); nW++; }
            else if (q < 0.50 && nA < 190){ angelica(x, y, z); nA++; } else if (q < 0.62 && nB < 150){ butterbur(x, y, z); nB++; }
            else if (q < 0.70 && nU < 25){ bush(x, y, z, 0.17f, 0.27f, 0.13f); nU++; }       // willow scrub: greyer, silvery green
            else if (nS < 800){ sedgeTuft(x, y, z); nS++; } }
    }
    for (const Pond::P& p : Pond::gP){                                                           // ponds: irises, marigolds, loosestrife and sedge round the edge
        for (int k = 0; k < 22; k++){ const double a = U() * 6.283, e = Pond::edgeAt(p, (float)a), r = p.r * e * (0.95 + U() * 0.45), x = p.x + std::cos(a) * r, z = p.z + std::sin(a) * r; if (!okSpot(x, z)) continue; const double yy = Village::groundAt(x, z), q = U();
            if (q < 0.22) waterIris(x, yy, z); else if (q < 0.40) marshMarigold(x, yy, z); else if (q < 0.55) loosestrife(x, yy, z); else if (q < 0.65) horsetail(x, yy, z); else if (q < 0.72) angelica(x, yy, z); else sedgeTuft(x, yy, z); } }
}

// ---- wildflower patches along the road edges: yellow + purple, ~15-26 small flowers per patch (stem + 6-sided blossom + centre)
static void flower(double x, double y, double z, bool purple){
    const double L = 0.22 + U() * 0.34, hr = 0.055 + U() * 0.04, v = 0.85 + U() * 0.3; const double hy = y + L;
    ribbon(x, y, z, U() * 6.283, L, 0.022, 0.0, 1, 0.10f, 0.26f, 0.06f, 0.14f, 0.32f, 0.08f, 0.9f);
    const float pr = purple ? 0.52f * (float)v : 0.96f * (float)v, pg = purple ? 0.18f * (float)v : 0.80f * (float)v, pb = purple ? 0.78f * (float)v : 0.06f;
    const double tx = (U() - 0.5) * 0.5, tz = (U() - 0.5) * 0.5;
    const uint32_t c = vtx(x, hy + 0.012, z, tx, 1, tz, purple ? 0.95f : 0.55f, purple ? 0.80f : 0.32f, purple ? 0.20f : 0.05f, 0.9f);
    uint32_t first = 0, prev = 0;
    for (int i = 0; i < 6; i++){ const double a = i * 1.0471976; const uint32_t q = vtx(x + std::cos(a) * hr + tx * hr * 0.5, hy + (i % 2 ? 0.0 : 0.015), z + std::sin(a) * hr + tz * hr * 0.5, tx, 1, tz, pr, pg, pb, 0.9f);
        if (i == 0) first = q; else OUT->insert(OUT->end(), {c, prev, q}); prev = q; }
    OUT->insert(OUT->end(), {c, prev, first});
}
static void roadFlowers(){
    const std::vector<const Road::Curve*> R = Road::all();
    for (size_t ci = 0; ci < R.size(); ci++){
        const Road::Curve& cv = *R[ci]; const double L = cv.length(); const int n = std::max(2, (int)(L / 9.0));
        for (int k = 0; k < n; k++){
            const double t = cv.open ? std::min((double)k / n, 0.99999) : (double)k / n; Road::V3 p = cv.getPointAt(t), tg = cv.getTangentAt(t); double tl = std::hypot(tg.x, tg.z); if (tl < 1e-9) continue; const double nx = -tg.z / tl, nz = tg.x / tl;
            for (int side = -1; side <= 1; side += 2){
                if (U() > 0.30) continue; const double off = cv.hw + 0.9 + U() * 2.2, along = (U() - 0.5) * 8.0, cx = p.x + nx * side * off + tg.x / tl * along, cz = p.z + nz * side * off + tg.z / tl * along;
                if (std::fabs(River::riverSd(cx, cz)) < 30.0 || Terrain::coastDist(cx, cz) > -52.0 || Terrain::trackDist(cx, cz) < 14.0) continue;
                bool nb = false; for (const Village::Building& b : Village::gB){ const double dx = cx - b.x, dz = cz - b.z; if (dx*dx + dz*dz < 8.0 * 8.0){ nb = true; break; } } if (nb) continue;
                const bool purple0 = U() < 0.5; const int cnt = 14 + (int)(U() * 12); cell(cx, cz);
                for (int f = 0; f < cnt; f++){ const double a = U() * 6.283, r = std::sqrt(U()) * 1.5, x = cx + std::cos(a) * r, z = cz + std::sin(a) * r;
                    flower(x, Terrain::fieldH(x, z), z, U() < 0.2 ? !purple0 : purple0); }
            }
        }
    }
}

// ---- rock cuts: steep rocky faces cut into the mountain beside the hill road (inner side), boulders at their foot; rocks roll down from the top (see drawRocks)
struct Wall { double bx, by, bz, ix, iz, H; };
static std::vector<Wall> gWalls;
static void boulder(double x, double y, double z, double r){
    cell(x, z); const int W = 6, H = 4; std::vector<uint32_t> g; const double v = 0.8 + U() * 0.3;
    for (int j = 0; j <= H; j++) for (int i = 0; i <= W; i++){ const double a = i * 6.283185 / W, e = j * 3.14159 / H, nx = std::cos(a) * std::sin(e), ny = std::cos(e), nz = std::sin(a) * std::sin(e), k = 0.85 + 0.3 * U();
        g.push_back(vtx(x + nx * r * k, y + r * 0.5 + ny * r * 0.7 * k, z + nz * r * k, nx, ny, nz, (float)(0.36 * v), (float)(0.34 * v), (float)(0.31 * v), 0.f)); }
    for (int j = 0; j < H; j++) for (int i = 0; i < W; i++){ const uint32_t a = g[j*(W+1)+i], b = g[j*(W+1)+i+1], c = g[(j+1)*(W+1)+i], d = g[(j+1)*(W+1)+i+1]; OUT->insert(OUT->end(), {a, c, b, b, c, d}); }
}
static void rockCuts(){
    if (!(Terrain::TRK.on && Terrain::PEAK.on && Terrain::TRK.n > 20)) return;
    const std::vector<float>& P = Terrain::TRK.pts; const int n = Terrain::TRK.n; const double hw = Terrain::TRK_W * 0.5; double acc = 0;
    std::vector<uint32_t> prevB(0), prevT(0); bool havePrev = false; double lastH = 4;
    for (int k = 14; k < n - 1; k++){
        const int a = std::max(k - 1, 0), b = std::min(k + 1, n - 1); double tx = P[b*2] - P[a*2], tz = P[b*2+1] - P[a*2+1]; const double tl = std::hypot(tx, tz); if (tl < 1e-6){ havePrev = false; continue; } tx /= tl; tz /= tl;
        double nx = -tz, nz = tx; if (nx * (P[k*2] - Terrain::PEAK.x) + nz * (P[k*2+1] - Terrain::PEAK.z) > 0){ nx = -nx; nz = -nz; }         // towards the mountain = the wall side
        const double bx = P[k*2] + nx * (hw + 0.7), bz = P[k*2+1] + nz * (hw + 0.7);
        if (Terrain::TRK.clr[k] <= 14.f || std::fabs(River::riverSd(bx, bz)) < 36 || Terrain::coastDist(bx, bz) > -52 || (Road::gPark[2] > 0.f && std::hypot(bx - Road::gPark[0], bz - Road::gPark[1]) < Road::gPark[2] + 8)){ havePrev = false; continue; }
        const double by = Terrain::fieldH(bx, bz), H = 3.0 + 3.5 * (0.5 + 0.5 * std::sin(k * 0.21) * std::sin(k * 0.071 + 1.3)) + U() * 0.8, back = 0.6 + H * 0.28;
        cell(bx, bz); std::vector<uint32_t> col; const int RW = 4;
        for (int r = 0; r <= RW; r++){ const double f = (double)r / RW, jit = (r == 0 ? 0 : (U() - 0.5) * 0.5), up = by - 0.4 + (H + 0.4) * f, out = -(back * f) + jit;
            const double xx = bx + nx * out + (U() - 0.5) * 0.15, zz = bz + nz * out + (U() - 0.5) * 0.15; const double band = 0.5 + 0.5 * std::sin(f * 9.0 + k * 0.4) * 0.5, v = (0.75 + 0.35 * band) * (0.85 + 0.3 * U());
            col.push_back(vtx(xx, up, zz, -nx * 0.9, 0.35, -nz * 0.9, (float)(0.40 * v), (float)(0.37 * v), (float)(0.33 * v), 0.f)); }
        if (havePrev) for (int r = 0; r < RW; r++){ const uint32_t A = prevB[r], B = prevB[r+1], C = col[r], D = col[r+1]; OUT->insert(OUT->end(), {A, C, B, B, C, D}); }
        prevB = col; havePrev = true; acc += 1;
        if (k % 3 == 0) boulder(bx - nx * 0.3 + (U() - 0.5) * 1.2, by, bz - nz * 0.3 + (U() - 0.5) * 1.2, 0.25 + U() * 0.4);
        if (k % 4 == 0) gWalls.push_back({bx, by, bz, -nx, -nz, H});                         // (ix, iz) points from the wall towards the road
    }
}
static void build(){
    if (gOk) return;
    roadFlowers(); rockCuts(); riversidePlants();
    int nR = 0, nF = 0, nB = 0;
    for (int t = 0; t < 260000 && (nR < 1500 || nF < 1100 || nB < 70); t++){                                   // ---- river banks
        const double x = (U() * 2 - 1) * 1180.0, z = (U() * 2 - 1) * 840.0, sd = std::fabs(River::riverSd(x, z)); if (sd > 52) continue;
        const double g = River::groundH(x, z); const double hill = Terrain::fieldH(x, z); const double y = g + hill;
        if (g < -0.3 && g > -1.9 && nR < 1500 && U() < 0.55){ if (okSpot(x, z)){ reedClump(x, y - 0.12, z); nR++; } }                                // shallows: reeds
        else if (g > -0.12 && sd > 27 && sd < 46){
            if (nF < 1100 && U() < 0.40 && okSpot(x, z)){ fern(x, y, z); nF++; }
            else if (nB < 70 && U() < 0.10 && okSpot(x, z)){ bush(x, y, z); nB++; } }
    }
    for (const Pond::P& p : Pond::gP){                                                                          // ---- ponds
        for (int k = 0; k < 26; k++){ const double a = U() * 6.283, e = Pond::edgeAt(p, (float)a), r = p.r * e * (0.90 + U() * 0.14); reedClump(p.x + std::cos(a) * r, p.y - 0.10, p.z + std::sin(a) * r); }
        for (int k = 0; k < 16; k++){ const double a = U() * 6.283, e = Pond::edgeAt(p, (float)a), r = p.r * e * (1.12 + U() * 0.5), x = p.x + std::cos(a) * r, z = p.z + std::sin(a) * r; if (okSpot(x, z)) fern(x, Village::groundAt(x, z), z); }
        for (int k = 0; k < 1; k++){ const double a = U() * 6.283, e = Pond::edgeAt(p, (float)a), r = p.r * e * (1.4 + U() * 0.7), x = p.x + std::cos(a) * r, z = p.z + std::sin(a) * r; if (okSpot(x, z)) bush(x, Village::groundAt(x, z), z); }
    }
    for (auto& kv : gCells){ Chunk c; c.first = (uint32_t)gIdx.size(); gIdx.insert(gIdx.end(), kv.second.begin(), kv.second.end()); c.count = (uint32_t)kv.second.size();
        const long long k = kv.first; c.cx = (float)((k / 20011LL - 10000 + 0.5) * CW); c.cz = (float)((k % 20011LL - 10000 + 0.5) * CW); if (c.count) gChunks.push_back(c); }
    gCells.clear();
}
static const char* VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in vec3 n; layout(location=2) in vec3 c; layout(location=3) in float sw;
uniform mat4 uVP; uniform float uT; out vec3 vn; out vec3 wp; out vec3 vc;
void main(){
  float w = sin(p.x * 0.45 + p.z * 0.30 - uT * 2.2) * 0.6 + sin(p.x * 1.3 - uT * 3.1 + p.z) * 0.25;
  vec3 q = p + vec3(w * 0.12, 0.0, w * 0.08) * sw;
  wp = q; vn = n; vc = c; gl_Position = uVP * vec4(q, 1.0);
}
)GLSL";
static const char* FS = R"GLSL(#version 300 es
precision highp float;
in vec3 vn; in vec3 wp; in vec3 vc; uniform vec3 uCam; out vec4 o;
void main(){
  vec3 N = normalize(vn); if (!gl_FrontFacing) N = -N;
  vec3 base = pow(vc, vec3(2.2)); vec3 L = SUNL; float d = max(dot(N, L), 0.0), wrap = max(dot(N, L) * 0.5 + 0.5, 0.0);
  vec3 amb = mix(vec3(0.20, 0.18, 0.13), vec3(0.32, 0.39, 0.50), N.y * 0.5 + 0.5);
  vec3 lit = base * (amb + vec3(1.0, 0.93, 0.78) * (0.55 * d + 0.35 * wrap));
  vec3 c = pow(lit, vec3(1.0 / 2.2)); c = mix(c, vec3(0.62, 0.80, 0.95), clamp(length(uCam - wp) / 3750.0, 0.0, 1.0)); o = vec4(c, 1.0);
}
)GLSL";
static GLuint sh(GLenum t, const char* s){ GLuint x = glCreateShader(t); SunLight::shaderSource(x, s); glCompileShader(x); return x; }

// ---- rolling rocks: up to 10 rocks break loose from a rock cut near the camera, slide down the face, bounce across the road edge and come to rest, then fade out
struct Roll { double x, y, z, vx, vy, vz, s, r, ang, life; int w; bool slide; };
static std::vector<Roll> gRolls; static GLuint gDV = 0, gDI = 0, gDVao = 0; static double gLastT = -1, gSpawn = 0;
static void drawRocks(const float* eye, float time){
    if (gWalls.empty()) return; double dt = gLastT < 0 ? 0.016 : time - gLastT; gLastT = time; if (dt <= 0 || dt > 0.2) dt = 0.016;
    gSpawn -= dt;
    if (gSpawn <= 0 && gRolls.size() < 10){ gSpawn = 0.8 + U() * 1.6;
        for (int t = 0; t < 40; t++){ const int w = (int)(U() * gWalls.size()) % (int)gWalls.size(); const Wall& W = gWalls[w]; const double dx = W.bx - eye[0], dz = W.bz - eye[2]; if (dx*dx + dz*dz > 90.0 * 90.0) continue;
            Roll r; r.w = w; r.s = 0; r.slide = true; r.r = 0.18 + U() * 0.28; r.ang = 0; r.life = 7; r.x = W.bx; r.y = W.by; r.z = W.bz; r.vx = r.vy = r.vz = 0; gRolls.push_back(r); break; } }
    std::vector<float> V; std::vector<uint32_t> I; const int Wd = 6, Hd = 4;
    for (size_t i = 0; i < gRolls.size();){
        Roll& r = gRolls[i]; const Wall& W = gWalls[r.w]; r.life -= dt; r.ang += dt * (r.slide ? 5.0 : 4.0);
        if (r.slide){ r.s += dt * (0.25 + r.s * 1.6); const double f = std::min(r.s, 1.0), back = 0.6 + W.H * 0.28; r.x = W.bx - W.ix * back * (1 - f); r.z = W.bz - W.iz * back * (1 - f); r.y = W.by + W.H * (1 - f);
            if (r.s >= 1.0){ r.slide = false; r.vx = W.ix * 3.2; r.vz = W.iz * 3.2; r.vy = 1.6; } }
        else { r.vy -= 9.8 * dt; r.x += r.vx * dt; r.y += r.vy * dt; r.z += r.vz * dt; const double gy = W.by; if (r.y < gy){ r.y = gy; r.vy = -r.vy * 0.35; r.vx *= 0.8; r.vz *= 0.8; if (std::fabs(r.vy) < 0.5) r.vy = 0; } }
        if (r.life <= 0){ gRolls.erase(gRolls.begin() + i); continue; } i++;
        const double c = std::cos(r.ang), sn = std::sin(r.ang); const uint32_t base = (uint32_t)(V.size() / 10);
        for (int j = 0; j <= Hd; j++) for (int k = 0; k <= Wd; k++){ const double a = k * 6.283185 / Wd, e = j * 3.14159 / Hd; double nx = std::cos(a) * std::sin(e), ny = std::cos(e), nz = std::sin(a) * std::sin(e);
            const double qx = nx * c - ny * sn, qy = nx * sn + ny * c; const double sh = 0.85 + 0.2 * std::sin(a * 3 + j);                                   // rotate in the (x, y) plane
            const double px = W.ix != 0 || W.iz != 0 ? qx : 0; const float f[10] = {(float)(r.x + (px * W.ix) * r.r * sh), (float)(r.y + r.r * 0.7 + qy * r.r * sh * 0.85), (float)(r.z + (px * W.iz) * r.r * sh + nz * r.r * sh), (float)nx, (float)ny, (float)nz, 0.30f, 0.28f, 0.25f, 0.f};
            V.insert(V.end(), f, f + 10); }
        for (int j = 0; j < Hd; j++) for (int k = 0; k < Wd; k++){ const uint32_t a = base + j * (Wd + 1) + k, b = a + 1, cc = a + Wd + 1, d = cc + 1; I.insert(I.end(), {a, cc, b, b, cc, d}); }
    }
    if (V.empty()) return;
    glBindVertexArray(gDVao); glBindBuffer(GL_ARRAY_BUFFER, gDV); glBufferData(GL_ARRAY_BUFFER, V.size() * 4, V.data(), GL_STREAM_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gDI); glBufferData(GL_ELEMENT_ARRAY_BUFFER, I.size() * 4, I.data(), GL_STREAM_DRAW);
    glDrawElements(GL_TRIANGLES, (GLsizei)I.size(), GL_UNSIGNED_INT, (void*)0); glBindVertexArray(0);
}
// after Pond::plan() / Terrain::init() / Road::finish() / Village plans
static void init(){
    if (gOk) return; build(); if (gIdx.empty()) return;
    gProg = glCreateProgram(); glAttachShader(gProg, sh(GL_VERTEX_SHADER, VS)); glAttachShader(gProg, sh(GL_FRAGMENT_SHADER, FS)); glLinkProgram(gProg); SunLight::attach(gProg);
    uVP = glGetUniformLocation(gProg, "uVP"); uCam = glGetUniformLocation(gProg, "uCam"); uT = glGetUniformLocation(gProg, "uT");
    glGenVertexArrays(1, &gVao); glBindVertexArray(gVao);
    glGenBuffers(1, &gVbo); glBindBuffer(GL_ARRAY_BUFFER, gVbo); glBufferData(GL_ARRAY_BUFFER, gV.size() * 4, gV.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 40, (void*)0); glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 40, (void*)12);
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 40, (void*)24); glEnableVertexAttribArray(3); glVertexAttribPointer(3, 1, GL_FLOAT, GL_FALSE, 40, (void*)36);
    glGenBuffers(1, &gIbo); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gIbo); glBufferData(GL_ELEMENT_ARRAY_BUFFER, gIdx.size() * 4, gIdx.data(), GL_STATIC_DRAW); glBindVertexArray(0);
    glGenVertexArrays(1, &gDVao); glBindVertexArray(gDVao); glGenBuffers(1, &gDV); glBindBuffer(GL_ARRAY_BUFFER, gDV); glGenBuffers(1, &gDI);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 40, (void*)0); glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 40, (void*)12);
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 40, (void*)24); glEnableVertexAttribArray(3); glVertexAttribPointer(3, 1, GL_FLOAT, GL_FALSE, 40, (void*)36); glBindVertexArray(0);
    std::vector<float>().swap(gV); std::vector<uint32_t>().swap(gIdx); gOk = true;
}
static void draw(const float* VP, const float* eye, float time){
    if (!gOk) return; const float range = 230.f * std::max(1.0f, Quality::distScale());   // riverbank plants keep their full range on Low too
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glDisable(GL_BLEND); glUseProgram(gProg); glUniformMatrix4fv(uVP, 1, GL_FALSE, VP); glUniform3fv(uCam, 1, eye); glUniform1f(uT, time); glBindVertexArray(gVao);
    for (const Chunk& c : gChunks){ const float dx = c.cx - eye[0], dz = c.cz - eye[2], lim = range + 75.f; if (dx*dx + dz*dz > lim*lim) continue; glDrawElements(GL_TRIANGLES, (GLsizei)c.count, GL_UNSIGNED_INT, (void*)(uintptr_t)(c.first * 4)); }
    glBindVertexArray(0);
    drawRocks(eye, time);
}
}
