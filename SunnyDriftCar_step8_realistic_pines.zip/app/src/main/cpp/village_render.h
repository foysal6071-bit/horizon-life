// Sunny Drift - OpenGL ES 3 rendering of the Swiss village (chalets + church), see village.h (layout) and village_mesh.h (models).
//  * one static vertex buffer per model (chalet, church); every house is one INSTANCE (x, z, scale, yaw, ground y, width factor, colour variant),
//    so the whole village is 2 draw calls no matter how many houses; houses outside the view / too far away are skipped on the CPU
//  * materials (log walls, stone, shingles, glass, shutters, plaster) come from a per-vertex material id + procedural noise: no textures
//  * at night the window glass lights up warm yellow
#pragma once
#include <GLES3/gl3.h>
#include <cstring>
#include "village.h"
#include "village_mesh.h"
#ifdef __ANDROID__
#include <android/log.h>
#endif

namespace VillageGL {

static const char* VS = R"GLSL(#version 300 es
layout(location=0) in vec3 p; layout(location=1) in vec3 n; layout(location=2) in vec3 c; layout(location=3) in float mat;
layout(location=4) in vec4 ia; layout(location=5) in vec4 ib;           // ia = (x, z, scale, yaw)   ib = (ground y, width factor, variant, -)
uniform mat4 uVP;
out vec3 vc; out vec3 vn; out vec3 wp; flat out float vm; out float vv;
void main(){
  float cs = cos(ia.w), sn = sin(ia.w); mat3 Ry = mat3(cs, 0., -sn, 0., 1., 0., sn, 0., cs);
  vec3 q = vec3(p.x * ib.y, p.y, p.z) * ia.z;
  wp = Ry * q + vec3(ia.x, ib.x, ia.y); vn = Ry * n; vc = c; vm = mat; vv = ib.z;
  gl_Position = uVP * vec4(wp, 1.0);
}
)GLSL";

static const char* FS = R"GLSL(#version 300 es
precision highp float;
in vec3 vc; in vec3 vn; in vec3 wp; flat in float vm; in float vv;
uniform vec3 uCam; uniform float uNight;
out vec4 o;
float h3(vec3 p){ p = fract(p * 0.1031); p += dot(p, p.yzx + 33.33); return fract((p.x + p.y) * p.z); }
void main(){
  vec3 V = uCam - wp; float dist = length(V); V /= dist;
  vec3 N = normalize(vn); if (!gl_FrontFacing) N = -N;
  vec3 alb = vc; float emis = 0.0; float spec = 0.0; int m = int(vm + 0.5);
  float tone = fract(vv * 3.7);
  if (m == 1){                                                    // log walls: horizontal logs, darker seams, grain, a different tone per house
    float ln = fract(wp.y * 3.2); alb *= vec3(0.80 + 0.45 * tone, 0.82 + 0.38 * tone, 0.86 + 0.28 * tone);
    alb *= 0.76 + 0.30 * smoothstep(0.0, 0.16, ln) * (1.0 - smoothstep(0.84, 1.0, ln));
    if (dist < 70.0) alb *= 0.90 + 0.16 * h3(floor(wp * vec3(22.0, 3.2, 22.0)));
  } else if (m == 2){                                             // stone: blocks of slightly different grey, dark joints
    float row = fract(wp.y * 2.8); float nz = h3(floor(wp * vec3(1.6, 2.8, 1.6))) * 0.55 + h3(floor(wp * vec3(4.5, 7.0, 4.5))) * 0.45;
    alb *= (0.62 + 0.70 * nz) * (0.82 + 0.18 * smoothstep(0.0, 0.10, row));
  } else if (m == 3){                                             // shingles / tiles: rows along the slope, each a bit different
    float ln = fract(wp.y * 4.2); float nz = h3(floor(wp * vec3(3.0, 4.2, 3.0)));
    alb *= (0.78 + 0.40 * nz) * (0.80 + 0.20 * smoothstep(0.0, 0.2, ln));
  } else if (m == 4){                                             // glass: dark sky reflection by day, warm lit windows at night
    float fr = pow(1.0 - max(dot(N, V), 0.0), 2.0);
    alb = mix(vec3(0.13, 0.18, 0.25), vec3(0.55, 0.70, 0.88), fr); spec = 1.0;
    float lit = step(0.35, h3(vec3(floor(wp.xz * 0.8), floor(wp.y * 0.45)) + vv * 17.0));
    emis = uNight * lit * 2.2;
  } else if (m == 5){                                             // painted shutters: red / green / blue by house
    float a = fract(vv * 7.13);
    alb = a < 0.40 ? vec3(0.60, 0.11, 0.09) : (a < 0.75 ? vec3(0.13, 0.34, 0.16) : vec3(0.18, 0.30, 0.50));
  } else if (m == 6){                                             // plaster
    alb *= 0.93 + 0.10 * h3(floor(wp * vec3(6.0, 6.0, 6.0)));
  }
  vec3 L = normalize(vec3(0.4, 0.8, 0.3));
  float nd = dot(N, L); float d = max(nd, 0.0), wrap = max(nd * 0.6 + 0.4, 0.0);
  vec3 sky = vec3(0.50, 0.66, 0.95), gnd = vec3(0.26, 0.30, 0.18);
  vec3 amb = mix(gnd, sky, N.y * 0.5 + 0.5) * 0.85;
  vec3 col = alb * (amb + vec3(1.00, 0.93, 0.80) * (0.85 * d + 0.24 * wrap));
  col += spec * vec3(0.9, 0.95, 1.0) * pow(max(dot(reflect(-L, N), V), 0.0), 40.0) * 0.5;
  col += vec3(1.0, 0.72, 0.32) * emis;
  col = pow(col, vec3(0.92));
  float fog = 1.0 - exp(-pow(dist / 1900.0, 1.35));
  col = mix(col, vec3(0.72, 0.87, 0.98), clamp(fog, 0.0, 1.0));
  o = vec4(col, 1.0);
}
)GLSL";

struct Model { GLuint vao = 0, vbo = 0, ibo = 0, inst = 0; GLsizei count = 0; };
static Model gM[2];
static GLuint gProg = 0; static GLint uVP = -1, uCam = -1, uNight = -1; static bool gReady = false;
const float MAX_DIST = 1100.f;

static GLuint compile(GLenum t, const char* s){
    GLuint x = glCreateShader(t); glShaderSource(x, 1, &s, nullptr); glCompileShader(x);
#ifdef __ANDROID__
    GLint ok = 0; glGetShaderiv(x, GL_COMPILE_STATUS, &ok); if (!ok){ char log[1024]; glGetShaderInfoLog(x, sizeof log, nullptr, log); __android_log_print(ANDROID_LOG_ERROR, "village", "shader: %s", log); }
#endif
    return x;
}
static void build(Model& M, const VillageMesh::Mesh& m){
    glGenVertexArrays(1, &M.vao); glBindVertexArray(M.vao);
    glGenBuffers(1, &M.vbo); glBindBuffer(GL_ARRAY_BUFFER, M.vbo); glBufferData(GL_ARRAY_BUFFER, m.v.size() * 4, m.v.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 40, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 40, (void*)12);
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 40, (void*)24);
    glEnableVertexAttribArray(3); glVertexAttribPointer(3, 1, GL_FLOAT, GL_FALSE, 40, (void*)36);
    glGenBuffers(1, &M.ibo); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, M.ibo); glBufferData(GL_ELEMENT_ARRAY_BUFFER, m.i.size() * 2, m.i.data(), GL_STATIC_DRAW);
    M.count = (GLsizei)m.i.size();
    glGenBuffers(1, &M.inst); glBindBuffer(GL_ARRAY_BUFFER, M.inst);                                   // per-instance data, 8 floats
    glEnableVertexAttribArray(4); glVertexAttribPointer(4, 4, GL_FLOAT, GL_FALSE, 32, (void*)0);  glVertexAttribDivisor(4, 1);
    glEnableVertexAttribArray(5); glVertexAttribPointer(5, 4, GL_FLOAT, GL_FALSE, 32, (void*)16); glVertexAttribDivisor(5, 1);
    glBindVertexArray(0);
}

// call once with a current GL context, after Village::plan()
static void init(){
    if (Village::gB.empty()) return;
    gProg = glCreateProgram(); glAttachShader(gProg, compile(GL_VERTEX_SHADER, VS)); glAttachShader(gProg, compile(GL_FRAGMENT_SHADER, FS)); glLinkProgram(gProg);
    uVP = glGetUniformLocation(gProg, "uVP"); uCam = glGetUniformLocation(gProg, "uCam"); uNight = glGetUniformLocation(gProg, "uNight");
    VillageMesh::Mesh ch, ck; VillageMesh::buildChalet(ch); VillageMesh::buildChurch(ck);
    build(gM[Village::CHALET], ch); build(gM[Village::CHURCH], ck);
    gReady = true;
}

static void draw(const float* VP, const float* eye, float night){
    if (!gReady) return;
    static std::vector<float> B[2]; B[0].clear(); B[1].clear();
    float pl[6][4];                                                                       // frustum planes from the column-major view-projection matrix
    for (int i = 0; i < 6; i++){ const int a = i >> 1; const float sg = (i & 1) ? 1.f : -1.f;
        for (int j = 0; j < 4; j++) pl[i][j] = VP[j*4 + 3] + sg * VP[j*4 + a];
        const float l = std::sqrt(pl[i][0]*pl[i][0] + pl[i][1]*pl[i][1] + pl[i][2]*pl[i][2]); if (l > 1e-6f) for (int j = 0; j < 4; j++) pl[i][j] /= l; }
    for (const Village::Building& b : Village::gB){
        const float dx = b.x - eye[0], dz = b.z - eye[2]; if (dx*dx + dz*dz > MAX_DIST * MAX_DIST) continue;
        const bool church = b.type == Village::CHURCH;
        const float cy = b.y + (church ? 14.f : 4.f) * b.scale, rad = (church ? 22.f : 9.f) * b.scale * (church ? 1.f : std::max(1.f, b.ws)); bool out = false;
        for (int i = 0; i < 6 && !out; i++) if (pl[i][0]*b.x + pl[i][1]*cy + pl[i][2]*b.z + pl[i][3] < -rad) out = true;
        if (out) continue;
        std::vector<float>& v = B[b.type];
        const float f[8] = {b.x, b.z, b.scale, b.rot, b.y, b.ws, b.var, 0.f}; v.insert(v.end(), f, f + 8);
    }
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE);
    glUseProgram(gProg); glUniformMatrix4fv(uVP, 1, GL_FALSE, VP); glUniform3fv(uCam, 1, eye); glUniform1f(uNight, night);
    for (int t = 0; t < 2; t++){
        const int cnt = (int)(B[t].size() / 8); if (!cnt) continue;
        glBindVertexArray(gM[t].vao);
        glBindBuffer(GL_ARRAY_BUFFER, gM[t].inst); glBufferData(GL_ARRAY_BUFFER, B[t].size() * 4, B[t].data(), GL_STREAM_DRAW);
        glDrawElementsInstanced(GL_TRIANGLES, gM[t].count, GL_UNSIGNED_SHORT, (void*)0, cnt);
    }
    glBindVertexArray(0);
}

} // namespace VillageGL
