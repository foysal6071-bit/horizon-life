// Sunny Drift - graphics quality preset (0 = Low, 1 = Normal, 2 = High). Scales how far trees / fences / houses are drawn.
#pragma once
namespace Quality {
  static int level = 1;
  static bool billboards(){ return level == 1; }   // Normal: far trees are baked camera-facing pictures
  static float distScale(){ return level == 0 ? 0.5f : (level == 2 ? 1.3f : 1.0f); }   // Normal = the original look
}
