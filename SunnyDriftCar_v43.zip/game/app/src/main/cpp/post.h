// Sunny Drift - post-processing: the whole scene is drawn into an off-screen texture, then one full-screen pass adds
//   * bloom (soft glow round the sun, bright sky and the car's lights; taken from the blurry high mip levels of the scene, so it is cheap)
//   * cinematic colour grading (gentle S-curve contrast, a little more saturation, cool shadows / warm highlights)
//   * a soft vignette
// Off on the Low quality level, and if the off-screen buffer can not be created the game simply draws straight to the screen as before.
#pragma once
#include <GLES3/gl3.h>

namespace Post {

static GLuint gFbo = 0, gTex = 0, gDepth = 0, gProg = 0, gVao = 0; static int gW = 0, gH = 0; static bool gFailed = false;
static GLint uS, uRes, uD, uWx, uNF, uCF, uCR, uCU, uTH, uSunD, uSunUV;
// weather (weather.h): the depth buffer becomes a texture while rain / fog / golden light is on, so fog can be computed per pixel from the real distance
static bool gDepthIsTex = false, wantDepth = false;
static float wx[3] = {0.f, 0.f, 0.f};                                    // rain, fog, golden light (0..1)
static float camF[3] = {0, 0, 1}, camR[3] = {1, 0, 0}, camU[3] = {0, 1, 0}, camTH[2] = {1.f, 1.f}, sunD[3] = {0, 1, 0}, sunUV[3] = {0.5f, 0.5f, 0.f};
static float bloom = 1.0f;                    // 0 = off, 1 = default
static float fxSpeed = 0.f, fxTime = 0.f, fxVan[2] = {0.5f, 0.55f}, fxCar[2] = {0.5f, 0.3f};   // speed effects: 0..1 speed, clock, vanishing point + car position on screen (0..1)

static const char* VS = R"GLSL(#version 300 es
void main(){ vec2 p = vec2((gl_VertexID == 1) ? 3.0 : -1.0, (gl_VertexID == 2) ? 3.0 : -1.0); gl_Position = vec4(p, 0.0, 1.0); }
)GLSL";
static const char* FS = R"GLSL(#version 300 es
precision highp float;
uniform sampler2D uS; uniform highp sampler2D uD; uniform vec2 uRes; uniform float uBloom;
uniform vec4 uWx; uniform vec2 uNF; uniform vec3 uCF, uCR, uCU, uSunD, uSunUV; uniform vec2 uTH; uniform float uSpd; uniform float uTime; uniform vec2 uVan; uniform vec2 uCarUV; out vec4 o;
float hs(float n){ return fract(sin(n*127.1 + 311.7)*43758.5453); }
// one layer of falling rain streaks: columns that lean with `slant`, each with a bright head and a fading tail
float rainLayer(vec2 uv, float asp, float cols, float spd, float len, float w, float slant, float seed, float dens){
  float x = (uv.x*asp + uv.y*slant) * cols;
  float id = floor(x), fx = fract(x) - 0.5;
  float h = hs(id + seed), h2 = hs(id*1.7 + seed + 9.0);
  float y = uv.y * (cols*0.35) + uTime*spd*(0.75 + 0.5*h) + h*13.0;
  float t = fract(y);
  float on = step(1.0 - dens, hs(id + floor(y)*3.7 + seed));
  return (1.0 - smoothstep(0.0, w, abs(fx - (h2 - 0.5)*0.5))) * (1.0 - smoothstep(0.0, len, t)) * on;
}
void main(){
  vec2 uv = gl_FragCoord.xy / uRes;
  float asp = uRes.x / uRes.y;
  vec3 c = texture(uS, uv).rgb;
  // speed: radial motion blur towards the vanishing point of the road. The car itself (and its surroundings) stays sharp, the road and the sides streak.
  if (uSpd > 0.02){
    vec2 q = (uv - uCarUV) * vec2(asp, 1.35);
    float keep = smoothstep(0.17, 0.32, length(q));
    vec2 d = (uVan - uv) * (0.075 * uSpd * keep);
    vec3 acc = vec3(0.0);
    for (int i = 0; i < 8; i++) acc += textureLod(uS, uv + d * (float(i) / 7.0), 0.0).rgb;
    c = acc * 0.125;
  }
  // ---- weather: overcast + depth fog + golden light + rain streaks (all fade in with uWx) ----
  float rainK = uWx.x, fogK = uWx.y, sunK = uWx.z;
  if (rainK + fogK + sunK > 0.002){
    float d0 = texture(uD, uv).r;
    bool sky = d0 > 0.99999;
    vec3 vd = normalize(uCF + (uv.x*2.0 - 1.0)*uTH.x*uCR + (uv.y*2.0 - 1.0)*uTH.y*uCU);
    float zn = d0*2.0 - 1.0;
    float ld = 2.0*uNF.x*uNF.y / (uNF.y + uNF.x - zn*(uNF.y - uNF.x));
    float dist = sky ? 7000.0 : ld / max(dot(vd, uCF), 0.25);
    float sd = max(dot(vd, uSunD), 0.0);
    float l0 = dot(c, vec3(0.299, 0.587, 0.114));
    if (rainK > 0.0){          // grey rain clouds (warm underneath when the golden light is on), flatter colours, a little darker
      vec3 oc = mix(vec3(0.70, 0.74, 0.79), vec3(0.42, 0.46, 0.53), smoothstep(0.0, 0.75, vd.y));
      oc = mix(oc, oc*vec3(1.30, 0.92, 0.72) + vec3(0.10, 0.03, 0.0), sunK*0.65);
      if (sky) c = mix(c, oc, 0.82*rainK);
      c = mix(c, vec3(l0)*vec3(0.93, 0.97, 1.03), 0.32*rainK) * (1.0 - 0.20*rainK);
    }
    float dens = 0.0024*fogK + 0.0009*rainK + 0.00030*sunK;      // mist thickens with distance; a faint warm haze with the golden light
    float fa = 1.0 - exp(-dist*dens);
    if (sky) fa = clamp((fogK*0.90 + rainK*0.25) * (1.0 - 0.55*smoothstep(0.0, 0.7, vd.y)), 0.0, 1.0);
    vec3 fc = mix(vec3(0.78, 0.82, 0.86), vec3(0.50, 0.54, 0.60), rainK*0.8);
    fc = mix(fc, vec3(1.00, 0.70, 0.42), sunK*(0.40 + 0.60*pow(sd, 3.0)));                  // warm mist, brightest towards the sun
    fc += vec3(1.0, 0.82, 0.55)*pow(sd, 16.0)*0.35*sunK;
    c = mix(c, fc, fa);
    if (sunK > 0.0){
      c *= mix(vec3(1.0), vec3(1.14, 0.96, 0.78), sunK);                                   // warm key light
      c += vec3(1.0, 0.60, 0.26)*pow(sd, 8.0)*0.30*sunK*(1.0 - 0.55*rainK);               // glow round the low sun
      if (uSunUV.z > 0.0){                                                                  // light shafts: bright sky smeared towards the sun
        vec2 dl = (uSunUV.xy - uv)*0.07; vec2 sp = uv; float acc = 0.0, w = 1.0;
        for (int i = 0; i < 10; i++){ sp += dl; vec3 sm = textureLod(uS, sp, 1.0).rgb; acc += smoothstep(0.45, 0.85, dot(sm, vec3(0.299, 0.587, 0.114)))*w; w *= 0.90; }
        float fall = exp(-3.0*length((uv - uSunUV.xy)*vec2(asp, 1.0)));
        c += vec3(1.0, 0.66, 0.32)*acc*0.040*sunK*uSunUV.z*(0.35 + fall);
      }
    }
    if (rainK > 0.01){
      float sl = 0.10 + 0.25*uSpd, dn = 0.55*rainK;
      float rs = rainLayer(uv, asp, 22.0, 14.0, 0.75, 0.045, sl, 1.0, dn)*0.55 + rainLayer(uv, asp, 45.0, 19.0, 0.65, 0.060, sl*0.9, 5.0, dn)*0.40 + rainLayer(uv, asp, 90.0, 25.0, 0.55, 0.080, sl*0.8, 11.0, dn)*0.30;
      c = mix(c, vec3(0.90, 0.94, 1.0), clamp(rs*0.55*rainK*(1.0 - 0.35*fogK), 0.0, 0.6));
    }
  }
  // bloom: three blurry mip levels, only what is clearly brighter than the sky / road leaks into a glow
  vec3 b = textureLod(uS, uv, 3.0).rgb*0.30 + textureLod(uS, uv, 4.5).rgb*0.40 + textureLod(uS, uv, 6.0).rgb*0.30;
  float bl = dot(b, vec3(0.299, 0.587, 0.114));
  c += b * (max(bl - 0.80, 0.0) / max(bl, 1e-3)) * 1.7 * uBloom;
  // colour grade
  c = mix(c, c*c*(3.0 - 2.0*c), 0.26);                                         // S-curve: deeper shadows, brighter highlights
  float l = dot(c, vec3(0.299, 0.587, 0.114));
  c = mix(vec3(l), c, 1.10);                                                   // a bit more colour
  c *= mix(vec3(0.96, 1.00, 1.05), vec3(1.04, 1.00, 0.94), smoothstep(0.20, 0.80, l));   // cool shadows, warm highlights
  float r = length((uv - 0.5)*vec2(1.0, 0.9));
  c *= 1.0 - 0.26*smoothstep(0.40, 0.88, r);                                   // vignette
  // speed lines: thin white streaks rushing outwards from the vanishing point, only near the edges of the screen, from ~100 km/h
  float lk = smoothstep(0.30, 0.85, uSpd);
  if (lk > 0.001){
    vec2 p = (uv - uVan) * vec2(asp, 1.0); float rr = length(p); float a = atan(p.y, p.x) * (64.0 / 6.2831853);
    float id = floor(a), f = fract(a);
    float h1 = hs(id), h2 = hs(id + 17.0), h3 = hs(id + 41.0), h4 = hs(id + 73.0);
    float t = fract(uTime * (1.1 + 1.6*h2) + h1);
    float head = mix(0.30, 1.35, t), len = 0.22 + 0.35*h3;
    float along = smoothstep(head - len, head, rr) * (1.0 - smoothstep(head, head + 0.03, rr));
    float lat = abs(f - 0.5) * (6.2831853 / 64.0) * rr;
    float line = (1.0 - smoothstep(0.0007, 0.0024, lat)) * along * step(0.42, h4);
    float edge = smoothstep(0.40, 0.80, rr);
    c += vec3(0.92, 0.96, 1.0) * line * edge * 0.40 * lk;
    c *= 1.0 - 0.14 * uSpd * smoothstep(0.35, 0.95, rr);                    // edges darken a little with speed
  }
  o = vec4(clamp(c, 0.0, 1.0), 1.0);
}
)GLSL";

static GLuint comp(GLenum t, const char* s){ GLuint sh = glCreateShader(t); glShaderSource(sh, 1, &s, nullptr); glCompileShader(sh); return sh; }
static void freeFbo(){ if (gFbo) glDeleteFramebuffers(1, &gFbo); if (gTex) glDeleteTextures(1, &gTex); if (gDepth){ if (gDepthIsTex) glDeleteTextures(1, &gDepth); else glDeleteRenderbuffers(1, &gDepth); } gFbo = gTex = gDepth = 0; }

static bool ensure(int W, int H){
    if (gFailed) return false;
    if (gFbo && gW == W && gH == H && gDepthIsTex == wantDepth) return true;
    if (!gProg){
        gProg = glCreateProgram(); glAttachShader(gProg, comp(GL_VERTEX_SHADER, VS)); glAttachShader(gProg, comp(GL_FRAGMENT_SHADER, FS)); glLinkProgram(gProg);
        GLint ok = 0; glGetProgramiv(gProg, GL_LINK_STATUS, &ok); if (!ok){ gFailed = true; return false; }
        uS = glGetUniformLocation(gProg, "uS"); uRes = glGetUniformLocation(gProg, "uRes"); glGenVertexArrays(1, &gVao);
        uD = glGetUniformLocation(gProg, "uD"); uWx = glGetUniformLocation(gProg, "uWx"); uNF = glGetUniformLocation(gProg, "uNF"); uCF = glGetUniformLocation(gProg, "uCF");
        uCR = glGetUniformLocation(gProg, "uCR"); uCU = glGetUniformLocation(gProg, "uCU"); uTH = glGetUniformLocation(gProg, "uTH");
        uSunD = glGetUniformLocation(gProg, "uSunD"); uSunUV = glGetUniformLocation(gProg, "uSunUV");
    }
    freeFbo(); gW = W; gH = H; gDepthIsTex = wantDepth;
    glGenTextures(1, &gTex); glBindTexture(GL_TEXTURE_2D, gTex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, W, H, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glGenFramebuffers(1, &gFbo); glBindFramebuffer(GL_FRAMEBUFFER, gFbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, gTex, 0);
    if (gDepthIsTex){      // weather: sampled depth (distance fog, sky mask)
        glGenTextures(1, &gDepth); glBindTexture(GL_TEXTURE_2D, gDepth);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT24, W, H, 0, GL_DEPTH_COMPONENT, GL_UNSIGNED_INT, nullptr);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, gDepth, 0);
    } else {
        glGenRenderbuffers(1, &gDepth); glBindRenderbuffer(GL_RENDERBUFFER, gDepth); glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT24, W, H);
        glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, gDepth);
    }
    const bool ok = glCheckFramebufferStatus(GL_FRAMEBUFFER) == GL_FRAMEBUFFER_COMPLETE;
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    if (!ok){ freeFbo(); gFailed = true; return false; }
    return true;
}

// start of the frame: redirect drawing into the off-screen buffer. Returns false when post-processing is off (then draw to the screen as usual).
static bool begin(int W, int H, bool wanted){
    if (!wanted || W < 16 || H < 16 || !ensure(W, H)) return false;
    glBindFramebuffer(GL_FRAMEBUFFER, gFbo); glViewport(0, 0, W, H); return true;
}
// end of the frame: bloom + grade + vignette onto the screen
static void end(int W, int H){
    glBindFramebuffer(GL_FRAMEBUFFER, 0); glViewport(0, 0, W, H);
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, gTex); glGenerateMipmap(GL_TEXTURE_2D);
    glDisable(GL_DEPTH_TEST); glDisable(GL_BLEND); glDisable(GL_CULL_FACE); glDepthMask(GL_FALSE);
    glUseProgram(gProg); glUniform1i(uS, 0); glUniform2f(uRes, (float)W, (float)H); glUniform1f(glGetUniformLocation(gProg, "uBloom"), bloom);
    glUniform1f(glGetUniformLocation(gProg, "uSpd"), fxSpeed); glUniform1f(glGetUniformLocation(gProg, "uTime"), fxTime);
    glUniform2f(glGetUniformLocation(gProg, "uVan"), fxVan[0], fxVan[1]); glUniform2f(glGetUniformLocation(gProg, "uCarUV"), fxCar[0], fxCar[1]);
    if (gDepthIsTex) glUniform4f(uWx, wx[0], wx[1], wx[2], 0.f); else glUniform4f(uWx, 0.f, 0.f, 0.f, 0.f); glUniform2f(uNF, 0.2f, 7000.f);
    glUniform3fv(uCF, 1, camF); glUniform3fv(uCR, 1, camR); glUniform3fv(uCU, 1, camU); glUniform2fv(uTH, 1, camTH); glUniform3fv(uSunD, 1, sunD); glUniform3fv(uSunUV, 1, sunUV);
    if (gDepthIsTex){ glActiveTexture(GL_TEXTURE1); glBindTexture(GL_TEXTURE_2D, gDepth); glUniform1i(uD, 1); glActiveTexture(GL_TEXTURE0); }
    glBindVertexArray(gVao); glDrawArrays(GL_TRIANGLES, 0, 3); glBindVertexArray(0);
    glDepthMask(GL_TRUE); glEnable(GL_DEPTH_TEST);
}

}   // namespace Post
