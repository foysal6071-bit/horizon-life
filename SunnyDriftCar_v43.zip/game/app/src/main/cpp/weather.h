#pragma once
// Sunny Drift - weather: rain, wet road, fog and golden sunset light. Four independent switches (Settings > Graphics > Weather),
// every one fades in / out smoothly (~2 s) instead of popping.
//   * rain, fog, golden light : drawn by the post pass (post.h): depth fog, overcast sky, falling streaks, warm grade + sun glow + light shafts
//   * wet road                : tarmac shader (road_shaders.h): dark glossy asphalt, sky reflections, puddles in the wheel ruts, rain ripples, sun glint
//   * golden light also lowers the real sun in the sky shader (sky.h: time of day -> late afternoon / sunset)
#include <cmath>

namespace Weather {

static float tRain = 0.f, tWet = 0.f, tFog = 0.f, tSun = 0.f;     // switches (0 / 1) set from the settings
static float rain = 0.f, wet = 0.f, fog = 0.f, sun = 0.f;          // smoothed 0..1 values used by the renderer
static float clock = 0.f;                                          // seconds, drives the ripples
static float sunDir[3] = {0.f, 0.f, 0.f};                          // unit vector towards the sun (filled from the sky each frame)

static inline void ease(float& v, float t, float k){ v += (t - v) * k; if (std::fabs(v - t) < 0.003f) v = t; }
static void update(float dt){
    const float k = 1.f - std::exp(-dt * 1.6f);
    ease(rain, tRain, k); ease(fog, tFog, k); ease(sun, tSun, k);
    ease(wet, tWet, 1.f - std::exp(-dt * (tWet > wet ? 1.2f : 0.7f)));     // the road dries a bit slower than it gets wet
    clock += dt; if (clock > 4000.f) clock -= 4000.f;
}
// the post pass (and its depth texture) is needed while any of rain / fog / golden light is on or still fading out
static bool postFx(){ return tRain > 0.f || tFog > 0.f || tSun > 0.f || rain > 0.f || fog > 0.f || sun > 0.f; }

}   // namespace Weather
