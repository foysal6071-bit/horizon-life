plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.horizonlife"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.horizonlife.game"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "0.1-kotlin-port"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
