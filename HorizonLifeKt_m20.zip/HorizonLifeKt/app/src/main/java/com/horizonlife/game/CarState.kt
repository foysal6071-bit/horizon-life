package com.horizonlife.game

/** Port of `carState` (JS). Body frame: x = forward. heading 0 faces +Z, positive heading turns left (+X). */
class CarState {
    var x = 0.0; var z = 0.0
    var heading = 0.0
    var speed = 0.0; var vy = 0.0; var yaw = 0.0
    var steer = 0.0; var steerAngle = 0.0
    var throttle = 0.0; var brake = 0.0
    var ax = 0.0; var ay = 0.0; var axS = 0.0
    var revTimer = 0.0
    var gear = 1; var rpm = 900.0; var shiftT = 0.0
    var ayLim = 9.0; var hb = 0.0; var drift = 0.0
    var fd = 0.0; var slope = 0.0
    var reverse = false; var braking = false; var handOn = false
    var wheelSpin = 0.0
}

/** Ground contact under the car (JS `_surf`). */
class Surface(var mu: Double = 1.5, var rr: Double = 0.015, var rideY: Double = 0.08)

class DriveInput {
    @Volatile var gas = false
    @Volatile var brake = false
    @Volatile var left = false
    @Volatile var right = false
    @Volatile var hand = false
    @Volatile var sens = 1.8          // JS default steerSens
    @Volatile var analog: Double? = null
}
