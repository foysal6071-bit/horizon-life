package com.horizonlife.gl

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.opengl.GLES30
import android.opengl.GLUtils
import android.opengl.Matrix
import com.horizonlife.game.Environment
import com.horizonlife.game.Harbor
import com.horizonlife.game.World
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.*

/**
 * JS "ISLAND" block: harbor pier (planks, piles, rails, gantry sign), concrete yard with warehouse + containers, 7 bobbing boats,
 * the wooden coast rail all round the island and the soft shore foam band.
 * Everything static is merged into two meshes (pier group, coast ring); boats have their own tiny meshes (drawn with a model matrix).
 * Vertex: pos(3) normal(3) colour(3) (u, v, kind)  -> see Shaders.HARBOR_*.
 */
class HarborRenderer {
    private val prog = GlUtil.program(Shaders.HARBOR_VS, Shaders.HARBOR_FS)
    private val locs = HashMap<String, Int>()
    private fun u(n: String) = locs.getOrPut(n) { GLES30.glGetUniformLocation(prog, n) }

    // ---------------- mesh builder ----------------
    private class Mb(val x0: Double, val z0: Double, val dx: Double, val dz: Double) {
        val th = atan2(-dz, dx)
        var v = FloatArray(12 * 8192); var nv = 0
        var idx = IntArray(6 * 8192); var ni = 0

        fun vert(px: Double, py: Double, pz: Double, nx: Double, ny: Double, nz: Double, c: Int, uu: Double, vv: Double, kind: Int): Int {
            if ((nv + 1) * 12 > v.size) v = v.copyOf(v.size * 2)
            val o = nv * 12
            v[o] = px.toFloat(); v[o + 1] = py.toFloat(); v[o + 2] = pz.toFloat()
            v[o + 3] = nx.toFloat(); v[o + 4] = ny.toFloat(); v[o + 5] = nz.toFloat()
            v[o + 6] = (c shr 16 and 255) / 255f; v[o + 7] = (c shr 8 and 255) / 255f; v[o + 8] = (c and 255) / 255f
            v[o + 9] = uu.toFloat(); v[o + 10] = vv.toFloat(); v[o + 11] = kind.toFloat()
            return nv++
        }
        fun tri(a: Int, b: Int, c: Int) {
            if (ni + 3 > idx.size) idx = idx.copyOf(idx.size * 2)
            idx[ni++] = a; idx[ni++] = b; idx[ni++] = c
        }
        fun quad(a: Int, b: Int, c: Int, d: Int) { tri(a, b, c); tri(a, c, d) }

        fun wx(lx: Double, lz: Double) = x0 + dx * lx - dz * lz
        fun wz(lx: Double, lz: Double) = z0 + dz * lx + dx * lz

        /** box centred at pier-local (lx,ly,lz), half sizes h*, own yaw (about its centre) and tilt about its local X (applied first, like the JS group nesting) */
        fun box(lx: Double, ly: Double, lz: Double, hx: Double, hy: Double, hz: Double, c: Int, kind: Int = 0, yaw: Double = 0.0, tilt: Double = 0.0) {
            val ct = cos(tilt); val st = sin(tilt); val phi = th + yaw; val cp = cos(phi); val sp = sin(phi)
            // local axes after the tilt, then yawed about Y
            fun yawV(x: Double, y: Double, z: Double) = doubleArrayOf(x * cp + z * sp, y, -x * sp + z * cp)
            val ax = arrayOf(yawV(1.0, 0.0, 0.0), yawV(0.0, ct, st), yawV(0.0, -st, ct))
            val hs = doubleArrayOf(hx, hy, hz)
            val cx = wx(lx, lz); val cz = wz(lx, lz)
            for (i in 0..2) {
                val j = (i + 1) % 3; val k = (i + 2) % 3
                for (s in intArrayOf(-1, 1)) {
                    val nx = ax[i][0] * s; val ny = ax[i][1] * s; val nz = ax[i][2] * s
                    val ids = IntArray(4); var q = 0
                    for ((sj, sk) in arrayOf(-1 to -1, 1 to -1, 1 to 1, -1 to 1)) {
                        val px = cx + ax[i][0] * hs[i] * s + ax[j][0] * hs[j] * sj + ax[k][0] * hs[k] * sk
                        val py = ly + ax[i][1] * hs[i] * s + ax[j][1] * hs[j] * sj + ax[k][1] * hs[k] * sk
                        val pz = cz + ax[i][2] * hs[i] * s + ax[j][2] * hs[j] * sj + ax[k][2] * hs[k] * sk
                        // local (pre-yaw, pier-local) coordinates for the plank / concrete patterns
                        val l = doubleArrayOf(0.0, 0.0, 0.0); l[i] = hs[i] * s; l[j] = hs[j] * sj; l[k] = hs[k] * sk
                        ids[q++] = vert(px, py, pz, nx, ny, nz, c, lx + l[0], lz + l[2], kind)
                    }
                    quad(ids[0], ids[1], ids[2], ids[3])
                }
            }
        }

        /** vertical prism (flat shaded) over a convex polygon given in local x/z, from y0 to y1 */
        fun prism(poly: List<DoubleArray>, y0: Double, y1: Double, c: Int) {
            val n = poly.size; var mx = 0.0; var mz = 0.0
            for (p in poly) { mx += p[0] / n; mz += p[1] / n }
            for (i in 0 until n) {
                val a = poly[i]; val b = poly[(i + 1) % n]
                var nx = b[1] - a[1]; var nz = -(b[0] - a[0]); val l = hypot(nx, nz).let { if (it == 0.0) 1.0 else it }; nx /= l; nz /= l
                if (nx * ((a[0] + b[0]) / 2 - mx) + nz * ((a[1] + b[1]) / 2 - mz) < 0) { nx = -nx; nz = -nz }
                val q = intArrayOf(vert(wx(a[0], a[1]), y0, wz(a[0], a[1]), nx, 0.0, nz, c, 0.0, 0.0, 0), vert(wx(b[0], b[1]), y0, wz(b[0], b[1]), nx, 0.0, nz, c, 0.0, 0.0, 0),
                    vert(wx(b[0], b[1]), y1, wz(b[0], b[1]), nx, 0.0, nz, c, 0.0, 0.0, 0), vert(wx(a[0], a[1]), y1, wz(a[0], a[1]), nx, 0.0, nz, c, 0.0, 0.0, 0))
                quad(q[0], q[1], q[2], q[3])
            }
            for ((y, ny) in listOf(y1 to 1.0, y0 to -1.0)) {
                val cen = vert(wx(mx, mz), y, wz(mx, mz), 0.0, ny, 0.0, c, 0.0, 0.0, 0)
                for (i in 0 until n) {
                    val a = poly[i]; val b = poly[(i + 1) % n]
                    tri(cen, vert(wx(a[0], a[1]), y, wz(a[0], a[1]), 0.0, ny, 0.0, c, 0.0, 0.0, 0), vert(wx(b[0], b[1]), y, wz(b[0], b[1]), 0.0, ny, 0.0, c, 0.0, 0.0, 0))
                }
            }
        }
    }

    private class Gpu(val vao: Int, val n: Int)
    private fun upload(b: Mb): Gpu? {
        if (b.ni == 0) return null
        val id = IntArray(1)
        GLES30.glGenVertexArrays(1, id, 0); val vao = id[0]; GLES30.glBindVertexArray(vao)
        GLES30.glGenBuffers(1, id, 0); GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, id[0])
        val fb = ByteBuffer.allocateDirect(b.nv * 48).order(ByteOrder.nativeOrder()).asFloatBuffer().put(b.v, 0, b.nv * 12).also { it.position(0) }
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, b.nv * 48, fb, GLES30.GL_STATIC_DRAW)
        for (a in 0..3) { GLES30.glEnableVertexAttribArray(a); GLES30.glVertexAttribPointer(a, 3, GLES30.GL_FLOAT, false, 48, a * 12) }
        GLES30.glGenBuffers(1, id, 0); GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, id[0])
        val ib = ByteBuffer.allocateDirect(b.ni * 4).order(ByteOrder.nativeOrder()).asIntBuffer().put(b.idx, 0, b.ni).also { it.position(0) }
        GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, b.ni * 4, ib, GLES30.GL_STATIC_DRAW)
        GLES30.glBindVertexArray(0)
        return Gpu(vao, b.ni)
    }

    private class Boat(val g: Gpu, val lx: Double, val lz: Double, val rot: Double, val ph: Double)

    private var pier: Gpu? = null; private var ring: Gpu? = null; private var foam: Gpu? = null
    private val boats = ArrayList<Boat>()
    private var signTex = 0
    private val ident = FloatArray(16).also { Matrix.setIdentityM(it, 0) }
    private val mm = FloatArray(16); private val mt = FloatArray(16)

    private fun rgb(h: Int) = h

    init {
        buildPier(); buildRing(); buildBoats(); makeSign()
    }

    private fun buildPier() {
        val b = Mb(Harbor.x0, Harbor.z0, Harbor.dx, Harbor.dz)
        val L = Harbor.L; val W = Harbor.W; val HL = Harbor.HL; val HW = Harbor.HW; val M = Harbor.MAINL
        val deckSide = 0x8c6b45
        b.box(M / 2, -0.17, 0.0, M / 2, 0.2, W / 2, deckSide, 1)
        b.box(L - HL / 2, -0.17, 0.0, HL / 2, 0.2, HW / 2, deckSide, 1)
        // piles under the deck
        val pile = 0x4b3a2a
        var x = 4.0
        while (x <= M) { for (s in intArrayOf(-1, 1)) b.box(x, -5.65, s * (W / 2 - 0.7), 0.38, 5.25, 0.38, pile); x += 7.0 }
        x = M + 3
        while (x <= L - 2) { for (z in doubleArrayOf(-HW / 2 + 1, 0.0, HW / 2 - 1)) b.box(x, -5.65, z, 0.38, 5.25, 0.38, pile); x += 6.0 }
        // rails + posts
        val rail = 0xe9e4d6; val hw = W / 2 - 0.15; val hh = HW / 2 - 0.15
        fun line(x1: Double, z1: Double, x2: Double, z2: Double) {
            val len = hypot(x2 - x1, z2 - z1)
            b.box((x1 + x2) / 2, 1.0, (z1 + z2) / 2, len / 2, 0.05, 0.05, rail, 0, atan2(-(z2 - z1), x2 - x1))
            val n = max(1, (len / 3.5).roundToInt())
            for (i in 0..n) b.box(x1 + (x2 - x1) * i / n, 0.55, z1 + (z2 - z1) * i / n, 0.08, 0.525, 0.08, rail)
        }
        line(1.0, hw, M, hw); line(1.0, -hw, M, -hw)
        line(M, hw, M, hh); line(M, -hw, M, -hh)
        line(M, hh, L - 0.15, hh); line(M, -hh, L - 0.15, -hh); line(L - 0.15, -hh, L - 0.15, hh)
        // gantry at the entrance: two poles + the "HARBOR PIER" board (textured quad, both sides)
        for (s in intArrayOf(-1, 1)) b.box(-3.0, 3.6, s * (W / 2 + 1.5), 0.25, 3.6, 0.25, 0xcfd4da)
        run {
            val bw = W + 3.4; val bh = bw * 220 / 1024; val y = 6.2
            for (side in 0..1) {
                val ids = IntArray(4); var q = 0
                for ((su, sv) in arrayOf(0 to 0, 1 to 0, 1 to 1, 0 to 1)) {
                    val lz = (su - 0.5) * bw; val ly = y + (sv - 0.5) * bh; val lx = -3.0 + if (side == 0) -0.03 else 0.03
                    ids[q++] = b.vert(b.wx(lx, lz), ly, b.wz(lx, lz), b.dx * (if (side == 0) -1 else 1), 0.0, b.dz * (if (side == 0) -1 else 1), 0xffffff, su.toDouble(), sv.toDouble(), 4)
                }
                b.quad(ids[0], ids[1], ids[2], ids[3])
            }
        }
        // yard: concrete apron, warehouse, containers
        b.box(-26.0, 0.03, 0.0, 34.0, 0.02, 29.0, 0x9a9a96, 2)
        if (Harbor.hasWarehouse) {
            val wx = -40.0; val wz = -20.0
            b.box(wx, 3.5, wz, 11.0, 3.5, 7.0, 0xb9c6d2)
            for (s in intArrayOf(-1, 1)) b.box(wx, 7.9, wz + s * 3.6, 11.4, 0.175, 4.2, 0x9b3a2e, 0, 0.0, s * 0.42)
            b.box(wx + 11.05, 2.3, wz, 0.1, 2.3, 3.5, 0x3d4a57)
        }
        val cols = intArrayOf(0xc0392b, 0x2e86c1, 0xe6b800, 0x27ae60, 0xe67e22, 0xecf0f1, 0x8e44ad, 0x16a085)
        for (c in Harbor.containers) {
            val i = c[3].toInt()
            for (lv in 0..c[2].toInt()) b.box(c[0], 1.3 + lv * 2.6, c[1], 3.1, 1.3, 1.25, cols[(i + lv * 3) % cols.size])
        }
        pier = upload(b)
    }

    private fun buildRing() {
        val b = Mb(0.0, 0.0, 1.0, 0.0)
        val COAST0 = 600.0; val n = (2 * PI * (COAST0 - 50) / 5).roundToInt()
        fun pt(i: Int): DoubleArray { val a = (i % n).toDouble() / n * 2 * PI; val r = World.coastR(a) - 50; return doubleArrayOf(cos(a) * r, sin(a) * r) }
        for (i in 0 until n) {
            val p1 = pt(i); val p2 = pt(i + 1); val mx = (p1[0] + p2[0]) / 2; val mz = (p1[1] + p2[1]) / 2
            if (abs(World.riverSd(mx, mz)) < 32) continue
            val a = Harbor.lx(mx, mz); if (a > -14 && a < Harbor.L + 2 && abs(Harbor.lz(mx, mz)) < Harbor.W / 2 + 3) continue
            b.box(p1[0], 0.55, p1[1], 0.11, 0.55, 0.11, 0x7a5a38)
            val len = hypot(p2[0] - p1[0], p2[1] - p1[1]); val yaw = atan2(-(p2[1] - p1[1]), p2[0] - p1[0])
            for (y in doubleArrayOf(0.55, 0.95)) b.box(mx, y, mz, (len + 0.1) / 2, 0.06, 0.045, 0xd8b98a, 0, yaw)
        }
        ring = upload(b)
        // shore foam: soft white band on the water along the whole coast (blended, kind 3)
        val f = Mb(0.0, 0.0, 1.0, 0.0); val FN = 360; val y = World.WATER_Y + 0.03
        for (i in 0..FN) {
            val a = i.toDouble() / FN * 2 * PI; val c = World.coastR(a); val ca = cos(a); val sa = sin(a); val uu = i.toDouble() / FN * 140
            f.vert(ca * (c - 15), y, sa * (c - 15), 0.0, 1.0, 0.0, 0xffffff, uu, 0.0, 3)
            f.vert(ca * (c - 7), y, sa * (c - 7), 0.0, 1.0, 0.0, 0xffffff, uu, 1.0, 3)
        }
        for (i in 0 until FN) { val a = i * 2; f.tri(a, a + 1, a + 2); f.tri(a + 1, a + 3, a + 2) }
        foam = upload(f)
    }

    private fun boatMesh(len: Double, hullCol: Int, cabCol: Int): Gpu? {
        val b = Mb(0.0, 0.0, 1.0, 0.0)
        val hl = len / 2; val hw = len * 0.17; val dep = len * 0.2
        val poly = ArrayList<DoubleArray>()
        poly.add(doubleArrayOf(-hl, -hw)); poly.add(doubleArrayOf(hl * 0.35, -hw))
        fun bez(p0x: Double, p0z: Double, cx: Double, cz: Double, p1x: Double, p1z: Double) {
            for (s in 1..5) { val t = s / 5.0; val u = 1 - t; poly.add(doubleArrayOf(u * u * p0x + 2 * u * t * cx + t * t * p1x, u * u * p0z + 2 * u * t * cz + t * t * p1z)) }
        }
        bez(hl * 0.35, -hw, hl * 0.85, -hw * 0.9, hl, 0.0); bez(hl, 0.0, hl * 0.85, hw * 0.9, hl * 0.35, hw)
        poly.add(doubleArrayOf(-hl, hw))
        b.prism(poly, 0.0, dep, hullCol)
        b.box(-hl * 0.15, dep + len * 0.065, 0.0, len * 0.14, len * 0.065, hw * 0.75, cabCol)
        b.box(-hl * 0.15, dep + len * 0.14, 0.0, len * 0.16, 0.06, hw * 0.85, 0x3a4350)
        b.box(hl * 0.25, dep + len * 0.22, 0.0, 0.06, len * 0.225, 0.06, 0xdddddd)
        b.box(hl * 0.25 - len * 0.06, dep + len * 0.4, 0.0, len * 0.06, len * 0.035, 0.012, 0xe63946)
        return upload(b)
    }

    private fun buildBoats() {
        val L = Harbor.L; val M = Harbor.MAINL
        // lx, lz, length, hull, cabin  (JS list; the random yaw of the last three is fixed here)
        val defs = arrayOf(
            doubleArrayOf(M - 30, 8.2, 7.5, 0xf4f1ea.toDouble(), 0x2e86c1.toDouble()), doubleArrayOf(M - 14, -8.2, 7.0, 0x2e86c1.toDouble(), 0xf4f1ea.toDouble()),
            doubleArrayOf(L - 6, 15.5, 8.0, 0xc0392b.toDouble(), 0xf4f1ea.toDouble()), doubleArrayOf(L - 8, -15.5, 6.5, 0xf1c40f.toDouble(), 0xffffff.toDouble()),
            doubleArrayOf(L + 26, 30.0, 9.0, 0xf4f1ea.toDouble(), 0x27ae60.toDouble()), doubleArrayOf(L + 14, -34.0, 7.0, 0x27ae60.toDouble(), 0xf4f1ea.toDouble()),
            doubleArrayOf(L + 44, -8.0, 10.0, 0x1f3a5f.toDouble(), 0xf4f1ea.toDouble()))
        val rnd = doubleArrayOf(0.0, 0.0, 0.0, 0.0, 0.27, -0.18, 0.12)
        defs.forEachIndexed { i, d ->
            val g = boatMesh(d[2], d[3].toInt(), d[4].toInt()) ?: return@forEachIndexed
            boats.add(Boat(g, d[0], d[1], rnd[i] + (if (d[1] < 0) 0.04 else -0.04), i * 1.7))
        }
    }

    private fun makeSign() {
        val bmp = Bitmap.createBitmap(1024, 220, Bitmap.Config.ARGB_8888); val c = Canvas(bmp); val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = 0xFF0B4F7A.toInt(); c.drawRect(0f, 0f, 1024f, 220f, p)
        p.style = Paint.Style.STROKE; p.color = 0xFFFFFFFF.toInt(); p.strokeWidth = 10f; c.drawRect(8f, 8f, 1016f, 212f, p)
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD); p.textSize = 120f
        c.drawText("HARBOR PIER", 512f, 150f, p)
        val id = IntArray(1); GLES30.glGenTextures(1, id, 0); signTex = id[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, signTex)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR); GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE); GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0); bmp.recycle()
    }

    private fun setup(vp: FloatArray, env: Environment, sun: FloatArray, fog: FloatArray, cx: Float, cy: Float, cz: Float, time: Float) {
        GLES30.glUseProgram(prog)
        GLES30.glUniformMatrix4fv(u("uVP"), 1, false, vp, 0)
        GLES30.glUniform3f(u("uCam"), cx, cy, cz); GLES30.glUniform3fv(u("uFog"), 1, fog, 0); GLES30.glUniform3fv(u("uSun"), 1, sun, 0)
        GLES30.glUniform3fv(u("uSunCol"), 1, env.sunCol, 0); GLES30.glUniform3fv(u("uAmbCol"), 1, env.ambCol, 0); GLES30.glUniform1f(u("uTime"), time)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0); GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, signTex); GLES30.glUniform1i(u("uSign"), 0)
    }
    private fun drawGpu(g: Gpu?) {
        if (g == null) return
        GLES30.glBindVertexArray(g.vao); GLES30.glDrawElements(GLES30.GL_TRIANGLES, g.n, GLES30.GL_UNSIGNED_INT, 0)
    }

    /** opaque pass (draw BEFORE the water so the piles show through it): coast rail, pier group, boats */
    fun drawSolid(vp: FloatArray, env: Environment, sun: FloatArray, fog: FloatArray, cx: Float, cy: Float, cz: Float, time: Float) {
        setup(vp, env, sun, fog, cx, cy, cz, time)
        GLES30.glDisable(GLES30.GL_CULL_FACE)
        GLES30.glUniformMatrix4fv(u("uM"), 1, false, ident, 0)
        drawGpu(ring)
        val dx = cx - Harbor.worldX(60.0, 0.0); val dz = cz - Harbor.worldZ(60.0, 0.0)
        if (dx * dx + dz * dz < 560.0 * 560.0) {
            drawGpu(pier)
            val t = time.toDouble()
            for (bt in boats) {
                Matrix.setIdentityM(mm, 0)
                Matrix.translateM(mm, 0, Harbor.x0.toFloat(), 0f, Harbor.z0.toFloat()); Matrix.rotateM(mm, 0, Math.toDegrees(Harbor.yawRad).toFloat(), 0f, 1f, 0f)
                Matrix.translateM(mm, 0, bt.lx.toFloat(), (World.WATER_Y - 0.45 + sin(t * 1.2 + bt.ph) * 0.07).toFloat(), bt.lz.toFloat())
                Matrix.rotateM(mm, 0, Math.toDegrees(bt.rot).toFloat(), 0f, 1f, 0f)
                Matrix.rotateM(mm, 0, Math.toDegrees(sin(t * 1.1 + bt.ph) * 0.02).toFloat(), 1f, 0f, 0f)
                Matrix.rotateM(mm, 0, Math.toDegrees(sin(t * 0.9 + bt.ph * 1.3) * 0.035).toFloat(), 0f, 0f, 1f)
                GLES30.glUniformMatrix4fv(u("uM"), 1, false, mm, 0)
                drawGpu(bt.g)
            }
        }
        GLES30.glBindVertexArray(0); GLES30.glEnable(GLES30.GL_CULL_FACE)
    }

    /** blended pass (after the water): shore foam band */
    fun drawFoam(vp: FloatArray, env: Environment, sun: FloatArray, fog: FloatArray, cx: Float, cy: Float, cz: Float, time: Float) {
        setup(vp, env, sun, fog, cx, cy, cz, time)
        GLES30.glUniformMatrix4fv(u("uM"), 1, false, ident, 0)
        GLES30.glDisable(GLES30.GL_CULL_FACE); GLES30.glEnable(GLES30.GL_BLEND); GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)
        GLES30.glDepthMask(false); GLES30.glEnable(GLES30.GL_POLYGON_OFFSET_FILL); GLES30.glPolygonOffset(-2f, -2f)
        drawGpu(foam)
        GLES30.glBindVertexArray(0)
        GLES30.glDisable(GLES30.GL_POLYGON_OFFSET_FILL); GLES30.glDepthMask(true); GLES30.glDisable(GLES30.GL_BLEND); GLES30.glEnable(GLES30.GL_CULL_FACE)
    }
}
