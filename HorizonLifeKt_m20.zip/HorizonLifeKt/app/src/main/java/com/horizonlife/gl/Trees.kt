package com.horizonlife.gl

import android.content.Context
import android.graphics.BitmapFactory
import android.opengl.GLES30
import android.opengl.GLUtils
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.*

/**
 * The supplied low-poly natural tree (decoded offline from TREE_B64 into assets/tree_leaf.bin + tree_bark.bin + 2 textures),
 * instanced. Per-instance data: x, y, z, scale, rotation.  Only the nearest MAX trees within RANGE metres are drawn
 * (a tree is ~40k triangles; far impostor billboards like the JS tree-LOD come in a later milestone).
 */
class Trees(ctx: Context) {
    private class Prim(val vao: Int, val nIdx: Int, val tex: Int, val leaf: Boolean)
    private val prims = ArrayList<Prim>()
    private var inst = 0
    private val buf = FloatArray(MAX * 5)
    private val fbuf = ByteBuffer.allocateDirect(MAX * 5 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()

    companion object { const val MAX = 40; const val RANGE = 220.0 }

    init {
        val ids = IntArray(1); GLES30.glGenBuffers(1, ids, 0); inst = ids[0]
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, inst); GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, MAX * 5 * 4, null, GLES30.GL_DYNAMIC_DRAW)
        prims.add(load(ctx, "tree_leaf.bin", "tree_leaf.png", true))
        prims.add(load(ctx, "tree_bark.bin", "tree_bark.jpg", false))
        GLES30.glBindVertexArray(0)
    }

    private fun load(ctx: Context, mesh: String, tex: String, leaf: Boolean): Prim {
        val raw = ctx.assets.open(mesh).use { it.readBytes() }
        val bb = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN)
        val nv = bb.getInt(0); val ni = bb.getInt(4)
        val pos = FloatArray(nv * 3) { bb.getFloat(8 + it * 4) }
        val nrm = FloatArray(nv * 3) { bb.getFloat(8 + nv * 12 + it * 4) }
        val uv = FloatArray(nv * 2) { bb.getFloat(8 + nv * 24 + it * 4) }
        val idxOff = 8 + nv * 32
        val vert = FloatArray(nv * 8)
        for (i in 0 until nv) {
            vert[i * 8] = pos[i * 3]; vert[i * 8 + 1] = pos[i * 3 + 1]; vert[i * 8 + 2] = pos[i * 3 + 2]
            vert[i * 8 + 3] = nrm[i * 3]; vert[i * 8 + 4] = nrm[i * 3 + 1]; vert[i * 8 + 5] = nrm[i * 3 + 2]
            vert[i * 8 + 6] = uv[i * 2]; vert[i * 8 + 7] = uv[i * 2 + 1]
        }
        val idx = ShortArray(ni) { bb.getShort(idxOff + it * 2) }
        val id = IntArray(1)
        GLES30.glGenVertexArrays(1, id, 0); val vao = id[0]; GLES30.glBindVertexArray(vao)
        GLES30.glGenBuffers(1, id, 0); GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, id[0])
        val fb = ByteBuffer.allocateDirect(vert.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(vert).also { it.position(0) }
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, vert.size * 4, fb, GLES30.GL_STATIC_DRAW)
        GLES30.glEnableVertexAttribArray(0); GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 32, 0)
        GLES30.glEnableVertexAttribArray(1); GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 32, 12)
        GLES30.glEnableVertexAttribArray(2); GLES30.glVertexAttribPointer(2, 2, GLES30.GL_FLOAT, false, 32, 24)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, inst)
        GLES30.glEnableVertexAttribArray(3); GLES30.glVertexAttribPointer(3, 4, GLES30.GL_FLOAT, false, 20, 0); GLES30.glVertexAttribDivisor(3, 1)
        GLES30.glEnableVertexAttribArray(4); GLES30.glVertexAttribPointer(4, 1, GLES30.GL_FLOAT, false, 20, 16); GLES30.glVertexAttribDivisor(4, 1)
        GLES30.glGenBuffers(1, id, 0); GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, id[0])
        val sb = ByteBuffer.allocateDirect(ni * 2).order(ByteOrder.nativeOrder()).asShortBuffer().put(idx).also { it.position(0) }
        GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, ni * 2, sb, GLES30.GL_STATIC_DRAW)
        GLES30.glBindVertexArray(0)
        // texture (image row 0 = v 0, same as three.js flipY=false)
        GLES30.glGenTextures(1, id, 0); GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, id[0])
        val bmp = ctx.assets.open(tex).use { BitmapFactory.decodeStream(it) }
        GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0); bmp.recycle(); GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR_MIPMAP_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_REPEAT)
        return Prim(vao, ni, id[0], leaf)
    }

    /** @param candidates flat array x,y,z,scale,rot of every tree in the loaded chunks */
    fun draw(program: Int, candidates: List<FloatArray>, camX: Double, camZ: Double, time: Float, loc: (String) -> Int) {
        // pick the nearest MAX trees within RANGE
        class C(val d: Double, val arr: FloatArray, val k: Int)
        val near = ArrayList<C>()
        for (a in candidates) for (k in 0 until a.size / 5) {
            val dx = a[k * 5] - camX; val dz = a[k * 5 + 2] - camZ; val d = dx * dx + dz * dz
            if (d < RANGE * RANGE) near.add(C(d, a, k))
        }
        if (near.isEmpty()) return
        near.sortBy { it.d }
        val n = min(near.size, min(MAX, com.horizonlife.game.Settings.treeMax))
        for (i in 0 until n) { val c = near[i]; System.arraycopy(c.arr, c.k * 5, buf, i * 5, 5) }
        fbuf.clear(); fbuf.put(buf, 0, n * 5); fbuf.position(0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, inst); GLES30.glBufferSubData(GLES30.GL_ARRAY_BUFFER, 0, n * 20, fbuf)
        GLES30.glDisable(GLES30.GL_CULL_FACE)
        GLES30.glUniform1f(loc("uTime"), time); GLES30.glUniform1i(loc("uTex"), 0)
        for (p in prims) {
            GLES30.glUniform1f(loc("uLeaf"), if (p.leaf) 1f else 0f)
            GLES30.glActiveTexture(GLES30.GL_TEXTURE0); GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, p.tex)
            GLES30.glBindVertexArray(p.vao)
            GLES30.glDrawElementsInstanced(GLES30.GL_TRIANGLES, p.nIdx, GLES30.GL_UNSIGNED_SHORT, 0, n)
        }
        GLES30.glBindVertexArray(0); GLES30.glEnable(GLES30.GL_CULL_FACE)
    }
}
