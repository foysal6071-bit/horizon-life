package com.horizonlife.game

import kotlin.math.*

/**
 * Port of the JS POTH block: a few shallow, wet potholes 70-180 m apart along every road (JS seed 20260, same LCG so the layout matches).
 * The only effect on the car is the wheel sinking up to 2 cm (spring in Game) + a faint body nod; the decal is drawn by GameRenderer.drawPotholes.
 * JS puddles are disabled in the original (`n = 0 // puddles removed`) and it never rains, so neither is ported.
 */
object Potholes {
    class P(val x: Double, val z: Double, val r: Double, val y: Double, val a: Double, val e: Double)
    private const val C = 8.0
    val list = ArrayList<P>()
    private val cell = HashMap<Long, ArrayList<P>>()
    private fun key(i: Int, j: Int) = (i.toLong() shl 32) xor (j.toLong() and 0xffffffffL)

    init {
        var sd = 20260L
        fun rn(): Double { sd = (sd * 16807L) % 2147483647L; return sd / 2147483647.0 }
        val t = DoubleArray(4)
        for (cv in Roads.all) {
            val len = cv.length
            var dd = 40 + rn() * 80
            while (dd < len - 20) {
                val s = if (cv.closed) dd % len else min(dd, len * 0.99999)
                cv.at(s, t)
                val nl = hypot(t[2], t[3]).let { if (it == 0.0) 1.0 else it }
                val off = (rn() - 0.5) * 2 * cv.hw * 0.7
                val x = t[0] + (-t[3] / nl) * off; val z = t[1] + (t[2] / nl) * off; val r = 0.42 + rn() * 0.30
                if (abs(World.riverSd(x, z)) >= 12 + World.RIVER_WALL && !Harbor.near(x, z, 10.0)) {          // JS inRiver(x,z,12); no pier / track / islands yet
                    val p = P(x, z, r, World.fieldH(x, z), rn() * 6.283, 0.75 + rn() * 0.5)
                    list.add(p); cell.getOrPut(key(floor(x / C).toInt(), floor(z / C).toInt())) { ArrayList() }.add(p)
                }
                dd += 70 + rn() * 110
            }
        }
    }

    /** 0..1 depth of the pothole under a point (smooth bowl) */
    fun at(x: Double, z: Double): Double {
        val cx = floor(x / C).toInt(); val cz = floor(z / C).toInt(); var best = 0.0
        for (i in cx - 1..cx + 1) for (j in cz - 1..cz + 1) {
            val g = cell[key(i, j)] ?: continue
            for (p in g) {
                val dx = x - p.x; val dz = z - p.z; val c = cos(p.a); val s = sin(p.a)
                val u = (dx * c - dz * s) / (p.r * p.e); val v = (dx * s + dz * c) / p.r; val d = sqrt(u * u + v * v)
                if (d < 1) { val k = 0.5 + 0.5 * cos(PI * d); if (k > best) best = k }
            }
        }
        return best
    }
}
