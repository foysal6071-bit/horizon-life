package com.horizonlife.game

import kotlin.math.*

/**
 * Port of the JS road network: two winding ring roads (R=220 / R=420, harmonics `ringRad`) and the radial connector between them,
 * a 24 m grid of centre-line samples for roadClearance()/fieldClear(). Bridges are NOT ported yet (flat deck over the river).
 */
object Roads {
    const val SURF = 0.08
    private const val RG = 24.0

    class Road(val x: DoubleArray, val z: DoubleArray, val hw: Double, val closed: Boolean, val yBias: Double) {
        val n get() = x.size
        val s = DoubleArray(x.size)            // cumulative arc length
        val length: Double
        init {
            for (i in 1 until n) s[i] = s[i - 1] + hypot(x[i] - x[i - 1], z[i] - z[i - 1])
            length = s[n - 1] + if (closed) hypot(x[0] - x[n - 1], z[0] - z[n - 1]) else 0.0
        }
        fun tangent(i: Int): DoubleArray {
            val a = if (closed) (i - 1 + n) % n else max(i - 1, 0); val b = if (closed) (i + 1) % n else min(i + 1, n - 1)
            val tx = x[b] - x[a]; val tz = z[b] - z[a]; val l = hypot(tx, tz).let { if (it == 0.0) 1.0 else it }
            return doubleArrayOf(tx / l, tz / l)
        }
        /** point + unit tangent at arc length s0 (wraps on closed roads): out = x, z, tx, tz */
        fun at(s0: Double, out: DoubleArray) {
            var q = s0
            if (closed) { q %= length; if (q < 0) q += length } else q = min(max(q, 0.0), length)
            var lo = 0; var hi = n - 1
            while (lo < hi) { val m = (lo + hi + 1) / 2; if (s[m] <= q) lo = m else hi = m - 1 }
            val i = lo; val j = if (closed) (i + 1) % n else min(i + 1, n - 1)
            val seg = (if (closed && i == n - 1) length - s[i] else s[j] - s[i]).let { if (it <= 0.0) 1.0 else it }
            val u = min(max((q - s[i]) / seg, 0.0), 1.0)
            out[0] = x[i] + (x[j] - x[i]) * u; out[1] = z[i] + (z[j] - z[i]) * u
            val a = tangent(i); val b = tangent(j)
            val tx = a[0] + (b[0] - a[0]) * u; val tz = a[1] + (b[1] - a[1]) * u
            val l = hypot(tx, tz).let { if (it == 0.0) 1.0 else it }
            out[2] = tx / l; out[3] = tz / l
        }
    }

    private val RING_H = mapOf(
        220 to Triple(doubleArrayOf(36.0, 22.0, 14.0, 6.0), doubleArrayOf(2.0, 3.0, 5.0, 7.0), 0.8),
        420 to Triple(doubleArrayOf(34.0, 24.0, 12.0, 10.0), doubleArrayOf(3.0, 4.0, 7.0, 11.0), 1.0))

    fun ringRad(R: Int, a: Double): Double {
        val h = RING_H[R] ?: RING_H[if (R < 300) 220 else 420]!!
        val p = R * 0.013; var r = R.toDouble()
        for (i in 0..3) r += h.third * h.first[i] * (if (i % 2 == 1) cos(h.second[i] * a - p * i) else sin(h.second[i] * a + p * (i + 1)))
        return r
    }

    /** the river angle that both rings cross most perpendicular / straight (only used to place the connector) */
    private fun pickRiverAngle(): Double {
        var best = 0.4; var bestScore = 1e18; val e = 0.002
        var A = 0.0
        while (A < PI) {
            val a0 = atan2(cos(A), sin(A))
            var sc = if (abs(sin(a0)) < 0.45) 1e3 else 0.0
            for (R in intArrayOf(220, 420)) for (base in doubleArrayOf(a0, a0 + PI)) for (k in -4..4) {
                val a = base + k * (60.0 / R / 4)
                val r0 = ringRad(R, a); val r1 = ringRad(R, a + e); val rm = ringRad(R, a - e)
                val dr = (r1 - rm) / (2 * e); val ddr = (r1 - 2 * r0 + rm) / (e * e)
                val kappa = (r0 * r0 + 2 * dr * dr - r0 * ddr) / (r0 * r0 + dr * dr).pow(1.5)
                sc += 6 * (dr / R) * (dr / R) + 0.5 * (kappa * R) * (kappa * R)
            }
            if (sc < bestScore) { bestScore = sc; best = A }
            A += 0.01
        }
        return best
    }
    val RIVER_ANG = pickRiverAngle()

    /** uniform Catmull-Rom through control points, `sub` samples per segment */
    private fun spline(px: DoubleArray, pz: DoubleArray, closed: Boolean, sub: Int): Pair<DoubleArray, DoubleArray> {
        val n = px.size; val ox = ArrayList<Double>(); val oz = ArrayList<Double>()
        val segs = if (closed) n else n - 1
        fun idx(i: Int) = if (closed) ((i % n) + n) % n else min(max(i, 0), n - 1)
        for (i in 0 until segs) for (k in 0 until sub) {
            val t = k.toDouble() / sub; val t2 = t * t; val t3 = t2 * t
            val i0 = idx(i - 1); val i1 = idx(i); val i2 = idx(i + 1); val i3 = idx(i + 2)
            fun cr(p0: Double, p1: Double, p2: Double, p3: Double) =
                0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 + (-p0 + 3 * p1 - 3 * p2 + p3) * t3)
            ox.add(cr(px[i0], px[i1], px[i2], px[i3])); oz.add(cr(pz[i0], pz[i1], pz[i2], pz[i3]))
        }
        if (!closed) { ox.add(px[n - 1]); oz.add(pz[n - 1]) }
        return ox.toDoubleArray() to oz.toDoubleArray()
    }

    private fun ring(R: Int, width: Double): Road {
        val seg = (R * 1.6).roundToInt(); val px = DoubleArray(seg); val pz = DoubleArray(seg)
        for (i in 0 until seg) { val a = i.toDouble() / seg * PI * 2; val rr = ringRad(R, a); px[i] = cos(a) * rr; pz[i] = sin(a) * rr }
        val (x, z) = spline(px, pz, true, 3)
        return Road(x, z, width / 2, true, 0.0)
    }

    private fun connector(width: Double): Road {
        fun wrap(a: Double) = atan2(sin(a), cos(a))
        val a0 = atan2(cos(RIVER_ANG), sin(RIVER_ANG))
        var a = wrap(a0 + PI / 2); if (abs(a) < 0.7) a = wrap(a0 - PI / 2)
        val rA = ringRad(220, a); val rB = ringRad(420, a); val K = 14
        val px = DoubleArray(K + 1); val pz = DoubleArray(K + 1)
        for (i in 0..K) {
            val t = i.toDouble() / K; val r = rA + (rB - rA) * t; val ang = a + 0.11 * sin(2 * PI * t) * sin(PI * t)
            px[i] = cos(ang) * r; pz[i] = sin(ang) * r
        }
        val (x, z) = spline(px, pz, false, 8)
        return Road(x, z, width / 2, false, 0.005)
    }

    val roadA = ring(220, 14.0)
    val roadB = ring(420, 15.0)
    val roadC = connector(12.0)
    val all = listOf(roadA, roadB, roadC)

    private val grid = HashMap<Long, ArrayList<Double>>()
    private fun key(cx: Int, cz: Int) = (cx.toLong() shl 32) xor (cz.toLong() and 0xffffffffL)
    init {
        for (r in all) {
            // resample every ~2 m along the centre line
            var next = 0.0
            for (i in 0 until r.n) {
                if (r.s[i] < next) continue
                next = r.s[i] + 2.0
                val l = grid.getOrPut(key(floor(r.x[i] / RG).toInt(), floor(r.z[i] / RG).toInt())) { ArrayList() }
                l.add(r.x[i]); l.add(r.z[i]); l.add(r.hw)
            }
        }
    }

    /** distance from the nearest road EDGE (negative = on the road); radius = cells searched around */
    fun clearance(x: Double, z: Double, cells: Int = 1): Double {
        val cx = floor(x / RG).toInt(); val cz = floor(z / RG).toInt(); var best = 1e9
        for (i in -cells..cells) for (j in -cells..cells) {
            val l = grid[key(cx + i, cz + j)] ?: continue
            var k = 0
            while (k < l.size) { val dx = x - l[k]; val dz = z - l[k + 1]; val d = sqrt(dx * dx + dz * dz) - l[k + 2]; if (d < best) best = d; k += 3 }
        }
        return best
    }

    /** start line: first sample of the inner ring + its heading */
    fun startPose(): Triple<Double, Double, Double> {
        val t = roadA.tangent(0); return Triple(roadA.x[0], roadA.z[0], atan2(t[0], t[1]))
    }
}
