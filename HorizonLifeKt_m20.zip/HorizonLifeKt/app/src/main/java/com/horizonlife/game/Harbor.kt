package com.horizonlife.game

import kotlin.math.*

/**
 * Port of the JS harbor: PIER placement (closest coast spot to the start line with free road / river margins), pierLocal / nearPier,
 * the solid obstacles of the harbor yard (gantry poles, warehouse, containers) and the pier part of coastGuard().
 * Meshes: gl/HarborRenderer.kt. Pier-local frame: +x = out to sea, z = across, y up.
 */
object Harbor {
    const val L = 110.0; const val W = 9.0; const val HL = 16.0; const val HW = 22.0
    const val MAINL = L - HL
    private const val CAR_R = 1.4

    val x0: Double; val z0: Double; val dx: Double; val dz: Double

    /** true while the car is on the wide pier head (JS islandObj.onPier): no tyre marks / mud there */
    @Volatile var onPier = false

    /** solid circles of the yard: x, z, r (world space) */
    val obst: DoubleArray
    /** containers that fit (not on a road): lx, lz, stack height, original index (colour) */
    val containers: List<DoubleArray>
    val hasWarehouse: Boolean

    init {
        val sp = Roads.startPose(); val a0 = atan2(sp.second, sp.first)
        fun find(cMin: Double, rvMin: Double): DoubleArray? {
            var best: DoubleArray? = null; var bs = 1e18; var a = -PI
            while (a < PI) {
                val c = World.coastR(a)
                if (c >= cMin) {
                    val ddx = cos(a); val ddz = sin(a); val px = -ddz; val pz = ddx; val r0 = c - 62
                    var ok = true; var s = -62.0
                    while (s <= L + 30 && ok) {
                        for (o in doubleArrayOf(-46.0, -23.0, 0.0, 23.0, 46.0)) {
                            val x = ddx * (r0 + s) + px * o; val z = ddz * (r0 + s) + pz * o
                            if (abs(World.riverSd(x, z)) < rvMin || (s < 0 && World.roadClearance(x, z) < 8)) { ok = false; break }
                        }
                        s += 8.0
                    }
                    if (ok) {
                        var da = abs(a - a0); if (da > PI) da = 2 * PI - da
                        if (da < bs) { bs = da; best = doubleArrayOf(ddx * r0, ddz * r0, ddx, ddz) }
                    }
                }
                a += 0.01
            }
            return best
        }
        val sel = find(590.0, 100.0) ?: find(570.0, 70.0) ?: find(540.0, 45.0) ?: run {
            val a = 1.0; val c = World.coastR(a); val ddx = cos(a); val ddz = sin(a); doubleArrayOf(ddx * (c - 62), ddz * (c - 62), ddx, ddz)
        }
        x0 = sel[0]; z0 = sel[1]; dx = sel[2]; dz = sel[3]

        fun wx(lx: Double, lz: Double) = x0 + dx * lx - dz * lz
        fun wz(lx: Double, lz: Double) = z0 + dz * lx + dx * lz
        fun free(lx: Double, lz: Double) = World.roadClearance(wx(lx, lz), wz(lx, lz)) > 5
        val o = ArrayList<Double>()
        fun circle(lx: Double, lz: Double, r: Double) { o.add(wx(lx, lz)); o.add(wz(lx, lz)); o.add(r) }
        for (s in intArrayOf(-1, 1)) circle(-3.0, s * (W / 2 + 1.5), 0.6)               // gantry poles
        hasWarehouse = free(-40.0, -20.0)
        if (hasWarehouse) for (lx in doubleArrayOf(-47.0, -40.0, -33.0)) circle(lx, -20.0, 7.4)
        val cs = ArrayList<DoubleArray>()
        val spots = arrayOf(doubleArrayOf(-18.0, 20.0, 0.0), doubleArrayOf(-18.0, 24.0, 0.0), doubleArrayOf(-26.0, 20.0, 1.0), doubleArrayOf(-26.0, 24.0, 0.0),
            doubleArrayOf(-12.0, -24.0, 0.0), doubleArrayOf(-12.0, -28.0, 1.0), doubleArrayOf(-34.0, 22.0, 0.0), doubleArrayOf(-4.0, 24.0, 0.0))
        spots.forEachIndexed { i, s -> if (free(s[0], s[1])) { cs.add(doubleArrayOf(s[0], s[1], s[2], i.toDouble())); circle(s[0], s[1], 3.3) } }
        containers = cs; obst = o.toDoubleArray()
    }

    /** pier-local coordinates of a world point (thread safe: no shared scratch like the JS _plx / _plz) */
    fun lx(x: Double, z: Double) = (x - x0) * dx + (z - z0) * dz
    fun lz(x: Double, z: Double) = -(x - x0) * dz + (z - z0) * dx
    fun worldX(lx: Double, lz: Double) = x0 + dx * lx - dz * lz
    fun worldZ(lx: Double, lz: Double) = z0 + dz * lx + dx * lz
    /** rotation about +Y (degrees, Three.js convention) that takes the pier-local frame to world space */
    val yawRad: Double get() = atan2(-dz, dx)

    fun halfW(lx: Double) = if (lx > L - HL) HW / 2 else W / 2
    /** JS nearPier(x,z,m) */
    fun near(x: Double, z: Double, m: Double = 0.0): Boolean {
        val a = lx(x, z); return a > -64 - m && a < L + 34 + m && abs(lz(x, z)) < 48 + m
    }
    /** JS fieldMask term: distance (m) outside the flattened pier box, 0 inside */
    fun flatDist(x: Double, z: Double): Double {
        val a = lx(x, z); val b = lz(x, z)
        val ddx = max(max(-64 - a, a - (L + 34)), 0.0); val ddz = max(abs(b) - 48, 0.0)
        return hypot(ddx, ddz)
    }

    /** solid yard obstacles (JS roadObstacles entries added by the pier code); true if the car hit one */
    fun collide(c: CarState): Boolean {
        var k = 0
        while (k < obst.size) {
            val ox = obst[k]; val oz = obst[k + 1]; val r = obst[k + 2] + CAR_R
            val ex = c.x - ox; val ez = c.z - oz
            if (ex * ex + ez * ez < r * r) {
                val d = sqrt(ex * ex + ez * ez).let { if (it == 0.0) 0.001 else it }; val nx = ex / d; val nz = ez / d
                c.x = ox + nx * r; c.z = oz + nz * r
                Collision.bounceOff(c, nx, nz, 0.22, 0.18)
                if (Collision.cooldown <= 0) { Collision.cooldown = 0.6; Collision.hits++; Collision.thuds++ }
                return true
            }
            k += 3
        }
        return false
    }

    /** pier rails + end rail (JS coastGuard pier branch). Returns true when the car is on / next to the pier (the sea wall must not apply). */
    fun guard(c: CarState): Boolean {
        val a = lx(c.x, c.z); val b = lz(c.x, c.z); val hw = halfW(a)
        if (a > 10 && a < L + 6 && abs(b) < hw + 3.5) {
            val lim = hw - 1.15; var dl = 0.0; var dn = 0.0
            if (abs(b) > lim) dl = sign(b) * lim - b
            if (a > L - 1.8) dn = (L - 1.8) - a
            if (dl != 0.0 || dn != 0.0) {
                c.x += dn * dx - dl * dz; c.z += dn * dz + dl * dx
                val k = 0.96; c.speed *= k; c.vy *= k; c.yaw *= sqrt(k)
            }
            return true
        }
        return false
    }

    fun update(c: CarState) {
        val a = lx(c.x, c.z); val b = lz(c.x, c.z)
        onPier = a > 12 && a < L && abs(b) < HW / 2
    }
}
