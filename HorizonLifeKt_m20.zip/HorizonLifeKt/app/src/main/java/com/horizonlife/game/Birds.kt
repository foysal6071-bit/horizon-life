package com.horizonlife.game

import kotlin.math.*
import kotlin.random.Random

/** Port of the JS bird flocks (BSP / mkFlock / respawn / updateBirds). The result is a flat instance array per species for gl/BirdRenderer. */
object Birds {
    class Sp(val name: String, val vis: Float, val span: Float, val bl: Float, val br: Float, val nk: Float, val tl: Float, val tw: Float, val cr: Float, val ct: Float, val sw: Float,
             val back: FloatArray, val belly: FloatArray, val wing: FloatArray, val tip: FloatArray, val head: FloatArray,
             val hz: Float, val spd: Float, val amp: Float, val alt0: Float, val alt1: Float, val count: Int)

    val species = listOf(
        Sp("goose", 1.4f, 1.5f, .75f, .075f, .45f, .16f, .12f, .27f, .10f, .35f, f(.30, .26, .22), f(.78, .74, .68), f(.34, .29, .24), f(.08, .08, .08), f(.05, .05, .05), 2.7f, 15f, .85f, 60f, 130f, 16),
        Sp("gull", 1.4f, 1.2f, .5f, .055f, .08f, .13f, .10f, .17f, .06f, .5f, f(.88, .88, .9), f(.97, .97, .97), f(.72, .74, .78), f(.05, .05, .06), f(.95, .95, .95), 3.3f, 9f, .75f, 35f, 90f, 6),
        Sp("small", 1.8f, .38f, .2f, .03f, .02f, .08f, .05f, .09f, .045f, .2f, f(.07, .07, .08), f(.13, .13, .14), f(.08, .08, .09), f(.04, .04, .05), f(.05, .05, .06), 11f, 13f, 1f, 30f, 80f, 28),
        Sp("raptor", 1.4f, 1.9f, .7f, .08f, .06f, .3f, .2f, .38f, .24f, .15f, f(.33, .22, .12), f(.55, .42, .28), f(.30, .20, .11), f(.08, .06, .05), f(.78, .72, .6), 2.2f, 10f, .5f, 70f, 130f, 3)
    )
    private fun f(a: Double, b: Double, c: Double) = floatArrayOf(a.toFloat(), b.toFloat(), c.toFloat())

    const val F = 10   // floats per instance: pos3, yaw/pitch/bank 3, scale/phase/amp 3, tint 1

    private class Bird(val ph: Double, var flap: Double, val rate: Double, val th0: Double, val r: Double) {
        var px = 0.0; var py = 0.0; var pz = 0.0; var vx = 0.0; var vy = 0.0; var vz = 0.0
        var yaw = 0.0; var yr = 0.0; var bank = 0.0; var amp = 0.0; var init = false; var th = th0
        var slot = DoubleArray(3); var w = DoubleArray(3); var a = DoubleArray(3); var tint = 1f
    }
    private class Flock(val sp: Int, val type: Char, val keep: Boolean, val fph: Double) {
        var x = 0.0; var y = 0.0; var z = 0.0; var cx = 0.0; var cy = 0.0; var cz = 0.0
        var hdg = 0.0; var turn = 0.0; var tgt = 0.0; var tt = 0.0; var alt = 80.0; var hid = false
        val birds = ArrayList<Bird>()
    }

    private val flocks = ArrayList<Flock>()
    private val rnd = Random(20260)
    /** per species: instance data + number of visible birds (read by BirdRenderer on the GL thread, same thread as update) */
    val data = Array(species.size) { FloatArray(species[it].count * F) }
    val count = IntArray(species.size)
    private var t = 0.0
    private var ready = false

    private fun mk(sp: Int, type: Char, n: Int, keep: Boolean = false) {
        val s = species[sp]; val f = Flock(sp, type, keep, rnd.nextDouble() * 6.28)
        for (k in 0 until n) {
            val b = Bird(rnd.nextDouble() * 6.28, rnd.nextDouble() * 6.28, 6.2832 * s.hz * (.92 + rnd.nextDouble() * .16), rnd.nextDouble() * 6.28, 38 + rnd.nextDouble() * 30)
            b.tint = (.85 + rnd.nextDouble() * .3).toFloat()
            if (type == 'v') {
                val side = if (k % 2 == 1) 1 else -1; val rank = ceil(k / 2.0)
                b.slot = doubleArrayOf(if (k > 0) side * rank * 3.6 else 0.0, 0.0, -rank * 3.2); b.a = doubleArrayOf(.4, .35, .4)
                b.w = doubleArrayOf(.7 + rnd.nextDouble(), .9 + rnd.nextDouble(), .6 + rnd.nextDouble())
            } else {
                val sc = if (s.name == "gull") 1.8 else 1.0
                b.a = doubleArrayOf((4 + rnd.nextDouble() * 3) * sc, (1.5 + rnd.nextDouble() * 1.5) * sc, (5 + rnd.nextDouble() * 3) * sc)
                b.w = doubleArrayOf(.25 + rnd.nextDouble() * .45, .3 + rnd.nextDouble() * .4, .25 + rnd.nextDouble() * .45)
            }
            f.birds.add(b)
        }
        flocks.add(f)
    }

    private fun respawn(f: Flock, car: CarState, init: Boolean) {
        val s = species[f.sp]
        val a = if (init) rnd.nextDouble() * 6.283 else car.heading + (rnd.nextDouble() - .5) * 3.2
        val d = if (init) 80 + rnd.nextDouble() * 250 else 300 + rnd.nextDouble() * 130
        f.x = car.x + sin(a) * d; f.y = s.alt0 + rnd.nextDouble() * (s.alt1 - s.alt0); f.z = car.z + cos(a) * d
        f.alt = f.y; f.hdg = atan2(car.x - f.x, car.z - f.z) + (rnd.nextDouble() - .5) * 1.6
        f.cx = f.x; f.cy = f.y; f.cz = f.z; f.hid = false
        for (b in f.birds) b.init = false
    }

    private fun ss(a: Double, b: Double, x: Double): Double { val u = min(1.0, max(0.0, (x - a) / (b - a))); return u * u * (3 - 2 * u) }
    private fun wrapPi(d: Double) = ((d + PI) % (PI * 2) + PI * 2) % (PI * 2) - PI

    private fun setup(car: CarState) {
        mk(0, 'v', 9, true); mk(0, 'v', 7); mk(1, 'l', 6); mk(2, 'l', 16); mk(2, 'l', 12); mk(3, 'o', 1); mk(3, 'o', 2)
        for (f in flocks) respawn(f, car, true)
        ready = true
    }

    /** sunElev = true sun height (Environment.skySun[1]); maxFlocks = Settings.flocks (JS QUAL.flocks) */
    fun update(car: CarState, dtIn: Double, sunElev: Double, maxFlocks: Int) {
        if (!ready) setup(car)
        val dt = max(dtIn, 1e-4); t += dt
        val act = ss(-.12, .08, sunElev)
        val fill = IntArray(species.size); var fi = 0
        for (f in flocks) {
            val s = species[f.sp]
            val on = (f.keep || act > .5) && (fi++ < maxFlocks)
            if (f.hid && on) respawn(f, car, false)
            if (f.hid) continue
            if (f.type == 'o') {
                if (on) { f.cx += sin(f.fph) * 2 * dt; f.cz += cos(f.fph) * 2 * dt }
                else { val ox = f.cx - car.x; val oz = f.cz - car.z; val l = hypot(ox, oz).let { if (it == 0.0) 1.0 else it }; f.cx += ox / l * 12 * dt; f.cz += oz / l * 12 * dt }
                f.cy = f.alt + sin(t * .2 + f.fph) * 6; f.x = f.cx; f.y = f.cy; f.z = f.cz
            } else {
                f.tt -= dt; if (f.tt < 0) { f.tt = 2 + rnd.nextDouble() * 5; f.tgt = (rnd.nextDouble() - .5) * .5 }
                f.turn += (f.tgt - f.turn) * dt * .8; f.hdg += f.turn * dt
                f.x += sin(f.hdg) * s.spd * dt; f.z += cos(f.hdg) * s.spd * dt; f.y = f.alt + sin(t * .1 + f.fph) * 8
            }
            val dx = f.x - car.x; val dz = f.z - car.z
            if (dx * dx + dz * dz > 470 * 470) { if (on) respawn(f, car, false) else { f.hid = true; continue } }
            val ch = cos(f.hdg); val sh = sin(f.hdg)
            for (b in f.birds) {
                val nx: Double; val ny: Double; val nz: Double
                if (f.type == 'o') {
                    b.th += s.spd / b.r * dt
                    nx = f.cx + cos(b.th) * b.r; ny = f.cy + sin(t * .3 + b.ph) * 3; nz = f.cz + sin(b.th) * b.r
                } else {
                    val sx = b.slot[0] + sin(t * b.w[0] + b.ph) * b.a[0]; val sy = b.slot[1] + sin(t * b.w[1] + b.ph * 2) * b.a[1]; val sz = b.slot[2] + sin(t * b.w[2] + b.ph * 3) * b.a[2]
                    nx = f.x + sx * ch + sz * sh; ny = f.y + sy; nz = f.z - sx * sh + sz * ch
                }
                if (!b.init) { b.init = true; b.px = nx; b.py = ny; b.pz = nz; b.vx = sin(f.hdg) * s.spd; b.vy = 0.0; b.vz = cos(f.hdg) * s.spd; b.yaw = f.hdg; b.yr = 0.0 }
                val k = 1 - exp(-5 * dt)
                b.vx += ((nx - b.px) / dt - b.vx) * k; b.vy += ((ny - b.py) / dt - b.vy) * k; b.vz += ((nz - b.pz) / dt - b.vz) * k
                b.px = nx; b.py = ny; b.pz = nz
                val len = max(sqrt(b.vx * b.vx + b.vy * b.vy + b.vz * b.vz), .1)
                val yaw = atan2(b.vx, b.vz); val pit = asin((b.vy / len).coerceIn(-1.0, 1.0))
                b.yr += (wrapPi(yaw - b.yaw) / dt - b.yr) * (1 - exp(-4 * dt)); b.yaw = yaw
                val bk = (atan(len * b.yr / 9.8) * 1.8).coerceIn(-.75, .75); b.bank += (bk - b.bank) * (1 - exp(-3 * dt))
                val env = when {
                    f.type == 'v' -> .85 + .15 * sin(t * .5 + f.fph)
                    f.type == 'o' -> .1 + .9 * ss(.8, .95, sin(t * .22 + b.ph))
                    s.name == "gull" -> .1 + .9 * ss(-.1, .5, sin(t * .5 + f.fph))
                    else -> .12 + .88 * ss(-.3, .4, sin(t * 1.7 + f.fph + b.ph * .15))
                }
                b.amp += (s.amp * env - b.amp) * (1 - exp(-4 * dt)); b.flap += b.rate * dt * (.6 + .4 * env)
                val arr = data[f.sp]; val o = fill[f.sp]++ * F
                if (o + F > arr.size) { fill[f.sp]--; continue }
                arr[o] = b.px.toFloat(); arr[o + 1] = b.py.toFloat(); arr[o + 2] = b.pz.toFloat()
                arr[o + 3] = yaw.toFloat(); arr[o + 4] = (-pit).toFloat(); arr[o + 5] = (-b.bank).toFloat()
                arr[o + 6] = s.vis; arr[o + 7] = (b.flap % 6.2831853).toFloat(); arr[o + 8] = b.amp.toFloat(); arr[o + 9] = b.tint
            }
        }
        for (i in species.indices) count[i] = fill[i]
    }
}
