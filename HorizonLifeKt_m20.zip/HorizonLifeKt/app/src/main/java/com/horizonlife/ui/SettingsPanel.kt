package com.horizonlife.ui

import android.graphics.*
import android.view.MotionEvent
import com.horizonlife.game.EngineSound
import com.horizonlife.game.Game
import com.horizonlife.game.Settings
import kotlin.math.*

/**
 * Port of the JS Settings window (folder tabs on the left, rows on the right): Graphics, Sound, Camera, Regulation, HUD.
 * Drawn with Canvas on top of the GL view; it swallows every touch while open. Values live in [Settings] (persisted).
 */
class SettingsPanel(private val game: Game, private val onResolution: () -> Unit, private val onHudLayout: () -> Unit) {
    var open = false

    private sealed class Row(val label: String)
    private class Slider(l: String, val get: () -> Double, val set: (Double) -> Unit, val min: Double, val max: Double, val step: Double, val fmt: (Double) -> String) : Row(l)
    private class Seg(l: String, val opts: List<String>, val get: () -> Int, val set: (Int) -> Unit) : Row(l)
    private class Act(l: String, val text: String, val run: () -> Unit) : Row(l)

    private val tabs = listOf("Graphics", "Sound", "Camera", "Regulation", "Control", "HUD")
    private var tab = 0
    private var scroll = 0f

    private fun camChanged() = game.cam.applySettings(game.car, game.pose)
    private fun onOff(label: String, i: Int, after: () -> Unit = {}) =
        Seg(label, listOf("OFF", "ON"), { if (Settings.hudShow[i]) 1 else 0 }, { Settings.hudShow[i] = it == 1; after() })

    private val presets = doubleArrayOf(0.5, 0.65, 0.8, 1.0)
    private val rows: List<List<Row>> = listOf(
        listOf(
            Seg("Graphics", listOf("Super Smooth", "Smooth", "Medium", "High"),
                { presets.indexOfFirst { abs(it - Settings.resScale) < 0.02 } }, { Settings.resScale = presets[it]; onResolution()
                    Settings.flocks = intArrayOf(0, 2, 4, 7)[it]; Settings.treeMax = intArrayOf(10, 20, 30, 40)[it]; Settings.renderDist = doubleArrayOf(380.0, 500.0, 640.0, 770.0)[it] }),
            Slider("Resolution", { Settings.resScale }, { Settings.resScale = it; onResolution() }, 0.3, 1.0, 0.01, { "${(it * 100).roundToInt()}%" }),
            Slider("Render distance", { Settings.renderDist }, { Settings.renderDist = it }, 380.0, 770.0, 10.0, { "${it.roundToInt()} m" }),
            Slider("Tree detail count", { Settings.treeMax.toDouble() }, { Settings.treeMax = it.roundToInt() }, 10.0, 40.0, 1.0, { it.roundToInt().toString() }),
            Slider("Bird flocks", { Settings.flocks.toDouble() }, { Settings.flocks = it.roundToInt() }, 0.0, 7.0, 1.0, { it.roundToInt().toString() })
        ),
        listOf(
            Slider("Master volume", { Settings.vol }, { Settings.vol = it; EngineSound.vol = it }, 0.0, 1.0, 0.05, { "${(it * 100).roundToInt()}%" }),
            Seg("Game sound", listOf("ON", "MUTED"), { if (EngineSound.muted) 1 else 0 }, { EngineSound.muted = it == 1 })
        ),
        listOf(
            Seg("Camera view", Settings.CamMode.values().map { it.label }, { Settings.camMode.ordinal },
                { Settings.camMode = Settings.CamMode.values()[it]; camChanged(); game.showToast(Settings.camMode.label) }),
            Slider("Camera distance", { Settings.camDist }, { Settings.camDist = it; camChanged() }, 3.5, 14.0, 0.1, { "%.1f m".format(it) }),
            Slider("Camera height", { Settings.camPitch }, { Settings.camPitch = it; camChanged() }, 0.05, 0.8, 0.01, { "%.2f".format(it) }),
            Slider("Sky view (look up)", { Settings.sky }, { Settings.sky = it }, 0.0, 4.0, 0.1, { "%.1f".format(it) }),
            Slider("Field of view", { Settings.fov }, { Settings.fov = it }, 50.0, 85.0, 1.0, { "${it.roundToInt()}°" }),
            Act("Defaults", "Reset camera") { Settings.camReset(); camChanged() }
        ),
        listOf(
            Slider("Speed FOV effect", { Settings.speedFov }, { Settings.speedFov = it }, 0.0, 20.0, 1.0, { it.roundToInt().toString() }),
            Slider("Camera shake", { Settings.shake }, { Settings.shake = it }, 0.0, 1.0, 0.05, { "${(it * 100).roundToInt()}%" })
        ),
        listOf(
            Seg("Steering control", listOf("Buttons", "Wheel"), { if (Settings.ctrlWheel) 1 else 0 },
                { Settings.ctrlWheel = it == 1; game.showToast(if (it == 1) "Steering: wheel" else "Steering: buttons") }),
            Slider("Steering sensitivity", { Settings.steerSens }, { Settings.steerSens = it }, 0.6, 3.0, 0.05, { "%.2f".format(it) })
        ),
        listOf(
            onOff("Minimap", 0), onOff("Speed", 1), onOff("FPS", 2), onOff("Buttons", 3),
            Slider("HUD size", { Settings.hudScale }, { Settings.hudScale = it; onHudLayout() }, 0.7, 1.3, 0.05, { "${(it * 100).roundToInt()}%" }),
            Slider("HUD opacity", { Settings.hudAlpha }, { Settings.hudAlpha = it }, 0.3, 1.0, 0.05, { "${(it * 100).roundToInt()}%" }),
            Act("Layout", "Reset HUD") { Settings.hudReset(); onHudLayout() }
        )
    )

    // ---- geometry (recomputed every draw) ----
    private val panel = RectF(); private var navW = 0f; private var rowH = 0f; private var d = 1f
    private val doneR = RectF()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG); private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; typeface = Typeface.DEFAULT_BOLD }

    private fun layout(w: Int, h: Int, dens: Float) {
        d = dens
        val pw = min(w * 0.96f, 680f * d); val ph = min(h * 0.94f, 400f * d)
        panel.set((w - pw) / 2, (h - ph) / 2, (w + pw) / 2, (h + ph) / 2)
        navW = min(124f * d, pw * 0.26f); rowH = 54f * d
        doneR.set(panel.left + 10f * d, panel.bottom - 46f * d, panel.left + navW - 10f * d, panel.bottom - 10f * d)
    }
    private fun paneL() = panel.left + navW + 16f * d
    private fun paneR() = panel.right - 16f * d
    private fun paneTop() = panel.top + 52f * d
    private fun ctlL() = paneL() + (paneR() - paneL()) * 0.40f
    private fun maxScroll() = max(0f, rows[tab].size * rowH - (panel.bottom - paneTop() - 8f * d))
    private fun rowTop(i: Int) = paneTop() + i * rowH - scroll

    fun draw(c: Canvas, w: Int, h: Int, dens: Float) {
        layout(w, h, dens)
        fill.color = 0x73000000; c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), fill)
        fill.color = 0xF0141A24.toInt(); c.drawRoundRect(panel, 18f * d, 18f * d, fill)
        line.strokeWidth = 1.5f * d; line.color = 0x55FFFFFF; c.drawRoundRect(panel, 18f * d, 18f * d, line)
        line.color = 0x30FFFFFF; c.drawLine(panel.left + navW, panel.top + 12f * d, panel.left + navW, panel.bottom - 12f * d, line)
        // tabs
        txt.textAlign = Paint.Align.LEFT; txt.textSize = 13f * d
        for (i in tabs.indices) {
            val r = RectF(panel.left + 8f * d, panel.top + 14f * d + i * 40f * d, panel.left + navW - 8f * d, panel.top + 14f * d + i * 40f * d + 34f * d)
            if (i == tab) { fill.color = 0x2EFFFFFF; c.drawRoundRect(r, 10f * d, 10f * d, fill); line.color = 0x80FFFFFF.toInt(); c.drawRoundRect(r, 10f * d, 10f * d, line) }
            txt.alpha = if (i == tab) 255 else 190; c.drawText(tabs[i], r.left + 12f * d, r.centerY() + 4.5f * d, txt)
        }
        txt.alpha = 255
        fill.color = 0xEBFFFFFF.toInt(); c.drawRoundRect(doneR, 12f * d, 12f * d, fill)
        txt.color = 0xFF111111.toInt(); txt.textAlign = Paint.Align.CENTER; c.drawText("DONE", doneR.centerX(), doneR.centerY() + 4.5f * d, txt); txt.color = Color.WHITE
        // header
        txt.textAlign = Paint.Align.LEFT; txt.textSize = 20f * d; c.drawText(tabs[tab], paneL(), panel.top + 34f * d, txt)
        line.color = 0x2EFFFFFF; c.drawLine(paneL(), panel.top + 44f * d, paneR(), panel.top + 44f * d, line)
        // rows (clipped to the pane)
        c.save(); c.clipRect(paneL() - 4f * d, paneTop(), paneR() + 4f * d, panel.bottom - 6f * d)
        for ((i, row) in rows[tab].withIndex()) {
            val y = rowTop(i); if (y + rowH < paneTop() || y > panel.bottom) continue
            val cy = y + rowH / 2
            txt.textAlign = Paint.Align.LEFT; txt.textSize = 13f * d; txt.alpha = 235; c.drawText(row.label, paneL(), cy + 4.5f * d, txt); txt.alpha = 255
            when (row) {
                is Slider -> {
                    val tl = ctlL(); val tr = paneR() - 52f * d; val t = ((row.get() - row.min) / (row.max - row.min)).toFloat().coerceIn(0f, 1f)
                    fill.color = 0x40FFFFFF; c.drawRoundRect(tl, cy - 2.5f * d, tr, cy + 2.5f * d, 3f * d, 3f * d, fill)
                    fill.color = 0xFFFFFFFF.toInt(); c.drawRoundRect(tl, cy - 2.5f * d, tl + (tr - tl) * t, cy + 2.5f * d, 3f * d, 3f * d, fill)
                    c.drawCircle(tl + (tr - tl) * t, cy, 9f * d, fill)
                    txt.textAlign = Paint.Align.RIGHT; txt.textSize = 12f * d; c.drawText(row.fmt(row.get()), paneR(), cy + 4f * d, txt)
                }
                is Seg -> {
                    val n = row.opts.size; val cw = (paneR() - ctlL()) / n; val sel = row.get()
                    txt.textAlign = Paint.Align.CENTER; txt.textSize = (if (n > 3) 10.5f else 12f) * d
                    for (k in 0 until n) {
                        val r = RectF(ctlL() + k * cw + 2f * d, cy - 17f * d, ctlL() + (k + 1) * cw - 2f * d, cy + 17f * d)
                        fill.color = if (k == sel) 0xEBFFFFFF.toInt() else 0x26FFFFFF; c.drawRoundRect(r, 10f * d, 10f * d, fill)
                        txt.color = if (k == sel) 0xFF111111.toInt() else Color.WHITE; c.drawText(row.opts[k], r.centerX(), r.centerY() + 4f * d, txt)
                    }
                    txt.color = Color.WHITE
                }
                is Act -> {
                    val r = RectF(ctlL() + 2f * d, cy - 17f * d, paneR() - 2f * d, cy + 17f * d)
                    fill.color = 0x26FFFFFF; c.drawRoundRect(r, 10f * d, 10f * d, fill)
                    txt.textAlign = Paint.Align.CENTER; txt.textSize = 12f * d; c.drawText(row.text, r.centerX(), r.centerY() + 4f * d, txt)
                }
            }
            line.color = 0x1FFFFFFF; c.drawLine(paneL(), y + rowH, paneR(), y + rowH, line)
        }
        c.restore()
        txt.textAlign = Paint.Align.CENTER
    }

    // ---- touch ----
    private var activeSlider: Slider? = null
    private var dragY = 0f; private var moved = false; private var downRow = -1

    private fun setSlider(s: Slider, x: Float) {
        val tl = ctlL(); val tr = paneR() - 52f * d
        val t = ((x - tl) / (tr - tl)).coerceIn(0f, 1f); var v = s.min + (s.max - s.min) * t
        v = (s.min + ((v - s.min) / s.step).roundToInt() * s.step).coerceIn(s.min, s.max); s.set(v)
    }

    private fun rowAt(y: Float): Int { if (y < paneTop() || y > panel.bottom) return -1; val i = ((y - paneTop() + scroll) / rowH).toInt(); return if (i in rows[tab].indices) i else -1 }

    /** returns true (the panel swallows all touches while open) */
    fun touch(e: MotionEvent): Boolean {
        val x = e.x; val y = e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                moved = false; dragY = y; activeSlider = null; downRow = -1
                if (!panel.contains(x, y)) { close(); return true }
                if (doneR.contains(x, y)) { close(); return true }
                for (i in tabs.indices) {
                    val ty = panel.top + 14f * d + i * 40f * d
                    if (x < panel.left + navW && y in ty..(ty + 34f * d)) { tab = i; scroll = 0f; return true }
                }
                val i = rowAt(y)
                if (i >= 0 && x > ctlL() - 8f * d) {
                    downRow = i
                    when (val r = rows[tab][i]) {
                        is Slider -> { activeSlider = r; setSlider(r, x) }
                        is Seg -> { val k = ((x - ctlL()) / ((paneR() - ctlL()) / r.opts.size)).toInt().coerceIn(0, r.opts.size - 1); r.set(k); Settings.save() }
                        is Act -> { r.run() }
                    }
                }
            }
            MotionEvent.ACTION_MOVE -> {
                val s = activeSlider
                if (s != null) setSlider(s, x)
                else if (downRow < 0 || abs(y - dragY) > 6f * d) { scroll = (scroll - (y - dragY)).coerceIn(0f, maxScroll()); dragY = y; moved = true }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { if (activeSlider != null) Settings.save(); activeSlider = null }
        }
        return true
    }

    private fun close() { open = false; Settings.save() }
}
