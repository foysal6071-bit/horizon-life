package com.horizonlife.gl

import android.content.Context
import android.opengl.GLES30
import android.opengl.Matrix
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.*

/**
 * Audi R8 (46k verts / 51k tris) decoded from the JS blobs (assets/r8.bin + r8_meta.json).
 * Bin layout: n*3 uint16 positions, n*4 int8 normals, ni uint16 indices.  Game frame: nose +Z, left +X, up +Y,
 * axle mid-point at the origin, tyres touching y = 0.   Neon underglow is skipped (the JS version removed it too).
 */
class R8Model(ctx: Context) {
    private class Mat(val color: FloatArray, val gloss: Float, val alpha: Float, val emis: Float)
    private class Part(val start: Int, val count: Int, val mat: Mat, val wheel: Int, val spinning: Boolean)

    private val parts = ArrayList<Part>()
    private val centre = Array(4) { FloatArray(3) }       // wheel centres, game order: front L/R, rear L/R
    private val rawOrder = intArrayOf(0, 2, 1, 3)           // game wheel k -> raw wheel index
    private var vao = 0
    private val tailMats = ArrayList<Mat>()
    private val tint = FloatArray(3)

    companion object {
        const val WH0 = 54432; const val WHN = 24570; const val NEON0 = 152712
        private const val S = 2.8 / 2643.1; private const val ZC = -104.45
        private fun hex(h: String, k: Int) = (h.substring(1 + k * 2, 3 + k * 2).toInt(16) / 255f)
    }

    init {
        val bin = ctx.assets.open("r8.bin").use { it.readBytes() }
        val meta = JSONObject(ctx.assets.open("r8_meta.json").use { String(it.readBytes()) })
        val n = meta.getInt("n"); val ni = meta.getInt("ni")
        val mn = meta.getJSONArray("mn"); val sz = meta.getJSONArray("sz")
        val bb = ByteBuffer.wrap(bin).order(ByteOrder.LITTLE_ENDIAN)
        val vert = FloatArray(n * 6)
        for (i in 0 until n) {
            val u = bb.getShort(i * 6).toInt() and 0xffff; val v = bb.getShort(i * 6 + 2).toInt() and 0xffff; val w = bb.getShort(i * 6 + 4).toInt() and 0xffff
            val rx = mn.getDouble(0) + u / 65535.0 * sz.getDouble(0); val ry = mn.getDouble(1) + v / 65535.0 * sz.getDouble(1)
            val rz = mn.getDouble(2) + w / 65535.0 * sz.getDouble(2)
            vert[i * 6] = (rx * S).toFloat(); vert[i * 6 + 1] = (ry * S).toFloat(); vert[i * 6 + 2] = ((rz - ZC) * S).toFloat()
            val nx = bin[n * 6 + i * 4] / 127f; val ny = bin[n * 6 + i * 4 + 1] / 127f; val nz = bin[n * 6 + i * 4 + 2] / 127f
            val l = sqrt(nx * nx + ny * ny + nz * nz).let { if (it == 0f) 1f else it }
            vert[i * 6 + 3] = nx / l; vert[i * 6 + 4] = ny / l; vert[i * 6 + 5] = nz / l
        }
        val idx = ShortArray(ni) { bb.getShort(n * 10 + it * 2) }
        // wheel centres from the bounding boxes of each raw wheel's index range
        for (k in 0..3) {
            val wi = rawOrder[k]; val lo = FloatArray(3) { 1e9f }; val hi = FloatArray(3) { -1e9f }
            for (q in WH0 + wi * WHN until WH0 + (wi + 1) * WHN) {
                val v = idx[q].toInt() and 0xffff
                for (a in 0..2) { lo[a] = min(lo[a], vert[v * 6 + a]); hi[a] = max(hi[a], vert[v * 6 + a]) }
            }
            for (a in 0..2) centre[k][a] = (lo[a] + hi[a]) / 2
        }
        // groups -> parts
        val groups = meta.getJSONArray("groups"); val cache = HashMap<String, Mat>()
        for (gi in 0 until groups.length()) {
            val g = groups.getJSONArray(gi)
            val name = g.getString(0); val start = g.getInt(2); val count = g.getInt(3); val col = g.getString(4)
            val em = g.getInt(6); val a = g.getDouble(7).toFloat()
            if (count == 0 || em == 2 || start >= NEON0) continue
            var wheel = -1; var spinning = false
            if (start >= WH0) {
                val wi = (start - WH0) / WHN; val off = start - WH0 - wi * WHN
                wheel = rawOrder.indexOf(wi); spinning = !(off in 666 until 1944)
            }
            val key = "$name|$col|$em|$a"
            val mat = cache.getOrPut(key) {
                var c = floatArrayOf(hex(col, 0), hex(col, 1), hex(col, 2)); var gloss = 0.3f; var alpha = 1f; var emis = 0f
                if (em == 1) { emis = 1f; c = if (name == "light") floatArrayOf(0.95f, 0.98f, 1f) else floatArrayOf(1f, 0.16f, 0.16f) }
                else if (a < 1) { alpha = min(0.9f, a * 1.5f); gloss = 1f }
                else gloss = when (name) {
                    "body_color" -> 0.9f; "black_gloss", "trim" -> 0.7f; "chrome", "rims_1" -> 1f
                    "Aluminium_1", "Aluminum_2" -> 0.6f; "tyre" -> 0.03f; "interior_1", "interior_2", "interior_roof" -> 0.08f
                    "black_matt", "tail_light_red_2", "tail_light_red_3", "grille" -> 0.35f; else -> 0.3f
                }
                Mat(c, gloss, alpha, emis).also { if (em == 1 && name != "light") tailMats.add(it) }
            }
            parts.add(Part(start, count, mat, wheel, spinning))
        }
        parts.sortBy { it.mat.alpha < 1f }      // opaque first, glass last

        val ids = IntArray(1)
        GLES30.glGenVertexArrays(1, ids, 0); vao = ids[0]; GLES30.glBindVertexArray(vao)
        val vb = IntArray(1); GLES30.glGenBuffers(1, vb, 0); GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vb[0])
        val fb = ByteBuffer.allocateDirect(vert.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(vert).also { it.position(0) }
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, vert.size * 4, fb, GLES30.GL_STATIC_DRAW)
        GLES30.glEnableVertexAttribArray(0); GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 24, 0)
        GLES30.glEnableVertexAttribArray(1); GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 24, 12)
        val eb = IntArray(1); GLES30.glGenBuffers(1, eb, 0); GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, eb[0])
        val sb = ByteBuffer.allocateDirect(ni * 2).order(ByteOrder.nativeOrder()).asShortBuffer().put(idx).also { it.position(0) }
        GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, ni * 2, sb, GLES30.GL_STATIC_DRAW)
        GLES30.glBindVertexArray(0)
    }

    /**
     * @param base car rig matrix (position + heading + roll/pitch). Program must already be in use with uVP/uSun/uCam/uFog set.
     * @param loc uniform-location lookup for the mesh program.
     */
    fun draw(base: FloatArray, steerDeg: Float, spinDeg: Float, brake: Float, wheelDy: FloatArray, mudLvl: DoubleArray, mudDry: DoubleArray, loc: (String) -> Int) {
        val m = FloatArray(16); GLES30.glBindVertexArray(vao); GLES30.glDisable(GLES30.GL_CULL_FACE)
        var glass = false
        for (p in parts) {
            if (p.mat.alpha < 1f && !glass) { glass = true; GLES30.glEnable(GLES30.GL_BLEND); GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA); GLES30.glDepthMask(false) }
            System.arraycopy(base, 0, m, 0, 16)
            if (p.wheel >= 0) {
                val c = centre[p.wheel]
                Matrix.translateM(m, 0, 0f, wheelDy[p.wheel], 0f)          // pothole travel
                Matrix.translateM(m, 0, c[0], c[1], c[2])
                if (p.wheel < 2) Matrix.rotateM(m, 0, steerDeg, 0f, 1f, 0f)
                if (p.spinning) Matrix.rotateM(m, 0, spinDeg, 1f, 0f, 0f)
                Matrix.translateM(m, 0, -c[0], -c[1], -c[2])
            }
            GLES30.glUniformMatrix4fv(loc("uM"), 1, false, m, 0)
            if (p.wheel >= 0 && mudLvl[p.wheel] > 0.01) {          // mud caked on the tyre / rim (JS TYRE_MUD, simplified to a colour blend)
                val L = (mudLvl[p.wheel] * 0.85).toFloat(); val dd = mudDry[p.wheel].toFloat()
                tint[0] = p.mat.color[0] + ((0.040f + 0.16f * dd) - p.mat.color[0]) * L; tint[1] = p.mat.color[1] + ((0.026f + 0.109f * dd) - p.mat.color[1]) * L
                tint[2] = p.mat.color[2] + ((0.016f + 0.064f * dd) - p.mat.color[2]) * L
                GLES30.glUniform3fv(loc("uColor"), 1, tint, 0); GLES30.glUniform1f(loc("uGloss"), p.mat.gloss * (1 - L * 0.8f))
            } else { GLES30.glUniform3fv(loc("uColor"), 1, p.mat.color, 0); GLES30.glUniform1f(loc("uGloss"), p.mat.gloss) }
            GLES30.glUniform1f(loc("uAlpha"), p.mat.alpha)
            GLES30.glUniform1f(loc("uEmis"), if (p.mat.emis > 0f && p.mat in tailMats) 0.55f + 0.45f * brake else p.mat.emis)
            GLES30.glDrawElements(GLES30.GL_TRIANGLES, p.count, GLES30.GL_UNSIGNED_SHORT, p.start * 2)
        }
        if (glass) { GLES30.glDepthMask(true); GLES30.glDisable(GLES30.GL_BLEND) }
        GLES30.glEnable(GLES30.GL_CULL_FACE); GLES30.glBindVertexArray(0)
    }
}
