package com.horizonlife.game

import kotlin.math.*
import kotlin.random.Random

/**
 * Port of the JS tyre smoke (updateSmoke): one pool of 110 soft puffs that rise, grow and fade. Emitted at the wheels while braking hard / drifting
 * (intensity = Marks.smoke[w]; rolling wheels in mud do not smoke). Layout per puff = GL vertex: x y z size alpha.
 */
object Smoke {
    const val N = 110; const val VF = 5
    val data = FloatArray(N * VF)
    private val vel = FloatArray(N * 3); private val age = FloatArray(N) { 9f }; private val life = FloatArray(N) { 1f }
    private val s0 = FloatArray(N); private val a0 = FloatArray(N)
    private var head = 0; private val acc = DoubleArray(4)
    private val rnd = Random.Default
    init { for (i in 0 until N) data[i * VF + 1] = -100f }

    /** y = height of the smoke emitter (car body y + 0.12) */
    fun update(S: CarState, dt: Double, y: Double) {
        val sH = sin(S.heading); val cH = cos(S.heading)
        val vwx = S.speed * sH + S.vy * cH; val vwz = S.speed * cH - S.vy * sH
        val slip = min(abs(S.vy) / 2.2, 1.0)
        for (w in 0..3) {
            val it = Marks.smoke[w]
            if (it < 0.06) { acc[w] = 0.0; continue }
            acc[w] += dt * (if (w >= 2) 46 * (0.4 + slip) else 20.0) * min(it * 1.4, 1.0)
            val wx = S.x + sH * Mud.WHEEL_OFF[w][0] + cH * Mud.WHEEL_OFF[w][1]; val wz = S.z + cH * Mud.WHEEL_OFF[w][0] - sH * Mud.WHEEL_OFF[w][1]
            while (acc[w] >= 1) {
                acc[w] -= 1.0
                val i = head; head = (head + 1) % N
                data[i * VF] = (wx + (rnd.nextDouble() - 0.5) * 0.3).toFloat(); data[i * VF + 1] = y.toFloat(); data[i * VF + 2] = (wz + (rnd.nextDouble() - 0.5) * 0.3).toFloat()
                vel[i * 3] = (vwx * 0.22 + (rnd.nextDouble() - 0.5) * 1.2).toFloat(); vel[i * 3 + 1] = (0.5 + rnd.nextDouble() * 0.7).toFloat(); vel[i * 3 + 2] = (vwz * 0.22 + (rnd.nextDouble() - 0.5) * 1.2).toFloat()
                age[i] = 0f; life[i] = (0.9 + rnd.nextDouble() * 0.9).toFloat(); s0[i] = (0.55 + rnd.nextDouble() * 0.35).toFloat(); a0[i] = ((0.26 + 0.3 * it) * (0.8 + rnd.nextDouble() * 0.4)).toFloat()
            }
        }
        val dr = exp(-1.3 * dt).toFloat(); val dy = exp(-0.6 * dt).toFloat(); val d = dt.toFloat()
        for (i in 0 until N) {
            if (age[i] >= life[i]) { data[i * VF + 3] = 0f; data[i * VF + 4] = 0f; continue }
            age[i] += d; val k = age[i] / life[i]
            data[i * VF] += vel[i * 3] * d; data[i * VF + 1] += vel[i * 3 + 1] * d; data[i * VF + 2] += vel[i * 3 + 2] * d
            vel[i * 3] *= dr; vel[i * 3 + 2] *= dr; vel[i * 3 + 1] *= dy
            data[i * VF + 3] = s0[i] * (1 + age[i] * 1.8f)
            data[i * VF + 4] = a0[i] * (1 - min(k, 1f)).pow(1.3f) * min(age[i] * 7, 1f)
        }
    }
}
