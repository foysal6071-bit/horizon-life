package com.horizonlife.gl

import android.opengl.GLES30
import com.horizonlife.game.Birds
import com.horizonlife.game.Environment
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.*

/** Instanced birds (JS birdGeo + birdVS/FS): spindle body, neck/head, tail and two 6-segment wings flapped in the vertex shader. */
class BirdRenderer {
    private val prog = GlUtil.program(Shaders.BIRD_VS, Shaders.BIRD_FS)
    private val locs = HashMap<String, Int>()
    private fun u(n: String) = locs.getOrPut(n) { GLES30.glGetUniformLocation(prog, n) }

    private class Mesh(val vao: Int, val vbo: Int, val nIdx: Int, val L: Float, val rx: Float, val cpu: FloatBuffer)
    private val meshes = Birds.species.map { build(it) }

    private fun build(s: Birds.Sp): Mesh {
        val V = ArrayList<Float>(); val I = ArrayList<Int>(); var nv = 0
        fun push(p: FloatArray, n: FloatArray, a: Float, c: FloatArray): Int { V.addAll(listOf(p[0], p[1], p[2], n[0], n[1], n[2], a, c[0], c[1], c[2])); return nv++ }
        fun mc(a: FloatArray, b: FloatArray, t: Float) = FloatArray(3) { a[it] + (b[it] - a[it]) * t }
        val bl = s.bl; val br = s.br; val hx = bl * .4f + s.nk; val SIDES = 6
        val R = arrayOf(floatArrayOf(-bl * .5f, br * .2f), floatArrayOf(-bl * .3f, br * .65f), floatArrayOf(0f, br), floatArrayOf(bl * .22f, br * .85f), floatArrayOf(bl * .4f, br * .5f),
            floatArrayOf(bl * .4f + s.nk * .6f, br * .3f), floatArrayOf(hx, br * .38f), floatArrayOf(hx + br * 1.2f, br * .22f), floatArrayOf(hx + br * 1.9f, br * .04f))
        for (rg in R) for (k in 0 until SIDES) {
            val an = k.toFloat() / SIDES * 6.2832f; val dx = cos(an); val dy = sin(an); val z = rg[0]; val r = rg[1]
            push(floatArrayOf(dx * r, dy * r * .85f, z), floatArrayOf(dx, dy, 0f), -1f,
                if (z > bl * .4f + s.nk * .5f) s.head else mc(s.back, s.belly, (.5f - dy * .8f).coerceIn(0f, 1f)))
        }
        for (j in 0 until R.size - 1) for (k in 0 until SIDES) {
            val a = j * SIDES + k; val b = j * SIDES + (k + 1) % SIDES; val c = a + SIDES; val d = b + SIDES
            I.addAll(listOf(a, c, b, b, c, d))
        }
        val up = floatArrayOf(0f, 1f, 0f); val tz = -bl * .5f
        val t0 = push(floatArrayOf(-br * .8f, 0f, tz + .02f), up, -1f, s.back); val t1 = push(floatArrayOf(br * .8f, 0f, tz + .02f), up, -1f, s.back)
        val t2 = push(floatArrayOf(-s.tw / 2, 0f, tz - s.tl), up, -1f, s.back); val t3 = push(floatArrayOf(s.tw / 2, 0f, tz - s.tl), up, -1f, s.back)
        I.addAll(listOf(t0, t2, t1, t1, t2, t3))
        val L = s.span / 2; val rx = br * .7f; val ry = br * .2f; val zl0 = bl * .16f; val NS = 6
        for (sd in intArrayOf(1, -1)) {
            val base = nv
            for (i in 0..NS) {
                val t = i.toFloat() / NS; val x = sd * (rx + t * L); val zl = zl0 - s.sw * t * t * L * .6f; val zt = zl - (s.cr + (s.ct - s.cr) * t)
                val col = mc(s.wing, s.tip, ((t - .6f) / .4f).coerceIn(0f, 1f))
                push(floatArrayOf(x, ry, zl), up, t, col); push(floatArrayOf(x, ry, zt), up, t, col)
            }
            for (i in 0 until NS) { val a = base + i * 2; I.addAll(listOf(a, a + 1, a + 2, a + 1, a + 3, a + 2)) }
        }
        val id = IntArray(1)
        GLES30.glGenVertexArrays(1, id, 0); val vao = id[0]; GLES30.glBindVertexArray(vao)
        GLES30.glGenBuffers(1, id, 0); GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, id[0])
        val vb = ByteBuffer.allocateDirect(V.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer(); V.forEach { vb.put(it) }; vb.position(0)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, V.size * 4, vb, GLES30.GL_STATIC_DRAW)
        GLES30.glEnableVertexAttribArray(0); GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 40, 0)
        GLES30.glEnableVertexAttribArray(1); GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 40, 12)
        GLES30.glEnableVertexAttribArray(2); GLES30.glVertexAttribPointer(2, 1, GLES30.GL_FLOAT, false, 40, 24)
        GLES30.glEnableVertexAttribArray(3); GLES30.glVertexAttribPointer(3, 3, GLES30.GL_FLOAT, false, 40, 28)
        GLES30.glGenBuffers(1, id, 0); GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, id[0])
        val ib = ByteBuffer.allocateDirect(I.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer(); I.forEach { ib.put(it.toShort()) }; ib.position(0)
        GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, I.size * 2, ib, GLES30.GL_STATIC_DRAW)
        GLES30.glGenBuffers(1, id, 0); val ivbo = id[0]; GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, ivbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, s.count * Birds.F * 4, null, GLES30.GL_DYNAMIC_DRAW)
        val st = Birds.F * 4
        GLES30.glEnableVertexAttribArray(4); GLES30.glVertexAttribPointer(4, 3, GLES30.GL_FLOAT, false, st, 0); GLES30.glVertexAttribDivisor(4, 1)
        GLES30.glEnableVertexAttribArray(5); GLES30.glVertexAttribPointer(5, 3, GLES30.GL_FLOAT, false, st, 12); GLES30.glVertexAttribDivisor(5, 1)
        GLES30.glEnableVertexAttribArray(6); GLES30.glVertexAttribPointer(6, 3, GLES30.GL_FLOAT, false, st, 24); GLES30.glVertexAttribDivisor(6, 1)
        GLES30.glEnableVertexAttribArray(7); GLES30.glVertexAttribPointer(7, 1, GLES30.GL_FLOAT, false, st, 36); GLES30.glVertexAttribDivisor(7, 1)
        GLES30.glBindVertexArray(0)
        return Mesh(vao, ivbo, I.size, L, rx, ByteBuffer.allocateDirect(s.count * Birds.F * 4).order(ByteOrder.nativeOrder()).asFloatBuffer())
    }

    fun draw(vp: FloatArray, env: Environment, camX: Float, camY: Float, camZ: Float) {
        GLES30.glUseProgram(prog)
        GLES30.glUniformMatrix4fv(u("uVP"), 1, false, vp, 0)
        GLES30.glUniform3f(u("uCam"), camX, camY, camZ); GLES30.glUniform3fv(u("uFog"), 1, env.fog, 0)
        GLES30.glUniform3fv(u("uSun"), 1, env.sunDir, 0); GLES30.glUniform3fv(u("uSunCol"), 1, env.sunCol, 0); GLES30.glUniform3fv(u("uAmbCol"), 1, env.ambCol, 0)
        GLES30.glDisable(GLES30.GL_CULL_FACE)
        for (i in meshes.indices) {
            val n = Birds.count[i]; if (n == 0) continue
            val m = meshes[i]
            m.cpu.clear(); m.cpu.put(Birds.data[i], 0, n * Birds.F); m.cpu.position(0)
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, m.vbo); GLES30.glBufferSubData(GLES30.GL_ARRAY_BUFFER, 0, n * Birds.F * 4, m.cpu)
            GLES30.glUniform1f(u("uL"), m.L); GLES30.glUniform1f(u("uRx"), m.rx)
            GLES30.glBindVertexArray(m.vao)
            GLES30.glDrawElementsInstanced(GLES30.GL_TRIANGLES, m.nIdx, GLES30.GL_UNSIGNED_SHORT, 0, n)
        }
        GLES30.glBindVertexArray(0); GLES30.glEnable(GLES30.GL_CULL_FACE)
    }
}
