package com.horizonlife.game

import kotlin.math.*

/**
 * JS collideWith(roadObstacles): trunks are solid circles (r = 0.6 * scale, the JS value), the car is a circle of CAR_R = 1.4 m.
 * Also JS coastGuard(): an invisible wall 52 m inside the coast line (except on the pier, see Harbor.guard).
 * Not ported yet: hillSpots (sea islands are not in the terrain), garage obstacles (houses do not exist in the JS).
 */
object Obstacles {
    private const val CAR_R = 1.4
    private const val TREE_K = 1.25          // gl/Trees.kt draws every tree at scale * 1.25, so the trunk circle grows with it

    fun collide(c: CarState) {
        if (Harbor.collide(c)) return                 // gantry poles, warehouse, containers
        val cx = floor(c.x / TreeField.CH).toInt(); val cz = floor(c.z / TreeField.CH).toInt()
        for (i in cx - 1..cx + 1) for (j in cz - 1..cz + 1) {
            val t = TreeField.chunk(i, j); var k = 0
            while (k < t.size) {
                val ox = t[k].toDouble(); val oz = t[k + 2].toDouble(); val r = 0.6 * t[k + 3] * TREE_K + CAR_R
                val dx = c.x - ox; val dz = c.z - oz
                if (dx * dx + dz * dz < r * r) {
                    val d = sqrt(dx * dx + dz * dz).let { if (it == 0.0) 0.001 else it }; val nx = dx / d; val nz = dz / d
                    c.x = ox + nx * r; c.z = oz + nz * r
                    Collision.bounceOff(c, nx, nz, 0.22, 0.18)
                    if (Collision.cooldown <= 0) { Collision.cooldown = 0.6; Collision.hits++; Collision.thuds++ }   // one bump per impact
                    return
                }
                k += 5
            }
        }
    }

    fun coastGuard(c: CarState) {
        val r = hypot(c.x, c.z); if (r < 440) return
        if (Harbor.guard(c)) return                   // on the pier: side rails + end rail instead of the sea wall
        val lim = World.coastR(atan2(c.z, c.x)) - 52
        if (r > lim) { Collision.bounceOff(c, -c.x / r, -c.z / r, 0.25, 0.15); c.x *= lim / r; c.z *= lim / r }
    }
}
