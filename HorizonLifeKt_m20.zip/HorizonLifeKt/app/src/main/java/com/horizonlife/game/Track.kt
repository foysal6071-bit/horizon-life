package com.horizonlife.game

import kotlin.math.*

/**
 * Port of the JS dirt track (buildTrack / trackQ / trackDist): a narrow dirt road winding over the mountains from one coast to the other,
 * parallel to the river. The terrain along it is graded (World.fieldH), the surface is packed dirt (World.surfaceAt) and it counts as mud (Mud.at).
 * JS picked random phases every launch; here they are fixed. build() must run once on the main thread BEFORE the terrain workers start
 * (Game.init does that). While building, World.fieldH ignores the track exactly like the JS (TRK == null).
 */
object Track {
    const val HW = 7.2; const val BL = 38.0; const val W = 8.5      // flat half-width, banks blend width, visible dirt width (m)
    private const val CELL = 48.0
    private const val PH1 = 1.9; private const val PH2 = 4.1

    @Volatile var ready = false
        private set
    var n = 0
        private set
    var pts = FloatArray(0)                     // x,z pairs, 3 m apart
        private set
    var g = FloatArray(0)                       // graded height per point
        private set
    var clr = FloatArray(0)                     // fieldClear per point (distance to the tarmac)
        private set
    var len = FloatArray(0)                     // length of segment i -> i+1
        private set
    private var grid: HashMap<Long, IntArray> = HashMap()
    private fun key(cx: Int, cz: Int) = (cx.toLong() shl 32) xor (cz.toLong() and 0xffffffffL)
    private val tl = ThreadLocal.withInitial { DoubleArray(2) }

    /** o[0] = distance to the track centre line (1e9 if none near), o[1] = graded height there */
    fun q(x: Double, z: Double, o: DoubleArray) {
        o[0] = 1e9; o[1] = 0.0
        if (!ready) return
        val cx = floor(x / CELL).toInt(); val cz = floor(z / CELL).toInt()
        for (i in -1..1) for (j in -1..1) {
            val l = grid[key(cx + i, cz + j)] ?: continue
            for (idx in l) for (k in idx - 1..idx) {
                if (k < 0 || k >= n - 1) continue
                val ax = pts[k * 2].toDouble(); val az = pts[k * 2 + 1].toDouble()
                val ex = pts[k * 2 + 2] - ax; val ez = pts[k * 2 + 3] - az
                var t = ((x - ax) * ex + (z - az) * ez) / (ex * ex + ez * ez); t = if (t < 0) 0.0 else if (t > 1) 1.0 else t
                val dx = x - (ax + ex * t); val dz = z - (az + ez * t); val d = sqrt(dx * dx + dz * dz)
                if (d < o[0]) { o[0] = d; o[1] = g[k] + (g[k + 1] - g[k]) * t }
            }
        }
    }

    fun dist(x: Double, z: Double): Double { val o = tl.get()!!; q(x, z, o); return o[0] }
    /** distance + graded height (shared per-thread array: read it immediately) */
    fun query(x: Double, z: Double): DoubleArray { val o = tl.get()!!; q(x, z, o); return o }

    fun build() {
        if (ready) return
        val rvC = cos(Roads.RIVER_ANG); val rvS = sin(Roads.RIVER_ANG); val nx = rvC; val nz = -rvS
        var best: DoubleArray? = null; var bestScore = -1.0; var bT0 = 0.0; var bT1 = 0.0; var bO = 0.0
        fun px(t: Double, o0: Double): Double { val o = o0 + 45 * sin(t / 140 + PH1) + 20 * sin(t / 60 + PH2); return rvS * t + nx * o }
        fun pz(t: Double, o0: Double): Double { val o = o0 + 45 * sin(t / 140 + PH1) + 20 * sin(t / 60 + PH2); return rvC * t + nz * o }
        for (o0 in doubleArrayOf(-340.0, -320.0, 320.0, 340.0)) {
            var t0 = 0.0; var t1 = 0.0
            while (t0 > -900) { if (World.coastDist(px(t0 - 3, o0), pz(t0 - 3, o0)) > -75) break; t0 -= 3 }
            while (t1 < 900) { if (World.coastDist(px(t1 + 3, o0), pz(t1 + 3, o0)) > -75) break; t1 += 3 }
            if (t1 - t0 < 500) continue
            var near = false; var t = t0
            while (t <= t1) { if (abs(World.riverSd(px(t, o0), pz(t, o0))) < 70) { near = true; break }; t += 6 }
            if (near) continue
            var sc = 0.0; var cnt = 0; t = t0
            while (t <= t1) { sc += World.fieldH(px(t, o0), pz(t, o0)); cnt++; t += 30 }
            sc /= cnt
            if (sc > bestScore) { bestScore = sc; best = doubleArrayOf(o0); bT0 = t0; bT1 = t1; bO = o0 }
        }
        if (best == null) return
        val pl = ArrayList<Float>(); var t = bT0
        while (t <= bT1) { pl.add(px(t, bO).toFloat()); pl.add(pz(t, bO).toFloat()); t += 3 }
        val nn = pl.size / 2; val p = pl.toFloatArray()
        val h0 = FloatArray(nn); val cl = FloatArray(nn); val ln = FloatArray(nn)
        for (i in 0 until nn) {
            h0[i] = World.fieldH(p[i * 2].toDouble(), p[i * 2 + 1].toDouble()).toFloat()
            cl[i] = World.fieldClear(p[i * 2].toDouble(), p[i * 2 + 1].toDouble()).toFloat()
            if (i < nn - 1) ln[i] = hypot((p[i * 2 + 2] - p[i * 2]).toDouble(), (p[i * 2 + 3] - p[i * 2 + 1]).toDouble()).toFloat()
        }
        fun smooth(a: FloatArray, w: Int): FloatArray {
            val b = FloatArray(nn)
            for (i in 0 until nn) { var sm = 0f; var c = 0; for (k in -w..w) { val j = i + k; if (j < 0 || j >= nn) continue; sm += a[j]; c++ }; b[i] = sm / c }
            return b
        }
        fun pin(a: FloatArray) { for (i in 0 until nn) if (cl[i] < 12 || i < 4 || i > nn - 5) a[i] = 0f }   // level where it meets the tarmac and the beach
        var gg = h0.copyOf()
        repeat(3) { gg = smooth(gg, 12) }
        pin(gg)
        repeat(3) {                                  // never steeper than ~11 %: cuts through ridges, fills the dips
            for (i in 1 until nn) gg[i] = min(gg[i], gg[i - 1] + 0.11f * ln[i - 1])
            for (i in nn - 2 downTo 0) gg[i] = min(gg[i], gg[i + 1] + 0.11f * ln[i])
        }
        gg = smooth(gg, 2); pin(gg)
        val gr = HashMap<Long, IntArray>()
        val tmp = HashMap<Long, ArrayList<Int>>()
        for (i in 0 until nn) tmp.getOrPut(key(floor(p[i * 2] / CELL).toInt(), floor(p[i * 2 + 1] / CELL).toInt())) { ArrayList() }.add(i)
        for ((k, v) in tmp) gr[k] = v.toIntArray()
        n = nn; pts = p; g = gg; clr = cl; len = ln; grid = gr
        ready = true                                  // publishing last: workers only see a complete track
    }
}
