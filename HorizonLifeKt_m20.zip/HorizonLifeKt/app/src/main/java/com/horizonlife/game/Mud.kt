package com.horizonlife.game

import kotlin.math.*
import kotlin.random.Random

/**
 * Port of the JS mud block: mudAt(), tyre mud level (updateTyreMud) and the spray (updateMud): flung clumps, mist puffs and the splats clumps leave on the road.
 * Data lives in plain FloatArrays laid out exactly like the GL vertex buffers (gl/MudRenderer.kt uploads them).
 * Not ported: puddles (disabled in the JS), dirt track, wet-mud body shader on the car (only the tyres/rims get tinted).
 */
object Mud {
    const val MUD_N = 280; const val MIST_N = 110; const val SPL_N = 400
    const val CF = 13      // clump: pos3 vel3 col3 size alpha misc2
    const val MF = 9       // mist: pos3 col3 size alpha seed
    const val SF = 11      // splat vertex: pos3 uv2 col4 misc2
    private const val GRAV = 11.5; private const val MUD_R = 0.34
    val WHEEL_OFF = arrayOf(doubleArrayOf(1.4, 0.86), doubleArrayOf(1.4, -0.86), doubleArrayOf(-1.4, 0.86), doubleArrayOf(-1.4, -0.86))   // [forward, left] FL FR RL RR

    var k = 0.0; var dry = 0.0                       // result of the last at()
    private fun sstep(a: Double, b: Double, x: Double) = World.sstep(a, b, x)

    /** how much loose mud is under a tyre at (x,z): 1 = wet road, 0 = grass; `dry` = dusty verge */
    fun at(x: Double, z: Double): Double {
        val c = World.roadClearance(x, z); var kk = 0.0; var d = 0.0
        if (c < 2.4) { kk = 1 - sstep(0.7, 2.4, c); d = sstep(0.3, 1.8, c) }
        if (Track.ready) {                                  // dirt track = wet mud, almost no dust
            val td = Track.dist(x, z)
            if (td < Track.W * 0.5 + 1.6) { val kt = 1 - sstep(Track.W * 0.5 - 0.4, Track.W * 0.5 + 1.6, td); if (kt > kk) { kk = kt; d = 1 - 0.9 * kt } }
        }
        k = kk; dry = d; return kk
    }

    // ---- tyre mud level (0..1) and how dry it is, per wheel ----
    val lvl = DoubleArray(4); val tdry = DoubleArray(4)

    // ---- particles ----
    val clump = FloatArray(MUD_N * CF); private val cAge = FloatArray(MUD_N) { 9f }; private val cLife = FloatArray(MUD_N) { 1f }; private val cA0 = FloatArray(MUD_N)
    val mist = FloatArray(MIST_N * MF); private val mVel = FloatArray(MIST_N * 3); private val mAge = FloatArray(MIST_N) { 9f }; private val mLife = FloatArray(MIST_N) { 1f }
    private val mS0 = FloatArray(MIST_N); private val mA0 = FloatArray(MIST_N)
    val spl = FloatArray(SPL_N * 6 * SF); var splCount = 0; var splDirty = false; private var splHead = 0
    var time = 0.0
    private var cHead = 0; private var mHead = 0
    private val cAcc = DoubleArray(4); private val mAcc = DoubleArray(4)
    private var gy = 0.0; private var gpx = 0.0; private var gpz = 0.0; private var gsH = 0.0; private var gcH = 1.0; private var gg = 0.0; private var gsl = 0.0
    private val rnd = Random.Default
    private fun r() = rnd.nextDouble()

    init { for (i in 0 until MUD_N) clump[i * CF + 1] = -100f; for (i in 0 until MIST_N) mist[i * MF + 1] = -100f }

    private fun groundY(x: Double, z: Double): Double {
        val dx = x - gpx; val dz = z - gpz
        val off = gg * (dx * gsH + dz * gcH) + gsl * (dx * gcH - dz * gsH)
        return gy + 0.02 + max(-0.5, min(0.5, off))
    }

    private fun addSplat(x: Double, y: Double, z: Double, dx: Double, dz: Double, size: Double, cr: Double, cg: Double, cb: Double, a: Double) {
        val sp = hypot(dx, dz); val ux: Double; val uz: Double
        if (sp > 0.3) { ux = dx / sp; uz = dz / sp } else { val t = r() * 6.283; ux = cos(t); uz = sin(t) }
        val A = size * 0.38 * (1.0 + min(sp * 0.06, 1.0)); val B = size * 0.38 * (0.85 + r() * 0.4); val px = -uz; val pz = ux; val seed = r(); val q = splHead
        val sc = intArrayOf(-1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1)
        for (kk in 0 until 6) {
            val s = sc[kk * 2]; val t = sc[kk * 2 + 1]; val o = (q * 6 + kk) * SF
            spl[o] = (x + ux * A * s + px * B * t).toFloat(); spl[o + 1] = y.toFloat(); spl[o + 2] = (z + uz * A * s + pz * B * t).toFloat()
            spl[o + 3] = s.toFloat(); spl[o + 4] = t.toFloat()
            spl[o + 5] = cr.toFloat(); spl[o + 6] = cg.toFloat(); spl[o + 7] = cb.toFloat(); spl[o + 8] = a.toFloat()
            spl[o + 9] = time.toFloat(); spl[o + 10] = seed.toFloat()
        }
        splHead = (splHead + 1) % SPL_N; splCount = min(splCount + 1, SPL_N); splDirty = true
    }

    /** one frame: tyre mud + spray. groundY = tyre-contact height under the car, g / sl = ground gradient along / across the car */
    fun update(c: CarState, dt: Double, groundY: Double, g: Double, sl: Double, grounded: Boolean) {
        time += dt
        val sH = sin(c.heading); val cH = cos(c.heading)
        if (grounded) { gy = groundY; gpx = c.x; gpz = c.z; gsH = sH; gcH = cH; gg = g; gsl = sl }
        val roll = hypot(c.speed, c.vy); val slip = min(abs(c.vy) / 2.2, 1.0); val thr = c.throttle
        // ---- tyre mud (JS updateTyreMud) ----
        val spinT = thr * max(0.0, 1 - abs(c.speed) / 13).pow(1.3)
        for (w in 0..3) {
            var L = lvl[w]; var D = tdry[w]
            if (grounded && roll > 0.4) {
                val wx = c.x + sH * WHEEL_OFF[w][0] + cH * WHEEL_OFF[w][1]; val wz = c.z + cH * WHEEL_OFF[w][0] - sH * WHEEL_OFF[w][1]
                val kk = at(wx, wz); val dr = dry
                if (kk > 0.05) {
                    val pick = min(roll / 7, 1.4) + slip + (if (w >= 2) spinT else 0.0)
                    L += dt * kk * (0.055 + 0.05 * (1 - dr)) * pick * (1 - 0.55 * L)
                    D += (dr * 0.9 - D) * min(1.0, dt * 0.4)
                } else {
                    L -= dt * (0.004 + 0.010 * min(roll / 20, 1.0)); D += (0.8 - D) * min(1.0, dt / 45)
                }
            } else D += (0.8 - D) * min(1.0, dt / 90)
            lvl[w] = min(1.0, max(0.0, L)); tdry[w] = min(1.0, max(0.0, D))
        }
        // ---- emit ----
        if (grounded) {
            val hb = c.hb
            val vwx = c.speed * sH + c.vy * cH; val vwz = c.speed * cH - c.vy * sH
            val spin = thr * max(0.0, 1 - abs(c.speed) / 13).pow(1.3) * 0.85 + hb * 0.25 * thr
            val rolling = sstep(1.0, 9.0, roll)
            for (w in 0..3) {
                val front = w < 2; val side = if (WHEEL_OFF[w][1] > 0) 1.0 else -1.0
                val wx = c.x + sH * WHEEL_OFF[w][0] + cH * WHEEL_OFF[w][1]; val wz = c.z + cH * WHEEL_OFF[w][0] - sH * WHEEL_OFF[w][1]
                val rateF = if (front) max(rolling, slip * 0.6) * 0.5 else max(rolling, max(spin, slip * 0.8))
                if (rateF < 0.02) { cAcc[w] = 0.0; mAcc[w] = 0.0; continue }
                val kk = at(wx, wz)
                if (kk < 0.05) { cAcc[w] = 0.0; mAcc[w] = 0.0; continue }
                val dr = dry
                val hd = if (front) c.heading + c.steerAngle else c.heading; val fx = sin(hd); val fz = cos(hd); val lx = cos(hd); val lz = -sin(hd)
                val sRim = min(50.0, roll + (if (front) 0.0 else 15 * spin + 5 * slip) + (if (front) 2 * slip else 0.0))
                cAcc[w] += dt * (if (front) 50 else 110) * rateF * kk
                var n = 0
                while (cAcc[w] >= 1 && n++ < 8) {
                    cAcc[w] = cAcc[w] - 1.0; val i = cHead; cHead = (cHead + 1) % MUD_N; val o = i * CF
                    val al = (if (front) 10 + r() * 35 else 12 + r() * 45) * PI / 180; val sa = sin(al); val ca = cos(al)
                    val u = min(7.5, (0.12 + r() * 0.20) * sRim); val lat = (r() - 0.5) * 0.26
                    val sideU = side * (0.08 + 0.32 * r()) * u * (if (front) 1.4 else 0.5) + (r() - 0.5) * 0.22 * u + (if (c.vy > 0) 1 else -1) * slip * r() * 3.5 * (if (front) 0.5 else 1.0)
                    val back = MUD_R * sa
                    clump[o] = (wx - fx * back + lx * lat).toFloat(); clump[o + 1] = (gy + 0.03 + MUD_R * (1 - ca)).toFloat(); clump[o + 2] = (wz - fz * back + lz * lat).toFloat()
                    clump[o + 3] = (vwx - fx * ca * u + lx * sideU).toFloat()
                    clump[o + 4] = max(0.15, min(2.6, sa * u * (0.30 + 0.25 * r()) + 0.25 * r())).toFloat()
                    clump[o + 5] = (vwz - fz * ca * u + lz * sideU).toFloat()
                    val t = r(); val sz = if (t < 0.70) 0.035 + r() * 0.035 else if (t < 0.95) 0.07 + r() * 0.05 else 0.12 + r() * 0.08
                    clump[o + 9] = sz.toFloat(); cAge[i] = 0f; cLife[i] = 2.2f; cA0[i] = (0.92 * (0.85 + 0.15 * r())).toFloat()
                    val v = 0.8 + 0.4 * r()
                    clump[o + 6] = ((0.23 + 0.29 * dr) * v).toFloat(); clump[o + 7] = ((0.165 + 0.245 * dr) * v).toFloat(); clump[o + 8] = ((0.105 + 0.175 * dr) * v).toFloat()
                    clump[o + 11] = r().toFloat(); clump[o + 12] = (0.35 + 0.65 * (1 - dr)).toFloat()
                }
                mAcc[w] += dt * (if (front) 10 else 22) * rateF * kk
                n = 0
                while (mAcc[w] >= 1 && n++ < 4) {
                    mAcc[w] = mAcc[w] - 1.0; val i = mHead; mHead = (mHead + 1) % MIST_N; val back = MUD_R * (0.4 + 0.6 * r()); val o = i * MF
                    mist[o] = (wx - fx * back + lx * (r() - 0.5) * 0.3).toFloat(); mist[o + 1] = (gy + 0.05 + r() * 0.10).toFloat(); mist[o + 2] = (wz - fz * back + lz * (r() - 0.5) * 0.3).toFloat()
                    mVel[i * 3] = (vwx * 0.45 + lx * side * (0.3 + r() * 1.0) + (r() - 0.5) * 0.8).toFloat(); mVel[i * 3 + 1] = (0.08 + r() * 0.30).toFloat()
                    mVel[i * 3 + 2] = (vwz * 0.45 + lz * side * (0.3 + r() * 1.0) + (r() - 0.5) * 0.8).toFloat()
                    mAge[i] = 0f; mLife[i] = (0.7 + r() * 0.7).toFloat(); mS0[i] = (0.28 + r() * 0.22).toFloat()
                    mA0[i] = ((0.2 + 0.18 * min(rateF * 1.3, 1.0)) * (0.8 + 0.4 * r()) * (0.5 + 0.5 * kk)).toFloat(); mist[o + 8] = r().toFloat()
                    val v = 0.85 + 0.3 * r()
                    mist[o + 3] = ((0.30 + 0.32 * dr) * v).toFloat(); mist[o + 4] = ((0.23 + 0.29 * dr) * v).toFloat(); mist[o + 5] = ((0.16 + 0.22 * dr) * v).toFloat()
                }
            }
        } else for (w in 0..3) { cAcc[w] = 0.0; mAcc[w] = 0.0 }
        // ---- clumps: fly, land, splat ----
        val drag = exp(-0.5 * dt).toFloat(); val fdt = dt.toFloat()
        for (i in 0 until MUD_N) {
            val o = i * CF
            if (cAge[i] >= cLife[i]) { clump[o + 10] = 0f; clump[o + 9] = 0f; continue }
            cAge[i] += fdt
            clump[o + 4] -= (GRAV * dt).toFloat(); clump[o + 3] *= drag; clump[o + 5] *= drag
            clump[o] += clump[o + 3] * fdt; clump[o + 1] += clump[o + 4] * fdt; clump[o + 2] += clump[o + 5] * fdt
            val sz = clump[o + 9]; val gyy = groundY(clump[o].toDouble(), clump[o + 2].toDouble())
            if (clump[o + 4] < 0 && clump[o + 1] <= gyy + sz * 0.5) {
                if (sz > 0.045 && r() < 0.38 && at(clump[o].toDouble(), clump[o + 2].toDouble()) > 0.35)
                    addSplat(clump[o].toDouble(), gyy + 0.012, clump[o + 2].toDouble(), clump[o + 3].toDouble(), clump[o + 5].toDouble(), sz * (1 + 0.4 * r()),
                        clump[o + 6] * 0.9, clump[o + 7] * 0.9, clump[o + 8] * 0.9, 0.85)
                cAge[i] = cLife[i]; clump[o + 10] = 0f; clump[o + 9] = 0f; continue
            }
            clump[o + 10] = cA0[i] * (1 - sstep(0.8, 1.0, (cAge[i] / cLife[i]).toDouble())).toFloat()
        }
        // ---- mist ----
        val dr2 = exp(-1.8 * dt).toFloat(); val dy2 = exp(-1.0 * dt).toFloat()
        for (i in 0 until MIST_N) {
            val o = i * MF
            if (mAge[i] >= mLife[i]) { mist[o + 7] = 0f; mist[o + 6] = 0f; continue }
            mAge[i] += fdt; val kk = mAge[i] / mLife[i]
            mist[o] += mVel[i * 3] * fdt; mist[o + 1] += mVel[i * 3 + 1] * fdt; mist[o + 2] += mVel[i * 3 + 2] * fdt
            mVel[i * 3] *= dr2; mVel[i * 3 + 2] *= dr2; mVel[i * 3 + 1] *= dy2
            mist[o + 6] = mS0[i] * (1 + mAge[i] * 1.7f)
            mist[o + 7] = mA0[i] * (1 - min(kk, 1f)).pow(1.4f) * min(mAge[i] * 9, 1f)
        }
    }
}
