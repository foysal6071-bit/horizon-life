package com.horizonlife.gl

import android.opengl.GLES30
import com.horizonlife.game.Track
import com.horizonlife.game.World
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.*

/**
 * Dirt-track ribbon (JS "the dirt strip itself"). Same vertex layout and shader as RoadMesh (x y z, lat, v, hw) so ROAD_FS paints the same wet rutted mud.
 * Like the JS, the ribbon follows the REAL rendered terrain triangles (4 m grid, diagonal b-c) and is cut into ~2 m rows, so the ground never pokes through.
 */
class TrackMesh {
    private var vao = 0; private var nIdx = 0
    val empty get() = nIdx == 0

    private fun triH(x: Double, z: Double): Double {
        val s = Terrain.STEP; val fx = x / s; val fz = z / s; val ix = floor(fx).toInt(); val iz = floor(fz).toInt()
        val u = fx - ix; val v = fz - iz
        val ha = World.height(ix * s, iz * s); val hb = World.height((ix + 1) * s, iz * s)
        val hc = World.height(ix * s, (iz + 1) * s); val hd = World.height((ix + 1) * s, (iz + 1) * s)
        return if (u + v <= 1) ha + u * (hb - ha) + v * (hc - ha) else hb * (1 - v) + hc * (1 - u) + hd * (u + v - 1)
    }

    init {
        if (Track.ready && Track.n > 1) build()
    }

    private fun build() {
        val P = Track.pts; val n = Track.n
        // rows: x, z, tangent x, tangent z, distance along; rowOk = strip between this row and the next is drawn (it stops short of the tarmac)
        val rx = ArrayList<Float>(); val rz = ArrayList<Float>(); val rtx = ArrayList<Float>(); val rtz = ArrayList<Float>(); val rs = ArrayList<Float>(); val ok = ArrayList<Boolean>()
        fun tanAt(i: Int): DoubleArray {
            val a = max(i - 1, 0); val b = min(i + 1, n - 1)
            val tx = (P[b * 2] - P[a * 2]).toDouble(); val tz = (P[b * 2 + 1] - P[a * 2 + 1]).toDouble(); val l = hypot(tx, tz).let { if (it == 0.0) 1.0 else it }
            return doubleArrayOf(tx / l, tz / l)
        }
        var sAcc = 0.0
        for (i in 0 until n - 1) {
            val good = Track.clr[i] > 1.2 && Track.clr[i + 1] > 1.2; val segL = Track.len[i].toDouble(); val m = max(1, ceil(segL / 2).toInt())
            val t0 = tanAt(i); val t1 = tanAt(i + 1)
            for (k in 0 until m) {
                val f = k.toDouble() / m
                var tx = t0[0] + (t1[0] - t0[0]) * f; var tz = t0[1] + (t1[1] - t0[1]) * f; val tl = hypot(tx, tz).let { if (it == 0.0) 1.0 else it }; tx /= tl; tz /= tl
                rx.add((P[i * 2] + (P[i * 2 + 2] - P[i * 2]) * f).toFloat()); rz.add((P[i * 2 + 1] + (P[i * 2 + 3] - P[i * 2 + 1]) * f).toFloat())
                rtx.add(tx.toFloat()); rtz.add(tz.toFloat()); rs.add(sAcc.toFloat()); ok.add(good); sAcc += segL / m
            }
        }
        run { val t = tanAt(n - 1); rx.add(P[(n - 1) * 2]); rz.add(P[(n - 1) * 2 + 1]); rtx.add(t[0].toFloat()); rtz.add(t[1].toFloat()); rs.add(sAcc.toFloat()); ok.add(false) }
        val hw = Track.W / 2
        val lat = doubleArrayOf(-(hw + 8), -(hw + 3.5), -hw, -(hw - 1.5), -hw / 2, 0.0, hw / 2, hw - 1.5, hw, hw + 3.5, hw + 8)
        val yy = doubleArrayOf(0.06, 0.09, 0.12, 0.13, 0.14, 0.14, 0.14, 0.13, 0.12, 0.09, 0.06)
        val NC = lat.size; val rows = rx.size
        require(rows * NC < 65536) { "track mesh too large for 16-bit indices: ${rows * NC}" }
        val verts = FloatArray(rows * NC * 6); var o = 0
        for (r in 0 until rows) for (c in 0 until NC) {
            // left of travel (same convention as RoadMesh: n = (t.z, -t.x), lat > 0 = left)
            val x = rx[r] + rtz[r] * lat[c]; val z = rz[r] - rtx[r] * lat[c]
            verts[o++] = x.toFloat(); verts[o++] = (triH(x, z) + yy[c]).toFloat(); verts[o++] = z.toFloat()
            verts[o++] = lat[c].toFloat(); verts[o++] = rs[r]; verts[o++] = hw.toFloat()
        }
        val idx = ArrayList<Short>()
        for (r in 0 until rows - 1) if (ok[r]) for (c in 0 until NC - 1) {
            val a = r * NC + c; val b = a + 1; val cc = (r + 1) * NC + c; val d = cc + 1
            idx.add(a.toShort()); idx.add(cc.toShort()); idx.add(b.toShort()); idx.add(b.toShort()); idx.add(cc.toShort()); idx.add(d.toShort())
        }
        nIdx = idx.size
        val id = IntArray(1)
        GLES30.glGenVertexArrays(1, id, 0); vao = id[0]; GLES30.glBindVertexArray(vao)
        GLES30.glGenBuffers(1, id, 0); GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, id[0])
        val fb = ByteBuffer.allocateDirect(verts.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(verts).also { it.position(0) }
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, verts.size * 4, fb, GLES30.GL_STATIC_DRAW)
        GLES30.glEnableVertexAttribArray(0); GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 24, 0)
        GLES30.glEnableVertexAttribArray(1); GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 24, 12)
        GLES30.glGenBuffers(1, id, 0); GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, id[0])
        val sb = ByteBuffer.allocateDirect(idx.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer().put(idx.toShortArray()).also { it.position(0) }
        GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, idx.size * 2, sb, GLES30.GL_STATIC_DRAW)
        GLES30.glBindVertexArray(0)
    }

    fun draw() {
        if (nIdx == 0) return
        GLES30.glBindVertexArray(vao); GLES30.glDrawElements(GLES30.GL_TRIANGLES, nIdx, GLES30.GL_UNSIGNED_SHORT, 0); GLES30.glBindVertexArray(0)
    }
}
