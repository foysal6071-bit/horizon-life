package com.horizonlife.game

import kotlin.math.*
import kotlin.random.Random

/**
 * Port of the JS tyre marks (updateMarks / addMarkQuad): continuous strips behind each wheel in a 14000-quad ring buffer.
 * mode 0 = rolling tread in mud, 1 = locked / spinning wheel in mud, 2 = black rubber on hard ground. Vertex: pos3 rgba4 uv2 (uv.x = mode/3 + lateral/3).
 */
object Marks {
    const val Q = 14000; const val VF = 9
    val data = FloatArray(Q * 6 * VF)
    var count = 0; private var head = 0
    var dirtyFirst = 0; var dirtyN = 0; var dirtyAll = false      // range written this frame (renderer uploads it)
    private const val VLEN = 0.6; private const val STEP2 = 0.16
    private val K = doubleArrayOf(1 / 0.62, 1 / 0.62, 1.12)
    private val mx = DoubleArray(4); private val mz = DoubleArray(4); private val my = DoubleArray(4); private val ma = DoubleArray(4)
    private val on = BooleanArray(4); private val md = DoubleArray(4); private val mhw = doubleArrayOf(0.15, 0.15, 0.15, 0.15)
    private val tnx = DoubleArray(4); private val tnz = DoubleArray(4); private val tl = BooleanArray(4)
    val smoke = DoubleArray(4)                                      // mark intensity per wheel (JS mk.inten) for later tyre smoke

    private fun put(q: Int, i: Int, x: Double, y: Double, z: Double, r: Double, g: Double, b: Double, a: Double, u: Double, v: Double) {
        val o = (q * 6 + i) * VF
        data[o] = x.toFloat(); data[o + 1] = y.toFloat(); data[o + 2] = z.toFloat()
        data[o + 3] = r.toFloat(); data[o + 4] = g.toFloat(); data[o + 5] = b.toFloat(); data[o + 6] = a.toFloat(); data[o + 7] = u.toFloat(); data[o + 8] = v.toFloat()
    }

    private fun addQuad(ax: Double, az: Double, bx: Double, bz: Double, ay: Double, by: Double, a0: Double, a1: Double, r: Double, g: Double, b: Double,
                        d0: Double, d1: Double, hw0: Double, hw1: Double, mode: Int, w: Int): Int {
        val dx = bx - ax; val dz = bz - az; val l = hypot(dx, dz).let { if (it == 0.0) 1.0 else it }; val tx = -dz / l; val tz = dx / l; val kk = K[mode]
        var px = tx; var pz = tz; if (tl[w] && tnx[w] * tx + tnz[w] * tz > 0.2) { px = tnx[w]; pz = tnz[w] }
        tnx[w] = tx; tnz[w] = tz; tl[w] = true
        val n0x = px * hw0 * kk; val n0z = pz * hw0 * kk; val n1x = tx * hw1 * kk; val n1z = tz * hw1 * kk
        val q = head; val v0 = d0 / VLEN; val v1 = d1 / VLEN; val ua = mode / 3.0; val ub = ua + 1 / 3.0
        put(q, 0, ax + n0x, ay, az + n0z, r, g, b, a0, ua, v0); put(q, 1, bx + n1x, by, bz + n1z, r, g, b, a1, ua, v1); put(q, 2, ax - n0x, ay, az - n0z, r, g, b, a0, ub, v0)
        put(q, 3, ax - n0x, ay, az - n0z, r, g, b, a0, ub, v0); put(q, 4, bx + n1x, by, bz + n1z, r, g, b, a1, ua, v1); put(q, 5, bx - n1x, by, bz - n1z, r, g, b, a1, ub, v1)
        head = (head + 1) % Q; count = min(count + 1, Q)
        return q
    }

    /** y = tyre contact height; grounded = on the ground and not on a bridge deck */
    fun update(S: CarState, y: Double, grounded: Boolean) {
        val sp = abs(S.speed); val sH = sin(S.heading); val cH = cos(S.heading)
        val slip = min(abs(S.vy) / 2.2, 1.0)
        val drift = if (S.drift > 0.4 && sp > 6) S.drift * (0.35 + 0.65 * slip) else 0.0
        var first = -1; var wrote = 0
        for (w in 0..3) {
            val wx = S.x + sH * Mud.WHEEL_OFF[w][0] + cH * Mud.WHEEL_OFF[w][1]; val wz = S.z + cH * Mud.WHEEL_OFF[w][0] - sH * Mud.WHEEL_OFF[w][1]
            val mud = Mud.at(wx, wz); val dry = Mud.dry; val onMud = mud > 0.35
            val load = if (w < 2) 0.85 else 1.0
            var a = 0.0; var smear = 0; var rolling = false
            val brk = grounded && !S.reverse && S.brake > (if (onMud) 0.3 else 0.7) && S.speed > (if (onMud) 3.0 else 9.0)
            if (brk) {
                val lock = min(max((S.brake - 0.75) / 0.25, 0.0), 1.0)
                smear = if (onMud && lock > 0.5) 1 else 0
                a = if (onMud) (0.42 + 0.5 * min((S.speed - 3) / 12, 1.0)) * load else 0.62 * min((S.speed - 7) / 12, 1.0)
            }
            if (drift > 0) { val ad = if (w >= 2) 0.9 * drift else 0.5 * drift * slip; if (ad > a) { a = ad; smear = if (onMud) 1 else 0 } }
            if (!brk && onMud && grounded && sp > 0.8) { a = max(a, (0.55 + 0.30 * min(sp / 12, 1.0)) * mud * (if (w >= 2) 1.0 else 0.92)); rolling = true }
            if (!grounded) a = 0.0
            smoke[w] = if (rolling) 0.0 else a
            if (a < 0.04) { on[w] = false; tl[w] = false; continue }
            if (on[w]) {
                val dx = wx - mx[w]; val dz = wz - mz[w]; val d2 = dx * dx + dz * dz
                if (d2 < (if (rolling) STEP2 else 0.09)) continue
                if (d2 <= 16) {
                    val dd = sqrt(d2); val d0 = md[w]; val d1 = d0 + dd
                    val hw1 = if (smear == 1) 0.19 + 0.02 * sin(d1 * 3.1 + w) else 0.15; val hw0 = mhw[w]; val y0 = my[w]
                    val q: Int
                    if (onMud) {
                        val k = 1.0; val rr = (0.115 + 0.20 * dry) * k; val gg = (0.072 + 0.15 * dry) * k; val bb = (0.044 + 0.10 * dry) * k; val m = min(1.0, 0.55 + mud * 0.6)
                        q = addQuad(mx[w], mz[w], wx, wz, y0, y, ma[w] * m, a * m, rr, gg, bb, d0, d1, hw0, hw1, if (smear == 1) 1 else 0, w)
                    } else if (World.roadClearance(wx, wz) < 0.9) q = addQuad(mx[w], mz[w], wx, wz, y0, y, ma[w], a, 0.05, 0.05, 0.055, d0, d1, hw0, hw1, 2, w)
                    else q = addQuad(mx[w], mz[w], wx, wz, y0, y, ma[w] * 0.55, a * 0.55, 0.20, 0.14, 0.085, d0, d1, hw0, hw1, 0, w)
                    if (first < 0) first = q; wrote++
                    mx[w] = wx; mz[w] = wz; my[w] = y; ma[w] = a; md[w] = d1; mhw[w] = hw1; continue
                }
            }
            on[w] = true; tl[w] = false; mx[w] = wx; mz[w] = wz; my[w] = y; ma[w] = 0.0; md[w] = Random.nextDouble() * 8; mhw[w] = 0.15
        }
        dirtyN = wrote; dirtyFirst = max(first, 0); dirtyAll = wrote > 0 && first + wrote > Q
    }
}
