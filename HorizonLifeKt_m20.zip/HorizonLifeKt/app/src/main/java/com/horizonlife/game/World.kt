package com.horizonlife.game

import kotlin.math.*

/**
 * Milestone 2: real terrain functions ported from the JS (coast / island, winding river, rolling hills + mountains).
 * Roads: see Roads.kt. Dirt track: Track.kt. Harbor pier: Harbor.kt (flat ground around it).
 * Hills use a FIXED seed (JS used a random seed per launch).
 */
object World {
    const val ROAD_SURF = Roads.SURF
    const val WATER_Y = -1.3
    const val RIVER_WALL = 24.0
    const val RIVER_DEPTH = 3.2
    private const val FIELD_MAX = 25.0
    private const val FIELD_AMP = 15.0
    private val FSEED = doubleArrayOf(123.4, 267.1, 341.9, 58.2)

    private fun smooth(t: Double) = t * t * (3 - 2 * t)
    fun sstep(a: Double, b: Double, x: Double): Double { val t = min(max((x - a) / (b - a), 0.0), 1.0); return t * t * (3 - 2 * t) }

    // ---------------- island / coast ----------------
    private const val COAST0 = 600.0
    fun coastR(a: Double) = COAST0 + sin(a * 2 + 0.7) * 34 + cos(a * 3 - 1.1) * 22 + sin(a * 5 + 2.0) * 10
    fun coastDist(x: Double, z: Double) = hypot(x, z) - coastR(atan2(z, x))

    // ---------------- river (Catmull-Rom through the traced control points) ----------------
    private val RIVER_CTRL = arrayOf(
        -882, -47, -533, -70, -465, -69, -397, -79, -328, -89, -260, -91, -192, -81, -124, -60, -56, -30, 12, 12, 80, 73,
        148, 160, 216, 254, 284, 299, 352, 326, 420, 331, 488, 314, 550, 286, 881, 173)
    private val rvX: DoubleArray
    private val rvZ: DoubleArray
    /** river centre-line polyline (for the minimap) */
    fun riverPolyline(): Pair<DoubleArray, DoubleArray> = rvX to rvZ
    private const val RV_CELL = 64.0
    private const val RV_RANGE = 280.0
    private val rvGrid = HashMap<Int, IntArray>()

    init {
        val n = RIVER_CTRL.size / 2
        val xs = ArrayList<Double>(); val zs = ArrayList<Double>()
        fun p(i: Int, c: Int) = RIVER_CTRL[i * 2 + c].toDouble()
        for (i in 0 until n - 1) {
            val i0 = max(i - 1, 0); val i3 = min(i + 2, n - 1)
            val m = max(2, ceil(hypot(p(i + 1, 0) - p(i, 0), p(i + 1, 1) - p(i, 1)) / 10).toInt())
            for (k in 0 until m) {
                val t = k.toDouble() / m; val t2 = t * t; val t3 = t2 * t
                for (c in 0..1) {
                    val p0 = p(i0, c); val p1 = p(i, c); val p2 = p(i + 1, c); val p3 = p(i3, c)
                    val v = 0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 + (-p0 + 3 * p1 - 3 * p2 + p3) * t3)
                    if (c == 1) zs.add(v) else xs.add(v)
                }
            }
        }
        xs.add(p(n - 1, 0)); zs.add(p(n - 1, 1))
        rvX = xs.toDoubleArray(); rvZ = zs.toDoubleArray()
        for (cx in -24..24) for (cz in -24..24) {
            val mx = (cx + 0.5) * RV_CELL; val mz = (cz + 0.5) * RV_CELL; val lim = RV_RANGE + 0.72 * RV_CELL
            val list = ArrayList<Int>()
            for (i in 0 until rvX.size - 1) {
                val ax = rvX[i]; val az = rvZ[i]; val bx = rvX[i + 1] - ax; val bz = rvZ[i + 1] - az
                val d = bx * bx + bz * bz
                val t = min(max(((mx - ax) * bx + (mz - az) * bz) / (if (d == 0.0) 1.0 else d), 0.0), 1.0)
                val dx = mx - ax - bx * t; val dz = mz - az - bz * t
                if (dx * dx + dz * dz < lim * lim) list.add(i)
            }
            if (list.isNotEmpty()) rvGrid[(cx + 32) * 128 + (cz + 32)] = list.toIntArray()
        }
    }

    /** signed distance from the river centre line */
    fun riverSd(x: Double, z: Double): Double {
        val l = rvGrid[(floor(x / RV_CELL).toInt() + 32) * 128 + (floor(z / RV_CELL).toInt() + 32)] ?: return 9999.0
        var bd = 1e18; var bs = 1.0
        for (i in l) {
            val ax = rvX[i]; val az = rvZ[i]; val bx = rvX[i + 1] - ax; val bz = rvZ[i + 1] - az
            val bb = (bx * bx + bz * bz).let { if (it == 0.0) 1.0 else it }
            val t = min(max(((x - ax) * bx + (z - az) * bz) / bb, 0.0), 1.0)
            val ox = x - ax - bx * t; val oz = z - az - bz * t; val d2 = ox * ox + oz * oz
            if (d2 < bd) { bd = d2; bs = if (ox * bz - oz * bx >= 0) 1.0 else -1.0 }
        }
        return bs * sqrt(bd)
    }

    // ---------------- noise ----------------
    private fun fHash(x: Double, y: Double): Double { val h = sin(x * 127.1 + y * 311.7 + FSEED[0] * 0.37) * 43758.5453; return h - floor(h) }
    fun fNoise(x: Double, y: Double): Double {
        val ix = floor(x); val iy = floor(y); val fx = x - ix; val fy = y - iy
        val u = fx * fx * (3 - 2 * fx); val v = fy * fy * (3 - 2 * fy)
        return (fHash(ix, iy) * (1 - u) + fHash(ix + 1, iy) * u) * (1 - v) + (fHash(ix, iy + 1) * (1 - u) + fHash(ix + 1, iy + 1) * u) * v
    }
    private fun fFbm(x: Double, y: Double, o: Int): Double {
        var a = 0.5; var s = 0.0; var f = 1.0; var n = 0.0
        for (i in 0 until o) { s += a * fNoise(x * f + i * 17.3, y * f - i * 9.1); n += a; f *= 2.03; a *= 0.5 }
        return s / n
    }
    private fun fieldNoise(x: Double, z: Double): Double {
        val big = fFbm(x / 420 + FSEED[1], z / 420 + FSEED[2], 3)
        val mass = sstep(0.37, 0.61, big)
        val det = fFbm(x / 150 + FSEED[3], z / 150 - FSEED[1], 3)
        val roll = fFbm(x / 160 - FSEED[2], z / 160 + FSEED[3], 2)
        return min(FIELD_MAX, FIELD_AMP * mass * (0.5 + det) + 3.0 * roll)
    }

    // ---------------- roads ----------------
    /** Distance from the nearest road edge: <0.8 tarmac/kerb, >3 grass. */
    fun roadClearance(x: Double, z: Double) = Roads.clearance(x, z, 1)
    /** like roadClearance but looks 4 cells (~100 m) around, so the terrain fade is smooth */
    fun fieldClear(x: Double, z: Double) = Roads.clearance(x, z, 4)

    // ---------------- height functions ----------------
    /** river bed + sea carving (JS groundH). Real bridges: see Bridges.kt. */
    fun groundH(x: Double, z: Double): Double {
        var d = abs(riverSd(x, z)); var rv = 0.0
        if (d < 33) {
            d += (fNoise(x / 46 + 3.1, z / 46 - 1.7) - 0.5) * 5.0 + (fNoise(x / 13 - 4.2, z / 13 + 8.8) - 0.5) * 1.7
            val t = min(max((d - 11) / 17, 0.0), 1.0)
            rv = if (d >= 28) 0.0 else -RIVER_DEPTH * (1 - t * t * (3 - 2 * t) * (0.88 + 0.12 * t))
        }
        val cd = coastDist(x, z)
        val sea = if (cd < -48) 0.0 else -9 * sstep(-48.0, 88.0, cd)
        val g = min(rv, sea)
        return g
    }

    private fun fieldMask(x: Double, z: Double): Double {
        val cd = coastDist(x, z); if (cd > -62) return 0.0
        var m = 1 - sstep(-150.0, -62.0, cd)
        val rd = abs(riverSd(x, z)); if (rd < 120) m *= sstep(40.0, 120.0, rd)
        if (m <= 0) return 0.0
        val fd = Harbor.flatDist(x, z); if (fd < 60) m *= sstep(0.0, 60.0, fd)     // flat ground round the harbor yard (JS pierLocal term)
        if (m <= 0) return 0.0
        return m * sstep(12.0, 80.0, fieldClear(x, z))
    }

    /** rolling hills / mountains (JS fieldH without dirt track + flat pads) */
    fun fieldH(x: Double, z: Double): Double {
        val m = fieldMask(x, z)
        var h = if (m > 0) fieldNoise(x, z) * m else 0.0
        if (Track.ready) { val o = Track.query(x, z); if (o[0] < Track.HW + Track.BL) h += (o[1] - h) * (1 - sstep(Track.HW, Track.HW + Track.BL, o[0])) }   // grade the ground along the dirt track
        val rc = roadClearance(x, z); if (rc < 14) h *= sstep(4.0, 14.0, rc)
        return h
    }

    /** full terrain height (mesh = groundH + fieldH, same as the JS ground mesh) */
    fun height(x: Double, z: Double) = groundH(x, z) + fieldH(x, z)

    /** Same grip / drag blend as JS surfaceAt(), without dirt track / puddles yet. */
    fun surfaceAt(x: Double, z: Double, out: Surface): Surface {
        val c = roadClearance(x, z)
        val t = min(max((c - 0.8) / 2.2, 0.0), 1.0); val g = smooth(t)
        out.mu = 1.15 - 0.3 * g
        out.rr = 0.028 + 0.06 * g
        val u = min(max((c - 0.3) / 2.4, 0.0), 1.0)
        out.rideY = ROAD_SURF * (1 - smooth(u))
        if (c > 1.5 && Track.ready) {            // packed dirt track: more grip than grass, less than tarmac
            val td = Track.dist(x, z)
            if (td < 3.4) { val k = 1 - sstep(2.1, 3.4, td); out.mu = out.mu * (1 - k) + 1.05 * k; out.rr = out.rr * (1 - k) + 0.032 * k }
        }
        return out
    }
}
