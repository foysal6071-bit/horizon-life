package com.horizonlife.game

import kotlin.math.*

/**
 * Port of the JS roadside border: a rustic post-and-rope fence 2.8 m beside both edges of every road, stopping 10 m before junctions
 * and left out near the river / bridges and the coast. The car knocks posts down (FENCE.breakPost); they stand up again after a lap.
 */
object Fence {
    private const val CELL = 8.0; private const val OFF = 2.8; private const val SP = 3.0

    class Post(val x: Double, val z: Double, val y: Double, val len: Double) {
        var next: Post? = null           // rope towards this post (null = no rope)
        var broken = false; var ang = 0.0; var dx = 0.0; var dz = 0.0; var at = 0.0
    }

    private val grid = HashMap<Long, ArrayList<Post>>()
    private val broken = ArrayList<Post>()
    private fun key(i: Int, j: Int) = (i.toLong() shl 32) xor (j.toLong() and 0xffffffffL)
    fun cell(v: Double) = floor(v / CELL).toInt()
    fun posts(i: Int, j: Int): List<Post>? = grid[key(i, j)]

    init {
        val pts = Roads.all.map { r ->
            val n = ceil(r.length / 3).toInt(); val a = DoubleArray((n + 1) * 2); val t = DoubleArray(4)
            for (k in 0..n) { r.at(if (r.closed) (k % n).toDouble() / n * r.length else min(k.toDouble() / n, 0.99999) * r.length, t); a[k * 2] = t[0]; a[k * 2 + 1] = t[1] }
            a
        }
        fun otherEdge(x: Double, z: Double, ci: Int): Double {
            var best = 1e9
            for (r in Roads.all.indices) {
                if (r == ci) continue
                val a = pts[r]; val hw = Roads.all[r].hw; var k = 0
                while (k < a.size) { val dx = x - a[k]; val dz = z - a[k + 1]; val d = sqrt(dx * dx + dz * dz) - hw; if (d < best) best = d; k += 2 }
            }
            return best
        }
        fun okAt(x: Double, z: Double, ci: Int) =
            otherEdge(x, z, ci) > 10 && abs(World.riverSd(x, z)) >= World.RIVER_WALL + 12 && World.coastDist(x, z) < -52 && !Harbor.near(x, z, 10.0)
        val t = DoubleArray(4)
        Roads.all.forEachIndexed { ci, r ->
            val len = r.length; val n = max(2, (len / SP).roundToInt()); val closed = r.closed; val cnt = if (closed) n else n + 1
            for (sd in intArrayOf(-1, 1)) {
                val posts = arrayOfNulls<Post>(cnt)
                for (k in 0 until cnt) {
                    r.at((if (closed) k.toDouble() / n else min(k.toDouble() / n, 0.99999)) * len, t)
                    val nl = hypot(t[2], t[3]).let { if (it == 0.0) 1.0 else it }
                    val x = t[0] + (-t[3] / nl) * sd * (r.hw + OFF); val z = t[1] + (t[2] / nl) * sd * (r.hw + OFF)
                    if (okAt(x, z, ci)) posts[k] = Post(x, z, World.fieldH(x, z) + 0.05, len)
                }
                for (k in 0 until cnt) {
                    val a = posts[k] ?: continue
                    grid.getOrPut(key(cell(a.x), cell(a.z))) { ArrayList() }.add(a)
                    val b = if (k + 1 < cnt) posts[k + 1] else if (closed) posts[0] else null
                    a.next = b
                }
            }
        }
    }

    private fun breakPost(p: Post, dx: Double, dz: Double, distance: Double) {
        p.broken = true; p.ang = 0.0; p.dx = dx; p.dz = dz; p.at = distance; broken.add(p)
    }

    fun collide(c: CarState, dt: Double, distance: Double) {
        val sH = sin(c.heading); val cH = cos(c.heading); val sw = abs(c.speed) * dt
        val cx = cell(c.x); val cz = cell(c.z)
        for (i in cx - 1..cx + 1) for (j in cz - 1..cz + 1) {
            val g = grid[key(i, j)] ?: continue
            for (p in g) {
                if (p.broken) continue
                val dx = p.x - c.x; val dz = p.z - c.z; val lon = dx * sH + dz * cH; val lat = dx * cH - dz * sH
                if (abs(lat) > 1.02 || lon > 2.3 + sw || lon < -2.2 - sw) continue
                val d = hypot(dx, dz).let { if (it == 0.0) 0.001 else it }
                breakPost(p, dx / d, dz / d, distance); c.speed *= 0.93; Collision.thuds++
            }
            // the rope between two standing posts crossing the car body knocks down the nearer post
            for (p in g) {
                if (p.broken) continue
                val q = p.next ?: continue; if (q.broken) continue
                val x0 = (p.x - c.x) * cH - (p.z - c.z) * sH; val y0 = (p.x - c.x) * sH + (p.z - c.z) * cH
                val x1 = (q.x - c.x) * cH - (q.z - c.z) * sH; val y1 = (q.x - c.x) * sH + (q.z - c.z) * cH
                val bx = 1.12; val yMin = -2.3 - sw; val yMax = 2.5 + sw
                var t0 = 0.0; var t1 = 1.0; val ddx = x1 - x0; val ddy = y1 - y0; var hit = true
                fun clip(pp: Double, qq: Double) {
                    if (pp == 0.0) { if (qq < 0) hit = false; return }
                    val t = qq / pp
                    if (pp < 0) { if (t > t1) hit = false else if (t > t0) t0 = t } else { if (t < t0) hit = false else if (t < t1) t1 = t }
                }
                clip(-ddx, x0 + bx); clip(ddx, bx - x0); clip(-ddy, y0 - yMin); clip(ddy, yMax - y0)
                if (!hit || t0 > t1) continue
                val dp = hypot(p.x - c.x, p.z - c.z); val dq = hypot(q.x - c.x, q.z - c.z); val kp = if (dp <= dq) p else q
                val ex = kp.x - c.x; val ez = kp.z - c.z; val dd = hypot(ex, ez).let { if (it == 0.0) 0.001 else it }
                breakPost(kp, ex / dd, ez / dd, distance); c.speed *= 0.95; Collision.thuds++
                break
            }
        }
        for (k in broken.indices.reversed()) {                      // fall animation + restore after a full lap
            val p = broken[k]; p.ang = min(1.5, p.ang + dt * 5.0)
            if (distance - p.at > p.len && hypot(p.x - c.x, p.z - c.z) > 40) { p.broken = false; p.ang = 0.0; broken.removeAt(k) }
        }
    }
}
