package com.horizonlife.game

import kotlin.math.*

/**
 * Port of the JS street lamps: one wooden pole every ~44 m beside each road (outer side, arm pointing over the road),
 * never on another road or beside the river; solid poles (car box vs pole circle) that lean when hit hard (lampCollide).
 */
object Lamps {
    const val H = 6.5
    private const val POLE_R = 0.16; private const val HL = 2.3; private const val HW = 0.97; private const val LIM2 = 3.6 * 3.6

    lateinit var x: DoubleArray; lateinit var z: DoubleArray; lateinit var ang: DoubleArray
    lateinit var tilt: DoubleArray; lateinit var tiltDir: DoubleArray
    lateinit var by: DoubleArray                         // deck lift where a lamp stands on a bridge approach
    val count get() = x.size

    init {
        val roadPts = Roads.all.map { r ->
            val n = ceil(r.length / 2).toInt(); val a = DoubleArray((n + 1) * 2); val t = DoubleArray(4)
            for (k in 0..n) { r.at(if (r.closed) (k % n).toDouble() / n * r.length else min(k.toDouble() / n, 0.99999) * r.length, t); a[k * 2] = t[0]; a[k * 2 + 1] = t[1] }
            a
        }
        fun blocked(px: Double, pz: Double, ci: Int): Boolean {
            if (abs(World.riverSd(px, pz)) < World.RIVER_WALL + 3) return true
            for (r in Roads.all.indices) {
                if (r == ci) continue
                val a = roadPts[r]; val lim = Roads.all[r].hw + 3.5; val l2 = lim * lim
                var k = 0
                while (k < a.size) { val dx = px - a[k]; val dz = pz - a[k + 1]; if (dx * dx + dz * dz < l2) return true; k += 2 }
            }
            return false
        }
        val lx = ArrayList<Double>(); val lz = ArrayList<Double>(); val la = ArrayList<Double>(); val t = DoubleArray(4)
        Roads.all.forEachIndexed { ci, r ->
            val n = floor(r.length / 44).toInt()
            for (i in 0 until n) {
                r.at(i.toDouble() / n * r.length, t)
                var nx = -t[3]; var nz = t[2]; val nl = hypot(nx, nz).let { if (it == 0.0) 1.0 else it }; nx /= nl; nz /= nl
                if (nx * t[0] + nz * t[1] < 0) { nx = -nx; nz = -nz }                    // outer side of the ring
                val off = r.hw + 1.3; val px = t[0] + nx * off; val pz = t[1] + nz * off
                if (blocked(px, pz, ci)) continue
                lx.add(px); lz.add(pz); la.add(atan2(nz, nx))
            }
        }
        x = lx.toDoubleArray(); z = lz.toDoubleArray(); ang = la.toDoubleArray()
        tilt = DoubleArray(x.size); tiltDir = DoubleArray(x.size)
        by = DoubleArray(x.size) { Bridges.lift(x[it], z[it], 9.0) }
    }

    /** JS lampCollide(): the car's body (a box) is pushed out of each pole; a hard hit leaves the pole leaning away */
    fun collide(c: CarState) {
        val sH = sin(c.heading); val cH = cos(c.heading)
        for (i in 0 until count) {
            val dx = x[i] - c.x; val dz = z[i] - c.z; if (dx * dx + dz * dz > LIM2) continue
            val f = dx * sH + dz * cH; val l = dx * cH - dz * sH                         // pole in the car's frame (f forward, l left)
            val cf = min(max(f, -HL), HL); val cl = min(max(l, -HW), HW); val vf = f - cf; val vl = l - cl; val d = hypot(vf, vl)
            val nf: Double; val nl: Double; val pen: Double
            if (d > 1e-4) { if (d >= POLE_R) continue; nf = -vf / d; nl = -vl / d; pen = POLE_R - d }
            else {
                val ef = HL - abs(f); val el = HW - abs(l)
                if (ef < el) { nf = if (f > 0) -1.0 else 1.0; nl = 0.0; pen = ef + POLE_R } else { nf = 0.0; nl = if (l > 0) -1.0 else 1.0; pen = el + POLE_R }
            }
            val nx = nf * sH + nl * cH; val nz = nf * cH - nl * sH                        // world normal: from the pole towards the car
            val wx = c.speed * sH + c.vy * cH; val wz = c.speed * cH - c.vy * sH; val vn = -(wx * nx + wz * nz)
            c.x += nx * pen; c.z += nz * pen
            Collision.bounceOff(c, nx, nz, 0.28, 0.22)
            if (vn > 0.5 && Collision.cooldown <= 0) {
                Collision.cooldown = 0.6; Collision.hits++; Collision.thuds++
                if (vn > 4) { tilt[i] = min(0.16, tilt[i] + 0.012 * vn); tiltDir[i] = atan2(-nz, -nx) }
            }
        }
    }
}
