package com.horizonlife.game

import kotlin.math.*
import kotlin.random.Random

/**
 * Port of the JS buildGardens(): flower gardens in bands along both sides of every road (behind the rope fence), one species per patch
 * (marigold 45 % / daffodil 30 % / tulip 25 %), ragged ends, crest-limited depth. The raster is built once on a background thread;
 * plants are bucketed into 32 m cells. One instance = a clump of 3 flowers (gl/ScatterRenderer draws it).
 * Simplified vs JS: clump meshes are low-poly, no stone border, no brown soil tint of the ground, no far LOD.
 */
object Gardens {
    const val CELLC = 32.0
    const val F = Scatter.F
    private const val R0 = -720.0; private const val CS = 2.0; private const val NR = 720
    private const val BUDGET = 70000

    /** per bucket: three FloatArrays (marigold, daffodil, tulip) with F floats per instance */
    class Bucket(val lists: Array<FloatArray>)
    private val buckets = HashMap<Long, Bucket>()
    @Volatile var ready = false
        private set
    @Volatile private var started = false
    private fun key(cx: Int, cz: Int) = (cx.toLong() shl 32) xor (cz.toLong() and 0xffffffffL)
    fun bucket(cx: Int, cz: Int): Bucket? = if (ready) buckets[key(cx, cz)] else null

    private val COL = arrayOf(
        arrayOf(floatArrayOf(1f, .50f, .08f), floatArrayOf(1f, .78f, .14f)),          // marigold orange 75 % / gold 25 %
        arrayOf(floatArrayOf(1f, .86f, .16f), floatArrayOf(.98f, .95f, .78f)),        // daffodil yellow 85 % / bicolor-white 15 %
        arrayOf(floatArrayOf(.85f, .08f, .12f), floatArrayOf(.95f, .42f, .60f), floatArrayOf(.80f, .10f, .55f)))  // tulip red / pink / magenta
    private val W = arrayOf(doubleArrayOf(.75, .25), doubleArrayOf(.85, .15), doubleArrayOf(.40, .35, .25))
    private val SMIN = doubleArrayOf(1.2, 1.15, 1.0); private val SMAX = doubleArrayOf(1.7, 1.6, 1.4)

    fun start() {
        if (started) return; started = true
        Thread({ try { build() } catch (e: Throwable) { android.util.Log.e("Gardens", "garden build failed", e) } }, "gardens").apply { priority = Thread.MIN_PRIORITY; start() }
    }

    private fun inTrunk(x: Double, z: Double, r: Double): Boolean {
        val cx = floor(x / TreeField.CH).toInt(); val cz = floor(z / TreeField.CH).toInt()
        for (i in cx - 1..cx + 1) for (j in cz - 1..cz + 1) {
            val t = TreeField.chunk(i, j); var k = 0
            while (k < t.size) { val dx = x - t[k]; val dz = z - t[k + 2]; if (dx * dx + dz * dz < r * r) return true; k += 5 }
        }
        return false
    }

    private fun build() {
        val rnd = Random(48151)
        val ras = ByteArray(NR * NR)
        fun cell(x: Double, z: Double): Int { val i = floor((x - R0) / CS).toInt(); val j = floor((z - R0) / CS).toInt(); return if (i < 0 || j < 0 || i >= NR || j >= NR) -1 else j * NR + i }
        fun okCell(x: Double, z: Double) = World.coastDist(x, z) < -60 && abs(World.riverSd(x, z)) >= 27 && World.roadClearance(x, z) >= 5.0 &&
            !Harbor.near(x, z, 6.0) && Track.dist(x, z) >= 9 && !inTrunk(x, z, 3.0)
        val START = 5.3; val CAP = 88.0; val MINDEP = 26.0; val STEP = 1.5
        fun crest(px: Double, pz: Double, nx: Double, nz: Double): Double {
            var hmax = -1e9; var dm = MINDEP; var d = START
            while (d <= CAP) { val h = World.fieldH(px + nx * d, pz + nz * d); if (h > hmax + .02) { hmax = h; dm = d } else if (d > dm + 14) break; d += 3.0 }
            return min(CAP, max(MINDEP, dm + 4))
        }
        val o = DoubleArray(4)
        for (road in Roads.all) {
            val len = road.length; val hw = road.hw; val nC = ceil(len / 6).toInt() + 1
            class Patch(val a: Double, val b: Double, val sp: Int)
            class Side(val side: Int, val sm: DoubleArray, val patches: List<Patch>)
            val sides = intArrayOf(-1, 1).map { side ->
                val dC = DoubleArray(nC)
                for (i in 0 until nC) {
                    road.at(min(i * 6.0, len * .99999), o); val nl = hypot(o[2], o[3]).let { if (it == 0.0) 1.0 else it }
                    val nx = -o[3] / nl * side; val nz = o[2] / nl * side
                    dC[i] = crest(o[0] + nx * hw, o[1] + nz * hw, nx, nz)
                }
                val sm = DoubleArray(nC) { i -> var a = 0.0; var n = 0; for (k in -3..3) { val q = i + k; if (q in 0 until nC) { a += dC[q]; n++ } }; a / n }
                val patches = ArrayList<Patch>(); var s = rnd.nextDouble() * 40; var last = -1
                while (s < len) {
                    val L = 60 + rnd.nextDouble() * 80; val rr = rnd.nextDouble(); var sp = if (rr < .45) 0 else if (rr < .75) 1 else 2
                    if (sp == last) sp = if (sp == 0) 1 else 0; last = sp
                    patches.add(Patch(s, s + L, sp)); s += L + 12 + rnd.nextDouble() * 5
                }
                Side(side, sm, patches)
            }
            var s = 0.0
            while (s < len) {
                road.at(min(s, len * .99999), o); val nl = hypot(o[2], o[3]).let { if (it == 0.0) 1.0 else it }; val nx = -o[3] / nl; val nz = o[2] / nl
                val px = o[0]; val pz = o[1]
                for (sd in sides) {
                    val f = s / 6; val i0 = min(nC - 1, floor(f).toInt()); val i1 = min(nC - 1, i0 + 1); val dep0 = sd.sm[i0] + (sd.sm[i1] - sd.sm[i0]) * (f - i0)
                    val dep = dep0 * (.85 + .3 * World.fNoise(s / 22 + sd.side * 7, 3.3))
                    var off = START
                    while (off <= dep) {
                        val jit = (World.fNoise(off / 10 + sd.side * 5, s / 90 + 1.7) - .5) * 5
                        val pat = sd.patches.firstOrNull { s >= it.a + jit && s <= it.b + jit }
                        if (pat != null) {
                            val x = px + nx * sd.side * (hw + off); val z = pz + nz * sd.side * (hw + off); val ci = cell(x, z)
                            if (ci >= 0 && ras[ci].toInt() == 0 && okCell(x, z)) ras[ci] = (pat.sp + 1).toByte()
                        }
                        off += STEP
                    }
                }
                s += STEP
            }
        }
        var cells = 0; for (b in ras) if (b.toInt() != 0) cells++
        val area = cells * CS * CS
        val spc = max(1.15, min(3.4, sqrt(area / BUDGET)))
        val scMul = min(1.8, max(1.0, spc / 1.3))
        val tmp = HashMap<Long, Array<ArrayList<Float>>>()
        fun pick(sp: Int): Int { var r = rnd.nextDouble(); val w = W[sp]; for (i in w.indices) { r -= w[i]; if (r <= 0) return i }; return w.size - 1 }
        var gx = R0
        while (gx < -R0) {
            var gz = R0
            while (gz < -R0) {
                val x = gx + rnd.nextDouble() * spc; val z = gz + rnd.nextDouble() * spc; val ci = cell(x, z)
                if (ci >= 0 && ras[ci].toInt() != 0) {
                    val sp = ras[ci] - 1; val v = .86f + rnd.nextFloat() * .26f; val c = COL[sp][pick(sp)]
                    val sc = (SMIN[sp] + rnd.nextDouble() * (SMAX[sp] - SMIN[sp])) * scMul; val sy = sc * (.8 + rnd.nextDouble() * .4)
                    val l = tmp.getOrPut(key(floor(x / CELLC).toInt(), floor(z / CELLC).toInt())) { Array(3) { ArrayList<Float>() } }[sp]
                    l.add(x.toFloat()); l.add((World.fieldH(x, z) - .05).toFloat()); l.add(z.toFloat()); l.add(sc.toFloat()); l.add(sy.toFloat()); l.add(sc.toFloat())
                    l.add((rnd.nextDouble() * 6.283).toFloat()); l.add(c[0] * v); l.add(c[1] * v * .98f); l.add(c[2] * v * .95f)
                }
                gz += spc
            }
            gx += spc
        }
        val out = HashMap<Long, Bucket>()
        var total = 0
        for ((k, v) in tmp) { out[k] = Bucket(Array(3) { v[it].toFloatArray() }); total += v[0].size + v[1].size + v[2].size }
        synchronized(buckets) { buckets.putAll(out) }
        android.util.Log.i("Gardens", "cells=$cells area=${area.roundToInt()} m2 spacing=${"%.2f".format(spc)} clumps=${total / F}")
        ready = true
    }
}
