package com.horizonlife

import android.app.Activity
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import kotlin.math.max
import com.horizonlife.game.EngineSound
import com.horizonlife.game.Game
import com.horizonlife.game.Settings
import com.horizonlife.gl.GameRenderer
import com.horizonlife.ui.ControlsView

class MainActivity : Activity() {
    private lateinit var gl: GLSurfaceView
    private val game = Game()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Settings.load(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val renderer = GameRenderer(game, this)
        gl = GLSurfaceView(this).apply {
            setEGLContextClientVersion(3)
            setEGLConfigChooser(8, 8, 8, 8, 24, 0)
            setRenderer(renderer)
            renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
        }
        val root = FrameLayout(this)
        root.addView(gl)
        rootView = root
        root.addView(ControlsView(this, game, { applyResolution() }) { renderer.fps })
        setContentView(root)
        hideSystemUi()
        root.post { applyResolution(); game.cam.applySettings(game.car, game.pose) }
    }

    private lateinit var rootView: FrameLayout

    /** Settings > Graphics > Resolution: render at native size * scale and let the GPU upscale to the screen. */
    private fun applyResolution() {
        runOnUiThread {
            val w = rootView.width; val h = rootView.height; if (w == 0 || h == 0) return@runOnUiThread
            val k = Settings.resScale
            if (k >= 0.99) gl.holder.setSizeFromLayout() else gl.holder.setFixedSize(max(1, (w * k).toInt()), max(1, (h * k).toInt()))
        }
    }

    private fun hideSystemUi() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    }
    override fun onWindowFocusChanged(hasFocus: Boolean) { super.onWindowFocusChanged(hasFocus); if (hasFocus) hideSystemUi() }
    override fun onPause() { super.onPause(); gl.onPause(); EngineSound.stop() }
    override fun onResume() { super.onResume(); gl.onResume(); EngineSound.start(this) }
}
