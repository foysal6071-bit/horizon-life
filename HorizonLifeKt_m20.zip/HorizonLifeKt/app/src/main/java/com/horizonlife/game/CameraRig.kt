package com.horizonlife.game

import kotlin.math.*

/** Port of the JS camera (camDesired / updateCamera): chase / close / hood / bumper, drag-orbit, auto return, speed FOV, shake. */
class CameraRig {
    var yaw = 0.0; var pitch = Settings.camPitch; var dist = Settings.camDist; var heading = 0.0; var idle = 99.0
    var dragging = false
    var fov = Settings.fov
    val pos = DoubleArray(3); val target = DoubleArray(3)
    private val off = DoubleArray(3)
    private var camExtra = 0.0

    private fun clamp(v: Double, a: Double, b: Double) = min(max(v, a), b)
    private val mode get() = Settings.camMode
    /** first-person views (hood / bumper) */
    val isFP get() = mode == Settings.CamMode.HOOD || mode == Settings.CamMode.BUMPER
    /** bumper cam hides the body so nothing blocks the view */
    val hideCar get() = mode == Settings.CamMode.BUMPER

    private fun desired(s: CarState, c: CarPose, out: DoubleArray) {
        if (isFP) {
            val fw = if (mode == Settings.CamMode.HOOD) 0.95 else 2.05; val up = if (mode == Settings.CamMode.HOOD) 1.18 else 0.55
            out[0] = c.x + sin(s.heading) * fw; out[2] = c.z + cos(s.heading) * fw
            out[1] = max(c.y + up, World.fieldH(out[0], out[2]) + 0.4)
            return
        }
        val a = heading + PI + yaw; val cp = cos(pitch)
        val d = dist * (if (mode == Settings.CamMode.CLOSE) 0.72 else 1.0) + camExtra
        out[0] = c.x + sin(a) * cp * d
        out[2] = c.z + cos(a) * cp * d
        out[1] = max(c.y + 1.4 + sin(pitch) * d, max(0.7, World.height(out[0], out[2]) + 1.3))
    }

    /** settings sliders / mode buttons changed: take the new base values and re-snap */
    fun applySettings(s: CarState, c: CarPose) { dist = Settings.camDist; pitch = Settings.camPitch; yaw = 0.0; snap(s, c) }

    fun snap(s: CarState, c: CarPose) {
        heading = s.heading; yaw = 0.0; pitch = Settings.camPitch
        val d = DoubleArray(3); desired(s, c, d)
        off[0] = d[0] - c.x; off[1] = d[1] - c.y; off[2] = d[2] - c.z
        pos[0] = d[0]; pos[1] = d[1]; pos[2] = d[2]
        target[0] = c.x; target[1] = c.y + 1.4 + Settings.sky; target[2] = c.z
    }

    fun update(s: CarState, c: CarPose, dt: Double) {
        val slipA = if (s.speed > 4) atan2(s.vy, s.speed) * 0.6 else 0.0
        var dh = s.heading + slipA - heading; dh = atan2(sin(dh), cos(dh))
        heading += dh * (1 - 0.02.pow(dt))
        idle += dt
        val k = min(abs(s.speed) / (220 / 3.6), 1.0); val kk = k * k
        val spF = Settings.speedFov
        camExtra += (kk * (0.5 + spF * 0.06) - camExtra) * (1 - exp(-3 * dt))
        val fpFov = if (isFP) (if (mode == Settings.CamMode.HOOD) 8.0 else 12.0) else 0.0      // first-person needs a wider lens
        fov += ((Settings.fov + fpFov + kk * spF * (if (isFP) 0.7 else 1.0)) - fov) * (1 - exp(-4 * dt))
        if (idle > 2.5 && !dragging) {
            yaw = atan2(sin(yaw), cos(yaw))
            val kr = 1 - 0.1.pow(dt)
            yaw += (0 - yaw) * kr; pitch += (Settings.camPitch - pitch) * kr
        }
        val d = DoubleArray(3); desired(s, c, d)
        val f = 1 - exp(-(if (isFP) 40.0 else 12.0) * dt)
        off[0] += (d[0] - c.x - off[0]) * f; off[1] += (d[1] - c.y - off[1]) * f; off[2] += (d[2] - c.z - off[2]) * f
        pos[0] = c.x + off[0]; pos[1] = c.y + off[1]; pos[2] = c.z + off[2]
        if (isFP) {   // look along the car heading (+ your drag), slightly down the road
            val a = s.heading + yaw; val pp = (pitch - Settings.camPitch) * 1.2 - 0.02
            target[0] = pos[0] + sin(a) * 40; target[1] = pos[1] + tan(pp) * 40; target[2] = pos[2] + cos(a) * 40
        } else {
            val lead = k * k * 3.5
            target[0] = c.x + sin(s.heading) * lead
            target[1] = c.y + 1.4 + Settings.sky
            target[2] = c.z + cos(s.heading) * lead
        }
        if (Settings.shake > 0) {   // subtle high-speed rumble
            val a = kk * 0.035 * Settings.shake; val tt = System.nanoTime() * 1e-9
            pos[0] += sin(tt * 37.1) * a; pos[1] += sin(tt * 43.7 + 1.3) * a; pos[2] += sin(tt * 31.9 + 2.1) * a * 0.6
        }
    }

    fun onDrag(dx: Float, dy: Float) {
        idle = 0.0
        yaw -= dx * 0.009; pitch = clamp(pitch + dy * 0.0075, 0.03, 1.4)
    }
    fun onPinch(scale: Double) { idle = 0.0; dist = clamp(dist * scale, 3.0, 32.0); Settings.camDist = dist.coerceIn(3.5, 14.0) }
}

/** Where the car body sits in the world (after ground follow). */
class CarPose { var x = 0.0; var y = 0.0; var z = 0.0 }
