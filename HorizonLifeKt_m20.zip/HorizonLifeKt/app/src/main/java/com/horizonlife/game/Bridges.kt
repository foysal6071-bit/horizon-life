package com.horizonlife.game

import kotlin.math.*

/**
 * Port of JS buildBridges() data + bridgeLift() + riverCollide(): wherever a ring road crosses the river (|riverSd| < RIVER_WALL+5)
 * a timber bridge follows the road centre line, arched BRIDGE_RISE m at mid-span. Mesh: gl/BridgeMesh.kt.
 */
object Bridges {
    const val RISE = 1.2
    fun arch(f: Double): Double { val q = sin(PI * min(max(f, 0.0), 1.0)); return RISE * q * q }
    fun archD(f: Double) = RISE * PI * sin(2 * PI * min(max(f, 0.0), 1.0))

    class Bridge(val road: Roads.Road, val s0: Double, val L: Double, val hw: Double,
                 val px: DoubleArray, val pz: DoubleArray, val tx: DoubleArray, val tz: DoubleArray,
                 val h: DoubleArray, val sl: DoubleArray) {
        val n get() = px.size
        val clampW = hw - 0.2; val capW = hw + 1.0
        val cx = px[px.size shr 1]; val cz = pz[pz.size shr 1]
        val r2: Double
        init { var r = 0.0; for (i in px.indices) r = max(r, hypot(px[i] - cx, pz[i] - cz)); r2 = (r + hw + 4) * (r + hw + 4) }
    }

    val list = ArrayList<Bridge>()
    var cur: Bridge? = null

    init { build(Roads.roadA); build(Roads.roadB) }

    private fun build(road: Roads.Road) {
        val hw = road.hw; val len = road.length; val S = ceil(len / 1.2).toInt(); val t = DoubleArray(4)
        val inside = BooleanArray(S) { road.at(it.toDouble() / S * len, t); abs(World.riverSd(t[0], t[1])) < World.RIVER_WALL + 5 }
        val s0 = inside.indexOfFirst { !it }; if (s0 < 0) return
        var i = 0
        while (i < S) {
            if (!inside[(s0 + i) % S]) { i++; continue }
            var j = i; while (j < S && inside[(s0 + j) % S]) j++
            val a = (s0 + i).toDouble() / S * len - 2.0; val b = (s0 + j).toDouble() / S * len + 2.0
            val L = b - a; val N = max(8, ceil(L / 1.5).toInt())
            val px = DoubleArray(N + 1); val pz = DoubleArray(N + 1); val tx = DoubleArray(N + 1); val tz = DoubleArray(N + 1)
            val h = DoubleArray(N + 1); val sl = DoubleArray(N + 1)
            for (k in 0..N) {
                road.at(a + L * k / N, t); px[k] = t[0]; pz[k] = t[1]
                val nl = hypot(t[2], t[3]).let { if (it == 0.0) 1.0 else it }; tx[k] = t[2] / nl; tz[k] = t[3] / nl
                h[k] = arch(k.toDouble() / N); sl[k] = archD(k.toDouble() / N) / L
            }
            list.add(Bridge(road, a, L, hw, px, pz, tx, tz, h, sl))
            i = j
        }
    }

    /** true if arc length s of `road` lies on a bridge (the flat road mesh is skipped there) */
    fun inSpan(road: Roads.Road, s: Double): Boolean {
        for (b in list) {
            if (b.road !== road) continue
            var rel = (s - b.s0) % road.length; if (rel < 0) rel += road.length
            if (rel <= b.L) return true
        }
        return false
    }

    // ---- local frame: nearest centre-line sample -> along (lal) / across (lac) offsets ----
    private var li = 0; private var lal = 0.0; private var lac = 0.0
    private fun local(b: Bridge, x: Double, z: Double) {
        var bi = 0; var bd = 1e18
        for (i in 0 until b.n) { val dx = x - b.px[i]; val dz = z - b.pz[i]; val d = dx * dx + dz * dz; if (d < bd) { bd = d; bi = i } }
        val dx = x - b.px[bi]; val dz = z - b.pz[bi]
        li = bi; lal = dx * b.tx[bi] + dz * b.tz[bi]; lac = -dx * b.tz[bi] + dz * b.tx[bi]
    }

    /** results of the last lift(): slope per metre along (bTx,bTz) */
    var bS = 0.0; var bTx = 0.0; var bTz = 0.0

    /** height of the bridge deck above normal road level at (x,z); 0 off the bridge. lat = widest sideways offset that still counts */
    fun lift(x: Double, z: Double, lat: Double = 0.0): Double {
        bS = 0.0
        for (b in list) {
            val dx = x - b.cx; val dz = z - b.cz; if (dx * dx + dz * dz > b.r2) continue
            local(b, x, z); val i = li; val n = b.n
            if ((i == 0 && lal < 0) || (i == n - 1 && lal > 0)) continue
            if (abs(lac) > (if (lat != 0.0) lat else b.capW)) continue
            val j = if (lal >= 0) min(i + 1, n - 1) else max(i - 1, 0)
            val seg = hypot(b.px[j] - b.px[i], b.pz[j] - b.pz[i]).let { if (it == 0.0) 1.0 else it }
            val u = min(1.0, abs(lal) / seg)
            bS = b.sl[i] + (b.sl[j] - b.sl[i]) * u; bTx = b.tx[i]; bTz = b.tz[i]
            return b.h[i] + (b.h[j] - b.h[i]) * u
        }
        return 0.0
    }

    private fun dampVel(c: CarState, k: Double) { c.speed *= k; c.vy *= k; c.yaw *= sqrt(k) }

    /** sideways reach of the car given the road direction: a yawed car is wider */
    private fun reach(c: CarState, tx: Double, tz: Double): Double {
        val sH = sin(c.heading); val cH = cos(c.heading)
        return 1.05 * abs(sH * tx + cH * tz) + 2.4 * abs(sH * tz - cH * tx)
    }

    /** JS riverCollide(): invisible walls along the bridge rails + the river banks */
    fun riverCollide(c: CarState) {
        cur?.let { b ->
            local(b, c.x, c.z); val n = b.n
            val beyond = (li == 0 && lal < 0) || (li == n - 1 && lal > 0)
            if (!beyond) {
                val lim = max(0.0, min(b.clampW, b.clampW + 1.5 - reach(c, b.tx[li], b.tz[li])))
                if (abs(lac) > lim) {
                    val nac = sign(lac) * lim; val q = li
                    c.x += (nac - lac) * (-b.tz[q]); c.z += (nac - lac) * b.tx[q]
                    val sH = sin(c.heading); val cH = cos(c.heading)
                    var wx = c.speed * sH + c.vy * cH; var wz = c.speed * cH - c.vy * sH
                    val nx = -b.tz[q] * sign(lac); val nz = b.tx[q] * sign(lac); val vn = wx * nx + wz * nz
                    if (vn > 0) { wx -= 1.15 * vn * nx; wz -= 1.15 * vn * nz; c.speed = wx * sH + wz * cH; c.vy = wx * cH - wz * sH }
                    dampVel(c, 0.97)
                }
                return
            }
            cur = null
        }
        for (b in list) {
            local(b, c.x, c.z); val n = b.n
            val beyond = (li == 0 && lal < 0) || (li == n - 1 && lal > 0)
            if (!beyond && abs(lac) < b.capW) { cur = b; return }
            if (!beyond) {   // alongside the bridge, outside the rails
                val out = b.clampW + 1.65 + 0.12 + reach(c, b.tx[li], b.tz[li])
                if (abs(lac) < out) {
                    val nac = (if (lac == 0.0) 1.0 else sign(lac)) * out; val q = li
                    c.x += (nac - lac) * (-b.tz[q]); c.z += (nac - lac) * b.tx[q]; dampVel(c, 0.97)
                }
            }
        }
        val sd = World.riverSd(c.x, c.z)
        if (abs(sd) < World.RIVER_WALL) {
            val e = 0.5; var gx = World.riverSd(c.x + e, c.z) - World.riverSd(c.x - e, c.z); var gz = World.riverSd(c.x, c.z + e) - World.riverSd(c.x, c.z - e)
            val gl = hypot(gx, gz); if (gl < 1e-6) { gx = 0.0; gz = 1.0 } else { gx /= gl; gz /= gl }
            val target = (if (sd >= 0) 1.0 else -1.0) * World.RIVER_WALL
            c.x += (target - sd) * gx; c.z += (target - sd) * gz; dampVel(c, 0.96)
        }
    }
}
