package com.horizonlife.game

import kotlin.math.*

/** Port of the JS collision helpers: bounceOff(), hit cooldown / bump counter, checkCollisions() (lamps + world edge). */
object Collision {
    var cooldown = 0.0
    var hits = 0
    var thuds = 0                      // every impact sound (lamps count as a bump + thud, fence posts only a thud)
    private const val LIM = 960.0          // invisible wall at the edge of the world

    /** reflect the world-space velocity off a surface with normal (nx,nz); a bit of scrub along the wall */
    fun bounceOff(c: CarState, nx: Double, nz: Double, e: Double, fric: Double) {
        val sH = sin(c.heading); val cH = cos(c.heading)
        var wx = c.speed * sH + c.vy * cH; var wz = c.speed * cH - c.vy * sH
        val vn = wx * nx + wz * nz
        if (vn >= 0) return
        wx -= (1 + e) * vn * nx; wz -= (1 + e) * vn * nz
        val tx = -nz; val tz = nx; val vt = wx * tx + wz * tz
        wx -= vt * fric * tx; wz -= vt * fric * tz
        c.speed = wx * sH + wz * cH; c.vy = wx * cH - wz * sH
        c.yaw *= 0.6
    }

    fun update(c: CarState, dt: Double) {
        cooldown = max(0.0, cooldown - dt)
        Lamps.collide(c)
        Obstacles.collide(c)                       // tree trunks (JS collideWith roadObstacles)
        Obstacles.coastGuard(c)                    // wall 52 m inside the coast
        val r = hypot(c.x, c.z)
        if (r > LIM) { c.x *= LIM / r; c.z *= LIM / r; c.speed *= 0.5; c.vy *= 0.5; c.yaw *= sqrt(0.5) }
    }
}
