package com.horizonlife.game

import kotlin.math.*

/**
 * Port of updateEnv(): day/night cycle (5 min day + 3 min night). The JS build freezes the clock at 13:00 (tod = 175 s);
 * `running` = false reproduces that, the on-screen sun/moon button turns the cycle on.  Rain/thunder is still off, as in the JS.
 */
class Environment {
    companion object {
        const val DAY_S = 300.0; const val NIGHT_S = 180.0; const val CYC = DAY_S + NIGHT_S
        private fun ss(a: Double, b: Double, x: Double): Double { val t = min(1.0, max(0.0, (x - a) / (b - a))); return t * t * (3 - 2 * t) }
        private fun mix(a: DoubleArray, b: DoubleArray, t: Double) = DoubleArray(3) { a[it] + (b[it] - a[it]) * t }
        private val SKY_DAY = arrayOf(doubleArrayOf(.70, .88, .97), doubleArrayOf(.52, .78, .98), doubleArrayOf(.30, .58, .92))
        private val SKY_DUSK = arrayOf(doubleArrayOf(1.0, .52, .26), doubleArrayOf(.62, .38, .56), doubleArrayOf(.17, .21, .47))
        private val SKY_NIGHT = arrayOf(doubleArrayOf(.035, .05, .10), doubleArrayOf(.012, .02, .055), doubleArrayOf(.004, .008, .025))
    }

    @Volatile var running = false
    var tod = 175.0
    var timeScale = 20.0                         // cycle speed when running (JS real-time would be 1)

    val sunDir = FloatArray(3); val moonDir = FloatArray(3)
    val hor = FloatArray(3); val mid = FloatArray(3); val zen = FloatArray(3)
    val cloudLit = FloatArray(3); val cloudShade = FloatArray(3)
    /** JS skyU.uCubeTint: light of the photo cubemap (day / golden sunset / moonlit night) */
    val cubeTint = FloatArray(3)
    /** the real sun direction (sunDir becomes the moon at night, for lighting only) */
    val skySun = FloatArray(3)
    val fog = FloatArray(3); val sunCol = FloatArray(3); val ambCol = FloatArray(3)
    var night = 0f; var twilight = 0f; var day = 1f
    /** 0..1: how dark it is (headlights etc. later) */
    val isDark get() = night > 0.5f

    init { update(0.0) }

    fun toggle() { running = !running }

    fun update(dt: Double) {
        if (running) tod = (tod + dt * timeScale) % CYC
        val th = if (tod < DAY_S) PI * tod / DAY_S else PI + PI * (tod - DAY_S) / NIGHT_S
        var sx = -cos(th) * .85; var sy = sin(th) * .95; var sz = .45; var l = sqrt(sx * sx + sy * sy + sz * sz)
        sx /= l; sy /= l; sz /= l
        sunDir[0] = sx.toFloat(); sunDir[1] = sy.toFloat(); sunDir[2] = sz.toFloat()
        if (tod >= DAY_S) {
            val m = PI * (tod - DAY_S) / NIGHT_S
            var mx = -cos(m) * .8; var my = sin(m) * .62; var mz = -.55; l = sqrt(mx * mx + my * my + mz * mz)
            moonDir[0] = (mx / l).toFloat(); moonDir[1] = (my / l).toFloat(); moonDir[2] = (mz / l).toFloat()
        } else { moonDir[0] = 0f; moonDir[1] = -1f; moonDir[2] = 0f }
        for (k in 0..2) skySun[k] = sunDir[k]
        val e = sy
        val dayW = ss(-.10, .32, e); val tw = exp(-((e - .03) / .15).pow(2)) * .9; val nt = 1 - ss(-.22, -.02, e)
        day = dayW.toFloat(); twilight = tw.toFloat(); night = nt.toFloat()
        val sk = Array(3) { mix(mix(SKY_NIGHT[it], SKY_DAY[it], dayW), SKY_DUSK[it], tw) }
        for (k in 0..2) { hor[k] = sk[0][k].toFloat(); mid[k] = sk[1][k].toFloat(); zen[k] = sk[2][k].toFloat() }
        val fg = mix(sk[0], doubleArrayOf(.70, .88, .97), dayW * (1 - tw))
        for (k in 0..2) fog[k] = fg[k].toFloat()
        val cl = mix(mix(doubleArrayOf(.07, .09, .16), doubleArrayOf(1.0, 1.0, 1.0), dayW), doubleArrayOf(1.0, .62, .45), tw)
        val cs = mix(mix(doubleArrayOf(.025, .035, .07), doubleArrayOf(.86, .91, .97), dayW), doubleArrayOf(.45, .32, .42), tw)
        for (k in 0..2) { cloudLit[k] = cl[k].toFloat(); cloudShade[k] = cs[k].toFloat() }
        val tn = mix(mix(doubleArrayOf(.05, .065, .13), doubleArrayOf(1.5, 1.5, 1.52), dayW), doubleArrayOf(1.38, .86, .62), tw * .8)
        for (k in 0..2) cubeTint[k] = tn[k].toFloat()
        val sunK = ss(-.04, .22, e); val sc = mix(doubleArrayOf(1.0, .55, .28), doubleArrayOf(1.0, .97, .90), ss(0.0, .35, e))
        val moonK = nt * ss(-.05, .12, moonDir[1].toDouble())
        for (k in 0..2) sunCol[k] = (sc[k] * sunK * .8 + (floatArrayOf(.12f, .15f, .26f)[k]) * moonK).toFloat()
        val amb = mix(mix(doubleArrayOf(.035, .045, .08), doubleArrayOf(.80, .85, .90), dayW), doubleArrayOf(.45, .33, .33), tw * .6)
        for (k in 0..2) ambCol[k] = (amb[k] * 0.5).toFloat()
        if (moonK > 0.01 && sunK < 0.05) { for (k in 0..2) sunDir[k] = moonDir[k] }   // at night the "sun" light comes from the moon
    }
}
