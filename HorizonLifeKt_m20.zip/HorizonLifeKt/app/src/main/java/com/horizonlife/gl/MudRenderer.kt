package com.horizonlife.gl

import android.opengl.GLES30
import com.horizonlife.game.Environment
import com.horizonlife.game.Marks
import com.horizonlife.game.Mud
import com.horizonlife.game.Smoke
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.tan

/** Draws tyre marks (ring-buffer strips), mud clumps, mist puffs and road splats. CPU data: game/Marks.kt and game/Mud.kt. */
class MudRenderer {
    private val markP = GlUtil.program(Shaders.MARK_VS, Shaders.MARK_FS)
    private val clumpP = GlUtil.program(Shaders.CLUMP_VS, Shaders.CLUMP_FS)
    private val mistP = GlUtil.program(Shaders.MIST_VS, Shaders.MIST_FS)
    private val splP = GlUtil.program(Shaders.SPLAT_VS, Shaders.SPLAT_FS)
    private val smokeP = GlUtil.program(Shaders.SMOKE_VS, Shaders.SMOKE_FS)
    private val locs = HashMap<String, Int>()
    private fun u(p: Int, n: String) = locs.getOrPut("$p/$n") { GLES30.glGetUniformLocation(p, n) }

    private fun direct(floats: Int): FloatBuffer = ByteBuffer.allocateDirect(floats * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
    private class Buf(val vao: Int, val vbo: Int, val cpu: FloatBuffer)

    /** attribute sizes in order; stride = sum */
    private fun makeBuf(floats: Int, sizes: IntArray): Buf {
        val ids = IntArray(1)
        GLES30.glGenVertexArrays(1, ids, 0); val vao = ids[0]; GLES30.glBindVertexArray(vao)
        GLES30.glGenBuffers(1, ids, 0); val vbo = ids[0]; GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, floats * 4, null, GLES30.GL_DYNAMIC_DRAW)
        val stride = sizes.sum() * 4; var off = 0
        for ((i, s) in sizes.withIndex()) { GLES30.glEnableVertexAttribArray(i); GLES30.glVertexAttribPointer(i, s, GLES30.GL_FLOAT, false, stride, off); off += s * 4 }
        GLES30.glBindVertexArray(0)
        return Buf(vao, vbo, direct(floats))
    }

    private val marks = makeBuf(Marks.Q * 6 * Marks.VF, intArrayOf(3, 4, 2))
    private val clumps = makeBuf(Mud.MUD_N * Mud.CF, intArrayOf(3, 3, 3, 1, 1, 2))
    private val mists = makeBuf(Mud.MIST_N * Mud.MF, intArrayOf(3, 3, 1, 1, 1))
    private val splats = makeBuf(Mud.SPL_N * 6 * Mud.SF, intArrayOf(3, 2, 4, 2))
    private val smokes = makeBuf(Smoke.N * Smoke.VF, intArrayOf(3, 1, 1))

    private fun upload(b: Buf, src: FloatArray, from: Int, n: Int) {
        b.cpu.clear(); b.cpu.position(0); b.cpu.put(src, from, n); b.cpu.position(0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, b.vbo)
        GLES30.glBufferSubData(GLES30.GL_ARRAY_BUFFER, from * 4, n * 4, b.cpu)
    }

    private fun light(p: Int, env: Environment, sun: FloatArray, fog: FloatArray, cx: Float, cy: Float, cz: Float) {
        GLES30.glUniform3f(u(p, "uCam"), cx, cy, cz); GLES30.glUniform3fv(u(p, "uFog"), 1, fog, 0); GLES30.glUniform3fv(u(p, "uSun"), 1, sun, 0)
        GLES30.glUniform3fv(u(p, "uSunCol"), 1, env.sunCol, 0); GLES30.glUniform3fv(u(p, "uAmbCol"), 1, env.ambCol, 0)
    }

    fun drawMarks(vp: FloatArray, env: Environment, sun: FloatArray, fog: FloatArray, cx: Float, cy: Float, cz: Float) {
        if (Marks.dirtyAll) upload(marks, Marks.data, 0, Marks.data.size)
        else if (Marks.dirtyN > 0) upload(marks, Marks.data, Marks.dirtyFirst * 6 * Marks.VF, Marks.dirtyN * 6 * Marks.VF)
        Marks.dirtyN = 0; Marks.dirtyAll = false
        if (Marks.count == 0) return
        GLES30.glUseProgram(markP); GLES30.glUniformMatrix4fv(u(markP, "uVP"), 1, false, vp, 0); light(markP, env, sun, fog, cx, cy, cz)
        GLES30.glDisable(GLES30.GL_CULL_FACE); GLES30.glEnable(GLES30.GL_BLEND); GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)
        GLES30.glDepthMask(false); GLES30.glEnable(GLES30.GL_POLYGON_OFFSET_FILL); GLES30.glPolygonOffset(-8f, -8f)
        GLES30.glBindVertexArray(marks.vao); GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, Marks.count * 6)
        GLES30.glBindVertexArray(0)
        GLES30.glDisable(GLES30.GL_POLYGON_OFFSET_FILL); GLES30.glDepthMask(true); GLES30.glDisable(GLES30.GL_BLEND); GLES30.glEnable(GLES30.GL_CULL_FACE)
    }

    fun drawParticles(vp: FloatArray, view: FloatArray, proj: FloatArray, w: Int, h: Int, fovDeg: Float, env: Environment) {
        val scale = (h / (2.0 * tan(Math.toRadians(fovDeg / 2.0)))).toFloat(); val lightK = 0.3f + 0.7f * env.day
        GLES30.glDisable(GLES30.GL_CULL_FACE); GLES30.glEnable(GLES30.GL_BLEND); GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA); GLES30.glDepthMask(false)
        // splats on the road
        if (Mud.splDirty) { upload(splats, Mud.spl, 0, Mud.spl.size); Mud.splDirty = false }
        if (Mud.splCount > 0) {
            GLES30.glUseProgram(splP); GLES30.glUniformMatrix4fv(u(splP, "uVP"), 1, false, vp, 0)
            GLES30.glUniform1f(u(splP, "uTime"), Mud.time.toFloat()); GLES30.glUniform1f(u(splP, "uLife"), 9f); GLES30.glUniform1f(u(splP, "uLight"), lightK)
            GLES30.glEnable(GLES30.GL_POLYGON_OFFSET_FILL); GLES30.glPolygonOffset(-9f, -9f)
            GLES30.glBindVertexArray(splats.vao); GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, Mud.splCount * 6)
            GLES30.glDisable(GLES30.GL_POLYGON_OFFSET_FILL)
        }
        // mist then clumps (point sprites)
        upload(mists, Mud.mist, 0, Mud.mist.size)
        GLES30.glUseProgram(mistP); GLES30.glUniformMatrix4fv(u(mistP, "uView"), 1, false, view, 0); GLES30.glUniformMatrix4fv(u(mistP, "uProj"), 1, false, proj, 0)
        GLES30.glUniform1f(u(mistP, "uScale"), scale); GLES30.glUniform1f(u(mistP, "uLight"), lightK)
        GLES30.glBindVertexArray(mists.vao); GLES30.glDrawArrays(GLES30.GL_POINTS, 0, Mud.MIST_N)
        upload(clumps, Mud.clump, 0, Mud.clump.size)
        GLES30.glUseProgram(clumpP); GLES30.glUniformMatrix4fv(u(clumpP, "uView"), 1, false, view, 0); GLES30.glUniformMatrix4fv(u(clumpP, "uProj"), 1, false, proj, 0)
        GLES30.glUniform1f(u(clumpP, "uScale"), scale); GLES30.glUniform2f(u(clumpP, "uRes"), w.toFloat(), h.toFloat()); GLES30.glUniform1f(u(clumpP, "uLight"), lightK)
        GLES30.glBindVertexArray(clumps.vao); GLES30.glDrawArrays(GLES30.GL_POINTS, 0, Mud.MUD_N)
        // tyre smoke (soft white puffs, drawn last so it sits over the spray)
        upload(smokes, Smoke.data, 0, Smoke.data.size)
        GLES30.glUseProgram(smokeP); GLES30.glUniformMatrix4fv(u(smokeP, "uView"), 1, false, view, 0); GLES30.glUniformMatrix4fv(u(smokeP, "uProj"), 1, false, proj, 0)
        GLES30.glUniform1f(u(smokeP, "uScale"), scale); GLES30.glUniform1f(u(smokeP, "uLight"), lightK)
        GLES30.glBindVertexArray(smokes.vao); GLES30.glDrawArrays(GLES30.GL_POINTS, 0, Smoke.N)
        GLES30.glBindVertexArray(0)
        GLES30.glDepthMask(true); GLES30.glDisable(GLES30.GL_BLEND); GLES30.glEnable(GLES30.GL_CULL_FACE)
    }
}
