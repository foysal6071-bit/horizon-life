package com.horizonlife.ui

import android.graphics.*
import com.horizonlife.game.Harbor
import com.horizonlife.game.Roads
import com.horizonlife.game.Track
import com.horizonlife.game.World
import kotlin.math.*

/** Port of the JS minimap base image: sea, shallows, beach, grass, river, both ring roads + connector, drawn once at 1 px/m. */
object Minimap {
    const val RANGE = 760
    @Volatile var bitmap: Bitmap? = null
    @Volatile private var started = false

    fun buildAsync() {
        if (started) return; started = true
        Thread {
            try {
                val S = RANGE * 2
                val bmp = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888); val c = Canvas(bmp)
                fun P(v: Double) = (v + RANGE).toFloat()
                val p = Paint(Paint.ANTI_ALIAS_FLAG)
                c.drawColor(0xFF2FB0C6.toInt())
                fun ring(off: Double, col: Int) {
                    val path = Path()
                    for (i in 0..360) { val a = i / 360.0 * 2 * PI; val r = World.coastR(a) + off; val x = P(cos(a) * r); val z = P(sin(a) * r); if (i == 0) path.moveTo(x, z) else path.lineTo(x, z) }
                    path.close(); p.style = Paint.Style.FILL; p.color = col; c.drawPath(path, p)
                }
                ring(4.0, 0xFFA6ECE6.toInt()); ring(-8.0, 0xFFF0E0B0.toInt()); ring(-48.0, 0xFF5F9F4A.toInt())
                val (rx, rz) = World.riverPolyline()
                val rp = Path(); for (i in rx.indices) { if (i == 0) rp.moveTo(P(rx[i]), P(rz[i])) else rp.lineTo(P(rx[i]), P(rz[i])) }
                p.style = Paint.Style.STROKE; p.strokeJoin = Paint.Join.ROUND; p.color = 0xFF2FB0C6.toInt(); p.strokeWidth = 44f; c.drawPath(rp, p)
                for (r in Roads.all) {
                    for ((w, col) in listOf((r.hw * 2 + 6) to 0xFFD9C7A6.toInt(), (r.hw * 2 + 2.5) to 0xFF8C6B49.toInt())) {
                        val path = Path(); val t = DoubleArray(4); val n = 700
                        for (i in 0..n) { r.at((if (r.closed) (i % n).toDouble() / n else min(i.toDouble() / n, 0.99999)) * r.length, t); if (i == 0) path.moveTo(P(t[0]), P(t[1])) else path.lineTo(P(t[0]), P(t[1])) }
                        p.color = col; p.strokeWidth = w.toFloat(); c.drawPath(path, p)
                    }
                }
                if (Track.ready && Track.n > 1) {                       // dirt track (JS minimap: pale line)
                    val tp = Path(); for (i in 0 until Track.n) { val x = P(Track.pts[i * 2].toDouble()); val z = P(Track.pts[i * 2 + 1].toDouble()); if (i == 0) tp.moveTo(x, z) else tp.lineTo(x, z) }
                    p.style = Paint.Style.STROKE; p.color = 0x99FFFFFF.toInt(); p.strokeWidth = 8f; c.drawPath(tp, p)
                }
                run {                                                    // harbor (JS minimap): pier, yard, warehouse, red buoy at the head
                    c.save(); c.translate(P(Harbor.x0), P(Harbor.z0)); c.rotate(Math.toDegrees(atan2(Harbor.dz, Harbor.dx)).toFloat())
                    val L = Harbor.L.toFloat(); val W = Harbor.W.toFloat(); val HL = Harbor.HL.toFloat(); val HW = Harbor.HW.toFloat()
                    p.style = Paint.Style.FILL; p.color = 0xFFC8A06A.toInt()
                    c.drawRect(0f, -W / 2 - 1, L - HL, W / 2 + 1, p); c.drawRect(L - HL, -HW / 2 - 1, L, HW / 2 + 1, p)
                    p.color = 0xFF9AA7B3.toInt(); c.drawRect(-60f, -29f, 8f, 29f, p)
                    if (Harbor.hasWarehouse) {
                        p.color = 0xFFB9C6D2.toInt(); c.drawRect(-51f, -27f, -29f, -13f, p)
                        p.style = Paint.Style.STROKE; p.color = 0xFF5A3A22.toInt(); p.strokeWidth = 2f; c.drawRect(-51f, -27f, -29f, -13f, p)
                    }
                    p.style = Paint.Style.FILL; p.color = 0xFFC8302C.toInt(); c.drawCircle(L - 6, 7f, 5f, p)
                    p.style = Paint.Style.STROKE; p.color = 0xFFFFFFFF.toInt(); p.strokeWidth = 2f; c.drawCircle(L - 6, 7f, 5f, p)
                    c.restore()
                }
                bitmap = bmp
            } catch (e: Throwable) { android.util.Log.e("Minimap", "build failed", e) }
        }.apply { isDaemon = true; start() }
    }
}
