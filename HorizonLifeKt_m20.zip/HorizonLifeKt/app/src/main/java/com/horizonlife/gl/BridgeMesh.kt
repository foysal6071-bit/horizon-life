package com.horizonlife.gl

import android.opengl.GLES30
import com.horizonlife.game.Bridges
import com.horizonlife.game.World
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.*

/**
 * Timber bridges (JS buildBridges): plank deck + fascia, 3 stringers, kerbs, two rails per side (lofted along the road),
 * fence posts every 3 m, cross beams every 3 m, pile bents every 9 m over water. Vertex: x y z nx ny nz u v kind (kind 0 planks, 1 timber).
 */
class BridgeMesh {
    private var vao = 0; private var nIdx = 0
    private val P = ArrayList<Float>(); private val I = ArrayList<Int>()      // P: x y z u v kind

    private fun vtx(x: Double, y: Double, z: Double, u: Double, v: Double, k: Int): Int {
        P.add(x.toFloat()); P.add(y.toFloat()); P.add(z.toFloat()); P.add(u.toFloat()); P.add(v.toFloat()); P.add(k.toFloat())
        return P.size / 6 - 1
    }

    /** loft a profile (o = lateral offset, y = height above road level) along the bridge */
    private fun strip(b: Bridges.Bridge, prof: Array<DoubleArray>, kind: Int) {
        val n = b.n - 1; val pc = prof.size; val base = P.size / 6
        for (k in 0..n) {
            val nx = -b.tz[k]; val nz = b.tx[k]; val along = b.L * k / n
            for (p in prof) vtx(b.px[k] + nx * p[0], p[1] + b.h[k], b.pz[k] + nz * p[0], p[0], along, kind)
        }
        for (k in 0 until n) for (j in 0 until pc - 1) {
            val a = base + k * pc + j; val c = base + (k + 1) * pc + j
            I.add(a); I.add(c); I.add(a + 1); I.add(a + 1); I.add(c); I.add(c + 1)
        }
    }

    /** box centred (cx,cy,cz); hx half-size across the road, hy up, hz along it (direction tx,tz) */
    private fun box(cx: Double, cy: Double, cz: Double, hx: Double, hy: Double, hz: Double, tx: Double, tz: Double) {
        val nx = -tz; val nz = tx; val half = doubleArrayOf(hx, hy, hz)
        val ax = if (hy >= hx && hy >= hz) 1 else if (hz >= hx) 2 else 0                   // longest axis -> wood grain direction
        fun corner(sx: Int, sy: Int, sz: Int): DoubleArray {
            val lx = sx * hx; val ly = sy * hy; val lz = sz * hz
            return doubleArrayOf(cx + nx * lx + tx * lz, cy + ly, cz + nz * lx + tz * lz, lx, ly, lz)
        }
        // 6 faces, each 4 separate vertices
        val faces = arrayOf(
            intArrayOf(1,-1,-1, 1,1,-1, 1,1,1, 1,-1,1), intArrayOf(-1,-1,1, -1,1,1, -1,1,-1, -1,-1,-1),
            intArrayOf(-1,1,-1, -1,1,1, 1,1,1, 1,1,-1), intArrayOf(-1,-1,1, -1,-1,-1, 1,-1,-1, 1,-1,1),
            intArrayOf(-1,-1,1, 1,-1,1, 1,1,1, -1,1,1), intArrayOf(1,-1,-1, -1,-1,-1, -1,1,-1, 1,1,-1))
        for (f in faces) {
            val ids = IntArray(4)
            for (q in 0 until 4) {
                val c = corner(f[q * 3], f[q * 3 + 1], f[q * 3 + 2]); val l = doubleArrayOf(c[3], c[4], c[5])
                ids[q] = vtx(c[0], c[1], c[2], l[(ax + 1) % 3] + l[(ax + 2) % 3], l[ax], 1)
            }
            I.add(ids[0]); I.add(ids[1]); I.add(ids[2]); I.add(ids[0]); I.add(ids[2]); I.add(ids[3])
        }
    }

    init {
        val t = DoubleArray(4)
        for (b in Bridges.list) {
            val hw = b.hw; val dw = hw + 1.8; val railO = hw + 1.45
            strip(b, arrayOf(doubleArrayOf(dw, 0.10), doubleArrayOf(dw, -0.72), doubleArrayOf(-dw, -0.72), doubleArrayOf(-dw, 0.10)), 1)   // deck body + fascia
            strip(b, arrayOf(doubleArrayOf(dw, 0.115), doubleArrayOf(-dw, 0.115)), 0)                                                       // plank roadway
            for (c in doubleArrayOf(-hw * 0.55, 0.0, hw * 0.55))
                strip(b, arrayOf(doubleArrayOf(c + .17, -.1), doubleArrayOf(c + .17, -.95), doubleArrayOf(c - .17, -.95), doubleArrayOf(c - .17, -.1)), 1)
            for (sd in intArrayOf(-1, 1)) {
                val k0 = sd * (hw + 0.05); val k1 = sd * (hw + 0.42)
                strip(b, arrayOf(doubleArrayOf(k0, .10), doubleArrayOf(k0, .36), doubleArrayOf(k1, .36), doubleArrayOf(k1, .10)), 1)     // wheel kerb
                for (yy in arrayOf(doubleArrayOf(0.93, 1.09), doubleArrayOf(0.50, 0.62))) {
                    val a = sd * (railO - 0.07); val c = sd * (railO + 0.07)
                    strip(b, arrayOf(doubleArrayOf(a, yy[0]), doubleArrayOf(a, yy[1]), doubleArrayOf(c, yy[1]), doubleArrayOf(c, yy[0])), 1)
                }
            }
            // fence posts + cross beams every 3 m, pile bents every 9 m over the water
            var d = 0.0
            while (d <= b.L) {
                b.road.at(b.s0 + d, t); val tx = t[2]; val tz = t[3]; val nx = -tz; val nz = tx; val ar = Bridges.arch(d / b.L)
                for (sd in intArrayOf(-1, 1)) {
                    val px = t[0] + nx * sd * railO; val pz = t[1] + nz * sd * railO
                    box(px, 0.58 + ar, pz, 0.08, 0.58, 0.08, tx, tz); box(px, 1.19 + ar, pz, 0.12, 0.04, 0.12, tx, tz)
                }
                box(t[0], -0.52 + ar, t[1], dw, 0.11, 0.14, tx, tz)
                d += 3.0
            }
            d = 3.0
            while (d <= b.L) {
                b.road.at(b.s0 + d, t)
                if (abs(World.riverSd(t[0], t[1])) <= World.RIVER_WALL - 2) {
                    val tx = t[2]; val tz = t[3]; val nx = -tz; val nz = tx; val ar = Bridges.arch(d / b.L)
                    box(t[0], -0.98 + ar, t[1], dw * 1.25, 0.12, 0.17, tx, tz)
                    val top = -0.95 + ar; val bot = -World.RIVER_DEPTH - 0.6
                    for (o in doubleArrayOf(-(dw - .5), -dw * .33, dw * .33, dw - .5))
                        box(t[0] + nx * o, (top + bot) / 2, t[1] + nz * o, 0.16, (top - bot) / 2, 0.16, tx, tz)
                }
                d += 9.0
            }
        }
        // smooth normals (accumulated face normals)
        val nv = P.size / 6; val nr = FloatArray(nv * 3)
        var q = 0
        while (q < I.size) {
            val a = I[q]; val c = I[q + 1]; val e = I[q + 2]; q += 3
            val ux = P[c * 6] - P[a * 6]; val uy = P[c * 6 + 1] - P[a * 6 + 1]; val uz = P[c * 6 + 2] - P[a * 6 + 2]
            val vx = P[e * 6] - P[a * 6]; val vy = P[e * 6 + 1] - P[a * 6 + 1]; val vz = P[e * 6 + 2] - P[a * 6 + 2]
            val fx = uy * vz - uz * vy; val fy = uz * vx - ux * vz; val fz = ux * vy - uy * vx
            for (id in intArrayOf(a, c, e)) { nr[id * 3] += fx; nr[id * 3 + 1] += fy; nr[id * 3 + 2] += fz }
        }
        val out = FloatArray(nv * 9)
        for (i in 0 until nv) {
            val l = sqrt(nr[i * 3] * nr[i * 3] + nr[i * 3 + 1] * nr[i * 3 + 1] + nr[i * 3 + 2] * nr[i * 3 + 2]).let { if (it == 0f) 1f else it }
            for (k in 0 until 3) out[i * 9 + k] = P[i * 6 + k]
            for (k in 0 until 3) out[i * 9 + 3 + k] = nr[i * 3 + k] / l
            for (k in 0 until 3) out[i * 9 + 6 + k] = P[i * 6 + 3 + k]
        }
        nIdx = I.size
        if (nIdx > 0) {
            val id = IntArray(1)
            GLES30.glGenVertexArrays(1, id, 0); vao = id[0]; GLES30.glBindVertexArray(vao)
            GLES30.glGenBuffers(1, id, 0); GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, id[0])
            val fb = ByteBuffer.allocateDirect(out.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(out).also { it.position(0) }
            GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, out.size * 4, fb, GLES30.GL_STATIC_DRAW)
            for (a in 0..2) { GLES30.glEnableVertexAttribArray(a); GLES30.glVertexAttribPointer(a, 3, GLES30.GL_FLOAT, false, 36, a * 12) }
            GLES30.glGenBuffers(1, id, 0); GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, id[0])
            val ib = ByteBuffer.allocateDirect(I.size * 4).order(ByteOrder.nativeOrder()).asIntBuffer().put(I.toIntArray()).also { it.position(0) }
            GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, I.size * 4, ib, GLES30.GL_STATIC_DRAW)
            GLES30.glBindVertexArray(0)
        }
        P.clear(); I.clear()
    }

    fun draw() {
        if (nIdx == 0) return
        GLES30.glBindVertexArray(vao)
        GLES30.glDrawElements(GLES30.GL_TRIANGLES, nIdx, GLES30.GL_UNSIGNED_INT, 0)
        GLES30.glBindVertexArray(0)
    }
}
