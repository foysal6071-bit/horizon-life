package com.horizonlife.gl

import android.opengl.GLES30
import com.horizonlife.game.Bridges
import com.horizonlife.game.Roads
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.*

/**
 * One static mesh for the whole road network: dirt/mud roadway + sandy verges (JS buildStrip + SHOULDER_PROFILE).
 * Vertex: x y z, lat (m from centre, + = left), v (m along), hw (half width).
 */
class RoadMesh {
    private var vao = 0; private var nIdx = 0

    init {
        val verts = ArrayList<Float>(); val idx = ArrayList<Short>()
        for (r in Roads.all) {
            val hw = r.hw
            val lat = doubleArrayOf(-(hw + 8), -(hw + 3.5), -hw, -(hw - 1.5), hw - 1.5, hw, hw + 3.5, hw + 8)
            val yy = doubleArrayOf(0.045, 0.06, 0.08, 0.075, 0.075, 0.08, 0.06, 0.045)
            val base0 = verts.size / 6
            val cnt = r.n
            for (i in 0 until cnt) {
                val t = r.tangent(i); val nx = t[1]; val nz = -t[0]      // left of travel direction
                for (k in 0 until 8) {
                    verts.add((r.x[i] + nx * lat[k]).toFloat()); verts.add((yy[k] + r.yBias).toFloat()); verts.add((r.z[i] + nz * lat[k]).toFloat())
                    verts.add(lat[k].toFloat()); verts.add(r.s[i].toFloat()); verts.add(hw.toFloat())
                }
            }
            val segs = if (r.closed) cnt else cnt - 1
            for (i in 0 until segs) {
                val j = (i + 1) % cnt
                if (Bridges.inSpan(r, r.s[i])) continue     // the bridge deck replaces the road here
                // connector: no verge near the two junctions (it would paint sand over the ring road's surface)
                val ends = !r.closed && (r.s[i] < 14 || r.s[i] > r.length - 14)
                val kr = if (ends) 2 until 5 else 0 until 7
                for (k in kr) {
                    val a = base0 + i * 8 + k; val b = a + 1; val c = base0 + j * 8 + k; val d = c + 1
                    idx.add(a.toShort()); idx.add(c.toShort()); idx.add(b.toShort())
                    idx.add(b.toShort()); idx.add(c.toShort()); idx.add(d.toShort())
                }
            }
        }
        nIdx = idx.size
        // closed rings: v wraps at the seam (harmless: only used for noise / dashes)
        val id = IntArray(1)
        GLES30.glGenVertexArrays(1, id, 0); vao = id[0]; GLES30.glBindVertexArray(vao)
        GLES30.glGenBuffers(1, id, 0); GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, id[0])
        val fb = ByteBuffer.allocateDirect(verts.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(verts.toFloatArray()).also { it.position(0) }
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, verts.size * 4, fb, GLES30.GL_STATIC_DRAW)
        GLES30.glEnableVertexAttribArray(0); GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 24, 0)
        GLES30.glEnableVertexAttribArray(1); GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 24, 12)
        GLES30.glGenBuffers(1, id, 0); GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, id[0])
        val sb = ByteBuffer.allocateDirect(idx.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer().put(idx.toShortArray()).also { it.position(0) }
        GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, idx.size * 2, sb, GLES30.GL_STATIC_DRAW)
        GLES30.glBindVertexArray(0)
        require(verts.size / 6 < 65536) { "road mesh too large for 16-bit indices: ${verts.size / 6}" }
    }

    fun draw() {
        GLES30.glBindVertexArray(vao)
        GLES30.glDrawElements(GLES30.GL_TRIANGLES, nIdx, GLES30.GL_UNSIGNED_SHORT, 0)
        GLES30.glBindVertexArray(0)
    }
}
