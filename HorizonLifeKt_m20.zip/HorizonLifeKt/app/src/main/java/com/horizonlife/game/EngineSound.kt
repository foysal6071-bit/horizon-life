package com.horizonlife.game

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import kotlin.math.*

/**
 * Port of the JS `sfx` engine sound (R8 V10 recording): two seamless loops (assets/engine_idle.pcm, engine_main.pcm, 16-bit mono 22050 Hz,
 * decoded offline from R8_SND), pitch-shifted by RPM (playbackRate) and cross-faded idle -> main (equal power, log-rpm) in a small software
 * mixer on its own thread (AudioTrack stream). Also wind, tyre squeal, rev-limiter chop, gear-change dip and the bump thud.
 */
object EngineSound {
    private const val SR = 22050
    private const val N_MAIN = 77973; private const val N_IDLE = 11154
    private const val MAIN_REF = 3500.0; private const val IDLE_REF = 1300.0

    @Volatile private var rpm = 900.0; @Volatile private var thr = 0.0; @Volatile private var spd = 0.0
    @Volatile private var gear = 1; @Volatile private var brk = 0.0
    @Volatile var vol = 0.55
    /** JS ambient layer inputs (Environment.day / night), set every frame from Game.update */
    @Volatile private var envDay = 1.0; @Volatile private var envNight = 0.0
    fun setEnv(day: Double, night: Double) { envDay = day; envNight = night }
    @Volatile var muted = false
    @Volatile private var running = false
    private var thread: Thread? = null

    /** called every frame from Game.update (JS sfx.update arguments) */
    fun set(rpm: Double, thr: Double, spd: Double, gear: Int, brk: Double) {
        this.rpm = rpm; this.thr = thr; this.spd = spd; this.gear = gear; this.brk = brk
    }

    fun start(ctx: Context) {
        if (running) return
        val idle = load(ctx, "engine_idle.pcm", N_IDLE) ?: return
        val main = load(ctx, "engine_main.pcm", N_MAIN) ?: return
        running = true
        thread = Thread { try { loop(idle, main) } catch (e: Exception) { android.util.Log.e("Sound", "engine sound failed", e) } }.apply { isDaemon = true; start() }
    }

    fun stop() { running = false; thread?.join(400); thread = null }

    private fun load(ctx: Context, name: String, n: Int): FloatArray? = try {
        val b = ctx.assets.open(name).use { it.readBytes() }
        FloatArray(n) { i -> ((b[2 * i].toInt() and 0xff) or (b[2 * i + 1].toInt() shl 8)).toShort() / 32768f }
    } catch (e: Exception) { android.util.Log.e("Sound", "missing $name", e); null }

    /** RBJ band-pass biquad (constant 0 dB peak) */
    private class BP {
        var b0 = 0.0; var b2 = 0.0; var a1 = 0.0; var a2 = 0.0; var z1 = 0.0; var z2 = 0.0
        fun set(f: Double, q: Double) {
            val w = 2 * PI * min(f, SR * 0.45) / SR; val al = sin(w) / (2 * q); val a0 = 1 + al
            b0 = al / a0; b2 = -al / a0; a1 = -2 * cos(w) / a0; a2 = (1 - al) / a0
        }
        fun p(x: Double): Double { val y = b0 * x + z1; z1 = -a1 * y + z2; z2 = b2 * x - a2 * y; return y }
    }

    private fun loop(idle: FloatArray, main: FloatArray) {
        val ch = 512
        val minBuf = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val track = AudioTrack(
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build(),
            AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(SR).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build(),
            max(minBuf, ch * 4 * 2), AudioTrack.MODE_STREAM, AudioManager.AUDIO_SESSION_ID_GENERATE)
        track.play()
        val out = ShortArray(ch)
        fun k(tc: Double) = 1 - exp(-1.0 / (SR * tc))
        val k03 = k(0.03); val k025 = k(0.025); val k05 = k(0.05); val k15 = k(0.15); val k08 = k(0.08); val k1 = k(0.1)
        var ip = 0.0; var mp = 0.0; var rI = 1.0; var rM = 1.0; var gI = 1.0; var gM = 0.0; var fc = 6000.0; var eg = 0.3
        var wg = 0.0; var sg = 0.0; var wf = 900.0; var sf = 2000.0; var lp = 0.0
        val wind = BP(); val squeal = BP(); var seed = 12345
        // ambient (JS initAmb / updateExtras): calm wind bed, night crickets (4.3 kHz, 34 Hz flutter, 2.6 Hz gate), daytime bird chirps
        val rnd = java.util.Random(7); val kAmb = k(0.8)
        var cricG = 0.0; var cricPh = 0.0; var flPh = 0.0; var gtPh = 0.0
        var chirpN = 0; var chirpBase = 3000.0; var chirpRise = 1.5; var chirpT = 0.0; var chirpPh = 0.0
        var nextChirp = System.nanoTime() + 3_000_000_000L
        var lastGear = 1; var dipUntil = 0L; var lastHits = Collision.thuds; var thudT = -1.0; var thudPh = 0.0; var master = if (muted) 0.0 else vol
        while (running) {
            val r = rpm; val th = thr; val sp = spd; val g = gear; val br = brk
            val now = System.nanoTime()
            val x = min(max((ln(max(r, 1.0)) - ln(1400.0)) / (ln(2800.0) - ln(1400.0)), 0.0), 1.0)
            val tI = min(max(r / IDLE_REF, 0.5), 2.2); val tM = min(max(r / MAIN_REF, 0.3), 2.6)
            val tgI = cos(x * PI / 2); val tgM = sin(x * PI / 2)
            val tFc = 3000 + r * 0.6 + th * 7000
            var v = (0.34 + th * 0.66) * (0.75 + 0.25 * r / 7000) * 1.25
            if (r > 6850 && th > 0.5 && (now / 55_000_000L) % 2L == 1L) v *= 0.3          // rev limiter chop
            if (g != lastGear) { if (g > lastGear && lastGear > 0) dipUntil = now + 140_000_000L; lastGear = g }
            if (now < dipUntil) v *= 0.35                                                  // torque cut on a gear change
            val tWg = 0.012 + min(sp / 32, 1.0) * 0.10; val tWf = 500 + sp * 28
            val tSg = if (br > 0.7 && sp > 14) min((sp - 14) / 10, 1.0) * 0.045 else 0.0; val tSf = 1700 + sp * 20
            val tMaster = if (muted) 0.0 else vol
            val dayK = envDay; val nightK = envNight; val tCric = 0.03 * nightK
            if (dayK > 0.5 && chirpN == 0 && now > nextChirp) {
                chirpN = 2 + rnd.nextInt(4); chirpBase = 2200 + rnd.nextDouble() * 1800; chirpRise = 1.3 + rnd.nextDouble() * 0.4; chirpT = 0.0
                nextChirp = now + ((1.5 + rnd.nextDouble() * 4.5) * 1e9).toLong()
            }
            if (Collision.thuds != lastHits) { lastHits = Collision.thuds; thudT = 0.0 }
            wind.set(wf, 0.6); squeal.set(sf, 5.0)
            for (i in 0 until ch) {
                rI += (tI - rI) * k03; rM += (tM - rM) * k03; gI += (tgI - gI) * k03; gM += (tgM - gM) * k03
                fc += (tFc - fc) * k05; eg += (v - eg) * k025; wg += (tWg - wg) * k15; wf += (tWf - wf) * k15
                sg += (tSg - sg) * k08; sf += (tSf - sf) * k1; master += (tMaster - master) * k05
                ip += rI; if (ip >= N_IDLE) ip -= N_IDLE; mp += rM; if (mp >= N_MAIN) mp -= N_MAIN
                val i0 = ip.toInt(); val fi = ip - i0; val i1 = if (i0 + 1 >= N_IDLE) 0 else i0 + 1
                val m0 = mp.toInt(); val fm = mp - m0; val m1 = if (m0 + 1 >= N_MAIN) 0 else m0 + 1
                val s = (idle[i0] + (idle[i1] - idle[i0]) * fi) * gI + (main[m0] + (main[m1] - main[m0]) * fm) * gM
                lp += min(0.95, 1 - exp(-2 * PI * fc / SR)) * (s - lp)
                seed = seed * 1103515245 + 12345; val nz = ((seed shr 8) and 0xffff) / 32768.0 - 1.0
                var o = lp * eg + wind.p(nz) * wg * 2.2 + squeal.p(nz) * sg * 2.5
                if (thudT >= 0) {                                                          // bump thud: 110 -> 35 Hz triangle, 0.3 s
                    val f = 110 * (35.0 / 110).pow(thudT / 0.3); thudPh += f / SR; thudPh -= floor(thudPh)
                    val tri = 4 * abs(thudPh - 0.5) - 1; o += tri * 0.6 * (0.001 / 0.6).pow(thudT / 0.3)
                    thudT += 1.0 / SR; if (thudT > 0.32) thudT = -1.0
                }
                // ambient bed
                cricG += (tCric - cricG) * kAmb
                if (cricG > 1e-5) {
                    cricPh += 4300.0 / SR; cricPh -= floor(cricPh); flPh += 34.0 / SR; flPh -= floor(flPh); gtPh += 2.6 / SR; gtPh -= floor(gtPh)
                    o += sin(2 * PI * cricPh) * (0.5 + 0.5 * sin(2 * PI * flPh)) * (0.5 + 0.5 * sin(2 * PI * gtPh)) * cricG
                }
                if (chirpN > 0) {
                    val idx = (chirpT / 0.13).toInt()
                    if (idx >= chirpN) chirpN = 0
                    else {
                        val lt = chirpT - idx * 0.13
                        if (lt < 0.1) {
                            val f = chirpBase * chirpRise.pow(min(lt / 0.07, 1.0)); chirpPh += f / SR; chirpPh -= floor(chirpPh)
                            val e = if (lt < 0.015) lt / 0.015 * 0.05 else 0.05 * (0.001 / 0.05).pow(min((lt - 0.015) / 0.075, 1.0))
                            o += sin(2 * PI * chirpPh) * e
                        }
                        chirpT += 1.0 / SR
                    }
                }
                o *= master
                out[i] = (tanh(o) * 32767).toInt().toShort()
            }
            track.write(out, 0, ch)                                                         // blocks until there is room: paces the loop
        }
        track.stop(); track.release()
    }
}
