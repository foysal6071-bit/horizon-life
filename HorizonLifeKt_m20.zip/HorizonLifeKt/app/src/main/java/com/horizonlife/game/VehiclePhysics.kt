package com.horizonlife.game

import kotlin.math.*

/**
 * 1:1 port of the JS `Veh` module (Forza-style model: bicycle model with slip angles, weight transfer,
 * friction circle, 6-speed auto gearbox, ABS/TCS, handbrake drift).
 */
object VehiclePhysics {
    private fun clamp(v: Double, a: Double, b: Double) = min(max(v, a), b)

    private const val G = 9.81
    private const val MASS = 1650.0
    private const val WHEELBASE = 2.8
    const val WR = 0.40
    private const val RPM_K = 1.0 / (0.10472 * WR)
    const val VMAX = 220.0 / 3.6
    private const val IDLE = 900.0
    private const val REDLINE = 7000.0
    private const val TMAX = 400.0
    private const val EFF = 0.9
    private const val ENGINE_BRAKE = 35.0
    private const val R6 = REDLINE / (VMAX * RPM_K)
    private val RATIOS = doubleArrayOf(0.0, R6 * 3.297, R6 * 2.286, R6 * 1.670, R6 * 1.319, R6 * 1.121, R6)
    private const val REV_MAX = 20.0 / 3.6
    private const val REV_FORCE = 3200.0
    private const val BRAKE_DECEL = 17.0
    private const val K_AERO = 0.40
    private const val K_DOWN = 1.8
    private const val TYRE_K = 1.05
    private const val TYRE_B = 16.0
    private const val TYRE_C = 1.35
    private const val DRIVE_REAR = 0.45
    private const val LA = 1.35
    private const val LB = 1.45
    private const val IZ = 3000.0
    private const val HCG = 0.45
    private const val STEER_LOCK = 0.55
    private const val STEER_RATE = 3.6
    private const val STEER_RETURN = 6.0
    val MAX_SPEED = REDLINE / (RATIOS[6] * RPM_K)

    private fun torque(rpm: Double) =
        TMAX * clamp(1 - 0.55 * ((rpm - 4800) / 4200).pow(2), 0.3, 1.0) * clamp((REDLINE + 300 - rpm) / 300, 0.0, 1.0)

    fun step(S: CarState, inp: DriveInput, surf: Surface, dt: Double) {
        val gas = inp.gas; val brk = inp.brake; val left = inp.left; val right = inp.right; val hand = inp.hand
        // ---- pedals ----
        val vx0 = S.speed
        var thrT = 0.0; var brkT = 0.0; var rev = false
        if (gas && brk) brkT = 1.0
        else if (gas) { if (vx0 < -0.8) brkT = 1.0 else thrT = 1.0 }
        else if (brk) {
            if (vx0 > 0.8) brkT = 1.0
            else { S.revTimer += dt; if (S.revTimer > 0.3 || vx0 < -0.8) { rev = true; thrT = 1.0 } else brkT = 1.0 }
        }
        if (!brk || gas) S.revTimer = 0.0
        if (hand) {
            if (S.speed > 6) brkT = if (brk) 1.0 else if (gas) 0.0 else if (left || right) 0.18 else 0.45
            else { brkT = 1.0; thrT = 0.0; rev = false }
        }
        S.reverse = rev
        S.throttle += (thrT - S.throttle) * (1 - exp(-dt * (if (thrT > S.throttle) 7 else 14)))
        S.brake += (brkT - S.brake) * (1 - exp(-dt * (if (brkT > S.brake) 22 else 20)))
        S.braking = S.brake > 0.25
        S.handOn = hand
        S.hb += ((if (hand && S.speed > 5) 1.0 else 0.0) - S.hb) * (1 - exp(-dt * 6))

        val av = abs(S.speed)

        // ---- steering input ----
        val steerIn = inp.analog ?: ((if (left) 1.0 else 0.0) - (if (right) 1.0 else 0.0))
        val rate = (if (steerIn == 0.0 || sign(steerIn) != sign(S.steer)) STEER_RETURN else STEER_RATE) * inp.sens / (1 + av / 120)
        val dS = steerIn - S.steer
        S.steer += sign(dS) * min(abs(dS), rate * dt)

        // ---- automatic gearbox ----
        S.shiftT = max(0.0, S.shiftT - dt)
        if (S.reverse || S.speed < -0.5) S.gear = 0
        else {
            if (S.gear == 0) S.gear = 1
            val sp = max(S.speed, 0.0); val rpmG = sp * RATIOS[S.gear] * RPM_K
            if (S.shiftT <= 0) {
                if (S.gear < 6 && (rpmG > 6600 || (rpmG > 5200 && S.throttle < 0.15))) { S.gear++; S.shiftT = 0.2 }
                else if (S.gear > 1 && (rpmG < 2300 || (S.throttle > 0.9 && rpmG < 3300)) && sp * RATIOS[S.gear - 1] * RPM_K < 6300) { S.gear--; S.shiftT = 0.15 }
            }
        }
        val gearR = if (S.gear == 0) 14.0 else RATIOS[S.gear]
        val rpmW = av * gearR * RPM_K; val clutch = 1 - clamp(av / 6, 0.0, 1.0)
        val rpmTgt = max(rpmW, IDLE + S.throttle * 3200 * clutch)
        S.rpm += (rpmTgt - S.rpm) * (1 - exp(-dt * (if (rpmTgt > S.rpm) 10 else 6)))
        S.rpm = min(S.rpm, REDLINE + 300)

        // ---- engine force ----
        var fdrive = 0.0
        if (S.throttle > 0.001) {
            fdrive = if (S.reverse) -S.throttle * REV_FORCE * clamp((REV_MAX + S.speed) / 3, 0.0, 1.0)
            else S.throttle * torque(max(S.rpm, 2800.0)) * RATIOS[S.gear] * EFF / WR *
                (if (S.shiftT > 0) 1 - 0.5 * sin(PI * (1 - min(S.shiftT / 0.2, 1.0))) else 1.0)
        }
        if (!S.reverse) fdrive *= clamp((VMAX - S.speed) / 1.2, 0.0, 1.0)
        S.fd += (fdrive - S.fd) * (1 - exp(-dt * 14)); fdrive = S.fd

        // ---- grip budget ----
        val gripN0 = surf.mu * TYRE_K * (MASS * G + K_DOWN * S.speed * S.speed)
        val flong = max(min(abs(fdrive), 0.8 * gripN0), S.brake * min(BRAKE_DECEL * MASS, 0.97 * gripN0))
        S.ayLim = sqrt(max(gripN0 * gripN0 - flong * flong, 0.04 * gripN0 * gripN0)) / MASS * 0.97
        val sensK = clamp(0.7 + 0.3 * inp.sens, 0.85, 1.6)
        val lockSpeed = sensK * STEER_LOCK / (1 + (av / 46).pow(2))
        val lockGrip = 0.06 * sensK + atan(WHEELBASE * S.ayLim * 1.1 / max(S.speed * S.speed, 1.0))
        val dDrv = S.steer * min(lockSpeed, lockGrip)
        var delta = dDrv

        // ---- integrate (sub-stepped, 5 ms) ----
        val n = max(1, ceil(dt / 0.005).toInt()); val h = dt / n
        var axAcc = 0.0
        for (it in 0 until n) {
            val vx = S.speed; val sp = abs(vx); val sgn = clamp(vx / 0.4, -1.0, 1.0)
            val wDyn = clamp((vx - 3) / 4, 0.0, 1.0)
            val down = K_DOWN * vx * vx
            val mu = surf.mu * TYRE_K
            val gripN = surf.mu * (MASS * G + down)
            val wasDrift = S.drift > 0.3
            val lim = (if (wasDrift) 1.0 else 0.62) * gripN
            val fd = clamp(fdrive, -lim, lim)
            val fb = S.brake * min(BRAKE_DECEL * MASS, 0.97 * gripN)
            var fres = -sgn * (surf.rr * MASS * G + K_AERO * vx * vx + MASS * abs(S.ay) * 0.04)
            if (S.gear > 0) {
                val eb = clamp(1 - S.throttle / 0.15, 0.0, 1.0) * clamp(1 - S.brake / 0.15, 0.0, 1.0)
                fres -= sgn * clamp(sp / 2, 0.0, 1.0) * ENGINE_BRAKE * RATIOS[S.gear] * (S.rpm / REDLINE) / WR * eb
            }
            val fg = -MASS * G * S.slope
            val fx = fd - sgn * fb + fres + fg

            val dFz = clamp(MASS * S.axS * HCG / WHEELBASE, -0.22 * MASS * G, 0.22 * MASS * G)
            val fzF = max(MASS * G * LB / WHEELBASE - dFz + down * 0.40, 800.0)
            val fzR = max(MASS * G * LA / WHEELBASE + dFz + down * 0.60, 800.0)
            val uA = max(vx, 2.5)
            val beta = atan2(S.vy, uA)
            val usF = clamp(fb * 0.70 / (mu * fzF), 0.0, 0.95)
            val usR = clamp(0.6 * abs(fd * DRIVE_REAR - sgn * fb * 0.30) / (mu * fzR), 0.0, 0.9)
            val capF = sqrt(1 - usF * usF)
            val capR = sqrt(1 - usR * usR) * (1 - 0.55 * S.hb) * (1 + 1.3 * clamp((abs(beta) - 0.55) / 0.4, 0.0, 1.0))
            val wAs = clamp((abs(beta) - 0.08) / 0.15, 0.0, 1.0) * 0.85 * wDyn
            delta = clamp(dDrv + wAs * clamp(beta, -0.7, 0.7), -0.65, 0.65)
            val aF = atan2(S.vy + LA * S.yaw, uA) - delta
            val aR = atan2(S.vy - LB * S.yaw, uA)
            val fyF = -mu * fzF * capF * sin(TYRE_C * atan(TYRE_B * aF))
            val fyR = -mu * fzR * capR * sin(TYRE_C * atan(TYRE_B * aR))
            val cd = cos(delta); val sd = sin(delta)

            S.speed += (fx - fyF * sd * wDyn) / MASS * h
            S.speed = clamp(S.speed, -REV_MAX, VMAX * (1 + 0.03 * clamp(-S.slope * 8, 0.0, 1.0)))
            axAcc += fx / MASS
            S.vy += (fyF * cd + fyR) / MASS * h * wDyn
            S.yaw += ((LA * fyF * cd - LB * fyR) / IZ - 1.4 * S.yaw) * h * wDyn
            if (wDyn < 1) {
                val rK = S.speed * tan(delta) / WHEELBASE
                S.yaw += (rK - S.yaw) * (1 - exp(-h / 0.05)) * (1 - wDyn)
                S.vy *= exp(-8 * (1 - wDyn) * h)
            }
            S.yaw = clamp(S.yaw, -2.6, 2.6)
            if (abs(S.speed) < 0.08 && S.throttle < 0.02 && (abs(S.slope) < 0.3 || S.brake > 0.3 || S.handOn)) {
                S.speed = 0.0; S.vy = 0.0; S.yaw = 0.0
            }
            val dH = S.yaw * h; S.heading += dH
            val a = dH * wDyn; val c = cos(a); val sn = sin(a); val sp0 = S.speed
            S.speed = sp0 * c + S.vy * sn; S.vy = -sp0 * sn + S.vy * c
            val sH = sin(S.heading); val cH = cos(S.heading)
            S.x += (S.speed * sH + S.vy * cH) * h
            S.z += (S.speed * cH - S.vy * sH) * h
        }
        S.steerAngle = clamp(delta, -0.6, 0.6)
        val bR = abs(atan2(S.vy - LB * S.yaw, max(S.speed, 2.5)))
        val tgt = if (S.speed > 5) clamp((bR - 0.12) / 0.2, 0.0, 1.0) else 0.0
        S.drift += (tgt - S.drift) * (1 - exp(-dt * (if (tgt > S.drift) 10 else 3)))
        S.ax = axAcc / n
        S.axS += (S.ax - S.axS) * (1 - exp(-dt * 5))
        S.ay = S.speed * S.yaw
        S.wheelSpin += S.speed / WR * dt
    }
}
