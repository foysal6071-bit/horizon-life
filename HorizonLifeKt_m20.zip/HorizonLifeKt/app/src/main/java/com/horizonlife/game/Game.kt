package com.horizonlife.game

import kotlin.math.*

/** Owns the simulation (fixed per-frame step like the JS animate()): input -> physics -> pose -> camera. */
class Game {
    val car = CarState()
    val pose = CarPose()
    val input = DriveInput()
    val cam = CameraRig()
    val surf = Surface()
    val env = Environment()
    var roll = 0.0; private var rollV = 0.0
    var pitch = 0.0; private var pitchV = 0.0
    var distance = 0.0
    /** on-screen message (JS showToast): text + seconds left */
    @Volatile var toast: String? = null; @Volatile var toastT = 0.0
    private var life = 0.0
    fun showToast(m: String) { toast = m; toastT = 2.4 }
    private var dtS = 1.0 / 60
    private var lastHits = Collision.hits
    /** wheel travel (m, <= 0 = sunk) for front L/R, rear L/R: only ever moves over potholes (JS wy/wv/pp) */
    val wheelDy = FloatArray(4); private val wy = DoubleArray(4); private val wv = DoubleArray(4); private val pp = DoubleArray(4)

    init { Track.build(); Harbor.onPier = false; reset() }

    /** JS resetCar(): put the car on the road facing along it. */
    fun reset() {
        val st = Roads.startPose(); car.x = st.first; car.z = st.second; car.heading = st.third
        Bridges.cur = null
        car.speed = 0.0; car.vy = 0.0; car.yaw = 0.0; car.steer = 0.0
        car.gear = 1; car.rpm = 900.0; car.fd = 0.0; car.slope = 0.0
        pose.x = car.x; pose.y = World.ROAD_SURF; pose.z = car.z
        cam.snap(car, pose)
        showToast("Car reset")
    }

    fun update(rawDt: Double) {
        if (Settings.paused) { EngineSound.set(900.0, 0.0, 0.0, 1, 0.0); return }
        dtS += (min(rawDt, 0.05) - dtS) * 0.2      // smoothed step (same as JS dtS)
        val dt = dtS
        World.surfaceAt(car.x, car.z, surf)
        // 4 wheels sample the terrain: ride height, pitch/roll targets and the pull of gravity (JS animate())
        val sH = sin(car.heading); val cH = cos(car.heading); val A = 1.4; val B = 0.85
        fun hw(f: Double, l: Double) = World.fieldH(car.x + sH * f + cH * l, car.z + cH * f - sH * l)   // f forward, l to the LEFT (JS carGroundH: no river bed, bridges lift the deck)
        val hFL = hw(A, B); val hFR = hw(A, -B); val hRL = hw(-A, B); val hRR = hw(-A, -B)
        val hF = (hFL + hFR) / 2; val hR = (hRL + hRR) / 2; val hLf = (hFL + hRL) / 2; val hRt = (hFR + hRR) / 2; val avg = (hF + hR) / 2
        val g = (hF - hR) / (2 * A); val sl = (hLf - hRt) / (2 * B)
        val lift = max(0.0, max(hFL - (avg + A * g + B * sl), max(hFR - (avg + A * g - B * sl),
            max(hRL - (avg - A * g + B * sl), hRR - (avg - A * g - B * sl)))))
        val gRide = avg + lift
        val sn = g / sqrt(1 + g * g)
        car.slope += (sn - car.slope) * (1 - exp(-10 * dt))

        VehiclePhysics.step(car, input, surf, dt)
        Collision.update(car, dt)                  // lamp poles + world edge
        if (Collision.hits != lastHits) { lastHits = Collision.hits; showToast("Bump!") }
        Fence.collide(car, dt, distance)           // breakable roadside fence
        Bridges.riverCollide(car)                  // bridge rails + river banks (JS riverCollide)
        val bh = Bridges.lift(car.x, car.z)
        val bsl = Bridges.bS * (sH * Bridges.bTx + cH * Bridges.bTz)   // bridge slope along the heading (+ = uphill)
        distance += abs(car.speed) * dt
        pose.x = car.x; pose.z = car.z
        pose.y += (gRide + surf.rideY + bh - pose.y) * (1 - exp(-(if (bh > 0.002) 45.0 else 25.0) * dt))
        // body roll / pitch: damped springs: load transfer + terrain slope
        val rollT = (car.ay * 0.0035).coerceIn(-0.06, 0.06) + atan(sl)
        val pitchT = (-car.axS * 0.0025).coerceIn(-0.05, 0.05) - atan(g) - atan(bsl)
        rollV += ((rollT - roll) * 60 - rollV * 9) * dt; roll += rollV * dt
        pitchV += ((pitchT - pitch) * 60 - pitchV * 9) * dt; pitch += pitchV * dt
        EngineSound.set(car.rpm, car.throttle, abs(car.speed), car.gear, max(car.brake, car.drift * min(abs(car.vy) / 2, 1.0)))
        potholes(sH, cH, dt)
        life += dt; if (toastT > 0) { toastT -= dt; if (toastT <= 0) toast = null }
        val wasOnPier = Harbor.onPier
        Harbor.update(car)
        if (!wasOnPier && Harbor.onPier && life > 3.0) showToast("Harbor pier")
        val onGround = bh < 0.002 && !Harbor.onPier      // no tyre marks / mud on the pier deck
        Marks.update(car, pose.y + 0.02, onGround)
        Mud.update(car, dt, pose.y, g, sl, onGround)
        Smoke.update(car, dt, pose.y + 0.12)
        env.update(dt)
        Birds.update(car, dt, env.skySun[1].toDouble(), Settings.flocks)
        EngineSound.setEnv(env.day.toDouble(), env.night.toDouble())
        cam.update(car, pose, dt)
    }

    /** JS wheel block: soft spring + damper, 2 cm stop; a faint body nod as a tyre climbs out of a hole */
    private fun potholes(sH: Double, cH: Double, dt: Double) {
        val spd = abs(car.speed); val A = 1.4; val B = 0.85
        for (i in 0..3) {
            val f = if (i < 2) A else -A; val l = if (i % 2 == 0) B else -B
            val pd = Potholes.at(car.x + sH * f + cH * l, car.z + cH * f - sH * l)
            wv[i] += (110 * (-0.02 * pd - wy[i]) - 21 * wv[i]) * dt; wy[i] = (wy[i] + wv[i] * dt).coerceIn(-0.02, 0.01)
            if (pp[i] > 0.35 && pd <= 0.35 && spd > 4) {
                val k = min(spd / 20, 1.0)
                pitchV += (if (f > 0) 0.035 else -0.02) * k; rollV += (if (l > 0) 0.02 else -0.02) * k
            }
            pp[i] = pd; wheelDy[i] = wy[i].toFloat()
        }
    }
}
